# Admin guide

For community owners and admins who want to give members Claude skills built from their own material.
Install the starter bundle first (see [README.md](README.md#install-once)).

The path is: **build** skills from what you already have → **check** them → **ship** them to members →
**update** them.

## 1. Choose what to build

| You already have | Tool | You get |
|---|---|---|
| Classroom lessons (text, Markdown, or HTML pasted from your course) | `skool-kit classroom-to-skill` | A tutor skill that answers from your lessons, cites lesson titles and links back to your classroom |
| n8n workflows or Make.com scenarios you share as templates | `skillport convert` / `batch` | One skill folder per workflow, with setup steps for members and a "Conversion check" list for you |
| A live n8n workflow members should keep using | `skillport convert --mode bridge` | A small skill that calls your workflow's webhook and shows the result |
| Skills you wrote by hand | `skillkit new`, then edit | A skill that already passes the checks |

What members need on their side depends on where they use Claude:

| Members use | They need | You ship |
|---|---|---|
| Claude Code | Claude Code installed | One plugin (`skillkit pack --marketplace`) |
| Claude app (claude.ai, desktop), Free/Pro/Max | Code execution turned on in Settings | One `.zip` per skill (`skillkit pack --format claude-app`) |
| Claude app on your Team/Enterprise organization | Nothing: an owner uploads once for everyone | Same zips, uploaded in Organization settings |
| OpenClaw | OpenClaw installed | The skill folders (or `skillkit pack --format clawhub`, layout not yet verified) |

Sources (checked 2026-10-29): [Claude Code skills](https://code.claude.com/docs/en/skills),
[Claude Code plugins](https://code.claude.com/docs/en/discover-plugins),
[Use skills in Claude](https://support.claude.com/en/articles/12512180-use-skills-in-claude),
[Provisioning skills for an organization](https://support.claude.com/en/articles/13119606-provisioning-and-managing-skills-for-your-organization),
[OpenClaw skills](https://docs.openclaw.ai/tools/skills).

## 2. Build

Classroom tutor (copy each lesson into a file; one folder per module; numbers set the order):

```bash
skool-kit classroom-to-skill lessons --name my-community-tutor --community-name "My Community" \
  --classroom-url "https://www.skool.com/my-community/classroom" -o my-skills
```

Videos are not transcribed. Paste a transcript or notes into the lesson file.

Automation templates:

```bash
skillport batch my-blueprints -o my-skills --brand-name "My Community" --brand-url "https://example.com"
```

## 3. Brand

| What | How | What stays |
|---|---|---|
| Skill names and descriptions | Edit the `name:` and `description:` lines at the top of each `SKILL.md` | `name` must be lowercase letters, digits and hyphens, max 64 characters, and must not contain "claude" or "anthropic" |
| The "Converted with skillport" footer in member READMEs | `--brand-name` and `--brand-url` | Nothing required: the footer is optional |
| Tutor wording | `--community-name`, `--classroom-url`, or edit the generated `SKILL.md` | |
| Welcome messages | `skool-kit rules -o rules.yaml`, edit, then pass `--rules rules.yaml` | |
| Dashboard and HTML reports | `--community-name`, `--brand-color` and similar options per tool | |
| The tools themselves | You may rename and redistribute them (MIT) | Keep each tool's `LICENSE` file and copyright line in any copy of the code you hand out |

## 4. Check before you share

```bash
skillkit lint my-skills
```

- **Errors** (broken links, leaked keys, invalid names) must be fixed. `pack` refuses to package a library with errors.
- **`needs-review`** warnings come from skillport. Open the skill's `SKILL.md`, read its **Conversion check** list
  (code steps, schedules, AI steps, loops, error handling that didn't carry over), fix what matters, then delete the
  `<!-- skillport: needs-review -->` line.
- **`frontmatter-upload-key`** warnings mean the Claude app would reject the skill's header. Remove the listed key.

Then test each skill by hand: install it (section 5) and ask Claude to do the job on test data. That is the only
check of the real thing.

Optional, needs an API key and costs a few API calls per case: write sample inputs and expected traits in a
`cases.yaml` (see `skillkit/examples/cases.yaml`) and run

```bash
skillkit eval my-skills --cases cases.yaml --provider anthropic --format html -o eval.html
```

This sends each skill's instructions and one sample message to the model and checks the answer. It does not run
tools, scripts or reference files. It's most useful as a baseline to re-run after model updates
(`--format json -o baseline.json`, later `--baseline baseline.json`).

## 5. Ship to members

**Claude Code members (one plugin, easy updates).**

```bash
skillkit pack my-skills -o dist --name my-community-skills --version 1.0.0 --author "My Community" --marketplace
```

Push the `dist/` folder to a GitHub repository your members can read. Members run:

```
/plugin marketplace add your-org/your-repo
/plugin install my-community-skills@my-community-skills-marketplace
```

**Claude app members.**

```bash
skillkit pack my-skills -o dist --name my-community-skills --version 1.0.0 --author "My Community" --format claude-app
```

Share the zips from `dist/my-community-skills/` (classroom post, Drive folder, file attachment) together with its
`INSTALL.md`. Each member uploads each zip: Customize > Skills > + > Create skill > Upload a skill, with code
execution turned on in Settings > Capabilities.

**Team or Enterprise organization.** An owner uploads each zip once in Organization settings > Plugins & skills >
Add > Upload a skill. Everyone in the organization gets it; members can turn it off but not delete it.

Point members to [MEMBER-GUIDE.md](MEMBER-GUIDE.md) (or your own copy of it).

## 6. Update

1. Change the source (lessons, workflows) and rebuild, or edit the skill.
2. `skillkit lint my-skills` again.
3. Pack with a higher `--version` (for example `1.1.0`).
4. Claude Code: push the new `dist/`. Members open `/plugin marketplace update`, pick your marketplace and choose
   "Update marketplace". Claude app: members delete the old skill and upload the new zip. Team/Enterprise owners
   upload the new version in Organization settings.
5. Post a short "what changed" note for members.

To update the tools themselves, see [CHANGELOG.md](CHANGELOG.md#upgrading).

## Support load: what members usually trip on

| Problem | Prevent it by |
|---|---|
| "The skill doesn't show up" | Tell them which surface you support (Claude Code or the app) and link the right install steps |
| Upload rejected in the Claude app | Run `skillkit lint`; fix `frontmatter-upload-key` warnings; use `pack --format claude-app` zips (the skill folder must be at the top of the zip) |
| "It asks for an API key" | Converted skills list the accounts they need under "Required credentials". Say which ones are required before members start |
| Converted skill behaves differently from the n8n original | Review the Conversion check before sharing; offer a bridge skill for workflows that must stay exact |
| Bridge skill says only "Workflow was started" | Set the n8n Webhook node to respond when the last node finishes, or use a Respond to Webhook node |
