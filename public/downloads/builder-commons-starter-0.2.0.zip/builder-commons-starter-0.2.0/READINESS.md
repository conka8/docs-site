# Readiness

<!-- Generated from docs-site/src/data/readiness.js by `npm run readiness`. Edit that file, not this one. -->

What each integration has been tested against. Passing tests against fakes does not make an integration
production ready; only a live check (with a date and version) does.

Totals: 10 work locally, 19 tested against fakes only, 0 live verified, 5 unverified or unsupported.

| Status | Meaning |
|---|---|
| Works locally | Runs end to end on a local machine with the bundled sample data. No outside service involved. |
| Fakes only | Tested against fakes, fixtures or a local test server built from public docs. Not yet run against the real service. |
| Live verified | Run against the real service on the date and version shown. |
| Unverified | Best guess from public information, or not supported. Check before relying on it. |

## skillport

| Integration | Status | Evidence | Live check |
|---|---|---|---|
| n8n workflow JSON import | Fakes only | Fixtures modelled on public exports. Top-level fields (nodes, connections keyed by node name) match n8n's API schema, checked 2026-10-29; per-node parameters are not verified. | Not yet |
| Make.com blueprint import | Fakes only | Fixtures modelled on public blueprints. No official schema found. | Not yet |
| Bridge skill calling an n8n webhook | Fakes only | Tested against a local test server. Webhook auth options match n8n docs (checked 2026-10-29). Not run against a real n8n instance. | Not yet |
| Generated skill loads in Claude Code / Claude app | Fakes only | Output passes skillkit lint, whose rules follow the official skill limits (checked 2026-10-29). Not loaded in a live session. | Not yet |
| Browser converter (web/index.html) | Works locally | Its JavaScript runs under the test suite with Node. | Not yet |

## skillkit

| Integration | Status | Evidence | Live check |
|---|---|---|---|
| lint, new, pack (files on disk) | Works locally | Runs on the bundled sample library. | Not yet |
| eval with Anthropic Messages API | Fakes only | Request and response shapes tested against fakes. | Not yet |
| eval with OpenAI-compatible APIs | Fakes only | Request and response shapes tested against fakes. | Not yet |
| Claude Code plugin + marketplace from pack | Fakes only | Layout follows Claude Code plugin docs (checked 2026-10-29). Not installed in a live session. | Not yet |
| Claude app upload zips from pack --format claude-app | Fakes only | Zip layout follows the Claude help center (checked 2026-10-29). Not uploaded to a live account. | Not yet |
| ClawHub bundle from pack --format clawhub | Unverified | Layout is a best guess. | Not yet |

## skool-owner-kit

| Integration | Status | Evidence | Live check |
|---|---|---|---|
| Classroom files to tutor skill | Works locally | Runs on the bundled sample classroom. | Not yet |
| Welcome messages and dashboard from CSV | Works locally | Runs on the bundled sample export. | Not yet |
| Real Skool member export columns | Unverified | Skool doesn't document its export columns. Columns are matched loosely; run skool-kit inspect first. | Not yet |
| Zapier webhook receiver | Fakes only | Tested with a local HTTP server. Trigger names (Answered Membership Questions, New Paid Member) checked against Skool and Zapier pages 2026-10-29; field names in real Zap payloads not seen. | Not yet |
| AI-personalised messages (Anthropic / OpenAI) | Fakes only | Tested against fakes. Falls back to the template message on any failure. | Not yet |

## shipsafe

| Integration | Status | Evidence | Live check |
|---|---|---|---|
| Folder scan (secrets, config, code checks) | Works locally | Runs on the bundled demo app. | Not yet |
| URL scan and Supabase checks | Fakes only | Tested against a local test server and fakes. | Not yet |

## geo-audit

| Integration | Status | Evidence | Live check |
|---|---|---|---|
| Demo provider | Works locally | Runs offline with canned answers (reports are marked demo data). | Not yet |
| OpenAI | Fakes only | Tested against saved response fixtures. | Not yet |
| Anthropic (web search tool) | Fakes only | Tested against saved response fixtures. | Not yet |
| Perplexity | Fakes only | Tested against saved response fixtures. | Not yet |
| Gemini | Fakes only | Tested against saved response fixtures. | Not yet |

## ghl-agency-kit

| Integration | Status | Evidence | Live check |
|---|---|---|---|
| Demo account (fake API) | Works locally | Runs offline (reports are marked demo data). | Not yet |
| GoHighLevel API v2 | Fakes only | Tested against a built-in fake API and a local server. Endpoint versions not checked against a live sub-account. | Not yet |

## voice-qa

| Integration | Status | Evidence | Live check |
|---|---|---|---|
| Scripted demo receptionist | Works locally | Runs offline (reports are marked demo data). | Not yet |
| Your agent over an HTTP webhook | Fakes only | Tested against a local test server. | Not yet |
| Simulated caller via OpenAI / Anthropic | Fakes only | Tested against fakes. | Not yet |
| Vapi / Retell assistant import | Fakes only | Tested against hand-written export files. | Not yet |
| Audio or phone calls | Unverified | Not supported: voice-qa tests text conversations only. | Not yet |

## career-labs

| Integration | Status | Evidence | Live check |
|---|---|---|---|
| Labs and local grader | Works locally | Every reference solution scores 100%; starters score lower. | Not yet |
| GitHub Classroom autograding workflow | Unverified | Not run on GitHub. | Not yet |

## vertical-packs

| Integration | Status | Evidence | Live check |
|---|---|---|---|
| Calculators and checks | Works locally | Run offline on the bundled examples. | Not yet |
| Platform limits (Airbnb, KDP, carrier insurance) | Unverified | Kept in one constants file per pack; not checked against current platform rules. | Not yet |

## Live checks still to do

Each needs an account the maintainer controls (never a customer's) and is a manual run. Record the date,
version or plan, and what you ran in `docs-site/src/data/readiness.js`, then regenerate this file.

1. Upload a `skillkit pack --format claude-app` zip to a Claude account and run it.
2. Install a `skillkit pack --marketplace` plugin in Claude Code from a GitHub repository.
3. Convert a real exported n8n workflow and a Make.com blueprint; run a bridge skill against a test n8n instance.
4. Run `skillkit eval --provider anthropic` and `--provider openai` with a small key.
5. Import a real Skool member export and receive one real Zapier test event.
6. One small run per AI provider in geo-audit and voice-qa; one read-only ghl-kit report on a test sub-account.
