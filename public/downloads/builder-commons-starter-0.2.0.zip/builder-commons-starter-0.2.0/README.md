# Builder Commons

Free, open-source (MIT) command-line tools and Claude skills for people who run online communities, teach AI
automation or run small agencies. The focus is one job: **give your members useful, branded AI skills with little
setup and little support work.**

## Who it's for

- **Community admins** (Skool owners, course creators, automation educators) who want to hand members Claude skills
  built from their own lessons and automations. Start with the [Admin guide](ADMIN-GUIDE.md).
- **Members** who received a skill or a tool from their community. Start with the [Member guide](MEMBER-GUIDE.md).

## What's here

**Starter bundle** (what most admins need first):

| Tool | Command | What it does |
|---|---|---|
| [skool-owner-kit](skool-owner-kit) | `skool-kit` | Turns your classroom lessons into a tutor skill, writes welcome messages from join answers, and builds an inactivity dashboard from your exports |
| [skillport](skillport) | `skillport` | Converts n8n workflows and Make.com scenarios into skill folders, with a list of what to check before you share each one |
| [skillkit](skillkit) | `skillkit` | Checks a skill library, tests skill instructions against a model, and packages the library for Claude Code or the Claude app |

**More tools** (useful for specific audiences): [shipsafe](shipsafe) (pre-launch checks for AI-built apps),
[geo-audit](geo-audit) (how AI assistants answer about a business), [ghl-agency-kit](ghl-agency-kit) (GoHighLevel
reports and onboarding), [voice-qa](voice-qa) (text-based tests for AI receptionists),
[career-labs](career-labs) (graded practice labs), [vertical-packs](vertical-packs) (niche calculators and checks).

What each tool has been tested against, and what has not been checked against a live service yet, is in
[READINESS.md](READINESS.md). Short version: everything runs locally with sample data; **no third-party
integration has been verified against a live account yet.**

## Install (once)

You need Python 3.10 or newer. Download the starter bundle zip from the docs site (Downloads), unzip it, and open
a terminal in the unzipped folder.

macOS / Linux:

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install ./skool-owner-kit ./skillport ./skillkit
```

Windows (PowerShell):

```powershell
py -m venv .venv
.venv\Scripts\Activate.ps1
python -m pip install .\skool-owner-kit .\skillport .\skillkit
```

If PowerShell says running scripts is disabled, run
`Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser` once and try again
([Python docs](https://docs.python.org/3/library/venv.html)).

Check it worked: `skool-kit --version`, `skillport --version`, `skillkit --version` each print a version number.
Open a new terminal later? Activate the environment again first (`source .venv/bin/activate` or
`.venv\Scripts\Activate.ps1`).

## First successful run (2 minutes, no account or API key)

From the unzipped bundle folder, with the environment active:

```bash
skool-kit classroom-to-skill skool-owner-kit/examples/classroom --name ai-builders-tutor --community-name "AI Builders" -o my-skills
skillport batch skillport/examples -o my-skills
skillkit lint my-skills
skillkit pack my-skills -o dist --name ai-builders-skills --author "AI Builders" --format claude-app
```

You should end with:

- `my-skills/` holding 4 skill folders: a classroom tutor and 3 converted workflows.
- A lint summary of `Checked 4 skills: 0 errors, 3 warnings`. The warnings are the converted skills'
  "Conversion check" lists, waiting for you to review them.
- `dist/ai-builders-skills/` holding one upload `.zip` per skill and an `INSTALL.md` with the upload steps.

## Documentation

| Guide | For |
|---|---|
| [ADMIN-GUIDE.md](ADMIN-GUIDE.md) | Choosing tools, branding, checking, distributing and updating skills |
| [MEMBER-GUIDE.md](MEMBER-GUIDE.md) | Installing a skill or tool, connections, examples, troubleshooting |
| [READINESS.md](READINESS.md) | What was tested how, per integration, and what's still unverified |
| [DATA-AND-COSTS.md](DATA-AND-COSTS.md) | What data each tool reads and sends, and which steps cost API money |
| [CHANGELOG.md](CHANGELOG.md) | Release notes and upgrade steps |
| [MAINTAINING.md](MAINTAINING.md) | Keeping code, docs and downloads in sync |
| Each tool's `README.md` | Full command reference and limits |

## License

Every tool is MIT licensed (see the `LICENSE` file in each folder). You may use, change, rebrand and resell them.
The one requirement: keep the copyright and license notice in copies of the code you pass on. Skills and reports
the tools generate from your own content are yours.
