"""skillkit: lint, test (eval) and package libraries of Claude / OpenClaw skills."""

__version__ = "0.2.0"
