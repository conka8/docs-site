"""Upload-key and review lint rules, honest eval labels, Claude app zips and the bundled examples."""
import json
import zipfile
from pathlib import Path

from skillkit.cli import main
from skillkit.constants import REVIEW_MARKER
from skillkit.evaluate import load_cases, render_report, run_eval
from skillkit.lint import lint_path
from skillkit.providers import FakeProvider

from conftest import write_skill

EXAMPLES = Path(__file__).parent.parent / "examples"


def rules(path):
    return [i.rule for i in lint_path(path).issues]


def test_upload_key_warning(tmp_path):
    write_skill(tmp_path, "a", "name: a\ndescription: Does a thing. Use when testing.\nwhen_to_use: later")
    result = lint_path(tmp_path)
    issue = next(i for i in result.issues if i.rule == "frontmatter-upload-key")
    assert issue.severity == "warning" and issue.line == 4 and '"when_to_use"' in issue.message
    write_skill(tmp_path, "b", "name: b\ndescription: Does a thing. Use when testing.\nlicense: MIT\nallowed-tools: Bash")
    assert "frontmatter-upload-key" not in rules(tmp_path / "b")


def test_needs_review_warning_until_marker_is_deleted(tmp_path):
    d = write_skill(tmp_path, "converted", body=f"## Conversion check\n\n- check this\n\n{REVIEW_MARKER}\n")
    issue = next(i for i in lint_path(d).issues if i.rule == "needs-review")
    assert issue.severity == "warning" and issue.line == 10
    (d / "SKILL.md").write_text((d / "SKILL.md").read_text().replace(REVIEW_MARKER, ""), encoding="utf-8")
    assert "needs-review" not in rules(d)


def test_needs_review_fails_only_with_strict(tmp_path, capsys):
    write_skill(tmp_path, "converted", body=f"{REVIEW_MARKER}\n")
    assert main(["lint", str(tmp_path)]) == 0
    assert main(["lint", str(tmp_path), "--strict"]) == 1


def test_eval_report_is_labelled_instruction_only_and_demo():
    cases, _ = load_cases(EXAMPLES / "cases.yaml")
    report = run_eval(EXAMPLES / "skills", cases, FakeProvider())
    assert report["mode"] == "instruction-only" and report["demo"] is True
    assert report["files_not_sent"] == {"linkedin-post": ["references/voice.md"]}
    text = render_report(report, "text")
    assert text.splitlines()[1].startswith("DEMO DATA: The 'fake' provider")
    assert "Instruction-only test" in text and "Not sent to the model for linkedin-post: references/voice.md" in text
    html = render_report(report, "html")
    assert 'class="demo"' in html and "Instruction-only test" in html
    assert json.loads(render_report(report, "json"))["demo"] is True


def test_real_provider_report_has_no_demo_banner():
    class Real(FakeProvider):
        name = "anthropic"
    cases, _ = load_cases(EXAMPLES / "cases.yaml")
    report = run_eval(EXAMPLES / "skills", cases, Real())
    assert report["demo"] is False
    assert "DEMO DATA" not in render_report(report, "text")
    assert 'class="demo"' not in render_report(report, "html")
    assert "Instruction-only test" in render_report(report, "text")


def test_pack_claude_app_one_zip_per_skill(tmp_path, capsys):
    out = tmp_path / "out"
    assert main(["pack", str(EXAMPLES / "skills"), "-o", str(out), "--name", "demo-skills", "--author", "Demo",
                 "--format", "claude-app"]) == 0
    assert "2 upload zip(s)" in capsys.readouterr().out
    root = out / "demo-skills"
    with zipfile.ZipFile(root / "linkedin-post.zip") as zf:
        assert sorted(zf.namelist()) == ["linkedin-post/SKILL.md", "linkedin-post/references/voice.md"]
    assert (root / "summarize-email.zip").is_file()
    assert not (root / ".stage").exists()
    install = (root / "INSTALL.md").read_text(encoding="utf-8")
    assert "Upload a skill" in install and "- linkedin-post.zip" in install


def test_pack_claude_app_names_zip_folder_after_the_skill(tmp_path):
    lib = tmp_path / "lib"
    write_skill(lib, "Folder Name", "name: real-name\ndescription: Does a thing. Use when testing.")
    assert main(["pack", str(lib), "-o", str(tmp_path / "o"), "--name", "x", "--author", "A",
                 "--format", "claude-app", "--force"]) == 0
    with zipfile.ZipFile(tmp_path / "o" / "x" / "real-name.zip") as zf:
        assert zf.namelist() == ["real-name/SKILL.md"]


def test_bundled_examples_lint_clean_and_eval(capsys):
    assert main(["lint", str(EXAMPLES / "skills"), "--strict"]) == 0
    assert main(["eval", str(EXAMPLES / "skills"), "--cases", str(EXAMPLES / "cases.yaml")]) == 0
    assert "2 of 2 cases passed" in capsys.readouterr().out
