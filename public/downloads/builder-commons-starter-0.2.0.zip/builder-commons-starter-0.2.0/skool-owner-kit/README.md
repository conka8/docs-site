# skool-owner-kit

Free tools for Skool community owners: personalised welcome messages for new members, an inactivity-risk dashboard,
and a "classroom tutor" Claude/OpenClaw skill built from your lessons.

**It only uses your own data**: CSV exports you download and Zapier/webhook events you send it.
We found no public Skool API documentation (checked 2026-10-29); Skool's own integration is its Zapier app. This kit does **not** scrape Skool, does not log in as you and never needs
your Skool password or cookies.

Python 3.10+, no dependencies besides PyYAML. MIT licensed.

## Install

```bash
pip install .        # from this folder (not on PyPI yet)
skool-kit --version
```

Try every command on the sample files in `examples/` first.

## 1. Check your export

```bash
skool-kit inspect examples/members.csv
```

```
Delimiter: comma
Columns used:
  name          <- Name
  email         <- Email
  joined        <- Joined Date
  answers       <- Question 1, Question 2
  ...
Read 36 member(s) from 36 row(s).
```

Column names are matched loosely (case doesn't matter): "Name" / "Full Name" / "First Name"+"Last Name", "Email",
"Joined" / "Join Date" / "Approved At", "Answers" / "Question 1..3" / "Membership Questions" / any column ending
in "?", "Level", "Points", "Last Active" / "Last Seen", "Posts", "Comments", "Price" / "Plan" / "Tier",
"Invited By", "LTV". Comma, semicolon and tab files, Excel's BOM and Windows encodings all work.
Dates can be `2026-10-03`, `10/3/2026 2:15 PM`, `Oct 3, 2026`, `3d ago`...

If a column isn't picked up, tell the tool: `--map "What brings you here?=answers"`.
Day/month/year dates: add `--dayfirst`. Rows without a name or email, and duplicates, are skipped and listed.

## 2. Welcome messages for new members

```bash
skool-kit onboard examples/members.csv --since 2026-10-14 --community-name "AI Builders" -o messages.csv
skool-kit onboard examples/members.csv --since 2026-10-14 -o messages.md     # easy to read
```

Each member's join-question answers decide their **segment** (beginner, agency owner, developer, business owner,
job seeker) and **goal** (first client, build an app, automate my business, get hired, learn AI). That picks
3 lessons and a first action:

```
Hey Ana, welcome to AI Builders! Since you want to land your first client, here's your first week:
1. Start Here: How This Community Works
2. The AI Agency Offer That Sells
3. Finding Your First Client in 7 Days
Your first action: Write down 10 local businesses you could help and share your niche in the wins channel.
Reply here if you get stuck. Happy to help!
```

**Use your own lesson names**: `skool-kit rules -o rules.yaml`, edit it (keywords, lesson titles, wording;
placeholders `{first_name} {goal} {lesson_1} {lesson_2} {lesson_3} {first_action} {community_name}`), then
add `--rules rules.yaml`.

**Optional AI personalisation**: `--llm anthropic` (env `ANTHROPIC_API_KEY`, model `claude-sonnet-5-5` by default)
or `--llm openai` (env `OPENAI_API_KEY`, `OPENAI_MODEL`, and `OPENAI_BASE_URL` for any OpenAI-compatible service).
If the AI call fails, or its reply drops a lesson name, the template message is used instead.

## 3. Automatic welcomes with Zapier

```bash
export SKOOL_KIT_SECRET="a-long-random-secret"      # Windows PowerShell: $env:SKOOL_KIT_SECRET="a-long-random-secret"
skool-kit webhook --host 0.0.0.0 --port 8787 --rules rules.yaml \
  --forward-url "https://hooks.zapier.com/hooks/catch/123/abc/"
```

`--secret` also works, but it ends up in your shell history, so prefer the environment variable.

In Zapier (Skool's Zapier app needs Skool's **Pro** plan; the API key is in your group settings > Plugins > Zapier):

- **Trigger:** Skool **Answered Membership Questions** (fires when someone answers your join questions), or
  **New Paid Member** for paid groups. Skool's Zapier app has no trigger for every new free member.
- **Action:** **Webhooks by Zapier (POST)** to `https://your-server:8787/`, payload type JSON, with the member's
  name, email and answers, and a header `X-Skool-Kit-Secret: a-long-random-secret`
  (`?secret=...` in the URL also works, but URLs are often logged).

Trigger names come from Skool's help center and Zapier's Skool app page, checked 2026-10-29:
https://help.skool.com/article/56-zapier-integration and https://zapier.com/apps/skool/integrations.

Field names are matched like CSV columns (nested JSON is fine); add `--map "Zap Field=email"` if needed.

Each event: the message is returned (200), appended to `outbox.jsonl`, and forwarded to `--forward-url`
(e.g. a second Zap that sends the email or DM). Wrong secret: 401. Bad JSON: 400. Health check: `GET /health`.
Connections that stall for 30 seconds are dropped. Run it behind HTTPS (a reverse proxy or a tunnel) when it's
reachable from the internet.

`outbox.jsonl` contains members' names, emails and answers. Keep it on your own machine and delete it when you
no longer need it.

## 4. Engagement and inactivity-risk dashboard

```bash
skool-kit health examples/members.csv --activity examples/activity.csv \
  --community-name "AI Builders" -o dashboard.html --at-risk at_risk.csv --as-of 2026-10-28
```

```
36 members, 77.8% active in 30 days, 15 at risk (8 paying).
```

`--as-of 2026-10-28` makes the sample data give the same result every day. Leave it out for your own exports
(it defaults to today).

`dashboard.html` is one file (no internet needed, prints to PDF): active % (7/30 days), new members per week,
at-risk paying members, cohort activity by join month, inactivity-risk bands, top contributors, and the at-risk list
with a suggested re-engagement message for each person. `at_risk.csv` / `.json` has the same list.

**Activity history** (optional, makes trends work): save the member export every week and stack the files into one
CSV with a date column: `Email, Snapshot Date, Posts, Comments, Level, Points`.

The risk score is a transparent heuristic built from activity in your exports. It flags members who have gone
quiet; it does not predict cancellations, and the dashboard says so. How the score (0-100) works:

| Signal | Points |
|---|---|
| Last active 4-7 / 8-14 / 15-30 / 31+ days ago (unknown: 20) | 10 / 25 / 40 / 55 |
| Never posted or commented (member 14+ days; newer: 5) | 15 |
| Stopped posting (needs 3+ snapshots) / posting less than half as much | 20 / 12 |
| No new posts since the last snapshot (2 snapshots) | 8 |
| Same level for 28+ days, or still level 1 after 30 days | 10 |
| Member for 6+ months | -5 |

60+ is high risk, 35-59 medium (`--threshold` changes the at-risk cut-off). Paying vs free does not change the
score; paying members are listed first and counted in "at-risk paying members".

## 5. Classroom -> AI tutor skill

Copy your lessons into folders (one folder per module, numbers set the order; `.md`, `.txt` or `.html` files):

```
lessons/
  01-start-here/01-welcome.md
  01-start-here/02-ai-basics.txt
  02-finding-clients/1 - The offer that sells.html
```

```bash
skool-kit classroom-to-skill examples/classroom --name ai-builders-tutor --community-name "AI Builders" \
  --classroom-url "https://www.skool.com/your-community/classroom" -o skills-out/
```

You get `skills-out/ai-builders-tutor/SKILL.md` (instructions + a lesson index) and
`references/<module>/<lesson>.md`. Long lessons are split into parts, empty files are skipped with a warning,
HTML is turned into clean text. The tutor answers from your lessons, cites lesson titles, links back to your
classroom and says when something isn't covered. Put the folder in `~/.claude/skills/` (Claude Code / Cowork) or
your OpenClaw skills folder, or upload it to Claude.

## Claude skill

`skills/skool-onboarding/SKILL.md` teaches Claude to run the onboarding commands for you.

## Limits

- Skool's export columns and Zapier field names are not documented publicly and could not be verified here;
  that's why every column is matched loosely and can be overridden with `--map`. Run `skool-kit inspect` first.
- A member export only contains current members, so "cohort activity" means "share of each join-month cohort that was
  active in the last 30 days", not cancellations.
- Trends need several weekly exports stacked into an activity file; with a single export the score uses
  last-active date, post counts, level and tenure only.
- The keyword rules are simple and transparent (no AI needed). Review messages before sending them.
- Classroom videos aren't transcribed: paste transcripts or notes into the lesson files.

## Development

```bash
cd skool-owner-kit && ../.venv/bin/python -m pytest -q
```

Tests run offline (the webhook tests use local servers on 127.0.0.1, LLM calls are faked).
