# Member guide

For members who received a skill or a tool from their community. You don't need to know how to code.

**First, know which thing you got:**

| You got | What it is | Do this |
|---|---|---|
| A `.zip` or a folder with a `SKILL.md` inside | A **skill**: instructions Claude follows | [Install a skill](#install-a-skill) |
| A plugin name and a `/plugin marketplace add ...` line | A **Claude Code plugin**: several skills in one package | [Install a plugin](#install-a-plugin-claude-code) |
| A tool zip like `shipsafe-0.1.1.zip` | A **command-line tool** (Python) that you run in a terminal | [Install a tool](#install-a-command-line-tool) |

None of these are websites or hosted apps: they run on your computer or inside your own Claude account.

## Install a skill

**Claude app (claude.ai or the desktop app)**

1. Settings > Capabilities: turn on **Code execution and file creation**.
2. Customize > Skills > **+** > **Create skill** > **Upload a skill**, and choose the `.zip`.
3. Start a new chat and ask for the job in plain words, e.g. *"Use the my-community-tutor skill: how do I price my
   first offer?"*

Works on Free, Pro, Max, Team and Enterprise plans. On Team/Enterprise your organization's owner may have to allow
skills first; if they uploaded the skill for everyone, it is already there.
Source: [Use skills in Claude](https://support.claude.com/en/articles/12512180-use-skills-in-claude) (checked 2026-10-29).

**Claude Code**

Put the skill folder (the folder that contains `SKILL.md`, not the zip) in:

- macOS / Linux: `~/.claude/skills/<skill-name>/`
- Windows: `%USERPROFILE%\.claude\skills\<skill-name>\`

Claude Code notices new skills without a restart. If the `skills` folder didn't exist when you started Claude Code,
type `/reload-skills`. Then ask for the job, or type `/<skill-name>`.
Source: [Claude Code skills](https://code.claude.com/docs/en/skills) (checked 2026-10-29).

**OpenClaw**

Put the skill folder in `~/.openclaw/skills/` (all workspaces) or `<workspace>/skills/`.
Source: [OpenClaw skills](https://docs.openclaw.ai/tools/skills) (checked 2026-10-29).

## Install a plugin (Claude Code)

Type the two lines your community gave you, for example:

```
/plugin marketplace add your-community/skills
/plugin install your-community-skills@your-community-skills-marketplace
```

**Updates:** `/plugin marketplace update`, pick the marketplace, choose "Update marketplace".
Source: [Discover and install plugins](https://code.claude.com/docs/en/discover-plugins) (checked 2026-10-29).

## Connections and API keys

Open the skill's `README.md` or the **Required credentials / accounts** section of its `SKILL.md`:

- **None listed:** nothing to set up.
- **A service listed (Slack, Google Sheets, ...):** Claude needs a way to use that service. The easiest is a
  connector or MCP server for that service in your Claude app or Claude Code. Otherwise the skill names an
  environment variable (like `SLACK_TOKEN`) for a key.
- **Never paste keys into the chat.** Set them in your terminal before starting Claude Code:
  - macOS / Linux: `export SLACK_TOKEN="your-key"`
  - Windows PowerShell: `$env:SLACK_TOKEN="your-key"`
- **Bridge skills** (they say "runs in n8n") need only the webhook address your community gives you
  (`N8N_WEBHOOK_URL`) and sometimes a header (`N8N_WEBHOOK_HEADER`).

Some services charge for API use. See [DATA-AND-COSTS.md](DATA-AND-COSTS.md).

## Install a command-line tool

You need Python 3.10 or newer: [python.org/downloads](https://www.python.org/downloads/). On Windows, tick
"Add python.exe to PATH" in the installer.

1. Unzip the tool and open a terminal in the unzipped folder (the one with `pyproject.toml` in it).
2. Create a private environment and install the tool into it:

macOS / Linux:

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install .
```

Windows PowerShell:

```powershell
py -m venv .venv
.venv\Scripts\Activate.ps1
python -m pip install .
```

3. Check it: `<tool> --version` (for example `shipsafe --version`) prints a version number.
4. Run the tool's first example. Every tool's README starts with one that uses the files in its `examples/`
   folder and needs no account.

Each time you open a new terminal, activate the environment again (step 2's second line).

## Understand the result

- **Converted skills** (from n8n or Make.com) are written instructions. Claude follows them with its own tools; the
  original automation doesn't run, so results can differ. Read the **Conversion check** section in `SKILL.md`.
- **Reports marked "Demo data"** use made-up answers. They show what a report looks like, nothing more.
- **Scores and grades** (shipsafe grades, inactivity risk, AI-visibility scores) come from a fixed set of checks
  explained in each report. They are a starting point for a human decision.

## Troubleshooting

| You see | Do this |
|---|---|
| `command not found` / `is not recognized` after installing | Activate the environment again (install step 2), or reinstall inside it |
| `python3: command not found` on Windows | Use `py` instead of `python3` |
| PowerShell: "running scripts is disabled on this system" | Run `Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser` once ([Python docs](https://docs.python.org/3/library/venv.html)) |
| `externally-managed-environment` from pip | You're installing outside a virtual environment. Do install step 2 first |
| The skill zip upload fails | Ask your community for the `pack --format claude-app` zip: the skill folder must be at the top of the zip, and its name must match the skill name |
| Claude doesn't use the skill | Name it in your request ("use the X skill"), check it's switched on in Customize > Skills, start a new chat |
| `... is not set` (an API key) | Set the key in the same terminal, then start Claude Code or the tool again |
| Bridge skill: `HTTP 404` | The workflow is switched off, or it's a test URL (`/webhook-test/`). Ask for the production URL |
| Bridge skill: only "Workflow was started" | Your community needs to change the n8n Webhook node's Respond setting |
| Exit code 2 from a tool | Bad input or a missing key: read the error line, it says which |

Still stuck? Send your community the exact command you ran and the full error text, but **remove any keys** first.
