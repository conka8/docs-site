# Pilot plan

How to find out whether a member pack helps new members reach their first win, and whether that's worth what it
costs. `skool-kit pack-build` writes the plan and empty logs into `member-pack/pilot/`; `skool-kit pilot` reads them.

## Before you start: is this a fit?

Answer these first. Several "poor fit" answers mean: don't pay for implementation; try the free tools or skip it.

| Question | Answer that signals a poor fit |
|---|---|
| What outcome do you promise new members early on, and how do you know someone reached it? | No clear outcome, or no way to see it |
| How many new paid members join per month, and what share renew after month 1? | Under about 20 a month (a pilot takes months), or renewal already above 90% |
| Do your lessons contain a method members can follow step by step? | Mostly motivation, or video without transcripts |
| Which AI tools do your members use? | Mostly ChatGPT and unwilling to use Claude |
| How many hours a week go into answering the same questions? | Under an hour |
| Who will review the skills and update them when lessons change? | Nobody |
| Would you include the pack in membership or sell it separately? | Separately: no evidence yet that members pay extra; test that on its own |
| Can you log first outcomes and renewals per member for two cohorts? | No: you can try the pack but won't learn whether it worked |

## Design

| Part | What to do |
|---|---|
| Primary outcome | Share of new paid members who reach the first outcome within N days of joining (set in `pack.yaml`) |
| Pilot cohort | Every new paid member who joins in one calendar month gets the pack on day 1 |
| Baseline cohort | Members who joined in an earlier month, without the pack. Avoid months with a launch, sale or price change |
| Baseline period | Fill the baseline before the pilot starts: first outcomes from #wins posts, renewals from payment history |
| Adoption | Share of pilot members who install it, and who report using a skill |
| Quality | Manual acceptance runs before launch (`pilot/acceptance.csv`); tutor answers reviewed and the share corrected |
| Money | First-renewal rate per cohort (Skool's dashboard shows retention and churn), refunds |
| Costs | Every cash cost and every hour, in `pilot/costs.csv` |
| Problems | Anything unexpected goes in the `note` column of the logs |
| Length | One cohort month + the outcome window + the first renewal date: about two months |

Set the thresholds in `pilot.yaml` before you start, not after you've seen the numbers.

## Decision rules (defaults)

| Result | Suggestion |
|---|---|
| Fewer than 20 members in either cohort | Not enough data: run another month |
| Fewer than 40% of pilot members installed | Change: fix onboarding first |
| Outcome rate at least 10 points above baseline | Continue. If the 95% ranges overlap, run a second cohort before treating it as settled |
| Between 0 and 10 points | Extend: run another cohort |
| No better than baseline | Stop or change the tasks |
| More than 10% of reviewed tutor answers corrected | Fix the lessons or tutor before scaling |

**Sufficient evidence to continue:** two cohorts in a row above the continue threshold, adoption above target,
corrections under the limit, and a renewal difference that at least doesn't go the other way. **To stop:** no
outcome difference after two cohorts with good adoption, or corrections you can't bring down.

## What it can't tell you

- It compares two months of members, so it can't prove cause. Season, marketing and who joined also change.
- With 30-50 members per cohort only large differences stand out from chance; the report shows 95% ranges.
- Self-reported outcomes undercount. Log both cohorts the same way.
- Renewal is a later, noisier signal than the first outcome: a clue, not proof of revenue earned.
- Time freed is capacity, not cash, unless you cut paid hours.

## Try the report

`skool-owner-kit/examples/agency-lab/pilot-sample/` has synthetic logs (invented members and numbers):

```bash
skool-kit pilot skool-owner-kit/examples/agency-lab/pilot-sample/pilot.yaml
```

It suggests CONTINUE and warns that the 95% ranges overlap: with 40 members per cohort, a 16-point difference could
still be chance.
