# Builder Commons

Free, open-source (MIT) tools for owners of paid online communities, starting with AI-automation and AI-agency
communities on Skool. The main one turns **your lessons into Claude skills that walk each new member to their first
win**, using your method, and gives you a **pilot report** to see whether more members get there and stay.

## Who it's for

- **Community owners and admins** whose paid members should reach an early result (a first client, a first
  automation) and often don't. Start with the [Admin guide](ADMIN-GUIDE.md), then [PILOT.md](PILOT.md) and
  [VALUE-MODEL.md](VALUE-MODEL.md).
- **Members** who received a skill or a tool from their community. Start with the [Member guide](MEMBER-GUIDE.md).

## What's here

**Starter bundle:**

| Tool | Command | What it does |
|---|---|---|
| [skool-owner-kit](skool-owner-kit) | `skool-kit` | `pack-build`: a member pack from your lessons (tutor with citations, task skills for your first-win steps, acceptance checks, member and admin guides, pilot kit). `pilot`: compares a pilot cohort with a baseline. Also welcome messages and an inactivity dashboard |
| [skillkit](skillkit) | `skillkit` | Checks skills, tests them against a model (optionally with their lesson files), and packages them for Claude Code or the Claude app |
| [skillport](skillport) | `skillport` | Converts n8n workflows and Make.com scenarios into skill folders, with a list of what to check before you share each one |

**More tools** (useful for specific audiences): [shipsafe](shipsafe) (pre-launch checks for AI-built apps),
[geo-audit](geo-audit) (how AI assistants answer about a business), [ghl-agency-kit](ghl-agency-kit) (GoHighLevel
reports and onboarding), [voice-qa](voice-qa) (text-based tests for AI receptionists),
[career-labs](career-labs) (graded practice labs), [vertical-packs](vertical-packs) (niche calculators and checks).

What each tool has been tested against, and what has not been checked against a live service yet, is in
[READINESS.md](READINESS.md). Short version: everything runs locally with sample data; **no third-party
integration and no generated skill has been verified in a live Claude account yet**, and no community has run a
pilot. Why the member pack is the lead, with sources: [BUSINESS-AUDIT.md](BUSINESS-AUDIT.md).

## Install (once)

You need Python 3.10 or newer. Download the starter bundle zip from the docs site (Downloads), unzip it, and open
a terminal in the unzipped folder.

macOS / Linux:

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install ./skool-owner-kit ./skillport ./skillkit
```

Windows (PowerShell):

```powershell
py -m venv .venv
.venv\Scripts\Activate.ps1
python -m pip install .\skool-owner-kit .\skillport .\skillkit
```

If PowerShell says running scripts is disabled, run
`Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser` once and try again
([Python docs](https://docs.python.org/3/library/venv.html)).

Check it worked: `skool-kit --version`, `skillport --version`, `skillkit --version` each print a version number.
Open a new terminal later? Activate the environment again first (`source .venv/bin/activate` or
`.venv\Scripts\Activate.ps1`).

## First successful run (no account or API key)

From the unzipped bundle folder, with the environment active, build the worked example: a synthetic AI-agency
community (all names, lessons and numbers are invented):

```bash
skool-kit pack-build skool-owner-kit/examples/agency-lab/pack.yaml -o pack
skillkit lint pack/skills
skillkit eval pack/skills --cases pack/evals/cases.yaml
skillkit pack pack/skills -o dist --name northwind-skills --author "Northwind Agency Lab" --format claude-app
skool-kit pilot skool-owner-kit/examples/agency-lab/pilot-sample/pilot.yaml
```

You should see, in order:

- `Built pack: 3 skills (northwind-tutor, northwind-offer-builder, northwind-outreach-sprint)`.
- `Checked 3 skills: 0 errors, 0 warnings`.
- `5 of 5 cases passed` under a **DEMO DATA** line. These are the hand-written example answers, which shows the checks
  work, not that the skills do.
- `3 upload zip(s), one per skill`.
- A pilot report starting `Suggestion: CONTINUE`, followed by a warning that the cohorts' ranges overlap.

Then read `pack/ADMIN-REVIEW.md`: it is what you'd do with your own pack, including the manual run in Claude that
none of the above replaces.

## Documentation

| Guide | For |
|---|---|
| [ADMIN-GUIDE.md](ADMIN-GUIDE.md) | Building a member pack, branding, checking, distributing and updating skills |
| [PILOT.md](PILOT.md) | Fit questions, pilot design, decision rules |
| [VALUE-MODEL.md](VALUE-MODEL.md) | How to estimate whether it earns or saves more than it costs, with a worked example |
| [BUSINESS-AUDIT.md](BUSINESS-AUDIT.md) | What each tool is worth to whom, and the evidence |
| [MEMBER-GUIDE.md](MEMBER-GUIDE.md) | Installing a skill or tool, connections, examples, troubleshooting |
| [READINESS.md](READINESS.md) | What was tested how, per integration, and what's still unverified |
| [DATA-AND-COSTS.md](DATA-AND-COSTS.md) | What data each tool reads and sends, and which steps cost API money |
| [CHANGELOG.md](CHANGELOG.md) | Release notes and upgrade steps |
| [MAINTAINING.md](MAINTAINING.md) | Keeping code, docs and downloads in sync |
| Each tool's `README.md` | Full command reference and limits |

## License

Every tool is MIT licensed (see the `LICENSE` file in each folder). You may use, change, rebrand and resell them.
The one requirement: keep the copyright and license notice in copies of the code you pass on. Skills and reports
the tools generate from your own content are yours.
