# Value model

How to judge whether a member pack earns or saves more than it costs. The docs site has an editable version
("Estimate value"); the formulas live in `docs-site/src/data/value-model.js` and are tested.

**This is a decision aid, not evidence.** Every number below is an illustration, not a measurement or a result from
any community. The renewal lift in particular has never been measured for this product.

## Three kinds of benefit, kept apart

1. **Incremental cash contribution.** Members who renew because of the pack, after platform fees; optional add-on
   sales after fees and refunds.
2. **Cash costs actually avoided.** Support time saved counts here *only* if you really reduce paid support hours.
3. **Staff capacity freed.** The same saved time when you don't cut paid hours. Valued separately, never added to cash.

Saved time is counted in either 2 or 3, never both. Your own setup and maintenance hours are a cost, shown in a
separate view so they don't hide inside the cash figures.

## Formulas

| Result | Formula |
|---|---|
| Extra renewing members per month | new paid members × renewal lift (points ÷ 100), capped so renewals can't exceed 100% |
| Extra renewal revenue per month of new members | extra renewing members × price × (1 − fee) × further paid months |
| Add-on revenue (one-off) | members offered × share who buy × price × (1 − fee − refunds) |
| Support hours freed | (questions × share resolved × minutes) − (questions × share corrected × correction minutes), in hours |
| Cash avoided | hours freed × hourly cost, only if paid hours are cut |
| Capacity freed | hours freed, if paid hours are not cut |
| Net cash per month | renewal revenue + cash avoided − monthly fee − API and software |
| Net cash over 12 months | add-on revenue − one-off price + 12 × net cash per month |
| Renewal lift needed to break even | (monthly cash costs + one-off ÷ 12 − cash avoided) ÷ (new members ÷ 100 × net price × further months) |
| Most you could pay and break even in 12 months | add-on revenue + 12 × net cash per month |
| Wider 12-month view | net cash over 12 months + 12 × capacity value − (setup hours + 12 × monthly hours) × hourly value |

"Per month of new members" means each month's new members are credited with the extra months they stay. It is not
revenue that arrives next month.

## Worked example (illustrative inputs)

A community with **30 new paid members a month at 97 a month**, fees of 3.2% (Skool Pro is 2.9% + 30c per
transaction), 120 repeat questions a month at 6 staff minutes each, an hour of support time valued at 25, and 10 a
month of API costs. No paid support hours are cut. The one-off implementation price is left at 0 so the model shows
the most it could be worth paying.

| Assumption | Conservative | Base | Optimistic |
|---|---|---|---|
| Renewal lift with the pack | 0 points | 3 points | 8 points |
| Further paid months per extra renewing member | 1 | 3 | 6 |
| Questions the tutor resolves without correction | 20% | 40% | 60% |
| Answers needing correction (8 min each) | 15% | 10% | 5% |
| Paid support hours cut | no | no | yes |
| Your hours: setup / per month | 16 / 4 | 12 / 3 | 10 / 2 |

| Result | Conservative | Base | Optimistic |
|---|---|---|---|
| Extra renewing members per month | 0 | 0.9 | 2.4 |
| Extra renewal revenue per month of new members | 0 | 254 | 1,352 |
| Support cash avoided per month | 0 | 0 | 160 |
| Capacity freed per month | 0 h (correction time cancels it out) | 3.2 h (worth 80) | counted as cash instead |
| Net cash per month | −10 | 244 | 1,502 |
| **Most you could pay one-off and break even within 12 months** | **0** | **2,922** | **18,025** |
| Wider 12-month view, counting your hours | −1,720 | 2,682 | 17,175 |

How to read it:

- **The conservative case loses money.** If the pack doesn't change renewals and nobody's hours fall, it's a cost.
- **Almost all the value in the base case comes from one assumption:** 3 more new members in every 100 renewing,
  staying 3 more months. Each renewal-lift point is worth about 85 a month here (30 ÷ 100 × 93.90 net price ×
  3 months). A one-off price of Q breaks even in 12 months only if the lift is at least (10 + Q ÷ 12) ÷ 85 points.
- **The support side is small** unless you actually cut paid hours, and correcting wrong answers can wipe it out.
- **The optimistic case needs things no one has shown yet**: an 8-point lift, members staying 6 more months, and
  a real cut in paid support hours.

## Break-even questions to ask before buying

1. How many renewal points would the pack need to add to pay for itself? (The calculator shows it.)
2. Is that plausible for your community, given how many new members reach your first outcome today?
3. Can you measure it? You need first-outcome and first-renewal counts for at least two cohorts of 20+ members.

If the answer to 3 is no, run the free tools yourself before paying anyone. See [PILOT.md](PILOT.md).
