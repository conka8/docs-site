"""`skillkit pack`: turn a folder of skills into a Claude Code plugin or a ClawHub-style bundle."""

from __future__ import annotations

import json
import re
import shutil
import zipfile
from dataclasses import dataclass, field
from pathlib import Path

from . import constants as C
from .skill import Skill, load_skills


class PackError(Exception):
    pass


@dataclass
class PackResult:
    root: Path  # the plugin / bundle folder
    skills: list[str]
    manifest: Path
    marketplace: Path | None = None
    zip_path: Path | None = None
    files: list[Path] = field(default_factory=list)


def _ignore(_dir, names):
    return [n for n in names if n in C.IGNORED_NAMES or n.endswith((".pyc", ".zip"))]


def _skill_version(skill: Skill, default: str) -> str:
    meta = (skill.fm.meta if skill.fm else None) or {}
    v = meta.get("version")
    if v is None and isinstance(meta.get("metadata"), dict):
        v = meta["metadata"].get("version")
    return str(v) if v is not None else default


def _check_out(library, out) -> None:
    lib, dest = Path(library).resolve(), Path(out).resolve()
    if dest == lib or lib in dest.parents:
        raise PackError(f"The output folder ({out}) must be outside the skills folder ({library}).")


def validate_inputs(name: str, version: str) -> None:
    if not re.match(C.NAME_PATTERN, name or "") or len(name) > C.NAME_MAX_CHARS:
        raise PackError(f"--name \"{name}\" must be lowercase letters, digits and hyphens (e.g. my-skills).")
    if not re.match(r"^\d+\.\d+\.\d+([-+][0-9A-Za-z.\-]+)?$", version or ""):
        raise PackError(f"--version \"{version}\" should look like 1.0.0.")


def _copy_skills(skills: list[Skill], dest: Path) -> list[str]:
    names = []
    for s in skills:
        if not s.exists:
            continue
        target = dest / s.folder_name
        shutil.copytree(s.folder, target, ignore=_ignore)
        names.append(s.folder_name)
    return names


def _write_json(path: Path, data: dict) -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    return path


def _zip_dir(zip_path: Path, base: Path, members: list[Path]) -> Path:
    zip_path.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
        for member in members:
            items = [member] if member.is_file() else sorted(p for p in member.rglob("*") if p.is_file())
            for p in items:
                info = zipfile.ZipInfo.from_file(p, p.relative_to(base).as_posix())
                info.compress_type = zipfile.ZIP_DEFLATED
                zf.writestr(info, p.read_bytes())  # keeps unix permissions (executable scripts)
    return zip_path


def pack_plugin(library, out, name: str, version: str, author: str, description: str | None = None,
                marketplace: bool = False, marketplace_name: str | None = None, make_zip: bool = False
                ) -> PackResult:
    """Build out/<name>/.claude-plugin/plugin.json + out/<name>/skills/<skill>/..."""
    validate_inputs(name, version)
    _check_out(library, out)
    skills, _ = load_skills(Path(library))
    out = Path(out)
    root = out / name
    if root.exists():
        shutil.rmtree(root)
    skill_names = _copy_skills(skills, root / C.PLUGIN_SKILLS_DIR)
    if not skill_names:
        raise PackError(f"No skills with a SKILL.md found in {library}.")
    description = description or f"{len(skill_names)} skills by {author}."
    manifest = _write_json(root / C.PLUGIN_DIR / C.PLUGIN_MANIFEST, {
        "name": name,
        "version": version,
        "description": description,
        "author": {"name": author},
    })
    result = PackResult(root, skill_names, manifest)
    members = [root]
    if marketplace:
        result.marketplace = _write_json(out / C.PLUGIN_DIR / C.MARKETPLACE_MANIFEST, {
            "name": marketplace_name or f"{name}-marketplace",
            "owner": {"name": author},
            "plugins": [{"name": name, "source": f"./{name}", "description": description, "version": version}],
        })
        members.append(result.marketplace)
    if make_zip:
        result.zip_path = _zip_dir(out / f"{name}-{version}.zip", out, members)
    return result


def pack_clawhub(library, out, name: str, version: str, author: str, description: str | None = None,
                 make_zip: bool = False) -> PackResult:
    """Build out/<name>/<skill>/... (flat, one folder per skill) + out/<name>/index.json."""
    validate_inputs(name, version)
    _check_out(library, out)
    skills, _ = load_skills(Path(library))
    out = Path(out)
    root = out / name
    if root.exists():
        shutil.rmtree(root)
    root.mkdir(parents=True)
    skill_names = _copy_skills(skills, root)
    if not skill_names:
        raise PackError(f"No skills with a SKILL.md found in {library}.")
    entries = []
    for s in skills:
        if not s.exists:
            continue
        desc = s.description if isinstance(s.description, str) else ""
        entries.append({"name": s.display_name, "description": desc.strip(),
                        "version": _skill_version(s, version), "path": f"{s.folder_name}/SKILL.md"})
    manifest = _write_json(root / C.CLAWHUB_INDEX, {
        "name": name, "version": version, "author": author,
        "description": description or f"{len(entries)} skills by {author}.",
        "skills": entries,
    })
    result = PackResult(root, skill_names, manifest)
    if make_zip:
        result.zip_path = _zip_dir(out / f"{name}-{version}-clawhub.zip", out, [root])
    return result


def _claude_app_install(name: str, version: str, author: str, zips: list[str]) -> str:
    lines = [f"# {name} {version} by {author}: install in the Claude app", "",
             "Each .zip in this folder is one skill. Upload them one at a time.", "",
             "## Members (Free, Pro, Max)", "",
             "1. Turn on code execution: Settings > Capabilities > \"Code execution and file creation\".",
             "2. Go to Customize > Skills, click +, then Create skill > Upload a skill.",
             "3. Choose one .zip from this folder. Repeat for each skill.",
             "4. To update a skill, delete the old one and upload the new .zip.", "",
             "## Team and Enterprise owners", "",
             "Organization settings > Plugins & skills > Add > Upload a skill makes a skill available to "
             "everyone in the organization. Owners also need \"Skills\" and code execution turned on "
             "in the same settings.", "",
             "Menu names come from Claude's help center (checked 2026-10-29) and may change: "
             + C.CLAUDE_APP_SKILLS_HELP, "", "## Skills", ""]
    lines += [f"- {z}" for z in zips]
    return "\n".join(lines) + "\n"


def pack_claude_app(library, out, name: str, version: str, author: str) -> PackResult:
    """Build out/<name>/<skill>.zip (one upload per skill, skill folder at the zip root) + INSTALL.md."""
    validate_inputs(name, version)
    _check_out(library, out)
    skills, _ = load_skills(Path(library))
    root = Path(out) / name
    if root.exists():
        shutil.rmtree(root)
    root.mkdir(parents=True)
    zips, names, files = [], [], []
    for s in skills:
        if not s.exists:
            continue
        # The Claude app wants the folder at the zip root, named like the skill.
        top = s.name if isinstance(s.name, str) and re.match(C.NAME_PATTERN, s.name) else s.folder_name
        stage = root / ".stage" / top
        shutil.copytree(s.folder, stage, ignore=_ignore)
        files.append(_zip_dir(root / f"{top}.zip", stage.parent, [stage]))
        zips.append(f"{top}.zip")
        names.append(s.folder_name)
    shutil.rmtree(root / ".stage", ignore_errors=True)
    if not names:
        raise PackError(f"No skills with a SKILL.md found in {library}.")
    manifest = root / "INSTALL.md"
    manifest.write_text(_claude_app_install(name, version, author, zips), encoding="utf-8")
    return PackResult(root, names, manifest, files=files)
