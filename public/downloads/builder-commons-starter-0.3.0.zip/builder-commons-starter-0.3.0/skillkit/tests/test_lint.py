import json
import os
import re

import pytest
import yaml

from skillkit.lint import (
    RULES,
    TODO_DESCRIPTION,
    fix_skill,
    format_github,
    format_json,
    format_result,
    format_text,
    lint_path,
)


def rules_of(result):
    return sorted({i.rule for i in result.issues})


# --------------------------------------------------------------- good input


def test_good_library_has_no_issues(copy_fixture):
    lib = copy_fixture("library")
    result = lint_path(lib)
    assert result.issues == []
    assert result.ok and result.is_library
    assert len(result.skills) == 2


def test_good_single_skill(copy_fixture):
    result = lint_path(copy_fixture("library/summarize-email"))
    assert result.issues == [] and not result.is_library


def test_every_rule_has_valid_severity():
    assert all(sev in ("error", "warning") for sev, _ in RULES.values())


# --------------------------------------------------------------- one fixture per rule

BAD_CASES = [
    ("no-skill-md", "missing-skill-md", "error"),
    ("no-frontmatter", "frontmatter-missing", "error"),
    ("unclosed-frontmatter", "frontmatter-missing", "error"),
    ("bad-yaml", "frontmatter-invalid", "error"),
    ("list-frontmatter", "frontmatter-invalid", "error"),
    ("name-missing", "name-missing", "error"),
    ("Bad_Name", "name-format", "error"),
    ("claude-helper", "name-reserved", "error"),
    ("folder-mismatch", "name-folder-mismatch", "warning"),
    ("desc-missing", "description-missing", "error"),
    ("desc-empty", "description-empty", "error"),
    ("desc-no-when", "description-no-when", "warning"),
    ("desc-xml", "description-xml", "error"),
    ("broken-link", "broken-link", "error"),
    ("absolute-path", "absolute-path", "warning"),
]


@pytest.mark.parametrize("folder,rule,severity", BAD_CASES)
def test_bad_fixture_triggers_exactly_its_rule(copy_fixture, folder, rule, severity):
    result = lint_path(copy_fixture(f"bad/{folder}"))
    assert rules_of(result) == [rule]
    assert all(i.severity == severity for i in result.issues)
    assert all(i.line >= 1 and i.file.endswith(".md") for i in result.issues)
    assert result.ok == (severity == "warning")


def test_bad_library_counts(copy_fixture):
    result = lint_path(copy_fixture("bad"))
    assert result.is_library and len(result.skills) == 15
    assert {r for _, r, _ in BAD_CASES} == set(rules_of(result))


def test_name_line_number(copy_fixture):
    result = lint_path(copy_fixture("bad/Bad_Name"))
    assert result.issues[0].line == 2
    assert "bad-name" in result.issues[0].message


def test_invalid_yaml_line_number(copy_fixture):
    issue = lint_path(copy_fixture("bad/bad-yaml")).issues[0]
    assert issue.line >= 3


def test_broken_link_details(copy_fixture):
    result = lint_path(copy_fixture("bad/broken-link"))
    targets = sorted(re.search(r'"([^"]+)"', i.message).group(1) for i in result.issues)
    assert targets == ["assets/logo.png", "references/missing-guide.md", "scripts/does_not_exist.py"]
    assert {i.line for i in result.issues} == {8, 9}


def test_absolute_paths_found_full(copy_fixture):
    result = lint_path(copy_fixture("bad/absolute-path"))
    assert len(result.issues) == 2
    assert "/Users/marko/Desktop/template.docx" in result.issues[0].message
    assert "C:\\Users" in result.issues[1].message


def test_name_too_long(make_skill):
    name = "a" * 70
    d = make_skill(name, f"name: {name}\ndescription: Long name. Use when testing.")
    assert rules_of(lint_path(d)) == ["name-too-long"]


def test_name_not_string(make_skill):
    d = make_skill("numeric", "name: 123\ndescription: Number name. Use when testing.")
    assert rules_of(lint_path(d)) == ["name-format"]


@pytest.mark.parametrize("name", ["my-anthropic-tool", "Claude-Bot", "claudebot"])
def test_reserved_words(make_skill, name):
    d = make_skill(name, f"name: {name}\ndescription: Reserved. Use when testing.")
    assert "name-reserved" in rules_of(lint_path(d))


@pytest.mark.parametrize("name", ["double--hyphen", "-leading", "trailing-", "has space", "under_score"])
def test_name_format_variants(make_skill, tmp_path, name):
    d = make_skill("folder", f"name: \"{name}\"\ndescription: Bad. Use when testing.")
    assert "name-format" in rules_of(lint_path(d))


def test_description_too_long(make_skill):
    desc = "Use when testing. " + "x" * 1100
    d = make_skill("long-desc", f"name: long-desc\ndescription: {desc}")
    assert rules_of(lint_path(d)) == ["description-too-long"]


def test_description_exactly_at_limit_ok(make_skill):
    desc = "Use when testing. " + "x" * (1024 - 18)
    assert len(desc) == 1024
    d = make_skill("limit-desc", f"name: limit-desc\ndescription: {desc}")
    assert rules_of(lint_path(d)) == []


def test_description_not_string(make_skill):
    d = make_skill("list-desc", "name: list-desc\ndescription:\n  - a\n  - b")
    issues = lint_path(d).issues
    assert [i.rule for i in issues] == ["description-empty"]
    assert "plain text" in issues[0].message


@pytest.mark.parametrize("desc", ["Writes posts. Use this for LinkedIn.", "Helpful WHEN writing.",
                                  "Use when the user asks."])
def test_when_cues_accepted(make_skill, desc):
    d = make_skill("cue", f"name: cue\ndescription: {desc}")
    assert rules_of(lint_path(d)) == []


def test_when_cue_needs_whole_word(make_skill):
    d = make_skill("cue", "name: cue\ndescription: Writes whenever-style posts.")
    assert rules_of(lint_path(d)) == ["description-no-when"]


def test_description_todo_placeholder(make_skill):
    d = make_skill("todo", f"name: todo\ndescription: \"{TODO_DESCRIPTION}\"")
    assert rules_of(lint_path(d)) == ["description-todo"]


def test_description_comparison_operators_not_xml(make_skill):
    d = make_skill("ops", "name: ops\ndescription: \"Checks if a < b and c > d. Use when comparing.\"")
    assert rules_of(lint_path(d)) == []


def test_body_too_long(make_skill):
    d = make_skill("long-body", body="line\n" * 501)
    issues = lint_path(d).issues
    assert [i.rule for i in issues] == ["body-too-long"]
    assert issues[0].severity == "warning"
    assert issues[0].line == 5 + 1 + 500  # frontmatter is 4 lines, then one blank line


def test_body_500_lines_ok(make_skill):
    d = make_skill("ok-body", body="line\n" * 500)
    assert lint_path(d).issues == []


def test_links_inside_code_fences_ignored_but_path_refs_checked(make_skill):
    body = "```\n[x](nothing-here.md)\npython scripts/missing.py\n```\n"
    issues = lint_path(make_skill("fenced", body=body)).issues
    assert [i.rule for i in issues] == ["broken-link"]
    assert "scripts/missing.py" in issues[0].message


def test_link_with_anchor_title_and_encoding(make_skill):
    body = ('See [a](references/my%20guide.md#part "Title") and [b](<references/other.md>) '
            "and [c](./references/other.md?x=1).\n")
    d = make_skill("links", body=body, files={"references/my guide.md": "x", "references/other.md": "y"})
    assert lint_path(d).issues == []


def test_external_links_ignored(make_skill):
    body = "[a](https://x.com/a.md) [b](mailto:a@b.c) [c](#top) [d](/abs/path.md) [e]({{var}})\n"
    assert lint_path(make_skill("ext", body=body)).issues == []


def test_reference_to_directory_ok(make_skill):
    d = make_skill("dirs", body="Templates live in templates/email and assets/img.\n",
                   files={"templates/email/a.txt": "x", "assets/img/b.txt": "y"})
    assert lint_path(d).issues == []


def test_url_containing_scripts_path_not_flagged(make_skill):
    body = "Download https://example.com/scripts/install.sh first.\n"
    assert lint_path(make_skill("url", body=body)).issues == []


@pytest.mark.skipif(os.name == "nt", reason="exec bits are POSIX only")
def test_script_without_shebang_and_not_executable(make_skill):
    d = make_skill("scripts-bad", body="Run `scripts/run.py` and `scripts/ok.sh`.\n",
                   files={"scripts/run.py": ("print('hi')\n", 0o644),
                          "scripts/ok.sh": ("#!/bin/sh\necho ok\n", 0o755)})
    issues = lint_path(d).issues
    assert sorted(i.rule for i in issues) == ["script-no-shebang", "script-not-executable"]
    assert all("scripts/run.py" in i.message for i in issues)
    assert all(i.severity == "warning" for i in issues)


@pytest.mark.skipif(os.name == "nt", reason="exec bits are POSIX only")
def test_script_checked_once_even_if_referenced_twice(make_skill):
    d = make_skill("twice", body="Run scripts/a.py.\n\nAgain: scripts/a.py\n",
                   files={"scripts/a.py": ("#!/usr/bin/env python3\n", 0o644)})
    assert [i.rule for i in lint_path(d).issues] == ["script-not-executable"]


def test_non_script_reference_not_checked_for_shebang(make_skill):
    d = make_skill("data", body="Read references/data.json.\n", files={"references/data.json": "{}"})
    assert lint_path(d).issues == []


# secrets are built at runtime so no secret-looking strings live in the repo
SECRETS = {
    "Anthropic": "sk-ant-" + "api03-" + "A1b2C3d4" * 4,
    "OpenAI": "sk-" + "proj-" + "Z9y8X7w6" * 4,
    "AWS": "AKIA" + "ABCDEFGHIJKLMNOP",
    "GitHub": "ghp_" + "a1B2c3D4e5" * 4,
    "Slack": "xox" + "b-" + "123456789012-abcdefABCDEF",
    "private key": "-----BEGIN " + "RSA PRIVATE KEY-----",
}


@pytest.mark.parametrize("kind", list(SECRETS))
def test_secret_detection_in_skill_md(make_skill, kind):
    d = make_skill("leaky", body=f"Use this key: {SECRETS[kind]}\n")
    issues = lint_path(d).issues
    assert [i.rule for i in issues] == ["secret"]
    assert issues[0].severity == "error"
    assert kind.lower().split()[0] in issues[0].message.lower()
    assert SECRETS[kind] not in issues[0].message  # masked
    assert issues[0].line == 6


def test_secret_in_script_file_reported_with_its_path(make_skill):
    d = make_skill("leaky-script", files={"scripts/config.py": f"KEY = '{SECRETS['OpenAI']}'\n"})
    issues = lint_path(d).issues
    assert len(issues) == 1 and issues[0].file.endswith("config.py") and issues[0].line == 1


def test_anthropic_key_not_double_reported(make_skill):
    d = make_skill("one", body=SECRETS["Anthropic"] + "\n")
    assert len(lint_path(d).issues) == 1


def test_placeholder_keys_not_flagged(make_skill):
    d = make_skill("placeholders", body="Set ANTHROPIC_API_KEY=sk-ant-... or sk-your-key-here.\n")
    assert lint_path(d).issues == []


def test_duplicate_names(copy_fixture):
    result = lint_path(copy_fixture("duplicates"))
    dups = [i for i in result.issues if i.rule == "duplicate-name"]
    assert len(dups) == 2
    assert all(i.severity == "error" for i in dups)
    assert "writer-two" in dups[0].message and "writer-one" in dups[1].message
    assert not result.ok


# --------------------------------------------------------------- --fix


def test_fix_name_to_folder(copy_fixture):
    d = copy_fixture("bad/folder-mismatch")
    result = lint_path(d, fix=True)
    assert result.issues == []
    assert any("set name" in f for f in result.fixes)
    meta = yaml.safe_load((d / "SKILL.md").read_text().split("---")[1])
    assert meta["name"] == "folder-mismatch"


def test_fix_invalid_name_slugified_from_folder(make_skill):
    d = make_skill("My Skill", "name: My Skill\ndescription: Does it. Use when testing.")
    fixes = fix_skill(d)
    assert any('"my-skill"' in f for f in fixes)
    assert "name: my-skill\n" in (d / "SKILL.md").read_text()
    # folder name still differs from the slug, so a warning remains (but no error)
    assert rules_of(lint_path(d)) == ["name-folder-mismatch"]


def test_fix_adds_missing_name_and_description(copy_fixture):
    d = copy_fixture("bad/name-missing")
    fix_skill(d)
    assert lint_path(d).issues == []
    d2 = copy_fixture("bad/desc-missing")
    fixes = fix_skill(d2)
    assert any("TODO description" in f for f in fixes)
    text = (d2 / "SKILL.md").read_text()
    assert text.index("name:") < text.index("description:")
    assert rules_of(lint_path(d2)) == ["description-todo"]


def test_fix_replaces_empty_description(copy_fixture):
    d = copy_fixture("bad/desc-empty")
    fix_skill(d)
    assert rules_of(lint_path(d)) == ["description-todo"]


def test_fix_trailing_whitespace(make_skill):
    d = make_skill("spaces", body="Line with spaces   \nTabs\t\t\n")
    fixes = fix_skill(d)
    assert fixes == ["trimmed trailing whitespace"]
    assert "Line with spaces\nTabs\n" in (d / "SKILL.md").read_text()
    assert fix_skill(d) == []  # idempotent


def test_fix_adds_frontmatter_skeleton(copy_fixture):
    d = copy_fixture("bad/no-frontmatter")
    fixes = fix_skill(d)
    assert any("skeleton" in f for f in fixes)
    text = (d / "SKILL.md").read_text()
    assert text.startswith("---\nname: no-frontmatter\n")
    assert "# No frontmatter here" in text
    assert rules_of(lint_path(d)) == ["description-todo"]


def test_fix_skeleton_uses_placeholder_name_for_reserved_folder(make_skill):
    d = make_skill("claude-stuff", frontmatter="", body="# Hi\n")
    fix_skill(d)
    assert "name: my-skill" in (d / "SKILL.md").read_text()


def test_fix_does_not_touch_invalid_yaml(copy_fixture):
    d = copy_fixture("bad/bad-yaml")
    before = (d / "SKILL.md").read_text()
    assert fix_skill(d) == []
    assert (d / "SKILL.md").read_text() == before


def test_fix_multiline_name_value_replaced(make_skill):
    d = make_skill("multi", "name: >\n  wrong name\ndescription: Ok. Use when testing.")
    fix_skill(d)
    assert lint_path(d).issues == []


def test_fix_missing_skill_md_noop(tmp_path):
    assert fix_skill(tmp_path) == []


def test_fix_normalizes_crlf(make_skill):
    d = make_skill("crlf")
    md = d / "SKILL.md"
    md.write_bytes(md.read_bytes().replace(b"\n", b"\r\n"))
    assert fix_skill(d) == ["normalized line endings"]
    assert b"\r" not in md.read_bytes()


def test_fix_on_library(copy_fixture):
    lib = copy_fixture("duplicates")
    result = lint_path(lib, fix=True)
    # names now follow folder names, so the duplicate disappears
    assert result.issues == []
    assert len(result.fixes) == 2


# --------------------------------------------------------------- output formats


def test_format_text(copy_fixture):
    out = format_text(lint_path(copy_fixture("bad/desc-xml")))
    assert re.search(r"SKILL\.md:3: error \[description-xml\]", out)
    assert "1 error, 0 warnings" in out
    assert "Errors must be fixed" in out


def test_format_text_warning_only_and_clean(copy_fixture):
    assert "No errors. Warnings are suggestions" in format_text(lint_path(copy_fixture("bad/desc-no-when")))
    assert "All good" in format_text(lint_path(copy_fixture("library")))


def test_format_text_lists_fixes(copy_fixture):
    out = format_text(lint_path(copy_fixture("bad/folder-mismatch"), fix=True))
    assert out.startswith("fixed: ")


def test_format_json(copy_fixture):
    data = json.loads(format_json(lint_path(copy_fixture("duplicates"))))
    assert data["skills_checked"] == 3
    assert data["errors"] == 2 and data["warnings"] == 2 and data["ok"] is False
    assert set(data["issues"][0]) == {"rule", "severity", "file", "line", "message", "skill"}
    assert data["skills"] == ["unique-skill", "blog-writer", "blog-writer"]


def test_format_github(copy_fixture):
    out = format_github(lint_path(copy_fixture("bad/broken-link")))
    lines = out.strip().splitlines()
    assert len(lines) == 4
    assert re.match(r"^::error file=.*SKILL\.md,line=8,title=skillkit broken-link::", lines[0])
    assert lines[-1].startswith("skillkit: 3 errors")


def test_format_github_escapes(make_skill):
    d = make_skill("esc", body="See [x](references/a,b:c%.md)\n")
    out = format_github(lint_path(d))
    first = out.splitlines()[0]
    msg = first.split("::", 2)[2]
    assert "%25" in msg and "\n" not in msg


def test_format_github_warning_level(copy_fixture):
    assert format_github(lint_path(copy_fixture("bad/absolute-path"))).startswith("::warning ")


def test_format_result_dispatch_and_unknown(copy_fixture):
    r = lint_path(copy_fixture("library"))
    assert format_result(r, "json").startswith("{")
    with pytest.raises(ValueError):
        format_result(r, "xml")
