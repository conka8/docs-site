"""Small text helpers: slugs, readable n8n/Make expressions, truncation."""

from __future__ import annotations

import hashlib
import re
import unicodedata
from typing import Any

MAX_NAME = 64
MAX_DESCRIPTION = 1024
RESERVED_WORDS = ("anthropic", "claude")


def slugify(text: str, fallback_prefix: str = "workflow") -> str:
    """Turn a workflow name into a valid skill name.

    Lowercase letters, digits and single hyphens, at most 64 characters.
    The reserved words "claude" and "anthropic" are removed because skill
    names may not contain them. Names with no usable characters (for example
    only emoji or non-Latin script) get a stable ``workflow-<hash>`` name.
    """
    original = text or ""
    ascii_text = unicodedata.normalize("NFKD", original).encode("ascii", "ignore").decode("ascii")
    slug = ascii_text.lower()
    for word in RESERVED_WORDS:
        slug = slug.replace(word, " ")
    slug = re.sub(r"[^a-z0-9]+", "-", slug).strip("-")
    if len(slug) > MAX_NAME:
        cut = slug[:MAX_NAME]
        if "-" in cut and slug[MAX_NAME] != "-":
            cut = cut.rsplit("-", 1)[0]
        slug = cut.strip("-")
    if not slug:
        digest = hashlib.sha1(original.encode("utf-8")).hexdigest()[:8]
        slug = f"{fallback_prefix}-{digest}"
    return slug


def is_valid_skill_name(name: str) -> bool:
    return (
        bool(re.fullmatch(r"[a-z0-9]+(-[a-z0-9]+)*", name or ""))
        and len(name) <= MAX_NAME
        and not any(w in name for w in RESERVED_WORDS)
    )


def truncate(text: str, limit: int) -> str:
    text = text or ""
    if len(text) <= limit:
        return text
    return text[: max(0, limit - 3)].rstrip() + "..."


def one_line(text: Any, limit: int = 200) -> str:
    """Collapse whitespace and shorten, for use inside a sentence."""
    s = re.sub(r"\s+", " ", str(text if text is not None else "")).strip()
    return truncate(s, limit)


def humanize(identifier: str) -> str:
    """'addRow' -> 'add row', 'send_message' -> 'send message'."""
    s = re.sub(r"([a-z0-9])([A-Z])", r"\1 \2", identifier or "")
    s = re.sub(r"[_\-.:]+", " ", s)
    return re.sub(r"\s+", " ", s).strip().lower()


_EXPR_BLOCK = re.compile(r"\{\{\s*(.*?)\s*\}\}", re.S)
_NODE_REF = re.compile(
    r"""\$\(\s*['"](?P<node>[^'"]+)['"]\s*\)\s*\.\s*(?:item|first\(\)|last\(\)|all\(\)(?:\[\d+\])?)\s*\.\s*json\s*\.\s*(?P<path>[\w.]+)"""
)
_OLD_NODE_REF = re.compile(r"""\$node\[\s*['"](?P<node>[^'"]+)['"]\s*\]\.json(?:\.(?P<path>[\w.]+)|\[['"](?P<path2>[^'"]+)['"]\])""")
_JSON_REF = re.compile(r"""\$json\s*(?:\.\s*(?P<path>[\w.]+)|\[\s*['"](?P<path2>[^'"]+)['"]\s*\])""")


def pretty_expr(value: Any) -> str:
    """Make an n8n expression readable: '={{ $json.body.email }}' -> 'body.email'."""
    if value is None:
        return ""
    if not isinstance(value, str):
        return str(value)
    s = value
    if s.startswith("="):
        s = s[1:]
    s = _NODE_REF.sub(lambda m: f'{m.group("path")} (from "{m.group("node")}")', s)
    s = _OLD_NODE_REF.sub(
        lambda m: f'{m.group("path") or m.group("path2")} (from "{m.group("node")}")', s
    )
    s = _JSON_REF.sub(lambda m: m.group("path") or m.group("path2"), s)
    whole = _EXPR_BLOCK.fullmatch(s.strip())
    if whole:
        return whole.group(1).strip()
    # Inside longer text keep a visible placeholder: "Hi {name}, ..."
    s = _EXPR_BLOCK.sub(lambda m: "{" + m.group(1) + "}", s)
    return s.strip()


def json_refs(value: str) -> list[str]:
    """Field paths referenced as $json.x in an n8n expression."""
    return [m.group("path") or m.group("path2") for m in _JSON_REF.finditer(value or "")]


def node_refs(value: str) -> list[tuple[str, str]]:
    """(node name, field path) pairs referenced as $('Node').item.json.x."""
    out = [(m.group("node"), m.group("path")) for m in _NODE_REF.finditer(value or "")]
    out += [
        (m.group("node"), m.group("path") or m.group("path2"))
        for m in _OLD_NODE_REF.finditer(value or "")
    ]
    return out


def iter_strings(obj: Any):
    """Yield every string inside a nested JSON value."""
    if isinstance(obj, str):
        yield obj
    elif isinstance(obj, dict):
        for v in obj.values():
            yield from iter_strings(v)
    elif isinstance(obj, list):
        for v in obj:
            yield from iter_strings(v)


def resource_name(value: Any) -> str:
    """n8n 'resource locator' values: prefer the cached display name."""
    if isinstance(value, dict):
        for key in ("cachedResultName", "value", "url"):
            v = value.get(key)
            if v not in (None, ""):
                return pretty_expr(v)
        return ""
    return pretty_expr(value)


def yaml_quote(text: str) -> str:
    """Quote a string as a YAML double-quoted scalar (also valid JSON)."""
    out = ['"']
    for ch in text:
        code = ord(ch)
        if ch == '"':
            out.append('\\"')
        elif ch == "\\":
            out.append("\\\\")
        elif ch == "\n":
            out.append("\\n")
        elif ch == "\t":
            out.append("\\t")
        elif code < 0x20 or code == 0x7F or 0x80 <= code <= 0x9F or ch in "  ﻿":
            out.append(f"\\u{code:04x}")
        elif 0xD800 <= code <= 0xDFFF:
            out.append("?")
        else:
            out.append(ch)
    out.append('"')
    return "".join(out)


def md_escape_inline(text: str) -> str:
    """Keep user text from breaking markdown structure inside a list item."""
    return re.sub(r"\s+", " ", text or "").replace("`", "'").strip()
