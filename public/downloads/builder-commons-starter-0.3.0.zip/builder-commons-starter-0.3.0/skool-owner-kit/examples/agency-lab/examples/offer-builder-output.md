> Illustrative output, written by hand to show what a good result looks like. It was not produced by a live
> Claude run. Synthetic example: invented community and businesses.

**Niche check** (Lesson: "Pick a niche with the 3-filter test")

| Niche | Money leak | Pays for software | Reachable this week | Score |
|---|---|---|---|---|
| Dental clinics, Leeds | Yes: a missed call is a lost patient | Yes: booking and phone systems | Yes: 60+ on Google Maps | 3/3 |
| Restaurants, Leeds | No: a missed call is a small order | Some | Yes | 1/3 |

Picked: **dental clinics in Leeds** (3/3).

## Headline

We reply to every missed call within 60 seconds for dental clinics in Leeds, without hiring a receptionist.

## Who it's for

Independent dental clinics in Leeds with one to three front-desk staff.

## The problem

When the front desk is busy or closed, calls go to voicemail and new patients book with the next clinic they find.

## How it works

1. A missed call triggers a text to the caller within 60 seconds with your booking link.
2. Your front desk gets a message with the caller's number.
3. Once a month we review the numbers together.

## What's included

Setup and testing, the text-back running every day, and a monthly check-in.

## Price

Founding client: 750 setup and 400 a month (Lesson: "Pricing your first offer"). Mid-range of the founding
ladder because one new patient is worth a lot to a clinic.

## Pilot and proof

A 30-day pilot. We agree one metric up front: the share of missed calls that get a text within 60 seconds.

## What I need from you

Access to your phone system, one contact person, and 30 minutes for setup.
