> Illustrative output, written by hand to show what a good result looks like. It was not produced by a live
> Claude run. Synthetic example: invented community and businesses.

## Messages

### Smile Studio Leeds

**Day 0** (Lesson: "The 3-line Loom script")
Three of your last ten Google reviews mention calls going to voicemail.
Each of those is a patient who may have booked with another clinic.
I recorded a 60-second video showing how I'd fix it: [Loom link]. Worth a look?

**Day 3** (Lesson: "The follow-up cadence")
Clinics like yours often miss most calls at lunchtime, when the front desk is busiest.
Happy to show you the 60-second fix: [Loom link]. Worth a look?

**Day 7**
Should I close your file? If missed calls aren't a priority right now, no problem at all.

### Kirkstall Dental

**Day 0**
Your website says the phone line closes at 4pm on weekdays.
Anyone who calls after work reaches voicemail and may book elsewhere.
I recorded a 60-second video on replying to them automatically: [Loom link]. Worth a look?

**Day 3**
After-hours callers are often people who can't call during work, which is a lot of new patients.
Here's the 60-second video again: [Loom link]. Worth a look?

**Day 7**
Should I close your file? Happy to leave it here if the timing's wrong.

## Skipped

- **Bright Dental Care**: no specific observation yet. The lesson says to skip businesses without a real
  observation. Check their reviews or opening hours, then add them back.

## Tracking sheet

```csv
Business,Contact,Observation,Day 0 sent,Day 3 sent,Day 7 sent,Reply,Call booked
Smile Studio Leeds,,3 of last 10 reviews mention voicemail,,,,,
Kirkstall Dental,,Phone line closes at 4pm on weekdays,,,,,
```
