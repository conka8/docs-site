# Northwind Agency Lab: your AI toolkit

These Claude skills are built from the Northwind Agency Lab classroom. They help you reach your **First win**: One-page offer posted in Wins and 20 outreach messages sent, within 14 days of joining.

| Skill | What it does | Time |
|---|---|---|
| **northwind-tutor** | Ask anything about the lessons. It answers from the classroom and says which lesson to watch. | Any time |
| **northwind-offer-builder** | Build your one-page offer: A one-page offer for one niche, priced, ready to post in Wins | 30 min |
| **northwind-outreach-sprint** | Write your first outreach messages: Personalised first messages and both follow-ups for up to 10 businesses, plus a tracking sheet | 45 min |

## 1. Install (once, about 5 minutes)

**Claude app (claude.ai or desktop):**

1. Settings > Capabilities: turn on **Code execution and file creation**.
2. Customize > Skills > **+** > **Create skill** > **Upload a skill**. Upload each `.zip` you received.

**Claude Code:** copy each skill folder into `~/.claude/skills/` (Windows: `%USERPROFILE%\.claude\skills\`), or run the two `/plugin` lines your admin shared.

Check it worked: start a new chat and ask *"Use the northwind-tutor skill: how do I get started?"*

## 2. Your first tasks

1. **Build your one-page offer**: ask *"Use the northwind-offer-builder skill"*. Have ready: which 1 to 3 niches are you considering, which city or region will you sell in, what can you set up for a client today (an automation, a chatbot, a booking flow). (Example: dental clinics, roofers)
2. **Write your first outreach messages**: ask *"Use the northwind-outreach-sprint skill"*. Have ready: what's your offer headline? (paste it from your one-page offer.), list up to 10 businesses, each with one specific thing you noticed (from their website or reviews).. (Example: We reply to every missed call within 60 seconds for dental clinics in Leeds, without hiring a receptionist.)

## 3. Report your First win

Post in Wins with "#firstwin" and a link to your offer.

## Good to know

- The skills follow the classroom. If something isn't covered they say so: then Ask in the Help channel and tag a coach.
- They run in your own Claude account. Nothing is sent to the community; Claude's own data terms apply.
- Check anything you send to a client. The skills help you draft; you are responsible for what you send.
- Start with **northwind-offer-builder** if you're not sure where to begin.
