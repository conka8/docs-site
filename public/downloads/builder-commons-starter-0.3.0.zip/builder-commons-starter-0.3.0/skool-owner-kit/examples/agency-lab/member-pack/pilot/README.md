# Pilot: does the member pack help new members reach their First win?

Run it for at least one full cohort (members who join in one month) and 14 days after the
last of them joins. Everything stays in these files on your computer.

## What to log

**events.csv**, one row per event, for members of both cohorts. Use any member ID you like (an email, or a
code if you'd rather not keep emails here). Events:

| event | Log it when |
|---|---|
| joined | A paid member joins (every member needs this row) |
| installed | A pilot member tells you, or you see, that they installed the skills |
| used | A member reports using a skill for a task |
| first_outcome | The member reports their First win: One-page offer posted in Wins and 20 outreach messages sent |
| renewed | The member's first renewal payment went through |
| cancelled | The member cancelled before or at the first renewal |
| refunded | The member got a refund |

For the baseline cohort, fill in `joined`, `first_outcome`, `renewed`, `cancelled` from your records
(for example #firstwin posts and your platform's payment history).

**questions.csv**: member questions you looked at during the pilot. `handled_by` is `tutor` (a member said the
tutor answered it, or you checked a tutor answer) or `staff`. `result` is `resolved`, `corrected` (the tutor was
wrong or incomplete and someone fixed it) or `escalated`. `staff_minutes` is the time staff spent on it.

**costs.csv**: every cost of running the pilot. `kind` is `cash` (money spent: implementation fee, API, software)
or `time` (minutes of your or your team's time).

## Read the result

```bash
skool-kit pilot pilot/pilot.yaml --format md -o pilot-report.md
```

The report compares cohorts, it does not prove cause: the pilot month can differ in season, marketing or price.
Small cohorts give wide ranges; the report says when there isn't enough data to decide.
