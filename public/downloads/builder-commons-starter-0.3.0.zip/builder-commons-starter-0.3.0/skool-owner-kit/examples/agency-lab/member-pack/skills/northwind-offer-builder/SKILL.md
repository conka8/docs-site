---
name: northwind-offer-builder
description: 'Build your one-page offer for Northwind Agency Lab members: a one-page offer for one niche, priced, ready to post in Wins. Follows the Northwind Agency Lab lessons "Pick a niche with the 3-filter test", "The one-outcome offer", "Pricing your first offer". Use when the member wants to choose a niche, write their offer or decide what to charge.'
---

# Build your one-page offer

You guide a member of Northwind Agency Lab to a finished result: **A one-page offer for one niche, priced, ready to post in Wins**. Work through it with the member step by step and produce the deliverable at the end. It usually takes about 30 minutes.

## Before you start

Ask for anything below the member hasn't already given you, one question at a time:

| Input | Ask | Example |
|---|---|---|
| niches | Which 1 to 3 niches are you considering? | dental clinics, roofers |
| area | Which city or region will you sell in? | Leeds |
| can_deliver | What can you set up for a client today (an automation, a chatbot, a booking flow)? | missed-call text-back with n8n and SMS |

## Steps

Read the lesson file for each step before you do it, and follow the Northwind Agency Lab method in it rather than general advice. Cite the lesson by title when you use it, like *(Lesson: "Pick a niche with the 3-filter test")*.

1. Score each niche against the three filters. Show the score per filter and pick one niche that scores 3/3. If none does, stop and help the member find one.
   - Lesson: "Pick a niche with the 3-filter test" ([pick-a-niche-with-the-3-filter-test.md](references/your-offer/pick-a-niche-with-the-3-filter-test.md))
2. Write the headline with the formula. Check it against the headline rules.
   - Lesson: "The one-outcome offer" ([the-one-outcome-offer.md](references/your-offer/the-one-outcome-offer.md))
3. Write every section of the one-page offer, in order, under 400 words.
   - Lesson: "The one-outcome offer" ([the-one-outcome-offer.md](references/your-offer/the-one-outcome-offer.md))
4. Set the setup fee and monthly fee for a founding client from the ladder, and say why you chose that point in the range.
   - Lesson: "Pricing your first offer" ([pricing-your-first-offer.md](references/your-offer/pricing-your-first-offer.md))

## Deliverable

Produce one Markdown document with these `##` headings, in this order:

- Headline
- Who it's for
- The problem
- How it works
- What's included
- Price
- Pilot and proof
- What I need from you

## Rules

- One niche and one outcome.
- No tool names in the headline.
- Never promise guaranteed revenue or results the member doesn't control.
- Never price below 300 a month.
- Base every recommendation on the lessons above. Never invent lessons, prices, results or promises.
- If the member asks something the lessons don't cover, say "This isn't covered in the classroom yet", label any suggestion as your own, and point them to: Ask in the Help channel and tag a coach.

## Check your work before you finish

Check the deliverable against this list and fix anything that fails before you show it:

- It contains "## Headline", "## Price", "## Pilot and proof", "## What I need from you".
- It matches the pattern `(?i)3/3`.
- It does not contain "guaranteed".
- It is at most 4000 characters long.

## When you're done

This task is part of the member's **First win** (One-page offer posted in Wins and 20 outreach messages sent, within 14 days of joining). When they have it, tell them: Post in Wins with "#firstwin" and a link to your offer.

## Example

[examples/example-input.md](examples/example-input.md) and [examples/example-output.md](examples/example-output.md) show the expected shape of a good result. The example output was written by hand; follow the lessons, not the example's specifics.
