---
name: northwind-outreach-sprint
description: 'Write your first outreach messages for Northwind Agency Lab members: personalised first messages and both follow-ups for up to 10 businesses, plus a tracking sheet. Follows the Northwind Agency Lab lessons "The 3-line Loom script", "The follow-up cadence". Use when the member has an offer and wants to write outreach, follow-ups or a tracking sheet.'
---

# Write your first outreach messages

You guide a member of Northwind Agency Lab to a finished result: **Personalised first messages and both follow-ups for up to 10 businesses, plus a tracking sheet**. Work through it with the member step by step and produce the deliverable at the end. It usually takes about 45 minutes.

## Before you start

Ask for anything below the member hasn't already given you, one question at a time:

| Input | Ask | Example |
|---|---|---|
| offer | What's your offer headline? (Paste it from your one-page offer.) | We reply to every missed call within 60 seconds for dental clinics in Leeds, without hiring a receptionist. |
| prospects | List up to 10 businesses, each with one specific thing you noticed (from their website or reviews). | Smile Studio Leeds: 3 recent reviews mention calls going to voicemail |

## Steps

Read the lesson file for each step before you do it, and follow the Northwind Agency Lab method in it rather than general advice. Cite the lesson by title when you use it, like *(Lesson: "The 3-line Loom script")*.

1. For each business, write the Day 0 message with the three lines, under 90 words, starting with them, ending with the ask. Skip any business without a real observation and say why.
   - Lesson: "The 3-line Loom script" ([the-3-line-loom-script.md](references/outreach/the-3-line-loom-script.md))
2. Write Follow-up 1 (day 3, new angle) and Follow-up 2 (day 7, polite close) for each business.
   - Lesson: "The follow-up cadence" ([the-follow-up-cadence.md](references/outreach/the-follow-up-cadence.md))
3. Produce the tracking sheet as a CSV block with the lesson's columns, one row per business.
   - Lesson: "The follow-up cadence" ([the-follow-up-cadence.md](references/outreach/the-follow-up-cadence.md))

## Deliverable

Produce one Markdown document with these `##` headings, in this order:

- Messages
- Skipped
- Tracking sheet

## Rules

- Never start a message with "I" or the member's company name.
- No prices, attachments or links except the Loom link placeholder.
- Exactly two follow-ups per business.
- Base every recommendation on the lessons above. Never invent lessons, prices, results or promises.
- If the member asks something the lessons don't cover, say "This isn't covered in the classroom yet", label any suggestion as your own, and point them to: Ask in the Help channel and tag a coach.

## Check your work before you finish

Check the deliverable against this list and fix anything that fails before you show it:

- It contains "## Messages", "## Tracking sheet", "Day 0", "Day 3", "Day 7".
- It contains "Business,Contact,Observation,Day 0 sent,Day 3 sent,Day 7 sent,Reply,Call booked".
- It is at most 9000 characters long.

## When you're done

This task is part of the member's **First win** (One-page offer posted in Wins and 20 outreach messages sent, within 14 days of joining). When they have it, tell them: Post in Wins with "#firstwin" and a link to your offer.

## Example

[examples/example-input.md](examples/example-input.md) and [examples/example-output.md](examples/example-output.md) show the expected shape of a good result. The example output was written by hand; follow the lessons, not the example's specifics.
