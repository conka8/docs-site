# Northwind member pack pilot (synthetic): pilot report

**Suggestion: CONTINUE**

- The outcome rate is 16.3 points above baseline (target 10).
- The 95% ranges still overlap: run another cohort before treating this as settled.

## Primary outcome: First win within 14 days of joining

| Cohort | Members | Reached the outcome |
|---|---|---|
| Pilot (got the pack) | 40 | 16/40 = 40% (95% range 26-55%) |
| Baseline (earlier members) | 38 | 9/38 = 24% (95% range 13-39%) |

Difference: +16.3 percentage points.

## Adoption

- Installed: 29/40 = 72% (95% range 57-84%)
- Reported using a skill: 23/40 = 58% (95% range 42-71%)

## First renewal

- Pilot: 29/39 = 74% (95% range 59-85%)
- Baseline: 25/38 = 66% (95% range 50-79%)
- Refunds in the pilot cohort: 1
- Observed revenue difference for the pilot cohort's first renewal: 323 (renewal-rate difference × pilot members × price, after platform fees; an observed difference, not money the pack is proven to have earned)

## Member questions

- Tutor answers reviewed: 42 (resolved 34, corrected 4, escalated 4)
- Correction rate: 10%
- Staff-handled questions: 18, 11 minutes each
- Staff capacity freed (estimate): 6.3 hours (resolved tutor answers × average staff minutes; capacity, not cash)

## Costs of the pilot

- Cash spent: 6
- Time spent: 12.5 hours

## Read this before you decide

- This compares two cohorts; it does not prove the member pack caused any difference. Season, marketing, price changes and who joined can all differ between months.
- Events are only as complete as your logging. Self-reported outcomes undercount members who don't post.
- Staff time freed is capacity, not cash, unless you actually reduced paid hours.
