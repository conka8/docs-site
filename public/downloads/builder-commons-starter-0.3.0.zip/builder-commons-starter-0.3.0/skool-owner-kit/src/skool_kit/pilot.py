"""`skool-kit pilot`: turn a pilot's three logs into a report and a continue / change / stop suggestion.

Inputs (made by `pack-build` in pilot/): pilot.yaml (cohort dates, thresholds), events.csv, questions.csv,
costs.csv. All local; nothing is sent anywhere.

The report compares a pilot cohort with an earlier baseline cohort. That is an observational comparison:
it can show a difference, not prove the pack caused it. Cash, costs avoided and staff time are kept apart.
"""
from __future__ import annotations

import csv
import io
import json
import math
from dataclasses import asdict, dataclass, field
from datetime import date, datetime
from pathlib import Path

import yaml

EVENTS = ("joined", "installed", "used", "first_outcome", "renewed", "cancelled", "refunded")
CAVEATS = [
    "This compares two cohorts; it does not prove the member pack caused any difference. Season, marketing, "
    "price changes and who joined can all differ between months.",
    "Events are only as complete as your logging. Self-reported outcomes undercount members who don't post.",
    "Staff time freed is capacity, not cash, unless you actually reduced paid hours.",
]


class PilotError(ValueError):
    pass


@dataclass
class Rate:
    hits: int
    total: int

    @property
    def pct(self) -> float | None:
        return 100.0 * self.hits / self.total if self.total else None

    def interval(self) -> tuple[float, float] | None:
        """95% Wilson score interval, in percent."""
        n = self.total
        if not n:
            return None
        z = 1.96
        p = self.hits / n
        centre = (p + z * z / (2 * n)) / (1 + z * z / n)
        half = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / (1 + z * z / n)
        return max(0.0, 100 * (centre - half)), min(100.0, 100 * (centre + half))


@dataclass
class PilotReport:
    name: str
    outcome: str
    within_days: int
    pilot_members: int
    baseline_members: int
    adoption: Rate
    used: Rate
    outcome_pilot: Rate
    outcome_baseline: Rate
    lift_pts: float | None
    renewal_pilot: Rate
    renewal_baseline: Rate
    refunds: int
    observed_revenue_difference: float | None
    tutor_answers: int
    tutor_resolved: int
    tutor_corrected: int
    tutor_escalated: int
    correction_pct: float | None
    staff_questions: int
    staff_minutes_per_question: float | None
    capacity_hours_freed_estimate: float | None
    cash_costs: float
    time_cost_hours: float
    decision: str
    reasons: list[str] = field(default_factory=list)
    caveats: list[str] = field(default_factory=lambda: list(CAVEATS))
    warnings: list[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        d = asdict(self)
        for key in ("adoption", "used", "outcome_pilot", "outcome_baseline", "renewal_pilot", "renewal_baseline"):
            rate = getattr(self, key)
            d[key] = {"hits": rate.hits, "total": rate.total, "pct": rate.pct, "ci95": rate.interval()}
        return d


def _date(text, where: str) -> date:
    if isinstance(text, date):
        return text
    try:
        return datetime.strptime(str(text).strip()[:10], "%Y-%m-%d").date()
    except ValueError as exc:
        raise PilotError(f"{where}: date {text!r} must look like 2026-12-01") from exc


def _read_csv(path: Path, required: tuple[str, ...]) -> list[dict]:
    if not path.is_file():
        raise PilotError(f"log not found: {path}")
    try:
        text = path.read_text(encoding="utf-8-sig")
    except UnicodeDecodeError as exc:
        raise PilotError(f"{path} is not saved as UTF-8 text (in Excel: Save As > CSV UTF-8)") from exc
    rows = list(csv.DictReader(io.StringIO(text)))
    header = [h.strip().lower() for h in (csv.reader(io.StringIO(text)).__next__() if text.strip() else [])]
    missing = [c for c in required if c not in header]
    if missing:
        raise PilotError(f"{path.name} is missing column(s): {', '.join(missing)}")
    return [{(k or "").strip().lower(): (v or "").strip() for k, v in r.items()} for r in rows]


def _number(value: str, where: str) -> float:
    if value in ("", None):
        return 0.0
    try:
        return float(str(value).replace(",", ""))
    except ValueError as exc:
        raise PilotError(f"{where}: {value!r} is not a number") from exc


def load_plan(path: str | Path) -> tuple[dict, Path]:
    path = Path(path)
    if not path.is_file():
        raise PilotError(f"pilot plan not found: {path}")
    try:
        plan = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
    except yaml.YAMLError as exc:
        raise PilotError(f"{path} is not valid YAML: {exc}") from exc
    for key in ("pilot_cohort", "baseline_cohort", "within_days"):
        if key not in plan:
            raise PilotError(f"{path.name}: '{key}' is required")
    for key in ("pilot_cohort", "baseline_cohort"):
        c = plan[key] or {}
        lo, hi = _date(c.get("joined_from"), f"{key}.joined_from"), _date(c.get("joined_to"), f"{key}.joined_to")
        if hi < lo:
            raise PilotError(f"{key}: joined_to is before joined_from")
        plan[key] = (lo, hi)
    return plan, path.parent


def analyse(plan: dict, events: list[dict], questions: list[dict], costs: list[dict]) -> PilotReport:
    warnings: list[str] = []
    within = int(plan["within_days"])
    outcome_event = plan.get("outcome_event") or "first_outcome"
    joined: dict[str, date] = {}
    by_member: dict[str, dict[str, list[date]]] = {}
    for n, row in enumerate(events, 2):
        member, event = row.get("member", ""), row.get("event", "").lower()
        if not member or not event:
            warnings.append(f"events.csv line {n}: needs a member and an event; skipped")
            continue
        if event not in EVENTS and event != outcome_event:
            warnings.append(f"events.csv line {n}: unknown event {event!r}; skipped")
            continue
        when = _date(row.get("date"), f"events.csv line {n}")
        if event == "joined":
            joined.setdefault(member, when)
        by_member.setdefault(member, {}).setdefault(event, []).append(when)
    orphans = sorted(set(by_member) - set(joined))
    if orphans:
        warnings.append(f"{len(orphans)} member(s) have events but no 'joined' row and were left out: "
                        + ", ".join(orphans[:5]) + ("..." if len(orphans) > 5 else ""))

    def cohort(rng) -> list[str]:
        lo, hi = rng
        return [m for m, d in joined.items() if lo <= d <= hi]

    pilot, base = cohort(plan["pilot_cohort"]), cohort(plan["baseline_cohort"])

    def has(m: str, event: str) -> bool:
        return bool(by_member.get(m, {}).get(event))

    def reached(m: str) -> bool:
        return any(0 <= (d - joined[m]).days <= within for d in by_member.get(m, {}).get(outcome_event, []))

    def renewal(members) -> Rate:
        decided = [m for m in members if has(m, "renewed") or has(m, "cancelled")]
        return Rate(sum(1 for m in decided if has(m, "renewed") and not has(m, "cancelled")), len(decided))

    adoption = Rate(sum(1 for m in pilot if has(m, "installed")), len(pilot))
    used = Rate(sum(1 for m in pilot if has(m, "used")), len(pilot))
    out_p = Rate(sum(1 for m in pilot if reached(m)), len(pilot))
    out_b = Rate(sum(1 for m in base if reached(m)), len(base))
    lift = out_p.pct - out_b.pct if out_p.total and out_b.total else None
    ren_p, ren_b = renewal(pilot), renewal(base)
    price = float(plan.get("membership_price") or 0)
    fee = float(plan.get("platform_fee_pct") or 0) / 100
    revenue_diff = None
    if ren_p.total and ren_b.total and price:
        revenue_diff = (ren_p.pct - ren_b.pct) / 100 * len(pilot) * price * (1 - fee)

    tutor = [q for q in questions if q.get("handled_by", "").lower() == "tutor"]
    staff = [q for q in questions if q.get("handled_by", "").lower() == "staff"]
    resolved = sum(1 for q in tutor if q.get("result", "").lower() == "resolved")
    corrected = sum(1 for q in tutor if q.get("result", "").lower() == "corrected")
    escalated = sum(1 for q in tutor if q.get("result", "").lower() == "escalated")
    staff_minutes = [_number(q.get("staff_minutes", ""), "questions.csv staff_minutes") for q in staff]
    per_q = sum(staff_minutes) / len(staff_minutes) if staff_minutes else None
    freed = resolved * per_q / 60 if per_q is not None else None
    cash = sum(_number(c.get("amount", ""), "costs.csv amount") for c in costs if c.get("kind", "").lower() == "cash")
    hours = sum(_number(c.get("minutes", ""), "costs.csv minutes") for c in costs
                if c.get("kind", "").lower() == "time") / 60
    correction_pct = 100 * corrected / len(tutor) if tutor else None

    t = plan.get("thresholds") or {}
    reasons: list[str] = []
    min_cohort = int(t.get("min_cohort", 20))
    if len(pilot) < min_cohort or len(base) < min_cohort:
        decision = "not enough data"
        reasons.append(f"Each cohort needs at least {min_cohort} members (pilot {len(pilot)}, baseline {len(base)}).")
    else:
        ci_p, ci_b = out_p.interval(), out_b.interval()
        overlap = ci_p and ci_b and ci_p[0] <= ci_b[1] and ci_b[0] <= ci_p[1]
        if adoption.pct is not None and adoption.pct < float(t.get("min_adoption_pct", 40)):
            decision = "change"
            reasons.append(f"Only {adoption.pct:.0f}% of pilot members installed the pack (target "
                           f"{t.get('min_adoption_pct', 40)}%). Fix onboarding before judging the outcome.")
        elif lift is not None and lift >= float(t.get("continue_if_lift_pts", 10)):
            decision = "continue"
            reasons.append(f"The outcome rate is {lift:.1f} points above baseline (target "
                           f"{t.get('continue_if_lift_pts', 10)}).")
            if overlap:
                reasons.append("The 95% ranges still overlap: run another cohort before treating this as settled.")
        elif lift is not None and lift <= float(t.get("stop_if_lift_pts", 0)):
            decision = "stop or change"
            reasons.append(f"The outcome rate is not above baseline ({lift:+.1f} points).")
        else:
            decision = "extend"
            reasons.append(f"The outcome rate moved {lift:+.1f} points: between your stop and continue thresholds. "
                           "Run another cohort.")
    if correction_pct is not None and correction_pct > float(t.get("max_correction_pct", 10)):
        reasons.append(f"{correction_pct:.0f}% of reviewed tutor answers needed correcting (limit "
                       f"{t.get('max_correction_pct', 10)}%). Fix the lessons or the tutor before scaling.")
    return PilotReport(
        name=str(plan.get("pilot") or "Pilot"), outcome=str(plan.get("outcome") or outcome_event), within_days=within,
        pilot_members=len(pilot), baseline_members=len(base), adoption=adoption, used=used,
        outcome_pilot=out_p, outcome_baseline=out_b, lift_pts=lift, renewal_pilot=ren_p, renewal_baseline=ren_b,
        refunds=sum(1 for m in pilot if has(m, "refunded")), observed_revenue_difference=revenue_diff,
        tutor_answers=len(tutor), tutor_resolved=resolved, tutor_corrected=corrected, tutor_escalated=escalated,
        correction_pct=correction_pct, staff_questions=len(staff), staff_minutes_per_question=per_q,
        capacity_hours_freed_estimate=freed, cash_costs=cash, time_cost_hours=hours, decision=decision,
        reasons=reasons, warnings=warnings)


def run(plan_path: str | Path) -> PilotReport:
    plan, base = load_plan(plan_path)
    events = _read_csv(base / plan.get("events", "events.csv"), ("member", "event", "date"))
    questions = _read_csv(base / plan.get("questions", "questions.csv"), ("handled_by", "result", "staff_minutes"))
    costs = _read_csv(base / plan.get("costs", "costs.csv"), ("kind", "amount", "minutes"))
    return analyse(plan, events, questions, costs)


# ---------------------------------------------------------------- output


def _rate(r: Rate) -> str:
    if not r.total:
        return "no data"
    lo, hi = r.interval()
    return f"{r.hits}/{r.total} = {r.pct:.0f}% (95% range {lo:.0f}-{hi:.0f}%)"


def _money(x: float | None) -> str:
    return "n/a" if x is None else f"{x:,.0f}"


def render_md(r: PilotReport) -> str:
    out = [f"# {r.name}: pilot report", "",
           f"**Suggestion: {r.decision.upper()}**", ""] + [f"- {x}" for x in r.reasons]
    out += ["", f"## Primary outcome: {r.outcome} within {r.within_days} days of joining", "",
            "| Cohort | Members | Reached the outcome |", "|---|---|---|",
            f"| Pilot (got the pack) | {r.pilot_members} | {_rate(r.outcome_pilot)} |",
            f"| Baseline (earlier members) | {r.baseline_members} | {_rate(r.outcome_baseline)} |", "",
            f"Difference: {'n/a' if r.lift_pts is None else f'{r.lift_pts:+.1f} percentage points'}.", "",
            "## Adoption", "",
            f"- Installed: {_rate(r.adoption)}", f"- Reported using a skill: {_rate(r.used)}", "",
            "## First renewal", "",
            f"- Pilot: {_rate(r.renewal_pilot)}", f"- Baseline: {_rate(r.renewal_baseline)}",
            f"- Refunds in the pilot cohort: {r.refunds}",
            f"- Observed revenue difference for the pilot cohort's first renewal: {_money(r.observed_revenue_difference)} "
            "(renewal-rate difference × pilot members × price, after platform fees; an observed difference, not "
            "money the pack is proven to have earned)", "",
            "## Member questions", "",
            f"- Tutor answers reviewed: {r.tutor_answers} (resolved {r.tutor_resolved}, corrected {r.tutor_corrected}, "
            f"escalated {r.tutor_escalated})",
            f"- Correction rate: {'n/a' if r.correction_pct is None else f'{r.correction_pct:.0f}%'}",
            f"- Staff-handled questions: {r.staff_questions}, "
            f"{'n/a' if r.staff_minutes_per_question is None else f'{r.staff_minutes_per_question:.0f}'} minutes each",
            f"- Staff capacity freed (estimate): "
            f"{'n/a' if r.capacity_hours_freed_estimate is None else f'{r.capacity_hours_freed_estimate:.1f} hours'} "
            "(resolved tutor answers × average staff minutes; capacity, not cash)", "",
            "## Costs of the pilot", "",
            f"- Cash spent: {_money(r.cash_costs)}", f"- Time spent: {r.time_cost_hours:.1f} hours", "",
            "## Read this before you decide", ""] + [f"- {c}" for c in r.caveats]
    if r.warnings:
        out += ["", "## Log problems", ""] + [f"- {w}" for w in r.warnings]
    return "\n".join(out) + "\n"


def render_text(r: PilotReport) -> str:
    return render_md(r).replace("**", "").replace("## ", "").replace("# ", "")


def render(r: PilotReport, fmt: str = "text") -> str:
    if fmt == "json":
        return json.dumps(r.to_dict(), indent=2, default=str) + "\n"
    if fmt == "md":
        return render_md(r)
    return render_text(r)
