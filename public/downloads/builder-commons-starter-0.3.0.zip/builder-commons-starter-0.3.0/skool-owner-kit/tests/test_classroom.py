import re

import pytest
import yaml

from skool_kit.classroom import (SkillError, build_description, build_skill, clean_title, discover, html_to_text,
                                 order_key, slugify, split_text, validate_name)


def make_lessons(root):
    (root / "10-advanced").mkdir(parents=True)
    (root / "2-basics").mkdir()
    (root / "1-start-here").mkdir()
    (root / "1-start-here" / "01-welcome.md").write_text("# Welcome!\n\nHello and welcome.\n")
    (root / "1-start-here" / "10-last.txt").write_text("Last lesson body.")
    (root / "1-start-here" / "2-second.html").write_text(
        "<html><head><title>Ignored title</title><style>.x{}</style><script>evil()</script></head>"
        "<body><h1>Second &amp; Better</h1><p>Use <b>bold</b> moves.</p><ul><li>One</li><li>Two</li></ul>"
        "<p><a href='https://ex.com/a'>link</a> <a href='/rel'>rel</a></p><img src=x alt='diagram'></body></html>")
    (root / "1-start-here" / ".hidden.md").write_text("secret")
    (root / "1-start-here" / "notes.pdf").write_bytes(b"%PDF")
    (root / "1-start-here" / "3-empty.md").write_text("   \n")
    (root / "2-basics" / "intro.md").write_text("Intro A")
    (root / "2-basics" / "Intro.txt").write_text("Intro B")  # same slug as intro.md
    (root / "10-advanced" / "1-deep.md").write_text("# Deep Dive\n\n" + "\n\n".join(f"Paragraph {i} " + "x" * 300 for i in range(20)))
    (root / "loose-file.md").write_text("Top-level lesson")
    (root / "empty-module").mkdir()
    (root / "empty-module" / "blank.md").write_text("")


def test_helpers():
    assert slugify("Héllo, World! 2") == "hello-world-2" and slugify("!!!", "x") == "x"
    assert order_key("2-b") < order_key("10-a") < order_key("zzz")
    assert order_key("1.2 sub") > order_key("1.1 sub")
    assert clean_title("03 - getting_started.md") == "Getting started"
    assert clean_title("Module 2: Finding Clients") == "Finding Clients"
    assert clean_title("12.md") == "Untitled"
    validate_name("my-community-tutor")
    for bad in ("My Tutor", "a--b", "-a", "x" * 65, ""):
        with pytest.raises(SkillError):
            validate_name(bad)


def test_html_to_text():
    text, title = html_to_text("<head><title>T</title></head><h2>Sub</h2><p>A&nbsp;&lt;b&gt;</p><script>x()</script>"
                               "<table><tr><td>1</td><td>2</td></tr></table><br>end")
    assert title == "T"
    assert "## Sub" in text and "A <b>" in text and "x()" not in text and "| 1 | 2" in text and "end" in text


def test_split_text():
    assert split_text("short", 100) == ["short"]
    text = "\n\n".join("p" * 40 for _ in range(10))
    parts = split_text(text, 100)
    assert all(len(p) <= 100 for p in parts) and "".join(parts).count("p") == 400
    huge = "word " * 100
    parts = split_text("intro\n\n" + huge, 120)
    assert all(len(p) <= 120 for p in parts) and parts[0] == "intro"
    nospace = "y" * 250
    assert [len(p) for p in split_text(nospace, 100)] == [100, 100, 50]


def test_discover_order_titles_and_warnings(tmp_path):
    make_lessons(tmp_path)
    modules, warnings = discover(tmp_path, max_chars=1000)
    assert [m.title for m in modules] == ["General", "Start here", "Basics", "Advanced"]
    start = modules[1]
    assert [lesson.title for lesson in start.lessons] == ["Welcome!", "Second & Better", "Last"]
    assert [lesson.slug for lesson in modules[2].lessons] == ["intro", "intro-2"]
    assert any("empty lesson skipped: 1-start-here/3-empty.md" in w for w in warnings)
    assert any("notes.pdf" in w and "not a lesson file" in w for w in warnings)
    assert any("module 'Empty module' has no usable lessons" in w for w in warnings)
    assert not any("hidden" in w for w in warnings)
    second = start.lessons[1].text
    assert "evil()" not in second and "Ignored title" not in second
    assert "- One\n- Two" in second and "link (https://ex.com/a)" in second and "(/rel)" not in second
    assert "[image: diagram]" in second
    assert len(modules[3].lessons[0].parts) > 1


def test_build_skill_structure(tmp_path):
    src = tmp_path / "lessons"
    make_lessons(src)
    info = build_skill(src, "club-tutor", tmp_path / "out", "AI Club", "https://www.skool.com/ai-club/classroom",
                       max_chars=1000)
    skill = tmp_path / "out" / "club-tutor"
    text = (skill / "SKILL.md").read_text()
    m = re.match(r"^---\n(.*?)\n---\n", text, re.S)
    front = yaml.safe_load(m.group(1))
    assert front["name"] == "club-tutor"
    assert re.fullmatch(r"[a-z0-9-]{1,64}", front["name"])
    assert 0 < len(front["description"]) <= 1024
    assert "AI Club" in front["description"] and "Use when" in front["description"]
    assert set(front) == {"name", "description"}
    assert "https://www.skool.com/ai-club/classroom" in text
    assert "isn't covered" in text
    # index table in classroom order
    rows = [line for line in text.splitlines() if re.match(r"^\| \d+ \|", line)]
    assert [r.split("|")[3].strip() for r in rows] == [
        "Loose file", "Welcome!", "Second & Better", "Last", "Intro", "Intro", "Deep Dive"]
    assert info["lessons"] == 7 and info["modules"] == 4
    deep_files = sorted(p.name for p in (skill / "references" / "advanced").iterdir())
    assert deep_files[0] == "deep-dive-part-1.md" and len(deep_files) == info["files"] - 6
    assert info["split_lessons"] == ["Deep Dive"]
    for f in deep_files:
        assert f"references/advanced/{f}" in text
    p1 = (skill / "references" / "advanced" / "deep-dive-part-1.md").read_text()
    assert p1.startswith(f"# Deep Dive (part 1 of {len(deep_files)})") and "Module: Advanced" in p1
    assert "Paragraph 0" in p1 and "# Deep Dive\n\n# Deep" not in p1
    welcome = (skill / "references" / "start-here" / "welcome.md").read_text()
    assert welcome.count("# Welcome!") == 1 and "Source file: 1-start-here/01-welcome.md" in welcome
    assert (skill / "references" / "basics" / "intro-2.md").exists()
    assert (skill / "references" / "general" / "loose-file.md").exists()


def test_frontmatter_survives_special_characters(tmp_path):
    src = tmp_path / "l"
    (src / "1-mod: \"quotes\" & #hash").mkdir(parents=True)
    (src / "1-mod: \"quotes\" & #hash" / "a.md").write_text("text")
    build_skill(src, "q-tutor", tmp_path / "o", community='Club: "The Best" #1')
    text = (tmp_path / "o" / "q-tutor" / "SKILL.md").read_text()
    front = yaml.safe_load(text.split("---\n")[1])
    assert 'Club: "The Best" #1' in front["description"]


def test_description_truncated_to_1024():
    from skool_kit.classroom import Module
    mods = [Module(f"Module number {i} with a long descriptive title", f"m{i}") for i in range(60)]
    d = build_description("Club", mods, 300)
    assert len(d) <= 1024 and d.endswith("covers a topic.") and ", ...)" in d


def test_build_skill_errors(tmp_path):
    with pytest.raises(SkillError, match="not found"):
        build_skill(tmp_path / "nope", "x", tmp_path)
    empty = tmp_path / "empty"
    empty.mkdir()
    (empty / "a.md").write_text("")
    with pytest.raises(SkillError, match="no lessons found"):
        build_skill(empty, "x", tmp_path / "o")
    src = tmp_path / "src"
    src.mkdir()
    (src / "a.md").write_text("hello")
    with pytest.raises(SkillError, match="max-chars"):
        build_skill(src, "x", tmp_path / "o", max_chars=10)
    build_skill(src, "x", tmp_path / "o")
    with pytest.raises(SkillError, match="already exists"):
        build_skill(src, "x", tmp_path / "o")
    (tmp_path / "o" / "x" / "references" / "stale.md").write_text("old")
    build_skill(src, "x", tmp_path / "o", force=True)
    assert not (tmp_path / "o" / "x" / "references" / "stale.md").exists()
    with pytest.raises(SkillError, match="lowercase"):
        build_skill(src, "Bad Name", tmp_path / "o2")


def test_non_utf8_lesson(tmp_path):
    src = tmp_path / "s"
    src.mkdir()
    (src / "a.txt").write_bytes("Caf\xe9 lesson".encode("cp1252"))
    modules, warnings = discover(src)
    assert "Café" in modules[0].lessons[0].text and "Windows-1252" in warnings[0]
