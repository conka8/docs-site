import json
import shutil
from pathlib import Path

import pytest

from skool_kit.cli import main
from skool_kit.pilot import PilotError, Rate, analyse, load_plan, render, run

SAMPLE = Path(__file__).parent.parent / "examples" / "agency-lab" / "pilot-sample"

PLAN = """pilot: Test pilot
outcome: First win
within_days: 14
pilot_cohort: {joined_from: 2026-11-01, joined_to: 2026-11-30}
baseline_cohort: {joined_from: 2026-09-01, joined_to: 2026-09-30}
membership_price: 100
platform_fee_pct: 10
thresholds: {min_cohort: 2, min_adoption_pct: 40, continue_if_lift_pts: 10, stop_if_lift_pts: 0, max_correction_pct: 10}
"""


def write(tmp_path, events, questions="", costs="", plan=PLAN):
    (tmp_path / "pilot.yaml").write_text(plan, encoding="utf-8")
    (tmp_path / "events.csv").write_text("member,event,date,note\n" + events, encoding="utf-8")
    (tmp_path / "questions.csv").write_text("date,topic,handled_by,result,staff_minutes,note\n" + questions,
                                            encoding="utf-8")
    (tmp_path / "costs.csv").write_text("date,item,kind,amount,minutes,note\n" + costs, encoding="utf-8")
    return tmp_path / "pilot.yaml"


def events(rows):
    return "".join(f"{m},{e},{d},\n" for m, e, d in rows)


BASIC = events([
    ("p1", "joined", "2026-11-01"), ("p1", "installed", "2026-11-02"), ("p1", "first_outcome", "2026-11-10"),
    ("p1", "renewed", "2026-12-01"),
    ("p2", "joined", "2026-11-05"), ("p2", "installed", "2026-11-05"), ("p2", "first_outcome", "2026-11-30"),
    ("p2", "cancelled", "2026-11-28"),
    ("b1", "joined", "2026-09-01"), ("b1", "first_outcome", "2026-09-30"), ("b1", "renewed", "2026-10-01"),
    ("b2", "joined", "2026-09-10"), ("b2", "cancelled", "2026-10-01"),
])


def test_cohorts_outcome_window_and_lift(tmp_path):
    r = run(write(tmp_path, BASIC))
    assert (r.pilot_members, r.baseline_members) == (2, 2)
    # p2 reached the outcome after 25 days and b1 after 29: outside the 14-day window
    assert (r.outcome_pilot.hits, r.outcome_baseline.hits) == (1, 0)
    assert r.lift_pts == pytest.approx(50.0)
    assert r.adoption.pct == 100.0 and r.decision == "continue"
    assert any("ranges still overlap" in x for x in r.reasons)


def test_renewal_and_observed_revenue_difference(tmp_path):
    r = run(write(tmp_path, BASIC))
    assert (r.renewal_pilot.hits, r.renewal_pilot.total) == (1, 2)
    assert (r.renewal_baseline.hits, r.renewal_baseline.total) == (1, 2)
    assert r.observed_revenue_difference == pytest.approx(0.0)


def test_support_metrics_keep_capacity_separate_from_cash(tmp_path):
    q = ("2026-11-02,niche,tutor,resolved,0,\n2026-11-03,niche,tutor,resolved,0,\n"
         "2026-11-04,price,tutor,corrected,5,\n2026-11-05,tax,tutor,escalated,5,\n"
         "2026-11-06,setup,staff,resolved,10,\n2026-11-07,setup,staff,resolved,20,\n")
    c = "2026-11-01,setup,time,,120,\n2026-11-01,api,cash,12.5,,\n2026-11-02,fee,cash,\"1,000\",,\n"
    r = run(write(tmp_path, BASIC, q, c))
    assert (r.tutor_answers, r.tutor_resolved, r.tutor_corrected, r.tutor_escalated) == (4, 2, 1, 1)
    assert r.correction_pct == 25.0 and r.staff_minutes_per_question == 15.0
    assert r.capacity_hours_freed_estimate == pytest.approx(0.5)
    assert r.cash_costs == 1012.5 and r.time_cost_hours == 2.0
    assert any("needed correcting" in x for x in r.reasons)


def test_not_enough_data(tmp_path):
    r = run(write(tmp_path, BASIC, plan=PLAN.replace("min_cohort: 2", "min_cohort: 20")))
    assert r.decision == "not enough data" and "at least 20 members" in r.reasons[0]


def test_low_adoption_means_change(tmp_path):
    rows = BASIC.replace("p1,installed,2026-11-02,\n", "").replace("p2,installed,2026-11-05,\n", "")
    r = run(write(tmp_path, rows))
    assert r.decision == "change" and "installed the pack" in r.reasons[0]


def test_no_lift_means_stop_or_change(tmp_path):
    rows = BASIC.replace("p1,first_outcome,2026-11-10,\n", "")
    assert run(write(tmp_path, rows)).decision == "stop or change"


def test_between_thresholds_means_extend(tmp_path):
    plan = PLAN.replace("continue_if_lift_pts: 10", "continue_if_lift_pts: 60")
    assert run(write(tmp_path, BASIC, plan=plan)).decision == "extend"


def test_log_problems_are_warnings(tmp_path):
    rows = BASIC + "x9,first_outcome,2026-11-02,\n,joined,2026-11-02,\np1,danced,2026-11-02,\n"
    r = run(write(tmp_path, rows))
    assert any("no 'joined' row" in w for w in r.warnings)
    assert any("needs a member and an event" in w for w in r.warnings)
    assert any("unknown event 'danced'" in w for w in r.warnings)


@pytest.mark.parametrize("bad, message", [
    ("p1,joined,11/01/2026,\n", "must look like 2026-12-01"),
])
def test_bad_dates(tmp_path, bad, message):
    with pytest.raises(PilotError, match=message):
        run(write(tmp_path, bad))


def test_plan_and_file_errors(tmp_path):
    with pytest.raises(PilotError, match="pilot plan not found"):
        load_plan(tmp_path / "nope.yaml")
    with pytest.raises(PilotError, match="'within_days' is required"):
        run(write(tmp_path, BASIC, plan="pilot_cohort: {joined_from: 2026-01-01, joined_to: 2026-01-02}\n"
                                        "baseline_cohort: {joined_from: 2026-01-01, joined_to: 2026-01-02}\n"))
    with pytest.raises(PilotError, match="joined_to is before joined_from"):
        run(write(tmp_path, BASIC, plan=PLAN.replace("joined_to: 2026-11-30", "joined_to: 2026-10-01")))
    path = write(tmp_path, BASIC)
    (tmp_path / "costs.csv").write_text("date,item\n", encoding="utf-8")
    with pytest.raises(PilotError, match="missing column"):
        run(path)
    (tmp_path / "costs.csv").write_bytes("date,item,kind,amount,minutes\n1,caf\xe9,cash,1,\n".encode("cp1252"))
    with pytest.raises(PilotError, match="UTF-8"):
        run(path)
    (tmp_path / "costs.csv").write_text("date,item,kind,amount,minutes\n1,x,cash,lots,\n", encoding="utf-8")
    with pytest.raises(PilotError, match="not a number"):
        run(path)


def test_rate_interval():
    assert Rate(0, 0).pct is None and Rate(0, 0).interval() is None
    lo, hi = Rate(16, 40).interval()
    assert round(lo) == 26 and round(hi) == 55


def test_render_formats_always_carry_the_caveats(tmp_path):
    r = run(write(tmp_path, BASIC))
    md = render(r, "md")
    assert md.startswith("# Test pilot: pilot report") and "**Suggestion: CONTINUE**" in md
    assert "does not prove the member pack caused" in md and "capacity, not cash" in md
    assert "Suggestion: CONTINUE" in render(r, "text") and "**" not in render(r, "text")
    data = json.loads(render(r, "json"))
    assert data["outcome_pilot"]["pct"] == 50.0 and len(data["outcome_pilot"]["ci95"]) == 2 and data["caveats"]


def test_sample_pilot_and_cli(tmp_path, capsys):
    shutil.copytree(SAMPLE, tmp_path / "s")
    assert main(["pilot", str(tmp_path / "s" / "pilot.yaml")]) == 0
    out = capsys.readouterr().out
    assert "Suggestion: CONTINUE" in out and "16/40 = 40%" in out and "9/38 = 24%" in out
    assert main(["pilot", str(tmp_path / "s" / "pilot.yaml"), "--format", "md", "-o", str(tmp_path / "r.md")]) == 0
    assert (tmp_path / "r.md").read_text() == (SAMPLE / "pilot-report.md").read_text()
    assert main(["pilot", str(tmp_path / "missing.yaml")]) == 2
    assert "pilot plan not found" in capsys.readouterr().err


def test_analyse_with_no_rows():
    plan, _ = None, None
    r = analyse({"within_days": 14, "pilot_cohort": (__import__("datetime").date(2026, 1, 1),) * 2,
                 "baseline_cohort": (__import__("datetime").date(2026, 1, 1),) * 2}, [], [], [])
    assert r.decision == "not enough data" and r.lift_pts is None and r.correction_pct is None
    assert "no data" in render(r, "md")
