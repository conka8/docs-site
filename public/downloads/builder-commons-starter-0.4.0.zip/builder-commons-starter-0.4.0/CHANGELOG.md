# Changelog

## 2026-10-29 (night): design-partner terms and enquiries

- **Design-partner pilot terms published** on the "Scoped pilot" page and in PILOT-OFFER.md:
  - US$500 fixed for each of the first 3 communities that pass the fit check.
  - Payable half on spec approval and half on acceptance; the second half isn't due if the pilot stops at acceptance.
  - Anonymised results publishable; the community is named only with written consent.
  - Replies within 2 business days.
  - The standard price is not published.
- **Enquiries work.** The pilot page links to a GitHub issue form (`docs-site/.github/ISSUE_TEMPLATE/pilot-enquiry.yml`)
  that warns the issue is public and asks only for public facts. A test checks that the linked form exists.
- Pilots support the Claude app only. The decisions and their reasons are recorded in OFFER.md (internal).

## 2026-10-29 (evening): verified member workflow, cohort value model, scoped pilot (skool-owner-kit 0.4.0)

### skool-owner-kit 0.4.0

- **Task skills complete the work.** They ask only for missing required inputs (optional inputs take stated
  defaults), apply rules tied to named lessons, name conflicts with the lessons instead of silently following the
  member, and end the deliverable with a pass/fail Check, Gaps and assumptions, a Next step, and a ready-to-post
  Question for a coach when something is unresolved.
- **Unsupported claims are flagged.** Any money amount, number or customer-behaviour claim that isn't from the
  lessons or the member must be marked "verify before use". This came from a defect found in a real run.
- New spec fields: `support_channel`, rules with `lesson:`, `required`/`default` on inputs, `next_action`,
  `deliverable.filename`, and `extra_cases` (extra acceptance cases such as conflicting input).
- **Pilot report.**
  - `as_of`, `renewal_after_days` and an `excluded` event: members still inside a window are pending, not failures.
  - `task_completed` events and `acceptance.csv`.
  - Separate quality, outcome and economics verdicts. Quality failures, negative economics or a budget overrun hold
    back "continue".
- **Recorded runs:** `examples/agency-lab/live-runs/` has 8 runs in Claude Code, and the example outputs are now
  actual outputs instead of hand-written ones.

### Docs site and guides

- The value calculator is a month-by-month cohort model:
  - Payments count in the month they arrive, with future contribution reported separately.
  - Payback comes from cumulative cash, including dips back below zero.
  - Inputs are validated.
  - Fixed fees, refunds and delivery costs are included, and paid hours cut are separated from capacity.
- New: EFFORT.md (one estimated effort breakdown), PILOT-OFFER.md (scoped paid pilot), both generated from the site
  data. PILOT.md is now the first-customer workflow.
- The site follows: outcome, real run, fit, economics, scoped pilot.


## 2026-10-29 (later): member pack and pilot (starter bundle 0.3.0)

### skool-owner-kit 0.3.0

- `skool-kit pack-build pack.yaml`: builds a member pack from your lessons: a tutor that cites lessons and routes
  uncovered questions to your support channel, one task skill per first-win step (inputs to ask for, steps each
  tied to a lesson, deliverable sections, your rules, a self-check), acceptance checks for `skillkit eval`,
  MEMBER-START.md, ADMIN-REVIEW.md with a manual acceptance procedure, and a pilot kit. Rebuilding keeps files you
  edited and writes the new version next to them as `<file>.new`.
- `skool-kit pilot pilot.yaml`: compares a pilot cohort with a baseline cohort (first-outcome rate with 95% ranges,
  adoption, first renewal, tutor corrections, staff minutes, cash and time costs) and suggests continue, extend,
  change, stop or change, or not enough data. Staff time is reported as capacity, never as cash.
- `classroom-to-skill` takes the support route into account when the pack sets one.
- `examples/agency-lab/`: a synthetic AI-agency community with eight lessons, an n8n template, a pack spec,
  hand-written example outputs, the generated pack, and synthetic pilot logs with their report.

### skillkit 0.3.0

- `eval --include-references` also sends the text files each SKILL.md points to (references/, assets/,
  templates/, examples/). Reports say which mode ran.

### Guides

- New: BUSINESS-AUDIT.md, VALUE-MODEL.md, PILOT.md. OFFER.md (internal) rewritten around one buyer and offer.


## 2026-10-29: starter bundle 0.2.0, other tools 0.1.1

### Everyone

- Every tool, and a starter bundle (skool-owner-kit, skillport, skillkit and the guides), can be downloaded from
  the docs site. Each zip is install-tested in a fresh environment before release (`scripts/smoke_test.py`).
- Every quickstart now starts with sample files that ship in the download.
- New guides: [ADMIN-GUIDE.md](ADMIN-GUIDE.md), [MEMBER-GUIDE.md](MEMBER-GUIDE.md), [READINESS.md](READINESS.md),
  [DATA-AND-COSTS.md](DATA-AND-COSTS.md), [MAINTAINING.md](MAINTAINING.md).

### skillport 0.2.0

- Every converted skill has a **Conversion check** listing what doesn't carry over: code steps, schedules, AI steps,
  loops, logic in expressions, retries, continue-on-fail, error workflows, Make.com error handlers and calls to
  other workflows. `inspect` prints it, `convert`/`batch` count it, `inspect --format json` has it under `review`.
- Bridge skills check the webhook's reply mode ("Workflow was started" problem), the auth header to set, test vs
  production URLs, and network access.
- A field that is only a reference (`{{ $json.text }}`) reads "the value of `text`" instead of looking like the
  literal text "text".
- Install steps in generated READMEs match the current Claude app, Claude Code (including Windows) and OpenClaw docs.
- Sample workflows in `examples/`.

### skillkit 0.2.0

- `pack --format claude-app`: one upload zip per skill (skill folder at the zip root) and an `INSTALL.md`.
- Lint warnings `needs-review` (a skillport skill whose Conversion check hasn't been reviewed) and
  `frontmatter-upload-key` (header keys the Claude app and API reject).
- `eval` reports state that they are instruction-only tests, list the files each skill points to that were not sent
  to the model, and mark `--provider fake` runs as **DEMO DATA** (`"demo": true`, `"mode": "instruction-only"` in JSON).
- Sample library and cases in `examples/`.

### skool-owner-kit 0.2.0

- Dashboard says "Inactivity risk" and "Cohort activity" instead of churn and retention, explains that the export
  only holds current members, and has a "How to read this" section.
- Zapier setup uses Skool's actual triggers (Answered Membership Questions, New Paid Member; needs Skool Pro) and
  sends the secret in a header from an environment variable.
- The webhook drops connections that stall for 30 seconds.

### shipsafe 0.1.1

- An empty or wrong folder stops with exit 2 instead of getting grade A.
- Verdicts describe what the checks found ("No serious problems found by shipsafe's checks") and text/Markdown
  reports end with a scope line: a clean result is not a security audit.
- Quoted values assigned to names like `apiKey`, `token`, `secret` are masked in evidence lines.
- New rule `SS-SECRET-CLIENT-APIKEY` for long API keys in browser code.
- The skill and the example GitHub workflow no longer run `pip install shipsafe` (it isn't on PyPI).

### geo-audit 0.1.1

- Reports from the demo provider carry a "Demo data" banner (`"demo": true` in JSON).
- Reports say answers come from the providers' APIs, which can differ from the consumer apps.
- CSVs saved by Excel (cp1252) work; undecodable files give a clear error.
- A missing key for a selected provider stops before any question is asked (exit 2, no report written).

### voice-qa 0.1.1

- Scorecards say "simulated text conversations (no audio or phone line was tested)".
- Demo runs (scripted agent or fake provider) carry a "Demo data" banner.
- Real agents default to "your business" instead of the pack's sample name.
- Any errored conversation makes the run exit 1.
- Secrets in webhook error bodies are hidden and bodies are cut to 200 characters; non-UTF-8 files give a clear error.

### ghl-agency-kit 0.1.1

- Every output from the fake demo account carries a "Demo data" banner.
- Create requests (POST) are no longer retried on server errors, to avoid duplicates; only on 429 with Retry-After.
- `onboard` prints which account it is about to write to.

### vertical-packs 0.1.1

- Maintenance triage escalates any mention of carbon monoxide, gas, smoke, burning, burst pipes, exposed wires or
  shocks, and flags them "needs a human to review now". Negated danger words ("I don't smell gas anymore") are
  escalated to URGENT rather than ignored.

### career-labs 0.1.1

- The installed `labgrade` command finds the labs (`--labs-dir`, `LABGRADE_LABS_DIR`, `./labs`, then the package
  folder) and says what to do when it can't.
- `pyyaml` is installed with it, so every reference solution scores 100.

## Upgrading

Download the new zip, unzip it, activate the virtual environment you installed into, and install again:

```bash
source .venv/bin/activate                     # Windows: .venv\Scripts\Activate.ps1
python -m pip install ./skool-owner-kit ./skillport ./skillkit
```

- Skills converted with skillport 0.1 have no Conversion check. Convert them again, then review each list.
- skool-owner-kit's JSON still calls the cohort field `retention_pct`; only the dashboard wording changed.
- voice-qa exits 1 when any conversation errors; geo-audit exits 2 when a selected provider's key is missing.
  Adjust CI jobs that relied on the old exit codes.
