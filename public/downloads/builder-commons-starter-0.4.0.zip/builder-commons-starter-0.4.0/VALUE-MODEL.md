# Value model

How to judge whether a member pack earns or saves more than it costs. The docs site has the editable version
("Estimate economics"). The formulas live in `docs-site/src/data/value-model.js` and are tested in
`docs-site/tests/offer.test.mjs`.

**This is a decision aid, not evidence.** Every preset is an illustration, not a measurement or a result from any
community. Nobody has measured the renewal change for this product. Each preset row below is an input you replace.

## How it works

The model runs month by month over a period you choose (12 months by default). Month 0 is the launch month.

1. **Cohorts.** Each month, the same number of new paid members join and get the pack. Their joining payment is
   unchanged.
2. **The assumed effect.** The pack changes the share who make their *first* renewal payment, one month after
   joining. The change can be positive, zero or negative, and must keep the rate between 0% and 100%.
3. **After that.** Members gained (or lost) at the first renewal keep paying at the *later monthly retention* rate,
   up to the *maximum total paid months*. Both are explicit inputs.
4. **Each payment** counts in the month it would arrive. It is net of the percentage fee, the fixed fee per payment,
   refunds, and any delivery cost per extra paying member.
5. **Payments after the period** are reported separately as *projected future contribution*. They are never counted
   as cash in the period.
6. **Optional add-on sales** land in the launch month, net of fees, refunds and delivery cost per buyer.
7. **Support.**
   - Net hours freed = time the tutor saves on correctly answered questions − time spent correcting wrong answers.
   - Only the *paid support hours you actually cut* become cash, and never more than the net hours freed.
   - The rest is capacity: hours, never cash. It can be negative, meaning the tutor costs staff time.
   - Resolved + corrected can't exceed 100% of questions.
8. **Costs.** The implementation price lands in month 0. The monthly fee and API/software costs come every month.
9. **Your time.** Setup, pilot logging and maintenance hours, with defaults from [EFFORT.md](EFFORT.md). This is never
   subtracted from cash; a separate row values it.

## Results

| Result | Definition |
|---|---|
| Net cash in the period | Sum of each month's renewal payments + add-on + support cash avoided − costs |
| Payback | The first month after which cumulative cash stays at or above zero for the rest of the period. If cumulative cash reaches zero and later falls below it, the result says so. If it never stays above zero: "not reached within the modeled period" |
| Projected contribution after the period | Payments from members who joined inside the period that would arrive after it, under the retention assumptions |
| Renewal change needed | The change that makes net cash in the period zero. Cash is linear in the change, so it is solved exactly. "Not needed" if the period is already cash-positive; "not reachable" if no renewal change can cover it (for example a one-month period) or it would need more than 100% renewal |
| Add-on buyers needed | Buyers needed to cover the shortfall: never negative; "more than offered" if above the number offered; "not reachable" if each buyer nets nothing |
| Most you could pay one-off | Net cash in the period before the implementation price, floored at zero |

**Input validation.**
- Counts, prices, costs and hours can't be negative.
- Percentages must be 0-100.
- The period is 1-60 whole months, and the maximum paid months is a whole number of at least 1.
- Baseline + change must stay within 0-100%.
- Resolved + corrected can't exceed 100%, and fees + refunds can't exceed 100%.
- A scenario with invalid inputs shows the errors and no results.

## Worked example (illustrative inputs)

Shared inputs:
- 30 new paid members a month at 97 a month.
- Payment fee 2.9% + 0.30 per payment, refunds 1%. That leaves 92.92 per payment.
- Baseline first renewal 70%.
- 120 repeat questions a month at 6 staff minutes, 8 minutes per correction, support hour 25.
- API 10 a month, period 12 months, no implementation price entered.
- Your time: 9 setup + 7 pilot + 1.5 a month = 34 hours.

| Assumption | Conservative | Base | Optimistic |
|---|---|---|---|
| Change in first renewal | 0 points | 3 points | 8 points |
| Later monthly retention / max paid months | 75% / 6 | 85% / 12 | 90% / 18 |
| Tutor answers correct / corrected | 20% / 15% | 40% / 10% | 60% / 5% |
| Paid support hours actually cut per month | 0 | 0 | 4 |

| Result (12 months) | Conservative | Base | Optimistic |
|---|---|---|---|
| Extra renewal payments | 0 | 3,502 | 10,758 |
| Support cash avoided | 0 | 0 | 1,200 |
| Cash costs | 120 | 120 | 120 |
| **Net cash in the period** | **−120** | **3,382** | **11,838** |
| Projected contribution after the period (not cash yet) | 0 | 2,068 | 11,539 |
| Support capacity freed per month | 0 h (corrections cancel it) | 3.2 h | 2.4 h, plus 4 h turned into cash |
| Most you could pay one-off and break even in 12 months | 0 | 3,382 | 11,838 |

**With a quote.** Suppose someone quotes Q = 1,500, entered only to show the arithmetic, not as a price. In the base
case:
- Net cash in the period is 1,882.
- Cumulative cash runs −1,510 in month 0, −193 in month 6, then +176 in month 7, so payback is **month 7**.
- Break-even needs a renewal change of **1.39 points**.

With a 2-point *drop* in first renewals instead, the base case loses 2,455 in the period and never pays back.

How to read it:
- **With no renewal change the pack is a cost.** The conservative case loses its running costs, and correcting wrong
  answers cancels the support time saved.
- **The base case rests on one unmeasured assumption:** about 1 more member in every 33 new members renews (3
  points), then keeps paying at 85% a month.
- **Late cohorts matter.** Members who join in month 11 can't renew inside a 12-month period, so a short period
  understates benefits that may come later. That's why projected contribution is shown, but it is not counted as cash.
- **Community size decides fit.**
  - At 15 new members a month and 49 a month, a 1,500 quote would need about a 5.5-point change to pay back within a
    year.
  - At 60 new members and 129, it would need about 0.5 points.
  - Small communities should use the free tools.

## Questions to ask before buying

1. What renewal change would a quote need to pay back within the period? (The calculator shows it.)
2. Is that plausible, given how many new members reach your first outcome today?
3. Can you measure it? A pilot needs first-outcome and first-renewal results for two cohorts of 20+ members. See
   [PILOT.md](PILOT.md).
