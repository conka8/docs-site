# Member acceptance journey

From the released download to a member finishing a task, then again after an update. Each step says what was
verified, how, and where. "Verified" is used only for steps that ran.

| # | Step | How it was checked | Status |
|---|---|---|---|
| 1 | Obtain the distributed package | `scripts/acceptance_journey.py`: starter bundle checked against `manifest.json` (sha256) and unzipped | **Verified locally** |
| 2 | Install the tools as the admin guide says | fresh virtual environment, `pip install` from the bundle | **Verified locally** |
| 3 | Build, check and share the pack | the commands in the pack's `ADMIN-REVIEW.md`, run as written: `pack-build`, `skillkit lint --strict`, replay of saved outputs, `pack-share` | **Verified locally** (the replay re-checks saved outputs; it is not a model run) |
| 4 | Install as a member | the Claude Code commands in `START-HERE.md`, run as written with `HOME` pointed at a sandbox; `unzip` was emulated with Python's zipfile where the `unzip` program isn't installed | **Verified locally for Claude Code's folder layout.** Claude app upload **not verified** |
| 5 | Confirm the skills are available | each installed skill has SKILL.md, a name matching its folder, a description within the Claude app's 200-character limit, and working links | **Verified locally** (files only) |
| 5b | Claude picks the right skill from realistic language | a fresh model session given only the installed names and descriptions, asked which it would load for 8 member messages | **Simulated** (`journey-select-v1.md`, `-v2.md`). Real discovery in Claude Code or the app **not verified** |
| 6 | Complete a task with referenced lessons and an editable deliverable | the C runs in `../benchmark/` used the installed copies | **Actual model execution in Claude Code**, single turn, told which skill applied |
| 7 | Check citations, constraints, missing information, escalation | blind grading in `../benchmark/grades/` | Done for 6 cases; defects found and listed there |
| 8 | Update: lesson changes, admin keeps their own edit, members reinstall | script step 6: `pack-build` keeps the edit and writes `.new`, `pack-share` refuses until merged, version 1.0.1 shared and reinstalled with the same commands | **Verified locally** |
| 9 | The update reaches the member | files: the installed offer skill and its lesson say "never below 350"; model: `journey-update-tutor.md` answers "350" and carries the admin's own line; `journey-update-offer.md` prices inside 350-500 | **Verified locally + actual model execution** (Claude Code) |

`local-record.md` is the latest output of the script. Re-run it with:

```bash
python3 scripts/package_tools.py
python3 scripts/acceptance_journey.py --record skool-owner-kit/examples/agency-lab/acceptance-journey/local-record.md
```

## How the model runs were supplied and executed

Every model run here, in `../benchmark/` and in `../live-runs/`, was a Claude Code subagent (Claude Agent SDK) with
model alias `sonnet`, started fresh for one reply. It was given the path to an installed skill folder and told to read
`SKILL.md` in full, follow it, read only the reference files inside that folder, and reply to one member message in one
turn. The skill was **not** loaded by Claude Code's own skill system, and the subagent was told which skill applied.
Prompts are quoted verbatim in `../benchmark/README.md`.

Known harness limits:
- No skill discovery: step 5b is a simulation from names and descriptions.
- Single turn: a member can't answer the skill's questions.
- These subagents inherit the operator's Claude Code memory (two replies mention the operator's city, one their hourly
  rate). A clean member account wouldn't have this.
- Not the Claude app: upload, the switch to turn a skill on, and the app's code-execution environment are untested.

## Skill selection (simulated)

The same 8 messages, before and after the tutor's description was changed. Expectations written after v1 ran:
1 and 2 could reasonably load either of two skills; the rest have one right answer.

| # | Message | v1 | v2 |
|---|---|---|---|
| 1 | What should I charge my first client? | offer-builder | offer-builder |
| 2 | someone opened my loom but didn't reply... | outreach-sprint | outreach-sprint |
| 3 | physio clinics or car garages... put my offer together? | offer-builder | offer-builder |
| 4 | here's my offer... can you write my messages? | outreach-sprint | outreach-sprint |
| 5 | Do I need to register as a limited company? (not covered) | **none**: no coach question | tutor |
| 6 | birthday message for my sister | none | none |
| 7 | what's the 3 filter thing again? | tutor | tutor |
| 8 | which lesson covers the discovery call? | tutor | tutor |

v1 missed the case that matters most for support load: a question the lessons don't cover got no skill, so no
question for a coach. The tutor's description now says it handles "what the lessons don't cover"; v2 loaded it for #5
and still loaded nothing for #6.

## Still manual: the Claude app (needs a Claude account)

1. In a Claude account on the plan members use (Free, Pro, Max, Team or Enterprise), turn on **Settings > Capabilities
   > Code execution and file creation**.
2. Build the kit (`skool-kit pack-share member-pack -o share --version 1.0.0`) and follow `START-HERE.md` from the kit
   folder, exactly as written: upload the three zips, switch each skill on.
3. Upload succeeded for all three? If not, record the error message.
4. In a **new chat**, without naming a skill, send each message from the table above. Record which skill Claude used
   (its thinking or the tool line shows it).
5. Send the six acceptance inputs from `member-pack/ADMIN-REVIEW.md` in new chats, and answer the skill's questions
   once, as a member would.
6. Record each run in `member-pack/pilot/acceptance.csv`: date, plan, model shown, input, pass/fail, notes.
7. Update: rebuild with a changed lesson, delete and re-upload the skills, and re-run the pricing question.

Until that's done, the site says the Claude app is untested.
