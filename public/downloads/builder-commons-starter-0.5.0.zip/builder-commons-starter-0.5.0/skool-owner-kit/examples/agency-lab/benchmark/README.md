# Benchmark: general assistant vs lessons + instructions vs packaged skill

**Question:** is a packaged member skill worth paying for, compared with what a member can already do?
**Answer from this run:** not because its answers are better. A general assistant given the same lessons and clear
instructions did as well or better on following the lessons. The skill's advantages are elsewhere: members don't
have to find, attach and prompt the right lessons each time, every member gets the same deliverable structure and
rules, it made the fewest unsupported claims, and the admin can update one pack for everyone. A general assistant
*without* the lessons did badly on every case.

All runs: 2026-10-29, Claude Code subagents, model alias `sonnet` for every reply, a fresh session per reply.
Synthetic community, lessons and businesses. Outputs are in `runs/`, unedited.

## The three conditions (same model, same member message)

| | What the assistant got | Prompt |
|---|---|---|
| **A** General assistant | The member's message only; told not to read files or use tools | "You are Claude, a general-purpose AI assistant, chatting with a user..." + message |
| **B** Same assistant + lessons | The same lesson files the skill ships (8 for tutor questions, 3 for the offer, 2 for outreach), as attachments, plus a clear instruction from the member: *"Use their method and rules, say which lesson each part comes from, ask me if anything you need is missing, and tell me if something I ask goes against the lessons or if you're adding anything that isn't in them."* | as A, plus "The user has attached N lesson files... read every file" |
| **C** Packaged skill | The installed skill folder from the member kit (`pack-share` 1.0.0, unzipped as START-HERE.md says), told which skill was invoked | "The user has installed a Claude skill... read SKILL.md and follow it" |

C included the pack's example output; B did not, because a member wouldn't have it. That is part of what the pack
adds, and is noted as a difference.

## Cases

| Id | Kind | Member message (short) | Used while building the skills? |
|---|---|---|---|
| T1 | Tutor, covered | What should I charge my first client? (dental missed-call text-back) | Yes |
| T2 | Tutor, not covered | Do I need a limited company first? (Ireland) | Yes |
| T3 | Tutor, covered | someone opened my loom but didn't reply, how many times should i chase | **No (held out)** |
| O2 | Offer, conflicting input | Restaurants in Manchester, £150 a month, guarantee 20% more bookings | Yes |
| O3 | Offer, realistic | physio clinics or car garages around Bristol, Voiceflow booking chatbot | **No (held out)**; run twice per condition |
| R2 | Outreach, realistic | Bristol physio offer + 3 prospects, one with no observation | **No (held out)** |

## Scoring

Blind: each case's replies relabelled with shuffled letters and given to a fresh grader with the lessons and a rubric
fixed in advance ([RUBRIC.md](RUBRIC.md)). Raw grades and the letter mapping: `grades/`. The grader is a model, there
was one grader per case, and C's structure (Check, Gaps and assumptions) is recognisable, so blinding is partial.

## Results (blind grades, 7 replies per condition)

| | A General | B + lessons | C Skill |
|---|---|---|---|
| Lesson rules applied correctly (0-2, mean) | 0.00 | **2.00** | 1.43 |
| Delivers what was asked, or asks only for what's missing (0-2) | 1.14 | 1.86 | **2.00** |
| Clarification quality (0-2) | 0.43 | 1.71 | 1.71 |
| Usable with light edits (0-2) | 0.14 | 1.71 | **1.86** |
| Unsupported claims, total | 60 | 5 | **2** |
| Wrong citations, total | 0 (none given) | 0 | 1 |
| Conflicts with the lessons named, where present | 0 of 4 | 4 of 4 | 4 of 4 |
| Grader's preferred reply (6 cases) | 0 | **4** | 2 |
| Consistency, O3 run twice | both ignore the price floor and promise results | one strong draft, one with no draft | both the same structure and price, both with the same defect |

Per case, the grader preferred: T1 C, T2 B, T3 B, O2 B, R2 C, O3 B.

## Defects the grading found in the skill, and what happened

| Defect | Seen in | Fix | After the fix (actual runs, **not graded blind**) |
|---|---|---|---|
| Scored unknown niche filters as passes ("1, provisional") to reach 3/3 | O3 C, both runs | Rule: unknown filters score "?"; a "?" niche is not 3/3 | `O3-C-fixed`, `O3-C-fixed-repeat`: no false pass, but no draft either (graded blind: usable 1) |
| ...then gave no draft at all | O3 after fix 1 | Rule: if only "?" filters are missing, draft with [brackets] and mark the check pending | `O3-C-round2`: draft with brackets, niche check marked fail/pending, filters to confirm listed |
| Didn't say restaurants fail the niche test (the lesson names them) | O2 C | Generator: read the lessons for what the member gave *before* asking for missing inputs | `O2-C-round2` (rule only): still missed; `O2-C-round3` (generator change): names all three conflicts with citations |
| Draft said "tag a coach" immediately; the lesson says only if nobody answers within a day | T2 C | `support_channel` wording | `T2-C-round2`: "tag a coach if nobody answers within a day" |
| A citation credited the wrong lesson (1 of 21) | T1 C | none yet | open |
| Classroom link `example.com/...` judged invented | T1, T2 C | none needed: it's the synthetic pack's placeholder `classroom_url`; a real pack uses the admin's link | n/a |

One run after each fix is not evidence that the fix holds. Re-run the six acceptance cases before relying on it.

## Effort: what it takes to get these answers

Counted from the guides and this benchmark's inputs; minutes are estimates, not timings.

| | A General | B + lessons | C Skill |
|---|---|---|---|
| Member, first time | nothing | find the right lesson files for the task (2-8 here), attach them, write the instruction | install 3 zips, about 5 minutes (START-HERE.md, 4 steps) |
| Member, each later task | type the request | attach the right lessons again and repeat the instruction, or set up a Claude Project once with all lessons and instructions | paste the starter message (or ask normally: the skill is chosen from its description) |
| Admin, first time | nothing | export lesson text, write and share a recommended instruction (estimate: 1-2 hours) | pack spec, review, acceptance runs (estimate: 6.5-11.5 hours, see EFFORT.md) |
| Admin, when a lesson changes | nothing | re-share the files; members re-attach them | rebuild, re-run acceptance, share a new version; members replace 3 skills |
| Rules members see | none | whatever the member's instruction says | the same rules, structure and checks for every member, set by the admin |

## What this means for the offer

- Don't claim better answers than "Claude with your lessons". This benchmark doesn't support it.
- The pitch that holds up: members get lesson-grounded results without assembling lessons and prompts themselves,
  every member gets the same rules and deliverable shape, the skill made the fewest unsupported claims, and the admin
  can update one pack.
- The weakest point is admin effort. B could be offered as a cheaper alternative: a shared Claude Project with the
  lessons and a recommended instruction.

## Limits

- 6 cases, one synthetic community, one model alias, one grader per case. Small and not representative.
- Harness leak: these subagents inherit the operator's Claude Code memory. A-T3 and B-T1 mention "Tokyo" and A-O2
  "£30/hr", none of which the member said. It affected A and B replies; the grader penalised them as invented facts.
  Runs in a clean account would remove it.
- Single turn only. Real members reply to questions; multi-turn use wasn't tested.
- Skill choice was simulated separately (see `../acceptance-journey/`); here each C run was told which skill applied.
- Claude Code, not the Claude app.
