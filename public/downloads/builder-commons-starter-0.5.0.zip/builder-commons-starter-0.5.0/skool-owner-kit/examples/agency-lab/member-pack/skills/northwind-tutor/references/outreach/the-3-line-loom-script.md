# The 3-line Loom script

Module: Outreach  
Source file: 03-outreach/01-the-3-line-loom-script.md  
Classroom: https://example.com/northwind-agency-lab/classroom  

Your first message is three lines, under 90 words, with a 60-second Loom video link.

1. **Observation:** one specific thing you noticed about *their* business. From their website, Google reviews
   or opening hours. ("Three of your last ten reviews mention calls going to voicemail.")
2. **Cost:** what that costs them, in their terms. ("Each missed call is a patient who books somewhere else.")
3. **Ask:** a small, easy yes. ("I recorded a 60-second video showing how I'd fix it. Worth a look?")

## Rules

- Never start with "I" or your company name. Start with them.
- No attachments, no prices, no links except the Loom.
- If you can't find a real observation, skip that business. Generic messages burn your list.
- Track every message (see "The follow-up cadence").
