# The discovery call

Module: Outreach  
Source file: 03-outreach/03-the-discovery-call.md  
Classroom: https://example.com/northwind-agency-lab/classroom  

Twenty minutes. You ask, they talk. Five questions:

1. "Walk me through what happens when a new enquiry comes in."
2. "What happens when nobody picks up?"
3. "Roughly how many of those do you think you lose a month?"
4. "What's one new client worth to you?"
5. "If we fixed that, what would it change for you?"

Then propose the 30-day pilot from your offer page. Don't send a proposal unless they ask for one.
