# The follow-up cadence

Module: Outreach  
Source file: 03-outreach/02-the-follow-up-cadence.md  
Classroom: https://example.com/northwind-agency-lab/classroom  

Most replies come from follow-ups. Send exactly two.

| Day | Message |
|---|---|
| 0 | The 3-line Loom message |
| 3 | Follow-up 1: one new angle (a different observation or a short result from another niche), same ask |
| 7 | Follow-up 2: a polite close ("Should I close your file?"). This one gets the most replies |

Then stop. Never send a third follow-up.

## Track it

Keep one sheet with these columns: Business, Contact, Observation, Day 0 sent, Day 3 sent, Day 7 sent, Reply, Call booked.
Count your outreach as "sent" only when the Day 0 message went out.
