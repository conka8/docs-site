# Your first 14 days

Module: Start here  
Source file: 01-start-here/01-your-first-14-days.md  
Classroom: https://example.com/northwind-agency-lab/classroom  

Welcome to Northwind Agency Lab. Most members who stay with us long enough to land a client did two things in
their first two weeks. That is your target too. We call it your **First win**:

1. **Post your one-page offer** in the Wins channel.
2. **Send 20 outreach messages** to real businesses in your niche.

That's it. You don't need a website, a logo or a finished automation to start. You need an offer and conversations.

## Your plan

- Day 1: Watch this lesson and "Pick a niche with the 3-filter test".
- Day 2-3: Write your one-page offer ("The one-outcome offer" and "Pricing your first offer"). Post it in Wins.
- Day 4-10: Send 20 messages with "The 3-line Loom script". Follow up with "The follow-up cadence".
- Day 11-14: Run your first calls with "The discovery call".

When you hit your First win, post in Wins with **#firstwin** and a link to your offer.

## Where to get help

Ask in the Help channel. Tag a coach if nobody answers within a day.
