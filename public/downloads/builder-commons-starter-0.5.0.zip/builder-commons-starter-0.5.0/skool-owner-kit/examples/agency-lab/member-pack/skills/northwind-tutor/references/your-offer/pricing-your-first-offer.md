# Pricing your first offer

Module: Your offer  
Source file: 02-your-offer/03-pricing-your-first-offer.md  
Classroom: https://example.com/northwind-agency-lab/classroom  

Price every offer as **setup fee + monthly fee**. Never only one-off: the monthly fee is your business.

## Our pricing ladder for first clients

| Client | Setup fee | Monthly fee |
|---|---|---|
| Clients 1-3 ("founding clients") | 500 to 1,000 | 300 to 500 |
| Clients 4-10 | 1,000 to 2,500 | 500 to 900 |

Amounts are in your local currency. Use the higher end when one recovered lead is worth a lot to the client
(a dental implant, a roof, a legal case).

## Rules

- Never go below 300 a month. Below that, support eats your time.
- Founding clients get the lower price in exchange for a testimonial and a 30-day pilot with an agreed metric.
- No refunds promised on results you don't control. Offer the pilot instead.
- Write the price on the offer page. "Contact us for pricing" kills first conversations.
