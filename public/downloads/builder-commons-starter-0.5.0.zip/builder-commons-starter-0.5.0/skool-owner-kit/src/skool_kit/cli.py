"""Command line interface for skool-owner-kit."""
from __future__ import annotations

import argparse
import os
import sys
from datetime import datetime, timezone
from pathlib import Path

from . import __version__
from .dates import parse_date
from .members import MappingError, import_members

EXIT_OK, EXIT_FAIL, EXIT_USAGE = 0, 1, 2


def _common_import(p: argparse.ArgumentParser):
    p.add_argument("--map", action="append", default=[], metavar="COLUMN=FIELD",
                   help='column override, repeatable, e.g. --map "What do you want?=answers"')
    p.add_argument("--dayfirst", action="store_true", help="dates are day/month/year (default month/day/year)")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="skool-kit",
        description="Tools for Skool community owners, using your own CSV exports and webhooks (no scraping).")
    parser.add_argument("--version", action="version", version=f"skool-kit {__version__}")
    sub = parser.add_subparsers(dest="command", metavar="COMMAND")

    p = sub.add_parser("inspect", help="show how a CSV export is read (columns, skipped rows)")
    p.add_argument("csv")
    _common_import(p)

    p = sub.add_parser("onboard", help="write a personalised first-week message for each new member")
    p.add_argument("csv", help="member export (CSV)")
    p.add_argument("--since", help="only members who joined on/after this date")
    p.add_argument("-o", "--output", help="messages.csv, messages.md or messages.jsonl (default: print)")
    p.add_argument("--format", choices=("csv", "md", "jsonl"))
    p.add_argument("--rules", help="rules YAML (default: built-in AI-community rules; see `skool-kit rules`)")
    p.add_argument("--community-name", help="used in {community_name}")
    p.add_argument("--llm", choices=("anthropic", "openai"), help="personalise with an LLM (falls back to templates)")
    p.add_argument("--model", help="LLM model name")
    _common_import(p)

    p = sub.add_parser("webhook", help="receive Zapier new-member POSTs and write welcome messages")
    p.add_argument("--host", default="127.0.0.1", help="use 0.0.0.0 to accept outside connections")
    p.add_argument("--port", type=int, default=8787)
    p.add_argument("--secret", default=None, help="shared secret (or env SKOOL_KIT_SECRET)")
    p.add_argument("--secret-header", default="X-Skool-Kit-Secret")
    p.add_argument("--outbox", default="outbox.jsonl", help="append each message here (JSON lines)")
    p.add_argument("--forward-url", default="", help="POST each message here, e.g. a Zapier catch hook")
    p.add_argument("--rules")
    p.add_argument("--community-name")
    p.add_argument("--llm", choices=("anthropic", "openai"))
    p.add_argument("--model")
    p.add_argument("--map", action="append", default=[], metavar="FIELD_NAME=FIELD")

    p = sub.add_parser("health", help="inactivity-risk scores, KPIs and an HTML dashboard")
    p.add_argument("csv", help="member export (CSV)")
    p.add_argument("--activity", help="activity history CSV (one row per member per snapshot date)")
    p.add_argument("-o", "--output", default="dashboard.html", help="dashboard.html, or .json / .csv for the at-risk list")
    p.add_argument("--at-risk", help="also write the at-risk list here (.csv or .json)")
    p.add_argument("--as-of", help="date to measure from (default: today)")
    p.add_argument("--threshold", type=int, default=35, help="risk score that counts as at-risk (default 35)")
    p.add_argument("--community-name", default="")
    p.add_argument("--brand-color", default="", help="hex color for charts, e.g. #0a7cff")
    p.add_argument("--currency-symbol", default="$")
    _common_import(p)

    p = sub.add_parser("classroom-to-skill", help="turn classroom lessons into a Claude/OpenClaw tutor skill")
    p.add_argument("lessons_dir")
    p.add_argument("--name", required=True, help="skill name: lowercase, digits, hyphens (e.g. my-community-tutor)")
    p.add_argument("-o", "--output", default=".", help="folder to create the skill folder in")
    p.add_argument("--community-name", default="")
    p.add_argument("--classroom-url", default="")
    p.add_argument("--max-chars", type=int, default=12000, help="split lessons longer than this")
    p.add_argument("--force", action="store_true", help="replace an existing skill folder")

    p = sub.add_parser("pack-build", help="build a member pack (tutor, task skills, checks, guides, pilot) from pack.yaml")
    p.add_argument("spec", help="pack spec, e.g. pack.yaml")
    p.add_argument("-o", "--output", default="member-pack", help="folder to write the pack into")
    p.add_argument("--list-lessons", action="store_true", help="only list the lesson titles you can reference")
    p.add_argument("--max-chars", type=int, default=12000, help="split lessons longer than this")
    p.add_argument("--force", action="store_true", help="overwrite files you edited since the last build")

    p = sub.add_parser("pack-share", help="zip a reviewed member pack into the kit members receive")
    p.add_argument("pack", help="the folder pack-build wrote, e.g. member-pack")
    p.add_argument("-o", "--output", default="share", help="folder to write the kit into (outside the pack)")
    p.add_argument("--version", required=True, help="version members will see, e.g. 1.0.0")

    p = sub.add_parser("pilot", help="report on a member-pack pilot from its logs (events, questions, costs)")
    p.add_argument("plan", help="pilot plan, e.g. member-pack/pilot/pilot.yaml")
    p.add_argument("--format", choices=("text", "md", "json"), default="text")
    p.add_argument("-o", "--output")

    p = sub.add_parser("rules", help="print or save the default onboarding rules to edit")
    p.add_argument("-o", "--output")
    return parser


def _write(text: str, output: str | None, out) -> None:
    if output:
        Path(output).parent.mkdir(parents=True, exist_ok=True)
        Path(output).write_text(text, encoding="utf-8")
        print(f"Wrote {output}", file=out)
    else:
        out.write(text)


def _report_import(res, out, err) -> None:
    print(f"Read {len(res.members)} member(s) from {res.total_rows} row(s).", file=out)
    for s in res.skipped:
        print(f"  skipped row {s.row}: {s.reason}", file=err)
    for w in res.warnings[:20]:
        print(f"  warning: {w}", file=err)
    if len(res.warnings) > 20:
        print(f"  ... and {len(res.warnings) - 20} more warnings", file=err)


def _rules(args):
    from .rules import load_rules
    rules = load_rules(args.rules)
    if getattr(args, "community_name", None):
        rules["community_name"] = args.community_name
    return rules


def _llm(args, env):
    if not args.llm:
        return None
    from .llm import LLMClient
    return LLMClient(args.llm, model=args.model, env=env)


def _as_of(text: str | None) -> datetime:
    if not text:
        return datetime.now(timezone.utc).replace(tzinfo=None)
    dt = parse_date(text)
    if dt is None:
        raise ValueError(f"--as-of: can't read date {text!r}; use YYYY-MM-DD")
    return dt


def cmd_inspect(args, out, err, env) -> int:
    res = import_members(args.csv, args.map, args.dayfirst)
    names = {",": "comma", ";": "semicolon", "\t": "tab", "|": "pipe"}
    print(f"Delimiter: {names.get(res.delimiter, res.delimiter)}", file=out)
    print("Columns used:", file=out)
    for fld, cols in res.mapping.items():
        print(f"  {fld:<13} <- {', '.join(cols)}", file=out)
    if res.unmapped:
        print(f"Columns ignored: {', '.join(res.unmapped)}", file=out)
    _report_import(res, out, err)
    paid = sum(1 for m in res.members if m.is_paid)
    print(f"Paying members: {paid}. With join answers: {sum(1 for m in res.members if m.answers)}.", file=out)
    return EXIT_OK


def cmd_onboard(args, out, err, env) -> int:
    from . import onboard
    rules = _rules(args)
    llm = _llm(args, env)
    res = import_members(args.csv, args.map, args.dayfirst)
    since = None
    if args.since:
        since = parse_date(args.since, dayfirst=args.dayfirst)
        if since is None:
            raise ValueError(f"--since: can't read date {args.since!r}; use YYYY-MM-DD")
    members, skipped = onboard.select_new(res.members, since)
    msgs = [onboard.build_message(m, rules, llm) for m in members]
    fmt = args.format
    if not fmt and args.output:
        fmt = {".csv": "csv", ".md": "md", ".markdown": "md", ".jsonl": "jsonl", ".json": "jsonl"}.get(
            Path(args.output).suffix.lower())
    fmt = fmt or "md"
    text = {"csv": onboard.render_csv, "md": onboard.render_markdown, "jsonl": onboard.render_jsonl}[fmt](msgs)
    _write(text, args.output, out)
    target = out if args.output else err
    _report_import(res, target, err)
    for row, reason in skipped:
        print(f"  skipped row {row}: {reason}", file=err)
    failed = [m for m in msgs if m.llm_error]
    if failed:
        print(f"  LLM failed for {len(failed)} message(s), used the template instead: {failed[0].llm_error}", file=err)
    print(f"{len(msgs)} onboarding message(s)" + (f" for members who joined since {since:%Y-%m-%d}" if since else "")
          + ".", file=target)
    return EXIT_OK


def cmd_webhook(args, out, err, env) -> int:
    from .members import parse_overrides
    from .webhook import WebhookConfig, make_server
    secret = args.secret or env.get("SKOOL_KIT_SECRET", "")
    if not secret:
        raise ValueError("a shared secret is required: --secret YOUR-SECRET or env SKOOL_KIT_SECRET")
    config = WebhookConfig(secret=secret, outbox=Path(args.outbox) if args.outbox else None,
                           forward_url=args.forward_url, secret_header=args.secret_header,
                           field_map=parse_overrides(args.map), rules=_rules(args), llm=_llm(args, env),
                           log=lambda line: print(line, file=out, flush=True))
    server = make_server(config, args.host, args.port)
    host, port = server.server_address[:2]
    print(f"Listening on http://{host}:{port}/  (POST JSON with header {args.secret_header}: <secret> "
          f"or ?secret=...). Ctrl+C to stop.", file=out, flush=True)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()
    return EXIT_OK


def cmd_health(args, out, err, env) -> int:
    from . import health
    from .dashboard import render_dashboard
    as_of = _as_of(args.as_of)
    res = import_members(args.csv, args.map, args.dayfirst, today=as_of)
    _report_import(res, out, err)
    activity = []
    if args.activity:
        act = import_members(args.activity, args.map, args.dayfirst, today=as_of, allow_duplicates=True)
        if "snapshot_date" not in act.mapping:
            print("  warning: activity file has no date column, so trends can't be computed", file=err)
        activity = act.members
        print(f"Read {len(activity)} activity row(s).", file=out)
    healths = health.score_all(res.members, as_of, activity)
    risky = health.at_risk(healths, args.threshold)
    kpis = health.compute_kpis(healths, as_of, args.threshold)

    def write_list(path: str):
        if path.lower().endswith(".json"):
            _write(health.health_json(kpis, risky), path, out)
        else:
            _write(health.at_risk_csv(risky), path, out)

    if args.output.lower().endswith((".json", ".csv")):
        write_list(args.output)
    else:
        _write(render_dashboard(kpis, healths, risky, args.community_name, args.brand_color, args.currency_symbol),
               args.output, out)
    if args.at_risk:
        write_list(args.at_risk)
    print(f"{kpis.total_members} members, {kpis.active_30d_pct if kpis.active_30d_pct is not None else 'n/a'}% "
          f"active in 30 days, {len(risky)} at risk ({kpis.at_risk_paying} paying).", file=out)
    return EXIT_OK


def cmd_classroom(args, out, err, env) -> int:
    from .classroom import build_skill
    info = build_skill(args.lessons_dir, args.name, args.output, args.community_name, args.classroom_url,
                       args.max_chars, args.force)
    for w in info["warnings"]:
        print(f"  warning: {w}", file=err)
    print(f"Created {info['skill_dir']}: {info['lessons']} lessons in {info['modules']} modules, "
          f"{info['files']} reference files.", file=out)
    if info["split_lessons"]:
        print(f"Split long lessons into parts: {', '.join(info['split_lessons'])}", file=out)
    print(f"Install: copy the folder to ~/.claude/skills/ (Claude Code) or your OpenClaw skills folder.", file=out)
    return EXIT_OK


def cmd_pack_build(args, out, err, env) -> int:
    from .memberpack import build_pack, list_lessons
    if args.list_lessons:
        for line in list_lessons(args.spec):
            print(line, file=out)
        return EXIT_OK
    res = build_pack(args.spec, args.output, force=args.force, max_chars=args.max_chars)
    for w in res.warnings:
        print(f"  warning: {w}", file=err)
    print(f"Built {res.out}: {len(res.skills)} skills ({', '.join(res.skills)}).", file=out)
    print(f"  {len(res.written)} file(s) written, {len(res.unchanged)} unchanged.", file=out)
    if res.kept:
        print(f"  Kept your edits in {len(res.kept)} file(s); the new version is next to each as <file>.new:", file=out)
        for rel in res.kept:
            print(f"    {rel}", file=out)
    print(f"Next: read {Path(res.out) / 'ADMIN-REVIEW.md'}", file=out)
    return EXIT_OK


def cmd_pack_share(args, out, err, env) -> int:
    from .share import share_pack
    res = share_pack(args.pack, args.output, args.version)
    print(f"Shared {len(res.skills)} skills ({', '.join(res.skills)}).", file=out)
    print(f"  Send every member: {res.kit_zip} (or the files in {res.folder})", file=out)
    print(f"  Edit and post: {res.launch_post}", file=out)
    print(f"  Keep to yourself: {args.pack} (your source, acceptance cases and pilot logs)", file=out)
    return EXIT_OK


def cmd_pilot(args, out, err, env) -> int:
    from .pilot import render, run
    report = run(args.plan)
    for w in report.warnings:
        print(f"  warning: {w}", file=err)
    _write(render(report, args.format), args.output, out)
    return EXIT_OK


def cmd_rules(args, out, err, env) -> int:
    from .rules import dump_rules
    _write(dump_rules(), args.output, out)
    return EXIT_OK


def main(argv=None, env=None, out=None, err=None) -> int:
    out = out or sys.stdout
    err = err or sys.stderr
    env = os.environ if env is None else env
    parser = build_parser()
    try:
        args = parser.parse_args(argv)
    except SystemExit as exc:
        return int(exc.code or 0)
    if not args.command:
        parser.print_help(out)
        return EXIT_USAGE
    handlers = {"inspect": cmd_inspect, "onboard": cmd_onboard, "webhook": cmd_webhook, "health": cmd_health,
                "classroom-to-skill": cmd_classroom, "rules": cmd_rules, "pack-build": cmd_pack_build,
                "pack-share": cmd_pack_share, "pilot": cmd_pilot}
    from .classroom import SkillError
    from .llm import LLMError
    from .pilot import PilotError
    from .rules import RulesError
    try:
        return handlers[args.command](args, out, err, env)
    except (MappingError, RulesError, SkillError, PilotError, LLMError, ValueError, FileNotFoundError) as exc:
        print(f"Error: {exc}", file=err)
        return EXIT_USAGE
    except OSError as exc:
        print(f"Error: {exc}", file=err)
        return EXIT_FAIL
