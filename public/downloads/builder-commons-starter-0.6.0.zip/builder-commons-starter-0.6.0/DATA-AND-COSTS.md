# Data handling and API costs

The tools run on your own computer. Nothing is sent to the people who made them: there is no account, no
telemetry, no hosted service. Data only leaves your computer when you point a tool at an outside service with
your own key or URL.

## Per tool

| Tool | Reads | Sends | Writes | Can cost money |
|---|---|---|---|---|
| skillport | Workflow JSON files you exported | Nothing (bridge skills: your data goes to *your* n8n webhook when a member runs them) | Skill folders. Removes keys, account IDs and pinned test data from the copy of the workflow it includes | No |
| skillkit | Your skill folders and test cases | `eval` only: each skill's instructions and test inputs to the AI provider you choose | Reports, packages | `eval` with a real provider: one API call per case, plus one per `llm_rubric` check |
| skool-owner-kit | Member CSV exports, lesson files, Zapier events | `--llm`: one member's name and join answers per message to the AI provider you choose. `webhook --forward-url`: the message to your next Zap | Messages, dashboard, `outbox.jsonl` (names, emails, answers: delete when done), tutor skill | `--llm` only: one call per member |
| shipsafe | Your app's folder | URL mode: ordinary GET requests to a site **you own** | Reports (key-like values are masked) | No |
| geo-audit | Your questions file | Each question to every AI provider you pick | Reports | Yes: questions × providers calls per run (the demo provider is free) |
| ghl-agency-kit | GoHighLevel data through your token | Requests to GoHighLevel. `onboard` without `--dry-run` creates fields, tags, pipelines in the sub-account | Reports, snapshots (no token in them) | No (uses your GHL plan) |
| voice-qa | Your agent prompt and test packs | Test conversations to your agent's webhook; with an AI caller, conversations to that provider | Scorecards, JSON, JUnit | AI caller: several calls per conversation |
| career-labs | Lab files | Nothing | Grades | No |
| vertical-packs | Your inputs | Nothing | Results | No |

## Keys

- Keys are read from environment variables (`ANTHROPIC_API_KEY`, `OPENAI_API_KEY`, `PERPLEXITY_API_KEY`,
  `GEMINI_API_KEY`, `GHL_TOKEN`, ...). Prefer them over command-line options such as `--token` or `--secret`, which
  end up in your shell history.
- Reports never include your keys. Secret detection in skillport, skillkit and shipsafe is pattern-based: look
  over anything before you publish it.
- If a key ever lands in a file you shared, rotate it at the provider. Deleting the file is not enough.

## Keeping costs down

- Try every tool in demo mode first (`--provider fake`, `--providers fake`, `--fake-api demo`, `--agent scripted`).
- Start with a few cases or questions, then grow.
- Set provider-side spending limits on the keys you use for these tools.
- Prices change; check your provider's pricing page rather than any number in these docs.

## Members' personal data

Member exports, join answers and Zapier events are personal data. Keep them on your own machine, don't paste them
into chats or public posts, and delete working files (`outbox.jsonl`, `at_risk.csv`, `messages.csv`) when you no
longer need them. If you send member data to an AI provider (`--llm`), that provider's data terms apply.
