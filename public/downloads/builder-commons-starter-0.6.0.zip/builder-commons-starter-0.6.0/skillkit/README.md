# skillkit

Free tools for communities that sell libraries of Claude / OpenClaw skills (`SKILL.md` folders).
Check every skill for mistakes, test skills on sample inputs so you notice when a model update
breaks them, and package the whole library as one installable Claude Code plugin.

**Why:** your library *is* your product. A skill with a broken link, a leaked API key or a name
Claude refuses to load is a support ticket, and a recipe that quietly stops working after a model
update is a cancellation. `skillkit` catches both before your members do.

## Install

You need Python 3.10 or newer. In a terminal, inside this folder:

```
pip install .
```

Check it worked:

```
skillkit --version
```

## Try it on the samples first

`examples/skills/` is a two-skill library and `examples/cases.yaml` has test cases for it. Nothing here needs an API key:

```
skillkit lint examples/skills
skillkit eval examples/skills --cases examples/cases.yaml
skillkit pack examples/skills -o dist --name demo-skills --author "Your Community" --marketplace
```

You should see `Checked 2 skills: 0 errors, 0 warnings`, then `2 of 2 cases passed` under a **DEMO DATA** line
(the sample cases use canned answers, so this shows how a report looks, not whether the skills work), then
`Packed 2 skill(s)`.

## Quickstart with your own library

```
# 1. Check a whole library (a folder that contains one folder per skill)
skillkit lint my-skills

# 2. Let skillkit fix the safe things for you (names, trailing spaces, missing header)
skillkit lint my-skills --fix

# 3. Create a new skill that already passes the checks
skillkit new cold-email --dir my-skills --description "Writes a short cold email. Use when the user wants outreach emails."

# 4. Test the instructions against a real model (needs ANTHROPIC_API_KEY; costs a few API calls per case)
skillkit eval my-skills --cases cases.yaml --provider anthropic --format html -o eval.html

# 5a. Members on Claude Code: package everything as one plugin + marketplace
skillkit pack my-skills -o dist --name my-skills --version 1.0.0 --author "Your Community" --marketplace --zip

# 5b. Members on the Claude app (claude.ai / desktop): one upload zip per skill
skillkit pack my-skills -o dist --name my-skills --version 1.0.0 --author "Your Community" --format claude-app
```

## What each command does

### `skillkit lint PATH`
`PATH` is one skill folder or a folder of skills. Every problem shows the file, the line, a rule id
and a plain-English fix. **Errors** must be fixed; **warnings** are suggestions.

| Rule | Level | What it means |
|---|---|---|
| `missing-skill-md` | error | The folder has no `SKILL.md` |
| `frontmatter-missing` / `frontmatter-invalid` | error | No `---` header at the top, or the header is broken YAML |
| `name-missing`, `name-format`, `name-too-long` | error | Name must be lowercase letters, digits and hyphens, max 64 characters |
| `name-reserved` | error | Name contains "anthropic" or "claude" |
| `name-folder-mismatch` | warning | Name is different from the folder name |
| `description-missing`, `description-empty`, `description-too-long` | error | Description is required, max 1024 characters |
| `description-xml` | error | Description contains tags like `<b>` |
| `description-no-when` | warning | Description does not say *when* to use the skill ("Use when ...") |
| `description-todo` | warning | Description is still the TODO placeholder |
| `body-too-long` | warning | Instructions longer than 500 lines (move detail into `references/`) |
| `broken-link` | error | A link or a `scripts/...`, `references/...`, `assets/...` file mentioned does not exist |
| `absolute-path` | warning | A path like `/Users/you/...` or `C:\...` that only works on one computer |
| `secret` | error | Something that looks like an API key, token or private key (any file in the skill) |
| `script-no-shebang`, `script-not-executable` | warning | A referenced script lacks `#!` or the executable bit |
| `duplicate-name` | error | Two skills in the library use the same name |
| `frontmatter-upload-key` | warning | A frontmatter key other than `name`, `description`, `license`, `compatibility`, `metadata`, `allowed-tools`. Claude Code accepts it, but uploads to the Claude app or API reject it |
| `needs-review` | warning | A skill converted by skillport still has its "Conversion check" marker. Review the list, then delete the `<!-- skillport: needs-review -->` line |

Options: `--format text|json|github` (`github` prints GitHub Actions annotations so problems show
up on pull requests), `--fix`, `--strict` (warnings count as errors). Exit code 1 if there are errors.

`--fix` only does safe things: sets `name` to the folder name (slugified), trims trailing spaces,
adds a missing frontmatter header or a TODO description. It never touches broken YAML.

Example output:

```
my-skills/claude-helper/SKILL.md:2: error [name-reserved] Name "claude-helper" contains the reserved word "claude". Pick another name.
my-skills/blog/SKILL.md:8: error [broken-link] "references/guide.md" is referenced but does not exist in the skill folder.
my-skills/blog/SKILL.md:3: warning [description-no-when] The description should say when to use the skill (e.g. "Use when ...").

Checked 12 skills: 2 errors, 1 warning.
Errors must be fixed before you publish. Warnings are suggestions.
```

### `skillkit eval PATH --cases cases.yaml`
Runs each test case: the skill's `SKILL.md` instructions go in as the system prompt, the case
`input` as the user message, and the answer is checked against your assertions.

**What this does and doesn't test.** It is an *instruction-only* test: one message per case, no tools, no
scripts, no `references/` files, and Claude doesn't have to pick the skill by itself. It catches instructions that
stop producing the right shape of answer (after a model update, say). It does not prove the skill works end to end
inside Claude Code or the Claude app; try those by hand. Every report says this at the top, lists the files each
skill points to that were not sent, and `--format json` has `"mode": "instruction-only"`.

**Three kinds of check, kept apart:**

| Check | Command | Needs |
|---|---|---|
| Structure (names, links, secrets, upload rules) | `skillkit lint` | Nothing |
| Answers to sample inputs | `skillkit eval --provider anthropic` or `openai` | An API key; a few calls per case |
| Running inside Claude Code / the Claude app | By hand: install the skill and ask Claude | A Claude account |

`--provider fake` returns the `fake_response` from each case and passes every `llm_rubric` unless the case sets
`fake_judge`. Use it to try the command and the report layout. Its reports start with **DEMO DATA** and
`"demo": true`; never show them as evidence that a skill works.

```yaml
provider: fake            # anthropic | openai | fake (can be overridden with --provider)
cases:
  - skill: summarize-email
    id: three-bullets
    input: "Hi team, the launch moves to Friday ..."
    fake_response: "Summary: launch moves to Friday"   # only used by --provider fake
    assert:
      - contains: "Summary:"          # case-insensitive; a list means "all of these"
      - not_contains: "As an AI"
      - regex: "^Summary:"
      - max_chars: 400
      - llm_rubric: "Has three bullet points and a reply."   # graded by the same AI
  - skill: linkedin-post
    id: json-post
    input: "Notes: we hit 1000 members. Return JSON."
    assert:
      - json_valid: true             # a ```json fenced block is accepted
      - json_has_keys: [hook, body, cta]
```

(You can also group cases as `skills: {summarize-email: {cases: [...]}}`.)

- `--provider anthropic` needs `ANTHROPIC_API_KEY` (default model `claude-sonnet-5-5`).
- `--provider openai` needs `OPENAI_API_KEY` (default model `gpt-4o-mini`); set `OPENAI_BASE_URL`
  to use any OpenAI-compatible service.
- `--model`, `--max-tokens`, `--timeout` to tune.
- `--format text|json|html` and `-o FILE` to save the report. The HTML report is one file you can
  open in a browser and print to PDF.
- **After a model update:** save a report once with `--format json -o baseline.json`, then run later
  with `--baseline baseline.json`. Any case that passed before and fails now is listed as a
  **regression** and the command exits with code 1.

Example output:

```
[FAIL] summarize-email / three-bullets  (812 ms)
       - contains 'Summary:' failed: missing: ['Summary:']
[PASS] linkedin-post / json-post  (640 ms)

1 of 2 cases passed, 1 failed.
REGRESSIONS (1): these passed in the baseline and fail now:
  - summarize-email::three-bullets
```

### `skillkit pack LIBRARY -o OUT --name NAME --version X --author "..."`
Builds a Claude Code plugin:

```
OUT/NAME/.claude-plugin/plugin.json      {name, version, description, author: {name}}
OUT/NAME/skills/<skill>/...              every skill folder, copied
OUT/.claude-plugin/marketplace.json      with --marketplace
OUT/NAME-X.zip                           with --zip
```

Members can then add the marketplace in Claude Code and install the plugin. `pack` runs `lint`
first and refuses to package a library with errors (use `--force` to override).

Members then run, in Claude Code (after you push `dist/` to a GitHub repo):

```
/plugin marketplace add your-org/your-repo
/plugin install my-skills@my-skills-marketplace
```

To ship an update, raise `--version`, pack again and push. Members open `/plugin marketplace update`, pick your
marketplace and choose "Update marketplace", which refreshes the listing and updates the plugins they installed
from it. (A plain refresh from the shell, `claude plugin marketplace update`, only refreshes the listing.)
Commands from https://code.claude.com/docs/en/discover-plugins and https://code.claude.com/docs/en/plugins/install,
checked 2026-10-29.

`--format claude-app` writes `OUT/NAME/<skill>.zip` (the skill folder at the root of each zip, which the Claude app
requires) and `OUT/NAME/INSTALL.md` with the upload steps: Customize > Skills > + > Create skill > Upload a skill,
with code execution turned on. Team and Enterprise owners can instead upload each zip once in Organization settings >
Plugins & skills, which makes it available to everyone in the organization.
Source: https://support.claude.com/en/articles/12512180-use-skills-in-claude, checked 2026-10-29.

`--format clawhub` instead writes `OUT/NAME/<skill>/...` (one flat folder per skill) plus
`OUT/NAME/index.json` listing each skill's name, description and version.
**Verify against current ClawHub requirements** before publishing there: this layout is a best guess.

### `skillkit new NAME`
Creates `NAME/SKILL.md` with valid frontmatter and a simple structure (When to use, Instructions,
Examples, Notes). Use `--dir` to choose where and `--description` to fill in the description.

## For community owners
- Put `skillkit lint skills --format github` in a GitHub Action so every change to your library
  is checked automatically.
- Run `skillkit eval` with your real provider after each model release and keep the HTML report
  as proof for members that the library still works.
- The `skills/skill-lint/` folder in this repo is a ready-made skill: copy it into your Claude Code
  skills folder and ask Claude "check my skills library".

## Limits
- The `description-no-when` check is a simple word check ("when" / "use this"); it can be fooled.
- Secret detection looks for common key formats (Anthropic, OpenAI, AWS, GitHub, Slack, private keys).
  It will not find every secret. Rotate any key it does find; deleting it from the file is not enough.
- File references are found from markdown links and from paths starting with `scripts/`,
  `references/`, `assets/`, `templates/` or `examples/`. Other mentions are not checked.
- `eval` sends one message per case (no tools, no multi-turn), so it tests the instructions, not
  the full Claude Code agent loop. AI answers vary between runs; use several cases per skill.
- `llm_rubric` uses the same provider as the judge, which costs one extra call per rubric.

## Verify against current docs
Third-party details live in one place: `src/skillkit/constants.py`. Check them against the
current vendor documentation before relying on them:
- Anthropic Messages API: `https://api.anthropic.com/v1/messages`, headers `x-api-key`,
  `anthropic-version: 2023-06-01`; request `model`, `max_tokens`, `system`, `messages`; answer in `content[].text`.
- OpenAI chat completions: `https://api.openai.com/v1/chat/completions`, `Authorization: Bearer`;
  answer in `choices[0].message.content`.
- Claude Code plugin layout (`.claude-plugin/plugin.json`, `skills/`) and `marketplace.json` fields.
- SKILL.md limits (name 64 characters, description 1024 characters, reserved words, 500-line body advice).
- ClawHub bundle format (`index.json`).

## Development

```
cd skillkit && ../.venv/bin/python -m pytest -q
```

MIT licensed.
