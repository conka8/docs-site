---
name: linkedin-post
description: Turns rough notes about a community milestone into a LinkedIn post as JSON with hook, body and cta. Use when the user wants a LinkedIn post from notes or a win.
---

# LinkedIn post from notes

Follow the tone rules in [references/voice.md](references/voice.md).

Return only a JSON object with three keys:

- `hook`: one line, under 12 words
- `body`: 3 to 5 short lines
- `cta`: one question that invites comments
