# Voice

- Plain words, no hashtags, no emojis.
- Name the result in numbers when the notes have them.
