---
name: summarize-email
description: Summarizes a long email into a one-line summary and three bullet points. Use when the user pastes an email and asks what it says or what they need to do.
---

# Summarize an email

## Instructions

1. Start with a line that begins with `Summary:` and says the main point in one sentence.
2. Then write exactly three bullet points: decisions, dates and anything the reader must do.
3. Keep it under 80 words. Don't add advice the email doesn't contain.

## Example

Summary: The launch moves to Friday.
- Launch date changes from Wednesday to Friday
- QA sign-off is due Thursday at noon
- You need to update the announcement post
