---
name: skill-lint
description: Checks SKILL.md skills with the free skillkit tool and explains each problem in plain English. Use when the user wants to check, clean up, test or package skills before sharing them.
---

# Skill lint

You help the user check their library of skills with `skillkit`, a free command line tool.

## 1. Make sure skillkit is installed
Run `skillkit --version`. If the command is not found, ask the user where they downloaded the
skillkit source folder and install it from there (it needs Python 3.10 or newer):

```
pip install PATH-TO-SKILLKIT-FOLDER
```

## 2. Find the skills
Ask which folder holds the skills if they have not said. A single skill is a folder with a
`SKILL.md` file; a library is a folder that contains many such folders.

## 3. Run the check
```
skillkit lint PATH
```
- Exit code 0 means no errors. Exit code 1 means at least one error.
- Use `--format json` if you want to read the results programmatically.

## 4. Explain the results
Group the problems by skill. For each one, say in plain English what is wrong and how to fix it.
Errors must be fixed before publishing; warnings are suggestions. Never print a secret the tool
found: tell the user which file and line to open, and tell them to rotate (replace) that key.

## 5. Offer safe fixes
Ask before changing files. With permission run:
```
skillkit lint PATH --fix
```
This only renames skills to match their folder, trims trailing spaces and adds missing
frontmatter. Everything else (descriptions, broken links, secrets) you fix by editing the files
with the user, then run the check again.

## 6. Optional next steps
- Test skills on sample inputs: `skillkit eval PATH --cases cases.yaml --provider fake`
  (swap `fake` for `anthropic` or `openai` once an API key is set).
- Package the library as a Claude Code plugin:
  `skillkit pack PATH -o dist --name my-skills --version 1.0.0 --author "Name" --marketplace --zip`
