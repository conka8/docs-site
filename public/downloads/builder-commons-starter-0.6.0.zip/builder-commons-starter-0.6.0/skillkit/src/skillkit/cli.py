"""Command line interface: skillkit lint | eval | pack | new."""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

from . import __version__
from .evaluate import CasesError, compare_to_baseline, load_baseline, load_cases, render_report, run_eval
from .lint import format_result, format_text, lint_path
from .pack import PackError, pack_claude_app, pack_clawhub, pack_plugin
from .providers import ProviderError, make_provider
from .scaffold import ScaffoldError, new_skill


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="skillkit",
        description="Check, test and package libraries of Claude / OpenClaw skills (SKILL.md folders).",
    )
    p.add_argument("--version", action="version", version=f"skillkit {__version__}")
    sub = p.add_subparsers(dest="command", metavar="COMMAND")

    lp = sub.add_parser("lint", help="check a skill folder or a folder of skills for problems")
    lp.add_argument("path", help="a skill folder (with SKILL.md) or a folder containing skill folders")
    lp.add_argument("--format", choices=["text", "json", "github"], default="text",
                    help="output format (github = GitHub Actions annotations)")
    lp.add_argument("--fix", action="store_true",
                    help="apply safe fixes: name = folder name, trim trailing spaces, add missing frontmatter")
    lp.add_argument("--strict", action="store_true", help="treat warnings as errors (exit 1)")

    ep = sub.add_parser("eval", help="run skills on sample inputs and check the answers")
    ep.add_argument("path", help="a skill folder or a folder of skills")
    ep.add_argument("--cases", required=True, help="YAML file with test cases")
    ep.add_argument("--provider", choices=["anthropic", "openai", "fake"],
                    help="which AI to call (default: 'provider' in the cases file, else anthropic)")
    ep.add_argument("--model", help="model name (default depends on the provider)")
    ep.add_argument("--format", choices=["text", "json", "html"], default="text", help="report format")
    ep.add_argument("-o", "--output", help="write the report to this file (a summary is still printed)")
    ep.add_argument("--baseline", help="earlier JSON report; flags cases that passed then and fail now")
    ep.add_argument("--include-references", action="store_true",
                    help="also send the text files each SKILL.md points to (references/, assets/, templates/)")
    ep.add_argument("--max-tokens", type=int, default=1024)
    ep.add_argument("--timeout", type=float, default=60.0, help="seconds to wait for each AI answer")

    pp = sub.add_parser("pack", help="package a folder of skills as a Claude Code plugin or ClawHub bundle")
    pp.add_argument("library", help="folder of skills (or a single skill folder)")
    pp.add_argument("-o", "--out", required=True, help="output folder")
    pp.add_argument("--name", required=True, help="plugin name, e.g. my-skills")
    pp.add_argument("--version", dest="pkg_version", default="1.0.0", help="version, e.g. 1.0.0")
    pp.add_argument("--author", required=True, help="author / community name")
    pp.add_argument("--description", help="one-line description of the package")
    pp.add_argument("--format", choices=["plugin", "claude-app", "clawhub"], default="plugin",
                    help="plugin = Claude Code plugin; claude-app = one .zip per skill to upload in the Claude app")
    pp.add_argument("--marketplace", action="store_true",
                    help="also write out/.claude-plugin/marketplace.json (plugin format only)")
    pp.add_argument("--marketplace-name", help="marketplace name (default: <name>-marketplace)")
    pp.add_argument("--zip", action="store_true", help="also create a .zip to share")
    pp.add_argument("--force", action="store_true", help="pack even if lint finds errors")

    np_ = sub.add_parser("new", help="create a new skill folder with a valid SKILL.md")
    np_.add_argument("name", help="skill name: lowercase letters, digits and hyphens")
    np_.add_argument("--dir", default=".", help="where to create it (default: current folder)")
    np_.add_argument("--description", help="what the skill does and when to use it")
    return p


def _err(msg: str) -> None:
    print(f"skillkit: error: {msg}", file=sys.stderr)


def cmd_lint(args) -> int:
    try:
        result = lint_path(args.path, fix=args.fix)
    except (FileNotFoundError, NotADirectoryError) as exc:
        _err(str(exc))
        return 2
    sys.stdout.write(format_result(result, args.format))
    if result.errors or (args.strict and result.warnings):
        return 1
    return 0


def cmd_eval(args, transport=None, environ=None) -> int:
    try:
        cases, settings = load_cases(args.cases)
        baseline = load_baseline(args.baseline) if args.baseline else None
        provider_name = args.provider or settings.get("provider") or "anthropic"
        provider = make_provider(provider_name, model=args.model or settings.get("model"), transport=transport,
                                 environ=environ, max_tokens=args.max_tokens, timeout=args.timeout)
        report = run_eval(args.path, cases, provider, include_references=args.include_references)
    except (CasesError, ProviderError, FileNotFoundError, NotADirectoryError) as exc:
        _err(str(exc))
        return 2
    if baseline is not None:
        compare_to_baseline(report, baseline)
    rendered = render_report(report, args.format)
    if args.output:
        Path(args.output).parent.mkdir(parents=True, exist_ok=True)
        Path(args.output).write_text(rendered, encoding="utf-8")
        sys.stdout.write(render_report(report, "text"))
        print(f"Report written to {args.output}")
    else:
        sys.stdout.write(rendered)
    if report["comparison"] is not None:
        return 1 if report["comparison"]["regressions"] else 0
    return 1 if report["summary"]["failed"] else 0


def cmd_pack(args) -> int:
    try:
        result = lint_path(args.library)
    except (FileNotFoundError, NotADirectoryError) as exc:
        _err(str(exc))
        return 2
    if result.errors:
        if not args.force:
            sys.stdout.write(format_text(result))
            _err(f"not packing: lint found {len(result.errors)} error(s). Fix them, or use --force.")
            return 1
        print(f"Warning: packing anyway (--force) despite {len(result.errors)} lint error(s).")
    try:
        if args.format == "claude-app":
            if args.marketplace or args.zip:
                print("Note: --marketplace and --zip only apply to --format plugin; ignored.")
            res = pack_claude_app(args.library, args.out, args.name, args.pkg_version, args.author)
        elif args.format == "clawhub":
            if args.marketplace:
                print("Note: --marketplace only applies to --format plugin; ignored.")
            res = pack_clawhub(args.library, args.out, args.name, args.pkg_version, args.author,
                               args.description, make_zip=args.zip)
        else:
            res = pack_plugin(args.library, args.out, args.name, args.pkg_version, args.author, args.description,
                              marketplace=args.marketplace, marketplace_name=args.marketplace_name,
                              make_zip=args.zip)
    except PackError as exc:
        _err(str(exc))
        return 2
    print(f"Packed {len(res.skills)} skill(s) into {res.root}")
    print(f"  manifest:    {res.manifest}")
    if res.marketplace:
        print(f"  marketplace: {res.marketplace}")
    if res.zip_path:
        print(f"  zip:         {res.zip_path}")
    if args.format == "claude-app":
        print(f"  {len(res.files)} upload zip(s), one per skill. Upload steps: {res.manifest}")
    if args.format == "clawhub":
        print("  ClawHub layout is a best guess: verify against current ClawHub requirements.")
    return 0


def cmd_new(args) -> int:
    try:
        folder = new_skill(args.name, args.dir, args.description)
    except ScaffoldError as exc:
        _err(str(exc))
        return 1
    print(f"Created {folder / 'SKILL.md'}")
    print(f"Next: edit it, then run: skillkit lint {folder}")
    return 0


def main(argv=None, transport=None, environ=None) -> int:
    parser = build_parser()
    try:
        args = parser.parse_args(argv)
    except SystemExit as exc:  # argparse: --help (0) or usage error (2)
        return int(exc.code or 0)
    if args.command is None:
        parser.print_help()
        return 2
    if args.command == "lint":
        return cmd_lint(args)
    if args.command == "eval":
        return cmd_eval(args, transport=transport, environ=environ)
    if args.command == "pack":
        return cmd_pack(args)
    return cmd_new(args)
