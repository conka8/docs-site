"""Every third-party detail (URLs, headers, field names, file layouts) lives here.

Verify these against the current vendor docs before relying on them; they are
listed in the README under "Verify against current docs".
"""

# --- SKILL.md rules (Claude Agent Skills / Claude Code / OpenClaw) ---
SKILL_FILE = "SKILL.md"
NAME_PATTERN = r"^[a-z0-9]+(-[a-z0-9]+)*$"
NAME_MAX_CHARS = 64
DESCRIPTION_MAX_CHARS = 1024
BODY_MAX_LINES = 500
RESERVED_WORDS = ("anthropic", "claude")
WHEN_CUES = ("use when", "when", "use this")
# Keys accepted when a skill is uploaded to the Claude apps or the Claude API (Claude Code accepts more).
# Source: https://code.claude.com/docs/en/skills, checked 2026-10-29.
UPLOAD_FRONTMATTER_KEYS = ("name", "description", "license", "compatibility", "metadata", "allowed-tools")
# Written by skillport into converted skills until a person has checked the "Conversion check" list.
REVIEW_MARKER = "<!-- skillport: needs-review -->"

# --- Anthropic Messages API ---
ANTHROPIC_MESSAGES_URL = "https://api.anthropic.com/v1/messages"
ANTHROPIC_VERSION = "2023-06-01"
ANTHROPIC_DEFAULT_MODEL = "claude-sonnet-5-5"
ANTHROPIC_API_KEY_ENV = "ANTHROPIC_API_KEY"

# --- OpenAI(-compatible) chat completions ---
OPENAI_CHAT_URL = "https://api.openai.com/v1/chat/completions"
OPENAI_BASE_URL_ENV = "OPENAI_BASE_URL"  # e.g. https://openrouter.ai/api/v1
OPENAI_DEFAULT_MODEL = "gpt-4o-mini"
OPENAI_API_KEY_ENV = "OPENAI_API_KEY"

DEFAULT_MAX_TOKENS = 1024
DEFAULT_TIMEOUT_SECONDS = 60

# --- Claude Code plugin / marketplace layout ---
PLUGIN_DIR = ".claude-plugin"
PLUGIN_MANIFEST = "plugin.json"
MARKETPLACE_MANIFEST = "marketplace.json"
PLUGIN_SKILLS_DIR = "skills"

# --- Claude app skill uploads (one zip per skill, folder at the zip root) ---
CLAUDE_APP_SKILLS_HELP = "https://support.claude.com/en/articles/12512180-use-skills-in-claude"
# The claude.ai upload form limits descriptions to 200 characters (Claude Code accepts 1024).
# Source: https://support.claude.com/en/articles/12512198-creating-custom-skills, checked 2026-10-29.
CLAUDE_APP_DESCRIPTION_MAX_CHARS = 200

# --- ClawHub-style bundle (verify against current ClawHub requirements) ---
CLAWHUB_INDEX = "index.json"

# Files and folders never copied into packages or scanned by lint.
IGNORED_NAMES = {".DS_Store", "Thumbs.db", "__pycache__", ".git", ".svn", "node_modules", ".venv"}
