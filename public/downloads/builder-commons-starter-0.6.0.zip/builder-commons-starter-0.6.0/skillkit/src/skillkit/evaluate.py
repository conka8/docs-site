"""`skillkit eval`: run skills on sample inputs, check assertions, compare to a baseline."""

from __future__ import annotations

import datetime as _dt
import html
import json
import re
import time
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Callable

import yaml

from . import __version__
from .providers import Provider, ProviderError
from .skill import load_skills

ASSERTION_TYPES = ("contains", "not_contains", "regex", "max_chars", "json_valid", "json_has_keys", "llm_rubric")

JUDGE_SYSTEM = (
    "You are a strict grader. You will get a rubric and a response. Decide if the response meets the rubric. "
    "Answer with PASS or FAIL as the first word, then one short sentence explaining why."
)


class CasesError(Exception):
    """The cases file is missing or malformed."""


@dataclass
class Case:
    skill: str | None
    id: str
    input: str
    assertions: list[tuple[str, object]]
    fake_response: object = None
    fake_judge: str | None = None


@dataclass
class AssertionResult:
    type: str
    expected: object
    passed: bool
    detail: str = ""


@dataclass
class CaseResult:
    skill: str
    case_id: str
    input: str
    passed: bool
    latency_ms: float
    output: str = ""
    error: str | None = None
    assertions: list[AssertionResult] = field(default_factory=list)


# ---------------------------------------------------------------- loading


def _norm_assertions(raw, where: str) -> list[tuple[str, object]]:
    if raw is None:
        return []
    if not isinstance(raw, list):
        raise CasesError(f"{where}: 'assert' must be a list.")
    out = []
    for item in raw:
        if isinstance(item, dict) and "type" in item:
            atype, value = item["type"], item.get("value", True)
        elif isinstance(item, dict) and len(item) == 1:
            (atype, value), = item.items()
        else:
            raise CasesError(f"{where}: each assertion must look like '- contains: text', got {item!r}.")
        if atype not in ASSERTION_TYPES:
            raise CasesError(f"{where}: unknown assertion '{atype}'. Use one of: {', '.join(ASSERTION_TYPES)}.")
        out.append((atype, value))
    return out


def _make_case(raw, skill: str | None, index: int) -> Case:
    if not isinstance(raw, dict):
        raise CasesError(f"Case #{index + 1} must be a mapping with at least 'input'.")
    skill = raw.get("skill", skill)
    cid = str(raw.get("id") or raw.get("name") or f"case-{index + 1}")
    where = f"case '{cid}'" + (f" of skill '{skill}'" if skill else "")
    if "input" not in raw or raw["input"] is None:
        raise CasesError(f"{where} has no 'input'.")
    return Case(
        skill=skill, id=cid, input=str(raw["input"]),
        assertions=_norm_assertions(raw.get("assert", raw.get("assertions")), where),
        fake_response=raw.get("fake_response"), fake_judge=raw.get("fake_judge"),
    )


def parse_cases(data) -> tuple[list[Case], dict]:
    """Accepts either ``cases: [ {skill, input, assert}, ... ]`` or ``skills: {name: {cases: [...]}}``."""
    if not isinstance(data, dict):
        raise CasesError("The cases file must be a YAML mapping with 'cases:' or 'skills:'.")
    settings = {k: data[k] for k in ("provider", "model") if k in data}
    cases: list[Case] = []
    if isinstance(data.get("cases"), list):
        cases += [_make_case(c, None, i) for i, c in enumerate(data["cases"])]
    skills = data.get("skills")
    if isinstance(skills, dict):
        for skill_name, block in skills.items():
            items = block.get("cases") if isinstance(block, dict) else block
            if not isinstance(items, list):
                raise CasesError(f"skills.{skill_name} must have a 'cases:' list.")
            cases += [_make_case(c, str(skill_name), i) for i, c in enumerate(items)]
    if not cases:
        raise CasesError("No cases found. Add a 'cases:' list (or 'skills: {name: {cases: [...]}}').")
    seen = set()
    for c in cases:
        key = (c.skill, c.id)
        if key in seen:
            raise CasesError(f"Duplicate case id '{c.id}' for skill '{c.skill}'.")
        seen.add(key)
    return cases, settings


def load_cases(path) -> tuple[list[Case], dict]:
    path = Path(path)
    if not path.is_file():
        raise CasesError(f"Cases file not found: {path}")
    try:
        data = yaml.safe_load(path.read_text(encoding="utf-8"))
    except yaml.YAMLError as exc:
        raise CasesError(f"Cases file {path} is not valid YAML: {exc}") from exc
    return parse_cases(data)


# What `eval` actually tests, shown in every report so a pass is not read as more than it is.
MODE_NOTE = ("Instruction-only test: each case sends the skill's SKILL.md instructions as the system prompt and "
             "the case input as one message. Tools, scripts, reference files, multi-turn chat and Claude choosing "
             "the skill by itself are not tested.")
DEMO_NOTE = ("Demo data: The 'fake' provider returns the canned answers from the cases file and passes every "
             "llm_rubric check unless the case sets fake_judge. This shows how the report looks; it says nothing "
             "about how the skill performs.")
_FILE_REF = re.compile(r"\b(?:scripts|references|assets|templates)/[\w./-]*\w")
_SEND_REF = re.compile(r"\b(?:references|assets|templates|examples)/[\w./-]*\w")


def unsent_files(path) -> dict[str, list[str]]:
    """Files each SKILL.md points to that `eval` never sends to the model (it only sends the instructions)."""
    skills, _ = load_skills(Path(path))
    out: dict[str, list[str]] = {}
    for s in skills:
        if s.exists:
            refs = sorted(set(_FILE_REF.findall(s.body if s.fm and s.fm.error is None else s.text)))
            if refs:
                out[s.name if isinstance(s.name, str) and s.name else s.folder_name] = refs
    return out


REFERENCES_NOTE = ("Instructions + reference files: each case sends the skill's SKILL.md instructions plus the text "
                   "files it points to (references/, assets/, templates/, examples/) as the system prompt, and the case input as "
                   "one message. Scripts are not run, there is no multi-turn chat, and Claude doesn't have to choose "
                   "the skill or open the files by itself as it would in the Claude apps.")


def _with_references(skill, body: str) -> str:
    """Append the text of every file the SKILL.md points to, as Claude would read them on demand."""
    parts = [body]
    for rel in sorted(set(_SEND_REF.findall(body))):
        path = skill.folder / rel
        if path.is_file():
            try:
                parts.append(f"\n\n<file path=\"{rel}\">\n{path.read_text(encoding='utf-8').strip()}\n</file>")
            except UnicodeDecodeError:
                continue
    return "".join(parts)


def load_skill_prompts(path, include_references: bool = False) -> dict[str, str]:
    """Map skill name (and folder name) -> SKILL.md body (used as the system prompt)."""
    skills, _ = load_skills(Path(path))
    prompts: dict[str, str] = {}
    for s in skills:
        if not s.exists:
            continue
        body = s.body.strip() if s.fm and s.fm.error is None else s.text.strip()
        if include_references:
            body = _with_references(s, body)
        prompts.setdefault(s.folder_name, body)
        if isinstance(s.name, str) and s.name:
            prompts[s.name] = body
    return prompts


# ---------------------------------------------------------------- assertions


def _strip_fences(text: str) -> str:
    m = re.match(r"^\s*```[A-Za-z0-9_-]*\s*\n(.*?)\n\s*```\s*$", text, re.DOTALL)
    return m.group(1) if m else text


def _parse_json(text: str):
    return json.loads(_strip_fences(text))


def judge(provider: Provider, rubric: str, output: str, case=None) -> tuple[bool, str]:
    user = f"Rubric:\n{rubric}\n\nResponse to grade:\n<<<\n{output}\n>>>\n\nAnswer PASS or FAIL first."
    verdict = provider.complete(JUDGE_SYSTEM, user, case=case, purpose="judge").strip()
    first = re.split(r"[\s:.,!-]+", verdict, maxsplit=1)[0].upper() if verdict else ""
    return first == "PASS", verdict[:300]


def check_assertion(atype: str, expected, output: str, judge_fn: Callable[[str], tuple[bool, str]] | None = None
                    ) -> AssertionResult:
    def res(ok, detail=""):
        return AssertionResult(atype, expected, bool(ok), detail)

    if atype in ("contains", "not_contains"):
        needles = expected if isinstance(expected, list) else [expected]
        low = output.lower()
        found = [str(n) for n in needles if str(n).lower() in low]
        if atype == "contains":
            missing = [str(n) for n in needles if str(n).lower() not in low]
            return res(not missing, f"missing: {missing}" if missing else "")
        return res(not found, f"found: {found}" if found else "")
    if atype == "regex":
        try:
            found_match = re.search(str(expected), output, re.MULTILINE)
            return res(found_match, "" if found_match else "pattern not found")
        except re.error as exc:
            return res(False, f"invalid regex: {exc}")
    if atype == "max_chars":
        try:
            limit = int(expected)
        except (TypeError, ValueError):
            return res(False, f"max_chars needs a number, got {expected!r}")
        return res(len(output) <= limit, f"{len(output)} chars (limit {limit})")
    if atype == "json_valid":
        try:
            _parse_json(output)
            ok = True
        except (json.JSONDecodeError, ValueError):
            ok = False
        want = bool(expected)
        return res(ok == want, "" if ok == want else ("not valid JSON" if want else "is valid JSON"))
    if atype == "json_has_keys":
        keys = expected if isinstance(expected, list) else [expected]
        try:
            data = _parse_json(output)
        except (json.JSONDecodeError, ValueError):
            return res(False, "not valid JSON")
        if not isinstance(data, dict):
            return res(False, "JSON is not an object")
        missing = [str(k) for k in keys if str(k) not in data]
        return res(not missing, f"missing keys: {missing}" if missing else "")
    if atype == "llm_rubric":
        if judge_fn is None:
            return res(False, "no judge available")
        try:
            ok, verdict = judge_fn(str(expected))
        except ProviderError as exc:
            return res(False, f"judge error: {exc}")
        return res(ok, verdict)
    return res(False, f"unknown assertion type {atype}")


# ---------------------------------------------------------------- running


def run_case(case: Case, system_prompt: str, provider: Provider, clock=time.perf_counter) -> CaseResult:
    skill = case.skill or ""
    start = clock()
    try:
        output = provider.complete(system_prompt, case.input, case=case, purpose="answer")
    except ProviderError as exc:
        latency = (clock() - start) * 1000
        return CaseResult(skill, case.id, case.input, False, round(latency, 1), error=str(exc))
    latency = (clock() - start) * 1000

    def judge_fn(rubric):
        return judge(provider, rubric, output, case)

    results = [check_assertion(t, v, output, judge_fn) for t, v in case.assertions]
    passed = all(r.passed for r in results)
    return CaseResult(skill, case.id, case.input, passed, round(latency, 1), output, None, results)


def run_eval(skill_path, cases: list[Case], provider: Provider, clock=time.perf_counter,
             include_references: bool = False) -> dict:
    prompts = load_skill_prompts(skill_path, include_references)
    if not prompts:
        raise CasesError(f"No skills with a SKILL.md found in {skill_path}.")
    only = next(iter(prompts.values())) if len(set(prompts.values())) == 1 else None
    only_name = list(prompts)[-1] if only is not None else None
    results: list[CaseResult] = []
    for case in cases:
        name = case.skill or only_name
        if name is None:
            results.append(CaseResult("", case.id, case.input, False, 0.0,
                                      error="Case has no 'skill:' and the library has several skills."))
            continue
        if name not in prompts:
            results.append(CaseResult(name, case.id, case.input, False, 0.0,
                                      error=f"Skill '{name}' not found in {skill_path}."))
            continue
        if not case.skill:
            case.skill = name
        results.append(run_case(case, prompts[name], provider, clock))
    passed = sum(1 for r in results if r.passed)
    return {
        "tool": "skillkit",
        "version": __version__,
        "created": _dt.datetime.now(_dt.timezone.utc).replace(microsecond=0).isoformat(),
        "provider": provider.name,
        "model": provider.model,
        "mode": "instructions+references" if include_references else "instruction-only",
        "demo": provider.name == "fake",
        "files_not_sent": {} if include_references else {k: v for k, v in unsent_files(skill_path).items()
                                                         if any(r.skill == k for r in results)},
        "summary": {"total": len(results), "passed": passed, "failed": len(results) - passed},
        "results": [asdict(r) for r in results],
        "comparison": None,
    }


def compare_to_baseline(report: dict, baseline: dict) -> dict:
    """Regression = passed in the baseline, fails now."""
    def key(r):
        return f"{r.get('skill', '')}::{r.get('case_id', '')}"

    before = {key(r): bool(r.get("passed")) for r in baseline.get("results", [])}
    now = {key(r): bool(r.get("passed")) for r in report.get("results", [])}
    comparison = {
        "regressions": sorted(k for k, ok in now.items() if not ok and before.get(k) is True),
        "fixed": sorted(k for k, ok in now.items() if ok and before.get(k) is False),
        "new": sorted(k for k in now if k not in before),
        "missing": sorted(k for k in before if k not in now),
        "baseline_created": baseline.get("created"),
        "baseline_model": baseline.get("model"),
    }
    report["comparison"] = comparison
    return comparison


def load_baseline(path) -> dict:
    path = Path(path)
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError as exc:
        raise CasesError(f"Baseline file not found: {path}") from exc
    except json.JSONDecodeError as exc:
        raise CasesError(f"Baseline file {path} is not valid JSON (use a report saved with --format json).") from exc
    if not isinstance(data, dict) or not isinstance(data.get("results"), list):
        raise CasesError(f"Baseline file {path} is not a skillkit JSON report.")
    return data


# ---------------------------------------------------------------- reports


def render_text(report: dict) -> str:
    s = report["summary"]
    out = [f"skillkit eval  provider={report['provider']}  model={report['model']}"]
    if report.get("demo"):
        out.append(DEMO_NOTE.replace("Demo data:", "DEMO DATA:", 1))
    out.append(REFERENCES_NOTE if report.get("mode") == "instructions+references" else MODE_NOTE)
    for skill, files in (report.get("files_not_sent") or {}).items():
        out.append(f"Not sent to the model for {skill}: {', '.join(files)}")
    out.append("")
    for r in report["results"]:
        mark = "PASS" if r["passed"] else "FAIL"
        out.append(f"[{mark}] {r['skill']} / {r['case_id']}  ({r['latency_ms']:.0f} ms)")
        if r.get("error"):
            out.append(f"       error: {r['error']}")
        for a in r.get("assertions", []):
            if not a["passed"]:
                out.append(f"       - {a['type']} {a['expected']!r} failed: {a['detail']}")
    out.append("")
    out.append(f"{s['passed']} of {s['total']} cases passed, {s['failed']} failed.")
    cmp_ = report.get("comparison")
    if cmp_:
        if cmp_["regressions"]:
            out.append(f"REGRESSIONS ({len(cmp_['regressions'])}): these passed in the baseline and fail now:")
            out += [f"  - {k}" for k in cmp_["regressions"]]
        else:
            out.append("No regressions compared to the baseline.")
        if cmp_["fixed"]:
            out.append(f"Fixed since baseline: {', '.join(cmp_['fixed'])}")
        if cmp_["new"]:
            out.append(f"New cases (not in baseline): {', '.join(cmp_['new'])}")
    return "\n".join(out) + "\n"


def render_json(report: dict) -> str:
    return json.dumps(report, indent=2, ensure_ascii=False, default=str) + "\n"


HTML_CSS = """
body{font-family:-apple-system,Segoe UI,Roboto,Helvetica,Arial,sans-serif;margin:2rem;color:#1f2328;background:#fff}
h1{font-size:1.5rem;margin:0 0 .25rem} .meta{color:#57606a;margin-bottom:1.5rem}
.summary{display:flex;gap:1rem;margin-bottom:1.5rem}
.box{border:1px solid #d0d7de;border-radius:8px;padding:.75rem 1rem;min-width:7rem}
.box b{display:block;font-size:1.5rem}
table{border-collapse:collapse;width:100%} th,td{border:1px solid #d0d7de;padding:.5rem;vertical-align:top;text-align:left}
th{background:#f6f8fa} .pass{color:#1a7f37;font-weight:600} .fail{color:#cf222e;font-weight:600}
pre{white-space:pre-wrap;word-break:break-word;margin:0;font-size:.85rem;max-height:20rem;overflow:auto}
ul{margin:0;padding-left:1.1rem} .reg{background:#fff1f0;border:1px solid #cf222e;border-radius:8px;padding:.75rem 1rem;margin-bottom:1.5rem}
.demo{background:#fff8c5;border:2px solid #9a6700;border-radius:8px;padding:.75rem 1rem;margin-bottom:1rem}
.note{color:#57606a;border-left:3px solid #d0d7de;padding-left:.75rem;margin:0 0 1.5rem}
@media print{pre{max-height:none;overflow:visible} body{margin:1cm}}
"""


def render_html(report: dict) -> str:
    e = html.escape
    s = report["summary"]
    rows = []
    for r in report["results"]:
        cls = "pass" if r["passed"] else "fail"
        checks = "".join(
            f"<li class=\"{'pass' if a['passed'] else 'fail'}\">{e(a['type'])}: {e(str(a['expected']))}"
            f"{(' &mdash; ' + e(str(a['detail']))) if a['detail'] else ''}</li>"
            for a in r.get("assertions", [])
        )
        if r.get("error"):
            checks += f"<li class=\"fail\">error: {e(r['error'])}</li>"
        rows.append(
            f"<tr><td>{e(r['skill'])}</td><td>{e(r['case_id'])}</td>"
            f"<td class=\"{cls}\">{'PASS' if r['passed'] else 'FAIL'}</td>"
            f"<td>{r['latency_ms']:.0f} ms</td><td><ul>{checks}</ul></td>"
            f"<td><pre>{e(r.get('output') or '')}</pre></td></tr>"
        )
    reg = ""
    cmp_ = report.get("comparison")
    if cmp_:
        if cmp_["regressions"]:
            items = "".join(f"<li>{e(k)}</li>" for k in cmp_["regressions"])
            reg = f"<div class=\"reg\"><b>Regressions</b> (passed in the baseline, fail now):<ul>{items}</ul></div>"
        else:
            reg = "<p class=\"pass\">No regressions compared to the baseline.</p>"
    demo = f'<div class="demo" role="note"><b>Demo data:</b> {e(DEMO_NOTE[len("Demo data: "):])}</div>' \
        if report.get("demo") else ""
    unsent = "".join(f"<br>Not sent to the model for {e(k)}: {e(', '.join(v))}"
                     for k, v in (report.get("files_not_sent") or {}).items())
    return f"""<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Skill eval report</title><style>{HTML_CSS}</style></head><body>
<h1>Skill eval report</h1>
<div class="meta">Provider {e(str(report['provider']))} &middot; model {e(str(report['model']))} &middot; {e(str(report.get('created', '')))}</div>
{demo}<p class="note">{e(REFERENCES_NOTE if report.get("mode") == "instructions+references" else MODE_NOTE)}{unsent}</p>
<div class="summary"><div class="box">Cases<b>{s['total']}</b></div><div class="box">Passed<b class="pass">{s['passed']}</b></div><div class="box">Failed<b class="fail">{s['failed']}</b></div></div>
{reg}
<table><thead><tr><th>Skill</th><th>Case</th><th>Result</th><th>Time</th><th>Checks</th><th>Output</th></tr></thead>
<tbody>{''.join(rows)}</tbody></table>
<p class="meta">Generated by skillkit {e(str(report.get('version', '')))}. Print this page to save it as PDF.</p>
</body></html>
"""


RENDERERS = {"text": render_text, "json": render_json, "html": render_html}


def render_report(report: dict, fmt: str = "text") -> str:
    if fmt not in RENDERERS:
        raise ValueError(f"Unknown report format {fmt!r}; choose one of {', '.join(RENDERERS)}")
    return RENDERERS[fmt](report)
