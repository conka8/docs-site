"""`skillkit lint`: rules, fixes and output formats."""

from __future__ import annotations

import json
import os
import re
from collections import defaultdict
from dataclasses import asdict, dataclass, field
from pathlib import Path
from urllib.parse import unquote

from .constants import (
    BODY_MAX_LINES,
    CLAUDE_APP_DESCRIPTION_MAX_CHARS,
    DESCRIPTION_MAX_CHARS,
    NAME_MAX_CHARS,
    NAME_PATTERN,
    RESERVED_WORDS,
    REVIEW_MARKER,
    UPLOAD_FRONTMATTER_KEYS,
    WHEN_CUES,
)
from .skill import Skill, iter_text_files, load_skills, normalize_newlines, parse_frontmatter, slugify

ERROR = "error"
WARNING = "warning"

# rule id -> (severity, what it checks)
RULES: dict[str, tuple[str, str]] = {
    "missing-skill-md": (ERROR, "The skill folder has no SKILL.md file."),
    "frontmatter-missing": (ERROR, "SKILL.md does not start with a '---' YAML frontmatter block."),
    "frontmatter-invalid": (ERROR, "The frontmatter is not valid YAML (or not key: value pairs)."),
    "name-missing": (ERROR, "Frontmatter has no 'name'."),
    "name-format": (ERROR, "'name' must be lowercase letters, digits and single hyphens."),
    "name-too-long": (ERROR, f"'name' is longer than {NAME_MAX_CHARS} characters."),
    "name-reserved": (ERROR, "'name' contains a reserved word ('anthropic' or 'claude')."),
    "name-folder-mismatch": (WARNING, "'name' is different from the folder name."),
    "description-missing": (ERROR, "Frontmatter has no 'description'."),
    "description-empty": (ERROR, "'description' is empty or not plain text."),
    "description-too-long": (ERROR, f"'description' is longer than {DESCRIPTION_MAX_CHARS} characters."),
    "description-too-long-for-app": (WARNING, f"'description' is longer than the Claude app's upload limit of "
                                              f"{CLAUDE_APP_DESCRIPTION_MAX_CHARS} characters."),
    "description-no-when": (WARNING, "'description' does not say when to use the skill."),
    "description-xml": (ERROR, "'description' contains XML/HTML tags."),
    "description-todo": (WARNING, "'description' is still a TODO placeholder."),
    "body-too-long": (WARNING, f"SKILL.md body is longer than {BODY_MAX_LINES} lines."),
    "broken-link": (ERROR, "A link or file reference points to a file that does not exist."),
    "absolute-path": (WARNING, "An absolute path from someone's computer (/Users/, /home/, C:\\) was found."),
    "secret": (ERROR, "Something that looks like an API key, token or private key was found."),
    "script-not-executable": (WARNING, "A referenced script is not marked as executable."),
    "script-no-shebang": (WARNING, "A referenced script has no '#!' first line."),
    "duplicate-name": (ERROR, "Two skills in the library use the same name."),
    "frontmatter-upload-key": (WARNING, "A frontmatter key that the Claude app and API reject on upload."),
    "needs-review": (WARNING, "A converted skill whose 'Conversion check' list has not been reviewed."),
}

SECRET_PATTERNS: list[tuple[str, re.Pattern]] = [
    ("Anthropic API key", re.compile(r"sk-ant-[A-Za-z0-9_\-]{20,}")),
    ("OpenAI-style API key", re.compile(r"sk-(?!ant-)(?:proj-)?[A-Za-z0-9_\-]{20,}")),
    ("AWS access key id", re.compile(r"\bAKIA[0-9A-Z]{16}\b")),
    ("GitHub token", re.compile(r"\bghp_[A-Za-z0-9]{30,}")),
    ("Slack token", re.compile(r"\bxox[bp]-[A-Za-z0-9\-]{10,}")),
    ("private key", re.compile(r"-----BEGIN (?:[A-Z0-9]+ )*PRIVATE KEY-----")),
]

ABS_PATH_RE = re.compile(r"(?<![\w.~/])(/Users/[^\s'\"`)]+|/home/[^\s'\"`)]+|\b[A-Za-z]:\\[^\s'\"`)]*)")
MD_LINK_RE = re.compile(r"!?\[[^\]]*\]\(\s*<?([^)\s>]+)>?(?:\s+[\"'][^\"']*[\"'])?\s*\)")
PATH_REF_RE = re.compile(r"(?<![\w/.:\-])((?:\./)?(?:scripts|references|assets|templates|examples)/[\w.\-/]*\w)")
XML_TAG_RE = re.compile(r"</?[A-Za-z][A-Za-z0-9_\-]*(?:\s[^<>]*)?/?>")
SCRIPT_EXTS = {".py", ".sh", ".bash", ".zsh", ".js", ".mjs", ".cjs", ".ts", ".rb", ".pl", ".php"}
TODO_DESCRIPTION = "TODO - describe what this skill does. Use when the user asks to ..."


@dataclass
class Issue:
    rule: str
    severity: str
    file: str
    line: int
    message: str
    skill: str = ""


@dataclass
class LintResult:
    skills: list[Skill]
    issues: list[Issue]
    fixes: list[str] = field(default_factory=list)
    is_library: bool = False

    @property
    def errors(self) -> list[Issue]:
        return [i for i in self.issues if i.severity == ERROR]

    @property
    def warnings(self) -> list[Issue]:
        return [i for i in self.issues if i.severity == WARNING]

    @property
    def ok(self) -> bool:
        return not self.errors


def _issue(rule: str, file: Path, line: int, message: str, skill: str = "") -> Issue:
    return Issue(rule, RULES[rule][0], str(file), max(int(line), 1), message, skill)


def _mask(secret: str) -> str:
    return secret[:6] + "..." if len(secret) > 6 else secret


# ---------------------------------------------------------------- single skill


def check_name(skill: Skill) -> list[Issue]:
    md, fm, label = skill.skill_md, skill.fm, skill.display_name
    meta = fm.meta
    line = fm.key_lines.get("name", 1)
    if "name" not in meta or meta.get("name") is None:
        return [_issue("name-missing", md, 1, "Add a 'name:' line to the frontmatter (e.g. name: "
                       f"{slugify(skill.folder_name) or 'my-skill'}).", label)]
    name = meta["name"]
    if not isinstance(name, str):
        return [_issue("name-format", md, line, f"'name' must be text, got {name!r}.", label)]
    out = []
    if not re.match(NAME_PATTERN, name):
        out.append(_issue("name-format", md, line, f"Name \"{name}\" must use only lowercase letters, digits "
                          f"and single hyphens (try \"{slugify(name) or 'my-skill'}\").", label))
    if len(name) > NAME_MAX_CHARS:
        out.append(_issue("name-too-long", md, line,
                          f"Name is {len(name)} characters; the limit is {NAME_MAX_CHARS}.", label))
    lowered = name.lower()
    for word in RESERVED_WORDS:
        if word in lowered:
            out.append(_issue("name-reserved", md, line,
                              f"Name \"{name}\" contains the reserved word \"{word}\". Pick another name.", label))
    folder = skill.folder_name
    if name != folder:
        out.append(_issue("name-folder-mismatch", md, line,
                          f"Name \"{name}\" is different from the folder name \"{folder}\". "
                          "Rename one so they match (or run with --fix).", label))
    return out


def check_description(skill: Skill) -> list[Issue]:
    md, fm, label = skill.skill_md, skill.fm, skill.display_name
    meta = fm.meta
    line = fm.key_lines.get("description", 1)
    if "description" not in meta:
        return [_issue("description-missing", md, 1,
                       "Add a 'description:' saying what the skill does and when to use it.", label)]
    desc = meta["description"]
    if desc is None or (isinstance(desc, str) and not desc.strip()):
        return [_issue("description-empty", md, line, "The description is empty.", label)]
    if not isinstance(desc, str):
        return [_issue("description-empty", md, line,
                       f"The description must be plain text, got {type(desc).__name__}.", label)]
    out = []
    if len(desc) > DESCRIPTION_MAX_CHARS:
        out.append(_issue("description-too-long", md, line,
                          f"Description is {len(desc)} characters; the limit is {DESCRIPTION_MAX_CHARS}.", label))
    elif len(desc) > CLAUDE_APP_DESCRIPTION_MAX_CHARS:
        out.append(_issue("description-too-long-for-app", md, line,
                          f"Description is {len(desc)} characters. Claude Code accepts it, but uploading it in the "
                          f"Claude app needs {CLAUDE_APP_DESCRIPTION_MAX_CHARS} or fewer.", label))
    lowered = desc.lower()
    if lowered.strip().startswith("todo"):
        out.append(_issue("description-todo", md, line, "The description is still a TODO placeholder.", label))
    elif not any(re.search(r"\b" + re.escape(cue) + r"\b", lowered) for cue in WHEN_CUES):
        out.append(_issue("description-no-when", md, line,
                          "The description should say when to use the skill (e.g. \"Use when ...\").", label))
    tag = XML_TAG_RE.search(desc)
    if tag:
        out.append(_issue("description-xml", md, line,
                          f"The description contains the tag {tag.group(0)!r}. Remove XML/HTML tags.", label))
    return out


def _code_fence_mask(lines: list[str]) -> list[bool]:
    inside, mask = False, []
    for line in lines:
        if line.lstrip().startswith(("```", "~~~")):
            mask.append(True)
            inside = not inside
            continue
        mask.append(inside)
    return mask


def _is_external(target: str) -> bool:
    t = target.lower()
    return (
        "://" in t
        or t.startswith(("mailto:", "tel:", "#", "data:", "/", "~"))
        or "{{" in t
        or re.match(r"^[a-z]:\\", t) is not None
    )


def check_references(skill: Skill) -> list[Issue]:
    """Broken relative links/file references, plus script checks for the ones that exist."""
    md, fm, label = skill.skill_md, skill.fm, skill.display_name
    body_lines = fm.body.split("\n")
    in_code = _code_fence_mask(body_lines)
    out: list[Issue] = []
    seen: set[tuple[int, str]] = set()
    checked_scripts: set[Path] = set()
    for idx, line in enumerate(body_lines):
        lineno = fm.body_start_line + idx
        targets = []
        if not in_code[idx]:
            targets += [m.group(1) for m in MD_LINK_RE.finditer(line)]
        # bare references like `scripts/run.py`, ignoring text already inside markdown links
        targets += [m.group(1) for m in PATH_REF_RE.finditer(MD_LINK_RE.sub(" ", line))]
        for raw in targets:
            if _is_external(raw):
                continue
            target = unquote(raw.split("#", 1)[0].split("?", 1)[0])
            if not target:
                continue
            norm = target[2:] if target.startswith("./") else target
            if (lineno, norm) in seen:
                continue
            seen.add((lineno, norm))
            path = skill.folder / norm
            if not path.exists():
                out.append(_issue("broken-link", md, lineno,
                                  f"\"{norm}\" is referenced but does not exist in the skill folder.", label))
                continue
            if path.is_file() and path not in checked_scripts and _looks_like_script(norm):
                checked_scripts.add(path)
                out += _check_script(path, md, lineno, norm, label)
    return out


def _looks_like_script(rel: str) -> bool:
    p = Path(rel)
    return p.suffix.lower() in SCRIPT_EXTS or (p.parts and p.parts[0] == "scripts" and p.suffix == "")


def _check_script(path: Path, md: Path, lineno: int, rel: str, label: str) -> list[Issue]:
    out = []
    try:
        with open(path, "rb") as fh:
            first = fh.read(2)
    except OSError:
        first = b""
    if first != b"#!":
        out.append(_issue("script-no-shebang", md, lineno,
                          f"Script \"{rel}\" has no '#!' first line (e.g. #!/usr/bin/env python3).", label))
    if os.name != "nt" and not (path.stat().st_mode & 0o111):
        out.append(_issue("script-not-executable", md, lineno,
                          f"Script \"{rel}\" is not executable. Run: chmod +x {rel}", label))
    return out


def check_body_length(skill: Skill) -> list[Issue]:
    body = skill.fm.body
    leading = len(body) - len(body.lstrip("\n"))
    lines = body.strip("\n").split("\n")
    if len(lines) > BODY_MAX_LINES:
        return [_issue("body-too-long", skill.skill_md, skill.fm.body_start_line + leading + BODY_MAX_LINES,
                       f"The instructions are {len(lines)} lines long (limit {BODY_MAX_LINES}). "
                       "Move details into separate files under references/.", skill.display_name)]
    return []


def check_files(skill: Skill) -> list[Issue]:
    """Secrets and absolute local paths in every text file of the skill."""
    out = []
    for path, text in iter_text_files(skill.folder):
        for lineno, line in enumerate(text.split("\n"), start=1):
            for kind, pattern in SECRET_PATTERNS:
                m = pattern.search(line)
                if m:
                    out.append(_issue("secret", path, lineno,
                                      f"Possible {kind} found ({_mask(m.group(0))}). Remove it and load "
                                      "keys from an environment variable instead.", skill.display_name))
            m = ABS_PATH_RE.search(line)
            if m:
                out.append(_issue("absolute-path", path, lineno,
                                  f"Absolute path \"{m.group(1)}\" only works on one computer. "
                                  "Use a path relative to the skill folder.", skill.display_name))
    return out


def check_upload_keys(skill: Skill) -> list[Issue]:
    meta = skill.fm.meta if isinstance(skill.fm.meta, dict) else {}
    return [_issue("frontmatter-upload-key", skill.skill_md, skill.fm.key_lines.get(str(k), 2),
                   f"Frontmatter key \"{k}\" works in Claude Code, but uploads to the Claude app or API only "
                   f"accept: {', '.join(UPLOAD_FRONTMATTER_KEYS)}. Remove it if members upload this skill.",
                   skill.display_name)
            for k in meta if str(k) not in UPLOAD_FRONTMATTER_KEYS]


def check_review_marker(skill: Skill) -> list[Issue]:
    for lineno, line in enumerate(skill.text.split("\n"), start=1):
        if REVIEW_MARKER in line:
            return [_issue("needs-review", skill.skill_md, lineno,
                           "This skill was converted by skillport and its \"Conversion check\" list has not been "
                           "reviewed. Check each item, then delete this line.", skill.display_name)]
    return []


def lint_skill(skill: Skill) -> list[Issue]:
    label = skill.display_name
    if not skill.exists:
        return [_issue("missing-skill-md", skill.skill_md, 1,
                       f"No SKILL.md in \"{skill.folder}\". Every skill folder needs one "
                       "(run: skillkit new <name>).", label)]
    fm = skill.fm
    issues: list[Issue] = []
    if fm.error in ("missing", "unclosed"):
        issues.append(_issue("frontmatter-missing", skill.skill_md, 1,
                             "SKILL.md must start with a frontmatter block: a '---' line, name: and "
                             "description: lines, then another '---' line." +
                             (" The closing '---' is missing." if fm.error == "unclosed" else ""), label))
    elif fm.error == "invalid":
        issues.append(_issue("frontmatter-invalid", skill.skill_md, fm.error_line,
                             f"The frontmatter is not valid YAML ({fm.error_detail}). Check colons and quotes.",
                             label))
    elif fm.error == "not-mapping":
        issues.append(_issue("frontmatter-invalid", skill.skill_md, 2,
                             f"The frontmatter must be 'key: value' lines like 'name: my-skill' ({fm.error_detail}).",
                             label))
    else:
        issues += check_name(skill)
        issues += check_description(skill)
        issues += check_upload_keys(skill)
    issues += check_review_marker(skill)
    issues += check_body_length(skill)
    issues += check_references(skill)
    issues += check_files(skill)
    return issues


# ---------------------------------------------------------------- library


def check_duplicates(skills: list[Skill]) -> list[Issue]:
    by_name: dict[str, list[Skill]] = defaultdict(list)
    for s in skills:
        if isinstance(s.name, str) and s.name:
            by_name[s.name].append(s)
    out = []
    for name, group in by_name.items():
        if len(group) < 2:
            continue
        for s in group:
            others = ", ".join(str(o.skill_md) for o in group if o is not s)
            out.append(_issue("duplicate-name", s.skill_md, s.fm.key_lines.get("name", 1),
                              f"Skill name \"{name}\" is also used by: {others}. Names must be unique.", name))
    return out


def lint_path(path, fix: bool = False) -> LintResult:
    """Lint a skill folder or a folder of skills. With fix=True apply safe fixes first."""
    fixes: list[str] = []
    if fix:
        skills, _ = load_skills(Path(path))
        for s in skills:
            for f in fix_skill(s.folder):
                fixes.append(f"{s.skill_md}: {f}")
    skills, is_library = load_skills(Path(path))
    issues: list[Issue] = []
    for s in skills:
        issues += lint_skill(s)
    issues += check_duplicates(skills)
    issues.sort(key=lambda i: (i.file, i.line, i.rule))
    return LintResult(skills, issues, fixes, is_library)


# ---------------------------------------------------------------- fixes


def _set_key(lines: list[str], end: int, key: str, value_line: str, after_key: str | None = None) -> None:
    """Replace/insert a top-level key inside frontmatter lines[1:end] (end = index of closing ---)."""
    for i in range(1, end):
        if re.match(rf"^{re.escape(key)}\s*:", lines[i]):
            j = i + 1
            while j < end and (lines[j].startswith((" ", "\t")) or not lines[j].strip()):
                j += 1
            lines[i:j] = [value_line]
            return
    pos = 1
    if after_key:
        for i in range(1, end):
            if re.match(rf"^{re.escape(after_key)}\s*:", lines[i]):
                pos = i + 1
                break
    lines.insert(pos, value_line)


def fix_skill(folder) -> list[str]:
    """Apply safe fixes to <folder>/SKILL.md. Returns a list of plain-English fix descriptions."""
    md = Path(folder) / "SKILL.md"
    if not md.is_file():
        return []
    original = md.read_bytes().decode("utf-8", errors="replace")
    text = normalize_newlines(original)
    fixes: list[str] = []

    lines = text.split("\n")
    trimmed = [ln.rstrip() for ln in lines]
    if trimmed != lines:
        fixes.append("trimmed trailing whitespace")
    text = "\n".join(trimmed)

    slug = slugify(Path(folder).resolve().name)
    slug_ok = bool(slug) and re.match(NAME_PATTERN, slug) and not any(w in slug for w in RESERVED_WORDS)
    fm = parse_frontmatter(text)
    if fm.error == "missing":
        name = slug if slug_ok else "my-skill"
        skeleton = f"---\nname: {name}\ndescription: {json.dumps(TODO_DESCRIPTION)}\n---\n\n"
        text = skeleton + text.lstrip("\n")
        fixes.append("added missing frontmatter skeleton (name + TODO description)")
    elif fm.error is None:
        lines = text.split("\n")
        end = fm.end_line - 1
        changed = []
        if slug_ok and fm.meta.get("name") != slug:
            _set_key(lines, end, "name", f"name: {slug}")
            changed.append(f'set name to "{slug}" to match the folder name')
            end = next(i for i in range(1, len(lines)) if lines[i].strip() in ("---", "..."))
        desc = fm.meta.get("description")
        if desc is None or (isinstance(desc, str) and not desc.strip()):
            _set_key(lines, end, "description", f"description: {json.dumps(TODO_DESCRIPTION)}", after_key="name")
            changed.append("added a TODO description placeholder")
        candidate = "\n".join(lines)
        if changed and parse_frontmatter(candidate).error is None:
            text = candidate
            fixes += changed
    if not text.endswith("\n"):
        text += "\n"
    if text != original:
        if not fixes:
            fixes.append("normalized line endings")
        md.write_bytes(text.encode("utf-8"))
    return fixes


# ---------------------------------------------------------------- output


def _plural(n: int, word: str) -> str:
    return f"{n} {word}{'' if n == 1 else 's'}"


def format_text(result: LintResult) -> str:
    out = []
    for f in result.fixes:
        out.append(f"fixed: {f}")
    for i in result.issues:
        out.append(f"{i.file}:{i.line}: {i.severity} [{i.rule}] {i.message}")
    n_err, n_warn = len(result.errors), len(result.warnings)
    out.append("")
    out.append(f"Checked {_plural(len(result.skills), 'skill')}: "
               f"{_plural(n_err, 'error')}, {_plural(n_warn, 'warning')}.")
    if n_err:
        out.append("Errors must be fixed before you publish. Warnings are suggestions.")
    elif n_warn:
        out.append("No errors. Warnings are suggestions worth a look.")
    else:
        out.append("All good: no problems found.")
    return "\n".join(out) + "\n"


def format_json(result: LintResult) -> str:
    payload = {
        "skills_checked": len(result.skills),
        "skills": [s.display_name for s in result.skills],
        "errors": len(result.errors),
        "warnings": len(result.warnings),
        "ok": result.ok,
        "fixes": result.fixes,
        "issues": [asdict(i) for i in result.issues],
    }
    return json.dumps(payload, indent=2, ensure_ascii=False) + "\n"


def _gh_escape_data(s: str) -> str:
    return s.replace("%", "%25").replace("\r", "%0D").replace("\n", "%0A")


def _gh_escape_prop(s: str) -> str:
    return _gh_escape_data(s).replace(":", "%3A").replace(",", "%2C")


def format_github(result: LintResult) -> str:
    """GitHub Actions workflow-command annotations."""
    out = []
    for i in result.issues:
        out.append(f"::{i.severity} file={_gh_escape_prop(i.file)},line={i.line},"
                   f"title={_gh_escape_prop('skillkit ' + i.rule)}::{_gh_escape_data(i.message)}")
    out.append(f"skillkit: {_plural(len(result.errors), 'error')}, {_plural(len(result.warnings), 'warning')} "
               f"in {_plural(len(result.skills), 'skill')}")
    return "\n".join(out) + "\n"


FORMATTERS = {"text": format_text, "json": format_json, "github": format_github}


def format_result(result: LintResult, fmt: str = "text") -> str:
    if fmt not in FORMATTERS:
        raise ValueError(f"Unknown format {fmt!r}; choose one of {', '.join(FORMATTERS)}")
    return FORMATTERS[fmt](result)
