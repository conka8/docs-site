"""LLM providers for `skillkit eval`. HTTP goes through an injectable transport."""

from __future__ import annotations

import json
import os
import urllib.error
import urllib.request
from typing import Callable

from . import constants as C

# transport(url, headers, body_bytes, timeout) -> (status_code, response_bytes)
Transport = Callable[[str, dict, bytes, float], tuple[int, bytes]]


class ProviderError(Exception):
    """Raised for missing keys, HTTP errors and unexpected API responses."""


def urllib_transport(url: str, headers: dict, body: bytes, timeout: float) -> tuple[int, bytes]:
    req = urllib.request.Request(url, data=body, headers=headers, method="POST")
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return resp.status, resp.read()
    except urllib.error.HTTPError as exc:
        return exc.code, exc.read() or b""
    except (urllib.error.URLError, OSError) as exc:
        raise ProviderError(f"Could not reach {url}: {getattr(exc, 'reason', exc)}") from exc


class Provider:
    name = "base"

    def __init__(self, model: str | None = None, max_tokens: int = C.DEFAULT_MAX_TOKENS,
                 timeout: float = C.DEFAULT_TIMEOUT_SECONDS, transport: Transport | None = None):
        self.model = model
        self.max_tokens = max_tokens
        self.timeout = timeout
        self.transport = transport or urllib_transport

    def complete(self, system: str, user: str, *, case=None, purpose: str = "answer") -> str:
        raise NotImplementedError

    def _post(self, url: str, headers: dict, payload: dict) -> dict:
        body = json.dumps(payload).encode("utf-8")
        status, raw = self.transport(url, headers, body, self.timeout)
        text = raw.decode("utf-8", errors="replace") if isinstance(raw, (bytes, bytearray)) else str(raw)
        if not 200 <= int(status) < 300:
            raise ProviderError(f"{self.name} API returned HTTP {status}: {text[:300]}")
        try:
            return json.loads(text)
        except json.JSONDecodeError as exc:
            raise ProviderError(f"{self.name} API returned invalid JSON: {text[:200]}") from exc


def _require_key(env: str, provider: str, environ=None) -> str:
    key = (environ if environ is not None else os.environ).get(env, "").strip()
    if not key:
        raise ProviderError(f"{env} is not set. Set it to your {provider} API key, "
                            "or use --provider fake for a demo run.")
    return key


class AnthropicProvider(Provider):
    name = "anthropic"

    def __init__(self, api_key: str | None = None, model: str | None = None, environ=None, **kw):
        super().__init__(model or C.ANTHROPIC_DEFAULT_MODEL, **kw)
        self.api_key = api_key or _require_key(C.ANTHROPIC_API_KEY_ENV, "Anthropic", environ)

    def complete(self, system: str, user: str, *, case=None, purpose: str = "answer") -> str:
        headers = {
            "x-api-key": self.api_key,
            "anthropic-version": C.ANTHROPIC_VERSION,
            "content-type": "application/json",
        }
        payload = {
            "model": self.model,
            "max_tokens": self.max_tokens,
            "system": system,
            "messages": [{"role": "user", "content": user}],
        }
        data = self._post(C.ANTHROPIC_MESSAGES_URL, headers, payload)
        blocks = data.get("content")
        if not isinstance(blocks, list):
            raise ProviderError(f"anthropic response has no 'content' list: {str(data)[:200]}")
        return "".join(b.get("text", "") for b in blocks if isinstance(b, dict) and b.get("type") == "text")


class OpenAIProvider(Provider):
    name = "openai"

    def __init__(self, api_key: str | None = None, model: str | None = None, base_url: str | None = None,
                 environ=None, **kw):
        super().__init__(model or C.OPENAI_DEFAULT_MODEL, **kw)
        env = environ if environ is not None else os.environ
        self.api_key = api_key or _require_key(C.OPENAI_API_KEY_ENV, "OpenAI", env)
        base = base_url or env.get(C.OPENAI_BASE_URL_ENV, "").strip()
        self.url = base.rstrip("/") + "/chat/completions" if base else C.OPENAI_CHAT_URL

    def complete(self, system: str, user: str, *, case=None, purpose: str = "answer") -> str:
        headers = {"Authorization": f"Bearer {self.api_key}", "Content-Type": "application/json"}
        payload = {
            "model": self.model,
            "max_tokens": self.max_tokens,
            "messages": [{"role": "system", "content": system}, {"role": "user", "content": user}],
        }
        data = self._post(self.url, headers, payload)
        try:
            content = data["choices"][0]["message"]["content"]
        except (KeyError, IndexError, TypeError) as exc:
            raise ProviderError(f"openai response has no choices[0].message.content: {str(data)[:200]}") from exc
        return content or ""


class FakeProvider(Provider):
    """Returns canned answers from the cases file (`fake_response`, `fake_judge`). For demos and tests."""

    name = "fake"

    def __init__(self, model: str | None = None, **kw):
        super().__init__(model or "fake", **kw)
        self.calls: list[dict] = []

    def complete(self, system: str, user: str, *, case=None, purpose: str = "answer") -> str:
        self.calls.append({"system": system, "user": user, "purpose": purpose})
        if purpose == "judge":
            return str(getattr(case, "fake_judge", None) or "PASS (fake judge)")
        resp = getattr(case, "fake_response", None)
        if resp is None:
            return ""
        if isinstance(resp, (dict, list)):
            return json.dumps(resp)
        return str(resp)


PROVIDERS = {"anthropic": AnthropicProvider, "openai": OpenAIProvider, "fake": FakeProvider}


def make_provider(name: str, model: str | None = None, transport: Transport | None = None,
                  environ=None, **kw) -> Provider:
    if name not in PROVIDERS:
        raise ProviderError(f"Unknown provider {name!r}; choose one of {', '.join(PROVIDERS)}.")
    if name == "fake":
        return FakeProvider(model=model, transport=transport, **kw)
    return PROVIDERS[name](model=model, transport=transport, environ=environ, **kw)
