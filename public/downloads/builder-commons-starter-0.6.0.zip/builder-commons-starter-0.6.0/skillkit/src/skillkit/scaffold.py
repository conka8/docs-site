"""`skillkit new`: scaffold a valid skill folder."""

from __future__ import annotations

import json
import re
from pathlib import Path

from .constants import NAME_MAX_CHARS, NAME_PATTERN, RESERVED_WORDS
from .lint import TODO_DESCRIPTION
from .skill import slugify


class ScaffoldError(Exception):
    pass


TEMPLATE = """---
name: {name}
description: {description}
---

# {title}

## When to use
Use this skill when the user asks to ... (describe the situations).

## Instructions
1. Ask the user for anything you need that they have not given you.
2. Do the task step by step.
3. Show the result and ask if they want changes.

## Examples
**User:** ...
**You:** ...

## Notes
- Keep extra material in a `references/` folder and link to it from here.
"""


def validate_name(name: str) -> None:
    if not re.match(NAME_PATTERN, name or ""):
        raise ScaffoldError(f"\"{name}\" is not a valid skill name. Use lowercase letters, digits and hyphens, "
                            f"for example \"{slugify(name) or 'my-skill'}\".")
    if len(name) > NAME_MAX_CHARS:
        raise ScaffoldError(f"Skill names can be at most {NAME_MAX_CHARS} characters.")
    for word in RESERVED_WORDS:
        if word in name:
            raise ScaffoldError(f"Skill names cannot contain the reserved word \"{word}\".")


def new_skill(name: str, parent=".", description: str | None = None) -> Path:
    validate_name(name)
    folder = Path(parent) / name
    if folder.exists():
        raise ScaffoldError(f"{folder} already exists. Pick another name or delete it first.")
    desc = (description or TODO_DESCRIPTION).strip()
    folder.mkdir(parents=True)
    title = name.replace("-", " ").title()
    (folder / "SKILL.md").write_text(
        TEMPLATE.format(name=name, description=json.dumps(desc, ensure_ascii=False), title=title),
        encoding="utf-8",
    )
    return folder
