"""Finding skill folders and reading SKILL.md (frontmatter + body)."""

from __future__ import annotations

import re
import unicodedata
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import yaml

from .constants import IGNORED_NAMES, NAME_MAX_CHARS, SKILL_FILE


@dataclass
class Frontmatter:
    """Result of splitting a SKILL.md into YAML frontmatter and markdown body."""

    meta: dict | None
    body: str
    body_start_line: int  # 1-based line number of the first body line
    error: str | None = None  # "missing", "unclosed", "invalid" or "not-mapping"
    error_detail: str = ""
    error_line: int = 1
    end_line: int = 0  # 1-based line of the closing '---' (0 if none)
    key_lines: dict = field(default_factory=dict)  # top-level key -> 1-based line


def normalize_newlines(text: str) -> str:
    if text.startswith("﻿"):
        text = text[1:]
    return text.replace("\r\n", "\n").replace("\r", "\n")


def parse_frontmatter(text: str) -> Frontmatter:
    """Split ``text`` into frontmatter and body. Never raises on bad input."""
    text = normalize_newlines(text)
    lines = text.split("\n")
    if not lines or lines[0].strip() != "---":
        return Frontmatter(None, text, 1, error="missing")
    end = None
    for i in range(1, len(lines)):
        if lines[i].strip() in ("---", "..."):
            end = i
            break
    if end is None:
        return Frontmatter(None, text, 1, error="unclosed", error_detail="no closing '---' line")
    fm_text = "\n".join(lines[1:end])
    body = "\n".join(lines[end + 1 :])
    key_lines = {}
    for i in range(1, end):
        m = re.match(r"^([A-Za-z0-9_-]+)\s*:", lines[i])
        if m and m.group(1) not in key_lines:
            key_lines[m.group(1)] = i + 1
    base = Frontmatter(None, body, end + 2, end_line=end + 1, key_lines=key_lines)
    try:
        meta = yaml.safe_load(fm_text) if fm_text.strip() else {}
    except yaml.YAMLError as exc:
        line = 1
        mark = getattr(exc, "problem_mark", None)
        if mark is not None:
            line = mark.line + 2  # +1 for 1-based, +1 for the opening '---'
        problem = getattr(exc, "problem", None) or str(exc).splitlines()[0]
        base.error, base.error_detail, base.error_line = "invalid", str(problem), line
        return base
    if not isinstance(meta, dict):
        base.error, base.error_detail = "not-mapping", f"got {type(meta).__name__}"
        return base
    base.meta = meta
    return base


@dataclass
class Skill:
    folder: Path  # as given by the user (may be relative)
    skill_md: Path
    exists: bool
    text: str = ""
    fm: Frontmatter | None = None

    @property
    def folder_name(self) -> str:
        return self.folder.resolve().name

    @property
    def name(self) -> Any:
        if self.fm and self.fm.meta:
            return self.fm.meta.get("name")
        return None

    @property
    def description(self) -> Any:
        if self.fm and self.fm.meta:
            return self.fm.meta.get("description")
        return None

    @property
    def display_name(self) -> str:
        n = self.name
        return n if isinstance(n, str) and n else self.folder_name

    @property
    def body(self) -> str:
        return self.fm.body if self.fm else ""


def load_skill(folder: Path) -> Skill:
    folder = Path(folder)
    md = folder / SKILL_FILE
    if not md.is_file():
        return Skill(folder, md, exists=False)
    text = normalize_newlines(md.read_text(encoding="utf-8", errors="replace"))
    return Skill(folder, md, exists=True, text=text, fm=parse_frontmatter(text))


def _visible_dirs(path: Path) -> list[Path]:
    return sorted(
        p for p in path.iterdir() if p.is_dir() and not p.name.startswith(".") and p.name not in IGNORED_NAMES
    )


def find_skill_folders(path: Path) -> tuple[list[Path], bool]:
    """Return (skill folders, is_library).

    A folder containing SKILL.md is a single skill. Otherwise every visible
    sub-folder is treated as one skill of a library.
    """
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(f"Path not found: {path}")
    if path.is_file():
        if path.name == SKILL_FILE:
            return [path.parent], False
        raise NotADirectoryError(f"Expected a skill folder or a folder of skills, got a file: {path}")
    if (path / SKILL_FILE).is_file():
        return [path], False
    subdirs = _visible_dirs(path)
    if not subdirs:
        return [path], False
    return subdirs, True


def load_skills(path: Path) -> tuple[list[Skill], bool]:
    folders, is_library = find_skill_folders(path)
    return [load_skill(f) for f in folders], is_library


def slugify(value: str) -> str:
    """Turn any text into a valid skill name: lowercase letters, digits, hyphens."""
    value = unicodedata.normalize("NFKD", str(value)).encode("ascii", "ignore").decode("ascii")
    value = re.sub(r"[^a-z0-9]+", "-", value.lower()).strip("-")
    return value[:NAME_MAX_CHARS].strip("-")


def iter_text_files(folder: Path, max_bytes: int = 2_000_000):
    """Yield (path, text) for every readable UTF-8 text file in a skill folder."""
    folder = Path(folder)
    for p in sorted(folder.rglob("*")):
        rel_parts = p.relative_to(folder).parts
        if any(part in IGNORED_NAMES or part.startswith(".") for part in rel_parts):
            continue
        if not p.is_file():
            continue
        try:
            if p.stat().st_size > max_bytes:
                continue
            data = p.read_bytes()
        except OSError:
            continue
        if b"\x00" in data:
            continue
        try:
            yield p, normalize_newlines(data.decode("utf-8"))
        except UnicodeDecodeError:
            continue
