import os
import shutil
import textwrap
from pathlib import Path

import pytest

FIXTURES = Path(__file__).parent / "fixtures"


def _make_scripts_executable(root: Path) -> None:
    for p in root.rglob("*"):
        if p.is_file() and p.parent.name == "scripts" and p.read_bytes().startswith(b"#!"):
            os.chmod(p, 0o755)


@pytest.fixture
def fixtures_dir():
    return FIXTURES


@pytest.fixture
def copy_fixture(tmp_path):
    """Copy a fixture folder into tmp_path (so tests may modify it) and return the copy."""

    def _copy(rel: str, dest_name: str | None = None) -> Path:
        src = FIXTURES / rel
        dest = tmp_path / (dest_name or Path(rel).name)
        shutil.copytree(src, dest)
        _make_scripts_executable(dest)
        return dest

    return _copy


def write_skill(parent: Path, folder: str, frontmatter: str | None = None, body: str = "Body.\n",
                files: dict | None = None) -> Path:
    """Create parent/folder/SKILL.md. frontmatter=None -> default valid one for the folder."""
    d = parent / folder
    d.mkdir(parents=True, exist_ok=True)
    if frontmatter is None:
        frontmatter = f"name: {folder}\ndescription: Does a thing. Use when testing."
    text = (f"---\n{textwrap.dedent(frontmatter).strip()}\n---\n\n" if frontmatter != "" else "") + body
    (d / "SKILL.md").write_text(text, encoding="utf-8")
    for rel, content in (files or {}).items():
        p = d / rel
        p.parent.mkdir(parents=True, exist_ok=True)
        if isinstance(content, tuple):
            content, mode = content
        else:
            mode = None
        p.write_text(content, encoding="utf-8")
        if mode is not None:
            os.chmod(p, mode)
    return d


@pytest.fixture
def make_skill(tmp_path):
    def _make(folder: str, frontmatter: str | None = None, body: str = "Body.\n", files=None, parent=None):
        return write_skill(Path(parent) if parent else tmp_path, folder, frontmatter, body, files)

    return _make
