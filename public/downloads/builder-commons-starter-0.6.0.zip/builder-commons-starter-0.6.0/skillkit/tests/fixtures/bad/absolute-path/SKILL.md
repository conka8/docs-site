---
name: absolute-path
description: Mentions paths from one computer. Use when testing.
---

Open /Users/marko/Desktop/template.docx first.
On Windows it lives in C:\Users\marko\template.docx
