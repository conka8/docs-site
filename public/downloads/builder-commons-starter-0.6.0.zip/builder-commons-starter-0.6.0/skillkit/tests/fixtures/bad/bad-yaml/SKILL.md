---
name: bad-yaml
description: [unclosed list, use when testing
---

Body.
