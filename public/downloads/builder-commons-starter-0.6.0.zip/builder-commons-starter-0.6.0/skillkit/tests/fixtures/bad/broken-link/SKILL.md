---
name: broken-link
description: Links to files that do not exist. Use when testing.
---

# Broken links

See [the guide](references/missing-guide.md) and ![logo](assets/logo.png).
Run `python scripts/does_not_exist.py` to start.
External links are fine: [docs](https://example.com/docs) and [top](#broken-links).
