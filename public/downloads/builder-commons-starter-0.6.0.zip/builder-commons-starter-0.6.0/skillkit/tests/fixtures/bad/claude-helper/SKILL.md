---
name: claude-helper
description: Uses a reserved word. Use when testing.
---

Body.
