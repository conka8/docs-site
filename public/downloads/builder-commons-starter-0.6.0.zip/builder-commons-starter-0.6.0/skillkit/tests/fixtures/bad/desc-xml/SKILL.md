---
name: desc-xml
description: Writes <b>bold</b> headlines. Use when the user needs headlines.
---

Body.
