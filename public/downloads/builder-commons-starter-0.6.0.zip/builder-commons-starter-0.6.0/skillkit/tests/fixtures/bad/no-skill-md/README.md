This folder forgot its SKILL.md.
