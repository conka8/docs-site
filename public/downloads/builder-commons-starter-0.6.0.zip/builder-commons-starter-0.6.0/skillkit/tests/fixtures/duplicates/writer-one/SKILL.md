---
name: blog-writer
description: Writes blog posts. Use when the user wants a blog post.
---

Body.
