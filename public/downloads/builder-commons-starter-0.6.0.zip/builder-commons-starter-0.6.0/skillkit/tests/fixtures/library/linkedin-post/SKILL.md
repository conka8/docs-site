---
name: linkedin-post
description: "Turns rough notes into a LinkedIn post with a hook, three short paragraphs and a call to action. Use this when the user wants a LinkedIn post."
---

# LinkedIn post

1. Ask for the topic if it is missing.
2. Write a one-line hook.
3. Return JSON with keys "hook", "body" and "cta" when the user asks for JSON.
