---
name: summarize-email
description: Summarizes a long email into three bullet points and a suggested reply. Use when the user pastes an email and asks for a summary or a reply.
---

# Summarize email

## Instructions
1. Read the email the user pasted.
2. Write exactly three bullet points starting with "Summary:".
3. Suggest a short reply. Follow the tone rules in [the style guide](references/style-guide.md).

To count words, run `python scripts/count_words.py` on the draft.
