# Style guide
- Friendly, short sentences.
- No jargon.
