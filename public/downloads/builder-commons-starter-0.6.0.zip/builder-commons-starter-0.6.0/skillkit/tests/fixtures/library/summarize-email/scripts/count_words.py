#!/usr/bin/env python3
import sys
print(len(sys.stdin.read().split()))
