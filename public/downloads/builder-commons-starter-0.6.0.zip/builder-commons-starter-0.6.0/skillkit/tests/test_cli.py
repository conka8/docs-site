import json
import os
import subprocess
import sys
import zipfile
from pathlib import Path

import pytest

from skillkit import __version__
from skillkit.cli import main

PROJECT = Path(__file__).resolve().parents[1]


# --------------------------------------------------------------- general


def test_no_command_prints_help(capsys):
    assert main([]) == 2
    assert "lint" in capsys.readouterr().out


def test_version(capsys):
    assert main(["--version"]) == 0
    assert __version__ in capsys.readouterr().out


def test_bad_usage_returns_2(capsys):
    assert main(["lint"]) == 2
    assert main(["frobnicate"]) == 2
    assert main(["lint", ".", "--format", "xml"]) == 2


def test_python_dash_m(fixtures_dir):
    env = dict(os.environ, PYTHONPATH=str(PROJECT / "src"))
    proc = subprocess.run([sys.executable, "-m", "skillkit", "lint", str(fixtures_dir / "library")],
                          capture_output=True, text=True, env=env)
    assert proc.returncode == 0, proc.stderr
    assert "All good" in proc.stdout


# --------------------------------------------------------------- lint


def test_lint_ok_exit_0(copy_fixture, capsys):
    assert main(["lint", str(copy_fixture("library"))]) == 0
    assert "Checked 2 skills: 0 errors, 0 warnings." in capsys.readouterr().out


def test_lint_errors_exit_1(copy_fixture, capsys):
    assert main(["lint", str(copy_fixture("bad"))]) == 1
    assert "[secret]" not in capsys.readouterr().out


def test_lint_warnings_only_exit_0_unless_strict(copy_fixture):
    d = copy_fixture("bad/desc-no-when")
    assert main(["lint", str(d)]) == 0
    assert main(["lint", str(d), "--strict"]) == 1


def test_lint_missing_path_exit_2(tmp_path, capsys):
    assert main(["lint", str(tmp_path / "nope")]) == 2
    assert "Path not found" in capsys.readouterr().err


def test_lint_json_format(copy_fixture, capsys):
    assert main(["lint", str(copy_fixture("duplicates")), "--format", "json"]) == 1
    data = json.loads(capsys.readouterr().out)
    assert data["errors"] == 2


def test_lint_github_format(copy_fixture, capsys):
    assert main(["lint", str(copy_fixture("bad/claude-helper")), "--format", "github"]) == 1
    out = capsys.readouterr().out
    assert out.startswith("::error file=") and "name-reserved" in out


def test_lint_fix(copy_fixture, capsys):
    d = copy_fixture("bad/folder-mismatch")
    assert main(["lint", str(d), "--fix"]) == 0
    out = capsys.readouterr().out
    assert "fixed:" in out and "All good" in out


def test_repo_example_skill_passes_lint(capsys):
    assert main(["lint", str(PROJECT / "skills"), "--strict"]) == 0


# --------------------------------------------------------------- eval


def test_eval_fake_pass(fixtures_dir, capsys):
    rc = main(["eval", str(fixtures_dir / "library"), "--cases", str(fixtures_dir / "cases" / "cases.yaml")])
    assert rc == 0
    assert "2 of 2 cases passed" in capsys.readouterr().out


def test_eval_fake_fail_exit_1(fixtures_dir, capsys):
    rc = main(["eval", str(fixtures_dir / "library"), "--cases", str(fixtures_dir / "cases" / "cases_failing.yaml"),
               "--provider", "fake"])
    assert rc == 1
    assert "[FAIL] summarize-email / three-bullets" in capsys.readouterr().out


@pytest.mark.parametrize("fmt", ["json", "html"])
def test_eval_report_to_file(fixtures_dir, tmp_path, capsys, fmt):
    out = tmp_path / "reports" / f"report.{fmt}"
    rc = main(["eval", str(fixtures_dir / "library"), "--cases", str(fixtures_dir / "cases" / "cases.yaml"),
               "--format", fmt, "-o", str(out)])
    assert rc == 0
    stdout = capsys.readouterr().out
    assert "2 of 2 cases passed" in stdout and f"Report written to {out}" in stdout
    text = out.read_text()
    if fmt == "json":
        assert json.loads(text)["summary"]["passed"] == 2
    else:
        assert text.startswith("<!doctype html>")


def test_eval_json_to_stdout(fixtures_dir, capsys):
    main(["eval", str(fixtures_dir / "library"), "--cases", str(fixtures_dir / "cases" / "cases.yaml"),
          "--format", "json"])
    assert json.loads(capsys.readouterr().out)["provider"] == "fake"


def test_eval_baseline_regression_flow(fixtures_dir, tmp_path, capsys):
    lib = str(fixtures_dir / "library")
    baseline = tmp_path / "baseline.json"
    assert main(["eval", lib, "--cases", str(fixtures_dir / "cases" / "cases.yaml"),
                 "--format", "json", "-o", str(baseline)]) == 0
    capsys.readouterr()
    rc = main(["eval", lib, "--cases", str(fixtures_dir / "cases" / "cases_failing.yaml"),
               "--baseline", str(baseline)])
    assert rc == 1
    out = capsys.readouterr().out
    assert "REGRESSIONS (1)" in out and "summarize-email::three-bullets" in out


def test_eval_baseline_failures_without_regressions_exit_0(fixtures_dir, tmp_path, capsys):
    lib = str(fixtures_dir / "library")
    cases = str(fixtures_dir / "cases" / "cases_failing.yaml")
    baseline = tmp_path / "b.json"
    main(["eval", lib, "--cases", cases, "--format", "json", "-o", str(baseline)])
    assert main(["eval", lib, "--cases", cases, "--baseline", str(baseline)]) == 0
    assert "No regressions" in capsys.readouterr().out


def test_eval_anthropic_via_injected_transport(fixtures_dir, capsys):
    calls = []

    def transport(url, headers, body, timeout):
        calls.append((url, headers, json.loads(body)))
        return 200, json.dumps({"content": [{"type": "text", "text": "Summary: a\nSummary: b\nSummary: c"}]}).encode()

    rc = main(["eval", str(fixtures_dir / "library" / "summarize-email"),
               "--cases", str(fixtures_dir / "cases" / "cases.yaml"), "--provider", "anthropic",
               "--model", "claude-test", "--max-tokens", "50"],
              transport=transport, environ={"ANTHROPIC_API_KEY": "k-123"})
    out = capsys.readouterr().out
    # linkedin-post is not in this single-skill folder -> that case errors, so exit 1
    assert rc == 1 and "Skill 'linkedin-post' not found" in out
    url, headers, body = calls[0]
    assert url == "https://api.anthropic.com/v1/messages"
    assert headers["x-api-key"] == "k-123" and headers["anthropic-version"] == "2023-06-01"
    assert body["model"] == "claude-test" and body["max_tokens"] == 50
    assert body["system"].startswith("# Summarize email")
    # second call is the llm_rubric judge
    assert len(calls) == 2 and "Rubric:" in calls[1][2]["messages"][0]["content"]


def test_eval_openai_via_injected_transport(fixtures_dir, capsys):
    def transport(url, headers, body, timeout):
        assert headers["Authorization"] == "Bearer sk-test"
        return 200, json.dumps({"choices": [{"message": {"content": '{"hook":1,"body":2,"cta":3}'}}]}).encode()

    cases = fixtures_dir / "cases" / "cases.yaml"
    rc = main(["eval", str(fixtures_dir / "library" / "linkedin-post"), "--cases", str(cases),
               "--provider", "openai"], transport=transport, environ={"OPENAI_API_KEY": "sk-test"})
    out = capsys.readouterr().out
    assert "[PASS] linkedin-post / json-post" in out
    assert rc == 1  # the summarize-email case cannot run against this single skill


def test_eval_missing_key_exit_2(fixtures_dir, capsys):
    rc = main(["eval", str(fixtures_dir / "library"), "--cases", str(fixtures_dir / "cases" / "cases.yaml"),
               "--provider", "anthropic"], environ={})
    assert rc == 2
    assert "ANTHROPIC_API_KEY is not set" in capsys.readouterr().err


def test_eval_bad_cases_exit_2(fixtures_dir, tmp_path, capsys):
    bad = tmp_path / "c.yaml"
    bad.write_text("cases: []\n")
    assert main(["eval", str(fixtures_dir / "library"), "--cases", str(bad)]) == 2
    assert "No cases found" in capsys.readouterr().err
    assert main(["eval", str(fixtures_dir / "library"), "--cases", str(tmp_path / "none.yaml")]) == 2


def test_eval_bad_baseline_exit_2(fixtures_dir, tmp_path, capsys):
    assert main(["eval", str(fixtures_dir / "library"), "--cases", str(fixtures_dir / "cases" / "cases.yaml"),
                 "--baseline", str(tmp_path / "missing.json")]) == 2


def test_eval_missing_path_exit_2(fixtures_dir, tmp_path):
    assert main(["eval", str(tmp_path / "nope"), "--cases", str(fixtures_dir / "cases" / "cases.yaml")]) == 2


# --------------------------------------------------------------- pack


def test_pack_plugin_cli(copy_fixture, tmp_path, capsys):
    out = tmp_path / "dist"
    rc = main(["pack", str(copy_fixture("library")), "-o", str(out), "--name", "creator-skills",
               "--version", "1.0.0", "--author", "Jane Doe", "--marketplace", "--zip"])
    assert rc == 0
    stdout = capsys.readouterr().out
    assert "Packed 2 skill(s)" in stdout and "marketplace:" in stdout and "zip:" in stdout
    assert json.loads((out / "creator-skills" / ".claude-plugin" / "plugin.json").read_text())["author"] == {
        "name": "Jane Doe"}
    assert json.loads((out / ".claude-plugin" / "marketplace.json").read_text())["owner"] == {"name": "Jane Doe"}
    assert zipfile.is_zipfile(out / "creator-skills-1.0.0.zip")


def test_pack_refuses_on_lint_errors(copy_fixture, tmp_path, capsys):
    out = tmp_path / "dist"
    rc = main(["pack", str(copy_fixture("duplicates")), "-o", str(out), "--name", "x", "--author", "A"])
    assert rc == 1
    captured = capsys.readouterr()
    assert "not packing" in captured.err and "duplicate-name" in captured.out
    assert not out.exists()


def test_pack_force(copy_fixture, tmp_path, capsys):
    out = tmp_path / "dist"
    rc = main(["pack", str(copy_fixture("duplicates")), "-o", str(out), "--name", "x", "--author", "A", "--force"])
    assert rc == 0
    assert "packing anyway" in capsys.readouterr().out
    assert (out / "x" / "skills" / "writer-one" / "SKILL.md").is_file()


def test_pack_clawhub_cli(copy_fixture, tmp_path, capsys):
    out = tmp_path / "hub"
    rc = main(["pack", str(copy_fixture("library")), "-o", str(out), "--name", "creator-skills", "--author", "A",
               "--format", "clawhub", "--marketplace"])
    assert rc == 0
    stdout = capsys.readouterr().out
    assert "verify against current ClawHub requirements" in stdout and "ignored" in stdout
    assert json.loads((out / "creator-skills" / "index.json").read_text())["version"] == "1.0.0"


def test_pack_bad_name_exit_2(copy_fixture, tmp_path, capsys):
    rc = main(["pack", str(copy_fixture("library")), "-o", str(tmp_path / "o"), "--name", "Bad Name", "--author", "A"])
    assert rc == 2
    assert "--name" in capsys.readouterr().err


def test_pack_missing_library_exit_2(tmp_path):
    assert main(["pack", str(tmp_path / "nope"), "-o", str(tmp_path / "o"), "--name", "x", "--author", "A"]) == 2


def test_pack_requires_args():
    assert main(["pack", "lib"]) == 2


# --------------------------------------------------------------- new


def test_new_cli(tmp_path, capsys):
    assert main(["new", "my-recipe", "--dir", str(tmp_path), "--description", "Does X. Use when Y."]) == 0
    assert "Created" in capsys.readouterr().out
    assert main(["lint", str(tmp_path / "my-recipe"), "--strict"]) == 0


def test_new_cli_errors(tmp_path, capsys):
    assert main(["new", "Bad Name", "--dir", str(tmp_path)]) == 1
    assert "bad-name" in capsys.readouterr().err
    main(["new", "twice", "--dir", str(tmp_path)])
    assert main(["new", "twice", "--dir", str(tmp_path)]) == 1
