import json

import pytest

from skillkit.evaluate import (
    Case,
    CasesError,
    check_assertion,
    compare_to_baseline,
    judge,
    load_baseline,
    load_cases,
    load_skill_prompts,
    parse_cases,
    render_html,
    render_json,
    render_report,
    render_text,
    run_case,
    run_eval,
)
from skillkit.providers import FakeProvider, OpenAIProvider, ProviderError


def tick_clock(step=0.25):
    t = [0.0]

    def clock():
        t[0] += step
        return t[0]

    return clock


# --------------------------------------------------------------- loading


def test_load_cases_list_format(fixtures_dir):
    cases, settings = load_cases(fixtures_dir / "cases" / "cases.yaml")
    assert settings == {"provider": "fake"}
    assert [c.id for c in cases] == ["three-bullets", "json-post"]
    assert cases[0].skill == "summarize-email"
    assert ("max_chars", 400) in cases[0].assertions
    assert cases[1].assertions[1] == ("json_has_keys", ["hook", "body", "cta"])


def test_load_cases_skills_mapping_format(fixtures_dir):
    cases, _ = load_cases(fixtures_dir / "cases" / "cases_failing.yaml")
    assert [(c.skill, c.id) for c in cases] == [("summarize-email", "three-bullets"), ("linkedin-post", "json-post")]
    assert cases[0].fake_judge.startswith("FAIL")


def test_parse_cases_type_value_form_and_defaults():
    cases, settings = parse_cases({"model": "m", "cases": [
        {"input": "hi", "assert": [{"type": "contains", "value": "x"}, {"type": "json_valid"}]}]})
    assert settings == {"model": "m"}
    assert cases[0].id == "case-1" and cases[0].skill is None
    assert cases[0].assertions == [("contains", "x"), ("json_valid", True)]


def test_parse_cases_skills_as_plain_list():
    cases, _ = parse_cases({"skills": {"a": [{"input": "x"}]}})
    assert cases[0].skill == "a" and cases[0].assertions == []


@pytest.mark.parametrize(
    "data,msg",
    [
        ([1, 2], "must be a YAML mapping"),
        ({}, "No cases found"),
        ({"cases": [{"id": "x"}]}, "has no 'input'"),
        ({"cases": ["just a string"]}, "must be a mapping"),
        ({"cases": [{"input": "x", "assert": "contains"}]}, "must be a list"),
        ({"cases": [{"input": "x", "assert": [{"contains": "a", "regex": "b"}]}]}, "each assertion"),
        ({"cases": [{"input": "x", "assert": [{"sounds_good": True}]}]}, "unknown assertion"),
        ({"cases": [{"id": "a", "input": "x"}, {"id": "a", "input": "y"}]}, "Duplicate case id"),
        ({"skills": {"a": {"nope": 1}}}, "must have a 'cases:' list"),
    ],
)
def test_parse_cases_errors(data, msg):
    with pytest.raises(CasesError, match=msg):
        parse_cases(data)


def test_load_cases_file_errors(tmp_path):
    with pytest.raises(CasesError, match="not found"):
        load_cases(tmp_path / "missing.yaml")
    bad = tmp_path / "bad.yaml"
    bad.write_text("cases: [unclosed")
    with pytest.raises(CasesError, match="not valid YAML"):
        load_cases(bad)


def test_load_skill_prompts(fixtures_dir, make_skill):
    prompts = load_skill_prompts(fixtures_dir / "library")
    assert set(prompts) == {"summarize-email", "linkedin-post"}
    assert prompts["summarize-email"].startswith("# Summarize email")
    assert "---" not in prompts["summarize-email"].splitlines()[0]
    d = make_skill("folder-a", "name: other-name\ndescription: x. Use when.")
    assert set(load_skill_prompts(d)) == {"folder-a", "other-name"}
    nofm = make_skill("raw", frontmatter="", body="Just text")
    assert load_skill_prompts(nofm) == {"raw": "Just text"}


# --------------------------------------------------------------- assertions


@pytest.mark.parametrize(
    "atype,expected,output,ok",
    [
        ("contains", "hello", "Say HELLO world", True),
        ("contains", ["hello", "world"], "hello there", False),
        ("not_contains", "As an AI", "Fine answer", True),
        ("not_contains", ["foo", "bar"], "has BAR", False),
        ("regex", r"^\d{3}$", "abc\n123\n", True),
        ("regex", r"^\d{3}$", "abc", False),
        ("regex", r"([", "x", False),
        ("max_chars", 5, "12345", True),
        ("max_chars", "5", "123456", False),
        ("max_chars", "lots", "x", False),
        ("json_valid", True, '{"a": 1}', True),
        ("json_valid", True, '```json\n{"a": 1}\n```', True),
        ("json_valid", True, "not json", False),
        ("json_valid", False, "plain text", True),
        ("json_has_keys", ["a", "b"], '{"a": 1, "b": 2}', True),
        ("json_has_keys", "a", '{"b": 2}', False),
        ("json_has_keys", ["a"], "[1, 2]", False),
        ("json_has_keys", ["a"], "nope", False),
        ("bogus", 1, "x", False),
    ],
)
def test_check_assertion(atype, expected, output, ok):
    r = check_assertion(atype, expected, output)
    assert r.passed is ok
    assert r.type == atype
    if not ok:
        assert r.detail


def test_llm_rubric_assertion():
    assert check_assertion("llm_rubric", "polite", "x", lambda rubric: (True, "PASS ok")).passed
    r = check_assertion("llm_rubric", "polite", "x", lambda rubric: (False, "FAIL rude"))
    assert not r.passed and r.detail == "FAIL rude"
    assert not check_assertion("llm_rubric", "polite", "x", None).passed

    def boom(_):
        raise ProviderError("down")

    r = check_assertion("llm_rubric", "polite", "x", boom)
    assert not r.passed and "judge error" in r.detail


@pytest.mark.parametrize("verdict,ok", [("PASS", True), ("pass: fine", True), ("PASS. good", True),
                                        ("FAIL - bad", False), ("", False), ("PASSABLE", False),
                                        ("I think it should PASS", False)])
def test_judge_parsing(verdict, ok):
    case = Case(None, "c", "in", [], fake_judge=verdict or " ")
    passed, text = judge(FakeProvider(), "rubric", "output", case)
    assert passed is ok


def test_judge_sends_rubric_and_output():
    p = FakeProvider()
    judge(p, "Must be polite", "the answer", Case(None, "c", "in", []))
    call = p.calls[-1]
    assert call["purpose"] == "judge"
    assert "Must be polite" in call["user"] and "the answer" in call["user"]
    assert "PASS or FAIL" in call["system"]


# --------------------------------------------------------------- running


def test_run_eval_fake_all_pass(fixtures_dir):
    cases, _ = load_cases(fixtures_dir / "cases" / "cases.yaml")
    report = run_eval(fixtures_dir / "library", cases, FakeProvider(), clock=tick_clock())
    assert report["summary"] == {"total": 2, "passed": 2, "failed": 0}
    assert report["provider"] == "fake" and report["comparison"] is None
    r0 = report["results"][0]
    assert r0["latency_ms"] == 250.0
    assert len(r0["assertions"]) == 5 and all(a["passed"] for a in r0["assertions"])


def test_run_eval_sends_skill_body_as_system_prompt(fixtures_dir):
    cases, _ = load_cases(fixtures_dir / "cases" / "cases.yaml")
    p = FakeProvider()
    run_eval(fixtures_dir / "library", cases, p)
    answers = [c for c in p.calls if c["purpose"] == "answer"]
    assert answers[0]["system"].startswith("# Summarize email")
    assert answers[0]["user"] == cases[0].input
    assert answers[1]["system"].startswith("# LinkedIn post")


def test_run_eval_failures(fixtures_dir):
    cases, _ = load_cases(fixtures_dir / "cases" / "cases_failing.yaml")
    report = run_eval(fixtures_dir / "library", cases, FakeProvider())
    assert report["summary"] == {"total": 2, "passed": 1, "failed": 1}
    failed = report["results"][0]
    assert [a["passed"] for a in failed["assertions"]] == [False, False, False]


def test_run_eval_single_skill_without_skill_field(fixtures_dir):
    cases, _ = parse_cases({"cases": [{"input": "x", "fake_response": "Summary: hi",
                                       "assert": [{"contains": "summary"}]}]})
    report = run_eval(fixtures_dir / "library" / "summarize-email", cases, FakeProvider())
    assert report["results"][0]["skill"] == "summarize-email" and report["summary"]["passed"] == 1


def test_run_eval_unknown_or_ambiguous_skill(fixtures_dir):
    cases, _ = parse_cases({"cases": [{"id": "a", "input": "x"}, {"id": "b", "skill": "ghost", "input": "x"}]})
    report = run_eval(fixtures_dir / "library", cases, FakeProvider())
    assert report["summary"]["failed"] == 2
    assert "several skills" in report["results"][0]["error"]
    assert "'ghost' not found" in report["results"][1]["error"]


def test_run_eval_no_skills(tmp_path):
    with pytest.raises(CasesError, match="No skills"):
        run_eval(tmp_path, [Case(None, "a", "x", [])], FakeProvider())


def test_run_case_provider_error_recorded():
    def failing_transport(url, headers, body, timeout):
        return 503, b"overloaded"

    p = OpenAIProvider(api_key="k", environ={}, transport=failing_transport)
    r = run_case(Case("s", "c", "hi", [("contains", "x")]), "system", p, clock=tick_clock())
    assert not r.passed and "HTTP 503" in r.error and r.latency_ms == 250.0 and r.assertions == []


def test_run_case_with_http_transport_and_llm_rubric():
    """Answer + judge both go through the (faked) OpenAI HTTP transport."""
    replies = iter(["The answer is 42.", "PASS - correct"])
    bodies = []

    def transport(url, headers, body, timeout):
        bodies.append(json.loads(body))
        return 200, json.dumps({"choices": [{"message": {"content": next(replies)}}]}).encode()

    p = OpenAIProvider(api_key="k", environ={}, transport=transport)
    case = Case("s", "c", "What is 6*7?", [("contains", "42"), ("llm_rubric", "Answers 42")])
    r = run_case(case, "You are a calculator.", p)
    assert r.passed and r.output == "The answer is 42."
    assert bodies[0]["messages"][0] == {"role": "system", "content": "You are a calculator."}
    assert "Answers 42" in bodies[1]["messages"][1]["content"]
    assert "The answer is 42." in bodies[1]["messages"][1]["content"]


# --------------------------------------------------------------- baseline


def _report(results):
    return {"results": [{"skill": s, "case_id": c, "passed": p} for s, c, p in results], "created": "t0",
            "model": "m0"}


def test_compare_to_baseline():
    baseline = _report([("a", "1", True), ("a", "2", False), ("a", "3", True), ("b", "gone", True)])
    now = _report([("a", "1", False), ("a", "2", True), ("a", "3", True), ("c", "new", False)])
    cmp_ = compare_to_baseline(now, baseline)
    assert cmp_["regressions"] == ["a::1"]
    assert cmp_["fixed"] == ["a::2"]
    assert cmp_["new"] == ["c::new"]
    assert cmp_["missing"] == ["b::gone"]
    assert now["comparison"] is cmp_ and cmp_["baseline_model"] == "m0"


def test_new_failing_case_is_not_a_regression():
    cmp_ = compare_to_baseline(_report([("a", "x", False)]), _report([]))
    assert cmp_["regressions"] == [] and cmp_["new"] == ["a::x"]


def test_load_baseline(tmp_path):
    good = tmp_path / "b.json"
    good.write_text(json.dumps({"results": []}))
    assert load_baseline(good) == {"results": []}
    with pytest.raises(CasesError, match="not found"):
        load_baseline(tmp_path / "nope.json")
    bad = tmp_path / "bad.json"
    bad.write_text("{nope")
    with pytest.raises(CasesError, match="not valid JSON"):
        load_baseline(bad)
    wrong = tmp_path / "wrong.json"
    wrong.write_text("[1]")
    with pytest.raises(CasesError, match="not a skillkit JSON report"):
        load_baseline(wrong)


# --------------------------------------------------------------- reports


@pytest.fixture
def failing_report(fixtures_dir):
    cases, _ = load_cases(fixtures_dir / "cases" / "cases_failing.yaml")
    report = run_eval(fixtures_dir / "library", cases, FakeProvider())
    report["results"].append({"skill": "x", "case_id": "boom", "input": "i", "passed": False, "latency_ms": 0.0,
                              "output": "", "error": "HTTP 500 <oops>", "assertions": []})
    report["summary"] = {"total": 3, "passed": 1, "failed": 2}
    return report


def test_render_text(failing_report):
    out = render_text(failing_report)
    assert "[FAIL] summarize-email / three-bullets" in out
    assert "[PASS] linkedin-post / json-post" in out
    assert "contains 'Summary:' failed" in out
    assert "error: HTTP 500" in out
    assert "1 of 3 cases passed, 2 failed." in out


def test_render_text_with_comparison(failing_report):
    baseline = _report([("summarize-email", "three-bullets", True), ("linkedin-post", "json-post", False)])
    compare_to_baseline(failing_report, baseline)
    out = render_text(failing_report)
    assert "REGRESSIONS (1)" in out and "summarize-email::three-bullets" in out
    assert "Fixed since baseline: linkedin-post::json-post" in out
    assert "New cases (not in baseline): x::boom" in out
    compare_to_baseline(failing_report, _report([]))
    assert "No regressions" in render_text(failing_report)


def test_render_json_roundtrip(failing_report):
    data = json.loads(render_json(failing_report))
    assert data["summary"]["total"] == 3
    assert data["results"][0]["assertions"][0]["type"] == "contains"


def test_render_html_escapes_and_is_self_contained(failing_report):
    failing_report["results"][0]["output"] = "<script>alert(1)</script>"
    compare_to_baseline(failing_report, _report([("summarize-email", "three-bullets", True)]))
    out = render_html(failing_report)
    assert out.startswith("<!doctype html>")
    assert "<script>" not in out and "&lt;script&gt;" in out
    assert "&lt;oops&gt;" in out
    assert "<style>" in out and "http" not in out.split("<body>")[0].replace("http-equiv", "")
    assert "Regressions" in out and "@media print" in out


def test_render_html_no_regressions(failing_report):
    compare_to_baseline(failing_report, _report([]))
    assert "No regressions" in render_html(failing_report)


def test_render_report_dispatch(failing_report):
    assert render_report(failing_report, "json").startswith("{")
    with pytest.raises(ValueError):
        render_report(failing_report, "pdf")
