import json
import os
import stat
import zipfile

import pytest

from skillkit.pack import PackError, pack_clawhub, pack_plugin, validate_inputs


def test_pack_plugin_structure(copy_fixture, tmp_path):
    lib = copy_fixture("library")
    out = tmp_path / "dist"
    res = pack_plugin(lib, out, "creator-skills", "1.2.0", "Jane Doe", "Skills for creators")
    root = out / "creator-skills"
    assert res.root == root and res.skills == ["linkedin-post", "summarize-email"]
    manifest = json.loads((root / ".claude-plugin" / "plugin.json").read_text())
    assert manifest == {"name": "creator-skills", "version": "1.2.0", "description": "Skills for creators",
                        "author": {"name": "Jane Doe"}}
    assert (root / "skills" / "summarize-email" / "SKILL.md").is_file()
    assert (root / "skills" / "summarize-email" / "references" / "style-guide.md").is_file()
    assert (root / "skills" / "linkedin-post" / "SKILL.md").is_file()
    assert res.marketplace is None and res.zip_path is None
    assert not (out / ".claude-plugin").exists()


def test_pack_plugin_default_description(copy_fixture, tmp_path):
    res = pack_plugin(copy_fixture("library"), tmp_path / "o", "x", "1.0.0", "Ann")
    assert json.loads(res.manifest.read_text())["description"] == "2 skills by Ann."


def test_pack_plugin_marketplace(copy_fixture, tmp_path):
    out = tmp_path / "dist"
    res = pack_plugin(copy_fixture("library"), out, "creator-skills", "1.0.0", "Jane", "Desc",
                      marketplace=True, marketplace_name="jane-market")
    data = json.loads((out / ".claude-plugin" / "marketplace.json").read_text())
    assert res.marketplace == out / ".claude-plugin" / "marketplace.json"
    assert data == {"name": "jane-market", "owner": {"name": "Jane"},
                    "plugins": [{"name": "creator-skills", "source": "./creator-skills",
                                 "description": "Desc", "version": "1.0.0"}]}
    res2 = pack_plugin(copy_fixture("library", "lib2"), tmp_path / "d2", "abc", "1.0.0", "J", marketplace=True)
    assert json.loads(res2.marketplace.read_text())["name"] == "abc-marketplace"


def test_pack_plugin_zip_contents(copy_fixture, tmp_path):
    out = tmp_path / "dist"
    res = pack_plugin(copy_fixture("library"), out, "creator-skills", "1.0.0", "Jane", marketplace=True,
                      make_zip=True)
    assert res.zip_path == out / "creator-skills-1.0.0.zip"
    with zipfile.ZipFile(res.zip_path) as zf:
        names = set(zf.namelist())
        assert {
            ".claude-plugin/marketplace.json",
            "creator-skills/.claude-plugin/plugin.json",
            "creator-skills/skills/summarize-email/SKILL.md",
            "creator-skills/skills/summarize-email/scripts/count_words.py",
            "creator-skills/skills/summarize-email/references/style-guide.md",
            "creator-skills/skills/linkedin-post/SKILL.md",
        } == names
        json.loads(zf.read("creator-skills/.claude-plugin/plugin.json"))
        if os.name != "nt":
            mode = zf.getinfo("creator-skills/skills/summarize-email/scripts/count_words.py").external_attr >> 16
            assert mode & stat.S_IXUSR


def test_pack_skips_junk_and_hidden(copy_fixture, tmp_path):
    lib = copy_fixture("library")
    (lib / "summarize-email" / ".DS_Store").write_text("x")
    (lib / "summarize-email" / "__pycache__").mkdir()
    (lib / "summarize-email" / "__pycache__" / "a.pyc").write_bytes(b"x")
    (lib / ".git").mkdir()
    res = pack_plugin(lib, tmp_path / "o", "x", "1.0.0", "A")
    copied = res.root / "skills" / "summarize-email"
    assert not (copied / ".DS_Store").exists() and not (copied / "__pycache__").exists()
    assert res.skills == ["linkedin-post", "summarize-email"]


def test_pack_overwrites_previous_output(copy_fixture, tmp_path):
    lib = copy_fixture("library")
    out = tmp_path / "o"
    pack_plugin(lib, out, "x", "1.0.0", "A")
    stale = out / "x" / "skills" / "old-skill"
    stale.mkdir()
    pack_plugin(lib, out, "x", "1.0.1", "A")
    assert not stale.exists()


def test_pack_single_skill_folder(copy_fixture, tmp_path):
    res = pack_plugin(copy_fixture("library/linkedin-post"), tmp_path / "o", "one", "0.1.0", "A")
    assert res.skills == ["linkedin-post"]


def test_pack_errors(copy_fixture, tmp_path):
    lib = copy_fixture("library")
    with pytest.raises(PackError, match="outside"):
        pack_plugin(lib, lib / "dist", "x", "1.0.0", "A")
    with pytest.raises(PackError, match="No skills"):
        pack_plugin(copy_fixture("bad/no-skill-md"), tmp_path / "o", "x", "1.0.0", "A")
    with pytest.raises(PackError, match="No skills"):
        pack_clawhub(copy_fixture("bad/no-skill-md", "nsm2"), tmp_path / "o2", "x", "1.0.0", "A")


@pytest.mark.parametrize("name,version", [("Bad Name", "1.0.0"), ("", "1.0.0"), ("ok", "v1"), ("ok", "1.0"),
                                          ("a" * 65, "1.0.0")])
def test_validate_inputs_rejects(name, version):
    with pytest.raises(PackError):
        validate_inputs(name, version)


@pytest.mark.parametrize("version", ["0.1.0", "10.20.30", "1.0.0-beta.1", "1.0.0+build"])
def test_validate_inputs_accepts(version):
    validate_inputs("ok-name", version)


def test_pack_clawhub(copy_fixture, tmp_path):
    lib = copy_fixture("library")
    md = lib / "linkedin-post" / "SKILL.md"
    md.write_text(md.read_text().replace("name: linkedin-post\n", "name: linkedin-post\nversion: 2.0.0\n"))
    out = tmp_path / "hub"
    res = pack_clawhub(lib, out, "creator-skills", "1.0.0", "Jane", make_zip=True)
    root = out / "creator-skills"
    assert (root / "summarize-email" / "SKILL.md").is_file()
    assert (root / "linkedin-post" / "SKILL.md").is_file()
    index = json.loads((root / "index.json").read_text())
    assert index["name"] == "creator-skills" and index["author"] == "Jane" and index["version"] == "1.0.0"
    by_name = {s["name"]: s for s in index["skills"]}
    assert by_name["linkedin-post"]["version"] == "2.0.0"
    assert by_name["summarize-email"]["version"] == "1.0.0"
    assert by_name["summarize-email"]["description"].startswith("Summarizes a long email")
    assert by_name["summarize-email"]["path"] == "summarize-email/SKILL.md"
    assert res.zip_path.name == "creator-skills-1.0.0-clawhub.zip"
    with zipfile.ZipFile(res.zip_path) as zf:
        assert "creator-skills/index.json" in zf.namelist()


def test_pack_clawhub_metadata_version(make_skill, tmp_path):
    lib = tmp_path / "lib"
    make_skill("meta-skill", "name: meta-skill\ndescription: x. Use when.\nmetadata:\n  version: 3.1.0", parent=lib)
    res = pack_clawhub(lib, tmp_path / "out", "b", "1.0.0", "A")
    assert json.loads(res.manifest.read_text())["skills"][0]["version"] == "3.1.0"
