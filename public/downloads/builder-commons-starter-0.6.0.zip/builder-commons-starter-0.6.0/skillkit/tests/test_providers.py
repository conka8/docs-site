import io
import json
import urllib.error

import pytest

from skillkit import constants as C
from skillkit import providers
from skillkit.providers import (
    AnthropicProvider,
    FakeProvider,
    OpenAIProvider,
    ProviderError,
    make_provider,
    urllib_transport,
)


class RecordingTransport:
    def __init__(self, status=200, payload=None, raw=None):
        self.status, self.payload, self.raw = status, payload, raw
        self.calls = []

    def __call__(self, url, headers, body, timeout):
        self.calls.append({"url": url, "headers": headers, "body": json.loads(body), "timeout": timeout})
        raw = self.raw if self.raw is not None else json.dumps(self.payload).encode()
        return self.status, raw


ANTHROPIC_OK = {"content": [{"type": "text", "text": "Hello "}, {"type": "tool_use", "id": "x"},
                            {"type": "text", "text": "world"}]}
OPENAI_OK = {"choices": [{"message": {"role": "assistant", "content": "Hi there"}}]}


def test_anthropic_request_shape():
    t = RecordingTransport(payload=ANTHROPIC_OK)
    p = AnthropicProvider(api_key="test-key", transport=t, max_tokens=321, timeout=9)
    assert p.complete("SYSTEM PROMPT", "user msg") == "Hello world"
    call = t.calls[0]
    assert call["url"] == "https://api.anthropic.com/v1/messages"
    assert call["headers"]["x-api-key"] == "test-key"
    assert call["headers"]["anthropic-version"] == "2023-06-01"
    assert call["headers"]["content-type"] == "application/json"
    assert call["body"] == {
        "model": "claude-sonnet-5-5",
        "max_tokens": 321,
        "system": "SYSTEM PROMPT",
        "messages": [{"role": "user", "content": "user msg"}],
    }
    assert call["timeout"] == 9


def test_anthropic_key_from_env_and_custom_model():
    t = RecordingTransport(payload=ANTHROPIC_OK)
    p = AnthropicProvider(model="claude-opus-5-5", environ={"ANTHROPIC_API_KEY": "env-key"}, transport=t)
    p.complete("s", "u")
    assert t.calls[0]["headers"]["x-api-key"] == "env-key"
    assert t.calls[0]["body"]["model"] == "claude-opus-5-5"


def test_anthropic_missing_key():
    with pytest.raises(ProviderError, match="ANTHROPIC_API_KEY is not set"):
        AnthropicProvider(environ={})


def test_anthropic_http_error():
    t = RecordingTransport(status=401, payload={"error": {"message": "invalid x-api-key"}})
    p = AnthropicProvider(api_key="k", transport=t)
    with pytest.raises(ProviderError, match="HTTP 401.*invalid x-api-key"):
        p.complete("s", "u")


def test_anthropic_bad_json_and_shape():
    with pytest.raises(ProviderError, match="invalid JSON"):
        AnthropicProvider(api_key="k", transport=RecordingTransport(raw=b"<html>")).complete("s", "u")
    with pytest.raises(ProviderError, match="no 'content'"):
        AnthropicProvider(api_key="k", transport=RecordingTransport(payload={"x": 1})).complete("s", "u")


def test_openai_request_shape():
    t = RecordingTransport(payload=OPENAI_OK)
    p = OpenAIProvider(api_key="oa-key", transport=t, environ={})
    assert p.complete("SYS", "USER") == "Hi there"
    call = t.calls[0]
    assert call["url"] == "https://api.openai.com/v1/chat/completions"
    assert call["headers"]["Authorization"] == "Bearer oa-key"
    assert call["headers"]["Content-Type"] == "application/json"
    assert call["body"]["model"] == C.OPENAI_DEFAULT_MODEL
    assert call["body"]["messages"] == [{"role": "system", "content": "SYS"}, {"role": "user", "content": "USER"}]
    assert call["body"]["max_tokens"] == C.DEFAULT_MAX_TOKENS


def test_openai_base_url_override():
    t = RecordingTransport(payload=OPENAI_OK)
    p = OpenAIProvider(environ={"OPENAI_API_KEY": "k", "OPENAI_BASE_URL": "https://openrouter.ai/api/v1/"},
                       transport=t)
    p.complete("s", "u")
    assert t.calls[0]["url"] == "https://openrouter.ai/api/v1/chat/completions"


def test_openai_errors():
    with pytest.raises(ProviderError, match="OPENAI_API_KEY"):
        OpenAIProvider(environ={})
    with pytest.raises(ProviderError, match="choices"):
        OpenAIProvider(api_key="k", environ={}, transport=RecordingTransport(payload={"choices": []})).complete("s", "u")
    with pytest.raises(ProviderError, match="HTTP 500"):
        OpenAIProvider(api_key="k", environ={}, transport=RecordingTransport(status=500, raw=b"oops")).complete("s", "u")


def test_openai_null_content_is_empty_string():
    t = RecordingTransport(payload={"choices": [{"message": {"content": None}}]})
    assert OpenAIProvider(api_key="k", environ={}, transport=t).complete("s", "u") == ""


class _Case:
    fake_response = {"a": 1}
    fake_judge = "FAIL: nope"


def test_fake_provider():
    p = FakeProvider()
    assert p.complete("s", "u", case=_Case()) == '{"a": 1}'
    assert p.complete("s", "u", case=_Case(), purpose="judge") == "FAIL: nope"
    assert p.complete("s", "u") == ""
    assert p.complete("s", "u", purpose="judge").startswith("PASS")
    assert len(p.calls) == 4 and p.calls[0]["system"] == "s"
    assert p.model == "fake"


def test_make_provider():
    assert isinstance(make_provider("fake"), FakeProvider)
    t = RecordingTransport(payload=OPENAI_OK)
    p = make_provider("openai", model="m", transport=t, environ={"OPENAI_API_KEY": "k"})
    assert isinstance(p, OpenAIProvider) and p.model == "m" and p.transport is t
    assert isinstance(make_provider("anthropic", environ={"ANTHROPIC_API_KEY": "k"}), AnthropicProvider)
    with pytest.raises(ProviderError, match="Unknown provider"):
        make_provider("gemini")


def test_default_transport_is_urllib():
    assert FakeProvider().transport is urllib_transport


# urllib_transport with urlopen faked (no network)


class _Resp(io.BytesIO):
    status = 201

    def __enter__(self):
        return self

    def __exit__(self, *a):
        return False


def test_urllib_transport_success(monkeypatch):
    seen = {}

    def fake_urlopen(req, timeout):
        seen.update(url=req.full_url, method=req.get_method(), data=req.data,
                    headers=dict(req.header_items()), timeout=timeout)
        return _Resp(b'{"ok": true}')

    monkeypatch.setattr(providers.urllib.request, "urlopen", fake_urlopen)
    status, body = urllib_transport("https://x.test/v1", {"X-Api-Key": "k"}, b"{}", 5)
    assert (status, body) == (201, b'{"ok": true}')
    assert seen["method"] == "POST" and seen["data"] == b"{}" and seen["timeout"] == 5
    assert seen["headers"]["X-api-key"] == "k"


def test_urllib_transport_http_error(monkeypatch):
    def fake_urlopen(req, timeout):
        raise urllib.error.HTTPError(req.full_url, 429, "Too Many", {}, io.BytesIO(b"slow down"))

    monkeypatch.setattr(providers.urllib.request, "urlopen", fake_urlopen)
    assert urllib_transport("https://x.test", {}, b"", 1) == (429, b"slow down")


def test_urllib_transport_connection_error(monkeypatch):
    def fake_urlopen(req, timeout):
        raise urllib.error.URLError("no route")

    monkeypatch.setattr(providers.urllib.request, "urlopen", fake_urlopen)
    with pytest.raises(ProviderError, match="Could not reach"):
        urllib_transport("https://x.test", {}, b"", 1)
