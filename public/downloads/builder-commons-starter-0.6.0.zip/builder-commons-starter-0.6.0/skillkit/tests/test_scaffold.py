import pytest
import yaml

from skillkit.lint import lint_path
from skillkit.scaffold import ScaffoldError, new_skill, validate_name


def test_new_skill_is_valid(tmp_path):
    folder = new_skill("lead-magnet-writer", tmp_path)
    assert folder == tmp_path / "lead-magnet-writer"
    text = (folder / "SKILL.md").read_text()
    meta = yaml.safe_load(text.split("---")[1])
    assert meta["name"] == "lead-magnet-writer"
    assert "# Lead Magnet Writer" in text
    result = lint_path(folder)
    assert result.ok
    assert [i.rule for i in result.issues] == ["description-todo"]


def test_new_skill_with_description_is_clean(tmp_path):
    folder = new_skill("cold-email", tmp_path, 'Writes "cold" emails: short. Use when the user needs outreach.')
    assert lint_path(folder).issues == []
    meta = yaml.safe_load((folder / "SKILL.md").read_text().split("---\n")[1])
    assert meta["description"].startswith('Writes "cold" emails: short.')


def test_new_skill_refuses_existing(tmp_path):
    new_skill("dup", tmp_path)
    with pytest.raises(ScaffoldError, match="already exists"):
        new_skill("dup", tmp_path)


@pytest.mark.parametrize("name,msg", [("My Skill", "my-skill"), ("claude-bot", "reserved"),
                                      ("anthropic", "reserved"), ("a" * 65, "at most 64"), ("", "not a valid")])
def test_validate_name_errors(name, msg):
    with pytest.raises(ScaffoldError, match=msg):
        validate_name(name)


def test_new_skill_creates_parent_dirs(tmp_path):
    folder = new_skill("deep", tmp_path / "a" / "b")
    assert (folder / "SKILL.md").is_file()
