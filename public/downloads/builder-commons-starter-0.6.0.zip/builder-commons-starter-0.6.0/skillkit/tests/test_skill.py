from pathlib import Path

import pytest

from skillkit.skill import (
    find_skill_folders,
    iter_text_files,
    load_skill,
    load_skills,
    normalize_newlines,
    parse_frontmatter,
    slugify,
)


def test_parse_frontmatter_valid():
    fm = parse_frontmatter("---\nname: a\ndescription: b\n---\n\n# Body\nline\n")
    assert fm.error is None
    assert fm.meta == {"name": "a", "description": "b"}
    assert fm.key_lines == {"name": 2, "description": 3}
    assert fm.end_line == 4
    assert fm.body_start_line == 5
    assert fm.body == "\n# Body\nline\n"


def test_parse_frontmatter_crlf_and_bom():
    fm = parse_frontmatter("﻿---\r\nname: a\r\ndescription: b\r\n---\r\nBody\r\n")
    assert fm.error is None and fm.meta["name"] == "a"
    assert fm.body == "Body\n"


@pytest.mark.parametrize(
    "text,error",
    [
        ("# no frontmatter\n", "missing"),
        ("", "missing"),
        ("---\nname: a\n", "unclosed"),
        ("---\nname: [a\n---\n", "invalid"),
        ("---\n- a\n- b\n---\n", "not-mapping"),
        ("---\njust text\n---\n", "not-mapping"),
    ],
)
def test_parse_frontmatter_errors(text, error):
    assert parse_frontmatter(text).error == error


def test_parse_frontmatter_invalid_reports_line():
    fm = parse_frontmatter("---\nname: ok\ndescription: [broken\nother: x\n---\n")
    assert fm.error == "invalid"
    assert fm.error_line >= 3
    assert fm.error_detail


def test_parse_frontmatter_empty_block_is_empty_mapping():
    fm = parse_frontmatter("---\n---\nbody")
    assert fm.error is None and fm.meta == {}


def test_normalize_newlines():
    assert normalize_newlines("a\r\nb\rc") == "a\nb\nc"


@pytest.mark.parametrize(
    "value,expected",
    [
        ("My Cool Skill!", "my-cool-skill"),
        ("  --Hello__World--  ", "hello-world"),
        ("Café Résumé", "cafe-resume"),
        ("🚀 Launch Plan", "launch-plan"),
        ("x" * 100, "x" * 64),
        ("!!!", ""),
    ],
)
def test_slugify(value, expected):
    assert slugify(value) == expected


def test_slugify_truncation_never_ends_with_hyphen():
    s = slugify("a" * 63 + " b")
    assert len(s) <= 64 and not s.endswith("-")


def test_find_skill_folders_single(fixtures_dir):
    folders, is_lib = find_skill_folders(fixtures_dir / "library" / "summarize-email")
    assert is_lib is False and len(folders) == 1


def test_find_skill_folders_single_via_skill_md_file(fixtures_dir):
    folders, is_lib = find_skill_folders(fixtures_dir / "library" / "summarize-email" / "SKILL.md")
    assert folders == [fixtures_dir / "library" / "summarize-email"] and not is_lib


def test_find_skill_folders_library(fixtures_dir):
    folders, is_lib = find_skill_folders(fixtures_dir / "library")
    assert is_lib is True
    assert [f.name for f in folders] == ["linkedin-post", "summarize-email"]


def test_find_skill_folders_skips_hidden(tmp_path):
    (tmp_path / ".git").mkdir()
    (tmp_path / "__pycache__").mkdir()
    (tmp_path / "real").mkdir()
    folders, is_lib = find_skill_folders(tmp_path)
    assert [f.name for f in folders] == ["real"] and is_lib


def test_find_skill_folders_empty_dir_is_single_skill(tmp_path):
    folders, is_lib = find_skill_folders(tmp_path)
    assert folders == [tmp_path] and not is_lib


def test_find_skill_folders_errors(tmp_path):
    with pytest.raises(FileNotFoundError):
        find_skill_folders(tmp_path / "nope")
    f = tmp_path / "file.txt"
    f.write_text("x")
    with pytest.raises(NotADirectoryError):
        find_skill_folders(f)


def test_load_skill_properties(fixtures_dir):
    s = load_skill(fixtures_dir / "library" / "summarize-email")
    assert s.exists and s.name == "summarize-email"
    assert "Use when" in s.description
    assert s.display_name == "summarize-email"
    assert s.folder_name == "summarize-email"
    assert "# Summarize email" in s.body


def test_load_skill_missing(tmp_path):
    s = load_skill(tmp_path)
    assert not s.exists and s.name is None and s.description is None and s.body == ""
    assert s.display_name == tmp_path.name


def test_load_skills(fixtures_dir):
    skills, is_lib = load_skills(fixtures_dir / "duplicates")
    assert is_lib and len(skills) == 3


def test_iter_text_files_skips_binary_hidden_and_large(tmp_path):
    (tmp_path / "a.md").write_text("hello")
    (tmp_path / "bin.png").write_bytes(b"\x89PNG\x00\x01")
    (tmp_path / "latin.txt").write_bytes(b"caf\xe9")
    (tmp_path / ".hidden").mkdir()
    (tmp_path / ".hidden" / "x.md").write_text("secret")
    (tmp_path / "big.txt").write_text("x" * 50)
    names = [p.name for p, _ in iter_text_files(tmp_path, max_bytes=20)]
    assert names == ["a.md"]
