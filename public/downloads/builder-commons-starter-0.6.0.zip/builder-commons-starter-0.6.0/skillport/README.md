# skillport

Turn your **n8n workflows** and **Make.com scenarios** into **Claude skills** (`SKILL.md` folders that work in
Claude Code, the Claude app and OpenClaw). Point it at one blueprint or a folder of 300, and you get one skill
folder per workflow. Each folder lists the accounts it needs and includes a README your members can follow.

**Why:** your blueprint library is locked in n8n/Make format, and your members are moving to Claude skills.
skillport converts the whole library in one go and removes API keys and account IDs on the way.

## Install (once)

You need Python 3.10 or newer. In a terminal, inside the `skillport` folder:

```bash
python3 -m pip install .
```

No other packages are needed. To skip installing, run `python3 -m skillport ...` from the `src` folder instead.

## Try it on the samples first

`examples/` has two n8n workflows and one Make.com scenario (any keys in them are fake):

```bash
skillport inspect examples/lead-capture.json
skillport batch examples -o skills
```

You should see a table with 3 rows marked `OK`, and three folders in `skills/`, each with a `SKILL.md`.

## Quickstart

In n8n, open a workflow, then use **⋯ → Download** to get the `.json` file. In Make.com, use **⋯ → Export Blueprint**.

```bash
# 1. See what's inside (nothing is written)
skillport inspect my-workflow.json

# 2. Make a skill folder (add --zip for a file you can upload or share)
skillport convert my-workflow.json -o skills --zip

# 3. Convert a whole folder of blueprints
skillport batch blueprints/ -o skills

# 4. Keep the workflow running in n8n and let Claude call its webhook ("bridge" skill)
skillport convert my-workflow.json -o skills --mode bridge --webhook-url https://your-n8n.example.com/webhook/lead-capture
```

Then copy the skill folder to `~/.claude/skills/` (Claude Code; on Windows `%USERPROFILE%\.claude\skills\`),
upload the zip in the Claude app (Customize > Skills > + > Create skill > Upload a skill; code execution must be on),
or put it in your OpenClaw skills folder (`~/.openclaw/skills/` or `<workspace>/skills/`).
To share a whole library, use [skillkit](../skillkit) `pack`.

**No terminal?** Open `web/index.html` in a browser, paste the workflow and download `SKILL.md`. Everything
runs in the browser and nothing is uploaded. (The page handles n8n only, and makes `SKILL.md` without the README or zip.)

### Example

```
$ skillport convert lead_capture.json -o skills --zip
Converted "Lead Capture → AI Scoring 🚀" (n8n) -> skills/lead-capture-ai-scoring/
  Files: README.md, SKILL.md, source/workflow.json
  7 steps, 4 account(s) needed: OPENAI_API_KEY, SLACK_TOKEN, GMAIL_OAUTH_TOKEN, GOOGLE_SHEETS_OAUTH_TOKEN
  Zip: skills/lead-capture-ai-scoring.zip
```

Part of the generated `SKILL.md`:

```markdown
---
name: lead-capture-ai-scoring
description: "Does the work of the \"Lead Capture → AI Scoring 🚀\" automation (converted from n8n): it takes incoming data (originally sent to a webhook); uses OpenAI, Slack, Gmail, Google Sheets. Use when the user asks to run ..."
---
## Steps

3. **Score Lead**: Ask OpenAI (model GPT-4O-MINI) to write a reply.
   - System message: "You are a sales assistant. Score leads from 0 to 100. ..."
4. **Hot Lead?**: Check whether `message.content.score` is greater than `70`.
   - If `message.content.score` is greater than `70` → go to step 5 (Notify Sales)
   - Otherwise → go to step 6 (Send Nurture Email)
```

Batch output:

```
File              Result  Skill                      Steps  Details
----------------  ------  -------------------------  -----  -------------------------------
broken.json       FAILED  -                          -      broken.json is not valid JSON (line 1, column 3: ...)
lead.json         OK      lead-capture-ai-scoring    7      4 account(s)
make_router.json  OK      make-lead-router           6      3 account(s)

2 skill(s) written to /home/me/skills, 1 file(s) failed.
```

## What a converted skill is (and isn't)

A converted skill is **written instructions** that Claude follows with its own tools. It is not a copy of the
n8n or Make.com engine, so results can differ from the original. Every `SKILL.md` has a **Conversion check**
section near the top listing what to look at before you share it:

| Flagged when the workflow has | Why |
|---|---|
| A schedule trigger | A skill only runs when someone asks Claude. Nothing runs automatically |
| Code nodes | Claude rewrites the code's job from the original code |
| Nodes skillport can't describe (community nodes, rare nodes) | You need to describe the step in plain words |
| AI model steps (OpenAI, agents, chains) | Claude does the step itself, so wording and scores can differ |
| Expressions with logic (`? :`, `.map(`, `$now`, ...) | The steps show them simplified |
| Loops | Check Claude stops where the original stopped |
| "Continue on fail", retries, error workflows, Make.com error handlers | Not carried over: the skill stops and reports errors |
| Calls to other workflows | The called workflow isn't included |

Bridge skills get a different list: whether the webhook waits for the workflow to finish (otherwise Claude only
sees "Workflow was started"), the auth header to set, test vs production URLs, and network access.

`inspect` prints the same list ("Check before sharing"), `convert` and `batch` show the count, and
`inspect --format json` has it under `review`. When you've checked the list, delete the
`<!-- skillport: needs-review -->` line from `SKILL.md`; until then `skillkit lint` shows a `needs-review` warning.

## What you get in each skill folder

| File | What it is |
|---|---|
| `SKILL.md` | The skill: what it does, accounts needed, inputs, numbered steps with the branches written out ("If … → … Otherwise → …"), and the sticky notes from the workflow |
| `README.md` | Setup steps in plain English for your members |
| `source/workflow.json` | The original workflow with account IDs, pinned test data and secrets removed |
| `scripts/call_webhook.py` | Bridge mode only: a small script that sends JSON to your n8n webhook and prints the reply |

## Options

| Option | What it does |
|---|---|
| `--zip` | Also write `<skill-name>.zip` |
| `--mode skill` (default) | Claude does the steps itself with its own tools |
| `--mode bridge` | Claude calls your existing n8n webhook instead (needs the workflow to start with a Webhook node) |
| `--webhook-url URL` | Bridge mode: the production webhook URL. Without it, members set `N8N_WEBHOOK_URL` |
| `--brand-name`, `--brand-url` | Change the "Converted with skillport" footer to your community's name and link |
| `inspect --format json` | Machine-readable output |

The web page can be branded too: `index.html?brand=Your%20Academy&brandUrl=https://...&color=%23ff6600`.

## For community owners

- Run `skillport batch` on your blueprint folder and you get a ready skill library with one folder per blueprint.
  Check the result with [skillkit](../skillkit) (`skillkit lint skills/`) before you share it.
- Generated skills are a **starting point**. A converted skill tells Claude *what* the workflow did. Claude then
  does it with whatever tools the member has (connected apps, MCP servers, web requests). Test each one before you
  publish it, especially workflows with Code nodes.
- Bridge skills are the fastest way to give members something that works today, because the workflow keeps running in n8n.

## Limits

- **About 45 common node types** get a plain-English description, from these n8n nodes: webhook, schedule, cron,
  form, chat, HTTP, Set, IF, Switch, Merge, Code, Loop/Split in Batches, Wait, Gmail, Google Sheets/Drive, Slack,
  Telegram, Airtable, Notion, HubSpot, Stripe, OpenAI, AI Agent, LLM chain, chat models, memory and more. Other nodes
  get a generic line and a note to check the original.
- **Make.com:** the main modules are described (webhook, router with filters, HTTP, OpenAI, Google Sheets, Gmail/email,
  Slack, Telegram, Airtable, iterator, aggregator, variables); others get a generic line. Error handlers and
  scenario schedules are not converted. A scenario without a trigger module gets a "Scenario start" step.
- **Secrets:** values under secret-sounding names (API key, token, password, Authorization header…) and anything
  that looks like a key (`sk-…`, `AKIA…`, `ghp_…`, `xoxb-…`, Bearer tokens, private keys, `?api_key=` in URLs)
  are replaced with `[REDACTED]`. This is pattern-based. Still look over the output before you publish it.
- **Credentials:** the environment variable names (like `SLACK_TOKEN`) are suggestions. Google services use an
  OAuth login, which is easiest to give Claude through a connected app or MCP server.
- **Loops** are found and shown once, with a "go back to step N" line. Disabled nodes are skipped, nodes not connected
  to the trigger are left out, and both are listed in the Notes.
- **Verify against current docs** (these details came from public exports and docs, and may change):
  - n8n export field names (`nodes`, `connections`, `typeVersion`, the parameter names of each node)
  - Make.com blueprint fields (`flow`, `routes`, `filter`, `mapper`, `__IMTCONN__`)
  - Claude app upload steps and OpenClaw skill folders (checked against their docs on 2026-10-29)
  - Whether your members' Claude environment can reach your n8n host (the Claude API's skill sandbox has no
    network access, so bridge skills don't work there)
  - The webhook URL format `https://<host>/webhook/<path>` (production) / `/webhook-test/<path>` (test)

## For developers

```bash
cd skillport && ../.venv/bin/python -m pytest -q
```

Standard library only. The code lives in `src/skillport/`:

| File | What it does |
|---|---|
| `n8n.py` | n8n importer and node registry |
| `make.py` | Make.com importer |
| `graph.py` | Step order, loops, disabled nodes |
| `render.py` | SKILL.md, README and inspect output |
| `bridge.py` | Bridge mode |
| `redact.py` | Secret removal |
| `writer.py` | Writes the folders and zips |

The web page's tests run its JavaScript with Node (`node` must be on PATH). Without Node, those tests are skipped.

License: MIT.
