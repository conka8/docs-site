---
name: n8n-to-skill
description: "Converts n8n workflow JSON files or Make.com blueprints into ready-to-use skill folders with the skillport command-line tool, either as a skill that does the steps itself or as a bridge that calls the existing n8n webhook. Use when the user wants to turn an n8n or Make.com automation (or a whole folder of blueprints) into skills, or asks what accounts a workflow needs."
---

# Convert n8n / Make.com workflows into skills

Use the `skillport` command-line tool. It only needs Python 3.10+ and has no other dependencies.

## 1. Check that skillport is available

```bash
skillport --version || python3 -m skillport --version
```

If neither works, ask the user where the `skillport` folder is and install it from there with
`python3 -m pip install <path-to-skillport>`. Do not install anything from the internet without asking.

## 2. Look before converting

Always inspect first and show the user a short summary: the steps, the accounts needed and any warnings.

```bash
skillport inspect path/to/workflow.json
```

If it reports "not valid JSON", ask the user to download the workflow again (n8n: ⋯ → Download;
Make.com: ⋯ → Export Blueprint) and make sure the whole file was copied.

## 3. Convert

Pick the mode with the user:

- **skill** (default): Claude does the steps itself. Use it when the user wants to stop using n8n/Make for this task.
- **bridge**: the workflow keeps running in n8n and the skill calls its webhook. Use it when the workflow is
  already live and works, or uses nodes Claude can't easily reproduce. It needs a Webhook trigger in the workflow.

```bash
# one workflow
skillport convert path/to/workflow.json -o skills --zip

# bridge to an existing n8n webhook
skillport convert path/to/workflow.json -o skills --mode bridge --webhook-url "https://<host>/webhook/<path>"

# a whole folder (continues past bad files and prints a table)
skillport batch path/to/blueprints -o skills
```

Exit code 1 means at least one file failed. Read the table or error line and tell the user which file and why.

## 4. After converting

1. Open the new `skills/<name>/SKILL.md` and read the **Steps** and **Notes** sections. Point out any step marked
   "has no built-in description", any loops, disabled or unconnected nodes, and any Code steps. These need a human check.
2. Tell the user which environment variables to set, from the "Required credentials / accounts" section.
   Never ask the user to paste secrets into chat, and never write keys into the skill files.
3. If the `skillkit` tool is installed, run `skillkit lint skills/` and fix what it reports.
4. To install for Claude Code, copy the folder to `~/.claude/skills/<name>/` (or `.claude/skills/<name>/` in a project).

## Notes

- Secrets in the workflow are replaced with `[REDACTED]`. If the user says a step needs a key, have them set it
  as an environment variable instead.
- `source/workflow.json` in each skill folder is the original workflow with account IDs and secrets removed.
