"""skillport: turn n8n workflows and Make.com blueprints into Claude / OpenClaw skills."""

from __future__ import annotations

from pathlib import Path

__version__ = "0.2.1"

from .loader import detect_format, load_workflows, parse_data  # noqa: E402
from .make import parse_make  # noqa: E402
from .model import Credential, Edge, Node, SkillportError, Workflow  # noqa: E402
from .n8n import parse_n8n  # noqa: E402
from .writer import ConvertResult, build_files, convert_workflow  # noqa: E402


def convert_file(path: str | Path, outdir: str | Path, **options) -> list[ConvertResult]:
    """Convert one exported .json file. Options are passed to convert_workflow()."""
    taken: set[str] = set()
    return [convert_workflow(wf, outdir, taken=taken, **options) for wf in load_workflows(path)]


__all__ = [
    "ConvertResult", "Credential", "Edge", "Node", "SkillportError", "Workflow", "build_files", "convert_file",
    "convert_workflow", "detect_format", "load_workflows", "parse_data", "parse_make", "parse_n8n", "__version__",
]
