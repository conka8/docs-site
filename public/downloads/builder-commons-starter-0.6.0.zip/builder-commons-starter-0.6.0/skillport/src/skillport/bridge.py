"""Bridge mode: a skill that keeps the workflow running in n8n and calls it through its webhook."""

from __future__ import annotations

import json
from pathlib import Path

from .credentials import collect_credentials
from .model import Workflow
from .redact import contains_secret
from .review import render_review, review_items
from .render import FORMAT_LABEL, build_description, footer, frontmatter, install_lines, render_notes
from .text import slugify

SCRIPT_PATH = "scripts/call_webhook.py"


def script_source() -> str:
    return (Path(__file__).parent / "call_webhook.py").read_text(encoding="utf-8")


def safe_webhook_url(url: str | None, wf: Workflow) -> str | None:
    """Return the URL if it is safe to write into the skill, else None (with a warning)."""
    if not url:
        return None
    if contains_secret(url):
        msg = ("The webhook URL looked like it contains a secret, so it was not written into the "
               "skill. Set N8N_WEBHOOK_URL on the computer that runs the skill instead.")
        if msg not in wf.warnings:
            wf.warnings.append(msg)
        return None
    return url


def _example_data(wf: Workflow) -> str:
    data: dict[str, str] = {}
    for f in wf.inputs:
        key = f.split(" ")[0].split(".")[0].split("[")[0]
        if key and key not in data:
            data[key] = "..."
    return json.dumps(data or {"message": "..."}, ensure_ascii=False)


def _shell_quote(text: str) -> str:
    return "'" + text.replace("'", "'\"'\"'") + "'"


def webhook_facts(wf: Workflow) -> dict:
    hook = wf.webhook
    if hook is None:
        return {}
    info = dict(hook.trigger_info)
    info["node"] = hook.name
    return info


def render_bridge_skill_md(wf: Workflow, url: str | None, name: str | None = None) -> str:
    name = name or slugify(wf.name)
    fmt = FORMAT_LABEL.get(wf.source_format, wf.source_format)
    facts = webhook_facts(wf)
    method = str(facts.get("method") or "POST").upper()
    out = [frontmatter(name, build_description(wf, mode="bridge")).rstrip("\n"), "", f"# {wf.name} (runs in {fmt})",
           "", "## Overview", "",
           f'This skill does not redo the work itself. It sends the user\'s data to the existing {fmt} workflow '
           f'"{wf.name}" through its webhook. {fmt} then does every step with its own saved accounts, '
           "and this skill shows the user the reply.", "", "## Webhook", ""]
    if url:
        out.append(f"- URL: `{url}` (already filled in in the command below).")
    else:
        out.append("- URL: read from the `N8N_WEBHOOK_URL` environment variable. If it is not set, "
                   "ask the user for the webhook URL and pass it with `--url`.")
    if facts and wf.source_format == "n8n":
        path = facts.get("path", "")
        out.append(f"- The workflow listens for **{method}** requests on the path `/{path}` "
                   f"(production URL: `https://<your-n8n-host>/webhook/{path}`; "
                   f"test URL: `https://<your-n8n-host>/webhook-test/{path}`).")
        if facts.get("auth") not in (None, "", "none"):
            out.append("- The webhook needs authentication. The user must set `N8N_WEBHOOK_HEADER` before "
                       "running the script (see Conversion check for the exact header).")
    elif facts:
        out.append(f"- The {fmt} scenario starts from a webhook. Use the webhook address shown in {fmt}.")
    else:
        out.append(f"- The original workflow does not start from a webhook. Add a Webhook trigger in {fmt} "
                   "first, then use its URL here.")

    out += ["", "## Conversion check", ""] + render_review(review_items(wf, "bridge", url), "bridge")
    out += ["", "## Inputs", ""]
    if wf.inputs:
        out += ["Send these fields as JSON:", ""] + [f"- `{f}`" for f in wf.inputs]
    else:
        out.append("Send the details the user gives you as a JSON object.")

    cmd = f"python3 {SCRIPT_PATH}"
    if url:
        cmd += f" --url {_shell_quote(url)}"
    if method != "POST":
        cmd += f" --method {method}"
    cmd += f" --data {_shell_quote(_example_data(wf))}"
    out += ["", "## How to run it", "",
            "1. Collect the inputs from the user. Ask for anything missing.",
            "2. Run the script from this skill's folder, with the real values:", "",
            "   ```bash", f"   {cmd}", "   ```", "",
            "3. Show the user the reply in plain words.",
            "4. If the script exits with an error (exit code 1 = the workflow answered with an error, "
            "2 = bad input or could not connect), show the error message and stop. Retry at most once.",
            "", "## Required credentials / accounts", ""]
    creds = collect_credentials(wf)
    if creds:
        out.append(f"None on this computer. {fmt} uses its own saved accounts: "
                   + ", ".join(c.service for c in creds) + ".")
    else:
        out.append("None.")
    out += ["", f"## What the workflow does in {fmt}", ""]
    out += [f"{wf.step_number(n)}. {wf.nodes[n].summary}" for n in wf.steps]
    out += ["", "## Notes", ""] + render_notes(wf)
    return "\n".join(out).rstrip() + "\n"


def render_bridge_readme(wf: Workflow, name: str, url: str | None, brand: str, brand_url: str | None) -> str:
    fmt = FORMAT_LABEL.get(wf.source_format, wf.source_format)
    out = [
        f"# {wf.name} (bridge skill)",
        "",
        f'This Claude skill runs your existing {fmt} workflow "{wf.name}" by calling its webhook. '
        f"Your workflow keeps running in {fmt}; Claude just starts it and reads the reply.",
        "",
        "## What you need",
        "",
        f"- The workflow switched **on** (active) in {fmt}, starting with a Webhook trigger.",
        "- Python 3 on the computer that runs the skill (Claude Code already has it on most computers).",
        "",
        "## Set it up",
        "",
    ] + install_lines(name)
    if url:
        out += ["2. The webhook address is already filled in. To change it later, set `N8N_WEBHOOK_URL`."]
    else:
        out += ["2. Tell the skill where your webhook is:", "", "   ```bash",
                '   export N8N_WEBHOOK_URL="https://your-n8n.example.com/webhook/your-path"', "   ```"]
    out += ["", f'3. Ask Claude: *"Use the {name} skill"*.', "", "## Try the webhook yourself", "",
            "```bash", f"python3 {SCRIPT_PATH} --data '{_example_data(wf)}'", "```", "",
            "## Good to know", "",
            "- The script only uses Python's standard library. It stops with an error if the webhook fails.",
            "- `source/workflow.json` is the original workflow with account IDs and secrets removed."]
    out += [f"- {w}" for w in wf.warnings]
    out += [""] + footer(brand, brand_url)
    return "\n".join(out).rstrip() + "\n"
