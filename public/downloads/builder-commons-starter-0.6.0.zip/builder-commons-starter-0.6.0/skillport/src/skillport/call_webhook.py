#!/usr/bin/env python3
"""Send JSON to an n8n (or Make.com) webhook and print the reply.

Usage:
  python3 scripts/call_webhook.py --data '{"email": "jane@example.com"}'
  python3 scripts/call_webhook.py --url https://your-n8n.example.com/webhook/lead --data-file input.json

The webhook URL comes from --url or the N8N_WEBHOOK_URL environment variable.
If the webhook needs a header (for example an API key), set N8N_WEBHOOK_HEADER="Header-Name: value"
or pass --header "Header-Name: value".

Exit codes: 0 = success, 1 = the webhook answered with an error, 2 = bad input or could not connect.
Only uses the Python standard library.
"""

import argparse
import json
import os
import sys
import urllib.error
import urllib.parse
import urllib.request


def _parse_header(text):
    name, sep, value = text.partition(":")
    if not sep or not name.strip():
        raise ValueError(f'Header must look like "Name: value", got: {text!r}')
    return name.strip(), value.strip()


def _show(body):
    text = body.decode("utf-8", errors="replace")
    try:
        return json.dumps(json.loads(text), indent=2, ensure_ascii=False)
    except ValueError:
        return text


def main(argv=None):
    parser = argparse.ArgumentParser(description="Send JSON to a webhook and print the reply.")
    parser.add_argument("--url", help="Webhook URL (default: $N8N_WEBHOOK_URL)")
    parser.add_argument("--data", help="JSON to send, e.g. '{\"email\": \"a@b.com\"}'")
    parser.add_argument("--data-file", help="Read the JSON to send from this file")
    parser.add_argument("--method", default="POST", help="HTTP method (default POST)")
    parser.add_argument("--header", action="append", default=[], help='Extra header "Name: value" (repeatable)')
    parser.add_argument("--timeout", type=float, default=60.0, help="Seconds to wait (default 60)")
    args = parser.parse_args(argv)

    url = args.url or os.environ.get("N8N_WEBHOOK_URL", "")
    if not url:
        print("Error: no webhook URL. Pass --url or set N8N_WEBHOOK_URL.", file=sys.stderr)
        return 2
    if not url.lower().startswith(("http://", "https://")):
        print(f"Error: the webhook URL must start with http:// or https:// (got {url!r}).", file=sys.stderr)
        return 2

    raw = "{}"
    try:
        if args.data_file:
            with open(args.data_file, encoding="utf-8") as fh:
                raw = fh.read()
        elif args.data is not None:
            raw = args.data
        payload = json.loads(raw)
    except (OSError, ValueError) as exc:
        print(f"Error: the data to send is not valid JSON ({exc}).", file=sys.stderr)
        return 2

    headers = {"Content-Type": "application/json", "Accept": "application/json, text/plain, */*"}
    try:
        extra = list(args.header)
        if os.environ.get("N8N_WEBHOOK_HEADER"):
            extra.insert(0, os.environ["N8N_WEBHOOK_HEADER"])
        for h in extra:
            name, value = _parse_header(h)
            headers[name] = value
    except ValueError as exc:
        print(f"Error: {exc}", file=sys.stderr)
        return 2

    method = args.method.upper()
    body = None
    if method in ("GET", "HEAD", "DELETE"):
        if isinstance(payload, dict) and payload:
            sep = "&" if urllib.parse.urlparse(url).query else "?"
            url = url + sep + urllib.parse.urlencode({k: v if isinstance(v, str) else json.dumps(v)
                                                      for k, v in payload.items()})
        headers.pop("Content-Type")
    else:
        body = json.dumps(payload).encode("utf-8")

    request = urllib.request.Request(url, data=body, headers=headers, method=method)
    try:
        with urllib.request.urlopen(request, timeout=args.timeout) as resp:
            print(_show(resp.read()))
            return 0
    except urllib.error.HTTPError as exc:
        detail = _show(exc.read() or b"")
        print(f"Error: the webhook answered with HTTP {exc.code} {exc.reason}.", file=sys.stderr)
        if detail:
            print(detail, file=sys.stderr)
        if exc.code == 404:
            print("Tip: check the URL, and that the workflow is active (or listening, for test URLs).",
                  file=sys.stderr)
        return 1
    except (urllib.error.URLError, OSError) as exc:
        reason = getattr(exc, "reason", exc)
        print(f"Error: could not reach the webhook ({reason}).", file=sys.stderr)
        return 2


if __name__ == "__main__":
    sys.exit(main())
