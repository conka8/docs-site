"""Command line: skillport convert | batch | inspect."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from . import __version__
from .credentials import collect_credentials
from .loader import load_workflows
from .model import SkillportError, Workflow
from .review import review_items
from .render import DEFAULT_BRAND, FORMAT_LABEL, render_inspect, step_links
from .text import slugify
from .writer import MODES, ConvertResult, convert_workflow


def _parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="skillport",
        description="Turn n8n workflows and Make.com blueprints into Claude / OpenClaw skills.",
    )
    p.add_argument("--version", action="version", version=f"skillport {__version__}")
    sub = p.add_subparsers(dest="command", metavar="COMMAND")

    def add_output_opts(sp: argparse.ArgumentParser) -> None:
        sp.add_argument("--zip", action="store_true", help="also write <skill-name>.zip next to the folder")
        sp.add_argument("--mode", choices=MODES, default="skill",
                        help="skill = Claude does the steps itself (default); bridge = Claude calls your n8n webhook")
        sp.add_argument("--brand-name", default=DEFAULT_BRAND, help='name in the "Converted with ..." footer')
        sp.add_argument("--brand-url", default=None, help="link for the footer name")

    c = sub.add_parser("convert", help="convert one workflow .json file into a skill folder")
    c.add_argument("file", help="exported n8n workflow or Make.com blueprint (.json)")
    c.add_argument("-o", "--out", default=".", help="folder to write the skill into (default: current folder)")
    add_output_opts(c)
    c.add_argument("--webhook-url", default=None, help="bridge mode: the n8n production webhook URL")

    b = sub.add_parser("batch", help="convert every .json file in a folder")
    b.add_argument("folder", help="folder with exported .json files (searched recursively)")
    b.add_argument("-o", "--out", required=True, help="folder to write all skills into")
    add_output_opts(b)

    i = sub.add_parser("inspect", help="show the steps and accounts of a workflow without writing anything")
    i.add_argument("file")
    i.add_argument("--format", choices=("text", "json"), default="text")
    return p


def _err(msg: str) -> None:
    print(f"skillport: error: {msg}", file=sys.stderr)


def _report(res: ConvertResult) -> None:
    wf = res.workflow
    fmt = FORMAT_LABEL.get(wf.source_format, wf.source_format)
    creds = collect_credentials(wf)
    print(f'Converted "{wf.name}" ({fmt}) -> {res.folder}{"/" if not str(res.folder).endswith("/") else ""}')
    print(f"  Files: {', '.join(res.files)}")
    acct = f"{len(creds)} account(s) needed: {', '.join(c.env_var for c in creds)}" if creds else "no accounts needed"
    print(f"  {len(wf.steps)} steps, {acct}")
    if res.zip_path:
        print(f"  Zip: {res.zip_path}")
    for w in wf.warnings:
        print(f"  Note: {w}")
    review = review_items(wf, res.mode, res.webhook_url)
    if review:
        print(f"  Check before sharing: {len(review)} item(s), listed under \"Conversion check\" in SKILL.md")


def cmd_convert(args: argparse.Namespace) -> int:
    workflows = load_workflows(args.file)
    if args.webhook_url and args.mode != "bridge":
        print("skillport: note: --webhook-url is only used with --mode bridge.", file=sys.stderr)
    taken: set[str] = set()
    failed = 0
    for wf in workflows:
        try:
            res = convert_workflow(wf, args.out, mode=args.mode, webhook_url=args.webhook_url,
                                   make_zip=args.zip, brand=args.brand_name, brand_url=args.brand_url, taken=taken)
        except SkillportError as exc:
            if len(workflows) == 1:
                raise
            _err(str(exc))
            failed += 1
            continue
        _report(res)
    return 1 if failed else 0


def _table(rows: list[list[str]]) -> str:
    widths = [max(len(r[i]) for r in rows) for i in range(len(rows[0]))]
    lines = []
    for n, r in enumerate(rows):
        lines.append("  ".join(cell.ljust(widths[i]) for i, cell in enumerate(r)).rstrip())
        if n == 0:
            lines.append("  ".join("-" * w for w in widths))
    return "\n".join(lines)


def cmd_batch(args: argparse.Namespace) -> int:
    folder = Path(args.folder)
    if not folder.is_dir():
        raise SkillportError(f"{folder} is not a folder.")
    out = Path(args.out).resolve()
    files = sorted(p for p in folder.rglob("*.json") if out not in p.resolve().parents)
    if not files:
        raise SkillportError(f"No .json files found in {folder}.")
    rows = [["File", "Result", "Skill", "Steps", "Details"]]
    taken: set[str] = set()
    ok = failed = 0
    for path in files:
        rel = str(path.relative_to(folder))
        try:
            workflows = load_workflows(path)
            for wf in workflows:
                res = convert_workflow(wf, out, mode=args.mode, make_zip=args.zip,
                                       brand=args.brand_name, brand_url=args.brand_url, taken=taken)
                creds = collect_credentials(wf)
                review = review_items(wf, args.mode)
                detail = (f"{len(creds)} account(s)" + (f", {len(wf.warnings)} note(s)" if wf.warnings else "")
                          + (f", {len(review)} to check" if review else ""))
                rows.append([rel, "OK", res.name, str(len(wf.steps)), detail])
                ok += 1
        except SkillportError as exc:
            msg = str(exc)
            rows.append([rel, "FAILED", "-", "-", msg if len(msg) <= 90 else msg[:87] + "..."])
            failed += 1
    print(_table(rows))
    print()
    print(f"{ok} skill(s) written to {out}" + (f", {failed} file(s) failed." if failed else "."))
    return 1 if failed else 0


def inspect_data(wf: Workflow) -> dict:
    return {
        "name": wf.name,
        "format": wf.source_format,
        "skill_name": slugify(wf.name),
        "steps": [
            {
                "number": wf.step_number(nid),
                "name": wf.nodes[nid].name,
                "type": wf.nodes[nid].type,
                "trigger": wf.nodes[nid].is_trigger,
                "summary": wf.nodes[nid].summary,
                "details": wf.nodes[nid].details,
                "links": step_links(wf, nid, arrow="->"),
            }
            for nid in wf.steps
        ],
        "credentials": [
            {"service": c.service, "env_var": c.env_var, "type": c.key, "used_by": c.used_by}
            for c in collect_credentials(wf)
        ],
        "inputs": wf.inputs,
        "notes": wf.notes,
        "warnings": wf.warnings,
        "review": review_items(wf),
    }


def cmd_inspect(args: argparse.Namespace) -> int:
    workflows = load_workflows(args.file)
    if args.format == "json":
        data = [inspect_data(wf) for wf in workflows]
        print(json.dumps(data[0] if len(data) == 1 else data, indent=2, ensure_ascii=False))
    else:
        print("\n".join(render_inspect(wf) for wf in workflows), end="")
    return 0


def main(argv: list[str] | None = None) -> int:
    parser = _parser()
    args = parser.parse_args(argv)
    if not args.command:
        parser.print_help()
        return 2
    handlers = {"convert": cmd_convert, "batch": cmd_batch, "inspect": cmd_inspect}
    try:
        return handlers[args.command](args)
    except SkillportError as exc:
        _err(str(exc))
        return 1
    except OSError as exc:
        _err(f"could not write files: {exc}")
        return 1


if __name__ == "__main__":  # pragma: no cover
    sys.exit(main())
