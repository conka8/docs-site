"""Turn n8n credential types / Make.com app names into a deduplicated
"accounts you need" list with suggested environment variable names."""

from __future__ import annotations

import re

from .model import Credential, Workflow

# credential type (n8n) or app id (Make) -> (service label, suggested env var)
KNOWN: dict[str, tuple[str, str]] = {
    # n8n credential types
    "openaiapi": ("OpenAI", "OPENAI_API_KEY"),
    "anthropicapi": ("Anthropic (Claude API)", "ANTHROPIC_API_KEY"),
    "googlepalmapi": ("Google Gemini", "GEMINI_API_KEY"),
    "googlegeminiapi": ("Google Gemini", "GEMINI_API_KEY"),
    "slackapi": ("Slack", "SLACK_TOKEN"),
    "slackoauth2api": ("Slack", "SLACK_TOKEN"),
    "gmailoauth2": ("Gmail", "GMAIL_OAUTH_TOKEN"),
    "gmailoauth2api": ("Gmail", "GMAIL_OAUTH_TOKEN"),
    "googlesheetsoauth2api": ("Google Sheets", "GOOGLE_SHEETS_OAUTH_TOKEN"),
    "googleapi": ("Google service account", "GOOGLE_APPLICATION_CREDENTIALS"),
    "googledriveoauth2api": ("Google Drive", "GOOGLE_DRIVE_OAUTH_TOKEN"),
    "googlecalendaroauth2api": ("Google Calendar", "GOOGLE_CALENDAR_OAUTH_TOKEN"),
    "telegramapi": ("Telegram bot", "TELEGRAM_BOT_TOKEN"),
    "airtabletokenapi": ("Airtable", "AIRTABLE_TOKEN"),
    "airtableapi": ("Airtable", "AIRTABLE_TOKEN"),
    "airtableoauth2api": ("Airtable", "AIRTABLE_TOKEN"),
    "notionapi": ("Notion", "NOTION_TOKEN"),
    "notionoauth2api": ("Notion", "NOTION_TOKEN"),
    "hubspotapi": ("HubSpot", "HUBSPOT_TOKEN"),
    "hubspotapptoken": ("HubSpot", "HUBSPOT_TOKEN"),
    "hubspotoauth2api": ("HubSpot", "HUBSPOT_TOKEN"),
    "stripeapi": ("Stripe", "STRIPE_SECRET_KEY"),
    "smtp": ("Email (SMTP server)", "SMTP_PASSWORD"),
    "imap": ("Email inbox (IMAP)", "IMAP_PASSWORD"),
    "discordwebhookapi": ("Discord webhook", "DISCORD_WEBHOOK_URL"),
    "discordbotapi": ("Discord bot", "DISCORD_BOT_TOKEN"),
    "httpheaderauth": ("API key sent in a header", "API_KEY"),
    "httpbasicauth": ("Username and password (basic auth)", "API_PASSWORD"),
    "httpqueryauth": ("API key sent in the URL", "API_KEY"),
    "oauth2api": ("OAuth2 login", "OAUTH_TOKEN"),
    "postgres": ("Postgres database", "DATABASE_URL"),
    "mysql": ("MySQL database", "DATABASE_URL"),
    "supabaseapi": ("Supabase", "SUPABASE_SERVICE_KEY"),
    "twilioapi": ("Twilio", "TWILIO_AUTH_TOKEN"),
    "perplexityapi": ("Perplexity", "PERPLEXITY_API_KEY"),
    "openrouterapi": ("OpenRouter", "OPENROUTER_API_KEY"),
    "apifyapi": ("Apify", "APIFY_TOKEN"),
    # Make.com app ids
    "google-sheets": ("Google Sheets", "GOOGLE_SHEETS_OAUTH_TOKEN"),
    "google-email": ("Gmail", "GMAIL_OAUTH_TOKEN"),
    "gmail": ("Gmail", "GMAIL_OAUTH_TOKEN"),
    "google-drive": ("Google Drive", "GOOGLE_DRIVE_OAUTH_TOKEN"),
    "google-calendar": ("Google Calendar", "GOOGLE_CALENDAR_OAUTH_TOKEN"),
    "openai-gpt-3": ("OpenAI", "OPENAI_API_KEY"),
    "openai": ("OpenAI", "OPENAI_API_KEY"),
    "anthropic-claude": ("Anthropic (Claude API)", "ANTHROPIC_API_KEY"),
    "slack": ("Slack", "SLACK_TOKEN"),
    "telegram": ("Telegram bot", "TELEGRAM_BOT_TOKEN"),
    "airtable": ("Airtable", "AIRTABLE_TOKEN"),
    "notion": ("Notion", "NOTION_TOKEN"),
    "hubspotcrm": ("HubSpot", "HUBSPOT_TOKEN"),
    "stripe": ("Stripe", "STRIPE_SECRET_KEY"),
    "email": ("Email (SMTP server)", "SMTP_PASSWORD"),
    "discord": ("Discord", "DISCORD_BOT_TOKEN"),
}

_SUFFIXES = ("oauth2api", "oauth2", "apptoken", "tokenapi", "api")

# Generic auth types: the account name tells us more than the type does.
GENERIC = {"httpheaderauth", "httpbasicauth", "httpqueryauth", "oauth2api", "httpcustomauth"}
_FILLER = {"account", "accounts", "credential", "credentials", "auth", "header", "key", "api", "n8n", "my", "the"}


def _generic_env(account: str, default_env: str) -> str:
    words = [w for w in re.split(r"[^A-Za-z0-9]+", account.upper()) if w and w.lower() not in _FILLER]
    if not words:
        return default_env
    suffix = "_PASSWORD" if default_env.endswith("PASSWORD") else "_OAUTH_TOKEN" if "OAUTH" in default_env else "_API_KEY"
    return "_".join(words)[:40] + suffix


def describe_credential(key: str) -> tuple[str, str]:
    """(service label, env var) for a credential type or app id."""
    norm = key.lower()
    if norm in KNOWN:
        return KNOWN[norm]
    base = key
    for suffix in _SUFFIXES:
        if base.lower().endswith(suffix) and len(base) > len(suffix):
            base = base[: -len(suffix)]
            break
    words = re.sub(r"([a-z0-9])([A-Z])", r"\1 \2", base)
    words = re.sub(r"[^A-Za-z0-9]+", " ", words).strip()
    label = " ".join(w if w.isupper() else w.capitalize() for w in words.split()) or key
    env = re.sub(r"[^A-Z0-9]+", "_", words.upper()).strip("_") or "SERVICE"
    if "oauth" in key.lower():
        env += "_OAUTH_TOKEN"
    else:
        env += "_API_KEY"
    return label, env


def collect_credentials(wf: Workflow) -> list[Credential]:
    """Deduplicated credentials used by the enabled steps, in step order."""
    by_env: dict[str, Credential] = {}
    for nid in wf.steps + [n for n in wf.nodes if wf.nodes[n].is_subnode and not wf.nodes[n].disabled]:
        node = wf.nodes[nid]
        for ctype, account in node.credentials:
            service, env = describe_credential(ctype)
            if ctype.lower() in GENERIC and account:
                env = _generic_env(account, env)
                service = f"{service}: {account}"
            cred = by_env.get(env)
            if cred is None:
                cred = by_env[env] = Credential(key=ctype, service=service, env_var=env)
            if account and account not in cred.accounts:
                cred.accounts.append(account)
            if node.name not in cred.used_by:
                cred.used_by.append(node.name)
    return list(by_env.values())
