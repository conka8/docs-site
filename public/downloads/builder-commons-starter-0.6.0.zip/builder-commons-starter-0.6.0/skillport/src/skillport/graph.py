"""Order the steps of a workflow, starting from its triggers.

- Disabled nodes are skipped (their neighbours are joined up, like n8n does).
- AI sub-nodes (chat models, memory, tools) are not steps; they are attached to their parent.
- Loops are reported, never followed forever.
- Nodes that cannot be reached from a trigger are listed as "unconnected".
"""

from __future__ import annotations

from .model import Edge, Workflow


def _bypass_disabled(wf: Workflow, edges: list[Edge]) -> list[Edge]:
    disabled = [nid for nid, n in wf.nodes.items() if n.disabled]
    for nid in disabled:
        incoming = [e for e in edges if e.target == nid and e.source != nid]
        outgoing = [e for e in edges if e.source == nid and e.target != nid]
        kept = [e for e in edges if e.source != nid and e.target != nid]
        for i in incoming:
            for o in outgoing:
                new = Edge(i.source, o.target, i.output, i.kind)
                if not any(
                    (k.source, k.target, k.output) == (new.source, new.target, new.output) for k in kept
                ):
                    kept.append(new)
        edges = kept
    return edges


def analyze(wf: Workflow) -> Workflow:
    """Fill wf.steps, wf.flow_edges, wf.cycles, wf.unconnected and wf.disabled."""
    nodes = wf.nodes
    wf.disabled = [nid for nid, n in nodes.items() if n.disabled and not n.is_subnode]
    main = [
        e
        for e in wf.edges
        if e.kind == "main" and e.source in nodes and e.target in nodes
        and not nodes[e.source].is_subnode and not nodes[e.target].is_subnode
    ]
    edges = _bypass_disabled(wf, main)
    active = [nid for nid, n in nodes.items() if not n.disabled and not n.is_subnode]

    succ: dict[str, list[Edge]] = {nid: [] for nid in active}
    indeg_all: dict[str, int] = {nid: 0 for nid in active}
    for e in sorted(edges, key=lambda e: e.output):
        if e.source in succ and e.target in succ:
            succ[e.source].append(e)
            indeg_all[e.target] += 1

    triggers = [nid for nid in active if nodes[nid].is_trigger]
    if triggers:
        roots = triggers
    else:
        roots = [nid for nid in active if indeg_all[nid] == 0]
        if not roots and active:
            roots = [active[0]]

    # Depth-first walk from the roots: find what is reachable and which edges loop back.
    reached: list[str] = []
    seen: set[str] = set()
    back_edges: set[tuple[str, str, int]] = set()
    cycles: list[list[str]] = []

    def walk(start: str) -> None:
        if start in seen:
            return
        seen.add(start)
        reached.append(start)
        path = [start]
        on_path = {start}
        stack = [iter(succ[start])]
        while stack:
            edge = next(stack[-1], None)
            if edge is None:
                stack.pop()
                on_path.discard(path.pop())
                continue
            t = edge.target
            if t in on_path:
                back_edges.add((edge.source, t, edge.output))
                loop = path[path.index(t):] + [t]
                if loop not in cycles:
                    cycles.append(loop)
            elif t not in seen:
                seen.add(t)
                reached.append(t)
                path.append(t)
                on_path.add(t)
                stack.append(iter(succ[t]))

    for r in roots:
        walk(r)
    if not triggers:
        # No trigger: keep picking up loops that no root leads into.
        for nid in active:
            if nid not in seen:
                walk(nid)

    flow = [
        e
        for nid in reached
        for e in succ[nid]
        if (e.source, e.target, e.output) not in back_edges and e.target in seen
    ]
    loop_edges = [e for nid in reached for e in succ[nid] if (e.source, e.target, e.output) in back_edges]

    # Topological order (Kahn) with a stack so that each branch stays together.
    indeg = {nid: 0 for nid in reached}
    out: dict[str, list[Edge]] = {nid: [] for nid in reached}
    for e in flow:
        indeg[e.target] += 1
        out[e.source].append(e)
    order: list[str] = []
    # `reached` starts with the roots in file order; a stack pops the first one first.
    # Nodes where branches join (merges) wait until every open branch has been listed.
    ready = [nid for nid in reversed(reached) if indeg[nid] == 0]
    joins: list[str] = []
    done: set[str] = set()
    while ready or joins:
        nid = ready.pop() if ready else joins.pop(0)
        if nid in done:
            continue
        done.add(nid)
        order.append(nid)
        newly = []
        for e in out[nid]:
            indeg[e.target] -= 1
            if indeg[e.target] == 0 and e.target not in newly:
                newly.append(e.target)
        for t in newly:
            if sum(1 for e in flow if e.target == t) > 1:
                joins.append(t)
        ready.extend(t for t in reversed(newly) if t not in joins)
    for nid in reached:  # safety net, should not happen
        if nid not in done:
            order.append(nid)

    wf.steps = order
    wf.flow_edges = flow + loop_edges
    wf.cycles = cycles
    wf.unconnected = [nid for nid in active if nid not in seen]
    for loop in cycles:
        names = " -> ".join(nodes[n].name for n in loop)
        msg = f"Loop found: {names}. The steps below show it once; repeat as described."
        if msg not in wf.warnings:
            wf.warnings.append(msg)
    if wf.unconnected:
        names = ", ".join(f'"{nodes[n].name}"' for n in wf.unconnected)
        wf.warnings.append(f"Not connected to the trigger, left out of the steps: {names}.")
    if wf.disabled:
        names = ", ".join(f'"{nodes[n].name}"' for n in wf.disabled)
        wf.warnings.append(f"Disabled in the original workflow, skipped: {names}.")
    return wf
