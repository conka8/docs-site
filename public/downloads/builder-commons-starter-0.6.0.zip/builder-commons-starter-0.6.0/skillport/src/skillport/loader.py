"""Read a JSON file and work out whether it is an n8n workflow or a Make.com blueprint."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from .make import parse_make
from .model import SkillportError, Workflow
from .n8n import parse_n8n


def detect_format(data: Any) -> str:
    """Return "n8n" or "make", or raise SkillportError."""
    if isinstance(data, dict):
        if isinstance(data.get("nodes"), list) or isinstance(data.get("connections"), dict):
            return "n8n"
        if isinstance(data.get("flow"), list):
            return "make"
        inner = data.get("workflow") or data.get("blueprint")
        if isinstance(inner, dict):
            return detect_format(inner)
    raise SkillportError(
        "This file doesn't look like an n8n workflow (no \"nodes\" list) "
        "or a Make.com blueprint (no \"flow\" list)."
    )


def parse_data(data: Any, fallback_name: str = "workflow") -> list[Workflow]:
    """Parse already-loaded JSON. Lists (n8n "export all") give several workflows."""
    if isinstance(data, list):
        if not data:
            raise SkillportError("The file contains an empty list, so there is nothing to convert.")
        out = []
        for i, item in enumerate(data):
            out.extend(parse_data(item, f"{fallback_name} {i + 1}"))
        return out
    fmt = detect_format(data)
    # Wrapped exports: {"name": ..., "workflow": {...}} (n8n.io templates) or {"blueprint": {...}}
    if isinstance(data, dict) and not isinstance(data.get("nodes"), list) and not isinstance(data.get("flow"), list):
        inner = dict(data.get("workflow") or data.get("blueprint"))
        if not inner.get("name") and data.get("name"):
            inner["name"] = data["name"]
        data = inner
    if fmt == "n8n":
        return [parse_n8n(data, fallback_name)]
    return [parse_make(data, fallback_name)]


def load_json(path: str | Path) -> Any:
    p = Path(path)
    if not p.exists():
        raise SkillportError(f"File not found: {p}")
    if p.is_dir():
        raise SkillportError(f"{p} is a folder. Use `skillport batch {p}` to convert a whole folder.")
    try:
        text = p.read_text(encoding="utf-8-sig")
    except UnicodeDecodeError:
        raise SkillportError(f"{p.name} is not a text file (it should be the .json you exported).") from None
    if not text.strip():
        raise SkillportError(f"{p.name} is empty.")
    try:
        return json.loads(text)
    except json.JSONDecodeError as exc:
        raise SkillportError(
            f"{p.name} is not valid JSON (line {exc.lineno}, column {exc.colno}: {exc.msg}). "
            "Export the workflow again and copy the whole file."
        ) from None


def load_workflows(path: str | Path) -> list[Workflow]:
    p = Path(path)
    return parse_data(load_json(p), fallback_name=p.stem)
