"""Make.com scenario blueprint JSON -> Workflow model.

Blueprint shape (export via "Export Blueprint" in the scenario editor):
  {"name": ..., "flow": [{"id": 1, "module": "app:action", "parameters": {...}, "mapper": {...},
                          "filter": {"name": ..., "conditions": [[{"a", "o", "b"}]]},
                          "routes": [{"flow": [...]}]   # only on builtin:BasicRouter
                         }], "metadata": {...}}
Field names here come from public blueprint exports; see README "verify against current docs".
"""

from __future__ import annotations

import re
from typing import Any

from . import graph
from .credentials import KNOWN
from .model import Edge, Node, SkillportError, Workflow
from .redact import redact
from .text import humanize, iter_strings, one_line

ROUTER = "builtin:BasicRouter"
NO_ACCOUNT_APPS = {"builtin", "gateway", "http", "json", "util", "regexp", "tools", "math", "text-parser",
                   "flow-control", "datastore", "csv", "xml", "markdown", "scenario-service"}
WEBHOOK_MODULES = {"gateway:CustomWebHook"}
TRIGGER_MODULES = {"gateway:CustomWebHook", "gateway:CustomMailHook"}

_MAKE_OPS = {
    "equal": "is equal to", "notequal": "is not equal to", "greater": "is greater than",
    "less": "is less than", "greaterorequal": "is at least", "lessorequal": "is at most",
    "contain": "contains", "notcontain": "does not contain", "startwith": "starts with",
    "endwith": "ends with", "pattern": "matches the pattern", "notpattern": "does not match the pattern",
    "exist": "exists", "notexist": "does not exist", "before": "is before", "after": "is after",
}
_UNARY = {"exist", "notexist"}

APP_NAMES = {
    "google-sheets": "Google Sheets", "google-email": "Gmail", "gmail": "Gmail", "google-drive": "Google Drive",
    "openai-gpt-3": "OpenAI", "openai": "OpenAI", "anthropic-claude": "Anthropic Claude", "slack": "Slack",
    "telegram": "Telegram", "airtable": "Airtable", "notion": "Notion", "hubspotcrm": "HubSpot",
    "stripe": "Stripe", "http": "HTTP API", "json": "JSON", "util": "Tools", "builtin": "Flow control",
    "gateway": "Webhook", "email": "Email", "discord": "Discord", "google-calendar": "Google Calendar",
}


MODULE_LABELS = {
    "gateway:CustomWebHook": "Webhook", "gateway:CustomMailHook": "Mailhook", "gateway:WebhookRespond": "Webhook response",
    "builtin:BasicRouter": "Router", "builtin:BasicFeeder": "Iterator", "builtin:BasicAggregator": "Array aggregator",
    "http:ActionSendData": "HTTP request", "http:ActionSendDataBasicAuth": "HTTP request", "http:ActionGetFile": "Download a file",
    "util:SetVariable2": "Set variable", "util:SetVariables": "Set variables", "util:FunctionSleep": "Sleep",
    "json:ParseJSON": "Parse JSON", "json:CreateJSON": "Create JSON",
}


def module_label(module: str) -> str:
    if module in MODULE_LABELS:
        return MODULE_LABELS[module]
    app, action = _app(module)
    action = re.sub(r"^Action(?=[A-Z])", "", action)
    return f"{_service(app)}: {humanize(action)}"


def _app(module: str) -> tuple[str, str]:
    app, _, action = module.partition(":")
    return app, action


def _service(app: str) -> str:
    return APP_NAMES.get(app) or " ".join(w.capitalize() for w in humanize(app).split()) or "Make"


class _Exprs:
    """Rewrites Make references like {{1.email}} as 'email (from "Webhook")'."""

    def __init__(self) -> None:
        self.names: dict[str, str] = {}

    def pretty(self, value: Any) -> str:
        if value is None:
            return ""
        if not isinstance(value, str):
            return str(value)

        def ref(m: re.Match) -> str:
            mid, path = m.group(1), m.group(2)
            src = self.names.get(mid)
            return f'{path} (from "{src}")' if src else path

        whole = re.fullmatch(r"\s*\{\{\s*(\d+)\.([\w.\[\]]+)\s*\}\}\s*", value)
        if whole:
            return ref(whole)
        s = re.sub(r"\{\{\s*(\d+)\.([\w.\[\]]+)\s*\}\}", lambda m: "{" + ref(m) + "}", value)
        return re.sub(r"\{\{\s*(.*?)\s*\}\}", r"{\1}", s, flags=re.S)


def _filter_text(flt: Any, ex: _Exprs) -> str:
    if not isinstance(flt, dict):
        return ""
    groups = []
    for group in flt.get("conditions") or []:
        parts = []
        for c in group if isinstance(group, list) else []:
            if not isinstance(c, dict):
                continue
            op_full = str(c.get("o") or "equal")
            op = op_full.split(":")[-1].lower()
            words = _MAKE_OPS.get(op, humanize(op))
            left = one_line(ex.pretty(c.get("a")), 80)
            if op in _UNARY:
                parts.append(f"`{left}` {words}")
            else:
                parts.append(f"`{left}` {words} `{one_line(ex.pretty(c.get('b')), 80)}`")
        if parts:
            groups.append(" and ".join(parts))
    cond = " or ".join(groups)
    name = str(flt.get("name") or "").strip()
    if name and cond:
        return f"{name}: {cond}"
    return name or cond


def _describe(module: str, p: dict, m: dict, ex: _Exprs) -> dict:
    app, action = _app(module)
    service = _service(app)
    a = action.lower()
    details: list[str] = []

    def q(v: Any, limit: int = 400) -> str:
        return '"' + one_line(ex.pretty(v), limit) + '"'

    if module == "gateway:CustomWebHook":
        return {"summary": "Starts when data is sent to the scenario's Make.com webhook.", "service": "Webhook",
                "trigger_info": {"kind": "webhook", "method": "POST", "path": ""}}
    if module == "gateway:CustomMailHook":
        return {"summary": "Starts when an email arrives at the scenario's Make.com mail address.",
                "service": "Email", "trigger_info": {"kind": "event", "service": "Email"}}
    if module == "gateway:WebhookRespond":
        if m.get("body"):
            details.append(f"Reply body: `{one_line(ex.pretty(m['body']), 200)}`")
        return {"summary": f"Send a reply (status {m.get('status', 200)}) to whoever called the webhook.",
                "service": "Webhook", "details": details}
    if app == "http":
        method = str(m.get("method") or "get").upper()
        url = one_line(ex.pretty(m.get("url", "")), 300) or "(no URL set)"
        details += [f"Method: {method}", f"URL: `{url}`"]
        for label, key in (("Headers", "headers"), ("Query parameters", "qs")):
            pairs = [f"{h.get('name')}: {one_line(ex.pretty(h.get('value')), 80)}"
                     for h in m.get(key) or [] if isinstance(h, dict) and h.get("name")]
            if pairs:
                details.append(f"{label}: " + "; ".join(pairs))
        if m.get("data"):
            details.append(f"Body: `{one_line(ex.pretty(m['data']), 300)}`")
        return {"summary": f"Send an HTTP {method} request to `{one_line(url, 120)}`.", "service": "HTTP API",
                "details": details}
    if module == ROUTER:
        return {"summary": "Split into routes. Every route whose filter matches runs, in order.", "service": ""}
    if module == "builtin:BasicFeeder":
        return {"summary": f"Go through each item of `{one_line(ex.pretty(m.get('array')), 80)}` one by one.",
                "service": ""}
    if module == "builtin:BasicAggregator":
        return {"summary": "Combine the items back into one bundle.", "service": ""}
    if app == "util" and a.startswith("setvariable"):
        pairs = [(m.get("name"), m.get("value"))] if m.get("name") else []
        pairs += [(v.get("name"), v.get("value")) for v in m.get("variables") or [] if isinstance(v, dict)]
        details = [f"`{n}` = {one_line(ex.pretty(v), 120)}" for n, v in pairs if n]
        return {"summary": "Set these variables: " + ", ".join(str(n) for n, _ in pairs if n) + ".",
                "service": "", "details": details}
    if app == "util" and "sleep" in a:
        return {"summary": f"Wait {m.get('duration', 1)} seconds.", "service": ""}
    if app == "json":
        return {"summary": "Parse JSON text into data." if "parse" in a else "Build a JSON text.", "service": ""}
    if app in ("openai-gpt-3", "openai", "anthropic-claude"):
        model = m.get("model")
        texts = []
        for msg in m.get("messages") or []:
            if isinstance(msg, dict) and msg.get("content"):
                texts.append(f"{str(msg.get('role', 'user')).capitalize()} message: {q(msg['content'], 1500)}")
        if m.get("prompt"):
            texts.append(f"Prompt: {q(m['prompt'], 1500)}")
        model_s = f" (model {model})" if model else ""
        verb = "Create an image" if "image" in a else "Ask " + service + model_s + " to write a reply"
        return {"summary": f"{verb}.", "service": service, "details": texts}
    if app == "google-sheets":
        verbs = {"addrow": "Add a row to", "updaterow": "Update a row in", "filterrows": "Search rows in",
                 "searchrows": "Search rows in", "getsheetcontent": "Read rows from", "deleterow": "Delete a row from",
                 "watchrows": "Watch for new rows in"}
        sheet = m.get("sheetId") or m.get("sheetName") or ""
        where = f"the sheet \"{ex.pretty(sheet)}\"" if sheet else "a sheet"
        vals = m.get("values")
        if isinstance(vals, dict) and vals:
            details.append("Values: " + "; ".join(f"column {k} = {one_line(ex.pretty(v), 60)}" for k, v in vals.items()))
        return {"summary": f"{verbs.get(a, humanize(action).capitalize() + ' in')} {where} in Google Sheets.",
                "service": service, "details": details}
    if app in ("google-email", "gmail", "email") and "send" in a:
        to = m.get("to")
        to_s = ", ".join(map(ex.pretty, to)) if isinstance(to, list) else ex.pretty(to or "")
        if m.get("subject"):
            details.append(f"Subject: {q(m['subject'], 150)}")
        body = m.get("html") or m.get("content") or m.get("text")
        if body:
            details.append(f"Message: {q(body)}")
        return {"summary": f"Send an email with {service} to `{one_line(to_s, 80)}`.", "service": service,
                "details": details}
    if app in ("slack", "telegram", "discord") and ("message" in a or "send" in a):
        where = m.get("channel") or m.get("chatId") or ""
        if m.get("text"):
            details.append(f"Message: {q(m['text'])}")
        to = f" to `{one_line(ex.pretty(where), 60)}`" if where else ""
        return {"summary": f"Post a message on {service}{to}.", "service": service, "details": details}
    if app == "airtable":
        table = m.get("table") or ""
        return {"summary": f"Airtable: {humanize(action.replace('Action', ''))}" +
                           (f" in table \"{ex.pretty(table)}\"" if table else "") + ".", "service": service}
    # generic fallback
    details.append(f"Make module `{module}` has no built-in description; check the original scenario for details.")
    shown = 0
    for k, v in m.items():
        if isinstance(v, (dict, list)) or v in ("", None):
            continue
        details.append(f"`{k}`: {one_line(ex.pretty(v), 120)}")
        shown += 1
        if shown >= 6:
            break
    return {"summary": f"{service}: {humanize(action)}.", "service": service, "details": details}


def _is_trigger(module: str) -> bool:
    if module in TRIGGER_MODULES:
        return True
    _, action = _app(module)
    return action.lower().startswith(("watch", "trigger", "listen"))


def parse_make(data: Any, fallback_name: str = "Make scenario") -> Workflow:
    if not isinstance(data, dict) or not isinstance(data.get("flow"), list):
        raise SkillportError("A Make.com blueprint must be a JSON object with a \"flow\" list.")
    name = str(data.get("name") or "").strip() or fallback_name
    wf = Workflow(name=name, source_format="make", raw=data)
    ex = _Exprs()
    modules: list[tuple[dict, list]] = []  # (module dict, its parent flow list)

    def collect(flow: list) -> None:
        for mod in flow:
            if not isinstance(mod, dict):
                wf.warnings.append("A module that is not an object was skipped.")
                continue
            modules.append((mod, flow))
            for route in mod.get("routes") or []:
                if isinstance(route, dict) and isinstance(route.get("flow"), list):
                    collect(route["flow"])

    collect(data["flow"])
    # Names first, so references like {{3.text}} can be shown with the step name.
    ids: dict[int, str] = {}
    for i, (mod, _) in enumerate(modules):
        mid = str(mod.get("id", f"m{i + 1}"))
        if mid in ex.names:
            mid = f"{mid}-{i + 1}"
        ids[id(mod)] = mid
        module = str(mod.get("module") or "unknown:unknown")
        app, action = _app(module)
        label = None
        meta = mod.get("metadata")
        if isinstance(meta, dict) and isinstance(meta.get("designer"), dict):
            label = meta["designer"].get("name")
        base = str(label or module_label(module))
        names = set(ex.names.values())
        ex.names[mid] = base if base not in names else f"{base} (#{mid})"

    for mod, _ in modules:
        mid = ids[id(mod)]
        module = str(mod.get("module") or "unknown:unknown")
        app, _action = _app(module)
        params = redact(mod.get("parameters") if isinstance(mod.get("parameters"), dict) else {})
        mapper = redact(mod.get("mapper") if isinstance(mod.get("mapper"), dict) else {})
        try:
            desc = _describe(module, params, mapper, ex)
        except Exception:
            desc = {"summary": f"{_service(app)}: {humanize(_action)}.", "service": _service(app)}
        details = list(desc.get("details") or [])
        cond = _filter_text(mod.get("filter"), ex)
        if cond:
            details.insert(0, f"Only runs if {cond}.")
        creds = []
        if app not in NO_ACCOUNT_APPS and ("__IMTCONN__" in params or app in KNOWN):
            creds.append((app, ""))
        wf.nodes[mid] = Node(
            id=mid, name=ex.names[mid], type=module, summary=desc["summary"], service=desc.get("service", ""),
            details=details, credentials=creds, trigger_info=dict(desc.get("trigger_info") or {}),
            disabled=bool(mod.get("disabled")),
        )
        if module == ROUTER:
            node = wf.nodes[mid]
            node.branch_style = "router"
            for r_i, route in enumerate(mod.get("routes") or []):
                first = (route.get("flow") or [None])[0] if isinstance(route, dict) else None
                cond = _filter_text(first.get("filter"), ex) if isinstance(first, dict) else ""
                node.outputs.append(f"Route {r_i + 1} (only if {cond})" if cond else f"Route {r_i + 1} (always)")

    # Links: each module leads to the next one in its flow; routers lead to the first module of each route.
    def link(flow: list) -> None:
        prev: dict | None = None
        for mod in flow:
            if not isinstance(mod, dict):
                continue
            if prev is not None:
                wf.edges.append(Edge(ids[id(prev)], ids[id(mod)], 0))
            if mod.get("module") == ROUTER:
                for r_i, route in enumerate(mod.get("routes") or []):
                    rflow = route.get("flow") if isinstance(route, dict) else None
                    if isinstance(rflow, list):
                        first = next((x for x in rflow if isinstance(x, dict)), None)
                        if first is not None:
                            wf.edges.append(Edge(ids[id(mod)], ids[id(first)], r_i))
                        link(rflow)
            prev = mod

    link(data["flow"])

    top = [m for m in data["flow"] if isinstance(m, dict)]
    if top and _is_trigger(str(top[0].get("module") or "")):
        first = wf.nodes[ids[id(top[0])]]
        first.is_trigger = True
        if not first.trigger_info:
            first.trigger_info = {"kind": "event", "service": first.service}
            first.summary = f"Starts when something new happens in {first.service}: {first.summary[0].lower()}{first.summary[1:]}"
    elif top:
        start = Node(id="start", name="Scenario start", type="make:start",
                     summary="Starts when the scenario runs (on its Make.com schedule or when run by hand).",
                     is_trigger=True, trigger_info={"kind": "schedule", "when": "on its Make.com schedule"})
        wf.nodes = {"start": start, **wf.nodes}
        wf.edges.insert(0, Edge("start", ids[id(top[0])], 0))

    graph.analyze(wf)
    wf.inputs = _collect_inputs(wf, modules, ids)
    return wf


def _collect_inputs(wf: Workflow, modules: list, ids: dict) -> list[str]:
    hook = wf.webhook
    if hook is None:
        return []
    fields: list[str] = []
    pat = re.compile(r"\{\{\s*" + re.escape(hook.id) + r"\.([\w.\[\]]+)")
    for mod, _ in modules:
        for s in iter_strings({k: mod.get(k) for k in ("mapper", "parameters", "filter", "routes")}):
            for f in pat.findall(s):
                if f not in fields:
                    fields.append(f)
    return fields
