"""The internal model shared by the n8n and Make.com importers.

Both importers turn their JSON into a :class:`Workflow`; everything after that
(ordering, SKILL.md, README, inspect) only looks at this model.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


class SkillportError(Exception):
    """A problem we can explain to the user in plain English."""


@dataclass
class Node:
    """One step (or trigger) of a workflow."""

    id: str
    name: str
    type: str
    summary: str
    service: str = ""
    details: list[str] = field(default_factory=list)
    is_trigger: bool = False
    disabled: bool = False
    # (credential type, account name) pairs, e.g. ("slackApi", "Team Slack")
    credentials: list[tuple[str, str]] = field(default_factory=list)
    # Labels of the outputs when the node branches, e.g. ["If x", "Otherwise"].
    outputs: list[str] = field(default_factory=list)
    branch_style: str = ""  # "if", "switch", "router", "multi" or ""
    # Plain-English descriptions of AI sub-nodes (models, memory, tools) attached to this node.
    attachments: list[str] = field(default_factory=list)
    is_subnode: bool = False
    # For triggers: {"kind": "webhook", "method": "POST", "path": "lead"} etc.
    trigger_info: dict[str, Any] = field(default_factory=dict)
    # Optional code block: (language, code)
    code: tuple[str, str] | None = None


@dataclass
class Edge:
    source: str
    target: str
    output: int = 0
    kind: str = "main"


@dataclass
class Credential:
    key: str
    service: str
    env_var: str
    accounts: list[str] = field(default_factory=list)
    used_by: list[str] = field(default_factory=list)


@dataclass
class Workflow:
    name: str
    source_format: str  # "n8n" or "make"
    nodes: dict[str, Node] = field(default_factory=dict)
    edges: list[Edge] = field(default_factory=list)
    notes: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
    inputs: list[str] = field(default_factory=list)
    raw: Any = None
    # Filled in by graph.analyze()
    steps: list[str] = field(default_factory=list)
    cycles: list[list[str]] = field(default_factory=list)
    unconnected: list[str] = field(default_factory=list)
    disabled: list[str] = field(default_factory=list)
    flow_edges: list[Edge] = field(default_factory=list)

    @property
    def triggers(self) -> list[Node]:
        return [self.nodes[n] for n in self.steps if self.nodes[n].is_trigger]

    @property
    def webhook(self) -> Node | None:
        for node in self.triggers:
            if node.trigger_info.get("kind") == "webhook":
                return node
        return None

    def step_number(self, node_id: str) -> int:
        return self.steps.index(node_id) + 1

    def successors(self, node_id: str) -> list[Edge]:
        return [e for e in self.flow_edges if e.source == node_id]

    def predecessors(self, node_id: str) -> list[Edge]:
        return [e for e in self.flow_edges if e.target == node_id]

    def services(self) -> list[str]:
        seen: list[str] = []
        for nid in self.steps:
            s = self.nodes[nid].service
            if s and s not in seen:
                seen.append(s)
        return seen
