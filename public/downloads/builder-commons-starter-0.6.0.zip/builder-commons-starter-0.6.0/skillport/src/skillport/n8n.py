"""n8n workflow export JSON -> Workflow model.

n8n export shape (as of n8n 1.x):
  {"name": ..., "nodes": [{"name", "type", "typeVersion", "parameters", "credentials", "disabled"}],
   "connections": {"Source node name": {"main": [[{"node": "Target", "type": "main", "index": 0}], ...]}}}
AI sub-nodes (chat models, memory, tools) connect with kinds like "ai_languageModel" instead of "main".
"""

from __future__ import annotations

import re
from typing import Any, Callable

from . import graph
from .model import Edge, Node, SkillportError, Workflow
from .redact import redact, redact_text
from .text import humanize, iter_strings, json_refs, node_refs, one_line, pretty_expr, resource_name, truncate

STICKY = "stickynote"
TRIGGER_SUFFIXES = {"webhook", "cron", "interval", "start", "manualtrigger", "scheduletrigger", "emailreadimap"}
PROMPT_LIMIT = 1500
CODE_LINES = 60

Desc = dict[str, Any]


def node_key(node_type: str) -> str:
    """'n8n-nodes-base.httpRequest' -> 'httprequest'; langchain nodes get an 'lc.' prefix."""
    t = node_type or ""
    suffix = t.rsplit(".", 1)[-1].lower()
    return ("lc." + suffix) if "langchain" in t.lower() else suffix


def is_trigger_type(node_type: str) -> bool:
    key = node_key(node_type)
    bare = key[3:] if key.startswith("lc.") else key
    return "trigger" in bare or bare in TRIGGER_SUFFIXES


def _get(obj: Any, *path: str, default: Any = None) -> Any:
    for key in path:
        if not isinstance(obj, dict) or key not in obj:
            return default
        obj = obj[key]
    return obj


def _service_from_type(node_type: str) -> str:
    suffix = node_type.rsplit(".", 1)[-1] if node_type else "unknown"
    for cut in ("Trigger", "Tool"):
        if suffix.endswith(cut) and len(suffix) > len(cut):
            suffix = suffix[: -len(cut)]
    if len(suffix) > 4 and suffix.startswith("tool") and suffix[4].isupper():
        suffix = suffix[4:]
    words = humanize(suffix).split()
    return " ".join(w.capitalize() for w in words) or "Unknown"


_WHOLE_EXPR = re.compile(r"=?\s*\{\{(?:(?!\}\}).)*\}\}", re.DOTALL)


def _quote(text: Any, limit: int = 120) -> str:
    """Quote literal text; a value that is only an expression is shown as a field reference."""
    if isinstance(text, str) and _WHOLE_EXPR.fullmatch(text.strip()):
        return f"the value of `{one_line(pretty_expr(text), limit)}`"
    return '"' + one_line(pretty_expr(text), limit) + '"'


# ---------------------------------------------------------------- conditions

_OPS = {
    "equals": "is equal to", "equal": "is equal to", "notequals": "is not equal to", "notequal": "is not equal to",
    "gt": "is greater than", "larger": "is greater than", "gte": "is at least", "largerequal": "is at least",
    "lt": "is less than", "smaller": "is less than", "lte": "is at most", "smallerequal": "is at most",
    "contains": "contains", "notcontains": "does not contain", "startswith": "starts with",
    "notstartswith": "does not start with", "endswith": "ends with", "notendswith": "does not end with",
    "regex": "matches the pattern", "notregex": "does not match the pattern", "exists": "exists",
    "notexists": "does not exist", "empty": "is empty", "isempty": "is empty", "notempty": "is not empty",
    "isnotempty": "is not empty", "true": "is true", "false": "is false", "after": "is after",
    "before": "is before", "lengthequals": "has length", "lengthgt": "has length greater than",
    "lengthlt": "has length less than",
}
_UNARY = {"exists", "notexists", "empty", "isempty", "notempty", "isnotempty", "true", "false"}


def _condition_text(left: Any, operation: str, right: Any) -> str:
    op = (operation or "equals").lower()
    words = _OPS.get(op, humanize(operation or "equals"))
    left_s = one_line(pretty_expr(left), 80) or "(empty)"
    if op in _UNARY:
        return f"`{left_s}` {words}"
    right_s = one_line(pretty_expr(right), 80)
    return f"`{left_s}` {words} `{right_s}`"


def summarize_conditions(params: dict) -> str:
    """Readable summary of an IF / Filter node's conditions (n8n v1 and v2 formats)."""
    conds = params.get("conditions")
    parts: list[str] = []
    joiner = " and "
    if isinstance(conds, dict) and isinstance(conds.get("conditions"), list):  # v2+
        if str(conds.get("combinator", "and")).lower() == "or":
            joiner = " or "
        for c in conds["conditions"]:
            if not isinstance(c, dict):
                continue
            op = _get(c, "operator", "operation", default="equals")
            parts.append(_condition_text(c.get("leftValue"), op, c.get("rightValue")))
    elif isinstance(conds, dict):  # v1: {"string": [...], "number": [...], "boolean": [...]}
        if str(params.get("combineOperation", "all")).lower() == "any":
            joiner = " or "
        for group in conds.values():
            for c in group if isinstance(group, list) else []:
                if isinstance(c, dict):
                    parts.append(_condition_text(c.get("value1"), c.get("operation", "equal"), c.get("value2")))
    if not parts:
        return "the condition set in the original workflow is met"
    return joiner.join(parts)


# ---------------------------------------------------------------- describers
# Each takes (redacted params, raw node) and returns a dict with any of:
# summary, service, details, outputs, branch_style, trigger_info, code


def _webhook(p: dict, node: dict) -> Desc:
    method = str(p.get("httpMethod") or "GET").upper()
    path = str(p.get("path") or node.get("webhookId") or "").strip("/")
    info = {"kind": "webhook", "method": method, "path": path, "auth": p.get("authentication") or "none"}
    details = [f"Method: {method}", f"Path: `/{path}`"]
    if info["auth"] not in ("none", None, ""):
        details.append(f"Callers must authenticate ({humanize(str(info['auth']))}).")
    if p.get("responseMode"):
        details.append(f"Reply mode: {humanize(str(p['responseMode']))}.")
    return {
        "summary": f"Starts when a {method} request arrives at the webhook path `/{path}`.",
        "service": "Webhook",
        "details": details,
        "trigger_info": info,
    }


def _schedule_text(p: dict) -> str:
    rules = _get(p, "rule", "interval", default=None)
    texts = []
    for r in rules or [{}]:
        if not isinstance(r, dict):
            continue
        field = r.get("field", "days")
        if field == "cronExpression":
            texts.append(f"on the cron schedule `{r.get('expression', '')}`")
            continue
        n = r.get(f"{field}Interval", 1)
        unit = field if str(n) != "1" else field.rstrip("s")
        text = f"every {unit}" if str(n) == "1" else f"every {n} {unit}"
        if field in ("days", "weeks", "months") and "triggerAtHour" in r:
            text += f" at {int(r.get('triggerAtHour', 0)):02d}:{int(r.get('triggerAtMinute', 0) or 0):02d}"
        texts.append(text)
    return " and ".join(texts) or "on a schedule"


def _schedule(p: dict, node: dict) -> Desc:
    when = _schedule_text(p)
    return {"summary": f"Starts automatically {when}.", "service": "Schedule",
            "trigger_info": {"kind": "schedule", "when": when}}


def _cron(p: dict, node: dict) -> Desc:
    texts = []
    for item in _get(p, "triggerTimes", "item", default=[]) or []:
        mode = item.get("mode", "everyDay")
        if mode == "custom":
            texts.append(f"on the cron schedule `{item.get('cronExpression', '')}`")
        elif mode == "everyMinute":
            texts.append("every minute")
        elif mode == "everyHour":
            texts.append(f"every hour at minute {item.get('minute', 0)}")
        else:
            texts.append(f"{humanize(mode)} at {int(item.get('hour', 0)):02d}:{int(item.get('minute', 0)):02d}")
    when = " and ".join(texts) or "on a schedule"
    return {"summary": f"Starts automatically {when}.", "service": "Schedule",
            "trigger_info": {"kind": "schedule", "when": when}}


def _interval(p: dict, node: dict) -> Desc:
    when = f"every {p.get('interval', 1)} {p.get('unit', 'seconds')}"
    return {"summary": f"Starts automatically {when}.", "service": "Schedule",
            "trigger_info": {"kind": "schedule", "when": when}}


def _manual(p: dict, node: dict) -> Desc:
    return {"summary": "Starts when someone runs the workflow by hand.", "service": "",
            "trigger_info": {"kind": "manual"}}


def _form(p: dict, node: dict) -> Desc:
    fields = [f.get("fieldLabel") for f in _get(p, "formFields", "values", default=[]) or [] if isinstance(f, dict)]
    title = p.get("formTitle") or "a form"
    return {"summary": f"Starts when someone submits the form {_quote(title)}.", "service": "n8n Form",
            "details": [f"Form fields: {', '.join(map(str, fields))}"] if fields else [],
            "trigger_info": {"kind": "form", "fields": [str(f) for f in fields]}}


def _chat_trigger(p: dict, node: dict) -> Desc:
    return {"summary": "Starts when a chat message arrives.", "service": "Chat",
            "trigger_info": {"kind": "chat"}}


def _sub_trigger(p: dict, node: dict) -> Desc:
    return {"summary": "Starts when another workflow calls this one.", "service": "",
            "trigger_info": {"kind": "subworkflow"}}


def _generic_trigger(p: dict, node: dict) -> Desc:
    service = _service_from_type(node.get("type", ""))
    event = p.get("event") or p.get("events") or p.get("updates") or p.get("triggerOn")
    if isinstance(event, list):
        event = ", ".join(map(str, event))
    what = f" ({humanize(str(event))})" if event else ""
    return {"summary": f"Starts when something happens in {service}{what}.", "service": service,
            "trigger_info": {"kind": "event", "service": service, "event": str(event or "")}}


def _http(p: dict, node: dict) -> Desc:
    method = str(p.get("method") or p.get("requestMethod") or "GET").upper()
    url = pretty_expr(p.get("url", "")) or "(no URL set)"
    details = [f"Method: {method}", f"URL: `{one_line(url, 300)}`"]
    auth = p.get("authentication")
    if auth and auth != "none":
        kind = p.get("genericAuthType") or p.get("nodeCredentialType") or auth
        details.append(f"Authentication: {humanize(str(kind))} (use the matching credential below).")
    for label, key in (("Headers", "headerParameters"), ("Query parameters", "queryParameters"),
                       ("Body fields", "bodyParameters")):
        items = _get(p, key, "parameters", default=[]) or []
        pairs = [f"{i.get('name')}: {one_line(pretty_expr(i.get('value', '')), 80)}"
                 for i in items if isinstance(i, dict) and i.get("name")]
        if pairs:
            details.append(f"{label}: " + "; ".join(pairs))
    if p.get("jsonBody") or p.get("body"):
        details.append("JSON body: `" + one_line(pretty_expr(p.get("jsonBody") or p.get("body")), 300) + "`")
    return {"summary": f"Send an HTTP {method} request to `{one_line(url, 120)}`.", "service": "HTTP API",
            "details": details}


def _set(p: dict, node: dict) -> Desc:
    pairs: list[tuple[str, Any]] = []
    for a in _get(p, "assignments", "assignments", default=[]) or []:
        if isinstance(a, dict):
            pairs.append((a.get("name"), a.get("value")))
    for group in ("string", "number", "boolean"):
        for a in _get(p, "values", group, default=[]) or []:
            if isinstance(a, dict):
                pairs.append((a.get("name"), a.get("value")))
    for a in _get(p, "fields", "values", default=[]) or []:
        if isinstance(a, dict):
            val = next((a[k] for k in a if k.endswith("Value")), "")
            pairs.append((a.get("name"), val))
    names = [str(n) for n, _ in pairs if n]
    if p.get("mode") == "raw" and p.get("jsonOutput"):
        return {"summary": "Build the data as JSON.", "service": "",
                "details": ["JSON: `" + one_line(pretty_expr(p["jsonOutput"]), 300) + "`"]}
    summary = f"Set these fields: {', '.join(names)}." if names else "Set or rename fields on the data."
    details = [f"`{n}` = {one_line(pretty_expr(v), 120)}" for n, v in pairs if n]
    return {"summary": summary, "service": "", "details": details}


def _if(p: dict, node: dict) -> Desc:
    cond = summarize_conditions(p)
    return {"summary": f"Check whether {cond}.", "service": "", "outputs": [f"If {cond}", "Otherwise"],
            "branch_style": "if"}


def _filter(p: dict, node: dict) -> Desc:
    return {"summary": f"Keep only the items where {summarize_conditions(p)}; drop the rest.", "service": ""}


def _switch(p: dict, node: dict) -> Desc:
    outputs: list[str] = []
    rules = _get(p, "rules", "values", default=None)
    if isinstance(rules, list):  # v3
        for i, r in enumerate(rules):
            label = r.get("outputKey") if r.get("renameOutput") else None
            cond = summarize_conditions(r) if isinstance(r.get("conditions"), dict) else f"rule {i + 1} matches"
            outputs.append(f"If {cond}" + (f" (\"{label}\")" if label else ""))
        fallback = _get(p, "options", "fallbackOutput", default="none")
        if fallback == "extra":
            outputs.append("Otherwise")
    else:  # v1/v2
        old = _get(p, "rules", "rules", default=[]) or []
        value1 = p.get("value1", "")
        slots: dict[int, str] = {}
        for r in old:
            if isinstance(r, dict):
                idx = int(r.get("output", len(slots)) or 0)
                slots.setdefault(idx, "If " + _condition_text(value1, r.get("operation", "equal"), r.get("value2")))
        if slots:
            outputs = [slots.get(i, f"Output {i + 1}") for i in range(max(slots) + 1)]
        fb = p.get("fallbackOutput")
        if isinstance(fb, int) and fb >= 0:
            while len(outputs) <= fb:
                outputs.append(f"Output {len(outputs) + 1}")
            outputs[fb] = "Otherwise"
        if p.get("mode") == "expression":
            outputs = [f"Output {i + 1}" for i in range(int(p.get("outputsAmount", 4) or 4))]
    return {"summary": "Choose a path based on the rules below.", "service": "", "outputs": outputs,
            "branch_style": "switch"}


def _merge(p: dict, node: dict) -> Desc:
    mode = p.get("mode", "append")
    extra = f" (mode: {humanize(str(mode))})" if mode else ""
    return {"summary": f"Wait for the incoming branches and combine their data{extra}.", "service": ""}


def _code(p: dict, node: dict) -> Desc:
    lang = str(p.get("language") or "javaScript")
    code = p.get("pythonCode") if lang.lower().startswith("python") else p.get("jsCode")
    code = code or p.get("functionCode") or p.get("code") or ""
    language = "python" if lang.lower().startswith("python") else "javascript"
    lines = str(code).strip("\n").splitlines()
    shown = "\n".join(lines[:CODE_LINES]) + ("\n// ... (cut, see source/workflow.json)" if len(lines) > CODE_LINES else "")
    mode = p.get("mode")
    per = " once for each item" if mode == "runOnceForEachItem" or node_key(node.get("type", "")) == "functionitem" else ""
    label = "Python" if language == "python" else "JavaScript"
    return {"summary": f"Run custom {label} code{per} ({len(lines)} lines).",
            "service": "", "code": (language, redact_text(shown)) if lines else None}


def _split_batches(p: dict, node: dict) -> Desc:
    size = p.get("batchSize", 10)
    desc: Desc = {"summary": f"Go through the items in batches of {size}.", "service": ""}
    if float(node.get("typeVersion") or 1) >= 3:
        desc["outputs"] = ["When all batches are done", "For each batch"]
        desc["branch_style"] = "multi"
    return desc


def _split_out(p: dict, node: dict) -> Desc:
    return {"summary": f"Split the list in `{p.get('fieldToSplitOut', 'the chosen field')}` into separate items.",
            "service": ""}


def _aggregate(p: dict, node: dict) -> Desc:
    return {"summary": "Combine all items into a single list.", "service": ""}


def _wait(p: dict, node: dict) -> Desc:
    resume = p.get("resume", "timeInterval")
    if resume == "webhook":
        return {"summary": "Pause until a follow-up webhook call arrives.", "service": ""}
    if resume == "specificTime":
        return {"summary": f"Pause until {pretty_expr(p.get('dateTime', 'a set time'))}.", "service": ""}
    return {"summary": f"Wait {p.get('amount', 1)} {p.get('unit', 'seconds')}.", "service": ""}


def _respond(p: dict, node: dict) -> Desc:
    how = p.get("respondWith", "firstIncomingItem")
    body = p.get("responseBody")
    details = [f"Reply body: `{one_line(pretty_expr(body), 200)}`"] if body else []
    return {"summary": f"Send a reply to whoever called the webhook ({humanize(str(how))}).",
            "service": "Webhook", "details": details}


def _noop(p: dict, node: dict) -> Desc:
    return {"summary": "Do nothing (a placeholder step).", "service": ""}


def _gmail(p: dict, node: dict) -> Desc:
    op = p.get("operation", "send")
    if op == "send" or op == "reply":
        to = pretty_expr(p.get("sendTo") or p.get("toList") or "")
        details = []
        if p.get("subject"):
            details.append(f"Subject: {_quote(p['subject'], 150)}")
        if p.get("message"):
            details.append(f"Message: {_quote(p['message'], 400)}")
        verb = "Reply to an email" if op == "reply" else f"Send an email with Gmail to `{one_line(to, 80)}`"
        return {"summary": f"{verb}.", "service": "Gmail", "details": details}
    return {"summary": f"Gmail: {humanize(str(op))} {humanize(str(p.get('resource', 'message')))}.",
            "service": "Gmail"}


def _email_send(p: dict, node: dict) -> Desc:
    details = [f"Subject: {_quote(p['subject'], 150)}"] if p.get("subject") else []
    body = p.get("text") or p.get("html") or p.get("message")
    if body:
        details.append(f"Message: {_quote(body, 400)}")
    to = one_line(pretty_expr(p.get("toEmail", "")), 80)
    return {"summary": f"Send an email (SMTP) to `{to}`.", "service": "Email (SMTP)", "details": details}


def _sheets(p: dict, node: dict) -> Desc:
    op = str(p.get("operation", "append"))
    doc = resource_name(p.get("documentId")) or pretty_expr(p.get("sheetId", ""))
    sheet = resource_name(p.get("sheetName")) or pretty_expr(p.get("range", ""))
    verbs = {"append": "Add a row to", "appendOrUpdate": "Add or update a row in", "update": "Update a row in",
             "read": "Read rows from", "lookup": "Look up rows in", "get": "Read rows from",
             "clear": "Clear", "delete": "Delete rows from", "create": "Create"}
    verb = verbs.get(op, humanize(op).capitalize() + " in")
    where = f"the sheet \"{sheet}\"" if sheet else "a sheet"
    if doc:
        where += f" of the spreadsheet \"{doc}\""
    details = []
    cols = _get(p, "columns", "value", default=None)
    if isinstance(cols, dict) and cols:
        details.append("Columns: " + "; ".join(f"{k} = {one_line(pretty_expr(v), 60)}" for k, v in cols.items()))
    return {"summary": f"{verb} {where} in Google Sheets.", "service": "Google Sheets", "details": details}


def _slack(p: dict, node: dict) -> Desc:
    op = p.get("operation", "post")
    channel = resource_name(p.get("channelId")) or pretty_expr(p.get("channel", "")) or resource_name(p.get("user"))
    if op in ("post", "send", "postMessage"):
        details = [f"Message: {_quote(p.get('text', ''), 400)}"] if p.get("text") else []
        where = f" to `{channel}`" if channel else ""
        return {"summary": f"Post a message on Slack{where}.", "service": "Slack", "details": details}
    return {"summary": f"Slack: {humanize(str(op))} {humanize(str(p.get('resource', 'message')))}.",
            "service": "Slack"}


def _telegram(p: dict, node: dict) -> Desc:
    op = p.get("operation", "sendMessage")
    details = [f"Message: {_quote(p['text'], 400)}"] if p.get("text") else []
    chat = one_line(pretty_expr(p.get("chatId", "")), 60)
    summary = f"Send a Telegram message to chat `{chat}`." if op == "sendMessage" else f"Telegram: {humanize(str(op))}."
    return {"summary": summary, "service": "Telegram", "details": details}


def _airtable(p: dict, node: dict) -> Desc:
    op = str(p.get("operation", "append"))
    verbs = {"append": "Create a record in", "create": "Create a record in", "search": "Search records in",
             "list": "List records in", "update": "Update a record in", "upsert": "Create or update a record in",
             "delete": "Delete a record from", "get": "Get a record from", "read": "Get a record from"}
    table = resource_name(p.get("table")) or "a table"
    base = resource_name(p.get("base") or p.get("application"))
    where = f"table \"{table}\"" + (f" (base \"{base}\")" if base else "")
    return {"summary": f"{verbs.get(op, humanize(op).capitalize() + ' in')} Airtable {where}.", "service": "Airtable"}


def _notion(p: dict, node: dict) -> Desc:
    op = str(p.get("operation", "create"))
    res = str(p.get("resource", "page"))
    db = resource_name(p.get("databaseId"))
    where = f" in the database \"{db}\"" if db else ""
    title = f" titled {_quote(p['title'], 80)}" if p.get("title") else ""
    return {"summary": f"Notion: {humanize(op)} {humanize(res)}{where}{title}.", "service": "Notion"}


def _crm(service: str, default_res: str) -> Callable[[dict, dict], Desc]:
    def describe(p: dict, node: dict) -> Desc:
        res = humanize(str(p.get("resource", default_res)))
        op = humanize(str(p.get("operation", "create")))
        details = [f"Email: {one_line(pretty_expr(p['email']), 80)}"] if p.get("email") else []
        return {"summary": f"{service}: {op} {res}.", "service": service, "details": details}
    return describe


def _prompt_details(texts: list[tuple[str, Any]]) -> list[str]:
    out = []
    for label, text in texts:
        if text:
            out.append(f"{label}: {_quote(text, PROMPT_LIMIT)}")
    return out


def _model_name(p: dict) -> str:
    return resource_name(p.get("modelId") or p.get("model") or "")


def _openai(p: dict, node: dict) -> Desc:
    resource = str(p.get("resource", "text"))
    model = _model_name(p)
    model_s = f" (model {model})" if model else ""
    if resource == "image":
        return {"summary": f"Create an image with OpenAI{model_s}.", "service": "OpenAI",
                "details": _prompt_details([("Prompt", p.get("prompt"))])}
    if resource == "audio":
        return {"summary": f"OpenAI audio: {humanize(str(p.get('operation', 'transcribe')))}{model_s}.",
                "service": "OpenAI"}
    texts: list[tuple[str, Any]] = []
    for m in _get(p, "messages", "values", default=[]) or []:
        if isinstance(m, dict):
            texts.append((f"{str(m.get('role', 'user')).capitalize()} message", m.get("content")))
    for m in _get(p, "prompt", "messages", default=[]) or []:
        if isinstance(m, dict):
            texts.append((f"{str(m.get('role', 'user')).capitalize()} message", m.get("content")))
    if isinstance(p.get("prompt"), str):
        texts.append(("Prompt", p["prompt"]))
    if p.get("jsonOutput"):
        texts.append(("Output", "reply as JSON"))
    return {"summary": f"Ask OpenAI{model_s} to write a reply.", "service": "OpenAI", "details": _prompt_details(texts)}


def _agent(p: dict, node: dict) -> Desc:
    texts: list[tuple[str, Any]] = []
    if p.get("promptType") == "define" or p.get("text"):
        texts.append(("Task", p.get("text")))
    else:
        texts.append(("Task", "the incoming chat message"))
    texts.append(("System message", _get(p, "options", "systemMessage")))
    return {"summary": "Run an AI agent on the task below.", "service": "AI agent", "details": _prompt_details(texts)}


def _chain(p: dict, node: dict) -> Desc:
    texts: list[tuple[str, Any]] = [("Prompt", p.get("text") or p.get("prompt"))]
    for m in _get(p, "messages", "messageValues", default=[]) or []:
        if isinstance(m, dict):
            texts.append(("Instruction", m.get("message")))
    return {"summary": "Ask an AI model to answer the prompt below.", "service": "AI model",
            "details": _prompt_details(texts)}


def _chat_model(vendor: str) -> Callable[[dict, dict], Desc]:
    def describe(p: dict, node: dict) -> Desc:
        model = _model_name(p)
        return {"summary": f"{vendor} chat model" + (f" ({model})" if model else ""), "service": vendor}
    return describe


def _memory(p: dict, node: dict) -> Desc:
    n = p.get("contextWindowLength")
    return {"summary": "Chat memory" + (f" (last {n} messages)" if n else ""), "service": ""}


def _parser(p: dict, node: dict) -> Desc:
    example = p.get("jsonSchemaExample") or p.get("inputSchema")
    return {"summary": "Reply in a fixed JSON format" + (f": `{one_line(example, 200)}`" if example else ""),
            "service": ""}


def _exec_workflow(p: dict, node: dict) -> Desc:
    target = resource_name(p.get("workflowId")) or "another workflow"
    return {"summary": f"Run the n8n workflow \"{target}\" and use its result.", "service": "n8n"}


def _discord(p: dict, node: dict) -> Desc:
    details = [f"Message: {_quote(p.get('text') or p.get('content'), 400)}"] if (p.get("text") or p.get("content")) else []
    return {"summary": "Send a message to Discord.", "service": "Discord", "details": details}


def _drive(p: dict, node: dict) -> Desc:
    op = humanize(str(p.get("operation", "upload")))
    folder = resource_name(p.get("folderId"))
    return {"summary": f"Google Drive: {op} file" + (f" in folder \"{folder}\"" if folder else "") + ".",
            "service": "Google Drive"}


REGISTRY: dict[str, Callable[[dict, dict], Desc]] = {
    "webhook": _webhook,
    "scheduletrigger": _schedule,
    "cron": _cron,
    "interval": _interval,
    "manualtrigger": _manual,
    "start": _manual,
    "formtrigger": _form,
    "lc.chattrigger": _chat_trigger,
    "executeworkflowtrigger": _sub_trigger,
    "httprequest": _http,
    "lc.toolhttprequest": _http,
    "set": _set,
    "if": _if,
    "filter": _filter,
    "switch": _switch,
    "merge": _merge,
    "code": _code,
    "function": _code,
    "functionitem": _code,
    "splitinbatches": _split_batches,
    "splitout": _split_out,
    "aggregate": _aggregate,
    "wait": _wait,
    "respondtowebhook": _respond,
    "noop": _noop,
    "gmail": _gmail,
    "emailsend": _email_send,
    "googlesheets": _sheets,
    "slack": _slack,
    "telegram": _telegram,
    "airtable": _airtable,
    "notion": _notion,
    "hubspot": _crm("HubSpot", "deal"),
    "stripe": _crm("Stripe", "customer"),
    "openai": _openai,
    "lc.openai": _openai,
    "lc.agent": _agent,
    "lc.chainllm": _chain,
    "lc.lmchatopenai": _chat_model("OpenAI"),
    "lc.lmopenai": _chat_model("OpenAI"),
    "lc.lmchatanthropic": _chat_model("Anthropic Claude"),
    "lc.lmchatgooglegemini": _chat_model("Google Gemini"),
    "lc.lmchatollama": _chat_model("Ollama"),
    "lc.memorybufferwindow": _memory,
    "lc.outputparserstructured": _parser,
    "executeworkflow": _exec_workflow,
    "discord": _discord,
    "googledrive": _drive,
}


def _generic(p: dict, node: dict) -> Desc:
    node_type = node.get("type") or "unknown"
    service = _service_from_type(node_type)
    action = " ".join(humanize(str(p[k])) for k in ("operation", "resource") if isinstance(p.get(k), str))
    summary = f"Use {service}" + (f": {action}" if action else "") + "."
    details = [f"Node type `{node_type}` has no built-in description; check the original workflow for details."]
    shown = 0
    for k, v in p.items():
        if k in ("operation", "resource") or isinstance(v, (dict, list)) or v in ("", None):
            continue
        details.append(f"`{k}`: {one_line(pretty_expr(v), 120)}")
        shown += 1
        if shown >= 6:
            break
    return {"summary": summary, "service": service, "details": details}


def describe_node(raw: dict) -> Desc:
    """Plain-English description of one n8n node (parameters are redacted first)."""
    node_type = str(raw.get("type") or "unknown")
    params = raw.get("parameters") if isinstance(raw.get("parameters"), dict) else {}
    params = redact(params)
    key = node_key(node_type)
    fn = REGISTRY.get(key)
    if fn is None:
        if is_trigger_type(node_type):
            fn = _generic_trigger
        elif key.startswith("lc.tool") or key.endswith("tool"):
            fn = lambda p, n: {"summary": f"Tool: {_service_from_type(node_type)}",  # noqa: E731
                               "service": _service_from_type(node_type)}
        else:
            fn = _generic
    try:
        desc = fn(params, raw)
    except Exception:  # odd parameter shapes must never crash a conversion
        desc = _generic(params, raw)
    return desc


# ---------------------------------------------------------------- parser


def parse_n8n(data: Any, fallback_name: str = "n8n workflow") -> Workflow:
    if not isinstance(data, dict):
        raise SkillportError("An n8n workflow must be a JSON object with a \"nodes\" list.")
    raw_nodes = data.get("nodes")
    if raw_nodes is None:
        raw_nodes = []
    if not isinstance(raw_nodes, list):
        raise SkillportError("The \"nodes\" field of this n8n workflow is not a list.")
    name = str(data.get("name") or "").strip() or fallback_name
    wf = Workflow(name=name, source_format="n8n", raw=data)

    for i, raw in enumerate(raw_nodes):
        if not isinstance(raw, dict):
            wf.warnings.append(f"Node #{i + 1} is not an object and was skipped.")
            continue
        node_type = str(raw.get("type") or "unknown")
        params = raw.get("parameters") if isinstance(raw.get("parameters"), dict) else {}
        if node_key(node_type) == STICKY:
            content = str(params.get("content") or "").strip()
            if content:
                wf.notes.append(redact_text(content))
            continue
        nname = str(raw.get("name") or "").strip() or f"{_service_from_type(node_type)} {i + 1}"
        if nname in wf.nodes:
            new = f"{nname} ({i + 1})"
            wf.warnings.append(f"Two nodes are called \"{nname}\"; the second one is shown as \"{new}\".")
            nname = new
        desc = describe_node(raw)
        creds = []
        rc = raw.get("credentials")
        if isinstance(rc, dict):
            for ctype, info in rc.items():
                account = info.get("name", "") if isinstance(info, dict) else str(info or "")
                creds.append((str(ctype), str(account)))
        details = list(desc.get("details") or [])
        if raw.get("notes"):
            details.append(f"Note from the author: {one_line(redact_text(str(raw['notes'])), 300)}")
        wf.nodes[nname] = Node(
            id=nname,
            name=nname,
            type=node_type,
            summary=desc.get("summary", ""),
            service=desc.get("service", ""),
            details=details,
            is_trigger=is_trigger_type(node_type),
            disabled=bool(raw.get("disabled")),
            credentials=creds,
            outputs=list(desc.get("outputs") or []),
            branch_style=desc.get("branch_style", ""),
            trigger_info=dict(desc.get("trigger_info") or {}),
            code=desc.get("code"),
        )

    conns = data.get("connections") or {}
    if not isinstance(conns, dict):
        wf.warnings.append("The \"connections\" field is not an object; steps are shown without links.")
        conns = {}
    for src, by_kind in conns.items():
        if src not in wf.nodes:
            if isinstance(by_kind, dict) and any(by_kind.values()):
                wf.warnings.append(f"A connection starts at an unknown node \"{src}\" and was ignored.")
            continue
        if not isinstance(by_kind, dict):
            continue
        for kind, outputs in by_kind.items():
            if not isinstance(outputs, list):
                continue
            for idx, targets in enumerate(outputs):
                for c in targets or []:
                    if not isinstance(c, dict):
                        continue
                    target = c.get("node")
                    if target not in wf.nodes:
                        wf.warnings.append(f"\"{src}\" connects to an unknown node \"{target}\"; ignored.")
                        continue
                    wf.edges.append(Edge(src, str(target), idx, str(kind)))

    # AI sub-nodes: only non-"main" outgoing links (chat model -> agent, etc.)
    for nid, node in wf.nodes.items():
        out = [e for e in wf.edges if e.source == nid]
        if out and all(e.kind != "main" for e in out) and not node.is_trigger:
            node.is_subnode = True
            for e in out:
                parent = wf.nodes[e.target]
                label = node.summary.rstrip(".")
                if node.disabled:
                    continue
                text = f"{humanize(e.kind.replace('ai_', ''))}: {label}"
                if text not in parent.attachments:
                    parent.attachments.append(text)

    graph.analyze(wf)
    wf.inputs = _collect_inputs(wf)
    return wf


def _clean_field(path: str) -> str | None:
    for prefix in ("body.", "query."):
        if path.startswith(prefix):
            return path[len(prefix):]
    if path.startswith("headers") or path in ("body", "query", "params"):
        return None
    return path


def _collect_inputs(wf: Workflow) -> list[str]:
    fields: list[str] = []

    def add(f: str | None) -> None:
        if f and f not in fields:
            fields.append(f)

    raw_by_name = {}
    for raw in (wf.raw or {}).get("nodes") or []:
        if isinstance(raw, dict):
            raw_by_name[str(raw.get("name") or "")] = raw
    for trig in wf.triggers:
        kind = trig.trigger_info.get("kind")
        if kind == "form":
            for f in trig.trigger_info.get("fields", []):
                add(f)
            continue
        if kind == "chat":
            add("chatInput (the user's chat message)")
            continue
        if kind not in ("webhook", "subworkflow", "event"):
            continue
        direct = {e.target for e in wf.successors(trig.id)}
        for nid in wf.steps:
            raw = raw_by_name.get(nid, {})
            for s in iter_strings(raw.get("parameters") or {}):
                for node_name, path in node_refs(s):
                    if node_name == trig.name:
                        add(_clean_field(path))
                if nid in direct and kind == "webhook":
                    for path in json_refs(s):
                        if path.startswith(("body.", "query.")):
                            add(_clean_field(path))
                elif nid in direct:
                    for path in json_refs(s):
                        add(_clean_field(path))
    return [truncate(f, 80) for f in fields]
