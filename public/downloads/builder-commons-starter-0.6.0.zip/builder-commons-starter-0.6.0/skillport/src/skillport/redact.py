"""Keep secrets out of everything we write.

Two layers:
1. Values stored under secret-sounding keys (apiKey, token, password,
   Authorization header, ...) are replaced.
2. Any string that *looks* like a secret (sk-..., AKIA..., ghp_..., xoxb-...,
   Bearer tokens, private keys, JWTs, ?api_key=... in URLs) is replaced, wherever it is.
"""

from __future__ import annotations

import re
from typing import Any

REDACTED = "[REDACTED]"

# Normalised key names (lowercase, no -, _ or spaces) that hold secrets.
_SECRET_KEY_PARTS = (
    "apikey",
    "secret",
    "password",
    "passwd",
    "authorization",
    "accesskey",
    "privatekey",
    "bearer",
    "cookie",
    "sessionid",
    "signingkey",
    "webhooksecret",
)
_SECRET_KEY_EXACT = {"token", "auth", "key", "pass", "pwd", "credential", "credentials", "xapikey", "jwt"}

_VALUE_PATTERNS = [
    re.compile(r"-----BEGIN [A-Z ]*PRIVATE KEY-----.*?(?:-----END [A-Z ]*PRIVATE KEY-----|$)", re.S),
    re.compile(r"\bsk-ant-[A-Za-z0-9_\-]{8,}"),
    re.compile(r"\bsk-(?:proj-|live-|test-)?[A-Za-z0-9_\-]{16,}"),
    re.compile(r"\b(?:sk|rk|pk)_(?:live|test)_[A-Za-z0-9]{10,}"),
    re.compile(r"\b(?:AKIA|ASIA)[0-9A-Z]{16}\b"),
    re.compile(r"\bgh[pousr]_[A-Za-z0-9]{20,}"),
    re.compile(r"\bgithub_pat_[A-Za-z0-9_]{20,}"),
    re.compile(r"\bxox[abprs]-[A-Za-z0-9\-]{8,}"),
    re.compile(r"\bAIza[0-9A-Za-z_\-]{30,}"),
    re.compile(r"\beyJ[A-Za-z0-9_\-]{8,}\.[A-Za-z0-9_\-]{8,}\.[A-Za-z0-9_\-]{8,}"),
    re.compile(r"https://hooks\.slack\.com/services/[A-Za-z0-9/_\-]+"),
    re.compile(r"\b\d{8,10}:AA[A-Za-z0-9_\-]{30,}"),  # Telegram bot token
]
_AUTH_SCHEME = re.compile(r"(?i)\b(Bearer|Basic|Token)\s+[A-Za-z0-9._~+/=\-]{12,}")
_URL_SECRET_PARAM = re.compile(
    r"(?i)([?&](?:api[_-]?key|apikey|key|token|access[_-]?token|secret|password|auth|sig|signature)=)[^&#\s\"']+"
)
_URL_USERINFO = re.compile(r"(?i)(\b[a-z][a-z0-9+.\-]*://)[^/\s:@\"']+:[^/\s@\"']+@")


def is_secret_key(key: str) -> bool:
    k = re.sub(r"[\s_\-]", "", str(key)).lower()
    if not k:
        return False
    if k in _SECRET_KEY_EXACT:
        return True
    if k.endswith("token") and not k.startswith("max"):
        return True
    return any(part in k for part in _SECRET_KEY_PARTS)


def redact_text(text: str) -> str:
    """Replace secret-looking substrings in free text."""
    if not text:
        return text
    out = text
    for pat in _VALUE_PATTERNS:
        out = pat.sub(REDACTED, out)
    out = _AUTH_SCHEME.sub(lambda m: f"{m.group(1)} {REDACTED}", out)
    out = _URL_SECRET_PARAM.sub(lambda m: m.group(1) + REDACTED, out)
    out = _URL_USERINFO.sub(lambda m: m.group(1) + REDACTED + "@", out)
    return out


def contains_secret(text: str) -> bool:
    return redact_text(text) != text


def _secret_value(value: Any) -> bool:
    return isinstance(value, str) and value.strip() != "" or isinstance(value, (int, float)) and not isinstance(value, bool) and len(str(value)) >= 6


def redact(obj: Any) -> Any:
    """Return a deep copy of a JSON value with secrets replaced."""
    if isinstance(obj, str):
        return redact_text(obj)
    if isinstance(obj, list):
        return [redact(v) for v in obj]
    if isinstance(obj, dict):
        # {"name": "Authorization", "value": "Bearer ..."} pairs (n8n headers, Make headers/qs)
        pair_name = None
        for name_key in ("name", "key", "parameterName"):
            if isinstance(obj.get(name_key), str):
                pair_name = obj[name_key]
                break
        secret_pair = pair_name is not None and is_secret_key(pair_name)
        out = {}
        for k, v in obj.items():
            if secret_pair and k in ("value", "stringValue", "parameterValue") and _secret_value(v):
                out[k] = REDACTED
            elif is_secret_key(k) and _secret_value(v):
                out[k] = REDACTED
            else:
                out[k] = redact(v)
        return out
    return obj
