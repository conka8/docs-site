"""Write the SKILL.md, README.md and `inspect` text for a Workflow."""

from __future__ import annotations

import re

from .credentials import collect_credentials
from .model import Credential, Workflow
from .review import render_review, review_items
from .text import MAX_DESCRIPTION, md_escape_inline, one_line, slugify, truncate, yaml_quote

DEFAULT_BRAND = "skillport"

FORMAT_LABEL = {"n8n": "n8n", "make": "Make.com"}


# ---------------------------------------------------------------- shared pieces


def _clean(text: str) -> str:
    """Text for the frontmatter description: one line, no XML-looking tags."""
    return re.sub(r"\s+", " ", (text or "").replace("<", "").replace(">", "")).strip()


def trigger_phrase(wf: Workflow) -> str:
    trig = wf.triggers[0] if wf.triggers else None
    if trig is None:
        return "runs on request"
    info = trig.trigger_info
    kind = info.get("kind")
    if kind == "webhook":
        return "takes incoming data (originally sent to a webhook)"
    if kind == "schedule":
        return f"originally ran automatically {info.get('when', 'on a schedule')}"
    if kind == "form":
        return "takes the answers of a form"
    if kind == "chat":
        return "answers a chat message"
    if kind == "event":
        return f"reacts to new {info.get('service') or 'app'} events"
    if kind == "subworkflow":
        return "is called with data by another workflow"
    return "runs on request"


def build_description(wf: Workflow, mode: str = "skill") -> str:
    name = _clean(wf.name)
    fmt = FORMAT_LABEL.get(wf.source_format, wf.source_format)
    services = [s for s in wf.services() if s not in ("Webhook", "Schedule")]
    uses = f"; uses {', '.join(services)}" if services else ""

    trigger = f": it {trigger_phrase(wf)}"

    def compose(title: str, how: str, extra: str) -> str:
        if mode == "bridge":
            return _clean(f'Runs the existing {fmt} workflow "{title}" by calling its webhook and reports the reply'
                          f'{extra}. Use when the user asks to run "{title}" or wants it triggered from Claude.')
        return _clean(f'Does the work of the "{title}" automation (converted from {fmt}){how}{extra}. '
                      f'Use when the user asks to run "{title}" or needs this task done without {fmt}.')

    # The body lists services and the trigger; drop them here first, then shorten the name (it appears twice),
    # so "Use when" always survives.
    for how, extra in ((trigger, uses), (trigger, ""), ("", "")):
        text = compose(name, how, extra)
        if len(text) <= MAX_DESCRIPTION:
            return text
    room = len(name) - (len(text) - MAX_DESCRIPTION + 1) // 2
    return truncate(compose(truncate(name, max(room, 12)), "", ""), MAX_DESCRIPTION)


def frontmatter(name: str, description: str) -> str:
    return f"---\nname: {name}\ndescription: {yaml_quote(description)}\n---\n"


def _step_ref(wf: Workflow, node_id: str) -> str:
    return f"step {wf.step_number(node_id)} ({wf.nodes[node_id].name})"


def _refs(wf: Workflow, ids: list[str]) -> str:
    if not ids:
        return ""
    if len(ids) == 1:
        return _step_ref(wf, ids[0])
    nums = [str(wf.step_number(i)) for i in ids]
    names = ", ".join(wf.nodes[i].name for i in ids)
    return f"steps {', '.join(nums[:-1])} and {nums[-1]} ({names})"


def step_links(wf: Workflow, node_id: str, arrow: str = "→") -> list[str]:
    """'If x → go to step 5 (...)' style lines for one step."""
    node = wf.nodes[node_id]
    me = wf.step_number(node_id)
    out_edges = wf.successors(node_id)
    lines: list[str] = []
    forward = [e for e in out_edges if wf.step_number(e.target) > me]
    back = [e for e in out_edges if wf.step_number(e.target) <= me]
    max_out = max([e.output for e in out_edges] + [-1])
    if node.outputs or max_out > 0:
        labels = list(node.outputs)
        while len(labels) <= max_out:
            labels.append(f"Output {len(labels) + 1}")
        for i, label in enumerate(labels):
            targets = [e.target for e in forward if e.output == i]
            loops = [e.target for e in back if e.output == i]
            if targets:
                lines.append(f"{label} {arrow} go to {_refs(wf, targets)}")
            elif loops:
                lines.append(f"{label} {arrow} go back to {_refs(wf, loops)} (this repeats)")
            else:
                lines.append(f"{label} {arrow} stop here (nothing else happens on this path)")
        return lines
    targets = [e.target for e in forward]
    if targets and not (len(targets) == 1 and wf.step_number(targets[0]) == me + 1):
        lines.append(f"Next {arrow} {_refs(wf, targets)}")
    for e in back:
        lines.append(f"Then go back to {_step_ref(wf, e.target)} (this repeats)")
    return lines


def _preds_line(wf: Workflow, node_id: str) -> str | None:
    me = wf.step_number(node_id)
    preds = []
    for e in wf.predecessors(node_id):
        if wf.step_number(e.source) < me and e.source not in preds:
            preds.append(e.source)
    if len(preds) > 1:
        return f"Waits for {_refs(wf, preds)} to finish."
    return None


def render_steps(wf: Workflow, with_details: bool = True, arrow: str = "→") -> list[str]:
    lines: list[str] = []
    for nid in wf.steps:
        node = wf.nodes[nid]
        num = wf.step_number(nid)
        lines.append(f"{num}. **{md_escape_inline(node.name)}**: {node.summary}")
        if with_details:
            lines += [f"   - {d}" for d in node.details]
            lines += [f"   - Uses {a}" for a in node.attachments]
            if node.code:
                lang, code = node.code
                lines.append("   - The original code is below. Do the same thing yourself, or with a short script:")
                lines.append("")
                lines.append(f"     ```{lang}")
                lines += [("     " + c) if c else "" for c in code.splitlines()]
                lines.append("     ```")
                lines.append("")
        flow = []
        merge = _preds_line(wf, nid)
        if merge:
            flow.append(merge)
        flow += step_links(wf, nid, arrow)
        lines += [f"   - {s}" for s in flow]
    return lines


def render_credentials(creds: list[Credential]) -> list[str]:
    if not creds:
        return ["None. This workflow does not log in to any outside service."]
    out = []
    for c in creds:
        acct = f' (account in the original: "{", ".join(c.accounts)}")' if c.accounts else ""
        line = f"- **{c.service}**{acct}: set `{c.env_var}`. Used by: {', '.join(c.used_by)}."
        if "oauth" in c.key.lower() or c.env_var.endswith("OAUTH_TOKEN"):
            line += f" This is an OAuth login, so a connected app or MCP server for {c.service} is the easiest way in."
        out.append(line)
    return out


def render_inputs(wf: Workflow) -> list[str]:
    trig = wf.triggers[0] if wf.triggers else None
    kind = trig.trigger_info.get("kind") if trig else None
    fields = [f"- `{f}`" for f in wf.inputs]
    if kind == "webhook":
        head = "The original workflow received data through a webhook."
        if fields:
            return [head + " Ask the user for these details (or take them from the conversation):", ""] + fields
        return [head + " Ask the user for the details the steps below need."]
    if kind == "form":
        return ["The original workflow started from a form. Ask the user for:", ""] + (fields or ["- the form answers"])
    if kind == "chat":
        return ["The user's chat message (what they want done)."]
    if kind == "schedule":
        return [f"No input needed. The original workflow ran automatically {trig.trigger_info.get('when')}; "
                "as a skill it runs whenever the user asks."]
    if kind == "event":
        svc = trig.trigger_info.get("service") or "the app"
        extra = ["", "Fields the workflow used:", ""] + fields if fields else []
        return [f"The original workflow started when something new happened in {svc}. "
                "Ask the user which item to work on, or fetch the newest one."] + extra
    if kind == "subworkflow":
        return ["Data passed in by the caller."] + ([""] + fields if fields else [])
    return ["No input needed. Ask the user if a step needs details that are missing."]


def _quote_block(text: str) -> list[str]:
    return [("> " + line).rstrip() for line in text.strip().splitlines()]


def render_notes(wf: Workflow) -> list[str]:
    lines: list[str] = []
    for note in wf.notes:
        lines += _quote_block(note) + [""]
    for w in wf.warnings:
        lines.append(f"- {w}")
    if not lines:
        lines = ["No notes in the original workflow."]
    while lines and lines[-1] == "":
        lines.pop()
    return lines


# ---------------------------------------------------------------- SKILL.md / README.md


def render_skill_md(wf: Workflow, name: str | None = None) -> str:
    name = name or slugify(wf.name)
    fmt = FORMAT_LABEL.get(wf.source_format, wf.source_format)
    creds = collect_credentials(wf)
    services = [s for s in wf.services() if s not in ("Webhook", "Schedule")]
    out = [frontmatter(name, build_description(wf)).rstrip("\n"), "", f"# {wf.name}", "", "## Overview", ""]
    out.append(
        f'This skill was converted from the {fmt} workflow "{wf.name}". It {trigger_phrase(wf)}, '
        f"then works through {len(wf.steps)} steps" + (f" using {', '.join(services)}." if services else ".")
    )
    out += [
        "",
        "How to run it:",
        "",
        "1. Collect the inputs listed below. Ask the user for anything missing before you start.",
        "2. Do the steps in order, with the tools you have (web requests, connected apps or MCP servers, "
        "or a short script). Follow the branches exactly as written.",
        "3. Read account keys only from the environment variables or connected accounts listed below. "
        "Never print them or write them into files.",
        "4. If a step can't be done with the tools you have, stop and tell the user which step and why.",
        "5. Finish with a short summary of what you did and the results.",
        "",
        "## Conversion check",
        "",
    ]
    out += render_review(review_items(wf), "skill")
    out += ["", "## Required credentials / accounts", ""]
    out += render_credentials(creds)
    out += ["", "## Inputs", ""] + render_inputs(wf)
    out += ["", "## Steps", ""] + render_steps(wf)
    out += ["", "## Notes", ""] + render_notes(wf)
    return "\n".join(out).rstrip() + "\n"


def install_lines(name: str) -> list[str]:
    return [
        "1. Copy this whole folder into your skills folder:",
        f"   - **Claude Code**: `~/.claude/skills/{name}/` (all projects; on Windows "
        f"`%USERPROFILE%\\.claude\\skills\\{name}\\`) or `.claude/skills/{name}/` inside one project.",
        "   - **Claude app (claude.ai / desktop)**: zip this folder (the folder itself at the top of the zip), "
        "turn on code execution, then Customize > Skills > + > Create skill > Upload a skill.",
        "   - **OpenClaw**: put it in `~/.openclaw/skills/` or your workspace's `skills/` folder.",
    ]


def _env_block(creds: list[Credential]) -> list[str]:
    if not creds:
        return ["   No accounts needed."]
    lines = ["   ```bash"]
    lines += [f'   export {c.env_var}="paste-your-key-here"' for c in creds]
    lines.append("   ```")
    return lines


def footer(brand: str = DEFAULT_BRAND, brand_url: str | None = None) -> list[str]:
    label = f"[{brand}]({brand_url})" if brand_url else brand
    return ["---", "", f"Converted with {label}."]


def render_readme(wf: Workflow, name: str, brand: str = DEFAULT_BRAND, brand_url: str | None = None) -> str:
    fmt = FORMAT_LABEL.get(wf.source_format, wf.source_format)
    creds = collect_credentials(wf)
    out = [
        f"# {wf.name}",
        "",
        f'A ready-to-use Claude skill made from the {fmt} workflow "{wf.name}". '
        f"Claude (or OpenClaw) reads `SKILL.md` and does the same job, without {fmt}.",
        "",
        "## What it does",
        "",
    ]
    out += [f"{wf.step_number(n)}. {wf.nodes[n].summary}" for n in wf.steps]
    out += ["", "## What you need", ""]
    if creds:
        out += [f"- **{c.service}** account (key goes in `{c.env_var}`)" for c in creds]
    else:
        out.append("- No outside accounts.")
    out += ["", "## Set it up", ""] + install_lines(name)
    out += ["2. Give Claude your account keys. The easiest way is to set them before you start Claude:", ""]
    out += _env_block(creds)
    out += [
        "",
        f'3. Ask Claude: *"Use the {name} skill"* and tell it what you want done.',
        "",
        "## Good to know",
        "",
        "- This is a starting point. Try it on test data and read `SKILL.md` before using it with real customers.",
        "- Claude follows written steps; it does not run the original automation, so results can differ. "
        "See **Conversion check** in `SKILL.md` for what to look at.",
        "- `source/workflow.json` is the original workflow with account IDs and secrets removed.",
    ]
    out += [f"- {w}" for w in wf.warnings]
    out += [""] + footer(brand, brand_url)
    return "\n".join(out).rstrip() + "\n"


# ---------------------------------------------------------------- inspect


def render_inspect(wf: Workflow) -> str:
    fmt = FORMAT_LABEL.get(wf.source_format, wf.source_format)
    out = [f"Workflow: {wf.name}  ({fmt})", f"Skill name: {slugify(wf.name)}", ""]
    if wf.steps:
        out.append(f"Steps ({len(wf.steps)}):")
        for nid in wf.steps:
            node = wf.nodes[nid]
            tag = " [trigger]" if node.is_trigger else ""
            out.append(f"  {wf.step_number(nid)}. {node.name}{tag}: {one_line(node.summary, 160)}")
            for a in node.attachments:
                out.append(f"       uses {a}")
            for link in step_links(wf, nid, arrow="->"):
                out.append(f"       {link}")
    else:
        out.append("Steps: none (the workflow is empty or only has notes)")
    out += ["", "Credentials / accounts:"]
    creds = collect_credentials(wf)
    if creds:
        for c in creds:
            out.append(f"  - {c.service}: {c.env_var}  (used by: {', '.join(c.used_by)})")
    else:
        out.append("  none")
    out += ["", "Inputs: " + (", ".join(wf.inputs) if wf.inputs else "none found")]
    if wf.notes:
        out.append(f"Notes: {len(wf.notes)} sticky note(s)")
    if wf.warnings:
        out += ["", "Warnings:"] + [f"  - {w}" for w in wf.warnings]
    review = review_items(wf)
    out += ["", f"Check before sharing ({len(review)}):" if review else "Check before sharing: nothing flagged"]
    out += [f"  - {r}" for r in review]
    return "\n".join(out) + "\n"
