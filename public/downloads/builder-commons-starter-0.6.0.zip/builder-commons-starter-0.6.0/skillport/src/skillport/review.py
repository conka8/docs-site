"""What a converted skill does not carry over from the original workflow.

A skill is written instructions that Claude follows with its own tools. It is not a copy of the
n8n or Make.com engine, so some behaviour can differ. These checks list each place where that can
happen, so a person reviews it before the skill is shared. The list goes into SKILL.md, README.md,
`inspect` and the convert/batch output.
"""

from __future__ import annotations

import re
from typing import Any

from .model import Workflow
from .text import iter_strings, one_line

# SKILL.md carries this marker until someone has checked the list. `skillkit lint` warns while it is there.
REVIEW_MARKER = "<!-- skillport: needs-review -->"

_EXPR = re.compile(r"\{\{(.*?)\}\}", re.DOTALL)
# Logic inside an expression that the plain-English steps can't show exactly.
_LOGIC = re.compile(
    r"=>|\?[^?.]*:|\|\||&&|"
    r"\.(?:map|filter|reduce|find|some|every|split|join|replace|slice|substring|toFixed|toLowerCase|"
    r"toUpperCase|format|plus|minus|toISO\w*|toFormat|parse\w*)\(|"
    r"\$now|\$today|DateTime|Math\.|JSON\.|\$(?:if|ifEmpty|max|min|jmespath)\("
)
_AI_TYPES = ("openai", "anthropic", "gemini", "mistral", "langchain.agent", "langchain.chain", "langchain.openai")
_RETRY_DEFAULT = 3


def _n8n_raw_nodes(wf: Workflow) -> dict[str, dict]:
    nodes = (wf.raw or {}).get("nodes") if isinstance(wf.raw, dict) else None
    return {str(n.get("name") or ""): n for n in nodes or [] if isinstance(n, dict)}


def _make_raw_modules(wf: Workflow) -> dict[str, dict]:
    found: dict[str, dict] = {}

    def walk(flow: Any) -> None:
        for mod in flow if isinstance(flow, list) else []:
            if not isinstance(mod, dict):
                continue
            found.setdefault(str(mod.get("id")), mod)
            for route in mod.get("routes") or []:
                if isinstance(route, dict):
                    walk(route.get("flow"))

    if isinstance(wf.raw, dict):
        walk(wf.raw.get("flow"))
    return found


def _logic_expressions(params: Any) -> list[str]:
    out = []
    for s in iter_strings(params):
        for m in _EXPR.finditer(s):
            inner = m.group(1).strip()
            if _LOGIC.search(inner) and inner not in out:
                out.append(inner)
    return out


def _step(wf: Workflow, nid: str) -> str:
    return f'Step {wf.step_number(nid)} ("{wf.nodes[nid].name}")'


def _skill_items(wf: Workflow) -> list[str]:
    items: list[str] = []
    raw_n8n = _n8n_raw_nodes(wf) if wf.source_format == "n8n" else {}
    raw_make = _make_raw_modules(wf) if wf.source_format == "make" else {}
    fmt = "n8n" if wf.source_format == "n8n" else "Make.com"

    for trig in wf.triggers:
        if trig.trigger_info.get("kind") == "schedule":
            items.append(f"The original ran on a schedule ({trig.trigger_info.get('when') or 'timed'}). "
                         "A skill only runs when someone asks Claude. Nothing runs automatically.")

    for nid in wf.steps:
        node = wf.nodes[nid]
        key = node.type.lower()
        if node.code is not None or node.summary.startswith("Run custom"):
            items.append(f"{_step(wf, nid)} runs custom code. Claude rewrites it from the original code, so "
                         f"compare its result with {fmt}'s on the same input.")
        if any("has no built-in description" in d for d in node.details):
            items.append(f"{_step(wf, nid)} uses `{node.type}`, which skillport can't describe. Check what it does "
                         "in the original and rewrite the step in plain words.")
        if key.endswith("executeworkflow"):
            items.append(f"{_step(wf, nid)} calls another n8n workflow, which is not included. Convert that "
                         "workflow too, or describe what it returns in this step.")
        if any(t in key for t in _AI_TYPES) and not node.is_subnode:
            items.append(f"{_step(wf, nid)} asks an AI model. Claude does this step itself unless told to call "
                         "that provider, so wording, scores and formats can differ from the original.")

        raw = raw_n8n.get(nid)
        if raw is not None:
            on_error = str(raw.get("onError") or "")
            if raw.get("continueOnFail") or on_error.startswith("continue"):
                items.append(f"{_step(wf, nid)} keeps going in n8n when it fails. The skill tells Claude to stop "
                             "and report errors instead.")
            if raw.get("retryOnFail"):
                tries = raw.get("maxTries") or _RETRY_DEFAULT
                items.append(f"{_step(wf, nid)} retries up to {tries} times in n8n. The skill does not retry.")
            exprs = _logic_expressions(raw.get("parameters") or {})
            if exprs:
                more = f" (and {len(exprs) - 1} more)" if len(exprs) > 1 else ""
                items.append(f"{_step(wf, nid)} computes values with expressions such as "
                             f"`{one_line(exprs[0], 80)}`{more}. The steps show them simplified, so check the "
                             "original.")
        mod = raw_make.get(nid)
        if mod is not None and mod.get("onerror"):
            items.append(f"{_step(wf, nid)} has a Make.com error handler, which is not converted.")

    if wf.cycles:
        for cycle in wf.cycles:
            names = " → ".join(wf.nodes[n].name for n in cycle if n in wf.nodes)
            items.append(f"Some steps repeat in a loop ({names}). Check that Claude stops where the original stopped.")
    settings = wf.raw.get("settings") if isinstance(wf.raw, dict) else None
    if isinstance(settings, dict) and settings.get("errorWorkflow"):
        items.append("The original sends failures to a separate error workflow. The skill reports errors to "
                     "the user instead.")
    return items


def _bridge_items(wf: Workflow, url: str | None) -> list[str]:
    items: list[str] = []
    hook = wf.webhook
    if hook is None:
        items.append("The workflow does not start with a Webhook trigger, so the bridge has nothing to call "
                     "until you add one.")
        return items
    info = hook.trigger_info
    if wf.source_format == "n8n":
        raw = _n8n_raw_nodes(wf).get(hook.id) or {}
        mode = str((raw.get("parameters") or {}).get("responseMode") or "onReceived")
        if mode == "onReceived":
            items.append("The webhook answers as soon as it receives data, before the workflow finishes, so "
                         "Claude only sees a \"started\" reply. To show the result, set the Webhook node's "
                         "Respond option to \"When Last Node Finishes\" or use a \"Respond to Webhook\" node.")
    auth = str(info.get("auth") or "none")
    if auth == "basicAuth":
        items.append("The webhook uses Basic auth. Set N8N_WEBHOOK_HEADER to "
                     "\"Authorization: Basic <base64 of user:password>\".")
    elif auth == "jwtAuth":
        items.append("The webhook uses JWT auth. Set N8N_WEBHOOK_HEADER to \"Authorization: Bearer <token>\".")
    elif auth not in ("none", ""):
        items.append("The webhook needs authentication. Set N8N_WEBHOOK_HEADER to \"Header-Name: value\".")
    if url and "/webhook-test/" in url:
        items.append("The URL is an n8n test URL. It only answers while the workflow editor is listening. "
                     "Use the production URL (/webhook/...) for members.")
    items.append("The skill's script needs network access to your webhook. Check that it can reach your "
                 f"{'n8n' if wf.source_format == 'n8n' else 'Make.com'} host from where members run Claude.")
    return items


def review_items(wf: Workflow, mode: str = "skill", url: str | None = None) -> list[str]:
    """Plain-English list of what to check before the converted skill is shared."""
    return _bridge_items(wf, url) if mode == "bridge" else _skill_items(wf)


def render_review(items: list[str], mode: str = "skill") -> list[str]:
    """The "Conversion check" section of SKILL.md."""
    if mode == "bridge":
        lead = ("This skill does not do the work itself: the original workflow runs where it always did. "
                "Check these before you share it:")
    else:
        lead = ("This skill is a written description of the original workflow. Claude follows it with its own "
                "tools; it does not run the original automation engine, so results can differ. "
                "Check these before you share it:")
    lines = [lead, ""]
    lines += [f"- {i}" for i in items] if items else [
        "- Nothing was flagged. Still run it once on test data and compare the result with the original."]
    lines += ["", "When you have checked the list, delete the next line so `skillkit lint` stops flagging this skill.",
              "", REVIEW_MARKER]
    return lines
