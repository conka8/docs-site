"""Build the skill folder files, write them to disk and optionally zip them."""

from __future__ import annotations

import copy
import json
import zipfile
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from .bridge import SCRIPT_PATH, render_bridge_readme, render_bridge_skill_md, safe_webhook_url, script_source
from .model import SkillportError, Workflow
from .redact import redact
from .render import DEFAULT_BRAND, render_readme, render_skill_md
from .text import slugify

MODES = ("skill", "bridge")
# Fields that can hold account data, test data or instance ids in an n8n export.
N8N_DROP = ("pinData", "staticData", "shared", "homeProject", "sharedWithProjects")


@dataclass
class ConvertResult:
    workflow: Workflow
    name: str
    folder: Path
    zip_path: Path | None = None
    files: list[str] = field(default_factory=list)
    mode: str = "skill"
    webhook_url: str | None = None


def sanitize_source(raw: Any, source_format: str) -> Any:
    """Copy of the original JSON with credential ids, pinned data and secrets removed."""
    data = copy.deepcopy(raw)
    if source_format == "n8n" and isinstance(data, dict):
        for key in N8N_DROP:
            data.pop(key, None)
        if isinstance(data.get("meta"), dict):
            data["meta"].pop("instanceId", None)
        for node in data.get("nodes") or []:
            if isinstance(node, dict) and isinstance(node.get("credentials"), dict):
                node["credentials"] = {
                    ctype: ({"name": info.get("name", "")} if isinstance(info, dict) else {"name": str(info)})
                    for ctype, info in node["credentials"].items()
                }
    if source_format == "make":
        def strip(obj: Any) -> None:
            if isinstance(obj, dict):
                for k in list(obj):
                    if k.startswith("__IMT") or (k == "hook" and isinstance(obj[k], (int, str))):
                        obj[k] = None
                    else:
                        strip(obj[k])
            elif isinstance(obj, list):
                for v in obj:
                    strip(v)
        strip(data)
    return redact(data)


def build_files(
    wf: Workflow,
    mode: str = "skill",
    webhook_url: str | None = None,
    name: str | None = None,
    brand: str = DEFAULT_BRAND,
    brand_url: str | None = None,
) -> dict[str, tuple[str, bool]]:
    """Map of relative path -> (text content, executable?)."""
    if mode not in MODES:
        raise SkillportError(f"Unknown mode {mode!r}. Use one of: {', '.join(MODES)}.")
    if not wf.steps:
        raise SkillportError(
            f'"{wf.name}" has no steps to convert (the workflow is empty, only has notes, or every node is disabled).'
        )
    name = name or slugify(wf.name)
    files: dict[str, tuple[str, bool]] = {}
    if mode == "bridge":
        url = safe_webhook_url(webhook_url, wf)
        files["SKILL.md"] = (render_bridge_skill_md(wf, url, name), False)
        files["README.md"] = (render_bridge_readme(wf, name, url, brand, brand_url), False)
        files[SCRIPT_PATH] = (script_source(), True)
    else:
        files["SKILL.md"] = (render_skill_md(wf, name), False)
        files["README.md"] = (render_readme(wf, name, brand, brand_url), False)
    source = sanitize_source(wf.raw, wf.source_format)
    files["source/workflow.json"] = (json.dumps(source, indent=2, ensure_ascii=False) + "\n", False)
    return files


def write_folder(files: dict[str, tuple[str, bool]], folder: Path) -> None:
    folder.mkdir(parents=True, exist_ok=True)
    for rel, (content, executable) in files.items():
        target = folder / rel
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(content, encoding="utf-8", newline="\n")
        if executable:
            target.chmod(0o755)


def write_zip(files: dict[str, tuple[str, bool]], zip_path: Path, top: str) -> None:
    zip_path.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        for rel, (content, executable) in sorted(files.items()):
            info = zipfile.ZipInfo(f"{top}/{rel}", date_time=(2026, 1, 1, 0, 0, 0))
            info.external_attr = ((0o100755 if executable else 0o100644) & 0xFFFF) << 16
            info.compress_type = zipfile.ZIP_DEFLATED
            zf.writestr(info, content.encode("utf-8"))


def unique_name(base: str, taken: set[str]) -> str:
    name, n = base, 2
    while name in taken:
        suffix = f"-{n}"
        name = base[: 64 - len(suffix)].rstrip("-") + suffix
        n += 1
    taken.add(name)
    return name


def convert_workflow(
    wf: Workflow,
    outdir: str | Path,
    mode: str = "skill",
    webhook_url: str | None = None,
    make_zip: bool = False,
    brand: str = DEFAULT_BRAND,
    brand_url: str | None = None,
    taken: set[str] | None = None,
) -> ConvertResult:
    name = slugify(wf.name)
    if taken is not None:
        name = unique_name(name, taken)
    files = build_files(wf, mode=mode, webhook_url=webhook_url, name=name, brand=brand, brand_url=brand_url)
    out = Path(outdir)
    folder = out / name
    write_folder(files, folder)
    zip_path = None
    if make_zip:
        zip_path = out / f"{name}.zip"
        write_zip(files, zip_path, name)
    return ConvertResult(workflow=wf, name=name, folder=folder, zip_path=zip_path, files=sorted(files),
                         mode=mode, webhook_url=webhook_url)
