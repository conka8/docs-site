import json
from pathlib import Path

import pytest

FIXTURES = Path(__file__).parent / "fixtures"
N8N = FIXTURES / "n8n"
MAKE = FIXTURES / "make"

# Fake secrets are assembled at runtime so no secret-looking string sits in the repo.
SECRETS = {
    "bearer": "abcdefghij" + "klmnopqrstuvwxyz0123456789",
    "openai": "sk-" + "proj-" + "A" * 32,
    "aws": "AK" + "IA" + "ABCDEFGHIJKLMNOP",
    "github": "gh" + "p_" + "abcdefghijklmnopqrstuvwxyz0123456789",
    "slack": "xo" + "xb-" + "1234567890-abcdefghijkl",
    "anthropic": "sk-" + "ant-" + "api03-" + "Z" * 20,
    "plain_header": "plainvalue-not-a-pattern-42",
    "password": "hunter2" + "hunter2",
    "query": "SUPERSECRET" + "QUERYKEY123",
    "live": "sk-" + "live-" + "0123456789abcdefghij",
    "pem_body": "MIIabc" + "defSECRETPEM",
}


def secrets_workflow() -> dict:
    s = SECRETS
    pem = "-----BEGIN RSA " + "PRIVATE KEY-----\n" + s["pem_body"] + "\n-----END RSA " + "PRIVATE KEY-----"
    return {
        "name": "Leaky Workflow",
        "nodes": [
            {"parameters": {"httpMethod": "POST", "path": "leaky", "authentication": "headerAuth"},
             "name": "Hook", "type": "n8n-nodes-base.webhook", "typeVersion": 2,
             "credentials": {"httpHeaderAuth": {"id": "hh1-CRED-ID", "name": "Webhook Guard"}}},
            {"parameters": {
                "method": "POST",
                "url": "https://api.example.com/v1/send?api_key=" + s["query"] + "&mode=fast",
                "sendHeaders": True,
                "headerParameters": {"parameters": [
                    {"name": "Authorization", "value": "Bearer " + s["bearer"]},
                    {"name": "X-API-Key", "value": s["plain_header"]},
                    {"name": "Content-Type", "value": "application/json"},
                ]},
                "sendBody": True,
                "jsonBody": "={\"openai\": \"" + s["openai"] + "\", \"aws\": \"" + s["aws"] + "\"}",
                "authentication": "genericCredentialType",
                "genericAuthType": "httpHeaderAuth",
            },
             "name": "Call API", "type": "n8n-nodes-base.httpRequest", "typeVersion": 4.2,
             "credentials": {"httpHeaderAuth": {"id": "hh2-CRED-ID", "name": "Acme API Key"}}},
            {"parameters": {"jsCode": "const token = '" + s["github"] + "';\nconst slack = '" + s["slack"]
                            + "';\nreturn items;"},
             "name": "Code", "type": "n8n-nodes-base.code", "typeVersion": 2},
            {"parameters": {"assignments": {"assignments": [
                {"name": "password", "value": s["password"]},
                {"name": "apiKey", "value": "anthropic " + s["anthropic"]},
                {"name": "greeting", "value": "hello"},
            ]}}, "name": "Set Secrets", "type": "n8n-nodes-base.set", "typeVersion": 3.4},
            {"parameters": {"content": "Remember: the key is " + s["live"] + " and " + pem},
             "name": "Note", "type": "n8n-nodes-base.stickyNote", "typeVersion": 1},
        ],
        "connections": {
            "Hook": {"main": [[{"node": "Call API", "type": "main", "index": 0}]]},
            "Call API": {"main": [[{"node": "Code", "type": "main", "index": 0}]]},
            "Code": {"main": [[{"node": "Set Secrets", "type": "main", "index": 0}]]},
        },
        "staticData": {"node:Hook": {"lastSeen": "static-" + s["password"]}},
        "pinData": {"Hook": [{"json": {"body": {"email": "real.person@example.com"}}}]},
    }


@pytest.fixture
def secrets_file(tmp_path) -> Path:
    p = tmp_path / "leaky.json"
    p.write_text(json.dumps(secrets_workflow()), encoding="utf-8")
    return p


@pytest.fixture
def out(tmp_path) -> Path:
    d = tmp_path / "out"
    d.mkdir()
    return d


def read_tree(folder: Path) -> str:
    """All text in a folder, for 'is this secret anywhere?' checks."""
    return "\n".join(p.read_text(encoding="utf-8") for p in sorted(folder.rglob("*")) if p.is_file())
