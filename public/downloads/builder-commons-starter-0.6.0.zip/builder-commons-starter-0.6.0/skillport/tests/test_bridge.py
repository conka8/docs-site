"""Bridge mode: SKILL.md content and the call_webhook.py script, tested against a local server on 127.0.0.1."""

import importlib.util
import json
import re
import subprocess
import sys
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

import pytest
import yaml

from skillport import call_webhook, convert_file, load_workflows
from skillport.bridge import render_bridge_skill_md, safe_webhook_url, script_source

from conftest import MAKE, N8N


class Handler(BaseHTTPRequestHandler):
    requests: list = []

    def log_message(self, *args):  # keep test output quiet
        pass

    def _record(self, body):
        Handler.requests.append({"method": self.command, "path": self.path, "headers": dict(self.headers),
                                 "body": body})

    def _reply(self, code, payload, content_type="application/json"):
        data = payload.encode() if isinstance(payload, str) else json.dumps(payload).encode()
        self.send_response(code)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def do_POST(self):
        length = int(self.headers.get("Content-Length") or 0)
        body = self.rfile.read(length).decode()
        self._record(body)
        if self.path.startswith("/webhook/fail"):
            self._reply(500, {"message": "Workflow could not be started"})
        elif self.path.startswith("/webhook/missing"):
            self._reply(404, {"message": "not registered"})
        elif self.path.startswith("/webhook/text"):
            self._reply(200, "plain ok", "text/plain")
        else:
            self._reply(200, {"received": json.loads(body or "{}"), "status": "ok"})

    def do_GET(self):
        self._record("")
        self._reply(200, {"method": "GET", "path": self.path})


@pytest.fixture
def server():
    Handler.requests = []
    srv = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
    thread = threading.Thread(target=srv.serve_forever, kwargs={"poll_interval": 0.01}, daemon=True)
    thread.start()
    yield f"http://127.0.0.1:{srv.server_address[1]}"
    srv.shutdown()
    srv.server_close()


@pytest.fixture(autouse=True)
def clean_env(monkeypatch):
    monkeypatch.delenv("N8N_WEBHOOK_URL", raising=False)
    monkeypatch.delenv("N8N_WEBHOOK_HEADER", raising=False)


# ---------------------------------------------------------------- the script


def test_post_json_and_print_reply(server, capsys):
    rc = call_webhook.main(["--url", server + "/webhook/lead", "--data", '{"email": "a@b.com", "n": 2}'])
    assert rc == 0
    req = Handler.requests[-1]
    assert req["method"] == "POST" and req["path"] == "/webhook/lead"
    assert json.loads(req["body"]) == {"email": "a@b.com", "n": 2}
    assert req["headers"]["Content-Type"] == "application/json"
    printed = json.loads(capsys.readouterr().out)
    assert printed == {"received": {"email": "a@b.com", "n": 2}, "status": "ok"}


def test_url_from_env_and_header_auth(server, monkeypatch, capsys):
    monkeypatch.setenv("N8N_WEBHOOK_URL", server + "/webhook/env")
    monkeypatch.setenv("N8N_WEBHOOK_HEADER", "X-Webhook-Key: s3cret")
    rc = call_webhook.main(["--header", "X-Extra: 1"])
    assert rc == 0
    req = Handler.requests[-1]
    assert req["path"] == "/webhook/env" and req["body"] == "{}"
    assert req["headers"]["X-Webhook-Key"] == "s3cret" and req["headers"]["X-Extra"] == "1"


def test_data_file(server, tmp_path, capsys):
    f = tmp_path / "in.json"
    f.write_text('{"city": "Zürich"}', encoding="utf-8")
    assert call_webhook.main(["--url", server + "/webhook/x", "--data-file", str(f)]) == 0
    assert json.loads(Handler.requests[-1]["body"]) == {"city": "Zürich"}


def test_get_sends_query_string(server, capsys):
    rc = call_webhook.main(["--url", server + "/webhook/q?x=1", "--method", "get", "--data", '{"a": "b c", "n": 1}'])
    assert rc == 0
    req = Handler.requests[-1]
    assert req["method"] == "GET" and req["path"] == "/webhook/q?x=1&a=b+c&n=1"


def test_plain_text_reply(server, capsys):
    assert call_webhook.main(["--url", server + "/webhook/text"]) == 0
    assert capsys.readouterr().out.strip() == "plain ok"


def test_http_error_exits_1(server, capsys):
    rc = call_webhook.main(["--url", server + "/webhook/fail", "--data", "{}"])
    assert rc == 1
    err = capsys.readouterr().err
    assert "HTTP 500" in err and "Workflow could not be started" in err
    assert call_webhook.main(["--url", server + "/webhook/missing"]) == 1
    assert "workflow is active" in capsys.readouterr().err


@pytest.mark.parametrize("argv, message", [
    ([], "no webhook URL"),
    (["--url", "ftp://x"], "must start with http"),
    (["--url", "http://127.0.0.1:9", "--data", "{not json"], "not valid JSON"),
    (["--url", "http://127.0.0.1:9", "--data-file", "/definitely/missing.json"], "not valid JSON"),
    (["--url", "http://127.0.0.1:9", "--header", "no-colon"], "Header must look like"),
])
def test_bad_input_exits_2(argv, message, capsys):
    assert call_webhook.main(argv) == 2
    assert message in capsys.readouterr().err


def test_connection_refused_exits_2(capsys):
    # Port 9 (discard) on localhost is closed in test environments; nothing leaves the machine.
    assert call_webhook.main(["--url", "http://127.0.0.1:9/webhook/x", "--timeout", "2"]) == 2
    assert "could not reach the webhook" in capsys.readouterr().err


def test_generated_script_runs_as_a_program(server, out):
    (res,) = convert_file(N8N / "lead_capture.json", out, mode="bridge", webhook_url=server + "/webhook/lead-capture")
    script = res.folder / "scripts" / "call_webhook.py"
    assert script.read_text(encoding="utf-8") == script_source()
    ok = subprocess.run([sys.executable, str(script), "--data", '{"email": "x@y.z"}', "--url",
                         server + "/webhook/lead-capture"], capture_output=True, text=True, timeout=30)
    assert ok.returncode == 0, ok.stderr
    assert json.loads(ok.stdout)["received"] == {"email": "x@y.z"}
    bad = subprocess.run([sys.executable, str(script), "--url", server + "/webhook/fail"],
                         capture_output=True, text=True, timeout=30)
    assert bad.returncode == 1 and "HTTP 500" in bad.stderr
    # the copy is importable on its own (stdlib only)
    spec = importlib.util.spec_from_file_location("copied_call_webhook", script)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    assert callable(mod.main)


# ---------------------------------------------------------------- the bridge SKILL.md


def frontmatter(md):
    m = re.match(r"^---\n(.*?)\n---\n", md, re.S)
    return yaml.safe_load(m.group(1))


def test_bridge_skill_md_detects_webhook():
    (wf,) = load_workflows(N8N / "lead_capture.json")
    md = render_bridge_skill_md(wf, "https://n8n.example.com/webhook/lead-capture")
    meta = frontmatter(md)
    assert meta["name"] == "lead-capture-ai-scoring"
    assert meta["description"].startswith("Runs the existing n8n workflow")
    assert "listens for **POST** requests on the path `/lead-capture`" in md
    assert "https://<your-n8n-host>/webhook/lead-capture" in md
    assert "python3 scripts/call_webhook.py --url 'https://n8n.example.com/webhook/lead-capture' --data" in md
    assert '"email": "..."' in md
    assert "None on this computer. n8n uses its own saved accounts: OpenAI, Slack, Gmail, Google Sheets." in md
    assert "4. Check whether" in md  # the step list of what n8n does


def test_bridge_without_url_uses_env_and_method():
    data = {"name": "Getter", "nodes": [
        {"name": "Hook", "type": "n8n-nodes-base.webhook", "parameters": {"httpMethod": "GET", "path": "/get-it/",
                                                                          "authentication": "headerAuth"}}]}
    from skillport import parse_n8n
    md = render_bridge_skill_md(parse_n8n(data), None)
    assert "`N8N_WEBHOOK_URL`" in md
    assert "--method GET" in md and "--url" not in md.split("```bash")[1]
    assert "`/get-it`" in md
    assert "N8N_WEBHOOK_HEADER" in md


def test_bridge_without_webhook_trigger_and_make():
    (wf,) = load_workflows(N8N / "schedule_http_code.json")
    md = render_bridge_skill_md(wf, None)
    assert "does not start from a webhook" in md
    (wf,) = load_workflows(MAKE / "lead_router.json")
    md = render_bridge_skill_md(wf, "https://hook.eu1.make.com/abc")
    assert "Make.com scenario starts from a webhook" in md
    assert "Make.com uses its own saved accounts" in md


def test_secret_looking_webhook_url_is_not_written(out):
    (wf,) = load_workflows(N8N / "lead_capture.json")
    assert safe_webhook_url("https://n8n.example.com/webhook/x?token=abcdef123", wf) is None
    assert any("looked like it contains a secret" in w for w in wf.warnings)
    count = len(wf.warnings)
    safe_webhook_url("https://n8n.example.com/webhook/x?token=abcdef123", wf)
    assert len(wf.warnings) == count, "warning is not repeated"
    assert safe_webhook_url(None, wf) is None
    assert safe_webhook_url("https://ok.example.com/webhook/x", wf) == "https://ok.example.com/webhook/x"
    (res,) = convert_file(N8N / "lead_capture.json", out, mode="bridge",
                          webhook_url="https://n8n.example.com/webhook/x?token=abcdef123")
    assert "abcdef123" not in (res.folder / "SKILL.md").read_text(encoding="utf-8")
    assert "abcdef123" not in (res.folder / "README.md").read_text(encoding="utf-8")


def test_bridge_readme(out):
    (res,) = convert_file(N8N / "lead_capture.json", out, mode="bridge", brand="Automation Lab")
    readme = (res.folder / "README.md").read_text(encoding="utf-8")
    assert 'export N8N_WEBHOOK_URL="https://your-n8n.example.com/webhook/your-path"' in readme
    assert "python3 scripts/call_webhook.py --data" in readme
    assert readme.rstrip().endswith("Converted with Automation Lab.")
    (res,) = convert_file(N8N / "lead_capture.json", out, mode="bridge", webhook_url="https://n8n.example.com/webhook/y")
    assert "already filled in" in (res.folder / "README.md").read_text(encoding="utf-8")
