import json
import shutil
import subprocess
import sys
from pathlib import Path

import pytest

from skillport.cli import main

from conftest import FIXTURES, MAKE, N8N

SRC = Path(__file__).parent.parent / "src"


def test_convert(out, capsys):
    rc = main(["convert", str(N8N / "lead_capture.json"), "-o", str(out)])
    assert rc == 0
    text = capsys.readouterr().out
    assert 'Converted "Lead Capture → AI Scoring 🚀" (n8n)' in text
    assert "7 steps, 4 account(s) needed: OPENAI_API_KEY, SLACK_TOKEN, GMAIL_OAUTH_TOKEN, GOOGLE_SHEETS_OAUTH_TOKEN" in text
    assert (out / "lead-capture-ai-scoring" / "SKILL.md").is_file()


def test_convert_zip_and_brand(out, capsys):
    rc = main(["convert", str(MAKE / "lead_router.json"), "-o", str(out), "--zip", "--brand-name", "Make Pros",
               "--brand-url", "https://example.com"])
    assert rc == 0
    assert "Zip: " in capsys.readouterr().out
    assert (out / "make-lead-router.zip").is_file()
    readme = (out / "make-lead-router" / "README.md").read_text(encoding="utf-8")
    assert "Converted with [Make Pros](https://example.com)." in readme


def test_convert_bridge(out, capsys):
    rc = main(["convert", str(N8N / "lead_capture.json"), "-o", str(out), "--mode", "bridge",
               "--webhook-url", "https://n8n.example.com/webhook/lead-capture"])
    assert rc == 0
    assert "scripts/call_webhook.py" in capsys.readouterr().out
    assert "https://n8n.example.com/webhook/lead-capture" in (out / "lead-capture-ai-scoring" / "SKILL.md").read_text(encoding="utf-8")


def test_convert_notes_on_warnings_and_unused_url(out, capsys):
    rc = main(["convert", str(N8N / "cycle.json"), "-o", str(out), "--webhook-url", "https://x.example.com"])
    assert rc == 0
    cap = capsys.readouterr()
    assert "Note: Loop found" in cap.out
    assert "--webhook-url is only used with --mode bridge" in cap.err


def test_convert_export_with_several_workflows(out, capsys):
    assert main(["convert", str(N8N / "export_all.json"), "-o", str(out)]) == 0
    assert sorted(p.name for p in out.iterdir()) == ["first-flow", "second-flow"]


def test_convert_list_with_one_empty_workflow(tmp_path, out, capsys):
    f = tmp_path / "mixed.json"
    f.write_text(json.dumps([{"name": "Ok", "nodes": [{"name": "T", "type": "n8n-nodes-base.manualTrigger"}]},
                             {"name": "Hollow", "nodes": []}]))
    assert main(["convert", str(f), "-o", str(out)]) == 1
    cap = capsys.readouterr()
    assert 'Converted "Ok"' in cap.out and '"Hollow" has no steps' in cap.err
    assert (out / "ok" / "SKILL.md").is_file()


@pytest.mark.parametrize("fixture, message", [
    ("malformed.json", "is not valid JSON (line 2, column 16"),
    ("empty.json", "has no steps to convert"),
    ("sticky_only.json", "has no steps to convert"),
    ("does_not_exist.json", "File not found"),
])
def test_convert_errors(fixture, message, out, capsys):
    rc = main(["convert", str(N8N / fixture), "-o", str(out)])
    assert rc == 1
    err = capsys.readouterr().err
    assert err.startswith("skillport: error: ") and message in err
    assert list(out.iterdir()) == []


def test_convert_unwritable_output(tmp_path, capsys):
    blocker = tmp_path / "file"
    blocker.write_text("x")
    rc = main(["convert", str(N8N / "cycle.json"), "-o", str(blocker / "sub")])
    assert rc == 1
    assert "could not write files" in capsys.readouterr().err


def test_inspect_text(capsys):
    assert main(["inspect", str(N8N / "lead_capture.json")]) == 0
    text = capsys.readouterr().out
    assert "Steps (7):" in text and "If `message.content.score` is greater than `70` -> go to step 5" in text
    assert "Inputs: name, email, company, message" in text


def test_inspect_json(capsys):
    assert main(["inspect", str(MAKE / "lead_router.json"), "--format", "json"]) == 0
    data = json.loads(capsys.readouterr().out)
    assert data["format"] == "make" and data["skill_name"] == "make-lead-router"
    assert [s["number"] for s in data["steps"]] == [1, 2, 3, 4, 5, 6]
    assert data["steps"][0]["trigger"] is True
    assert data["steps"][2]["links"][1] == "Route 2 (always) -> go to step 5 (Google Sheets: add row)"
    assert [c["env_var"] for c in data["credentials"]] == ["OPENAI_API_KEY", "SLACK_TOKEN", "GOOGLE_SHEETS_OAUTH_TOKEN"]
    assert main(["inspect", str(N8N / "export_all.json"), "--format", "json"]) == 0
    assert len(json.loads(capsys.readouterr().out)) == 2


def test_inspect_bad_file(capsys):
    assert main(["inspect", str(N8N / "malformed.json")]) == 1
    assert "not valid JSON" in capsys.readouterr().err


def test_batch_continues_after_errors(out, capsys):
    rc = main(["batch", str(FIXTURES / "batch"), "-o", str(out), "--zip"])
    assert rc == 1, "a failed file makes the exit code non-zero"
    text = capsys.readouterr().out
    lines = text.splitlines()
    assert lines[0].split() == ["File", "Result", "Skill", "Steps", "Details"]
    assert set(lines[1]) <= {"-", " "}
    rows = {line.split()[0]: line for line in lines[2:6]}
    assert "FAILED" in rows["broken.json"] and "not valid JSON" in rows["broken.json"]
    assert "OK" in rows["lead.json"] and "lead-capture-ai-scoring" in rows["lead.json"]
    assert "OK" in rows["make_router.json"] and "make-lead-router" in rows["make_router.json"]
    assert "OK" in rows["sub/digest.json"] and "daily-crypto-price-digest" in rows["sub/digest.json"]
    assert "3 skill(s) written to" in text and "1 file(s) failed." in text
    assert sorted(p.name for p in out.iterdir()) == [
        "daily-crypto-price-digest", "daily-crypto-price-digest.zip", "lead-capture-ai-scoring",
        "lead-capture-ai-scoring.zip", "make-lead-router", "make-lead-router.zip"]


def test_batch_all_good_and_duplicate_names(tmp_path, out, capsys):
    src = tmp_path / "lib"
    src.mkdir()
    shutil.copy(N8N / "cycle.json", src / "a.json")
    shutil.copy(N8N / "cycle.json", src / "b.json")
    assert main(["batch", str(src), "-o", str(out), "--mode", "bridge"]) == 0
    assert sorted(p.name for p in out.iterdir()) == ["retry-until-done", "retry-until-done-2"]
    assert (out / "retry-until-done-2" / "scripts" / "call_webhook.py").is_file()
    assert "2 skill(s) written" in capsys.readouterr().out


def test_batch_skips_output_folder_inside_input(tmp_path, capsys):
    src = tmp_path / "lib"
    src.mkdir()
    shutil.copy(N8N / "cycle.json", src / "a.json")
    assert main(["batch", str(src), "-o", str(src / "skills")]) == 0
    capsys.readouterr()
    # second run must not pick up anything written into lib/skills (e.g. source/workflow.json)
    assert main(["batch", str(src), "-o", str(src / "skills")]) == 0
    assert "1 skill(s) written" in capsys.readouterr().out


def test_batch_errors(tmp_path, capsys):
    assert main(["batch", str(tmp_path / "missing"), "-o", str(tmp_path / "o")]) == 1
    assert "is not a folder" in capsys.readouterr().err
    (tmp_path / "emptydir").mkdir()
    assert main(["batch", str(tmp_path / "emptydir"), "-o", str(tmp_path / "o")]) == 1
    assert "No .json files found" in capsys.readouterr().err


def test_usage(capsys):
    assert main([]) == 2
    assert "convert" in capsys.readouterr().out
    with pytest.raises(SystemExit) as exc:
        main(["convert"])
    assert exc.value.code == 2
    with pytest.raises(SystemExit) as exc:
        main(["convert", "x.json", "--mode", "nope"])
    assert exc.value.code == 2
    with pytest.raises(SystemExit) as exc:
        main(["--version"])
    assert exc.value.code == 0
    assert "skillport 0.2.1" in capsys.readouterr().out


def test_python_dash_m(out):
    env = {"PYTHONPATH": str(SRC), "PATH": "/usr/bin:/bin"}
    proc = subprocess.run([sys.executable, "-m", "skillport", "inspect", str(N8N / "cycle.json")],
                          capture_output=True, text=True, env=env, timeout=60)
    assert proc.returncode == 0, proc.stderr
    assert "Retry Until Done" in proc.stdout
    proc = subprocess.run([sys.executable, "-m", "skillport", "convert", str(N8N / "malformed.json")],
                          capture_output=True, text=True, env=env, timeout=60)
    assert proc.returncode == 1 and "not valid JSON" in proc.stderr


def test_bundled_skill_and_readme():
    import re

    import yaml
    root = Path(__file__).parent.parent
    md = (root / "skills" / "n8n-to-skill" / "SKILL.md").read_text(encoding="utf-8")
    meta = yaml.safe_load(re.match(r"^---\n(.*?)\n---\n", md, re.S).group(1))
    assert meta["name"] == "n8n-to-skill"
    assert len(meta["description"]) <= 1024 and "Use when" in meta["description"]
    assert "skillport inspect" in md and "skillport batch" in md
    readme = (root / "README.md").read_text(encoding="utf-8")
    for needle in ("## Quickstart", "## Limits", "verify against current docs".lower()):
        assert needle in readme.lower() if needle.islower() else needle in readme
