import json

import pytest

from skillport import detect_format, load_workflows, parse_data, parse_make
from skillport.credentials import collect_credentials
from skillport.loader import load_json
from skillport.model import SkillportError
from skillport.render import render_skill_md, step_links

from conftest import MAKE, N8N


def names(wf):
    return [wf.nodes[n].name for n in wf.steps]


# ---------------------------------------------------------------- Make.com


def test_make_router_blueprint():
    (wf,) = load_workflows(MAKE / "lead_router.json")
    assert wf.source_format == "make"
    assert names(wf) == ["Webhook", "Score lead", "Router", "Slack: create message", "Google Sheets: add row",
                         "HTTP request"]
    assert wf.webhook is wf.nodes["1"]
    assert wf.nodes["1"].is_trigger
    links = step_links(wf, "3")
    assert links == [
        'Route 1 (only if Hot lead: `result (from "Score lead")` is greater than `70`) → go to step 4 (Slack: create message)',
        "Route 2 (always) → go to step 5 (Google Sheets: add row)",
    ]
    assert wf.nodes["4"].details[0].startswith("Only runs if Hot lead")
    assert step_links(wf, "5") == []  # step 6 follows directly on route 2
    assert "Ask OpenAI (model gpt-4o-mini)" in wf.nodes["2"].summary
    assert 'User message: "Lead {name (from "Webhook")}' in wf.nodes["2"].details[1]
    assert [c.env_var for c in collect_credentials(wf)] == ["OPENAI_API_KEY", "SLACK_TOKEN", "GOOGLE_SHEETS_OAUTH_TOKEN"]
    assert wf.inputs == ["name", "email", "message"]


def test_make_http_module_is_redacted():
    (wf,) = load_workflows(MAKE / "lead_router.json")
    http = wf.nodes["6"]
    text = http.summary + " ".join(http.details)
    assert "MAKESECRETTOKEN999" not in text and "makebearertoken" not in text
    assert "token=[REDACTED]" in text and "Authorization: [REDACTED]" in text
    assert "Method: POST" in http.details


def test_make_without_trigger_gets_start_step():
    (wf,) = load_workflows(MAKE / "scheduled_no_trigger.json")
    assert names(wf)[0] == "Scenario start"
    assert wf.nodes["start"].trigger_info["kind"] == "schedule"
    assert wf.nodes["2"].summary == "Set these variables: total."
    assert "Send an email with Email to `owner@example.com`" in wf.nodes["3"].summary
    weird = wf.nodes["4"]
    assert weird.summary == "Weird App: do magic."
    assert "has no built-in description" in weird.details[0]
    assert "Make.com schedule" in render_skill_md(wf)
    # weird-app has no saved connection (__IMTCONN__) and is unknown, so no account is listed for it
    assert [c.env_var for c in collect_credentials(wf)] == ["GOOGLE_SHEETS_OAUTH_TOKEN", "SMTP_PASSWORD"]


def test_make_watch_trigger():
    (wf,) = load_workflows(MAKE / "watch_trigger.json")
    first = wf.nodes[wf.steps[0]]
    assert first.is_trigger and first.trigger_info == {"kind": "event", "service": "Google Sheets"}
    assert first.summary.startswith("Starts when something new happens in Google Sheets")
    assert "Telegram" in wf.nodes["2"].summary
    assert wf.inputs == []


def test_make_misc_modules():
    data = {"name": "Misc", "flow": [
        {"id": 1, "module": "gateway:CustomMailHook"},
        {"id": 2, "module": "builtin:BasicFeeder", "mapper": {"array": "{{1.attachments}}"}},
        {"id": 3, "module": "json:ParseJSON", "mapper": {"json": "{{2.data}}"}},
        {"id": 4, "module": "util:FunctionSleep", "mapper": {"duration": 3}},
        {"id": 5, "module": "builtin:BasicAggregator"},
        {"id": 6, "module": "airtable:ActionCreateRecord", "parameters": {"__IMTCONN__": 1}, "mapper": {"table": "Leads"}},
        {"id": 7, "module": "gateway:WebhookRespond", "mapper": {"status": 201, "body": "ok"}},
        "not a module",
        {"id": 7, "module": "util:SetVariables", "mapper": {"variables": [{"name": "a", "value": "1"}]}},
    ]}
    wf = parse_make(data)
    s = {n: wf.nodes[n].summary for n in wf.steps}
    assert s["1"].startswith("Starts when an email arrives")
    assert s["2"] == 'Go through each item of `attachments (from "Mailhook")` one by one.'
    assert s["3"] == "Parse JSON text into data."
    assert s["4"] == "Wait 3 seconds."
    assert s["5"] == "Combine the items back into one bundle."
    assert s["6"] == 'Airtable: create record in table "Leads".'
    assert s["7"] == "Send a reply (status 201) to whoever called the webhook."
    assert "7-8" in wf.nodes, "duplicate module ids are kept apart"
    assert any("not an object" in w for w in wf.warnings)


def test_parse_make_rejects_non_blueprint():
    with pytest.raises(SkillportError):
        parse_make({"name": "x"})
    with pytest.raises(SkillportError):
        parse_make([])


def test_make_empty_flow():
    wf = parse_make({"name": "Nothing", "flow": []})
    assert wf.steps == []


# ---------------------------------------------------------------- loader


def test_detect_format():
    assert detect_format({"nodes": [], "connections": {}}) == "n8n"
    assert detect_format({"connections": {}}) == "n8n"
    assert detect_format({"flow": []}) == "make"
    assert detect_format({"workflow": {"nodes": []}}) == "n8n"
    assert detect_format({"blueprint": {"flow": []}}) == "make"
    for bad in ({"hello": 1}, [], "x", None):
        with pytest.raises(SkillportError, match="doesn't look like"):
            detect_format(bad)


def test_parse_data_lists_and_wrappers():
    wfs = load_workflows(N8N / "export_all.json")
    assert [w.name for w in wfs] == ["First Flow", "Second Flow"]
    with pytest.raises(SkillportError, match="empty list"):
        parse_data([])
    (wf,) = parse_data({"name": "Outer", "blueprint": {"flow": [{"id": 1, "module": "gateway:CustomWebHook"}]}})
    assert wf.name == "Outer" and wf.source_format == "make"
    (wf,) = parse_data({"nodes": []}, fallback_name="from-file")
    assert wf.name == "from-file"


def test_load_errors(tmp_path):
    with pytest.raises(SkillportError, match="not valid JSON \\(line 2"):
        load_workflows(N8N / "malformed.json")
    with pytest.raises(SkillportError, match="File not found"):
        load_json(tmp_path / "nope.json")
    with pytest.raises(SkillportError, match="is a folder"):
        load_json(tmp_path)
    empty = tmp_path / "empty.json"
    empty.write_text("   ")
    with pytest.raises(SkillportError, match="is empty"):
        load_json(empty)
    binary = tmp_path / "bin.json"
    binary.write_bytes(b"\xff\xfe\x00\x81")
    with pytest.raises(SkillportError, match="not a text file"):
        load_json(binary)
    other = tmp_path / "other.json"
    other.write_text(json.dumps({"some": "thing"}))
    with pytest.raises(SkillportError, match="doesn't look like an n8n workflow"):
        load_workflows(other)


def test_load_handles_utf8_bom(tmp_path):
    p = tmp_path / "bom.json"
    p.write_bytes("﻿".encode("utf-8") + (N8N / "unicode.json").read_bytes())
    (wf,) = load_workflows(p)
    assert wf.name.startswith("🤖")
