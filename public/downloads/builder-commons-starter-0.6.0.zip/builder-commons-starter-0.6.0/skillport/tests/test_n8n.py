import json

import pytest

from skillport import load_workflows, parse_n8n
from skillport.credentials import collect_credentials, describe_credential
from skillport.model import SkillportError
from skillport.n8n import REGISTRY, describe_node, is_trigger_type, node_key, summarize_conditions
from skillport.render import step_links

from conftest import N8N


def load(name):
    (wf,) = load_workflows(N8N / name)
    return wf


def names(wf):
    return [wf.nodes[n].name for n in wf.steps]


# ---------------------------------------------------------------- lead capture (the realistic one)


def test_lead_capture_order_and_summaries():
    wf = load("lead_capture.json")
    assert wf.source_format == "n8n"
    assert wf.name == "Lead Capture → AI Scoring 🚀"
    assert names(wf) == ["Lead Webhook", "Normalize Lead", "Score Lead", "Hot Lead?", "Notify Sales",
                         "Send Nurture Email", "Log to Sheet"]
    hook = wf.nodes["Lead Webhook"]
    assert hook.is_trigger and hook.trigger_info == {"kind": "webhook", "method": "POST", "path": "lead-capture",
                                                     "auth": "none"}
    assert wf.webhook is hook
    assert "`/lead-capture`" in hook.summary
    assert wf.nodes["Normalize Lead"].summary == "Set these fields: name, email, company, message."
    assert "OpenAI (model GPT-4O-MINI)" in wf.nodes["Score Lead"].summary
    assert any("Score leads from 0 to 100" in d for d in wf.nodes["Score Lead"].details)
    assert "Lead: {name} from {company}" in " ".join(wf.nodes["Score Lead"].details)
    assert wf.nodes["Notify Sales"].summary == "Post a message on Slack to `#sales`."
    assert "Gmail" in wf.nodes["Send Nurture Email"].summary
    assert wf.nodes["Log to Sheet"].summary == (
        'Add a row to the sheet "Leads" of the spreadsheet "Lead Tracker" in Google Sheets.')
    assert wf.services() == ["Webhook", "OpenAI", "Slack", "Gmail", "Google Sheets"]


def test_lead_capture_branches():
    wf = load("lead_capture.json")
    links = step_links(wf, "Hot Lead?")
    assert links == [
        "If `message.content.score` is greater than `70` → go to step 5 (Notify Sales)",
        "Otherwise → go to step 6 (Send Nurture Email)",
    ]
    assert step_links(wf, "Notify Sales") == ["Next → step 7 (Log to Sheet)"]
    assert step_links(wf, "Send Nurture Email") == []  # next step follows directly
    assert step_links(wf, "Normalize Lead") == []


def test_lead_capture_credentials_inputs_notes():
    wf = load("lead_capture.json")
    creds = collect_credentials(wf)
    assert [(c.service, c.env_var) for c in creds] == [
        ("OpenAI", "OPENAI_API_KEY"), ("Slack", "SLACK_TOKEN"), ("Gmail", "GMAIL_OAUTH_TOKEN"),
        ("Google Sheets", "GOOGLE_SHEETS_OAUTH_TOKEN")]
    assert creds[1].accounts == ["Team Slack"] and creds[1].used_by == ["Notify Sales"]
    assert wf.inputs == ["name", "email", "company", "message"]
    assert len(wf.notes) == 1 and wf.notes[0].startswith("## Setup")
    assert "Sticky Note" not in wf.nodes
    assert wf.warnings == []


# ---------------------------------------------------------------- other shapes


def test_schedule_http_code():
    wf = load("schedule_http_code.json")
    assert names(wf) == ["Every Morning", "Get Prices", "Format Digest", "Send to Telegram"]
    trig = wf.nodes["Every Morning"]
    assert trig.trigger_info == {"kind": "schedule", "when": "every day at 09:30"}
    http = wf.nodes["Get Prices"]
    assert http.summary == "Send an HTTP GET request to `https://api.coingecko.com/api/v3/simple/price`."
    joined = " | ".join(http.details)
    assert "Query parameters: ids: bitcoin,ethereum; vs_currencies: usd" in joined
    assert "x-cg-demo-api-key: [REDACTED]" in joined and "CG-DEMOKEY" not in joined
    code = wf.nodes["Format Digest"]
    assert code.summary == "Run custom JavaScript code (3 lines)."
    assert code.code[0] == "javascript" and "Prices today" in code.code[1]
    assert wf.nodes["Send to Telegram"].summary == "Send a Telegram message to chat `-1001234567890`."
    assert wf.inputs == []


def test_switch_branch_and_merge():
    wf = load("branch_merge.json")
    assert names(wf) == ["Start", "By Priority", "Page On-Call", "Queue Ticket", "Ask Triage", "Merge Results", "Done"]
    links = step_links(wf, "By Priority")
    assert links[0] == 'If `priority` is equal to `urgent` ("urgent") → go to step 3 (Page On-Call)'
    assert links[1].endswith("→ go to step 4 (Queue Ticket)")
    assert links[2] == "Otherwise → go to step 5 (Ask Triage)"
    creds = collect_credentials(wf)
    slack = [c for c in creds if c.env_var == "SLACK_TOKEN"]
    assert len(slack) == 1, "slackApi and slackOAuth2Api must be deduplicated"
    assert slack[0].used_by == ["Page On-Call", "Ask Triage"] and slack[0].accounts == ["Slack A", "Slack B"]


def test_merge_waits_line_in_skill_md():
    from skillport.render import render_skill_md
    md = render_skill_md(load("branch_merge.json"))
    assert "Waits for steps 3 and 4 (Page On-Call, Queue Ticket) to finish." in md


def test_cycle_is_reported_and_does_not_hang():
    wf = load("cycle.json")
    assert names(wf) == ["When clicking Test", "Check Status", "Is Done?", "Finished", "Wait a bit"]
    assert wf.cycles == [["Check Status", "Is Done?", "Wait a bit", "Check Status"]]
    assert any(w.startswith("Loop found: Check Status -> Is Done? -> Wait a bit -> Check Status") for w in wf.warnings)
    assert step_links(wf, "Wait a bit") == ["Then go back to step 2 (Check Status) (this repeats)"]
    assert wf.nodes["Is Done?"].summary == "Check whether `status` is equal to `done`."


def test_pure_cycle_without_trigger():
    wf = load("pure_cycle.json")
    assert names(wf) == ["A", "B"]
    assert wf.cycles and wf.unconnected == []


def test_split_in_batches_loop():
    wf = load("template_wrapped.json")
    assert wf.name == "Wrapped Template"
    assert names(wf) == ["Every hour", "Batches", "Report", "Process"]
    assert step_links(wf, "Batches") == ["When all batches are done → go to step 3 (Report)",
                                         "For each batch → go to step 4 (Process)"]
    assert wf.nodes["Every hour"].trigger_info["when"] == "every 2 hours"
    assert collect_credentials(wf)[0].env_var == "SMTP_PASSWORD"


def test_disabled_nodes_are_skipped_and_bridged():
    wf = load("disabled_nodes.json")
    assert names(wf) == ["Booking Form", "Upsert Contact"]
    assert wf.disabled == ["Old Delay", "Debug Ping"]
    assert wf.unconnected == ["Orphan Step"]
    assert [c.env_var for c in collect_credentials(wf)] == ["HUBSPOT_TOKEN"], "disabled Slack node needs no account"
    assert wf.inputs == ["Full name", "Email", "Budget"]
    assert any("Disabled in the original workflow" in w for w in wf.warnings)
    assert any('"Orphan Step"' in w for w in wf.warnings)
    assert wf.nodes["Upsert Contact"].summary == "HubSpot: upsert contact."


def test_unknown_types_and_ai_subnodes():
    wf = load("unknown_and_agent.json")
    assert names(wf) == ["When chat message received", "AI Agent", "Fancy Scraper"]
    agent = wf.nodes["AI Agent"]
    assert agent.attachments == ["language model: Anthropic Claude chat model (claude-sonnet-5-5)",
                                 "memory: Chat memory (last 10 messages)"]
    assert wf.nodes["Claude Model"].is_subnode and "Claude Model" not in wf.unconnected
    scraper = wf.nodes["Fancy Scraper"]
    assert scraper.summary == "Use Super Scraper9000: scrape page."
    assert "has no built-in description" in scraper.details[0]
    assert "`targetUrl`: output" in scraper.details
    envs = [c.env_var for c in collect_credentials(wf)]
    assert envs == ["SUPER_SCRAPER_API_KEY", "ANTHROPIC_API_KEY"]
    assert wf.inputs == ["chatInput (the user's chat message)"]


def test_missing_fields_are_tolerated():
    wf = load("missing_fields.json")
    assert wf.name == "missing_fields"
    assert len(wf.steps) == 1 and wf.nodes[wf.steps[0]].is_trigger
    text = " ".join(wf.warnings)
    assert "Node #3 is not an object" in text
    assert 'unknown node "Ghost"' in text and 'unknown node "Nowhere"' in text
    assert wf.nodes["No Type"].type == "unknown"
    assert wf.nodes["Old IF"].summary.startswith("Check whether the condition set in the original workflow")


def test_unicode_names():
    wf = load("unicode.json")
    assert names(wf) == ["▶️ Start", "Café ☕ step"]
    assert wf.nodes["Café ☕ step"].details == ["`größe` = groß 🎉"]


def test_empty_and_sticky_only_parse_to_no_steps():
    assert load("empty.json").steps == []
    wf = load("sticky_only.json")
    assert wf.steps == [] and wf.notes == ["TODO: build this"]


def test_duplicate_node_names_get_renamed():
    data = {"nodes": [{"name": "X", "type": "n8n-nodes-base.manualTrigger"}, {"name": "X", "type": "n8n-nodes-base.noOp"}],
            "connections": {"X": {"main": [[{"node": "X (2)"}]]}}}
    wf = parse_n8n(data)
    assert list(wf.nodes) == ["X", "X (2)"]
    assert any("Two nodes are called" in w for w in wf.warnings)


def test_multiple_triggers_and_node_notes():
    data = {"name": "Two starts", "nodes": [
        {"name": "Hook", "type": "n8n-nodes-base.webhook", "parameters": {"path": "a"}},
        {"name": "Timer", "type": "n8n-nodes-base.cron", "parameters": {"triggerTimes": {"item": [{"mode": "everyHour", "minute": 5}]}}},
        {"name": "Work", "type": "n8n-nodes-base.noOp", "notes": "Remember to check the token sk-" + "a" * 20},
    ], "connections": {"Hook": {"main": [[{"node": "Work"}]]}, "Timer": {"main": [[{"node": "Work"}]]}}}
    wf = parse_n8n(data)
    assert [t.name for t in wf.triggers] == ["Hook", "Timer"]
    assert wf.nodes["Timer"].trigger_info["when"] == "every hour at minute 5"
    assert wf.nodes["Hook"].trigger_info["method"] == "GET"
    assert names(wf) == ["Hook", "Timer", "Work"]
    note = wf.nodes["Work"].details[-1]
    assert note.startswith("Note from the author:") and "[REDACTED]" in note and "aaaaaaaa" not in note


def test_parse_n8n_rejects_bad_shapes():
    with pytest.raises(SkillportError):
        parse_n8n([1, 2])
    with pytest.raises(SkillportError):
        parse_n8n({"nodes": "nope"})
    wf = parse_n8n({"name": "x", "nodes": [], "connections": "bad"})
    assert any("connections" in w for w in wf.warnings)


# ---------------------------------------------------------------- registry


def test_node_key_and_triggers():
    assert node_key("n8n-nodes-base.httpRequest") == "httprequest"
    assert node_key("@n8n/n8n-nodes-langchain.openAi") == "lc.openai"
    for t in ("n8n-nodes-base.webhook", "n8n-nodes-base.scheduleTrigger", "n8n-nodes-base.cron",
              "n8n-nodes-base.manualTrigger", "n8n-nodes-base.gmailTrigger", "@n8n/n8n-nodes-langchain.chatTrigger"):
        assert is_trigger_type(t), t
    assert not is_trigger_type("n8n-nodes-base.httpRequest")


def test_registry_has_at_least_30_types():
    assert len(REGISTRY) >= 30


SAMPLES = [
    ("n8n-nodes-base.interval", {"interval": 5, "unit": "minutes"}, "every 5 minutes"),
    ("n8n-nodes-base.formTrigger", {"formTitle": "Join"}, 'form "Join"'),
    ("n8n-nodes-base.executeWorkflowTrigger", {}, "another workflow calls"),
    ("n8n-nodes-base.gmailTrigger", {"event": "messageReceived"}, "Gmail (message received)"),
    ("n8n-nodes-base.filter", {"conditions": {"conditions": [{"leftValue": "={{$json.a}}", "operator": {"operation": "notEmpty"}}]}}, "`a` is not empty"),
    ("n8n-nodes-base.merge", {"mode": "combine"}, "mode: combine"),
    ("n8n-nodes-base.function", {"functionCode": "return items;"}, "JavaScript code (1 lines)"),
    ("n8n-nodes-base.code", {"language": "python", "pythonCode": "a=1\nb=2"}, "Python code (2 lines)"),
    ("n8n-nodes-base.splitOut", {"fieldToSplitOut": "items"}, "`items`"),
    ("n8n-nodes-base.aggregate", {}, "single list"),
    ("n8n-nodes-base.wait", {"resume": "webhook"}, "follow-up webhook"),
    ("n8n-nodes-base.wait", {"resume": "specificTime", "dateTime": "2026-01-01"}, "2026-01-01"),
    ("n8n-nodes-base.respondToWebhook", {"respondWith": "json", "responseBody": "={{ {ok: true} }}"}, "reply"),
    ("n8n-nodes-base.gmail", {"operation": "getAll", "resource": "message"}, "Gmail: get all message"),
    ("n8n-nodes-base.gmail", {"operation": "reply"}, "Reply to an email"),
    ("n8n-nodes-base.emailSend", {"toEmail": "a@b.c", "subject": "Hi", "html": "<p>x</p>"}, "SMTP"),
    ("n8n-nodes-base.googleSheets", {"operation": "read", "sheetName": "S"}, "Read rows from"),
    ("n8n-nodes-base.slack", {"operation": "getAll", "resource": "channel"}, "Slack: get all channel"),
    ("n8n-nodes-base.telegram", {"operation": "sendPhoto"}, "Telegram: send photo"),
    ("n8n-nodes-base.airtable", {"operation": "search", "table": "T"}, 'Search records in Airtable table "T"'),
    ("n8n-nodes-base.notion", {"operation": "create", "resource": "databasePage", "databaseId": {"cachedResultName": "CRM"}, "title": "New"}, 'database "CRM"'),
    ("n8n-nodes-base.hubspot", {"resource": "deal", "operation": "create"}, "HubSpot: create deal"),
    ("n8n-nodes-base.stripe", {"resource": "charge", "operation": "getAll"}, "Stripe: get all charge"),
    ("n8n-nodes-base.openAi", {"resource": "text", "operation": "complete", "prompt": "Write a haiku", "model": "gpt-3.5-turbo-instruct"}, "OpenAI (model gpt-3.5-turbo-instruct)"),
    ("n8n-nodes-base.openAi", {"resource": "chat", "prompt": {"messages": [{"role": "user", "content": "hi"}]}}, "OpenAI"),
    ("@n8n/n8n-nodes-langchain.openAi", {"resource": "image", "prompt": "a cat"}, "Create an image"),
    ("@n8n/n8n-nodes-langchain.openAi", {"resource": "audio", "operation": "transcribe"}, "OpenAI audio: transcribe"),
    ("@n8n/n8n-nodes-langchain.agent", {"promptType": "define", "text": "Research {{ $json.topic }}"}, "AI agent"),
    ("@n8n/n8n-nodes-langchain.chainLlm", {"text": "Summarize", "messages": {"messageValues": [{"message": "Be brief"}]}}, "AI model"),
    ("@n8n/n8n-nodes-langchain.lmChatOpenAi", {"model": "gpt-4o"}, "OpenAI chat model (gpt-4o)"),
    ("@n8n/n8n-nodes-langchain.outputParserStructured", {"jsonSchemaExample": "{\"a\": 1}"}, "fixed JSON format"),
    ("@n8n/n8n-nodes-langchain.toolCalculator", {}, "Tool: Calculator"),
    ("@n8n/n8n-nodes-langchain.toolHttpRequest", {"url": "https://x.io", "method": "POST"}, "HTTP POST"),
    ("n8n-nodes-base.executeWorkflow", {"workflowId": {"cachedResultName": "Sub"}}, '"Sub"'),
    ("n8n-nodes-base.discord", {"text": "hello"}, "Discord"),
    ("n8n-nodes-base.googleDrive", {"operation": "upload", "folderId": {"cachedResultName": "Docs"}}, 'folder "Docs"'),
    ("n8n-nodes-base.set", {"mode": "raw", "jsonOutput": "{\"a\": 1}"}, "Build the data as JSON"),
    ("n8n-nodes-base.set", {"values": {"string": [{"name": "a", "value": "b"}]}}, "Set these fields: a"),
    ("n8n-nodes-base.set", {"fields": {"values": [{"name": "c", "stringValue": "d"}]}}, "Set these fields: c"),
    ("n8n-nodes-base.noOp", {}, "placeholder"),
    ("n8n-nodes-base.start", {}, "by hand"),
]


@pytest.mark.parametrize("node_type, params, expected", SAMPLES)
def test_describe_node_samples(node_type, params, expected):
    desc = describe_node({"type": node_type, "parameters": params})
    assert expected in desc["summary"] + " " + " ".join(desc.get("details") or [])


def test_describe_node_survives_weird_parameters():
    # wrong types everywhere must fall back, not crash
    for node_type in ["n8n-nodes-base." + k for k in REGISTRY if not k.startswith("lc.")]:
        desc = describe_node({"type": node_type, "parameters": {"rules": 5, "conditions": "x", "assignments": [1],
                                                                 "messages": 3, "triggerTimes": {"item": "x"},
                                                                 "rule": {"interval": "x"}}})
        assert desc["summary"]


def test_if_v1_any_and_switch_v1():
    p = {"conditions": {"number": [{"value1": "={{$json.n}}", "operation": "larger", "value2": 5}],
                        "string": [{"value1": "={{$json.s}}", "operation": "isEmpty"}]},
         "combineOperation": "any"}
    assert summarize_conditions(p) == "`n` is greater than `5` or `s` is empty"
    desc = describe_node({"type": "n8n-nodes-base.switch", "parameters": {
        "value1": "={{$json.kind}}", "rules": {"rules": [{"operation": "equal", "value2": "a", "output": 0},
                                                         {"operation": "equal", "value2": "b", "output": 1}]},
        "fallbackOutput": 2}})
    assert desc["outputs"] == ["If `kind` is equal to `a`", "If `kind` is equal to `b`", "Otherwise"]
    desc = describe_node({"type": "n8n-nodes-base.switch", "parameters": {"mode": "expression", "outputsAmount": 2}})
    assert desc["outputs"] == ["Output 1", "Output 2"]


def test_if_with_only_true_branch_connected():
    data = {"name": "x", "nodes": [
        {"name": "T", "type": "n8n-nodes-base.manualTrigger"},
        {"name": "Check", "type": "n8n-nodes-base.if", "parameters": {}},
        {"name": "Yes", "type": "n8n-nodes-base.noOp"},
    ], "connections": {"T": {"main": [[{"node": "Check"}]]}, "Check": {"main": [[{"node": "Yes"}]]}}}
    wf = parse_n8n(data)
    links = step_links(wf, "Check")
    assert links[1] == "Otherwise → stop here (nothing else happens on this path)"


def test_unknown_multi_output_node_gets_generic_labels():
    data = {"name": "x", "nodes": [
        {"name": "T", "type": "n8n-nodes-base.manualTrigger"},
        {"name": "Fork", "type": "community.forker"},
        {"name": "A", "type": "n8n-nodes-base.noOp"},
        {"name": "B", "type": "n8n-nodes-base.noOp"},
    ], "connections": {"T": {"main": [[{"node": "Fork"}]]}, "Fork": {"main": [[{"node": "A"}], [{"node": "B"}]]}}}
    wf = parse_n8n(data)
    assert step_links(wf, "Fork") == ["Output 1 → go to step 3 (A)", "Output 2 → go to step 4 (B)"]


def test_fan_out_from_one_output():
    data = {"name": "x", "nodes": [
        {"name": "T", "type": "n8n-nodes-base.manualTrigger"},
        {"name": "A", "type": "n8n-nodes-base.noOp"},
        {"name": "B", "type": "n8n-nodes-base.noOp"},
    ], "connections": {"T": {"main": [[{"node": "A"}, {"node": "B"}]]}}}
    wf = parse_n8n(data)
    assert step_links(wf, "T") == ["Next → steps 2 and 3 (A, B)"]


@pytest.mark.parametrize("ctype, expected", [
    ("slackApi", ("Slack", "SLACK_TOKEN")),
    ("openAiApi", ("OpenAI", "OPENAI_API_KEY")),
    ("pipedriveApi", ("Pipedrive", "PIPEDRIVE_API_KEY")),
    ("zoomOAuth2Api", ("Zoom", "ZOOM_OAUTH_TOKEN")),
    ("superScraperApi", ("Super Scraper", "SUPER_SCRAPER_API_KEY")),
])
def test_describe_credential(ctype, expected):
    assert describe_credential(ctype) == expected


def test_generic_credentials_named_after_account(secrets_file):
    (wf,) = load_workflows(secrets_file)
    envs = [(c.env_var, c.service) for c in collect_credentials(wf)]
    assert envs == [("WEBHOOK_GUARD_API_KEY", "API key sent in a header: Webhook Guard"),
                    ("ACME_API_KEY", "API key sent in a header: Acme API Key")]


def test_inputs_from_node_references_anywhere():
    data = {"name": "x", "nodes": [
        {"name": "Hook", "type": "n8n-nodes-base.webhook", "parameters": {"path": "p"}},
        {"name": "A", "type": "n8n-nodes-base.noOp", "parameters": {}},
        {"name": "B", "type": "n8n-nodes-base.slack", "parameters": {"text": "={{ $('Hook').item.json.body.city }} {{ $json.ignored }}"}},
    ], "connections": {"Hook": {"main": [[{"node": "A"}]]}, "A": {"main": [[{"node": "B"}]]}}}
    wf = parse_n8n(data)
    assert wf.inputs == ["city"]


def test_json_fixture_is_valid():
    json.loads((N8N / "lead_capture.json").read_text(encoding="utf-8"))
