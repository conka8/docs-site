import json
import re
import stat
import zipfile

import pytest
import yaml

from skillport import build_files, convert_file, convert_workflow, load_workflows, parse_n8n
from skillport.model import SkillportError
from skillport.render import build_description, render_inspect, render_readme, render_skill_md
from skillport.text import is_valid_skill_name
from skillport.writer import sanitize_source, unique_name

from conftest import MAKE, N8N, SECRETS, read_tree

CONVERTIBLE = sorted(
    [p for p in N8N.glob("*.json") if p.name not in ("malformed.json", "empty.json", "sticky_only.json")]
    + list(MAKE.glob("*.json"))
)


def split_frontmatter(text):
    m = re.match(r"^---\n(.*?)\n---\n(.*)$", text, re.S)
    assert m, "SKILL.md must start with a --- frontmatter block"
    return yaml.safe_load(m.group(1)), m.group(2)


@pytest.mark.parametrize("path", CONVERTIBLE, ids=lambda p: p.name)
@pytest.mark.parametrize("mode", ["skill", "bridge"])
def test_frontmatter_is_valid_for_every_fixture(path, mode, out):
    for res in convert_file(path, out, mode=mode):
        md = (res.folder / "SKILL.md").read_text(encoding="utf-8")
        meta, body = split_frontmatter(md)
        assert set(meta) == {"name", "description"}
        assert meta["name"] == res.name == res.folder.name
        assert is_valid_skill_name(meta["name"]) and len(meta["name"]) <= 64
        desc = meta["description"]
        assert isinstance(desc, str) and 0 < len(desc) <= 1024
        assert "Use when" in desc
        assert "<" not in desc and ">" not in desc and "\n" not in desc
        assert body.lstrip().startswith("# ")
        for section in ("## Overview", "## Required credentials / accounts", "## Inputs", "## Notes"):
            assert section in body
        assert ("## Steps" in body) if mode == "skill" else ("## How to run it" in body)


def test_lead_capture_skill_md_content():
    (wf,) = load_workflows(N8N / "lead_capture.json")
    md = render_skill_md(wf)
    meta, body = split_frontmatter(md)
    assert meta["name"] == "lead-capture-ai-scoring"
    assert meta["description"].startswith('Does the work of the "Lead Capture → AI Scoring 🚀" automation')
    assert len(meta["description"]) <= 200 and "Use when the user asks to run" in meta["description"]
    assert "- **Slack** (account in the original: \"Team Slack\"): set `SLACK_TOKEN`. Used by: Notify Sales." in body
    assert "OAuth login" in body  # Gmail / Sheets hint
    assert "- `email`" in body
    assert "4. **Hot Lead?**: Check whether `message.content.score` is greater than `70`." in body
    assert "   - If `message.content.score` is greater than `70` → go to step 5 (Notify Sales)" in body
    assert "   - Otherwise → go to step 6 (Send Nurture Email)" in body
    assert "> ## Setup" in body
    steps = body.split("## Steps")[1].split("## Notes")[0]
    assert [int(n) for n in re.findall(r"^(\d+)\. ", steps, re.M)] == list(range(1, 8))


def test_code_steps_include_the_code_block():
    (wf,) = load_workflows(N8N / "schedule_http_code.json")
    md = render_skill_md(wf)
    assert "     ```javascript\n     const p = $input.first().json;" in md
    assert "No input needed. The original workflow ran automatically every day at 09:30" in md
    assert "- **Telegram bot**" in md


def test_no_credentials_and_no_notes_texts():
    (wf,) = load_workflows(N8N / "pure_cycle.json")
    md = render_skill_md(wf)
    assert "None. This workflow does not log in to any outside service." in md
    (wf,) = load_workflows(MAKE / "watch_trigger.json")
    md = render_skill_md(wf)
    assert "No notes in the original workflow." in md
    assert "started when something new happened in Google Sheets" in md


def test_unicode_workflow_output(out):
    (res,) = convert_file(N8N / "unicode.json", out)
    md = (res.folder / "SKILL.md").read_text(encoding="utf-8")
    meta, body = split_frontmatter(md)
    assert "claude" not in meta["name"]
    assert "🤖 Résumé" in meta["description"] and "<b>" not in meta["description"]
    assert "# 🤖 Résumé Ünïcödé — 日本語" in body
    assert "**Café ☕ step**" in body
    (res,) = convert_file(N8N / "japanese_only.json", out)
    assert res.name.startswith("workflow-")


def test_long_name_and_description_are_capped():
    data = {"name": "Very long " * 200, "nodes": [{"name": "T", "type": "n8n-nodes-base.manualTrigger"}]}
    wf = parse_n8n(data)
    desc = build_description(wf)
    assert len(desc) <= 200 and "Use when" in desc and "Very long Very long Very..." in desc
    meta, _ = split_frontmatter(render_skill_md(wf))
    assert len(meta["name"]) <= 64 and len(meta["description"]) <= 200


def test_readme_for_members():
    (wf,) = load_workflows(N8N / "lead_capture.json")
    text = render_readme(wf, "lead-capture", brand="Jack's Academy", brand_url="https://example.com/academy")
    assert "~/.claude/skills/lead-capture/" in text
    assert 'export SLACK_TOKEN="paste-your-key-here"' in text
    assert "**OpenAI** account" in text
    assert text.rstrip().endswith("Converted with [Jack's Academy](https://example.com/academy).")
    (wf,) = load_workflows(N8N / "cycle.json")
    plain = render_readme(wf, "retry")
    assert "No accounts needed." in plain and "Loop found" in plain
    assert plain.rstrip().endswith("Converted with skillport.")


def test_inspect_text():
    (wf,) = load_workflows(N8N / "branch_merge.json")
    text = render_inspect(wf)
    assert "Workflow: Support Ticket Router  (n8n)" in text
    assert "  2. By Priority: Choose a path" in text
    assert "Otherwise -> go to step 5 (Ask Triage)" in text
    assert "  - Slack: SLACK_TOKEN  (used by: Page On-Call, Ask Triage)" in text
    (wf,) = load_workflows(N8N / "empty.json")
    assert "Steps: none" in render_inspect(wf)


# ---------------------------------------------------------------- files, zip, source


def test_skill_folder_files(out):
    (res,) = convert_file(N8N / "lead_capture.json", out)
    assert res.folder == out / "lead-capture-ai-scoring"
    assert res.files == ["README.md", "SKILL.md", "source/workflow.json"]
    for f in res.files:
        assert (res.folder / f).is_file()
    assert res.zip_path is None and not list(out.glob("*.zip"))


def test_source_json_is_sanitized(out):
    (res,) = convert_file(N8N / "lead_capture.json", out)
    src = json.loads((res.folder / "source" / "workflow.json").read_text(encoding="utf-8"))
    assert "pinData" not in src
    assert "instanceId" not in src["meta"]
    creds = [n["credentials"] for n in src["nodes"] if "credentials" in n]
    assert creds and all(set(c[k]) == {"name"} for c in creds for k in c)
    text = json.dumps(src)
    for cred_id in ("Xyz123OpenAI", "SlackCred99", "GmailCred77", "SheetsCred55"):
        assert cred_id not in text
    assert "real.customer@example.com" not in text
    assert src["nodes"][0]["parameters"]["path"] == "lead-capture", "the rest of the workflow is kept"


def test_make_source_strips_connection_ids():
    (wf,) = load_workflows(MAKE / "lead_router.json")
    src = sanitize_source(wf.raw, "make")
    text = json.dumps(src)
    assert "3141592" not in text and "845123" not in text
    assert "MAKESECRETTOKEN999" not in text
    assert wf.raw["flow"][1]["parameters"]["__IMTCONN__"] == 3141592, "original data untouched"


def test_zip_output(out):
    (res,) = convert_file(N8N / "lead_capture.json", out, make_zip=True)
    assert res.zip_path == out / "lead-capture-ai-scoring.zip"
    with zipfile.ZipFile(res.zip_path) as zf:
        assert sorted(zf.namelist()) == ["lead-capture-ai-scoring/README.md", "lead-capture-ai-scoring/SKILL.md",
                                         "lead-capture-ai-scoring/source/workflow.json"]
        assert zf.read("lead-capture-ai-scoring/SKILL.md").decode() == (res.folder / "SKILL.md").read_text(encoding="utf-8")
        assert zf.testzip() is None


def test_zip_bridge_keeps_script_executable(out):
    (res,) = convert_file(N8N / "lead_capture.json", out, mode="bridge", make_zip=True)
    with zipfile.ZipFile(res.zip_path) as zf:
        info = zf.getinfo("lead-capture-ai-scoring/scripts/call_webhook.py")
        assert (info.external_attr >> 16) & 0o111
        assert zf.read(info).startswith(b"#!/usr/bin/env python3")
    mode = (res.folder / "scripts" / "call_webhook.py").stat().st_mode
    assert mode & stat.S_IXUSR


@pytest.mark.parametrize("mode", ["skill", "bridge"])
def test_no_secret_reaches_any_output(secrets_file, out, mode):
    (res,) = convert_file(secrets_file, out, mode=mode, make_zip=True)
    text = read_tree(res.folder)
    with zipfile.ZipFile(res.zip_path) as zf:
        text += "\n".join(zf.read(n).decode() for n in zf.namelist())
    for name, secret in SECRETS.items():
        assert secret not in text, f"{name} secret leaked"
    for cred_id in ("hh1-CRED-ID", "hh2-CRED-ID"):
        assert cred_id not in text
    assert "real.person@example.com" not in text
    assert "static-" not in text
    assert "[REDACTED]" in text
    if mode == "skill":
        md = (res.folder / "SKILL.md").read_text(encoding="utf-8")
        assert "- `greeting` = hello" in md, "non-secret values are kept"
        assert "Content-Type: application/json" in md


def test_build_files_errors():
    (wf,) = load_workflows(N8N / "empty.json")
    with pytest.raises(SkillportError, match="has no steps"):
        build_files(wf)
    (wf,) = load_workflows(N8N / "cycle.json")
    with pytest.raises(SkillportError, match="Unknown mode"):
        build_files(wf, mode="magic")


def test_unique_names(out):
    taken = set()
    assert unique_name("a", taken) == "a"
    assert unique_name("a", taken) == "a-2"
    assert unique_name("a", taken) == "a-3"
    long = "x" * 64
    assert unique_name(long, taken) == long
    second = unique_name(long, taken)
    assert len(second) <= 64 and second.endswith("-2")
    (wf,) = load_workflows(N8N / "cycle.json")
    taken = set()
    r1 = convert_workflow(wf, out, taken=taken)
    r2 = convert_workflow(wf, out, taken=taken)
    assert (r1.name, r2.name) == ("retry-until-done", "retry-until-done-2")
    meta, _ = split_frontmatter((r2.folder / "SKILL.md").read_text(encoding="utf-8"))
    assert meta["name"] == "retry-until-done-2"


def test_reconvert_overwrites(out):
    convert_file(N8N / "cycle.json", out)
    (res,) = convert_file(N8N / "cycle.json", out)
    assert (res.folder / "SKILL.md").is_file()
