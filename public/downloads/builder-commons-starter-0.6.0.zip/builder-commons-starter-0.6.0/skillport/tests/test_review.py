import json
from pathlib import Path

from skillport.cli import main
from skillport.loader import load_workflows, parse_data
from skillport.render import render_inspect, render_readme, render_skill_md
from skillport.bridge import render_bridge_skill_md
from skillport.review import REVIEW_MARKER, review_items

from conftest import MAKE, N8N

EXAMPLES = Path(__file__).parent.parent / "examples"


def wf_of(path):
    return load_workflows(path)[0]


def n8n(nodes, connections=None, settings=None):
    data = {"name": "Review Me", "nodes": nodes, "connections": connections or {}}
    if settings is not None:
        data["settings"] = settings
    return parse_data(data, "review.json")[0]


TRIGGER = {"name": "Start", "type": "n8n-nodes-base.manualTrigger", "parameters": {}}


def chain(*names):
    return {a: {"main": [[{"node": b, "type": "main", "index": 0}]]} for a, b in zip(names, names[1:])}


def test_schedule_and_code_are_flagged():
    items = review_items(wf_of(N8N / "schedule_http_code.json"))
    assert any("ran on a schedule (every day at 09:30)" in i for i in items)
    assert any('Step 3 ("Format Digest") runs custom code' in i for i in items)


def test_unknown_node_and_ai_agent_are_flagged():
    items = review_items(wf_of(N8N / "unknown_and_agent.json"))
    assert any("superScraper9000" in i and "can't describe" in i for i in items)
    assert any("asks an AI model" in i for i in items)


def test_loop_is_flagged():
    items = review_items(wf_of(N8N / "cycle.json"))
    assert any(i.startswith("Some steps repeat in a loop") for i in items)


def test_error_handling_retries_subworkflow_and_error_workflow():
    wf = n8n([
        TRIGGER,
        {"name": "Fetch", "type": "n8n-nodes-base.httpRequest", "parameters": {"url": "https://example.com"},
         "retryOnFail": True, "maxTries": 5, "onError": "continueRegularOutput"},
        {"name": "Child", "type": "n8n-nodes-base.executeWorkflow", "parameters": {"workflowId": "42"}},
    ], chain("Start", "Fetch", "Child"), settings={"errorWorkflow": "99"})
    items = review_items(wf)
    assert any('Step 2 ("Fetch") keeps going in n8n when it fails' in i for i in items)
    assert any("retries up to 5 times" in i for i in items)
    assert any('Step 3 ("Child") calls another n8n workflow' in i for i in items)
    assert any("separate error workflow" in i for i in items)


def test_logic_expressions_are_flagged_but_plain_references_are_not():
    plain = n8n([TRIGGER, {"name": "Set", "type": "n8n-nodes-base.set",
                           "parameters": {"values": {"string": [{"name": "a", "value": "={{ $json.email }}"}]}}}],
                chain("Start", "Set"))
    assert review_items(plain) == []
    logic = n8n([TRIGGER, {"name": "Set", "type": "n8n-nodes-base.set",
                           "parameters": {"values": {"string": [
                               {"name": "a", "value": "={{ $json.score > 70 ? 'hot' : 'cold' }}"},
                               {"name": "b", "value": "={{ $now.toFormat('yyyy') }}"}]}}}],
                chain("Start", "Set"))
    items = review_items(logic)
    assert len(items) == 1 and "computes values with expressions" in items[0] and "(and 1 more)" in items[0]


def test_make_error_handler_is_flagged():
    data = json.loads((MAKE / "lead_router.json").read_text(encoding="utf-8"))
    data["flow"][0]["onerror"] = [{"id": 99, "module": "builtin:Ignore"}]
    wf = parse_data(data, "make.json")[0]
    assert any("Make.com error handler" in i for i in review_items(wf))


def test_bridge_items():
    wf = wf_of(N8N / "lead_capture.json")
    items = review_items(wf, "bridge", "https://n8n.example.com/webhook-test/lead")
    assert any("answers as soon as it receives data" in i for i in items)
    assert any("n8n test URL" in i for i in items)
    assert any("network access" in i for i in items)
    assert not any("runs custom code" in i for i in items)  # the workflow still runs in n8n


def test_bridge_auth_header_hints():
    def hook(auth):
        return n8n([{"name": "Hook", "type": "n8n-nodes-base.webhook",
                     "parameters": {"path": "x", "authentication": auth, "responseMode": "lastNode"}}])
    assert any("Authorization: Basic" in i for i in review_items(hook("basicAuth"), "bridge"))
    assert any("Authorization: Bearer" in i for i in review_items(hook("jwtAuth"), "bridge"))
    items = review_items(hook("headerAuth"), "bridge")
    assert any("Header-Name: value" in i for i in items)
    assert not any("answers as soon as" in i for i in items)


def test_section_and_marker_in_every_output():
    wf = wf_of(N8N / "schedule_http_code.json")
    md = render_skill_md(wf)
    assert "## Conversion check" in md and REVIEW_MARKER in md
    assert md.index("## Conversion check") < md.index("## Steps")
    assert "does not run the original automation engine" in md
    assert "Conversion check" in render_readme(wf, "x")
    assert "Check before sharing (2):" in render_inspect(wf)
    bridge = render_bridge_skill_md(wf, None)
    assert "## Conversion check" in bridge and REVIEW_MARKER in bridge


def test_nothing_flagged_still_asks_for_a_test_run():
    wf = n8n([TRIGGER])
    md = render_skill_md(wf)
    assert "Nothing was flagged. Still run it once on test data" in md
    assert "Check before sharing: nothing flagged" in render_inspect(wf)


def test_whole_field_expression_is_shown_as_a_reference_not_literal_text():
    md = render_skill_md(wf_of(N8N / "schedule_http_code.json"))
    assert "Message: the value of `text`" in md
    assert 'Message: "text"' not in md


def test_cli_reports_review_counts(tmp_path, capsys):
    assert main(["convert", str(N8N / "schedule_http_code.json"), "-o", str(tmp_path)]) == 0
    assert "Check before sharing: 2 item(s)" in capsys.readouterr().out
    assert main(["inspect", str(N8N / "schedule_http_code.json"), "--format", "json"]) == 0
    assert len(json.loads(capsys.readouterr().out)["review"]) == 2


def test_bundled_examples_convert(tmp_path, capsys):
    assert main(["batch", str(EXAMPLES), "-o", str(tmp_path)]) == 0
    out = capsys.readouterr().out
    assert "FAILED" not in out and "to check" in out
