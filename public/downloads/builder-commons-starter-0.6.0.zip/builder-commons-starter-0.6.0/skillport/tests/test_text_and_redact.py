import pytest
import yaml

from skillport.redact import REDACTED, contains_secret, is_secret_key, redact, redact_text
from skillport.text import (
    humanize,
    is_valid_skill_name,
    iter_strings,
    json_refs,
    node_refs,
    one_line,
    pretty_expr,
    resource_name,
    slugify,
    truncate,
    yaml_quote,
)

from conftest import SECRETS


# ---------------------------------------------------------------- slugify


@pytest.mark.parametrize(
    "text, expected",
    [
        ("Lead Capture", "lead-capture"),
        ("  Lead   Capture!!  ", "lead-capture"),
        ("Résumé Builder", "resume-builder"),
        ("AI -> CRM (v2)", "ai-crm-v2"),
        ("Claude Content Bot", "content-bot"),
        ("My ANTHROPIC helper", "my-helper"),
        ("already-a-slug", "already-a-slug"),
        ("UPPER_snake_case", "upper-snake-case"),
        ("🚀 Launch 🚀", "launch"),
    ],
)
def test_slugify(text, expected):
    assert slugify(text) == expected
    assert is_valid_skill_name(slugify(text))


def test_slugify_non_latin_gets_stable_hash_name():
    a = slugify("リード獲得")
    assert a.startswith("workflow-") and len(a) == len("workflow-") + 8
    assert a == slugify("リード獲得")
    assert a != slugify("別のワークフロー")
    assert is_valid_skill_name(a)


def test_slugify_empty_and_reserved_only():
    assert slugify("").startswith("workflow-")
    assert slugify("claude").startswith("workflow-")


def test_slugify_long_names_cut_at_word_boundary():
    name = " ".join(["automation"] * 20)
    slug = slugify(name)
    assert len(slug) <= 64
    assert not slug.endswith("-")
    assert all(part == "automation" for part in slug.split("-"))
    long_word = "x" * 100
    assert slugify(long_word) == "x" * 64


def test_is_valid_skill_name():
    assert is_valid_skill_name("abc-123")
    for bad in ("", "Abc", "a--b", "-a", "a-", "a_b", "claude-x", "x" * 65):
        assert not is_valid_skill_name(bad), bad


# ---------------------------------------------------------------- expressions


@pytest.mark.parametrize(
    "expr, expected",
    [
        ("={{ $json.body.email }}", "body.email"),
        ("={{$json[\"status\"]}}", "status"),
        ("=Hi {{ $json.name }}!", "Hi {name}!"),
        ("={{ $('Normalize Lead').item.json.email }}", 'email (from "Normalize Lead")'),
        ("={{ $node[\"Webhook\"].json[\"body\"] }}", 'body (from "Webhook")'),
        ("plain text", "plain text"),
        (70, "70"),
        (None, ""),
    ],
)
def test_pretty_expr(expr, expected):
    assert pretty_expr(expr) == expected


def test_refs():
    s = "={{ $json.body.email }} {{ $('Hook').item.json.body.name }} {{ $node['Hook'].json.x }}"
    assert json_refs(s) == ["body.email"]
    assert node_refs(s) == [("Hook", "body.name"), ("Hook", "x")]


def test_small_helpers():
    assert humanize("addRow") == "add row"
    assert humanize("send_message-now") == "send message now"
    assert truncate("abcdef", 5) == "ab..."
    assert truncate("abc", 5) == "abc"
    assert one_line("a\n\n b   c") == "a b c"
    assert list(iter_strings({"a": ["x", {"b": "y"}], "c": 1})) == ["x", "y"]
    assert resource_name({"__rl": True, "value": "id1", "cachedResultName": "Leads"}) == "Leads"
    assert resource_name({"value": "id1"}) == "id1"
    assert resource_name("={{ $json.x }}") == "x"
    assert resource_name({}) == ""


@pytest.mark.parametrize(
    "text",
    ['plain', 'with "quotes" and \\ backslash', "new\nline\ttab", "emoji 🚀 and 日本語", "ctrl \x01 \x7f",
     "line sep   x", "colon: and # hash"],
)
def test_yaml_quote_round_trips(text):
    assert yaml.safe_load(f"k: {yaml_quote(text)}")["k"].replace(" ", "\n") == text.replace(" ", "\n")


# ---------------------------------------------------------------- redaction


@pytest.mark.parametrize("key", ["apiKey", "api_key", "X-API-Key", "Authorization", "password", "client_secret",
                                 "accessToken", "token", "refresh_token", "privateKey", "Cookie", "auth"])
def test_secret_keys(key):
    assert is_secret_key(key)


@pytest.mark.parametrize("key", ["authentication", "maxTokens", "max_tokens", "name", "url", "sendTo", "tokenType2x",
                                 "keyboard", ""])
def test_not_secret_keys(key):
    assert not is_secret_key(key)


@pytest.mark.parametrize("name", ["openai", "aws", "github", "slack", "anthropic", "live"])
def test_redact_text_patterns(name):
    secret = SECRETS[name]
    out = redact_text(f"value is {secret} ok")
    assert secret not in out and REDACTED in out and out.startswith("value is ")
    assert contains_secret(secret)


def test_redact_text_other_patterns():
    pem = "-----BEGIN PRIVATE KEY-----\nabc\n-----END PRIVATE KEY-----"
    assert redact_text(pem) == REDACTED
    assert redact_text("Authorization: Bearer abcdefghijklmnop123") == "Authorization: Bearer " + REDACTED
    assert redact_text("https://x.com/a?api_key=SECRET1&mode=1") == f"https://x.com/a?api_key={REDACTED}&mode=1"
    assert redact_text("https://user:pa55word@db.example.com/x") == f"https://{REDACTED}@db.example.com/x"
    assert redact_text("AIza" + "B" * 35) == REDACTED
    assert redact_text("plain text, nothing here") == "plain text, nothing here"
    assert redact_text("") == ""
    assert not contains_secret("hello world")


def test_redact_structures():
    data = {
        "headerParameters": {"parameters": [
            {"name": "Authorization", "value": "Basic xyz"},
            {"name": "X-Api-Key", "value": "not-pattern-value"},
            {"name": "Accept", "value": "application/json"},
        ]},
        "apiKey": "abc",
        "options": {"maxTokens": 300, "password": 12345678},
        "authentication": "headerAuth",
        "empty_token": "",
        "list": ["fine", SECRETS["openai"]],
        "keep_bool": True,
    }
    out = redact(data)
    params = out["headerParameters"]["parameters"]
    assert params[0]["value"] == REDACTED and params[1]["value"] == REDACTED
    assert params[2]["value"] == "application/json"
    assert out["apiKey"] == REDACTED
    assert out["options"] == {"maxTokens": 300, "password": REDACTED}
    assert out["authentication"] == "headerAuth"
    assert out["empty_token"] == ""
    assert out["list"] == ["fine", REDACTED]
    assert out["keep_bool"] is True
    assert data["apiKey"] == "abc", "redact must not change its input"
