"""The single-file web page: its JS core is run with Node (skipped if node is not installed)."""

import json
import re
import shutil
import subprocess
from pathlib import Path

import pytest
import yaml

from conftest import MAKE, N8N, SECRETS, secrets_workflow

WEB = Path(__file__).parent.parent / "web" / "index.html"
NODE = shutil.which("node")
needs_node = pytest.mark.skipif(NODE is None, reason="node is not installed")


def core_js() -> str:
    html = WEB.read_text(encoding="utf-8")
    m = re.search(r"// BEGIN CORE\n(.*?)// END CORE", html, re.S)
    assert m, "web/index.html must keep its converter between // BEGIN CORE and // END CORE"
    return m.group(1)


def run_web(tmp_path, workflow_text: str) -> dict:
    (tmp_path / "input.json").write_text(workflow_text, encoding="utf-8")
    harness = tmp_path / "harness.js"
    harness.write_text(
        core_js()
        + "\nconst fs = require('fs');\n"
        + "try { const r = SkillportWeb.convert(fs.readFileSync(process.argv[2], 'utf8'));\n"
        + "  process.stdout.write(JSON.stringify({ok: true, result: r})); }\n"
        + "catch (e) { process.stdout.write(JSON.stringify({ok: false, error: e.message})); }\n",
        encoding="utf-8",
    )
    proc = subprocess.run([NODE, str(harness), str(tmp_path / "input.json")], capture_output=True, text=True,
                          timeout=60)
    assert proc.returncode == 0, proc.stderr
    return json.loads(proc.stdout)


def frontmatter(md):
    m = re.match(r"^---\n(.*?)\n---\n", md, re.S)
    assert m
    return yaml.safe_load(m.group(1))


def test_page_is_self_contained():
    html = WEB.read_text(encoding="utf-8")
    assert "<title>n8n to Skill</title>" in html
    assert not re.search(r"<script[^>]+src=", html), "no external scripts"
    assert "fetch(" not in html and "XMLHttpRequest" not in html, "workflow never leaves the browser"
    assert "prefers-color-scheme: dark" in html


@needs_node
def test_web_converts_lead_capture(tmp_path):
    res = run_web(tmp_path, (N8N / "lead_capture.json").read_text(encoding="utf-8"))
    assert res["ok"], res
    r = res["result"]
    assert r["name"] == "lead-capture-ai-scoring"
    assert r["steps"] == ["Lead Webhook", "Normalize Lead", "Score Lead", "Hot Lead?", "Notify Sales",
                          "Send Nurture Email", "Log to Sheet"]
    md = r["skillMd"]
    meta = frontmatter(md)
    assert meta["name"] == "lead-capture-ai-scoring"
    assert "Use when" in meta["description"] and len(meta["description"]) <= 1024
    assert "   - If `message.content.score` is greater than `70` → go to step 5 (Notify Sales)" in md
    assert "   - Otherwise → go to step 6 (Send Nurture Email)" in md
    assert "- **Slack**: set `SLACK_TOKEN`. Used by: Notify Sales." in md
    assert "> ## Setup" in md


@needs_node
def test_web_matches_python_on_order_and_credentials(tmp_path):
    from skillport import load_workflows
    from skillport.credentials import collect_credentials
    for name in ("branch_merge.json", "cycle.json", "disabled_nodes.json", "schedule_http_code.json"):
        (wf,) = load_workflows(N8N / name)
        res = run_web(tmp_path, (N8N / name).read_text(encoding="utf-8"))["result"]
        assert res["steps"] == [wf.nodes[n].name for n in wf.steps], name
        assert [c["env"] for c in res["credentials"]] == [c.env_var for c in collect_credentials(wf)], name


@needs_node
def test_web_redacts_secrets(tmp_path):
    res = run_web(tmp_path, json.dumps(secrets_workflow()))
    md = res["result"]["skillMd"]
    for name, secret in SECRETS.items():
        assert secret not in md, name
    assert "[REDACTED]" in md


@needs_node
def test_web_cycle_and_unicode(tmp_path):
    res = run_web(tmp_path, (N8N / "cycle.json").read_text(encoding="utf-8"))["result"]
    assert any(w.startswith("Loop found: Check Status -> Is Done? -> Wait a bit -> Check Status") for w in res["warnings"])
    assert "Then go back to step 2 (Check Status) (this repeats)" in res["skillMd"]
    res = run_web(tmp_path, (N8N / "unicode.json").read_text(encoding="utf-8"))["result"]
    meta = frontmatter(res["skillMd"])
    assert meta["name"] == "resume-unicode-quoted-b-bold-b-helper"
    assert "<" not in meta["description"]


@needs_node
@pytest.mark.parametrize("text, message", [
    ("{oops", "not valid JSON"),
    ('{"hello": 1}', "not an n8n workflow"),
    ((N8N / "empty.json").read_text(encoding="utf-8"), "has no steps"),
    ((MAKE / "lead_router.json").read_text(encoding="utf-8"), "Make.com blueprint"),
])
def test_web_errors(tmp_path, text, message):
    res = run_web(tmp_path, text)
    assert not res["ok"] and message in res["error"]
