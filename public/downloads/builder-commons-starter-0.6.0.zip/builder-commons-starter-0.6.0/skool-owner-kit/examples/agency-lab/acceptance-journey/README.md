# Member acceptance journey

From the released download to a member finishing a task, then again after an update. Each step says what was
verified, how, and where. "Verified" is used only for steps that ran.

| # | Step | How it was checked | Status |
|---|---|---|---|
| 1 | Obtain the distributed package | `scripts/acceptance_journey.py`: starter bundle checked against `manifest.json` (sha256) and unzipped | **Verified locally** |
| 2 | Install the tools as the admin guide says | fresh virtual environment, `pip install` from the bundle | **Verified locally** |
| 3 | Build, check and share the pack | the commands in the pack's `ADMIN-REVIEW.md`, run as written: `pack-build`, `skillkit lint --strict`, replay of saved outputs, `pack-share` | **Verified locally** (the replay re-checks saved outputs; it is not a model run) |
| 4 | Install as a member | the Claude Code commands in `START-HERE.md`, run as written with `HOME` pointed at a sandbox; `unzip` was emulated with Python's zipfile where the `unzip` program isn't installed | **Verified locally for Claude Code's folder layout.** Claude app upload **not verified** |
| 5 | Confirm the skills are available | each installed skill has SKILL.md, a name matching its folder, a description within the Claude app's 200-character limit, and working links | **Verified locally** (files only) |
| 5b | Claude picks the right skill from realistic language | a fresh model session given only the installed names and descriptions, asked which it would load for 8 member messages | **Simulated** (`journey-select-v1.md`, `-v2.md`). Real discovery in Claude Code or the app **not verified** |
| 6 | Complete a task with referenced lessons and an editable deliverable | the C runs in `../benchmark/` used the installed copies | **Actual model execution in Claude Code**, single turn, told which skill applied |
| 7 | Check citations, constraints, missing information, escalation | blind grading in `../benchmark/grades/` | Done for 6 cases; defects found and listed there |
| 8 | Update: lesson changes, admin keeps their own edit, members reinstall | script step 6: `pack-build` keeps the edit and writes `.new`, `pack-share` refuses until merged, version 1.0.1 shared and reinstalled with the same commands | **Verified locally** |
| 9 | The update reaches the member | files: the installed offer skill and its lesson say "never below 350"; model: `journey-update-tutor.md` answers "350" and carries the admin's own line; `journey-update-offer.md` prices inside 350-500 | **Verified locally + actual model execution** (Claude Code) |

`local-record.md` is the latest output of the script. Re-run it with:

```bash
python3 scripts/package_tools.py
python3 scripts/acceptance_journey.py --record skool-owner-kit/examples/agency-lab/acceptance-journey/local-record.md
```

## How the model runs were supplied and executed

Every model run here, in `../benchmark/` and in `../live-runs/`, was a Claude Code subagent (Claude Agent SDK) with
model alias `sonnet`, started fresh for one reply. It was given the path to an installed skill folder and told to read
`SKILL.md` in full, follow it, read only the reference files inside that folder, and reply to one member message in one
turn. The skill was **not** loaded by Claude Code's own skill system, and the subagent was told which skill applied.
Prompts are quoted verbatim in `../benchmark/README.md`.

Known harness limits:
- No skill discovery: step 5b is a simulation from names and descriptions.
- Single turn: a member can't answer the skill's questions.
- These subagents inherit the operator's Claude Code memory (two replies mention the operator's city, one their hourly
  rate). A clean member account wouldn't have this.
- Not the Claude app: upload, the switch to turn a skill on, and the app's code-execution environment are untested.

## Skill selection (simulated)

The same 8 messages, before and after the tutor's description was changed. Expectations written after v1 ran:
1 and 2 could reasonably load either of two skills; the rest have one right answer.

| # | Message | v1 | v2 |
|---|---|---|---|
| 1 | What should I charge my first client? | offer-builder | offer-builder |
| 2 | someone opened my loom but didn't reply... | outreach-sprint | outreach-sprint |
| 3 | physio clinics or car garages... put my offer together? | offer-builder | offer-builder |
| 4 | here's my offer... can you write my messages? | outreach-sprint | outreach-sprint |
| 5 | Do I need to register as a limited company? (not covered) | **none**: no coach question | tutor |
| 6 | birthday message for my sister | none | none |
| 7 | what's the 3 filter thing again? | tutor | tutor |
| 8 | which lesson covers the discovery call? | tutor | tutor |

v1 missed the case that matters most for support load: a question the lessons don't cover got no skill, so no
question for a coach. The tutor's description now says it handles "what the lessons don't cover"; v2 loaded it for #5
and still loaded nothing for #6.

## Still manual: the Claude app (needs a Claude account)

Not run: no Claude app account was available. Until it is, the site says the Claude app is untested, and the offer
says members get nothing until the customer's own acceptance cases pass in their members' Claude surface.

Do it once on our own account before the first pilot, then for each customer in their members' surface. Record
everything in `app-record-template.md` (copy it per run) and one row per case in `member-pack/pilot/acceptance.csv`.

**A. Skills**

1. Download the exact release (`builder-commons-starter-<version>.zip`), check its sha256 against `manifest.json`,
   install skool-owner-kit from it, and run `skool-kit pack-share member-pack -o share --version 1.0.0`.
2. On the plan members use, follow `share/<prefix>-member-kit-1.0.0/START-HERE.md` exactly as written. Note every
   step that didn't match what you saw, and any error message from the upload.
3. In a **new chat**, without naming a skill, send each message from the selection table above. Record which skill
   Claude used, as the app shows it. Count a case as **automatic activation** only when you didn't name the skill.
4. Run each acceptance case from `member-pack/ADMIN-REVIEW.md` in a new chat and answer the skill's questions as a
   member would, for at least two turns on the offer task (use the scripted turns in `../comparison/CASES.md`, O3 and
   H2).
5. Check citations: copy each reply into a file and run `skool-kit check-citations reply.md --skills member-pack`.
   Then read each cited sentence: does it support the point?
6. Uncovered question (T2 or H3) and conflicting input (O2): it must say what isn't covered, keep its own suggestions
   labelled, and name the conflicts.
7. Update: change a lesson (for example the 300 floor to 350), rebuild, share 1.0.1, delete and re-upload the skills,
   and ask the pricing question again in a new chat. It must answer 350.

**B. Claude Project.** The same steps with `share/<prefix>-claude-project-1.0.0/START-HERE.md`: create the project,
paste the instructions, add the files, and run steps 3 to 7 inside the project. For the update, replace the
instructions and the changed files.

Pass for launch: every case the owner approved passes, in the format the members will use, with no step of
START-HERE.md needing a correction. Anything else is a documented exception the owner accepts in writing, or no
launch.
