# Claude app acceptance record (copy per run)

| | |
|---|---|
| Date and time (UTC) | |
| Who ran it | |
| Account plan | Free / Pro / Max / Team / Enterprise |
| Surface | claude.ai web / desktop app (OS) / mobile |
| Format | skills / Claude Project |
| Model shown in the app | |
| Release tested | starter bundle version and sha256; kit or project zip name and sha256 |
| Code execution setting | on / off / not offered |

## Install

| Step in START-HERE.md | Worked as written? | What you saw instead, or the error |
|---|---|---|
| | | |

## Cases

| Case | Turns | Named the skill? (yes = not automatic) | Skill or project used | Citations verified (check-citations) | Cited sentence supports the point? | Pass? | Interventions (anything you did beyond the scripted member turns) |
|---|---|---|---|---|---|---|---|
| | | | | | | | |

Save each conversation as text next to this record (`<case>-<format>.md`), unedited.

## Update

| | |
|---|---|
| Lesson change | |
| Version shared | |
| How members updated | |
| Pricing question answered with the new value? | |

## Failures and follow-ups

- 
