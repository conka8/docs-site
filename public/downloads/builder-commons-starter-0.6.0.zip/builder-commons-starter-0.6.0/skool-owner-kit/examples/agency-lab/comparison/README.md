# Comparison: the reviewed pack as skills vs as a Claude Project

**Question:** given the same reviewed lessons and instructions, is distributing them as installed skills better
for members than one Claude Project, the simplest strong alternative a member can set up?
**Answer from these 8 cases:** no. The Project version did at least as well on following the lessons and was
preferred by the blind grader in 5 of 8 cases (skills 2, 1 tie). The skill kit's two lower scores come from
the format: a task skill only carries its own task's lessons. On answer quality the skill kit has no measured
advantage over the Project. Its advantages are elsewhere: it works in any chat without opening a project, works in
Claude Code, and Team or Enterprise owners can provision it to everyone (and update it centrally).

Exploratory evidence: 8 cases, one synthetic community, one model, one grader per case. Not a general benchmark.

## Version tested (final)

| | |
|---|---|
| Pack | `examples/agency-lab/pack.yaml` built by skool-owner-kit with the citation, source-labelling and "?" rules: skool-owner-kit 0.6.0 before the fixes listed under "Defects found" |
| Skill kit | `northwind-member-kit-1.0.1.zip`, sha256 `292417b2d54eca3e9023effc1713ae6be2291e25a3943ee2b644bf5a3858986a`, unzipped as START-HERE.md says |
| Project | `northwind-claude-project-1.0.1.zip`, sha256 `a22df2bf0559bdcaa9ed6f03cd751fd2ac3052ed1f2087ed1a32456330e298ba`, from the same `pack-share` run |
| Model | `claude-sonnet-5-5` (alias "sonnet") for every conversation; graders `claude-opus-5-5` |
| Date | 2026-10-30, 00:55 to 01:10 UTC |

After this run, four defects it found were fixed in the generator and the example spec (see "Defects found"); those
fixes were **not** re-run. The `-1.0.1` kits above are what was tested.

## Conditions

| | Project (P) | Skill kit (K) |
|---|---|---|
| What the model got | The project instructions (`INSTRUCTIONS.md`, verbatim) and read access to the project's 15 files: all 8 lessons, one task guide per skill, the worked examples | The 3 installed skills' names and descriptions only; it decided itself which skill applied, then read that skill's `SKILL.md` and files |
| Source material | The same files: each task guide is that skill's `SKILL.md` body | |
| Turns | 1 to 3, with the member's later turns scripted in advance and identical for both (`CASES.md`) | same |

Skill choice: K chose a skill in all 12 of its turns, never "none" (offer-builder 8, outreach-sprint 2, tutor 2). This is a model choosing from names and descriptions inside the harness, not the Claude app's own skill
loading.

## Results (blind, `grades/`)

| | Project | Skill kit |
|---|---|---|
| Lesson rules applied correctly (0-2, mean) | 1.88 | 1.75 |
| Unknown facts shown as unknown (0-2) | 1.75 | 2.00 |
| Lessons, member and own suggestions kept apart (0-2) | 1.88 | 2.00 |
| Clarification across turns (0-2) | 2.00 | 2.00 |
| Usable deliverable by the end (0-2) | 2.00 | 1.88 |
| Citations judged supported by the grader | 58 of 61 | 43 of 45 |
| Unsupported claims (total) | 1 | 2 |
| Conflicts with the lessons named, where present | 5 of 5 | 5 of 5 |
| Grader's preferred conversation (8 cases) | 5 | 2 (and 1 tie) |

`skool-kit check-citations` (mechanical): every quoted passage in all 16 conversations exists in the lesson it
names; 0 "passage not found". 4 skill-kit citations named a lesson with the quote placed outside the checkable
format, so they couldn't be checked.

Per case, lesson rules (Project / Skill kit) and the grader's preference:

| Case | Rules | Preferred |
|---|---|---|
| T1 | 2 / 2 | Skill kit |
| T2 | 2 / 2 | Project |
| O2 | 2 / 2 | Project |
| O3 | 2 / 1 | Project |
| H1 | 2 / 2 | Skill kit |
| H2 | 2 / 2 | Project |
| H3 | 2 / 2 | tie |
| H4 | 1 / 1 | Project |

## Defects found, and what was done

| Defect | Seen in | Cause | Fix (not re-run) |
|---|---|---|---|
| Told the member "the lessons don't back 500 + 300/mo", which the pricing lesson does | H4 skill kit | The outreach skill ships only the outreach lessons, so it couldn't see the pricing lesson | Generator rule: say it's outside this task's lessons and which lesson to check; never claim the lessons don't support it |
| Told the member to post an offer whose niche check it still marked pending | O3 skill kit | The default Next step ("Post the offer in Wins today") conflicted with the pending rule | Generator: if any Check item failed or is pending, the next step is resolving it |
| Told members to tag "#firstwin" when posting the offer, before the 20 messages | H2 both, O2 both | The example spec's `next_action` contradicted its own first-outcome definition | `pack.yaml`: add "#firstwin" only once 20 messages are sent |
| A made-up classroom link | T1, H1 Project | The synthetic pack's placeholder URL | Example spec leaves `classroom_url` out; skills point to the Classroom tab |
| Kept "money leak" at "?" after the member gave per-patient value | O3 skill kit | Judgement: the lesson gives no threshold. The grader called it defensible but over-cautious | None; owners can add a threshold rule |
| A few citations quote a real sentence that doesn't support the point (3 Project, 2 skill kit) | O2, O3, H2, T1 | The model picked a nearby sentence | `check-citations` can't catch this; the acceptance review must |

## Effort (counted from the guides; no human timings were collected)

| | Project | Skill kit |
|---|---|---|
| Admin, extra work for this format | none: `pack-share` writes both from the same reviewed pack | none |
| Member setup | create a project, paste the instructions, upload 15 files (3 steps) | turn on code execution, then upload and switch on 3 skills (7 steps) |
| Settings needed | none listed on the projects pages | code execution must be on (support.claude.com, "Using skills in Claude") |
| Each later task | open the project, start a chat | any chat; the skill is picked from its description |
| Lesson update | replace the instructions and the changed files in the project | delete and re-upload each changed skill |
| Team/Enterprise | the project can be shared inside the organisation | the owner can provision skills to everyone; shared skills update for recipients automatically |

## What this means for the product

- Sell the reviewed method, its acceptance and the member onboarding, not the skill format. `pack-share` now gives
  every pack both formats.
- Recommend the Project to communities whose members are on individual plans, and skills to Claude Code users and
  organisations on Team or Enterprise.
- The published offer still describes skills (upload zips). Offering the Project format is a change to the
  deliverable for the owner to approve (`OFFER.md`).

## Limits

- 8 cases, one synthetic community, one model, one grader per case, no second rater. Exploratory.
- Claude Code subagents, not the Claude app: the Project condition simulates project knowledge by letting the
  model read the files, and the skill condition simulates skill loading from names and descriptions.
- Member turns were scripted. In H2 a third turn was added during the run because both conditions asked the same
  missing question (`CASES.md`).
- The subagents can see the operator's Claude Code memory. They were told to ignore it, and no reply mentions it.
- Measured: reply times only (in each run file). No human timings for setup or updates.
