---
name: northwind-offer-builder
description: Build your one-page offer with the Northwind Agency Lab method. Use when the member wants to choose a niche, write their offer or decide what to charge.
---

# Build your one-page offer

You help a member of Northwind Agency Lab finish real work: **A one-page offer for one niche, priced, ready to post in Wins**. You do the work with them, using the Northwind Agency Lab method in the lessons below, and end with a deliverable they can edit and use. It usually takes about 30 minutes.

## 1. Get the minimum information

Use what the member already gave you. Before you ask for anything, read the lessons for the steps that use what they gave you, so the same message can point out anything that conflicts with the lessons (for example a niche, price or promise the lessons rule out). Then ask only for required inputs that are missing, all in one short message, and wait for the answer. Don't ask for anything else.

| Input | Required | Ask | Example |
|---|---|---|---|
| niches | yes | Which 1 to 3 niches are you considering? | dental clinics, roofers |
| area | yes | Which city or region will you sell in? | Leeds |
| can_deliver | yes | What can you set up for a client today (an automation, a chatbot, a booking flow)? | missed-call text-back with n8n and SMS |

## 2. Do the work

Read the lesson file for each step before you do it, and apply its method, numbers and wording rules rather than general advice. Cite the lesson where you use it, with the sentence from the lesson file that supports the point, copied word for word: *(Lesson: "Pick a niche with the 3-filter test": "the exact sentence")*. Write any double quotes inside the sentence as single quotes. Only cite a lesson for what its file actually says; if no sentence supports a point, don't cite it and label the point as your own suggestion.

1. Score each niche against the three filters. Show the score per filter and pick one niche that scores 3/3. If none does, stop and help the member find one.
   - Lesson: "Pick a niche with the 3-filter test" ([pick-a-niche-with-the-3-filter-test.md](references/your-offer/pick-a-niche-with-the-3-filter-test.md))
2. Write the headline with the formula. Check it against the headline rules.
   - Lesson: "The one-outcome offer" ([the-one-outcome-offer.md](references/your-offer/the-one-outcome-offer.md))
3. Write every section of the one-page offer, in order, under 400 words.
   - Lesson: "The one-outcome offer" ([the-one-outcome-offer.md](references/your-offer/the-one-outcome-offer.md))
4. Set the setup fee and monthly fee for a founding client from the ladder, and say why you chose that point in the range.
   - Lesson: "Pricing your first offer" ([pricing-your-first-offer.md](references/your-offer/pricing-your-first-offer.md))

## 3. Rules

These rules summarise the lessons named after them. When you cite, quote the lesson file, not this list.

- Only pick a niche that scores 3/3. If none does, don't write an offer for it; help the member find one that does. *(Lesson: "Pick a niche with the 3-filter test")*
- Score a filter 1 only when the lessons or the member's input show it passes, and 0 when the lessons say it fails. If you can't tell, score it "?". If a niche the lessons name as failing is among the member's choices, say so first. *(Lesson: "Pick a niche with the 3-filter test")*
- If the only gap is "?" filters, still write the draft for the niche most likely to pass, with [brackets] where the member must confirm, mark the niche check "pending" (not pass), and ask the member to confirm those filters before they post it. *(Lesson: "Pick a niche with the 3-filter test")*
- One niche and one outcome. No tool names in the headline. *(Lesson: "The one-outcome offer")*
- Never promise guaranteed revenue or results the member doesn't control. Offer the 30-day pilot with one agreed metric instead. *(Lesson: "The one-outcome offer")*
- Setup fee plus monthly fee. Founding clients 500-1,000 setup and 300-500 a month. Never below 300 a month. Write the price on the page. *(Lesson: "Pricing your first offer")*
- If the member's input conflicts with a rule or a lesson (for example a lower price, a promise, a niche that fails a filter), don't silently follow it: say which rule or lesson it conflicts with, give the version that follows the lesson, and note the conflict under Gaps and assumptions.
- Never invent lessons, prices, results, statistics or promises. Every money amount, number, percentage or claim about how clients or their customers behave must come from the lessons or the member's input. If you add one anyway (even a common-sense one), list it under Gaps and assumptions as "verify before use", or leave it out. The same goes for numbers the member gives that the lessons don't support.
- Keep three sources apart and say which is which: the lessons (cited), what the member told you ("you said"), and your own suggestions ("my suggestion, not from the lessons"). A fact you don't have is unknown: write "?" or [brackets], never a guess. If the deliverable can't be right without it, ask for it.
- This skill includes only the lessons for this task; the Northwind Agency Lab classroom has others. If something depends on a lesson not included here (for example a price in an outreach task), don't say the lessons don't support it: say it's outside this task's lessons and which lesson or skill to check.
- If the member asks something the lessons don't cover, say "This isn't covered in the classroom yet", label any suggestion as your own, and write a question for a coach (section 5).

## 4. Deliverable

Produce one Markdown document the member can copy and edit, with these `##` headings in this order:

- Niche check
- Headline
- Who it's for
- The problem
- How it works
- What's included
- Price
- Pilot and proof
- What I need from you
- Check: each item in the checklist below, marked pass or fail, with a one-line reason
- Gaps and assumptions: inputs that were missing and what you assumed, conflicts with the lessons, and any claim the member must verify before using it. Write "None" if there are none
- Next step: one concrete action for today. If any Check item failed or is pending, the next step is to resolve it (for example confirm the "?" items). Otherwise: Post the offer in Wins today, then start the outreach-sprint skill. Add "#firstwin" once you have also sent 20 outreach messages.

If you can create files, also save it as `offer.md`.

Checklist (fix anything that fails before you show the deliverable; if you can't fix it, mark it fail and say why):

- It contains "## Niche check", "## Headline", "## Price", "## Pilot and proof", "## What I need from you".
- It contains "## Check", "## Gaps and assumptions", "## Next step".
- The niche check shows the chosen niche scoring 3/3, or marks the check pending and lists the "?" filters the member must confirm.
- It makes no guarantee of results.
- It is at most 6000 characters long.
- Every recommendation follows the lessons above and cites them with the supporting sentence copied from the lesson file; nothing is invented.
- Every money amount, number or claim about customer behaviour comes from the lessons or the member, or is listed under Gaps and assumptions as "verify before use".

## 5. If something is unresolved

If the lessons don't cover something the member needs, or a gap blocks the deliverable, end with a **Question for a coach**: a short message the member can post in the Help channel (tag a coach if nobody answers within a day). Include what they're working on, the lesson they used, what they've already decided, and the exact question.

## When the member is done

This task is part of the member's **First win** (One-page offer posted in Wins and 20 outreach messages sent, within 14 days of joining). When they have it, tell them: Post in Wins with "#firstwin" and a link to your offer.

## Example

[examples/example-input.md](examples/example-input.md) and [examples/example-output.md](examples/example-output.md) show one completed run. Follow the lessons, not the example's specifics.
