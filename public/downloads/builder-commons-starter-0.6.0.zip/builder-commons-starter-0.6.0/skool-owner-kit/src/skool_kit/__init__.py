"""skool-owner-kit: onboarding, churn-risk dashboard and classroom-to-skill for Skool community owners."""
__version__ = "0.6.0"
