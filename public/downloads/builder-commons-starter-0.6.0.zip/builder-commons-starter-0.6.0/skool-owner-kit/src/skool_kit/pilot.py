"""`skool-kit pilot`: turn a pilot's logs into a decision report.

Inputs (made by `pack-build` in pilot/): pilot.yaml (cohort dates, observation windows, thresholds), events.csv,
questions.csv, costs.csv and acceptance.csv. All local; nothing is sent anywhere.

The report keeps three things apart and judges each on its own:

- product quality: acceptance runs and reviewed tutor answers
- member outcomes: adoption, completed tasks, and the first outcome within its window, pilot vs baseline
- economics: what the pilot cost in cash and time, and the observed first-renewal difference

Members are only counted once their observation window has closed by the `as_of` date, so people who haven't
reached their outcome deadline or renewal date yet are never counted as failures. Comparing two cohorts can show
a difference; it can't prove the pack caused it.
"""
from __future__ import annotations

import csv
import io
import json
import math
from collections import Counter
from dataclasses import asdict, dataclass, field
from datetime import date, datetime, timedelta
from pathlib import Path

import yaml

EVENTS = ("joined", "installed", "used", "task_completed", "first_outcome", "renewed", "cancelled", "refunded",
          "excluded")
CAVEATS = [
    "This compares two cohorts; it does not prove the member pack caused any difference. Season, marketing, "
    "price changes and who joined can all differ between months.",
    "Events are only as complete as your logging. Self-reported outcomes undercount members who don't post.",
    "Staff time freed is capacity, not cash, unless you actually reduced paid hours.",
]


class PilotError(ValueError):
    pass


@dataclass
class Rate:
    hits: int
    total: int

    @property
    def pct(self) -> float | None:
        return 100.0 * self.hits / self.total if self.total else None

    def interval(self) -> tuple[float, float] | None:
        """95% Wilson score interval, in percent."""
        n = self.total
        if not n:
            return None
        z = 1.96
        p = self.hits / n
        centre = (p + z * z / (2 * n)) / (1 + z * z / n)
        half = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / (1 + z * z / n)
        return max(0.0, 100 * (centre - half)), min(100.0, 100 * (centre + half))


@dataclass
class Verdict:
    status: str
    reasons: list[str] = field(default_factory=list)


@dataclass
class PilotReport:
    name: str
    outcome: str
    within_days: int
    as_of: str
    pilot_members: int
    baseline_members: int
    adoption: Rate
    used: Rate
    tasks: dict
    outcome_pilot: Rate
    outcome_baseline: Rate
    outcome_pending: int
    lift_pts: float | None
    renewal_pilot: Rate
    renewal_baseline: Rate
    renewal_not_due: int
    renewal_unlogged: int
    refunds: int
    acceptance: Rate
    tutor_answers: int
    tutor_resolved: int
    tutor_corrected: int
    tutor_escalated: int
    correction_pct: float | None
    staff_questions: int
    staff_minutes_per_question: float | None
    capacity_hours_freed_estimate: float | None
    cash_costs: float
    time_cost_hours: float
    observed_revenue_difference: float | None
    observed_net_cash: float | None
    quality: Verdict
    outcomes: Verdict
    economics: Verdict
    decision: str
    reasons: list[str] = field(default_factory=list)
    caveats: list[str] = field(default_factory=lambda: list(CAVEATS))
    warnings: list[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        d = asdict(self)
        for key in ("adoption", "used", "outcome_pilot", "outcome_baseline", "renewal_pilot", "renewal_baseline",
                    "acceptance"):
            rate = getattr(self, key)
            d[key] = {"hits": rate.hits, "total": rate.total, "pct": rate.pct, "ci95": rate.interval()}
        return d


def _date(text, where: str) -> date:
    if isinstance(text, date):
        return text
    try:
        return datetime.strptime(str(text).strip()[:10], "%Y-%m-%d").date()
    except ValueError as exc:
        raise PilotError(f"{where}: date {text!r} must look like 2026-12-01") from exc


def _read_csv(path: Path, required: tuple[str, ...], optional: bool = False) -> list[dict]:
    if not path.is_file():
        if optional:
            return []
        raise PilotError(f"log not found: {path}")
    try:
        text = path.read_text(encoding="utf-8-sig")
    except UnicodeDecodeError as exc:
        raise PilotError(f"{path} is not saved as UTF-8 text (in Excel: Save As > CSV UTF-8)") from exc
    rows = list(csv.DictReader(io.StringIO(text)))
    header = [h.strip().lower() for h in (next(csv.reader(io.StringIO(text))) if text.strip() else [])]
    missing = [c for c in required if c not in header]
    if missing:
        raise PilotError(f"{path.name} is missing column(s): {', '.join(missing)}")
    return [{(k or "").strip().lower(): (v or "").strip() for k, v in r.items()} for r in rows]


def _number(value: str, where: str) -> float:
    if value in ("", None):
        return 0.0
    try:
        x = float(str(value).replace(",", ""))
    except ValueError as exc:
        raise PilotError(f"{where}: {value!r} is not a number") from exc
    if x < 0:
        raise PilotError(f"{where}: {value!r} can't be negative")
    return x


def load_plan(path: str | Path) -> tuple[dict, Path]:
    path = Path(path)
    if not path.is_file():
        raise PilotError(f"pilot plan not found: {path}")
    try:
        plan = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
    except yaml.YAMLError as exc:
        raise PilotError(f"{path} is not valid YAML: {exc}") from exc
    for key in ("pilot_cohort", "baseline_cohort", "within_days"):
        if key not in plan:
            raise PilotError(f"{path.name}: '{key}' is required")
    for key in ("pilot_cohort", "baseline_cohort"):
        c = plan[key] or {}
        lo, hi = _date(c.get("joined_from"), f"{key}.joined_from"), _date(c.get("joined_to"), f"{key}.joined_to")
        if hi < lo:
            raise PilotError(f"{key}: joined_to is before joined_from")
        plan[key] = (lo, hi)
    if plan.get("as_of"):
        plan["as_of"] = _date(plan["as_of"], "as_of")
    return plan, path.parent


def _outcome_verdict(t, pilot_n, base_n, adoption, out_p, out_b, lift) -> Verdict:
    min_cohort = int(t.get("min_cohort", 20))
    if out_p.total < min_cohort or out_b.total < min_cohort:
        return Verdict("not enough data", [
            f"Each cohort needs at least {min_cohort} members whose outcome window has closed "
            f"(pilot {out_p.total} of {pilot_n}, baseline {out_b.total} of {base_n})."])
    if adoption.pct is not None and adoption.pct < float(t.get("min_adoption_pct", 40)):
        return Verdict("change", [f"Only {adoption.pct:.0f}% of pilot members installed the pack (target "
                                  f"{t.get('min_adoption_pct', 40)}%). Fix onboarding before judging the outcome."])
    ci_p, ci_b = out_p.interval(), out_b.interval()
    if lift >= float(t.get("continue_if_lift_pts", 10)):
        reasons = [f"The outcome rate is {lift:.1f} points above baseline (target {t.get('continue_if_lift_pts', 10)})."]
        if ci_p[0] <= ci_b[1] and ci_b[0] <= ci_p[1]:
            reasons.append("The 95% ranges still overlap: run another cohort before treating this as settled.")
        return Verdict("continue", reasons)
    if lift <= float(t.get("stop_if_lift_pts", 0)):
        return Verdict("stop or change", [f"The outcome rate is not above baseline ({lift:+.1f} points)."])
    return Verdict("extend", [f"The outcome rate moved {lift:+.1f} points: between your stop and continue "
                              "thresholds. Run another cohort."])


def _quality_verdict(t, acceptance: Rate, correction_pct) -> Verdict:
    reasons, status = [], "pass"
    need = float(t.get("min_acceptance_pct", 100))
    if not acceptance.total:
        status = "not checked"
        reasons.append("No acceptance runs recorded in acceptance.csv. Run the acceptance cases in Claude before "
                       "members get the pack.")
    elif acceptance.pct < need:
        status = "fail"
        reasons.append(f"{acceptance.hits} of {acceptance.total} acceptance runs passed (need {need:.0f}%).")
    else:
        reasons.append(f"{acceptance.hits} of {acceptance.total} acceptance runs passed.")
    limit = float(t.get("max_correction_pct", 10))
    if correction_pct is not None and correction_pct > limit:
        status = "fail"
        reasons.append(f"{correction_pct:.0f}% of reviewed tutor answers needed correcting (limit {limit:.0f}%). "
                       "Fix the lessons or the tutor before scaling.")
    elif correction_pct is not None:
        reasons.append(f"{correction_pct:.0f}% of reviewed tutor answers needed correcting (limit {limit:.0f}%).")
    return Verdict(status, reasons)


def _economics_verdict(t, cash, hours, revenue_diff, ren_p, ren_b) -> Verdict:
    reasons, status = [], "not yet known"
    max_cash, max_hours = t.get("max_cash_costs"), t.get("max_effort_hours")
    over = False
    if max_cash is not None and cash > float(max_cash):
        over = True
        reasons.append(f"Cash costs {cash:,.0f} are over the limit of {float(max_cash):,.0f}.")
    if max_hours is not None and hours > float(max_hours):
        over = True
        reasons.append(f"Time spent, {hours:.1f} hours, is over the limit of {float(max_hours):.0f}.")
    if revenue_diff is None:
        reasons.append("Not enough members have reached their first renewal date to compare renewals yet.")
    else:
        net = revenue_diff - cash
        status = "positive" if net >= 0 else "negative"
        reasons.append(f"Observed first-renewal difference {revenue_diff:,.0f} minus cash costs {cash:,.0f} = "
                       f"{net:,.0f} (observed, not proven to be caused by the pack; time not included).")
        if min(ren_p.total, ren_b.total) < int(t.get("min_cohort", 20)):
            reasons.append("Few members have renewal results yet, so this figure is very uncertain.")
    if over:
        status = "over budget"
    return Verdict(status, reasons)


def analyse(plan: dict, events: list[dict], questions: list[dict], costs: list[dict],
            acceptance_rows: list[dict] | None = None) -> PilotReport:
    warnings: list[str] = []
    within = int(plan["within_days"])
    renewal_days = int(plan.get("renewal_after_days", 30))
    outcome_event = plan.get("outcome_event") or "first_outcome"
    joined: dict[str, date] = {}
    by_member: dict[str, dict[str, list[tuple[date, str]]]] = {}
    latest = None
    for n, row in enumerate(events, 2):
        member, event = row.get("member", ""), row.get("event", "").lower()
        if not member or not event:
            warnings.append(f"events.csv line {n}: needs a member and an event; skipped")
            continue
        if event not in EVENTS and event != outcome_event:
            warnings.append(f"events.csv line {n}: unknown event {event!r}; skipped")
            continue
        when = _date(row.get("date"), f"events.csv line {n}")
        latest = when if latest is None or when > latest else latest
        if event == "joined":
            joined.setdefault(member, when)
        by_member.setdefault(member, {}).setdefault(event, []).append((when, row.get("note", "")))
    orphans = sorted(set(by_member) - set(joined))
    if orphans:
        warnings.append(f"{len(orphans)} member(s) have events but no 'joined' row and were left out: "
                        + ", ".join(orphans[:5]) + ("..." if len(orphans) > 5 else ""))
    as_of = plan.get("as_of") or latest or date.today()
    if not plan.get("as_of"):
        warnings.append(f"No as_of date in the plan; using the latest event date, {as_of}.")

    def has(m: str, event: str) -> bool:
        return bool(by_member.get(m, {}).get(event))

    def cohort(rng) -> list[str]:
        lo, hi = rng
        return [m for m, d in joined.items() if lo <= d <= hi and not has(m, "excluded")]

    pilot, base = cohort(plan["pilot_cohort"]), cohort(plan["baseline_cohort"])

    def reached(m: str) -> bool:
        return any(0 <= (d - joined[m]).days <= within for d, _ in by_member.get(m, {}).get(outcome_event, []))

    def window_closed(m: str) -> bool:
        return joined[m] + timedelta(days=within) <= as_of

    def outcome_rate(members) -> Rate:
        eligible = [m for m in members if window_closed(m)]
        return Rate(sum(1 for m in eligible if reached(m)), len(eligible))

    unlogged = 0

    def renewal(members) -> tuple[Rate, int]:
        nonlocal unlogged
        due = [m for m in members if joined[m] + timedelta(days=renewal_days) <= as_of]
        decided = [m for m in due if has(m, "renewed") or has(m, "cancelled")]
        unlogged += len(due) - len(decided)
        renewed = sum(1 for m in decided if has(m, "renewed") and not has(m, "cancelled"))
        return Rate(renewed, len(decided)), len(members) - len(due)

    adoption = Rate(sum(1 for m in pilot if has(m, "installed")), len(pilot))
    used = Rate(sum(1 for m in pilot if has(m, "used") or has(m, "task_completed")), len(pilot))
    tasks = Counter(note or "unnamed task" for m in pilot for _, note in by_member.get(m, {}).get("task_completed", []))
    out_p, out_b = outcome_rate(pilot), outcome_rate(base)
    pending = len(pilot) - out_p.total
    lift = out_p.pct - out_b.pct if out_p.total and out_b.total else None
    (ren_p, not_due_p), (ren_b, _) = renewal(pilot), renewal(base)
    if unlogged:
        warnings.append(f"{unlogged} member(s) passed their renewal date with no 'renewed' or 'cancelled' row; "
                        "they were left out of the renewal rates.")
    price = float(plan.get("membership_price") or 0)
    fee = float(plan.get("platform_fee_pct") or 0) / 100
    revenue_diff = None
    if ren_p.total and ren_b.total and price:
        revenue_diff = (ren_p.pct - ren_b.pct) / 100 * ren_p.total * price * (1 - fee)

    tutor = [q for q in questions if q.get("handled_by", "").lower() == "tutor"]
    staff = [q for q in questions if q.get("handled_by", "").lower() == "staff"]
    resolved = sum(1 for q in tutor if q.get("result", "").lower() == "resolved")
    corrected = sum(1 for q in tutor if q.get("result", "").lower() == "corrected")
    escalated = sum(1 for q in tutor if q.get("result", "").lower() == "escalated")
    staff_minutes = [_number(q.get("staff_minutes", ""), "questions.csv staff_minutes") for q in staff]
    per_q = sum(staff_minutes) / len(staff_minutes) if staff_minutes else None
    freed = resolved * per_q / 60 if per_q is not None else None
    cash = sum(_number(c.get("amount", ""), "costs.csv amount") for c in costs if c.get("kind", "").lower() == "cash")
    hours = sum(_number(c.get("minutes", ""), "costs.csv minutes") for c in costs
                if c.get("kind", "").lower() == "time") / 60
    correction_pct = 100 * corrected / len(tutor) if tutor else None
    acc_rows = acceptance_rows or []
    acc = Rate(sum(1 for a in acc_rows if a.get("passed", "").lower() in ("yes", "y", "true", "1", "pass")), len(acc_rows))

    t = plan.get("thresholds") or {}
    quality = _quality_verdict(t, acc, correction_pct)
    outcomes = _outcome_verdict(t, len(pilot), len(base), adoption, out_p, out_b, lift)
    economics = _economics_verdict(t, cash, hours, revenue_diff, ren_p, ren_b)

    # One suggestion, but quality and economics can hold back an encouraging outcome result.
    decision, reasons = outcomes.status, []
    if outcomes.status == "not enough data":
        reasons.append("Member outcomes: not enough members whose window has closed.")
    elif quality.status == "fail":
        decision = "fix quality first"
        reasons.append("Product quality failed: fix it before reading anything into member outcomes.")
    elif outcomes.status == "continue" and quality.status == "not checked":
        decision = "extend"
        reasons.append("Outcomes look good, but the pack's quality wasn't checked: record acceptance runs first.")
    elif outcomes.status == "continue" and economics.status in ("negative", "over budget"):
        decision = "change"
        reasons.append(f"Outcomes look good, but the economics are {economics.status}: reduce costs or effort "
                       "before continuing.")
    else:
        reasons.append(f"Member outcomes: {outcomes.status}. Quality: {quality.status}. Economics: {economics.status}.")
    return PilotReport(
        name=str(plan.get("pilot") or "Pilot"), outcome=str(plan.get("outcome") or outcome_event), within_days=within,
        as_of=as_of.isoformat(), pilot_members=len(pilot), baseline_members=len(base), adoption=adoption, used=used,
        tasks=dict(sorted(tasks.items())), outcome_pilot=out_p, outcome_baseline=out_b, outcome_pending=pending,
        lift_pts=lift, renewal_pilot=ren_p, renewal_baseline=ren_b, renewal_not_due=not_due_p,
        renewal_unlogged=unlogged, refunds=sum(1 for m in pilot if has(m, "refunded")), acceptance=acc,
        tutor_answers=len(tutor), tutor_resolved=resolved, tutor_corrected=corrected, tutor_escalated=escalated,
        correction_pct=correction_pct, staff_questions=len(staff), staff_minutes_per_question=per_q,
        capacity_hours_freed_estimate=freed, cash_costs=cash, time_cost_hours=hours,
        observed_revenue_difference=revenue_diff,
        observed_net_cash=None if revenue_diff is None else revenue_diff - cash,
        quality=quality, outcomes=outcomes, economics=economics, decision=decision, reasons=reasons,
        warnings=warnings)


def run(plan_path: str | Path) -> PilotReport:
    plan, base = load_plan(plan_path)
    events = _read_csv(base / plan.get("events", "events.csv"), ("member", "event", "date"))
    questions = _read_csv(base / plan.get("questions", "questions.csv"), ("handled_by", "result", "staff_minutes"))
    costs = _read_csv(base / plan.get("costs", "costs.csv"), ("kind", "amount", "minutes"))
    acceptance = _read_csv(base / plan.get("acceptance", "acceptance.csv"), ("skill", "passed"), optional=True)
    return analyse(plan, events, questions, costs, acceptance)


# ---------------------------------------------------------------- output


def _rate(r: Rate) -> str:
    if not r.total:
        return "no data"
    lo, hi = r.interval()
    return f"{r.hits}/{r.total} = {r.pct:.0f}% (95% range {lo:.0f}-{hi:.0f}%)"


def _money(x: float | None) -> str:
    return "n/a" if x is None else f"{x:,.0f}"


def _verdict(title: str, v: Verdict) -> list[str]:
    return [f"**{title}: {v.status}**", ""] + [f"- {x}" for x in v.reasons] + [""]


def render_md(r: PilotReport) -> str:
    out = [f"# {r.name}: pilot report", "", f"Data as of {r.as_of}.", "",
           f"**Suggestion: {r.decision.upper()}**", ""] + [f"- {x}" for x in r.reasons] + [""]
    out += ["## 1. Product quality", ""] + _verdict("Quality", r.quality)
    out += [f"- Acceptance runs passed: {_rate(r.acceptance)}",
            f"- Tutor answers reviewed: {r.tutor_answers} (resolved {r.tutor_resolved}, corrected {r.tutor_corrected}, "
            f"escalated {r.tutor_escalated})", ""]
    out += ["## 2. Member outcomes", ""] + _verdict("Outcomes", r.outcomes)
    out += [f"Primary outcome: **{r.outcome}** within {r.within_days} days of joining. Only members whose "
            f"{r.within_days}-day window has closed are counted.", "",
            "| Cohort | Members | Window closed | Reached the outcome |", "|---|---|---|---|",
            f"| Pilot (got the pack) | {r.pilot_members} | {r.outcome_pilot.total} | {_rate(r.outcome_pilot)} |",
            f"| Baseline (earlier members) | {r.baseline_members} | {r.outcome_baseline.total} | "
            f"{_rate(r.outcome_baseline)} |", "",
            f"Difference: {'n/a' if r.lift_pts is None else f'{r.lift_pts:+.1f} percentage points'}. "
            f"Pilot members still inside their window: {r.outcome_pending}.", "",
            f"- Installed: {_rate(r.adoption)}", f"- Used a skill or completed a task: {_rate(r.used)}"]
    if r.tasks:
        out.append("- Completed tasks: " + ", ".join(f"{k} {v}" for k, v in r.tasks.items()))
    out += ["", "## 3. Economics", ""] + _verdict("Economics", r.economics)
    out += [f"- First renewal, pilot: {_rate(r.renewal_pilot)} ({r.renewal_not_due} pilot member(s) not due yet)",
            f"- First renewal, baseline: {_rate(r.renewal_baseline)}",
            f"- Refunds in the pilot cohort: {r.refunds}",
            f"- Observed revenue difference at first renewal: {_money(r.observed_revenue_difference)} "
            "(renewal-rate difference × pilot members with a renewal result × price, after fees)",
            f"- Cash spent on the pilot: {_money(r.cash_costs)}",
            f"- Time spent: {r.time_cost_hours:.1f} hours (not included in cash)",
            f"- Staff-handled questions: {r.staff_questions}, "
            f"{'n/a' if r.staff_minutes_per_question is None else f'{r.staff_minutes_per_question:.0f}'} minutes each; "
            f"capacity freed (estimate): "
            f"{'n/a' if r.capacity_hours_freed_estimate is None else f'{r.capacity_hours_freed_estimate:.1f} hours'} "
            "(capacity, not cash)", "",
            "## Read this before you decide", ""] + [f"- {c}" for c in r.caveats]
    if r.warnings:
        out += ["", "## Log problems", ""] + [f"- {w}" for w in r.warnings]
    return "\n".join(out) + "\n"


def render_text(r: PilotReport) -> str:
    return render_md(r).replace("**", "").replace("## ", "").replace("# ", "")


def render(r: PilotReport, fmt: str = "text") -> str:
    if fmt == "json":
        return json.dumps(r.to_dict(), indent=2, default=str) + "\n"
    if fmt == "md":
        return render_md(r)
    return render_text(r)
