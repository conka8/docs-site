# Changelog

## 2026-10-30 (later): one format-neutral offer (skool-owner-kit 0.7.0)

### Offer and site

- The paid offer is now "a reviewed AI member kit built from your community's lessons", delivered as one Claude
  Project (default for members on their own plans) or as Claude skills. Price, payment and the other terms are
  unchanged. Scope, deliverables, acceptance criteria, process, home page and guides now describe the same thing.
- Home page reordered: who it's for, what members produce, what US$500 buys, what we add over doing it yourself, what
  has been shown, and the next step. The evidence table moved into an expander.
- Pilot page: "Doing it yourself, or paying us". What we add (problem, deliverable, acceptance, effort it affects)
  and who does what, with every hour marked as an estimate. It says plainly that the pilot doesn't save setup time.
- The comparison is labelled as simulated: Project-like context and skill-like loading in Claude Code, not the app.
- Calculator: the verdict turns against a purchase that pays back in cash but needs a large change once the owner's
  time counts.
- FIRST-PILOT.md: one fill-in page to run a pilot (scope, intake, format choice, acceptance, logs, continue, change
  or stop).

### skool-owner-kit 0.7.0

- `pack-share --format project|skills|both`: only the format members will use, with a launch post for that format.
- ADMIN-REVIEW.md starts with **Rules to confirm first**: every rule that isn't word for word in the lesson it names.
- Pilot checklist: the format choice, the rules to confirm, acceptance in the chosen format, proportional logging,
  and time rows named by activity so the first pilots can replace the effort estimates.
- The acceptance journey also checks the Claude Project kit from the released package, before and after an update.

## 2026-10-30: checkable citations, skills or a Claude Project, a draft spec (skool-owner-kit 0.6.0)

### skool-owner-kit 0.6.0

- **Citations quote the passage**: every generated skill cites as *(Lesson: "Title": "the exact sentence")*.
  **`check-citations`** confirms each quoted sentence is in the named lesson (case, spacing, emphasis and quote marks
  ignored). It doesn't judge whether the sentence supports the point.
- **Sources kept apart**: skills label what the lessons say, what the member said ("you said") and their own
  suggestions, show unknown facts as "?" or [brackets], and ask for what the deliverable needs.
- **Claude Project output**: `pack-share` also writes `<prefix>-claude-project-<version>/` (and a zip):
  `INSTRUCTIONS.md`, the lessons, one task guide per skill (the reviewed SKILL.md body) and `START-HERE.md`.
- **`pack-draft`**: a first `pack.yaml` from the classroom. It has one draft task per module, rules copied word for
  word from the lessons, and `TODO (owner)` for every decision only the owner can make. `pack-share` refuses any
  `TODO (owner)`.
- **Fixes**:
  - The example's niche check accepts "pending", so it no longer pushes the model to invent a 3/3.
  - The next step resolves failed or pending checks first.
  - Task skills say when something is outside their own lessons instead of "the lessons don't support it".
  - The example pack's next step no longer tags "#firstwin" early.
  - The example pack has no made-up classroom link.
- **Evidence**:
  - `examples/agency-lab/comparison/`: 16 conversations (8 cases, up to 3 turns), the same pack as skills and as a
    Claude Project, graded blind.
  - `benchmark/README.md` gains a re-inspection: why 21 replies, which were development runs, equivalence and grader
    effects.

### Site

- The comparison section leads with skills vs a Claude Project; the earlier benchmark is kept as history.
- Calculator: the renewal change needed to cover the fee plus the owner's time, the inputs that move the answer most,
  and a note that a one-month pilot can't show a year-long effect.
- One compatibility statement (skills on every plan with code execution on; Projects on every plan). The page title
  and description describe the pilot.
- Members page: installing a Claude Project.

## 2026-10-29 (late): member kit, fair comparison, approachable calculator (skool-owner-kit 0.5.0)

### skool-owner-kit 0.5.0

- **`pack-share`**: builds what members receive: `share/<prefix>-member-kit-<version>.zip` with `START-HERE.md` and
  one upload zip per skill, plus a draft `LAUNCH-POST.md`. It zips the admin's edited skills as they are, and refuses
  unmerged `.new` files, a name that doesn't match its folder, or a description over 200 characters.
- **Member start guide** names every zip, gives copyable install commands (macOS/Linux and Windows), a one-minute check,
  a paste-ready first message per task, what the draft contains, and how to update.
- **Claude app limit**: generated descriptions fit 200 characters (the claude.ai upload limit; Claude Code accepts
  1024). The tutor's description now covers questions the lessons don't answer: in a simulated selection test, such a
  question loaded no skill before the change.
- **Fixes from blind grading**: task skills read the relevant lessons before asking for missing input, so conflicts
  are named at once; unconfirmed niche filters score "?" instead of passing, with a bracketed draft and the check
  marked pending; the example pack says to tag a coach only if nobody answers within a day.
- Every pack gets `pilot/CHECKLIST.md`; `acceptance.csv` has a `surface` column.
- `examples/agency-lab/benchmark/`: 21 replies across a general assistant, the same assistant with the lessons, and
  the skill, graded blind, plus reruns after fixes. `acceptance-journey/`: the member journey from download to update.

### skillkit 0.3.1, skillport 0.2.1

- `lint` warns `description-too-long-for-app` over 200 characters; `pack --format claude-app` refuses such skills.
- skillport descriptions fit 200 characters and keep the "Use when" sentence.

### Site and repository

- `scripts/acceptance_journey.py`: from the released download to an installed member kit and an update, 45 checks.
- Calculator: one scenario starting from the published fee, adoption separated from the effect among users,
  essential inputs first, advanced ones in an expander, a plain-language verdict that can say "unlikely to pay back",
  and no fit rule based on community size alone.
- The home page claims match the comparison; the paid pilot is the primary action and the free download secondary.
- The pilot offer separates what we commit to, what can be observed and what is only tested; payment never depends on
  member behaviour or revenue.
- The enquiry form asks only for public information and says a GitHub account is needed; a private route can be
  switched on in `pilot-offer.js`. A test checks the form's fields match the site.

## 2026-10-29 (night): design-partner terms and enquiries

- **Design-partner pilot terms published** on the "Scoped pilot" page and in PILOT-OFFER.md:
  - US$500 fixed for each of the first 3 communities that pass the fit check.
  - Payable half on spec approval and half on acceptance; the second half isn't due if the pilot stops at acceptance.
  - Anonymised results publishable; the community is named only with written consent.
  - Replies within 2 business days.
  - The standard price is not published.
- **Enquiries work.** The pilot page links to a GitHub issue form (`docs-site/.github/ISSUE_TEMPLATE/pilot-enquiry.yml`)
  that warns the issue is public and asks only for public facts. A test checks that the linked form exists.
- Pilots support the Claude app only. The decisions and their reasons are recorded in OFFER.md (internal).

## 2026-10-29 (evening): verified member workflow, cohort value model, scoped pilot (skool-owner-kit 0.4.0)

### skool-owner-kit 0.4.0

- **Task skills complete the work.** They ask only for missing required inputs (optional inputs take stated
  defaults), apply rules tied to named lessons, name conflicts with the lessons instead of silently following the
  member, and end the deliverable with a pass/fail Check, Gaps and assumptions, a Next step, and a ready-to-post
  Question for a coach when something is unresolved.
- **Unsupported claims are flagged.** Any money amount, number or customer-behaviour claim that isn't from the
  lessons or the member must be marked "verify before use". This came from a defect found in a real run.
- New spec fields: `support_channel`, rules with `lesson:`, `required`/`default` on inputs, `next_action`,
  `deliverable.filename`, and `extra_cases` (extra acceptance cases such as conflicting input).
- **Pilot report.**
  - `as_of`, `renewal_after_days` and an `excluded` event: members still inside a window are pending, not failures.
  - `task_completed` events and `acceptance.csv`.
  - Separate quality, outcome and economics verdicts. Quality failures, negative economics or a budget overrun hold
    back "continue".
- **Recorded runs:** `examples/agency-lab/live-runs/` has 8 runs in Claude Code, and the example outputs are now
  actual outputs instead of hand-written ones.

### Docs site and guides

- The value calculator is a month-by-month cohort model:
  - Payments count in the month they arrive, with future contribution reported separately.
  - Payback comes from cumulative cash, including dips back below zero.
  - Inputs are validated.
  - Fixed fees, refunds and delivery costs are included, and paid hours cut are separated from capacity.
- New: EFFORT.md (one estimated effort breakdown), PILOT-OFFER.md (scoped paid pilot), both generated from the site
  data. PILOT.md is now the first-customer workflow.
- The site follows: outcome, real run, fit, economics, scoped pilot.


## 2026-10-29 (later): member pack and pilot (starter bundle 0.3.0)

### skool-owner-kit 0.3.0

- `skool-kit pack-build pack.yaml`: builds a member pack from your lessons: a tutor that cites lessons and routes
  uncovered questions to your support channel, one task skill per first-win step (inputs to ask for, steps each
  tied to a lesson, deliverable sections, your rules, a self-check), acceptance checks for `skillkit eval`,
  MEMBER-START.md, ADMIN-REVIEW.md with a manual acceptance procedure, and a pilot kit. Rebuilding keeps files you
  edited and writes the new version next to them as `<file>.new`.
- `skool-kit pilot pilot.yaml`: compares a pilot cohort with a baseline cohort (first-outcome rate with 95% ranges,
  adoption, first renewal, tutor corrections, staff minutes, cash and time costs) and suggests continue, extend,
  change, stop or change, or not enough data. Staff time is reported as capacity, never as cash.
- `classroom-to-skill` takes the support route into account when the pack sets one.
- `examples/agency-lab/`: a synthetic AI-agency community with eight lessons, an n8n template, a pack spec,
  hand-written example outputs, the generated pack, and synthetic pilot logs with their report.

### skillkit 0.3.0

- `eval --include-references` also sends the text files each SKILL.md points to (references/, assets/,
  templates/, examples/). Reports say which mode ran.

### Guides

- New: BUSINESS-AUDIT.md, VALUE-MODEL.md, PILOT.md. OFFER.md (internal) rewritten around one buyer and offer.


## 2026-10-29: starter bundle 0.2.0, other tools 0.1.1

### Everyone

- Every tool, and a starter bundle (skool-owner-kit, skillport, skillkit and the guides), can be downloaded from
  the docs site. Each zip is install-tested in a fresh environment before release (`scripts/smoke_test.py`).
- Every quickstart now starts with sample files that ship in the download.
- New guides: [ADMIN-GUIDE.md](ADMIN-GUIDE.md), [MEMBER-GUIDE.md](MEMBER-GUIDE.md), [READINESS.md](READINESS.md),
  [DATA-AND-COSTS.md](DATA-AND-COSTS.md), [MAINTAINING.md](MAINTAINING.md).

### skillport 0.2.0

- Every converted skill has a **Conversion check** listing what doesn't carry over: code steps, schedules, AI steps,
  loops, logic in expressions, retries, continue-on-fail, error workflows, Make.com error handlers and calls to
  other workflows. `inspect` prints it, `convert`/`batch` count it, `inspect --format json` has it under `review`.
- Bridge skills check the webhook's reply mode ("Workflow was started" problem), the auth header to set, test vs
  production URLs, and network access.
- A field that is only a reference (`{{ $json.text }}`) reads "the value of `text`" instead of looking like the
  literal text "text".
- Install steps in generated READMEs match the current Claude app, Claude Code (including Windows) and OpenClaw docs.
- Sample workflows in `examples/`.

### skillkit 0.2.0

- `pack --format claude-app`: one upload zip per skill (skill folder at the zip root) and an `INSTALL.md`.
- Lint warnings `needs-review` (a skillport skill whose Conversion check hasn't been reviewed) and
  `frontmatter-upload-key` (header keys the Claude app and API reject).
- `eval` reports state that they are instruction-only tests, list the files each skill points to that were not sent
  to the model, and mark `--provider fake` runs as **DEMO DATA** (`"demo": true`, `"mode": "instruction-only"` in JSON).
- Sample library and cases in `examples/`.

### skool-owner-kit 0.2.0

- Dashboard says "Inactivity risk" and "Cohort activity" instead of churn and retention, explains that the export
  only holds current members, and has a "How to read this" section.
- Zapier setup uses Skool's actual triggers (Answered Membership Questions, New Paid Member; needs Skool Pro) and
  sends the secret in a header from an environment variable.
- The webhook drops connections that stall for 30 seconds.

### shipsafe 0.1.1

- An empty or wrong folder stops with exit 2 instead of getting grade A.
- Verdicts describe what the checks found ("No serious problems found by shipsafe's checks") and text/Markdown
  reports end with a scope line: a clean result is not a security audit.
- Quoted values assigned to names like `apiKey`, `token`, `secret` are masked in evidence lines.
- New rule `SS-SECRET-CLIENT-APIKEY` for long API keys in browser code.
- The skill and the example GitHub workflow no longer run `pip install shipsafe` (it isn't on PyPI).

### geo-audit 0.1.1

- Reports from the demo provider carry a "Demo data" banner (`"demo": true` in JSON).
- Reports say answers come from the providers' APIs, which can differ from the consumer apps.
- CSVs saved by Excel (cp1252) work; undecodable files give a clear error.
- A missing key for a selected provider stops before any question is asked (exit 2, no report written).

### voice-qa 0.1.1

- Scorecards say "simulated text conversations (no audio or phone line was tested)".
- Demo runs (scripted agent or fake provider) carry a "Demo data" banner.
- Real agents default to "your business" instead of the pack's sample name.
- Any errored conversation makes the run exit 1.
- Secrets in webhook error bodies are hidden and bodies are cut to 200 characters; non-UTF-8 files give a clear error.

### ghl-agency-kit 0.1.1

- Every output from the fake demo account carries a "Demo data" banner.
- Create requests (POST) are no longer retried on server errors, to avoid duplicates; only on 429 with Retry-After.
- `onboard` prints which account it is about to write to.

### vertical-packs 0.1.1

- Maintenance triage escalates any mention of carbon monoxide, gas, smoke, burning, burst pipes, exposed wires or
  shocks, and flags them "needs a human to review now". Negated danger words ("I don't smell gas anymore") are
  escalated to URGENT rather than ignored.

### career-labs 0.1.1

- The installed `labgrade` command finds the labs (`--labs-dir`, `LABGRADE_LABS_DIR`, `./labs`, then the package
  folder) and says what to do when it can't.
- `pyyaml` is installed with it, so every reference solution scores 100.

## Upgrading

Download the new zip, unzip it, activate the virtual environment you installed into, and install again:

```bash
source .venv/bin/activate                     # Windows: .venv\Scripts\Activate.ps1
python -m pip install ./skool-owner-kit ./skillport ./skillkit
```

- Skills converted with skillport 0.1 have no Conversion check. Convert them again, then review each list.
- skool-owner-kit's JSON still calls the cohort field `retention_pct`; only the dashboard wording changed.
- voice-qa exits 1 when any conversation errors; geo-audit exits 2 when a selected provider's key is missing.
  Adjust CI jobs that relied on the old exit codes.
