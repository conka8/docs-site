# skool-owner-kit

Free tools for Skool community owners: a member pack that turns your lessons into skills that walk new members to
their first win (with acceptance checks and a pilot report), personalised welcome messages, an inactivity dashboard,
and a "classroom tutor" Claude/OpenClaw skill built from your lessons.

**It only uses your own data**: CSV exports you download and Zapier/webhook events you send it.
We found no public Skool API documentation (checked 2026-10-29); Skool's own integration is its Zapier app. This kit does **not** scrape Skool, does not log in as you and never needs
your Skool password or cookies.

Python 3.10+, no dependencies besides PyYAML. MIT licensed.

## Install

```bash
pip install .        # from this folder (not on PyPI yet)
skool-kit --version
```

Try every command on the sample files in `examples/` first.

## 1. Check your export

```bash
skool-kit inspect examples/members.csv
```

```
Delimiter: comma
Columns used:
  name          <- Name
  email         <- Email
  joined        <- Joined Date
  answers       <- Question 1, Question 2
  ...
Read 36 member(s) from 36 row(s).
```

Column names are matched loosely (case doesn't matter): "Name" / "Full Name" / "First Name"+"Last Name", "Email",
"Joined" / "Join Date" / "Approved At", "Answers" / "Question 1..3" / "Membership Questions" / any column ending
in "?", "Level", "Points", "Last Active" / "Last Seen", "Posts", "Comments", "Price" / "Plan" / "Tier",
"Invited By", "LTV". Comma, semicolon and tab files, Excel's BOM and Windows encodings all work.
Dates can be `2026-10-03`, `10/3/2026 2:15 PM`, `Oct 3, 2026`, `3d ago`...

If a column isn't picked up, tell the tool: `--map "What brings you here?=answers"`.
Day/month/year dates: add `--dayfirst`. Rows without a name or email, and duplicates, are skipped and listed.

## 2. Welcome messages for new members

```bash
skool-kit onboard examples/members.csv --since 2026-10-14 --community-name "AI Builders" -o messages.csv
skool-kit onboard examples/members.csv --since 2026-10-14 -o messages.md     # easy to read
```

Each member's join-question answers decide their **segment** (beginner, agency owner, developer, business owner,
job seeker) and **goal** (first client, build an app, automate my business, get hired, learn AI). That picks
3 lessons and a first action:

```
Hey Ana, welcome to AI Builders! Since you want to land your first client, here's your first week:
1. Start Here: How This Community Works
2. The AI Agency Offer That Sells
3. Finding Your First Client in 7 Days
Your first action: Write down 10 local businesses you could help and share your niche in the wins channel.
Reply here if you get stuck. Happy to help!
```

**Use your own lesson names**: `skool-kit rules -o rules.yaml`, edit it (keywords, lesson titles, wording;
placeholders `{first_name} {goal} {lesson_1} {lesson_2} {lesson_3} {first_action} {community_name}`), then
add `--rules rules.yaml`.

**Optional AI personalisation**: `--llm anthropic` (env `ANTHROPIC_API_KEY`, model `claude-sonnet-5-5` by default)
or `--llm openai` (env `OPENAI_API_KEY`, `OPENAI_MODEL`, and `OPENAI_BASE_URL` for any OpenAI-compatible service).
If the AI call fails, or its reply drops a lesson name, the template message is used instead.

## 3. Automatic welcomes with Zapier

```bash
export SKOOL_KIT_SECRET="a-long-random-secret"      # Windows PowerShell: $env:SKOOL_KIT_SECRET="a-long-random-secret"
skool-kit webhook --host 0.0.0.0 --port 8787 --rules rules.yaml \
  --forward-url "https://hooks.zapier.com/hooks/catch/123/abc/"
```

`--secret` also works, but it ends up in your shell history, so prefer the environment variable.

In Zapier (Skool's Zapier app needs Skool's **Pro** plan; the API key is in your group settings > Plugins > Zapier):

- **Trigger:** Skool **Answered Membership Questions** (fires when someone answers your join questions), or
  **New Paid Member** for paid groups. Skool's Zapier app has no trigger for every new free member.
- **Action:** **Webhooks by Zapier (POST)** to `https://your-server:8787/`, payload type JSON, with the member's
  name, email and answers, and a header `X-Skool-Kit-Secret: a-long-random-secret`
  (`?secret=...` in the URL also works, but URLs are often logged).

Trigger names come from Skool's help center and Zapier's Skool app page, checked 2026-10-29:
https://help.skool.com/article/56-zapier-integration and https://zapier.com/apps/skool/integrations.

Field names are matched like CSV columns (nested JSON is fine); add `--map "Zap Field=email"` if needed.

Each event: the message is returned (200), appended to `outbox.jsonl`, and forwarded to `--forward-url`
(e.g. a second Zap that sends the email or DM). Wrong secret: 401. Bad JSON: 400. Health check: `GET /health`.
Connections that stall for 30 seconds are dropped. Run it behind HTTPS (a reverse proxy or a tunnel) when it's
reachable from the internet.

`outbox.jsonl` contains members' names, emails and answers. Keep it on your own machine and delete it when you
no longer need it.

## 4. Engagement and inactivity-risk dashboard

```bash
skool-kit health examples/members.csv --activity examples/activity.csv \
  --community-name "AI Builders" -o dashboard.html --at-risk at_risk.csv --as-of 2026-10-28
```

```
36 members, 77.8% active in 30 days, 15 at risk (8 paying).
```

`--as-of 2026-10-28` makes the sample data give the same result every day. Leave it out for your own exports
(it defaults to today).

`dashboard.html` is one file (no internet needed, prints to PDF): active % (7/30 days), new members per week,
at-risk paying members, cohort activity by join month, inactivity-risk bands, top contributors, and the at-risk list
with a suggested re-engagement message for each person. `at_risk.csv` / `.json` has the same list.

**Activity history** (optional, makes trends work): save the member export every week and stack the files into one
CSV with a date column: `Email, Snapshot Date, Posts, Comments, Level, Points`.

The risk score is a transparent heuristic built from activity in your exports. It flags members who have gone
quiet; it does not predict cancellations, and the dashboard says so. How the score (0-100) works:

| Signal | Points |
|---|---|
| Last active 4-7 / 8-14 / 15-30 / 31+ days ago (unknown: 20) | 10 / 25 / 40 / 55 |
| Never posted or commented (member 14+ days; newer: 5) | 15 |
| Stopped posting (needs 3+ snapshots) / posting less than half as much | 20 / 12 |
| No new posts since the last snapshot (2 snapshots) | 8 |
| Same level for 28+ days, or still level 1 after 30 days | 10 |
| Member for 6+ months | -5 |

60+ is high risk, 35-59 medium (`--threshold` changes the at-risk cut-off). Paying vs free does not change the
score; paying members are listed first and counted in "at-risk paying members".

## 5. Member pack: tutor + task skills + checks + pilot (start here)

A member pack turns your lessons into skills that **do your first-win tasks with each member**, step by step, using
your method, plus everything you need to check it and to measure whether it helped.

Try the synthetic example first (an invented AI-agency community; all names and numbers are made up):

```bash
cd examples/agency-lab
skool-kit pack-build pack.yaml -o my-pack          # 3 skills, acceptance checks, guides, pilot kit
skool-kit pilot pilot-sample/pilot.yaml           # how a pilot report reads (synthetic logs)
```

You should see `Built my-pack: 3 skills (northwind-tutor, northwind-offer-builder, northwind-outreach-sprint)` and
then a report starting `Suggestion: CONTINUE`, followed by the warning that the cohorts' ranges overlap.

**Your own pack:** start from a draft made from your lessons, or copy `examples/agency-lab/pack.yaml`:

```bash
skool-kit pack-draft my-classroom --community-name "My Community" -o pack.yaml
```

The draft has one task per module with its lessons as steps, and the rules copied word for word from your lessons
(bullets under a "Rules" or "Common mistakes" heading, and bullets starting with Never, Always, Only, No or Don't).
Every decision only you can make is marked `TODO (owner)`. After `pack-build`, **`APPROVAL.md`** is the one page the
owner approves: the tasks, every rule that isn't word for word in the lesson it names (shown beside the closest lesson
sentence, and marked "may be our addition" when nothing is close), and the acceptance cases. You can build it to preview, but `pack-share` refuses to
share a pack that still contains a TODO. The spec names:

- `first_outcome`: the result new members should reach and by when, and how they report it.
- `support` and `support_channel`: where members take what the lessons don't cover.
- `playbooks`: the tasks a member completes with Claude. Each has inputs (required or optional with a default),
  numbered steps that each point at a lesson (by title; `--list-lessons` shows them), the deliverable's sections,
  rules (each can name the lesson it comes from), checks, a `next_action`, an example and optional `extra_cases`
  (for example conflicting member input).
- `tutor`: sample questions with the lesson that should answer them, and questions your lessons don't cover.

Every task skill asks only for missing required inputs, applies your rules, names conflicts instead of silently
following the member, and ends its deliverable with a pass/fail **Check**, **Gaps and assumptions** (missing input,
assumptions, and any number or customer-behaviour claim not from the lessons, marked "verify before use"), a
**Next step**, and, when something is unresolved, a ready-to-post **Question for a coach**.

`pack-build` writes `skills/`, `evals/cases.yaml` (the cases with recorded answers, for `skillkit eval`),
`evals/acceptance.yaml` (every case in full, with later turns and review questions), `APPROVAL.md`, `MEMBER-START.md`,
`ADMIN-REVIEW.md` and `pilot/`. No AI is called and nothing is uploaded. **Rebuilding is safe:** files you edited
since the last build are kept, and the new version is written next to them as `<file>.new`. `--force` overwrites.

**Share it with members.** After the review, one command builds what members receive:

```bash
skool-kit pack-share member-pack -o share --version 1.0.0 --format project   # or --format skills; both if left out
```

| File | Who gets it |
|---|---|
| `share/<prefix>-member-kit-1.0.0.zip` | Every member: `START-HERE.md` (install steps you can copy, a check, a first-task walkthrough) and one upload zip per skill |
| `share/<prefix>-claude-project-1.0.0.zip` | Members, instead of the skills if you prefer: the same pack as one Claude Project (`INSTRUCTIONS.md` to paste, the lessons and one task guide per skill to upload, and its own `START-HERE.md`) |
| `share/LAUNCH-POST.md` | You: a draft announcement to edit |
| `member-pack/` | You only: the source you edit, your acceptance cases and pilot logs |

Each format gets its own launch post draft. It zips the skills as they are, so your edits are what members get. It refuses a pack with unmerged `.new` files, a
skill whose name doesn't match its folder, or a description over the Claude app's 200 characters. For an update, rebuild,
re-run the acceptance cases, and share with a higher `--version`.

**Skills or a Claude Project?** Both are built from the same reviewed files. In our comparison
(`examples/agency-lab/comparison/`) the Project did at least as well: it has every lesson in every chat, while a
task skill only carries its own task's lessons. Skills suit Claude Code users and Team or Enterprise organisations,
where an owner can provision skills for everyone. A Project suits members on their own plans: one setup, no
code-execution setting, and it works on every plan (Free accounts can have up to five projects).

**Answers you can check.** Every skill cites the lesson sentence it relies on, like
*(Lesson: "Pricing your first offer": "Never go below 300 a month.")*. `check-answer` checks a saved reply against
an acceptance case, answering separate questions for each citation:

```bash
skool-kit check-answer reply.md --pack member-pack --case offer-builder-dropped-qualification
```

1. Does the quote exist in the lessons?
2. Is it in the lesson named?
3. Was a qualification dropped? (the quote is cut from a lesson sentence whose missing part limits it)
4. Does it support the claim? **Not decided by the tool:** it lists each citation beside the sentence it backs,
   for a person.

It also flags numbers that aren't in the lessons, the member's input or the reply's Gaps and assumptions, promise
wording, and the case's own checks, then lists the case's review questions. `examples/agency-lab/verification/`
shows what it catches, and a reply it can't: a true quote used for the wrong conclusion passes every mechanical
check. `check-citations reply.md --skills member-pack` is the quick version (quotes only).

**Evidence.** `examples/agency-lab/live-runs/` has the first 8 runs in Claude Code, `acceptance-journey/` the member
journey from download to install and update, `benchmark/` a blind comparison with a general assistant with and
without the lessons (history: the version before the citation fixes), and `comparison/` the latest version as skills
vs as a Claude Project, over several turns. None of it was run in the Claude app. Do your own acceptance runs in your members' Claude surface
before members see a pack (`ADMIN-REVIEW.md`).

## 6. Pilot report

```bash
skool-kit pilot member-pack/pilot/pilot.yaml --format md -o pilot-report.md
```

Reads the logs you keep during a pilot (`events.csv`: joined, installed, used, task_completed, first_outcome,
renewed, cancelled, refunded, excluded; `questions.csv`; `costs.csv`; `acceptance.csv`) and reports three areas
separately. Only five things are essential: joins, first outcomes, corrected answers, renewals once due, and effort and
cash. The joins come from a member export:

```bash
skool-kit pilot-import member-pack/pilot/pilot.yaml members.csv   # joined rows for both cohorts, by code, no emails
```

An export lists current members only, so take it on the last day of the cohort month and add anyone who already left
from your payment history.

- **Product quality:** acceptance runs passed, share of reviewed tutor answers corrected.
- **Member outcomes:** adoption, completed tasks, and the first-outcome rate within the window, pilot vs baseline
  cohort, with 95% ranges.
- **Economics:** cash and time spent, first-renewal rate per cohort, observed renewal difference minus cash costs,
  optional budget limits.

Members count for the outcome only once their window has closed by `as_of`, and for renewal only once their renewal
date has passed. Members still inside a window are reported as pending, never as failures. The suggestion
(continue, extend, change, stop or change, fix quality first, not enough data) is held back when quality fails or
economics are negative or over budget. It's an observational comparison: it can show a difference, not prove the
pack caused it. Staff time freed is reported as capacity, never as cash. The whole workflow is in `../PILOT.md`.

## 7. Classroom -> AI tutor skill (on its own)

Copy your lessons into folders (one folder per module, numbers set the order; `.md`, `.txt` or `.html` files):

```
lessons/
  01-start-here/01-welcome.md
  01-start-here/02-ai-basics.txt
  02-finding-clients/1 - The offer that sells.html
```

```bash
skool-kit classroom-to-skill examples/classroom --name ai-builders-tutor --community-name "AI Builders" \
  --classroom-url "https://www.skool.com/your-community/classroom" -o skills-out/
```

You get `skills-out/ai-builders-tutor/SKILL.md` (instructions + a lesson index) and
`references/<module>/<lesson>.md`. Long lessons are split into parts, empty files are skipped with a warning,
HTML is turned into clean text. The tutor answers from your lessons, cites lesson titles, links back to your
classroom and says when something isn't covered. Put the folder in `~/.claude/skills/` (Claude Code / Cowork) or
your OpenClaw skills folder, or upload it to Claude.

## Claude skill

`skills/skool-onboarding/SKILL.md` teaches Claude to run the onboarding commands for you.

## Limits

- Skool's export columns and Zapier field names are not documented publicly and could not be verified here;
  that's why every column is matched loosely and can be overridden with `--map`. Run `skool-kit inspect` first.
- A member export only contains current members, so "cohort activity" means "share of each join-month cohort that was
  active in the last 30 days", not cancellations.
- Trends need several weekly exports stacked into an activity file; with a single export the score uses
  last-active date, post counts, level and tenure only.
- The keyword rules are simple and transparent (no AI needed). Review messages before sending them.
- Classroom videos aren't transcribed: paste transcripts or notes into the lesson files.

## Development

```bash
cd skool-owner-kit && ../.venv/bin/python -m pytest -q
```

Tests run offline (the webhook tests use local servers on 127.0.0.1, LLM calls are faked).
