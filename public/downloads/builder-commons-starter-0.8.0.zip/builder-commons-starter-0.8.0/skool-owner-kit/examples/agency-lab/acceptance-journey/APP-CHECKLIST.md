# Claude app check: the one manual run (about 60-90 minutes)

Needs a Claude account on the plan members use. Fill in `app-record-template.md` as you go, with the minutes for
each step. Do the Project first: it's the default format.

1. Download `builder-commons-starter-0.8.0.zip` from the site's Downloads page and compare its sha256 with
   `manifest.json`. Unzip it, then inside the unzipped folder:
   `pip install ./skool-owner-kit`, `cd skool-owner-kit/examples/agency-lab`, and
   `skool-kit pack-share member-pack -o share --version 1.0.0 --format project`
2. Open `share/northwind-claude-project-1.0.0/START-HERE.md` and follow section 1 **exactly**. Record the start
   time, every step that didn't match the screen, and the time when the 15 files are in.
3. Section 2 of START-HERE (the one-minute check): new chat in the project, ask "How do I choose a niche?". The
   reply must quote a lesson like *(Lesson: "...": "...")*.
4. For each case in `member-pack/evals/acceptance.yaml`: open a new chat in the project, send `input`, then each of
   `turns` whatever the reply. Copy the final reply into `<case>.md` without editing it.
5. `skool-kit check-answer <case>.md --pack member-pack --case <case>` for each. Then answer the "For a person to
   decide" questions yourself. A case passes only when both pass.
6. Read the offer-builder example case's final reply as a member would: could you post it after filling in the
   [brackets]?
7. Update: in `classroom/02-your-offer/03-pricing-your-first-offer.md` change "Never go below 300 a month" to 350.
   Run `skool-kit pack-build pack.yaml -o member-pack` and `skool-kit pack-share member-pack -o share --version 1.0.1
   --format project`. Follow START-HERE's "Updates" section, then in a new chat ask "What's the lowest monthly fee I
   can charge?". It must say 350. Undo the lesson change afterwards.
8. Record the model name the app shows, and every intervention: anything you typed that wasn't in the script.

Then the same with `--format skills` (START-HERE in `share/northwind-member-kit-1.0.0/`), if any pilot will use
skills. In step 4, send the input without naming a skill and record which skill the app used.

**Pass:** every case passes, and no START-HERE step needed a correction. Paste the record into
`acceptance-journey/app-record-<date>.md`, and only then change the site's "not yet tested in the Claude app" text.
