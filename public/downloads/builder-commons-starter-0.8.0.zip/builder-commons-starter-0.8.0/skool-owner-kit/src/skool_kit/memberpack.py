"""`skool-kit pack-build`: turn an admin's pack spec and classroom into a ready-to-distribute member pack.

The spec (pack.yaml) names the member outcome the pack is for, and the "playbooks": tasks a member completes
with Claude using the community's own method, step by step, each step tied to a lesson. The build writes:

    member-pack/
      skills/<prefix>-tutor/          lesson-grounded Q&A with citations and a "not covered" route
      skills/<prefix>-<playbook>/     one task skill per playbook, with only the lessons it needs
      evals/cases.yaml                acceptance checks for `skillkit eval`
      evals/acceptance.yaml           every acceptance case in full, for `skool-kit check-answer --case`
      APPROVAL.md                     the one page the owner approves: tasks, rules to confirm, acceptance cases
      MEMBER-START.md                 the member's first-days guide (install, tasks, how to report the outcome)
      ADMIN-REVIEW.md                 what the admin must check before sharing, and a manual acceptance procedure
      pilot/                          pilot plan and empty logs for `skool-kit pilot`

Rebuilding is safe: files the admin edited since the last build are kept, and the new version is written next to
them as <file>.new. Nothing is sent anywhere; no AI call is made.
"""
from __future__ import annotations

import hashlib
import json
import re
import tempfile
from dataclasses import dataclass, field
from pathlib import Path

import yaml

from .classroom import Lesson, SkillError, build_skill, cite_rule, discover, fit_description, slugify, validate_name

MANIFEST = ".skool-kit-pack.json"
CHECK_TYPES = ("contains", "not_contains", "regex", "max_chars", "json_valid", "json_has_keys")


@dataclass
class PackResult:
    out: Path
    skills: list[str]
    written: list[str] = field(default_factory=list)
    unchanged: list[str] = field(default_factory=list)
    kept: list[str] = field(default_factory=list)  # admin-edited files left alone; new version in <file>.new
    warnings: list[str] = field(default_factory=list)


# ---------------------------------------------------------------- spec


def _need(d: dict, key: str, where: str, kind=str):
    value = d.get(key) if isinstance(d, dict) else None
    if value is None or (kind is str and not str(value).strip()):
        raise SkillError(f"{where}: '{key}' is required")
    if kind is list and not isinstance(value, list):
        raise SkillError(f"{where}: '{key}' must be a list")
    return value


def load_spec(path: str | Path) -> tuple[dict, Path]:
    path = Path(path)
    if not path.is_file():
        raise SkillError(f"pack spec not found: {path}")
    try:
        spec = yaml.safe_load(path.read_text(encoding="utf-8"))
    except yaml.YAMLError as exc:
        raise SkillError(f"{path} is not valid YAML: {exc}") from exc
    except UnicodeDecodeError as exc:
        raise SkillError(f"{path} is not saved as UTF-8 text") from exc
    if not isinstance(spec, dict):
        raise SkillError(f"{path} must be a YAML mapping (community:, classroom:, playbooks: ...)")
    _need(spec, "community", "pack spec")
    _need(spec, "classroom", "pack spec")
    outcome = spec.get("first_outcome") or {}
    for key in ("name", "definition", "within_days", "how_to_report"):
        _need(outcome, key, "first_outcome", int if key == "within_days" else str)
    if not isinstance(outcome["within_days"], int) or outcome["within_days"] < 1:
        raise SkillError("first_outcome: 'within_days' must be a whole number of days, at least 1")
    playbooks = _need(spec, "playbooks", "pack spec", list)
    if not playbooks:
        raise SkillError("pack spec: add at least one playbook (a task members complete)")
    seen = set()
    for i, pb in enumerate(playbooks, 1):
        where = f"playbook {i}"
        for key in ("name", "title", "outcome", "when"):
            _need(pb, key, where)
        where = f"playbook '{pb['name']}'"
        if pb["name"] in seen:
            raise SkillError(f"{where}: two playbooks use this name")
        seen.add(pb["name"])
        for key in ("inputs", "steps"):
            if not _need(pb, key, where, list):
                raise SkillError(f"{where}: '{key}' is empty")
        for j, inp in enumerate(pb["inputs"], 1):
            _need(inp, "name", f"{where}, input {j}")
            _need(inp, "ask", f"{where}, input {j}")
        for j, step in enumerate(pb["steps"], 1):
            _need(step, "do", f"{where}, step {j}")
            _need(step, "lesson", f"{where}, step {j}")
        for j, rule in enumerate(pb.get("rules") or [], 1):
            if isinstance(rule, dict):
                _need(rule, "rule", f"{where}, rule {j}")
            elif not isinstance(rule, str):
                raise SkillError(f"{where}, rule {j}: write a sentence, or 'rule:' and 'lesson:'")
        extra = pb.get("extra_cases") or []
        if not isinstance(extra, list):
            raise SkillError(f"{where}: 'extra_cases' must be a list")
        for j, case in enumerate(extra, 1):
            _need(case, "id", f"{where}, extra case {j}")
            _need(case, "input", f"{where}, extra case {j}")
            _need(case, "pass_if", f"{where}, extra case {j}")
            for key in ("review", "turns"):
                if not isinstance(case.get(key) or [], list):
                    raise SkillError(f"{where}, extra case {j}: '{key}' must be a list")
        for check in [c for case in extra for c in case.get("checks") or []] + list(pb.get("checks") or []):
            kinds = [k for k in check if k != "explain"] if isinstance(check, dict) else []
            if len(kinds) != 1 or kinds[0] not in CHECK_TYPES:
                raise SkillError(f"{where}: each check needs exactly one of {', '.join(CHECK_TYPES)} (got {check!r})")
            if kinds[0] == "regex":
                try:
                    re.compile(check["regex"])
                except re.error as exc:
                    raise SkillError(f"{where}: check regex {check['regex']!r} is invalid: {exc}") from exc
    return spec, path.parent


def _key(title: str) -> str:
    return re.sub(r"[^a-z0-9]+", " ", title.casefold()).strip()


def lesson_index(modules) -> dict[str, tuple]:
    """Lesson title (normalised) -> (module, lesson). Also 'module/lesson-slug' paths."""
    index = {}
    for m in modules:
        for lesson in m.lessons:
            index.setdefault(_key(lesson.title), (m, lesson))
            index.setdefault(f"{m.slug}/{lesson.slug}", (m, lesson))
    return index


def find_lesson(index: dict, ref: str, where: str) -> tuple:
    hit = index.get(_key(str(ref))) or index.get(str(ref))
    if hit is None:
        titles = sorted({lesson.title for _, lesson in index.values()})
        raise SkillError(f"{where}: no lesson called {ref!r}. Lessons found: " + "; ".join(titles))
    return hit


# ---------------------------------------------------------------- rendering helpers


def _yaml_front(name: str, description: str) -> str:
    return yaml.safe_dump({"name": name, "description": description}, sort_keys=False, allow_unicode=True,
                          width=100000).strip()


def _cell(text) -> str:
    return str(text).replace("|", "\\|").replace("\n", " ").strip()


def _lesson_files(module, lesson: Lesson) -> list[tuple[str, str]]:
    """(relative path, content) for a lesson's reference file(s), split like the tutor's."""
    total = len(lesson.parts)
    out = []
    for i, part in enumerate(lesson.parts, 1):
        fname = f"{lesson.slug}.md" if total == 1 else f"{lesson.slug}-part-{i}.md"
        heading = lesson.title if total == 1 else f"{lesson.title} (part {i} of {total})"
        body = part
        if (total == 1 or i == 1) and body.startswith("# "):
            body = re.sub(r"^#\s+.+\n+", "", body, count=1)
        out.append((f"references/{module.slug}/{fname}",
                    f"# {heading}\n\nModule: {module.title}\n\n{body.strip()}\n"))
    return out


def describe_check(check: dict) -> str:
    if check.get("explain"):
        return str(check["explain"])
    kind = next(k for k in check if k != "explain")
    value = check[kind]
    if kind == "contains":
        items = value if isinstance(value, list) else [value]
        return "It contains " + ", ".join(f'"{v}"' for v in items) + "."
    if kind == "not_contains":
        items = value if isinstance(value, list) else [value]
        return "It does not contain " + ", ".join(f'"{v}"' for v in items) + "."
    if kind == "regex":
        return f"It matches the pattern `{value}`."
    if kind == "max_chars":
        return f"It is at most {value} characters long."
    if kind == "json_valid":
        return "It is valid JSON."
    return "It is JSON with the keys " + ", ".join(f'"{v}"' for v in value) + "."


def _description(community: str, pb: dict, lessons: list[str]) -> str:
    # Lesson titles are in the body; the description only has to tell Claude when to pick the skill.
    outcome = pb["outcome"] if pb["outcome"][1:2].isupper() else pb["outcome"][0].lower() + pb["outcome"][1:]
    when = f"Use when {pb['when']}."
    return fit_description([
        f"{pb['title']} with the {community} method: {outcome}. {when}",
        f"{pb['title']} with the {community} method. {when}",
        f"{pb['title']}. {when}",
    ])


STANDARD_SECTIONS = ["Check", "Gaps and assumptions", "Next step"]


def _rule_text(rule, refs: dict) -> str:
    if isinstance(rule, dict):
        lesson = refs[str(rule["lesson"])][1].title if rule.get("lesson") else ""
        return f"{rule['rule']}" + (f" *(Lesson: \"{lesson}\")*" if lesson else "")
    return str(rule)


def render_playbook(spec: dict, pb: dict, name: str, refs: dict[str, tuple], has_example: bool) -> str:
    community = spec["community"]
    support = spec.get("support") or "ask in the community"
    channel = (spec.get("support_channel") or support).rstrip(". ")
    outcome = spec["first_outcome"]
    lessons = list(dict.fromkeys(refs[str(s["lesson"])][1].title for s in pb["steps"]))
    minutes = f" It usually takes about {pb['minutes']} minutes." if pb.get("minutes") else ""
    required = [i for i in pb["inputs"] if i.get("required", True)]
    optional = [i for i in pb["inputs"] if not i.get("required", True)]
    deliverable = pb.get("deliverable") or {}
    sections = list(deliverable.get("sections") or [])
    next_action = pb.get("next_action") or f"{outcome['how_to_report']}"
    out = ["---", _yaml_front(name, _description(community, pb, lessons)), "---", "",
           f"# {pb['title']}", "",
           f"You help a member of {community} finish real work: **{pb['outcome']}**. You do the work with them, using "
           f"the {community} method in the lessons below, and end with a deliverable they can edit and use.{minutes}", "",
           "## 1. Get the minimum information", "",
           "Use what the member already gave you. Before you ask for anything, read the lessons for the steps that "
           "use what they gave you, so the same message can point out anything that conflicts with the lessons "
           "(for example a niche, price or promise the lessons rule out). Then ask only for required inputs that are "
           "missing, all in one short message, and wait for the answer. Don't ask for anything else.", "",
           "| Input | Required | Ask | Example |", "|---|---|---|---|"]
    for i in pb["inputs"]:
        req = "yes" if i.get("required", True) else f"no (if missing: {i.get('default', 'say what you assumed')})"
        out.append(f"| {_cell(i['name'])} | {_cell(req)} | {_cell(i['ask'])} | {_cell(i.get('example', ''))} |")
    if not required:
        out.append("")
    if optional:
        out += ["", "For optional inputs, use the default shown and list it under Gaps and assumptions."]
    out += ["", "## 2. Do the work", "",
            "Read the lesson file for each step before you do it, and apply its method, numbers and wording rules "
            "rather than general advice. " + cite_rule(lessons[0]),
            ""]
    for n, step in enumerate(pb["steps"], 1):
        module, lesson = refs[str(step["lesson"])]
        files = ", ".join(f"[{Path(p).name}]({p})" for p, _ in _lesson_files(module, lesson))
        out.append(f"{n}. {str(step['do']).strip()}")
        out.append(f"   - Lesson: \"{lesson.title}\" ({files})")
    out += ["", "## 3. Rules", "",
            "These rules summarise the lessons named after them. When you cite, quote the lesson file, not this list.", ""]
    out += [f"- {_rule_text(r, refs)}" for r in pb.get("rules") or []]
    out += ["- If the member's input conflicts with a rule or a lesson (for example a lower price, a promise, a niche "
            "that fails a filter), don't silently follow it: say which rule or lesson it conflicts with, give the "
            "version that follows the lesson, and note the conflict under Gaps and assumptions.",
            "- Never invent lessons, prices, results, statistics or promises. Every money amount, number, percentage "
            "or claim about how clients or their customers behave must come from the lessons or the member's input. "
            "If you add one anyway (even a common-sense one), list it under Gaps and assumptions as \"verify before "
            "use\", or leave it out. The same goes for numbers the member gives that the lessons don't support.",
            "- Keep three sources apart and say which is which: the lessons (cited), what the member told you "
            "(\"you said\"), and your own suggestions (\"my suggestion, not from the lessons\"). A fact you don't "
            "have is unknown: write \"?\" or [brackets], never a guess. If the deliverable can't be right without it, "
            "ask for it.",
            f"- This skill includes only the lessons for this task; the {community} classroom has others. If something "
            "depends on a lesson not included here (for example a price in an outreach task), don't say the lessons "
            "don't support it: say it's outside this task's lessons and which lesson or skill to check.",
            f"- If the member asks something the lessons don't cover, say \"This isn't covered in the classroom yet\", "
            f"label any suggestion as your own, and write a question for a coach (section 5)."]
    out += ["", "## 4. Deliverable", "",
            "Produce one Markdown document the member can copy and edit, with these `##` headings in this order:", ""]
    out += [f"- {s}" for s in sections]
    out += ["- Check: each item in the checklist below, marked pass or fail, with a one-line reason",
            "- Gaps and assumptions: inputs that were missing and what you assumed, conflicts with the lessons, and any "
            "claim the member must verify before using it. Write \"None\" if there are none",
            "- Next step: one concrete action for today. If any Check item failed or is pending, the next step is to "
            f"resolve it (for example confirm the \"?\" items). Otherwise: {next_action}"]
    if deliverable.get("filename"):
        out += ["", f"If you can create files, also save it as `{deliverable['filename']}`."]
    checks = pb.get("checks") or []
    out += ["", "Checklist (fix anything that fails before you show the deliverable; if you can't fix it, mark it "
            "fail and say why):", ""]
    out += [f"- {describe_check(c)}" for c in checks]
    out += ["- Every recommendation follows the lessons above and cites them with the supporting sentence copied "
            "from the lesson file; nothing is invented.",
            "- Every money amount, number or claim about customer behaviour comes from the lessons or the member, "
            "or is listed under Gaps and assumptions as \"verify before use\"."]
    out += ["", "## 5. If something is unresolved", "",
            f"If the lessons don't cover something the member needs, or a gap blocks the deliverable, end with a "
            f"**Question for a coach**: a short message the member can post in {channel}. Include what they're "
            "working on, the facts that matter (niche, area, the price or numbers involved), the lesson they used and "
            "why it doesn't settle this, what they've already decided, and the exact question, so a coach can answer "
            "without asking back.", "",
            "## When the member is done", "",
            f"This task is part of the member's **{outcome['name']}** ({outcome['definition']}, within "
            f"{outcome['within_days']} days of joining). When they have it, tell them: {outcome['how_to_report']}"]
    if has_example:
        out += ["", "## Example", "",
                "[examples/example-input.md](examples/example-input.md) and "
                "[examples/example-output.md](examples/example-output.md) show one completed run. Follow the lessons, "
                "not the example's specifics."]
    return "\n".join(out).rstrip() + "\n"


def _skill_entries(spec: dict, names: dict[str, str]) -> list[str]:
    rows = [f"| **{names['tutor']}** | Ask anything about the lessons. It answers from the classroom and says which "
            f"lesson to watch. | Any time |"]
    for pb in spec["playbooks"]:
        rows.append(f"| **{names[pb['name']]}** | {_cell(pb['title'])}: {_cell(pb['outcome'])} | "
                    f"{pb.get('minutes', '?')} min |")
    return rows


def _starter_message(pb: dict, skill: str) -> str:
    parts = [f"Use the {skill} skill."]
    for i in pb.get("inputs") or []:
        if i.get("required", True):
            parts.append(f"{i['ask'].strip()} [{i.get('example') or 'your answer'}]")
    return " ".join(parts)


def render_member_start(spec: dict, names: dict[str, str]) -> str:
    """The member's guide. Sent with the upload zips by `skool-kit pack-share` as START-HERE.md."""
    community = spec["community"]
    outcome = spec["first_outcome"]
    channel = (spec.get("support_channel") or "").rstrip(".") or "the community"
    skills = [names["tutor"]] + [names[pb["name"]] for pb in spec["playbooks"]]
    zips = [f"`{s}.zip`" for s in skills]
    sample = ((spec.get("tutor") or {}).get("sample_questions") or [None])[-1]
    out = [f"# {community}: your AI toolkit", "",
           f"{len(skills)} Claude skills built from the {community} classroom. They draft your first work with you, "
           f"following the lessons, toward your **{outcome['name']}**: {outcome['definition']}, within "
           f"{outcome['within_days']} days of joining. You review and edit everything they draft.", "",
           "| Skill | What it helps you make | Time |", "|---|---|---|"] + _skill_entries(spec, names)
    out += ["", "## What you need", "",
            "- A Claude account: claude.ai, the Claude desktop app, or Claude Code.",
            f"- The {len(skills)} files from your admin, one per skill: " + ", ".join(zips) + ".", "",
            "## 1. Install (once, about 5 minutes)", "",
            "**Claude app (claude.ai or desktop):**", "",
            "1. Settings > Capabilities: turn on **Code execution and file creation** (in some layouts: "
            "**Create and edit files**).",
            f"2. Customize > Skills > **+** > **Create skill** > **Upload a skill**. Choose {zips[0]}.",
            "3. Make sure the skill's switch is on.",
            "4. Repeat steps 2 and 3 for " + " and ".join(zips[1:]) + ".", "",
            "On a Team or Enterprise plan your admin may have added the skills for everyone: look in Customize > "
            "Skills first.", "",
            "**Claude Code:** put each zip in one folder, open a terminal there, and run:", "",
            "```bash", "mkdir -p ~/.claude/skills"]
    out += [f"unzip -o {s}.zip -d ~/.claude/skills/" for s in skills]
    out += ["```", "", "Windows (PowerShell):", "", "```powershell"]
    out += [f'Expand-Archive -Force {s}.zip "$env:USERPROFILE\\.claude\\skills"' for s in skills]
    out += ["```", "", f"You should now have `~/.claude/skills/{skills[0]}/SKILL.md`. Start a new Claude Code "
            "session; `/skills` lists them.", "",
            "## 2. Check it works (1 minute)", ""]
    if sample:
        out += [f"Start a new chat and ask: *\"{sample['question']}\"*", "",
                f"The answer should name a lesson, like *(Lesson: \"{sample['lesson']}\")*. If it doesn't, ask "
                f"again starting with \"Use the {names['tutor']} skill:\". If Claude says it has no such skill, go "
                "back to step 1.", ""]
    else:
        out += [f"Start a new chat and ask: *\"Use the {names['tutor']} skill: how do I get started?\"* The answer "
                "should name a lesson.", ""]
    out += ["## 3. Your first tasks", ""]
    for n, pb in enumerate(spec["playbooks"], 1):
        skill = names[pb["name"]]
        sections = (pb.get("deliverable") or {}).get("sections") or []
        out += [f"### {n}. {pb['title']} ({pb.get('minutes', '?')} min)", "",
                "Paste this into a new chat, replacing the parts in [brackets]:", "",
                "> " + _starter_message(pb, skill), "",
                "What you get: a draft you can copy and edit"
                + (f", with the sections {', '.join(sections)}" if sections else "")
                + ", then a **Check** of the draft against the lessons, **Gaps and assumptions**, and a **Next step**.",
                "",
                "Before you use it: read Gaps and assumptions first, and check or remove anything marked "
                "\"verify before use\". The check is Claude reviewing its own draft against the lessons; it can "
                "miss things.", ""]
    out += [f"## 4. Report your {outcome['name']}", "", outcome["how_to_report"], "",
            "## When the lessons don't cover something", "",
            "The skill says it isn't covered and drafts a short question for you. Copy it and post it in "
            f"{channel}; the skill can't post it for you.", "",
            "## Updates", "",
            "When your admin shares a new version: in the Claude app, delete the old skill (Customize > Skills) and "
            "upload the new zip. In Claude Code, run the same unzip commands again.", "",
            "## Good to know", "",
            "- The skills run in your own Claude account. Nothing is sent to the community; Claude's own data terms "
            "apply.",
            "- Check anything before you send it to a client. You are responsible for what you send.",
            f"- Not sure where to begin? Start with task 1."]
    return "\n".join(out).rstrip() + "\n"


STOPWORDS = {"the", "and", "you", "your", "one", "write", "with", "for", "that", "this", "when", "only", "don't",
             "not", "are", "any", "each", "from", "their", "they", "them", "what", "where", "who", "it's", "its",
             "say", "says", "member", "member's", "lesson", "lessons", "than", "then", "more", "have", "has"}


def _closest_sentences(rule: str, lesson_text: str) -> tuple[list[str], float]:
    """For each sentence of the rule, the lesson sentence sharing most of its words (headings skipped), and the
    share of the rule's words those sentences cover."""
    words = lambda t: {w for w in re.findall(r"[a-z0-9']+", t.lower()) if len(w) > 2} - STOPWORDS
    lesson = []
    for line in lesson_text.splitlines():
        if line.lstrip().startswith("#") or not line.strip():
            continue
        line = re.sub(r"^[>\s]*(?:[-*]|\d+\.)?\s*", "", line).replace("**", "").strip(" |")
        line = re.sub(r"\s*\|\s*", ", ", line)
        lesson += [x for x in re.split(r"(?<=[.!?])\s+", line) if x]
    found, covered, want_all = [], set(), words(rule)
    for part in re.split(r"(?<=[.!?;])\s+", rule):
        want = words(part)
        if not want:
            continue
        best = max(lesson, key=lambda x: len(want & words(x)), default="")
        if best and len(want & words(best)) / len(want) >= 0.25:
            covered |= want & words(best)
            if best not in found:
                found.append(best)
    return found[:3], len(covered) / (len(want_all) or 1)


def rule_review(spec: dict, refs: dict) -> tuple[list[dict], list[dict]]:
    """(rules to confirm, rules copied word for word). A rule to confirm is paraphrased from its lesson or names
    none; it carries the closest lesson sentence so the owner can compare without opening the lesson."""
    from .citations import normalise
    unsure, exact = [], []
    for pb in spec["playbooks"]:
        for rule in pb.get("rules") or []:
            text = rule["rule"] if isinstance(rule, dict) else str(rule)
            lesson_ref = rule.get("lesson") if isinstance(rule, dict) else None
            item = {"task": pb["name"], "rule": text, "lesson": "", "closest": [], "why": "names no lesson"}
            if lesson_ref:
                lesson = refs[str(lesson_ref)][1]
                body = "\n".join(lesson.parts)
                item["lesson"] = lesson.title
                if normalise(text) in normalise(body):
                    exact.append(item)
                    continue
                item["closest"], score = _closest_sentences(text, body)
                item["why"] = ("reworded from the lesson" if score >= 0.5 else
                               "partly in the lesson, partly added" if score >= 0.25 else
                               "no close sentence found: compare with the lesson, or it may be our addition")
            unsure.append(item)
    return unsure, exact


def _rules_to_confirm(spec: dict, refs: dict) -> list[str]:
    """The rules a member's answers will follow that aren't word for word in a lesson, for the owner to check first."""
    unsure, exact = rule_review(spec, refs)
    total = len(unsure) + len(exact)
    head = ["", "### Rules to confirm first", ""]
    if not unsure:
        return head + [f"All {total} rules are copied word for word from the lessons they name."]
    lines = []
    for r in unsure:
        if not r["lesson"]:
            lines.append(f"- [ ] {r['task']}: \"{r['rule']}\" names no lesson. Is it how you teach it?")
        else:
            lines.append(f"- [ ] {r['task']}: \"{r['rule']}\" is not word for word in \"{r['lesson']}\" "
                         f"({r['why']}). Does the lesson say this, or is it your own rule (then say so)?")
    return head + [f"{len(unsure)} of {total} rules are paraphrased or added. Members' answers will follow them, so "
                   "check each against the lesson (APPROVAL.md shows the closest lesson sentence next to each):",
                   ""] + lines


def render_approval(spec: dict, names: dict[str, str], refs: dict) -> str:
    """One sheet the owner approves instead of reading every generated file."""
    unsure, exact = rule_review(spec, refs)
    outcome = spec["first_outcome"]
    cell = lambda t: _cell(t)
    out = [f"# Approve the {spec['community']} member kit", "",
           "Generated by `skool-kit pack-build`. This page is what you approve. You don't need to open the generated "
           "files: everything that needs your judgement is here, and the rest is checked automatically or in the "
           "acceptance cases.", "",
           "## 1. What members get", "",
           f"Member outcome: **{outcome['name']}**: {outcome['definition']}, within {outcome['within_days']} days.", "",
           "| Task | The member gives | The member gets | Lessons used |", "|---|---|---|---|",
           f"| Tutor ({names['tutor']}) | A question | An answer quoting the lesson it relies on, or \"not covered\" and "
           "a question for a coach | All lessons in scope |"]
    for pb in spec["playbooks"]:
        used = "; ".join(dict.fromkeys(refs[str(s['lesson'])][1].title for s in pb["steps"]))
        gives = "; ".join(i["ask"] for i in pb["inputs"])
        out.append(f"| {cell(pb['title'])} ({names[pb['name']]}) | {cell(gives)} | {cell(pb['outcome'])} | "
                   f"{cell(used)} |")
    out += ["", "- [ ] These are the tasks members should use it for. Anything else gets \"not covered\" and goes to "
            f"{spec.get('support_channel') or spec.get('support') or 'your support channel'}.",
            "- [ ] Format: Claude Project (default: members on their own Claude plans) / skills (Claude Code, or a Team "
            "or Enterprise organisation). Chosen: ______", "",
            f"## 2. Rules to confirm ({len(unsure)} of {len(unsure) + len(exact)})", "",
            "These rules aren't word for word in a lesson. Members' answers follow them, so they are where the kit is "
            "most likely to say something you don't teach. Tick one box per rule.", ""]
    for n, r in enumerate(unsure, 1):
        out += [f"**{n}. {r['task']}**: {r['rule']}", "",
                f"- Lesson: {r['lesson'] or 'none named'} ({r['why']})"]
        out += [f"- Closest lesson sentence: \"{c}\"" for c in r["closest"]] or (
            ["- No similar sentence in the lesson."] if r["lesson"] else [])
        out += ["- [ ] The lesson says this  - [ ] My rule, keep it  - [ ] Change it to: ______", ""]
    if not unsure:
        out += ["None.", ""]
    out += [f"## 3. Rules copied word for word ({len(exact)})", "",
            "No action needed: these are the lessons' own sentences."]
    out += [f"- {r['task']}: {r['rule']}" for r in exact] or ["- None."]
    cases = yaml.safe_load(build_acceptance(spec, names))["cases"]
    out += ["", f"## 4. Acceptance cases ({len(cases)})", "",
            "We run each in the Claude app in the chosen format before any member sees the kit. A case passes only "
            "when its automatic checks pass and a person agrees with the review questions.", "",
            "| Case | Member says | Passes if |", "|---|---|---|"]
    out += [f"| {c['id']} | {cell(c['input'])} | {cell(c['pass_if'])} |" for c in cases]
    out += ["", "- [ ] These cases test what matters to me. Add any question members often get wrong: ______", "",
            "## Sign-off", "", "Approved by: ______  Date: ______", ""]
    return "\n".join(out)


def render_admin_review(spec: dict, names: dict[str, str], refs: dict, warnings: list[str]) -> str:
    community = spec["community"]
    out = [f"# Before you share the {community} member pack", "",
           "Generated by `skool-kit pack-build`. If you're the owner, start with **APPROVAL.md**: it's the one page "
           "to approve, with everything that needs your judgement. This file is the full procedure for whoever builds "
           "and tests the kit.", "",
           "## 1. Read each skill", ""]
    out.append(f"- [ ] **{names['tutor']}**: the lesson index lists every lesson members should be able to ask about.")
    for pb in spec["playbooks"]:
        used = list(dict.fromkeys(refs[str(s['lesson'])][1].title for s in pb["steps"]))
        out.append(f"- [ ] **{names[pb['name']]}**: each step points at the right lesson ({'; '.join(used)}), "
                   "the rules match how you teach it, and nothing promises results you can't stand behind.")
    out += _rules_to_confirm(spec, refs)
    out += ["", "## 2. Run the automatic checks", "", "```bash",
            "skillkit lint skills",
            "skillkit eval skills --cases evals/cases.yaml --provider fake        # shows the checks on the examples",
            "skillkit eval skills --cases evals/cases.yaml --provider anthropic   # real answers, needs ANTHROPIC_API_KEY",
            "```", "",
            "`--provider fake` only replays the example answers in `evals/cases.yaml`: it proves the checks work, not "
            "that the skills do. The real run sends each skill's instructions and one test message to the model; it "
            "doesn't read reference files or run tools, so also do step 3.", "",
            "## 3. Manual acceptance (the real test)", "",
            "For each case: set the kit up in the Claude surface your members use, start a new chat, paste the test "
            "input below (and any later turns in `evals/acceptance.yaml`), and save the final reply. Then run "
            "`skool-kit check-answer reply.md --pack . --case <id>`: it checks each quote exists, is in the lesson "
            "named and keeps its qualification, flags unsourced numbers and promises, and lists the questions a person "
            "must still answer. A case passes only when both are done. Record each run in `pilot/acceptance.csv`. "
            "The full list of cases, including those added in pack.yaml, is in `evals/acceptance.yaml`.", "",
            "| Skill | Test input | Pass if |", "|---|---|---|"]
    for q in (spec.get("tutor") or {}).get("sample_questions") or []:
        out.append(f"| {names['tutor']} | {_cell(q['question'])} | Answers from \"{_cell(q['lesson'])}\" and cites it |")
    for q in (spec.get("tutor") or {}).get("not_covered") or []:
        out.append(f"| {names['tutor']} | {_cell(q['question'])} | Says it isn't covered and points to support |")
    for pb in spec["playbooks"]:
        test = (pb.get("example") or {}).get("input") or "Your own realistic example"
        checks = " ".join(describe_check(c) for c in pb.get("checks") or []) or "A member could use it as is"
        out.append(f"| {names[pb['name']]} | {_cell(test)} | {_cell(checks)} A member could use it with light edits. |")
        for extra in pb.get("extra_cases") or []:
            out.append(f"| {names[pb['name']]} | {_cell(extra['input'])} | {_cell(extra['pass_if'])} |")
    kit = f"{spec.get('skill_prefix') or slugify(community)}-member-kit"
    out += ["", "## 4. Package and share", "", "```bash",
            "skool-kit pack-share . -o ../share --version 1.0.0", "```", "",
            "| File | Who gets it |", "|---|---|",
            f"| `../share/{kit}-1.0.0.zip` | Every member. It holds `START-HERE.md` (this pack's `MEMBER-START.md`) "
            "and one upload zip per skill. You can attach that zip, or the files in the folder next to it |",
            "| `../share/LAUNCH-POST.md` | You: a draft announcement to edit and post |",
            "| This folder (`skills/`, `evals/`, `pilot/`) | You only. It's the source you edit and rebuild, plus your "
            "acceptance cases and pilot logs |", "",
            "Then start the pilot (`pilot/README.md`).", "",
            "## 5. When you change a lesson", "",
            "1. Run `skool-kit pack-build` again. Files you edited are kept and the new version is written next to "
            "them as `<file>.new`; compare and merge.",
            "2. Re-run the acceptance cases in step 3 for the skills that changed.",
            "3. Run `skool-kit pack-share` with a higher `--version` and tell members to replace the old skills "
            "(START-HERE.md has the steps)."]
    if warnings:
        out += ["", "## Build warnings", ""] + [f"- {w}" for w in warnings]
    return "\n".join(out).rstrip() + "\n"


def build_cases(spec: dict, names: dict[str, str], base: Path) -> str:
    cases = []
    tutor = spec.get("tutor") or {}
    for i, q in enumerate(tutor.get("sample_questions") or [], 1):
        case = {"skill": names["tutor"], "id": f"tutor-question-{i}", "input": q["question"],
                "assert": [{"contains": q["lesson"]}]}
        if q.get("example_answer"):
            case["fake_response"] = q["example_answer"]
        cases.append(case)
    for i, q in enumerate(tutor.get("not_covered") or [], 1):
        case = {"skill": names["tutor"], "id": f"tutor-not-covered-{i}", "input": q["question"],
                "assert": [{"regex": r"(?i)(isn't|is not|not) covered"}]}
        if q.get("example_answer"):
            case["fake_response"] = q["example_answer"]
        cases.append(case)
    for pb in spec["playbooks"]:
        ex = pb.get("example") or {}
        if not ex.get("input"):
            continue
        case = {"skill": names[pb["name"]], "id": f"{pb['name']}-example", "input": ex["input"],
                "assert": [{k: v for k, v in c.items() if k != "explain"} for c in pb.get("checks") or []]}
        if ex.get("output_file"):
            case["fake_response"] = (base / ex["output_file"]).read_text(encoding="utf-8")
        cases.append(case)
    unrecorded = 0
    for pb in spec["playbooks"]:
        for extra in pb.get("extra_cases") or []:
            if not extra.get("output_file"):
                unrecorded += 1  # no recorded answer to replay; it's in evals/acceptance.yaml
                continue
            case = {"skill": names[pb["name"]], "id": f"{pb['name']}-{extra['id']}", "input": extra["input"],
                    "assert": [{k: v for k, v in c.items() if k != "explain"} for c in extra.get("checks") or []],
                    "fake_response": (base / extra["output_file"]).read_text(encoding="utf-8")}
            cases.append(case)
    more = (f"# {unrecorded} more case(s) with no recorded answer yet are in evals/acceptance.yaml: run those in the\n"
            "# Claude app and check them with `skool-kit check-answer`.\n") if unrecorded else ""
    head = (f"# Acceptance checks for the {spec['community']} member pack (generated by skool-kit pack-build).\n"
            "# Real run, a few API calls per case:  skillkit eval skills --cases evals/cases.yaml --provider anthropic\n"
            "# Demo run (replays the hand-written example answers below; proves the checks, not the skills):\n"
            "#   skillkit eval skills --cases evals/cases.yaml --provider fake\n" + more)
    return head + yaml.safe_dump({"provider": "fake", "cases": cases}, sort_keys=False, allow_unicode=True, width=110)


def build_acceptance(spec: dict, names: dict[str, str]) -> str:
    """Every acceptance case in full (later turns, pass criteria, checks and what a person must judge), for
    `skool-kit check-answer --case`. evals/cases.yaml keeps only what skillkit eval runs."""
    cases = []
    tutor = spec.get("tutor") or {}
    for i, q in enumerate(tutor.get("sample_questions") or [], 1):
        cases.append({"id": f"tutor-question-{i}", "skill": names["tutor"], "input": q["question"],
                      "pass_if": f"Answers from \"{q['lesson']}\" and cites it",
                      "checks": [{"contains": q["lesson"], "explain": f"Names \"{q['lesson']}\"."}]})
    for i, q in enumerate(tutor.get("not_covered") or [], 1):
        cases.append({"id": f"tutor-not-covered-{i}", "skill": names["tutor"], "input": q["question"],
                      "pass_if": "Says it isn't covered and points to support",
                      "checks": [{"regex": r"(?i)(isn't|is not|not) covered", "explain": "Says it isn't covered."}]})
    for pb in spec["playbooks"]:
        ex = pb.get("example") or {}
        if ex.get("input"):
            cases.append({"id": f"{pb['name']}-example", "skill": names[pb["name"]], "input": ex["input"],
                          "pass_if": "The deliverable passes its checklist and a member could use it with light edits",
                          "checks": list(pb.get("checks") or [])})
        for extra in pb.get("extra_cases") or []:
            case = {"id": f"{pb['name']}-{extra['id']}", "skill": names[pb["name"]], "input": extra["input"]}
            if extra.get("turns"):
                case["turns"] = list(extra["turns"])
            case.update({"pass_if": extra["pass_if"], "checks": list(extra.get("checks") or [])})
            if extra.get("review"):
                case["review"] = list(extra["review"])
            cases.append(case)
    head = (f"# Acceptance cases for the {spec['community']} member kit (generated by skool-kit pack-build).\n"
            "# Run each in the Claude app in a new chat, send `turns` in order whatever the reply, save the final\n"
            "# reply, then: skool-kit check-answer reply.md --pack . --case <id>\n"
            "# The checks are deterministic; `review` is what a person must decide before the case passes.\n")
    return head + yaml.safe_dump({"cases": cases}, sort_keys=False, allow_unicode=True, width=110)


def pilot_files(spec: dict) -> dict[str, str]:
    outcome = spec["first_outcome"]
    plan = f"""# Pilot plan for the {spec['community']} member pack. Fill in the dates and numbers before you start.
# Read pilot/README.md first. `skool-kit pilot pilot/pilot.yaml` turns the three logs into a report.
pilot: {spec['community']} member pack pilot
outcome: {outcome['name']}              # {outcome['definition']}
outcome_event: first_outcome            # the event name you log in events.csv
within_days: {outcome['within_days']}            # members count for the outcome only once this window has closed
renewal_after_days: 30                  # first renewal date; members not yet due are left out, not counted as lost
as_of: 2027-01-31                       # the date your logs are complete up to; update it every time you report
pilot_cohort:     {{joined_from: 2026-12-01, joined_to: 2026-12-31}}   # new paid members who get the pack
baseline_cohort:  {{joined_from: 2026-10-01, joined_to: 2026-10-31}}   # earlier members who didn't
membership_price: 0          # what a member pays per month
platform_fee_pct: 0          # your platform's transaction fee, in percent
# Decide these BEFORE the pilot starts.
thresholds:
  min_cohort: 20             # fewer members than this whose window has closed: not enough data to decide
  min_adoption_pct: 40       # share of pilot members who install the pack
  continue_if_lift_pts: 10   # outcome rate at least this many points above baseline: continue
  stop_if_lift_pts: 0        # outcome rate no better than baseline: stop or change
  min_acceptance_pct: 100    # acceptance runs that must pass (acceptance.csv)
  max_correction_pct: 10     # tutor answers you had to correct, as a share of tutor answers you reviewed
  # max_cash_costs: 0        # optional budget limits; going over blocks a "continue"
  # max_effort_hours: 0
"""
    readme = f"""# Pilot: does the member pack help new members reach their {outcome['name']}?

Run it for at least one full cohort (members who join in one month) and {outcome['within_days']} days after the
last of them joins. Everything stays in these files on your computer.

## What to log: the essentials

Five things, and nothing collected from members' chats:

1. **Who joined** (both cohorts): `skool-kit pilot-import pilot/pilot.yaml members.csv` with your community's member
   export. It adds a `joined` row per member, logged by a code instead of an email. An export lists current members
   only, so take it on the last day of the cohort month, and add anyone who has already left from your payment history.
2. **First outcomes**: `first_outcome` on the day a member reports it.
3. **Corrected answers**: one row in `questions.csv` whenever someone has to correct the kit.
4. **Renewals**: `renewed` or `cancelled` from your payment history, only once each member's renewal date has passed.
5. **Effort and cash**: time rows by activity and every payment, in `costs.csv` (whoever delivers the pilot keeps it).

Everything else below is optional: log it only when you can see it without asking every member.

**events.csv**, one row per event. Use the code `pilot-import` gave the member (`skool-kit pilot-import
pilot/pilot.yaml --code <email>` prints it), or any ID you like. Events:

| event | Log it when |
|---|---|
| joined | A paid member joins (every member needs this row) |
| installed | A pilot member tells you, or you see, that they installed the skills |
| used | A member reports using a skill |
| task_completed | A member shows a finished deliverable (put the task name, e.g. offer-builder, in `note`) |
| first_outcome | The member reports their {outcome['name']}: {outcome['definition']} |
| renewed | The member's first renewal payment went through |
| cancelled | The member cancelled before or at the first renewal |
| refunded | The member got a refund |
| excluded | Leave this member out (for example a refund during a trial, a test account); say why in `note` |

For the baseline cohort, fill in `joined`, `first_outcome`, `renewed`, `cancelled` from your records
(for example #firstwin posts and your platform's payment history).

**questions.csv**: member questions you looked at during the pilot. `handled_by` is `tutor` (a member said the
tutor answered it, or you checked a tutor answer) or `staff`. `result` is `resolved`, `corrected` (the tutor was
wrong or incomplete and someone fixed it) or `escalated`. `staff_minutes` is the time staff spent on it.

**acceptance.csv**: one row per acceptance run before launch (`passed` is yes or no; `surface` is where it ran, for
example "Claude app, Pro"). The report won't suggest
continuing until these are recorded and pass.

**costs.csv**: every cost of running the pilot. `kind` is `cash` (money spent: implementation fee, API, software)
or `time` (minutes of your or your team's time). For time, name `item` after the activity (intake, spec, review,
acceptance, onboarding, logging, corrections, maintenance) and put who did it in `note` (owner, staff or us): the first
pilots replace the published effort estimates with these minutes.

## Read the result

```bash
skool-kit pilot pilot/pilot.yaml --format md -o pilot-report.md
```

The report judges three things separately: **product quality** (acceptance runs, corrected answers), **member
outcomes** (adoption, completed tasks, the first outcome within its window, pilot vs baseline) and **economics**
(cash and time spent, the observed first-renewal difference). Members whose window or renewal date hasn't arrived
by `as_of` are left out, not counted as failures. A good outcome result is held back if quality fails or the
economics are negative or over budget.

It compares cohorts; it does not prove cause: the pilot month can differ in season, marketing or price.
Small cohorts give wide ranges; the report says when there isn't enough data to decide.
"""
    days = outcome["within_days"]
    checklist = f"""# Pilot operating checklist: {spec['community']}

One page to run the pilot from. Windows and thresholds come from `pilot.yaml`; set them there once. Product quality,
member outcomes and economics are judged separately: a good number in one never makes up for a failure in another.

## Before launch

- [ ] **Fit and scope**: the fit questions answered; one first outcome ({outcome['name']}: {outcome['definition']}); the
      supported tasks listed; the lessons the pack may use chosen.
- [ ] **Content intake**: those lessons as you have them (exports, transcripts or notes); two or three examples of good
      member work.
- [ ] **Format**: a Claude Project (default when members use Claude on their own plans) or skills (Claude Code users,
      or a Team or Enterprise organisation), chosen and written down with the reason.
- [ ] **Approval**: `skool-kit pack-build`, then the owner signs APPROVAL.md: the tasks, every rule listed to confirm
      (each shown beside its closest lesson sentence) and the acceptance cases.
- [ ] **Baseline**: an earlier month of new paid members with no launch, sale or price change, logged in `events.csv`
      the same way the pilot will be (joined, {outcome['name']}, first renewal or cancellation).
- [ ] **Thresholds** in `pilot.yaml`, agreed in writing before the first pilot member joins.
- [ ] **Acceptance**: every case in `evals/acceptance.yaml` run in the Claude app in the chosen format, in new chats,
      with its later turns; each final reply saved and checked with `skool-kit check-answer reply.md --pack .
      --case <id>`, and its review questions answered by a person. One row each in `acceptance.csv` (surface and plan
      in `surface`). Fix and re-run failures before launch.
- [ ] **Installation**: `skool-kit pack-share --format project` (or `skills`); set the kit up yourself by following its
      START-HERE.md exactly, and note any step that didn't match.

## During the pilot month

- [ ] **Member onboarding**: every new paid member gets the kit and START-HERE.md on the day they join.
- [ ] **Joins**: on the last day of the month, `skool-kit pilot-import` with a member export; add anyone who already
      left from your payment history.
- [ ] Optional: `installed` and `task_completed` (task in `note`), only when you can see them without asking.
- [ ] **{outcome['name']}**: log `first_outcome` on the day it's reported. It counts only within {days} days of joining.
- [ ] **Answer corrections**: in `questions.csv`, every answer someone had to correct (`corrected`), with staff
      minutes. Reviewing other answers is optional.
- [ ] **Staff effort and cash costs**: every hour and every payment in `costs.csv`, including your own time, with the
      activity as `item`.

- [ ] **Halfway**: run `skool-kit pilot pilot/pilot.yaml` to check the logs are complete; fix gaps now, not later.

## After the pilot month

- [ ] **Outcome window**: {days} days after the last pilot member joined, set `as_of` and run the report.
- [ ] **Renewal follow-up**: after each member's first renewal date (`renewal_after_days` after joining), log
      `renewed` or `cancelled`. Members not yet due are left out, never counted as lost.
- [ ] **Final customer report**: `skool-kit pilot pilot/pilot.yaml --format md -o pilot-report.md`, read with the
      three verdicts side by side, then decide: continue, extend, change or stop.

## What the report can't tell you

- Two cohorts of a few dozen members can only show large differences; the report gives 95% ranges and says when there
  isn't enough data.
- It compares months, so season, marketing and who joined also change the result. It can't prove cause.
- Self-reported outcomes undercount; log both cohorts the same way.
- Time freed is capacity, not cash, unless you cut paid hours.
"""
    return {
        "pilot/pilot.yaml": plan,
        "pilot/CHECKLIST.md": checklist,
        "pilot/README.md": readme,
        "pilot/events.csv": "member,event,date,note\n",
        "pilot/questions.csv": "date,topic,handled_by,result,staff_minutes,note\n",
        "pilot/costs.csv": "date,item,kind,amount,minutes,note\n",
        "pilot/acceptance.csv": "date,skill,test,surface,passed,reviewer,note\n",
    }


# ---------------------------------------------------------------- build


def plan_pack(spec_path: str | Path, max_chars: int = 12000) -> tuple[dict[str, str], list[str], list[str]]:
    """Return ({relative path: content}, skill names, warnings) without writing anything."""
    spec, base = load_spec(spec_path)
    community = spec["community"]
    prefix = spec.get("skill_prefix") or slugify(community)
    names = {"tutor": validate_name(f"{prefix}-tutor")}
    for pb in spec["playbooks"]:
        names[pb["name"]] = validate_name(f"{prefix}-{slugify(str(pb['name']))}")
    if len(set(names.values())) != len(names):
        raise SkillError("two skills would get the same name; rename a playbook")
    classroom = base / spec["classroom"]
    modules, warnings = discover(classroom, max_chars)
    index = lesson_index(modules)
    refs: dict[str, tuple] = {}
    for pb in spec["playbooks"]:
        for n, step in enumerate(pb["steps"], 1):
            refs[str(step["lesson"])] = find_lesson(index, step["lesson"], f"playbook '{pb['name']}', step {n}")
        for n, rule in enumerate(pb.get("rules") or [], 1):
            if isinstance(rule, dict) and rule.get("lesson"):
                refs[str(rule["lesson"])] = find_lesson(index, rule["lesson"], f"playbook '{pb['name']}', rule {n}")
    for q in (spec.get("tutor") or {}).get("sample_questions") or []:
        _need(q, "question", "tutor sample question")
        find_lesson(index, _need(q, "lesson", "tutor sample question"), f"tutor question {q['question']!r}")
    for q in (spec.get("tutor") or {}).get("not_covered") or []:
        _need(q, "question", "tutor not_covered question")

    files: dict[str, str] = {}
    with tempfile.TemporaryDirectory() as tmp:
        build_skill(classroom, names["tutor"], tmp, community, spec.get("classroom_url") or "", max_chars,
                    support=spec.get("support") or "", support_channel=spec.get("support_channel") or "")
        root = Path(tmp) / names["tutor"]
        for p in sorted(root.rglob("*")):
            if p.is_file():
                files[f"skills/{names['tutor']}/{p.relative_to(root).as_posix()}"] = p.read_text(encoding="utf-8")
    for pb in spec["playbooks"]:
        name = names[pb["name"]]
        ex = pb.get("example") or {}
        has_example = bool(ex.get("input") and ex.get("output_file"))
        files[f"skills/{name}/SKILL.md"] = render_playbook(spec, pb, name, refs, has_example)
        for step in pb["steps"]:
            module, lesson = refs[str(step["lesson"])]
            for rel, content in _lesson_files(module, lesson):
                files[f"skills/{name}/{rel}"] = content
        if has_example:
            out_file = base / ex["output_file"]
            if not out_file.is_file():
                raise SkillError(f"playbook '{pb['name']}': example output file not found: {out_file}")
            files[f"skills/{name}/examples/example-input.md"] = str(ex["input"]).strip() + "\n"
            files[f"skills/{name}/examples/example-output.md"] = out_file.read_text(encoding="utf-8")
        elif not pb.get("checks"):
            warnings.append(f"playbook '{pb['name']}' has no example and no checks: add both so you can test it")
    files["evals/cases.yaml"] = build_cases(spec, names, base)
    files["evals/acceptance.yaml"] = build_acceptance(spec, names)
    files["MEMBER-START.md"] = render_member_start(spec, names)
    files["ADMIN-REVIEW.md"] = render_admin_review(spec, names, refs, warnings)
    files["APPROVAL.md"] = render_approval(spec, names, refs)
    files.update(pilot_files(spec))
    return files, list(names.values()), warnings


def _hash(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def write_pack(files: dict[str, str], out: str | Path, force: bool = False) -> PackResult:
    out = Path(out)
    manifest_path = out / MANIFEST
    previous = {}
    if manifest_path.is_file():
        try:
            previous = json.loads(manifest_path.read_text(encoding="utf-8")).get("files", {})
        except (ValueError, AttributeError):
            previous = {}
    elif out.exists() and any(out.iterdir()) and not force:
        raise SkillError(f"{out} already exists and wasn't made by pack-build; choose another folder or use --force")
    result = PackResult(out, [])
    recorded = {}
    for rel, content in sorted(files.items()):
        target = out / rel
        new_hash = _hash(content)
        if target.is_file():
            current = target.read_text(encoding="utf-8", errors="replace")
            if current == content:
                result.unchanged.append(rel)
                recorded[rel] = new_hash
                continue
            edited = previous.get(rel) != _hash(current)
            if edited and not force:
                # The admin changed this file since the last build: keep it, offer the new version beside it.
                target.with_name(target.name + ".new").write_text(content, encoding="utf-8")
                result.kept.append(rel)
                recorded[rel] = previous.get(rel, "")
                continue
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(content, encoding="utf-8")
        result.written.append(rel)
        recorded[rel] = new_hash
    for rel in sorted(set(previous) - set(files)):
        if (out / rel).exists():
            result.warnings.append(f"{rel} is no longer generated; delete it if you don't need it")
    manifest_path.parent.mkdir(parents=True, exist_ok=True)
    manifest_path.write_text(json.dumps({"tool": "skool-kit pack-build", "files": recorded}, indent=2) + "\n",
                             encoding="utf-8")
    return result


def build_pack(spec_path: str | Path, out: str | Path, force: bool = False, max_chars: int = 12000) -> PackResult:
    files, names, warnings = plan_pack(spec_path, max_chars)
    result = write_pack(files, out, force)
    result.skills = names
    result.warnings = warnings + result.warnings
    return result


def list_lessons(spec_path: str | Path) -> list[str]:
    spec, base = load_spec(spec_path)
    modules, _ = discover(base / spec["classroom"])
    return [f"{m.title} / {lesson.title}" for m in modules for lesson in m.lessons]
