# Pilot workflow

> **The paid pilot is now member-work review: see [REVIEW-PILOT.md](REVIEW-PILOT.md).** This page covers the member
> kit, which stays free to build and run yourself.

How to find out, with a first customer, whether a member pack helps new members reach their first outcome, and
whether that's worth what it costs. `skool-kit pack-build` writes the plan and empty logs into `member-pack/pilot/`;
`skool-kit pilot member-pack/pilot/pilot.yaml` turns them into the decision report. Nothing is tracked
automatically: the owner logs what happens, in plain CSV files on their own computer.

Scope and deliverables of the paid version: [PILOT-OFFER.md](PILOT-OFFER.md). Time estimates: [EFFORT.md](EFFORT.md).

## Before you start: is this a fit?

Several "poor fit" answers mean: don't pay for a pilot; try the free tools, or skip it.

| Question | Answer that signals a poor fit |
|---|---|
| What outcome do you promise new members early on, and how do you know someone reached it? | No clear outcome, or no way to see it |
| How many new paid members join per month, at what price, and what share make their first renewal? | Under about 20 a month (too few to measure); the calculator says payback is unlikely with your price, adoption and baseline; renewal above 90% |
| Do your lessons contain a method members can follow step by step? | Mostly motivation, or video without transcripts |
| Which AI tools do your members use? | Mostly ChatGPT and unwilling to use Claude |
| How many hours a week go into answering the same questions? | Under an hour |
| Who will review the skills and update them when lessons change? | Nobody |
| Can you log first outcomes and renewals per member for two cohorts? | No |
| Would you include the pack in membership or sell it separately? | Separately: no evidence yet that members pay extra; test that on its own |

## The workflow, step by step

| Step | What happens | Logged in |
|---|---|---|
| 1. Baseline | Pick an earlier month of new paid members with no launch, sale or price change. Log each one's join date, whether they reached the first outcome within the window, and their first renewal or cancellation | `events.csv` (joined, first_outcome, renewed, cancelled) |
| 2. Thresholds | Agree success and failure thresholds in `pilot.yaml` **before** the first pilot member joins | `pilot.yaml` |
| 3. Installation and acceptance | Install the pack in the members' Claude surface, run every case in `evals/acceptance.yaml`, check each saved reply with `skool-kit check-answer` and answer its review questions | `acceptance.csv` |
| 4. Member onboarding | Every new paid member in the pilot month gets the start guide on day 1 | |
| 5. Joins | `skool-kit pilot-import` with a member export taken on the last day of the month; add anyone who already left from payment history | `events.csv` (joined) |
| 6. Optional: adoption and completed tasks | Only when you can see them without asking every member | `events.csv` (installed, task_completed) |
| 7. First outcome | Log the date a member reports the outcome (for example a #firstwin post) | `events.csv` (first_outcome) |
| 8. Answer corrections | Every answer someone had to correct, with staff minutes; reviewing others is optional | `questions.csv` |
| 9. Cash and effort | Every payment and every hour spent on the pilot, by anyone | `costs.csv` |
| 10. Renewal follow-up | After each member's first renewal date, log renewed or cancelled | `events.csv` |
| 11. Decision report | Set `as_of` to the date the logs are complete up to, and run the report | `skool-kit pilot` |

**Eligibility and windows.**
- A member counts for the outcome only once their window (for example 14 days) has closed by `as_of`.
- They count for renewal only once their renewal date (`renewal_after_days`, default 30) has passed.
- Members still inside a window are reported as pending, never as failures.
- Members who passed their renewal date with no logged result are left out and listed as a logging gap.
- `excluded` removes a member (for example a trial refund), with the reason in `note`.

## What the report judges, separately

| Area | Measures | Verdicts |
|---|---|---|
| Product quality | Acceptance runs passed; share of reviewed tutor answers corrected | pass, fail, not checked |
| Member outcomes | Adoption; completed tasks; first-outcome rate within the window, pilot vs baseline, with 95% ranges | continue, extend, change, stop or change, not enough data |
| Economics | Cash and time spent; first-renewal rate per cohort; observed renewal difference minus cash costs; optional budget limits | positive, negative, over budget, not yet known |

**One suggestion, held back by the other two.**
- If quality fails, the suggestion is "fix quality first", whatever the outcome numbers say.
- If the outcomes say continue but quality wasn't checked, it becomes "extend".
- If the outcomes say continue but the economics are negative or over budget, it becomes "change".

## Default thresholds (set your own before you start)

| Setting | Default |
|---|---|
| Members needed per cohort (window closed) | 20 |
| Pilot members who must install | 40% |
| Outcome lift to continue / to stop | +10 points / 0 points |
| Acceptance runs that must pass | 100% |
| Reviewed tutor answers corrected, at most | 10% |
| Budget limits (optional) | max cash costs, max effort hours |

**Sufficient evidence to continue:**
- Two cohorts in a row above the continue threshold.
- Adoption above target.
- Quality passing.
- Economics not negative.

**To stop:**
- No outcome difference after two cohorts with good adoption, or
- corrections you can't bring down, or
- costs that exceed what any plausible renewal change could cover (check in the calculator).

## What it can't tell you

- It compares two months of members, so it can't prove cause. Season, marketing and who joined also change.
- With 30-50 members per cohort, only large differences stand out from chance. The report shows 95% ranges.
- Self-reported outcomes undercount. Log both cohorts the same way.
- The renewal difference is a later, noisier signal than the first outcome: a clue, not proof of revenue earned.
- Time freed is capacity, not cash, unless you cut paid hours.

## Try the report

`skool-owner-kit/examples/agency-lab/pilot-sample/` has synthetic logs (invented members and numbers):

```bash
skool-kit pilot skool-owner-kit/examples/agency-lab/pilot-sample/pilot.yaml
```

It suggests CONTINUE: quality passes, outcomes are up 16 points, and the economics are positive on the synthetic
numbers. It also warns that the 95% ranges overlap. With 40 members a cohort, that difference could still be chance.
