# Builder Commons

Free, open-source (MIT) tools for owners of paid online communities, starting with AI-automation and AI-agency
communities on Skool. The main one turns **your lessons into a reviewed AI member kit** (one Claude Project, or
Claude skills) **that walks each new member to their first win**, using your method, and gives you a **pilot report** to see whether more members get there and stay.

## Who it's for

- **Community owners and admins** whose paid members should reach an early result (a first client, a first
  automation) and often don't. Start with the [Admin guide](ADMIN-GUIDE.md), then [PILOT.md](PILOT.md) and
  [VALUE-MODEL.md](VALUE-MODEL.md).
- **Members** who received a Claude Project, a skill or a tool from their community. Start with the [Member guide](MEMBER-GUIDE.md).

## What's here

**Starter bundle:**

| Tool | Command | What it does |
|---|---|---|
| [skool-owner-kit](skool-owner-kit) | `skool-kit` | `pack-draft` and `pack-build`: a member kit from your lessons (a tutor with checkable citations, guided tasks for your first-win steps, acceptance checks, member and admin guides, a pilot kit). `pack-share`: what members receive, as a Claude Project or skills. `pilot`: compares a pilot cohort with a baseline. Also welcome messages and an inactivity dashboard |
| [skillkit](skillkit) | `skillkit` | Checks skills, tests them against a model (optionally with their lesson files), and packages them for Claude Code or the Claude app |
| [skillport](skillport) | `skillport` | Converts n8n workflows and Make.com scenarios into skill folders, with a list of what to check before you share each one |

**More tools** (useful for specific audiences): [shipsafe](shipsafe) (pre-launch checks for AI-built apps),
[geo-audit](geo-audit) (how AI assistants answer about a business), [ghl-agency-kit](ghl-agency-kit) (GoHighLevel
reports and onboarding), [voice-qa](voice-qa) (text-based tests for AI receptionists),
[career-labs](career-labs) (graded practice labs), [vertical-packs](vertical-packs) (niche calculators and checks).

What each tool has been tested against, and what has not been checked against a live service yet, is in
[READINESS.md](READINESS.md). Short version: everything runs locally with sample data; the generated member-pack
skills have been **run in Claude Code** (8 recorded runs), but **not in the Claude app**, no third-party integration
has been verified against a live account, and no community has run a pilot. Why the member pack is the lead, with sources: [BUSINESS-AUDIT.md](BUSINESS-AUDIT.md).

## Install (once)

You need Python 3.10 or newer. Download the starter bundle zip from the docs site (Downloads), unzip it, and open
a terminal in the unzipped folder.

macOS / Linux:

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install ./skool-owner-kit ./skillport ./skillkit
```

Windows (PowerShell):

```powershell
py -m venv .venv
.venv\Scripts\Activate.ps1
python -m pip install .\skool-owner-kit .\skillport .\skillkit
```

If PowerShell says running scripts is disabled, run
`Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser` once and try again
([Python docs](https://docs.python.org/3/library/venv.html)).

Check it worked: `skool-kit --version`, `skillport --version`, `skillkit --version` each print a version number.
Open a new terminal later? Activate the environment again first (`source .venv/bin/activate` or
`.venv\Scripts\Activate.ps1`).

## First successful run (no account or API key)

From the unzipped bundle folder, with the environment active, build the worked example: a synthetic AI-agency
community (all names, lessons and numbers are invented):

```bash
skool-kit pack-build skool-owner-kit/examples/agency-lab/pack.yaml -o pack
skillkit lint pack/skills
skillkit eval pack/skills --cases pack/evals/cases.yaml
skool-kit pack-share pack -o share --version 1.0.0
skool-kit pilot skool-owner-kit/examples/agency-lab/pilot-sample/pilot.yaml
```

You should see, in order:

- `Built pack: 3 skills (northwind-tutor, northwind-offer-builder, northwind-outreach-sprint)`.
- `Checked 3 skills: 0 errors, 0 warnings`.
- `6 of 6 cases passed` under a **DEMO DATA** line. The "fake" provider replays saved outputs from real Claude Code
  runs of these skills (`skool-owner-kit/examples/agency-lab/live-runs/`); this re-checks those outputs, it doesn't run
  the skills again.
- `Shared 3 skills (...)`, `Send every member: share/northwind-member-kit-1.0.0.zip` (START-HERE.md and an upload
  zip per skill), and `Or, as one Claude Project instead of skills: share/northwind-claude-project-1.0.0.zip`. You
  send members one of the two; `--format project` or `--format skills` writes only that one.
- A pilot report starting `Suggestion: CONTINUE`, followed by a warning that the cohorts' ranges overlap.

Then read `pack/APPROVAL.md` (the one page an owner approves) and `pack/ADMIN-REVIEW.md` (the full procedure,
including the manual run in Claude that none of the above replaces).

## Documentation

| Guide | For |
|---|---|
| [ADMIN-GUIDE.md](ADMIN-GUIDE.md) | Building a member pack, branding, checking, distributing and updating skills |
| [PILOT.md](PILOT.md) | Fit questions, the pilot workflow, decision rules (each pack also gets `pilot/CHECKLIST.md`) |
| [FIRST-PILOT.md](FIRST-PILOT.md) | The operating pack for a customer pilot: intake, scope and format, the approval sheet, acceptance cases, start guide, launch post, minimal event log and the final report template |
| [REVIEW-PILOT.md](REVIEW-PILOT.md) | The paid pilot: member-work review. Who qualifies, setup, measures, continue / change / stop rules, and questions that could prove us wrong |
| [OBSERVED-TIMINGS.md](OBSERVED-TIMINGS.md) | What has actually been measured (tool steps, what a person must read), kept apart from the estimates |
| [PILOT-OFFER.md](PILOT-OFFER.md) | The paid scoped pilot: scope, deliverables, acceptance, exclusions |
| [EFFORT.md](EFFORT.md) | One effort breakdown (estimates): the owner's hours and ours |
| [VALUE-MODEL.md](VALUE-MODEL.md) | How to estimate whether it earns or saves more than it costs, with a worked example |
| [BUSINESS-AUDIT.md](BUSINESS-AUDIT.md) | What each tool is worth to whom, and the evidence |
| [MEMBER-GUIDE.md](MEMBER-GUIDE.md) | Installing a skill or tool, connections, examples, troubleshooting |
| [READINESS.md](READINESS.md) | What was tested how, per integration, and what's still unverified |
| [DATA-AND-COSTS.md](DATA-AND-COSTS.md) | What data each tool reads and sends, and which steps cost API money |
| [CHANGELOG.md](CHANGELOG.md) | Release notes and upgrade steps |
| [MAINTAINING.md](MAINTAINING.md) | Keeping code, docs and downloads in sync |
| Each tool's `README.md` | Full command reference and limits |

## License

Every tool is MIT licensed (see the `LICENSE` file in each folder). You may use, change, rebrand and resell them.
The one requirement: keep the copyright and license notice in copies of the code you pass on. Skills and reports
the tools generate from your own content are yours.
