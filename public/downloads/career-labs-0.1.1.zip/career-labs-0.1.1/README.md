# career-labs

Hands-on labs with an auto-grader, made for career-coaching communities (data engineering
interviews, cybersecurity careers, DevOps/SRE and MLOps). Each lab is a realistic work task
with starter code. Members fill it in, run one command, and get a score with a hint for every
failed check. It works locally or with GitHub Classroom.

Python only, standard library only (plus `pytest` to run the grader and `pyyaml` for two labs; both are
installed by `pip install .`).
No Docker, no cloud account, no API keys.

## The labs

| Lab | Track | What members build | Checks |
|---|---|---|---|
| `de-01-orders-pipeline` | Data engineering | Messy CSVs into SQLite: dedupe late updates, FX conversion, rejects, daily revenue, customer LTV, SCD type 2, idempotent re-runs | 9 |
| `de-02-sql-interview` | Data engineering | 8 interview SQL questions: running total, top-N per group, dedupe, retention cohort, gaps and islands, LAG, second purchase, share of total | 8 |
| `sec-01-log-forensics` | Cybersecurity | SSH brute force detection (sliding window), compromised account, attacker's sudo commands, SQLi and path traversal in nginx logs, incident timeline JSON | 10 |
| `sec-02-secure-code-review` | Cybersecurity | Fix a vulnerable backend: SQL injection, path traversal, MD5 passwords, timing-unsafe and fail-open token check, pickle cookies, unsafe YAML. Real exploits are run against it | 10 |
| `ops-01-incident-drill` | DevOps / SRE | SLO error budget and burn rate, sustained spike detection, deploy correlation, log triage, postmortem summary, fix a broken service config | 9 |
| `ml-01-mlops-basics` | MLOps | Seeded split, scaling, logistic regression by gradient descent, precision/recall/F1/ROC-AUC, PSI drift detection, model card (no numpy) | 9 |

Each lab is worth 100 points. Every lab folder has:

```
labs/<lab-id>/
  README.md     the brief: scenario, task, how to grade, points table
  starter/      code with TODOs (this is what members edit)
  reference/    a full solution (scores 100%) - remove it before giving the repo to members
  grader/       the graded checks (pytest)
  data/         fixture data + generate.py that rebuilds it byte-for-byte
```

## Quickstart (members)

You need Python 3.10 or newer. These commands are for macOS/Linux; on Windows type `py` instead of `python3`
and activate the virtual environment with `.venv\Scripts\activate`.

```
git clone <this repo> && cd career-labs
python3 -m venv .venv                     # a virtual environment keeps the lab's packages separate
source .venv/bin/activate
python3 -m pip install pytest pyyaml
python3 -m labgrade list
python3 -m labgrade run de-01-orders-pipeline
```

Run these from the `career-labs` folder: labgrade looks for `./labs` in the current folder. Prefer a
`labgrade` command? `python3 -m pip install .` installs it (with pytest and pyyaml). Run it from the
career-labs folder too, or pass `--labs-dir PATH` (or set `LABGRADE_LABS_DIR`).

Then open `labs/de-01-orders-pipeline/README.md`, edit `labs/de-01-orders-pipeline/starter/pipeline.py`,
and run the grader again until you reach 100.

Example output (the untouched starter of the code review lab):

```
Lab: sec-02-secure-code-review   (solution: starter)

  PASS    5/5   test_find_user_normal                  normal behaviour: create_user + find_user work for real usernames
  FAIL    0/15  test_find_user_sql_injection           SQL injection: find_user/create_user must use parameters, not string formatting
            -> AssertionError: login bypass: ' OR '1'='1 returned a user
  FAIL    0/10  test_search_products_sql_injection     SQL injection in LIKE search: no UNION leaks; normal search still works
            -> AssertionError: UNION injection leaked the users table
  ...
Score: 10/100 points (10%)  - 2/10 checks passed
Fix the FAIL and ERR lines above (read the '->' hint) and run the grader again.
```

## The grader (`labgrade`)

```
python3 -m labgrade list [--json]
python3 -m labgrade run <lab> [--solution starter|reference|PATH] [--json] [--test NAME] [--fail-under PCT]
python3 -m labgrade classroom [<lab> ...]        # print a GitHub Classroom autograding.json
python3 -m labgrade --labs-dir PATH list         # labs somewhere else (default: ./labs, or $LABGRADE_LABS_DIR)
```

- `--solution` defaults to `starter`. A folder path grades any other copy, such as a member's fork checked out elsewhere.
- Each graded test declares its weight with `@pytest.mark.points(N)`.
- The grader runs in a fresh `pytest` process. The solution folder is passed through the
  `LAB_SOLUTION_DIR` environment variable, and graders import the solution with `labgrade.helpers.load_solution`.
- Exit codes: `0` when graded, `1` when below `--fail-under`, `2` for errors (unknown lab, missing folder, or a grader that crashed).
- `--json` gives `score`, `max_score`, `percent`, and for each test its `outcome`, `earned` and `message`.

## GitHub Classroom

- `.github/workflows/classroom.yml` is an example workflow for `de-01-orders-pipeline`. Each graded check
  is one `autograding-command-grader` step worth its points. The workflow also writes the full score to the job summary.
- `.github/classroom/autograding.json` is the classic autograding format with one entry per graded test
  for all labs. Regenerate it with `python3 -m labgrade classroom > .github/classroom/autograding.json`.
- The action names and inputs follow what GitHub Classroom generates. Verify them against the current
  GitHub Classroom docs before you rely on them.
- For an assignment, make a template repo with **one** lab, **delete `reference/`**, and keep `labgrade/` and the lab's `grader/` and `data/`.
  Then regenerate the autograding file for just that lab, for example
  `python3 -m labgrade classroom de-01-orders-pipeline > .github/classroom/autograding.json`, and point
  `.github/workflows/classroom.yml` at the same lab.

## For community owners

- **Rebrand it:** fork the repo, rename it, and put your community's name in the README. The labs are MIT licensed.
- **Hand out one lab a week:** post it in your community, and members post a screenshot of their 100/100.
- **Portfolio material:** each lab README ends with a portfolio tip that turns the lab into something worth showing in an interview.

## Developing

```
cd career-labs
../.venv/bin/python -m pytest -q          # meta-tests
python3 labs/<lab>/data/generate.py        # rebuild fixture data (deterministic)
python3 labs/de-01-orders-pipeline/grader/make_expected.py   # recompute expected outputs (independent oracle)
```

The meta-tests in `tests/` check that:

- every lab's reference scores 100% and its starter scores below 100% without crashing the grader;
- every lab has 6 to 12 graded checks totalling 100 points;
- each README's points table matches the grader;
- regenerated data is byte-identical to the committed files;
- the `expected.json` files match an independent oracle;
- the classroom files are in sync with the graders.

To add a lab, create the five folders above and use `@pytest.mark.points`. The meta-tests pick it up automatically.

## Limits

- **No .NET lab yet.** A .NET + AI agent lab, for C# communities, is future work: this environment has no .NET SDK.
- **No Docker or cloud labs.** The DevOps lab works on logs, metrics and a YAML config rather than a running
  cluster, and the config schema is a simplified, Kubernetes-like one.
- **Visible graders.** Members can read the grader and its expected outputs, which is by design for learning.
  For assessed use, keep graders in a private repo or check out the grader at CI time.
- **Fixed scoring.** Scoring is per check (pass or fail). A check with several asserts earns nothing until all of them pass.
- **Security guidance changes.** Numbers like PBKDF2 iterations and PSI thresholds are common rules of thumb.
  Verify them against current OWASP and industry guidance.
- **Synthetic data.** The data and IPs are synthetic, and the IPs come from RFC 5737 documentation ranges.

## License

MIT, see `LICENSE`.
