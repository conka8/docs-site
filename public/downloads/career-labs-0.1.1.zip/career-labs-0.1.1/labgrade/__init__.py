"""labgrade: a tiny auto-grader for the career labs."""

__version__ = "0.1.1"

from .core import LabError, LabResult, discover_labs, format_text, get_lab, run_lab  # noqa: E402

__all__ = ["LabError", "LabResult", "discover_labs", "format_text", "get_lab", "run_lab", "__version__"]
