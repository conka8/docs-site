"""Command line interface: ``python -m labgrade list|run|classroom``."""

from __future__ import annotations

import argparse
import json
import sys

from . import __version__
from .core import LabError, classroom_config, discover_labs, format_text, run_lab


def _build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="labgrade",
        description="Auto-grader for the career labs. Runs a lab's graded checks and prints your score.",
    )
    p.add_argument("--version", action="version", version=f"labgrade {__version__}")
    p.add_argument(
        "--labs-dir", default=None,
        help="folder that contains the labs (default: $LABGRADE_LABS_DIR, else ./labs in the current folder)",
    )
    sub = p.add_subparsers(dest="command", required=True)

    ls = sub.add_parser("list", help="list the available labs and their points")
    ls.add_argument("--json", action="store_true", help="print JSON instead of a table")

    run = sub.add_parser("run", help="grade one lab")
    run.add_argument("lab", help="lab id, e.g. de-01-orders-pipeline (see `labgrade list`)")
    run.add_argument(
        "--solution", default="starter",
        help="which code to grade: 'starter' (your work, default), 'reference', or a folder path",
    )
    run.add_argument("--json", action="store_true", help="print a JSON report")
    run.add_argument("--test", default=None, help="run only this graded test (exact name)")
    run.add_argument(
        "--fail-under", type=float, default=None,
        help="exit with code 1 if the score percentage is below this (e.g. 100 for CI)",
    )
    run.add_argument("--timeout", type=int, default=600, help="seconds before the grader gives up")

    cr = sub.add_parser("classroom", help="print a GitHub Classroom autograding.json")
    cr.add_argument("labs", nargs="*", help="lab ids (default: all labs)")
    cr.add_argument("--solution", default="starter", help="solution folder the classroom run should grade")
    return p


def main(argv: list[str] | None = None) -> int:
    args = _build_parser().parse_args(argv)
    try:
        if args.command == "list":
            labs = discover_labs(args.labs_dir)
            rows = [
                {"id": lab.id, "title": lab.title, "tests": len(lab.static_points()), "points": lab.total_points()}
                for lab in labs
            ]
            if args.json:
                print(json.dumps(rows, indent=2))
            else:
                width = max([len(r["id"]) for r in rows] + [2])
                print(f"{'LAB':<{width}}  TESTS  POINTS  TITLE")
                for r in rows:
                    print(f"{r['id']:<{width}}  {r['tests']:>5}  {r['points']:>6}  {r['title']}")
            return 0

        if args.command == "run":
            result = run_lab(args.lab, args.solution, args.labs_dir, only=args.test, timeout=args.timeout)
            if args.test and not result.tests:
                raise LabError(f"no graded test named '{args.test}' in {args.lab}")
            if args.json:
                print(json.dumps(result.to_dict(), indent=2))
            else:
                print(format_text(result, args.solution))
            if result.crashed:
                return 2
            if args.fail_under is not None and result.percent < args.fail_under:
                return 1
            return 0

        if args.command == "classroom":
            ids = args.labs or [lab.id for lab in discover_labs(args.labs_dir)]
            print(json.dumps(classroom_config(ids, args.solution, args.labs_dir), indent=2))
            return 0
    except LabError as exc:
        print(f"Error: {exc}", file=sys.stderr)
        return 2
    return 2  # pragma: no cover


if __name__ == "__main__":  # pragma: no cover
    sys.exit(main())
