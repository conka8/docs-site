"""Lab discovery, grading runs and report formatting."""

from __future__ import annotations

import ast
import json
import os
import subprocess
import sys
import tempfile
import time
from dataclasses import dataclass, field
from pathlib import Path

PACKAGE_ROOT = Path(__file__).resolve().parent.parent  # the career-labs folder (in a source checkout)
DEFAULT_LABS_DIR = PACKAGE_ROOT / "labs"
LABS_DIR_ENV = "LABGRADE_LABS_DIR"
DEFAULT_TIMEOUT = 600


class LabError(Exception):
    """A problem the user can fix (unknown lab, missing folder...)."""


@dataclass
class Lab:
    id: str
    path: Path

    @property
    def grader_dir(self) -> Path:
        return self.path / "grader"

    @property
    def readme(self) -> Path:
        return self.path / "README.md"

    @property
    def title(self) -> str:
        if self.readme.is_file():
            for line in self.readme.read_text(encoding="utf-8").splitlines():
                if line.startswith("# "):
                    return line[2:].strip()
        return self.id

    def grader_files(self) -> list[Path]:
        return sorted(self.grader_dir.glob("test_*.py"))

    def static_points(self) -> dict[str, int]:
        """Points per graded test, read from the source without importing it."""
        points: dict[str, int] = {}
        for file in self.grader_files():
            try:
                tree = ast.parse(file.read_text(encoding="utf-8"), filename=str(file))
            except SyntaxError:
                continue  # reported properly when the grader runs
            for node in tree.body:
                if isinstance(node, ast.FunctionDef) and node.name.startswith("test"):
                    points[node.name] = _marker_points(node)
        return points

    def total_points(self) -> int:
        return sum(self.static_points().values())


def _marker_points(node: ast.FunctionDef) -> int:
    for deco in node.decorator_list:
        if (
            isinstance(deco, ast.Call)
            and isinstance(deco.func, ast.Attribute)
            and deco.func.attr == "points"
            and deco.args
            and isinstance(deco.args[0], ast.Constant)
        ):
            return int(deco.args[0].value)
    return 1


def labs_dir(path: str | os.PathLike | None = None) -> Path:
    """Where the labs are: ``path`` (--labs-dir), else $LABGRADE_LABS_DIR, else ./labs in the current
    folder if it exists, else the labs folder next to the labgrade package (source checkout)."""
    if path:
        return Path(path).expanduser().resolve()
    env = os.environ.get(LABS_DIR_ENV)
    if env:
        return Path(env).expanduser().resolve()
    here = Path.cwd() / "labs"
    if here.is_dir():
        return here.resolve()
    return DEFAULT_LABS_DIR


def discover_labs(path: str | os.PathLike | None = None) -> list[Lab]:
    root = labs_dir(path)
    if not root.is_dir():
        raise LabError(
            f"labs folder not found: {root}. Run labgrade from inside the career-labs folder (the one that "
            f"contains labs/), or pass --labs-dir PATH (or set {LABS_DIR_ENV})."
        )
    return [Lab(p.name, p) for p in sorted(root.iterdir()) if (p / "grader").is_dir()]


def get_lab(lab_id: str, path: str | os.PathLike | None = None) -> Lab:
    labs = discover_labs(path)
    for lab in labs:
        if lab.id == lab_id:
            return lab
    known = ", ".join(l.id for l in labs) or "(none)"
    raise LabError(f"unknown lab '{lab_id}'. Available labs: {known}")


def resolve_solution(lab: Lab, solution: str) -> Path:
    if solution in ("starter", "reference"):
        path = lab.path / solution
    else:
        path = Path(solution).expanduser().resolve()
    if not path.is_dir():
        raise LabError(f"solution folder not found: {path}")
    return path


@dataclass
class TestResult:
    __test__ = False  # not a pytest test class

    name: str
    points: int
    outcome: str
    message: str = ""
    description: str = ""
    nodeid: str = ""

    @property
    def earned(self) -> int:
        return self.points if self.outcome == "passed" else 0


@dataclass
class LabResult:
    lab: str
    solution: str
    tests: list[TestResult] = field(default_factory=list)
    errors: list[dict] = field(default_factory=list)
    pytest_exit_code: int = 0
    duration_s: float = 0.0

    @property
    def score(self) -> int:
        return sum(t.earned for t in self.tests)

    @property
    def max_score(self) -> int:
        return sum(t.points for t in self.tests)

    @property
    def percent(self) -> float:
        return round(100.0 * self.score / self.max_score, 1) if self.max_score else 0.0

    @property
    def crashed(self) -> bool:
        """True when the grader itself could not run (collection errors, no tests)."""
        return bool(self.errors) or not self.tests

    def to_dict(self) -> dict:
        return {
            "lab": self.lab,
            "solution": self.solution,
            "score": self.score,
            "max_score": self.max_score,
            "percent": self.percent,
            "passed": sum(1 for t in self.tests if t.outcome == "passed"),
            "total_tests": len(self.tests),
            "tests": [
                {
                    "name": t.name,
                    "description": t.description,
                    "points": t.points,
                    "earned": t.earned,
                    "outcome": t.outcome,
                    "message": t.message,
                }
                for t in self.tests
            ],
            "errors": self.errors,
            "pytest_exit_code": self.pytest_exit_code,
            "duration_s": self.duration_s,
        }


def run_lab(
    lab_id: str,
    solution: str = "reference",
    labs_path: str | os.PathLike | None = None,
    only: str | None = None,
    timeout: int = DEFAULT_TIMEOUT,
) -> LabResult:
    """Run one lab's graded tests against a solution folder in a fresh pytest process."""
    lab = get_lab(lab_id, labs_path)
    sol_dir = resolve_solution(lab, solution)
    if not lab.grader_files():
        raise LabError(f"lab '{lab.id}' has no grader/test_*.py files")

    env = dict(os.environ)
    env["LAB_SOLUTION_DIR"] = str(sol_dir)
    env["PYTHONDONTWRITEBYTECODE"] = "1"
    env["PYTHONPATH"] = os.pathsep.join(
        [str(PACKAGE_ROOT)] + ([env["PYTHONPATH"]] if env.get("PYTHONPATH") else [])
    )
    start = time.monotonic()
    with tempfile.TemporaryDirectory(prefix="labgrade-") as tmp:
        report_path = Path(tmp) / "report.json"
        cmd = [
            sys.executable, "-m", "pytest", str(lab.grader_dir),
            "-p", "labgrade.plugin", "-p", "no:cacheprovider",
            "-q", "--no-header", "-rN", "--tb=short",
            f"--labgrade-report={report_path}",
        ]
        if only:
            cmd.append(f"--labgrade-only={only}")
        try:
            proc = subprocess.run(
                cmd, cwd=str(lab.path), env=env, capture_output=True, text=True, timeout=timeout
            )
        except subprocess.TimeoutExpired:
            raise LabError(f"grader timed out after {timeout}s (infinite loop in the solution?)")
        if not report_path.is_file():
            tail = (proc.stdout + proc.stderr).strip()[-2000:]
            raise LabError(f"grader did not produce a report (pytest exit {proc.returncode}):\n{tail}")
        data = json.loads(report_path.read_text(encoding="utf-8"))

    result = LabResult(
        lab=lab.id,
        solution=str(sol_dir),
        errors=data.get("errors", []),
        pytest_exit_code=data.get("exitstatus", proc.returncode),
        duration_s=round(time.monotonic() - start, 2),
    )
    for t in data["tests"]:
        result.tests.append(
            TestResult(
                name=t["name"], points=t["points"], outcome=t["outcome"], message=t["message"],
                description=t.get("description", ""), nodeid=t.get("nodeid", ""),
            )
        )
    return result


_MARK = {"passed": "PASS", "failed": "FAIL", "error": "ERR ", "skipped": "SKIP", "not run": "----"}


def format_text(result: LabResult, solution_label: str | None = None) -> str:
    lines = [f"Lab: {result.lab}   (solution: {solution_label or result.solution})", ""]
    width = max([len(t.name) for t in result.tests] + [10])
    for t in result.tests:
        mark = _MARK.get(t.outcome, t.outcome.upper()[:4])
        line = f"  {mark}  {t.earned:>3}/{t.points:<3} {t.name:<{width}}"
        if t.description:
            line += f"  {t.description}"
        lines.append(line.rstrip())
        if t.outcome != "passed" and t.message:
            lines.append(f"{'':12}-> {t.message}")
    for err in result.errors:
        lines.append(f"  GRADER ERROR in {err['nodeid'] or 'collection'}: {err['message']}")
    lines.append("")
    passed = sum(1 for t in result.tests if t.outcome == "passed")
    lines.append(
        f"Score: {result.score}/{result.max_score} points ({result.percent:g}%)  "
        f"- {passed}/{len(result.tests)} checks passed"
    )
    if result.percent == 100.0 and not result.crashed:
        lines.append("All checks passed. Nice work - add this lab to your portfolio.")
    elif not result.crashed:
        lines.append("Fix the FAIL and ERR lines above (read the '->' hint) and run the grader again.")
    return "\n".join(lines)


def classroom_config(lab_ids: list[str], solution: str = "starter", labs_path=None) -> dict:
    """Build a GitHub Classroom ``autograding.json`` with one entry per graded test."""
    tests = []
    for lab_id in lab_ids:
        lab = get_lab(lab_id, labs_path)
        for name, pts in lab.static_points().items():
            tests.append(
                {
                    "name": f"{lab.id} :: {name}",
                    "setup": "",
                    "run": (
                        f"python -m labgrade run {lab.id} --solution {solution} "
                        f"--test {name} --fail-under 100"
                    ),
                    "input": "",
                    "output": "",
                    "comparison": "included",
                    "timeout": 5,
                    "points": pts,
                }
            )
    return {"tests": tests}
