"""Helpers imported by the graded tests in ``labs/<lab>/grader/``.

The solution being graded lives in the directory named by the ``LAB_SOLUTION_DIR``
environment variable (labgrade sets it). When it is not set, graders fall back to
the lab's ``reference/`` folder so maintainers can run ``pytest labs/<lab>/grader``.
"""

from __future__ import annotations

import importlib.util
import os
import sys
from pathlib import Path
from types import ModuleType

ENV_VAR = "LAB_SOLUTION_DIR"


def lab_dir_from(grader_file: str | os.PathLike) -> Path:
    """Return the lab folder for a file that lives in ``<lab>/grader/``."""
    return Path(grader_file).resolve().parent.parent


def solution_dir(lab_dir: Path) -> Path:
    raw = os.environ.get(ENV_VAR)
    path = Path(raw) if raw else Path(lab_dir) / "reference"
    return path.resolve()


def load_solution(lab_dir: Path, module: str) -> ModuleType:
    """Import ``<solution_dir>/<module>.py`` fresh, under a private name.

    Raises a clear ``FileNotFoundError`` if the file is missing so the member sees
    which file the grader expected.
    """
    sol = solution_dir(lab_dir)
    path = sol / f"{module}.py"
    if not path.is_file():
        raise FileNotFoundError(f"expected your solution file at {path}")
    if str(sol) not in sys.path:
        sys.path.insert(0, str(sol))
    name = f"_labsolution_{module}"
    sys.modules.pop(name, None)
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    sys.modules[name] = mod
    spec.loader.exec_module(mod)
    return mod


def solution_file(lab_dir: Path, filename: str) -> Path:
    """Path of a non-Python solution file (``.sql``, ``.yaml``...); must exist."""
    path = solution_dir(lab_dir) / filename
    if not path.is_file():
        raise FileNotFoundError(f"expected your solution file at {path}")
    return path


def register_points_marker(config) -> None:
    """Call from a grader ``conftest.pytest_configure`` so plain pytest runs don't warn."""
    config.addinivalue_line("markers", "points(n): how many points this graded test is worth")
