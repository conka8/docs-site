"""pytest plugin used by labgrade to record per-test points and outcomes.

Loaded with ``-p labgrade.plugin``. Each graded test declares its weight with
``@pytest.mark.points(N)`` (tests without the marker are worth 1 point).
The plugin writes a JSON report to the path given by ``--labgrade-report``.
"""

from __future__ import annotations

import json

import pytest

DEFAULT_POINTS = 1
_MAX_MESSAGE = 600


def pytest_addoption(parser):
    group = parser.getgroup("labgrade")
    group.addoption("--labgrade-report", default=None, help="write a JSON points report here")
    group.addoption("--labgrade-only", default=None, help="run only the graded test with this exact name")


def pytest_configure(config):
    config.addinivalue_line("markers", "points(n): how many points this graded test is worth")
    config._labgrade = _Recorder(config)
    config.pluginmanager.register(config._labgrade, "labgrade-recorder")


def item_points(item) -> int:
    marker = item.get_closest_marker("points")
    if marker is None or not marker.args:
        return DEFAULT_POINTS
    return int(marker.args[0])


def _short_message(report) -> str:
    crash = getattr(getattr(report, "longrepr", None), "reprcrash", None)
    if crash is not None and getattr(crash, "message", None):
        text = crash.message
    else:
        text = getattr(report, "longreprtext", "") or str(getattr(report, "longrepr", ""))
        text = text.strip().splitlines()[-1] if text.strip() else ""
    # drop pytest's "+  where x = ..." introspection lines: they are noise for members
    lines = [ln for ln in text.splitlines() if ln.strip() and not ln.lstrip().startswith("+")]
    # "AssertionError: <member-facing message>" followed by pytest's own diff: keep the message only
    if len(lines) > 1 and lines[1].lstrip().startswith("assert "):
        lines = lines[:1]
    text = " ".join(" ".join(lines).split())
    return text[:_MAX_MESSAGE]


class _Recorder:
    def __init__(self, config):
        self.config = config
        self.tests: dict[str, dict] = {}
        self.errors: list[dict] = []

    @pytest.hookimpl(trylast=True)
    def pytest_collection_modifyitems(self, session, config, items):
        only = config.getoption("--labgrade-only")
        if only:
            keep = [i for i in items if getattr(i, "originalname", i.name) == only or i.name == only]
            dropped = [i for i in items if i not in keep]
            if dropped:
                config.hook.pytest_deselected(items=dropped)
            items[:] = keep
        for item in items:
            doc = (getattr(item, "function", None) and item.function.__doc__) or ""
            self.tests[item.nodeid] = {
                "name": item.name,
                "nodeid": item.nodeid,
                "description": doc.strip().splitlines()[0] if doc.strip() else "",
                "points": item_points(item),
                "outcome": "not run",
                "message": "",
            }

    def pytest_collectreport(self, report):
        if report.failed:
            self.errors.append({"nodeid": report.nodeid, "message": _short_message(report)})

    def pytest_runtest_logreport(self, report):
        entry = self.tests.get(report.nodeid)
        if entry is None:
            return
        if report.when == "call":
            if report.passed and entry["outcome"] in ("not run", "running"):
                entry["outcome"] = "passed"
            elif report.failed:
                entry["outcome"] = "failed"
                entry["message"] = _short_message(report)
            elif report.skipped:
                entry["outcome"] = "skipped"
                entry["message"] = _short_message(report)
        elif report.when == "setup":
            if report.failed:
                entry["outcome"] = "error"
                entry["message"] = _short_message(report)
            elif report.skipped:
                entry["outcome"] = "skipped"
                entry["message"] = _short_message(report)
            else:
                entry["outcome"] = "running"
        elif report.when == "teardown" and report.failed and entry["outcome"] == "passed":
            entry["outcome"] = "error"
            entry["message"] = _short_message(report)

    def pytest_sessionfinish(self, session, exitstatus):
        path = self.config.getoption("--labgrade-report")
        if not path:
            return
        for entry in self.tests.values():
            if entry["outcome"] == "running":
                entry["outcome"] = "error"
        data = {"tests": list(self.tests.values()), "errors": self.errors, "exitstatus": int(exitstatus)}
        with open(path, "w", encoding="utf-8") as fh:
            json.dump(data, fh, indent=2)
