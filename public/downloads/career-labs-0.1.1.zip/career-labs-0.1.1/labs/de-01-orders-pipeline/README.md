# DE-01: Orders pipeline (data engineering take-home)

## Scenario

You just joined the data team of a small online shop. Every night, two exports land in
`data/`: `orders.csv` and `customers.csv`, plus `fx_rates.csv` from finance. They are messy:

- the export job sometimes runs twice (exact duplicate rows);
- orders get **updated later** (price corrections, cancellations, a fixed date). The update
  is a new row with the same `order_id` and a later `updated_at`, often at the end of the
  file. One stale update is *older* than what you already have;
- dates come in four formats, and a few are impossible (`2024-02-30`, `13/06/2024`);
- currency codes are written as `usd`, ` USD `, `Eur `...; one order is in JPY (no rate);
- finance publishes no FX rates at weekends;
- customers move house, and analysts need the **address history** (SCD type 2).

Build `pipeline.py` that loads everything into SQLite and produces clean tables. This is the
classic data engineering interview take-home. Do it well and it goes straight into your portfolio.

## What you will practise

Staging raw data, deduplicating by latest timestamp, data quality rules and a reject table,
as-of joins for FX rates, aggregate tables, slowly changing dimensions (type 2), and idempotent re-runs.

## Your task

Edit `starter/pipeline.py`. The docstring of each function is the exact spec.

| Step | Function | Output table(s) |
|---|---|---|
| 1 | `parse_date(text)` | (helper) returns `YYYY-MM-DD` or `None` |
| 2 | `load_raw(conn, data_dir)` (given) | `raw_orders`, `raw_customers`, `fx_rates` |
| 3 | `build_orders(conn)` | `orders`, `rejected_orders` |
| 4 | `build_daily_revenue(conn)` | `daily_revenue(order_date, orders_count, revenue_usd)` |
| 5 | `build_dim_customer(conn)` | `dim_customer` (SCD type 2) |
| 6 | `build_customer_ltv(conn)` | `customer_ltv(customer_id, orders_count, ltv_usd, first_order_date, last_order_date)` |
| 7 | `run_pipeline(db_path, data_dir)` (given) | everything; must be safe to run twice |

Rules that the grader checks exactly:

- **Dates**: accept `2024-03-05`, `2024/03/05`, `03/05/2024` (US month/day/year) and
  timestamps like `2024-03-05T23:29:00`. Anything else is `None`.
- **Dedupe**: one row per `order_id`, the row with the **latest `updated_at`** wins.
- **Reject reasons**, checked in this order: `bad_date`, `bad_amount` (not a number or <= 0),
  `unknown_currency` (no rate on or before the order date), `unknown_customer`.
- **USD**: `amount_usd = round(amount * rate, 2)` using the most recent rate **on or before** the order date.
- **Revenue and LTV** count `completed` orders only (status compared in lower case).
- **SCD2**: a new version only when `(address, city)` changes (after trimming spaces).
  Name or email changes update the current version in place.
  `valid_to` is the next version's `valid_from`, and the current row has `valid_to = NULL` and `is_current = 1`.

Try it by hand:

```
python labs/de-01-orders-pipeline/starter/pipeline.py warehouse.db
```

## Run the grader

```
python -m labgrade run de-01-orders-pipeline
```

(`--solution starter` is the default. Add `--json` for a machine-readable report.)

## Points

| Graded check | Points | What it checks |
|---|---:|---|
| `test_parse_date` | 10 | parse_date handles ISO, YYYY/MM/DD, MM/DD/YYYY, timestamps; rejects junk |
| `test_load_raw_counts` | 5 | load_raw stages every CSV row (no cleaning yet) into raw_* tables |
| `test_dedupe_keeps_latest_update` | 15 | one row per order_id; the latest updated_at wins (stale late rows ignored) |
| `test_currency_conversion` | 10 | currency is normalised (trim/upper) and amount_usd uses the as-of fx rate |
| `test_rejected_orders` | 10 | bad dates, bad amounts, unknown currency/customer go to rejected_orders with a reason |
| `test_daily_revenue` | 15 | daily_revenue = completed orders only, USD, rounded to cents |
| `test_customer_ltv` | 10 | customer_ltv has every current customer, including ones with no orders |
| `test_scd2_dim_customer` | 15 | dim_customer keeps address history (SCD type 2) with valid_from/valid_to/is_current |
| `test_idempotent_rerun` | 10 | running the pipeline twice on the same database gives identical tables |
| **Total** | **100** | |

## Portfolio tip

Add a short `DESIGN.md` next to your solution: why you dedupe before validating, how you made
re-runs idempotent (drop and rebuild, or `INSERT OR REPLACE`), and what you would change at
100x the data (incremental loads, partitioning, a proper orchestrator).

## For maintainers

`data/generate.py` rebuilds the CSVs (seeded, byte-identical). `grader/make_expected.py`
recomputes `grader/expected.json` with plain Python, independently of the reference solution.
