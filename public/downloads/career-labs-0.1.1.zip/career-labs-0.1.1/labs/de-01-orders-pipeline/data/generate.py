"""Generate the deterministic fixture data for de-01-orders-pipeline.

Run:  python labs/de-01-orders-pipeline/data/generate.py [--out DIR]
Same code + same seed = byte-identical files (the meta-tests check this).
"""

from __future__ import annotations

import argparse
import csv
import random
from datetime import date, timedelta
from pathlib import Path

SEED = 2024
DAYS = [date(2024, 3, 1) + timedelta(days=i) for i in range(7)]
CUSTOMER_CCY = {"C001": "USD", "C002": "USD", "C003": "USD", "C004": "USD",
                "C005": "EUR", "C006": "GBP", "C007": "USD"}
CCY_SPELLINGS = {"USD": ["USD", "usd", " USD "], "EUR": ["EUR", "eur", "Eur "], "GBP": ["GBP", "gbp"]}

CUSTOMERS = [
    # customer_id, name, email, address, city, updated_at
    ("C001", "Alice Nguyen", "alice@example.com", "12 Oak St", "Austin", "2024-01-02T09:00:00"),
    ("C002", "Bob Smith", "bob@example.com", "5 Elm Rd", "Denver", "2024-01-03T10:00:00"),
    ("C003", "Carla Diaz", "carla@example.com", "300 Main St", "Miami", "2024-01-05T11:30:00"),
    ("C004", "Dev Patel", "dev@example.com", "7 Lake Dr", "Chicago", "2024-01-06T08:15:00"),
    ("C005", "Emma Rossi", "emma@example.it", "Via Roma 1", "Milan", "2024-01-07T14:00:00"),
    ("C006", "Finn Walsh", "finn@example.co.uk", "22 Baker St", "London", "2024-01-08T16:45:00"),
    ("C007", "Grace Kim", "grace@example.com", "  42 Rain St ", "Seattle", "2024-01-09T12:00:00"),
    ("C008", "Hiro Tanaka", "hiro@example.com", "9 Sakura Ln", "Portland", "2024-01-10T10:10:00"),
    # exact duplicate row (double export)
    ("C002", "Bob Smith", "bob@example.com", "5 Elm Rd", "Denver", "2024-01-03T10:00:00"),
    # address changes -> new SCD2 versions
    ("C001", "Alice Nguyen", "alice@example.com", "88 Pine Ave", "Austin", "2024-03-04T12:00:00"),
    ("C004", "Dev Patel", "dev.patel@example.com", "1 Beacon St", "Boston", "2024-03-03T09:00:00"),
    ("C004", "Dev Patel", "dev.patel@example.com", "19 Harbor Way", "Boston", "2024-03-06T18:00:00"),
    # email-only change -> no new version, but latest email wins
    ("C003", "Carla Diaz", "carla.diaz@example.com", "300 Main St", "Miami", "2024-03-02T07:00:00"),
    # same address after trimming whitespace -> no new version
    ("C007", "Grace Kim", "grace@example.com", "42 Rain St", "Seattle", "2024-03-05T13:00:00"),
]


def _fmt_date(d: date, style: int, rng: random.Random) -> str:
    if style == 0:
        return d.isoformat()
    if style == 1:
        return d.strftime("%Y/%m/%d")
    if style == 2:
        return d.strftime("%m/%d/%Y")
    return f"{d.isoformat()}T{rng.randint(0, 23):02d}:{rng.randint(0, 59):02d}:00"


def build_orders() -> list[list[str]]:
    rng = random.Random(SEED)
    rows: list[list[str]] = []
    customers = sorted(CUSTOMER_CCY)
    for i in range(36):
        oid = f"O{1001 + i}"
        cust = rng.choice(customers)
        day = rng.choice(DAYS)
        amount = f"{rng.randint(1000, 50000) / 100:.2f}"
        ccy = rng.choice(CCY_SPELLINGS[CUSTOMER_CCY[cust]])
        status = rng.choices(["completed", "pending", "cancelled"], weights=[8, 1, 1])[0]
        if i % 5 == 0:
            status = status.upper()
        upd = f"{day.isoformat()}T{rng.randint(0, 23):02d}:{rng.randint(0, 59):02d}:{rng.randint(0, 59):02d}"
        rows.append([oid, cust, _fmt_date(day, i % 4, rng), amount, ccy, status, upd])

    # exact duplicates (the export job ran twice)
    rows.append(list(rows[3]))
    rows.append(list(rows[10]))
    rows.append(list(rows[17]))

    # late-arriving updates (later updated_at, appear at the end of the file)
    def update(idx: int, **changes) -> None:
        r = list(rows[idx])
        cols = ["order_id", "customer_id", "order_date", "amount", "currency", "status", "updated_at"]
        for k, v in changes.items():
            r[cols.index(k)] = v
        rows.append(r)

    update(0, amount="999.99", updated_at="2024-03-09T08:00:00")            # price correction
    update(5, status="cancelled", updated_at="2024-03-09T09:30:00")         # cancelled later
    update(14, status="completed", updated_at="2024-03-10T10:00:00")        # pending -> completed
    update(20, order_date="2024-03-07", updated_at="2024-03-10T11:00:00")   # date fixed
    # stale update: arrives late in the file but is OLDER than what we have -> must be ignored
    update(8, amount="1.00", updated_at="2024-02-01T00:00:00")

    # bad rows
    rows.append(["O2001", "C001", "not-a-date", "50.00", "USD", "completed", "2024-03-02T10:00:00"])
    rows.append(["O2002", "C002", "2024-02-30", "75.00", "USD", "completed", "2024-03-02T11:00:00"])
    rows.append(["O2003", "C003", "2024-03-03", "", "USD", "completed", "2024-03-03T12:00:00"])
    rows.append(["O2004", "C005", "2024-03-04", "-20.00", "EUR", "completed", "2024-03-04T12:00:00"])
    rows.append(["O2005", "C006", "2024-03-05", "120.00", "JPY", "completed", "2024-03-05T12:00:00"])
    rows.append(["O2006", "C999", "2024-03-05", "60.00", "USD", "completed", "2024-03-05T13:00:00"])
    # an order whose LATEST version is bad (date typo in a correction) -> rejected
    rows.append(["O2007", "C001", "2024-03-06", "80.00", "USD", "completed", "2024-03-06T09:00:00"])
    rows.append(["O2007", "C001", "13/06/2024", "80.00", "USD", "completed", "2024-03-06T10:00:00"])
    return rows


def build_fx() -> list[list[str]]:
    rng = random.Random(SEED + 1)
    rows = []
    for d in DAYS:
        if d.weekday() >= 5:  # no rates published at weekends -> use the last known rate
            continue
        rows.append([d.isoformat(), "USD", "1.0"])
        rows.append([d.isoformat(), "EUR", f"{1.08 + rng.randint(-150, 150) / 10000:.4f}"])
        rows.append([d.isoformat(), "GBP", f"{1.26 + rng.randint(-150, 150) / 10000:.4f}"])
    return rows


def write_csv(path: Path, header: list[str], rows) -> None:
    with path.open("w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh, lineterminator="\n")
        w.writerow(header)
        w.writerows(rows)


def generate(out: Path) -> list[Path]:
    out.mkdir(parents=True, exist_ok=True)
    files = [out / "customers.csv", out / "orders.csv", out / "fx_rates.csv"]
    write_csv(files[0], ["customer_id", "name", "email", "address", "city", "updated_at"], CUSTOMERS)
    write_csv(files[1], ["order_id", "customer_id", "order_date", "amount", "currency", "status", "updated_at"],
              build_orders())
    write_csv(files[2], ["date", "currency", "rate_to_usd"], build_fx())
    return files


if __name__ == "__main__":
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--out", default=str(Path(__file__).resolve().parent))
    for f in generate(Path(ap.parse_args().out)):
        print(f"wrote {f}")
