"""Maintainer tool: compute grader/expected.json from data/ with plain Python (no SQL).

This is an independent "oracle" implementation of the lab rules, so the expected
outputs do not come from the reference solution. Run it after changing data/:

    python labs/de-01-orders-pipeline/grader/make_expected.py
"""

from __future__ import annotations

import csv
import json
from datetime import date
from pathlib import Path

HERE = Path(__file__).resolve().parent


def _date(text: str):
    t = text.strip().split("T")[0].split(" ")[0]
    parts = t.replace("/", "-").split("-")
    try:
        if len(parts[0]) == 4:          # YYYY-MM-DD or YYYY/MM/DD
            y, m, d = map(int, parts)
        else:                            # MM/DD/YYYY
            m, d, y = map(int, parts)
        return date(y, m, d).isoformat()
    except (ValueError, TypeError):
        return None


def _rows(path: Path):
    with open(path, newline="", encoding="utf-8") as fh:
        return [{k: (v or "").strip() for k, v in r.items()} for r in csv.DictReader(fh)]


def compute(data_dir: Path) -> dict:
    orders = _rows(data_dir / "orders.csv")
    customers = _rows(data_dir / "customers.csv")
    rates = _rows(data_dir / "fx_rates.csv")

    latest = {}
    for r in orders:
        if r["order_id"] not in latest or r["updated_at"] >= latest[r["order_id"]]["updated_at"]:
            latest[r["order_id"]] = r

    def rate(ccy, day):
        cands = [r for r in rates if r["currency"].upper() == ccy and r["date"] <= day]
        return float(max(cands, key=lambda r: r["date"])["rate_to_usd"]) if cands else None

    cust_ids = {c["customer_id"] for c in customers}
    clean, rejected = {}, {}
    for oid, r in sorted(latest.items()):
        day = _date(r["order_date"])
        try:
            amt = float(r["amount"])
        except ValueError:
            amt = None
        ccy = r["currency"].upper()
        if day is None:
            rejected[oid] = "bad_date"
        elif amt is None or amt <= 0:
            rejected[oid] = "bad_amount"
        elif rate(ccy, day) is None:
            rejected[oid] = "unknown_currency"
        elif r["customer_id"] not in cust_ids:
            rejected[oid] = "unknown_customer"
        else:
            clean[oid] = {"order_id": oid, "customer_id": r["customer_id"], "order_date": day, "amount": amt,
                          "currency": ccy, "amount_usd": round(amt * rate(ccy, day), 2),
                          "status": r["status"].lower(), "updated_at": r["updated_at"]}

    completed = [o for o in clean.values() if o["status"] == "completed"]
    daily = {}
    for o in completed:
        d = daily.setdefault(o["order_date"], [0, 0.0])
        d[0] += 1
        d[1] += o["amount_usd"]
    daily_rows = [[k, v[0], round(v[1], 2)] for k, v in sorted(daily.items())]

    # SCD2
    uniq = sorted({tuple(c[k] for k in ["customer_id", "name", "email", "address", "city", "updated_at"])
                   for c in customers}, key=lambda t: (t[0], t[5]))
    dim = []
    for cid, name, email, addr, city, upd in uniq:
        prev = dim[-1] if dim and dim[-1][1] == cid else None
        if prev and (prev[4], prev[5]) == (addr, city):
            prev[2], prev[3] = name, email
            continue
        if prev:
            prev[7], prev[8] = upd[:10], 0
        dim.append([len(dim) + 1, cid, name, email, addr, city, upd[:10], None, 1])

    ltv = []
    for cid in sorted({d[1] for d in dim}):
        mine = [o for o in completed if o["customer_id"] == cid]
        ltv.append([cid, len(mine), round(sum(o["amount_usd"] for o in mine), 2),
                    min((o["order_date"] for o in mine), default=None),
                    max((o["order_date"] for o in mine), default=None)])

    return {
        "raw_counts": {"raw_orders": len(orders), "raw_customers": len(customers), "fx_rates": len(rates)},
        "orders": [list(o.values()) for o in sorted(clean.values(), key=lambda o: o["order_id"])],
        "rejected_orders": [[k, v] for k, v in sorted(rejected.items())],
        "daily_revenue": daily_rows,
        "customer_ltv": ltv,
        "dim_customer": dim,
    }


if __name__ == "__main__":
    out = HERE / "expected.json"
    out.write_text(json.dumps(compute(HERE.parent / "data"), indent=1) + "\n", encoding="utf-8")
    print(f"wrote {out}")
