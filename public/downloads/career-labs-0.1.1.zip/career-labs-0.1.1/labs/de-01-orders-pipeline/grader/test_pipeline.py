"""Graded checks for de-01-orders-pipeline. Expected values live in expected.json."""

import json
import sqlite3
from pathlib import Path

import pytest

LAB = Path(__file__).resolve().parent.parent
DATA = LAB / "data"
EXPECTED = json.loads((Path(__file__).parent / "expected.json").read_text(encoding="utf-8"))
TABLES = ["orders", "rejected_orders", "daily_revenue", "customer_ltv", "dim_customer"]


def rows(conn, sql):
    return [list(r) for r in conn.execute(sql)]


def same_rows(got, expected):
    assert len(got) == len(expected), f"expected {len(expected)} rows, got {len(got)}"
    for g, e in zip(got, expected):
        assert g == pytest.approx(e, abs=0.006), f"row {g} should be {e}"


def stage(sol, *steps):
    """Load the raw data into a fresh in-memory db and run only the given build steps."""
    conn = sqlite3.connect(":memory:")
    sol.load_raw(conn, DATA)
    for step in steps:
        getattr(sol, step)(conn)
    return conn


@pytest.mark.points(10)
def test_parse_date(sol):
    """parse_date handles ISO, YYYY/MM/DD, MM/DD/YYYY, timestamps; rejects junk"""
    assert sol.parse_date("2024-03-05") == "2024-03-05"
    assert sol.parse_date("2024/03/05") == "2024-03-05"
    assert sol.parse_date("03/05/2024") == "2024-03-05"
    assert sol.parse_date("2024-03-05T23:29:00") == "2024-03-05"
    assert sol.parse_date(" 2024-03-01 ") == "2024-03-01"
    for bad in ["not-a-date", "2024-02-30", "13/06/2024", "", None]:
        assert sol.parse_date(bad) is None, f"parse_date({bad!r}) should be None"


@pytest.mark.points(5)
def test_load_raw_counts(sol):
    """load_raw stages every CSV row (no cleaning yet) into raw_* tables"""
    conn = sqlite3.connect(":memory:")
    counts = sol.load_raw(conn, DATA)
    assert counts == EXPECTED["raw_counts"]
    assert conn.execute("SELECT COUNT(*) FROM raw_orders").fetchone()[0] == EXPECTED["raw_counts"]["raw_orders"]
    assert conn.execute("SELECT COUNT(*) FROM raw_customers").fetchone()[0] == EXPECTED["raw_counts"]["raw_customers"]


@pytest.mark.points(15)
def test_dedupe_keeps_latest_update(sol):
    """one row per order_id; the latest updated_at wins (stale late rows ignored)"""
    built = stage(sol, "build_orders")
    got = rows(built, "SELECT order_id, amount, status, order_date, updated_at FROM orders ORDER BY order_id")
    ids = [r[0] for r in got]
    assert len(ids) == len(set(ids)), "orders still has duplicate order_id values"
    by_id = {r[0]: r for r in got}
    assert by_id["O1001"][1] == pytest.approx(999.99), "price correction for O1001 was not applied"
    assert by_id["O1006"][2] == "cancelled", "late cancellation of O1006 was not applied"
    assert by_id["O1015"][2] == "completed", "O1015 moved from pending to completed"
    assert by_id["O1021"][3] == "2024-03-07", "O1021's corrected order_date was not applied"
    assert by_id["O1009"][1] == pytest.approx(341.37), "an OLDER update arrived late; it must not win"
    exp = [[o[0], o[3], o[6], o[2], o[7]] for o in EXPECTED["orders"]]
    same_rows(got, exp)


@pytest.mark.points(10)
def test_currency_conversion(sol):
    """currency is normalised (trim/upper) and amount_usd uses the as-of fx rate"""
    built = stage(sol, "build_orders")
    got = rows(built, "SELECT order_id, currency, amount_usd FROM orders ORDER BY order_id")
    same_rows(got, [[o[0], o[4], o[5]] for o in EXPECTED["orders"]])
    weekend = dict(rows(built, "SELECT order_id, amount_usd FROM orders WHERE order_id = 'O1032'"))
    assert weekend["O1032"] == pytest.approx(round(446.53 * 1.0935, 2)), \
        "weekend order should use Friday's EUR rate (last known rate on or before the date)"


@pytest.mark.points(10)
def test_rejected_orders(sol):
    """bad dates, bad amounts, unknown currency/customer go to rejected_orders with a reason"""
    built = stage(sol, "build_orders")
    got = rows(built, "SELECT order_id, reason FROM rejected_orders ORDER BY order_id")
    assert got == EXPECTED["rejected_orders"]
    clean_ids = {r[0] for r in rows(built, "SELECT order_id FROM orders")}
    assert not clean_ids & {r[0] for r in got}, "a rejected order also appears in orders"


@pytest.mark.points(15)
def test_daily_revenue(sol):
    """daily_revenue = completed orders only, USD, rounded to cents"""
    built = stage(sol, "build_orders", "build_daily_revenue")
    got = rows(built, "SELECT order_date, orders_count, revenue_usd FROM daily_revenue ORDER BY order_date")
    same_rows(got, EXPECTED["daily_revenue"])


@pytest.mark.points(10)
def test_customer_ltv(sol):
    """customer_ltv has every current customer, including ones with no orders"""
    built = stage(sol, "build_dim_customer", "build_orders", "build_customer_ltv")
    got = rows(built, "SELECT customer_id, orders_count, ltv_usd, first_order_date, last_order_date "
                      "FROM customer_ltv ORDER BY customer_id")
    same_rows(got, EXPECTED["customer_ltv"])


@pytest.mark.points(15)
def test_scd2_dim_customer(sol):
    """dim_customer keeps address history (SCD type 2) with valid_from/valid_to/is_current"""
    built = stage(sol, "build_dim_customer")
    got = rows(built, "SELECT customer_id, name, email, address, city, valid_from, valid_to, is_current "
                      "FROM dim_customer ORDER BY customer_id, valid_from")
    exp = [r[1:] for r in EXPECTED["dim_customer"]]
    current = [r for r in got if r[7] == 1]
    assert len(current) == len({r[0] for r in got}), "each customer needs exactly one is_current = 1 row"
    assert got == exp


@pytest.mark.points(10)
def test_idempotent_rerun(sol, tmp_path):
    """running the pipeline twice on the same database gives identical tables"""
    db = tmp_path / "warehouse.db"
    sol.run_pipeline(db, DATA)
    conn = sqlite3.connect(db)
    first = {t: rows(conn, f"SELECT * FROM {t} ORDER BY 1, 2") for t in TABLES}
    conn.close()
    sol.run_pipeline(db, DATA)
    conn = sqlite3.connect(db)
    second = {t: rows(conn, f"SELECT * FROM {t} ORDER BY 1, 2") for t in TABLES}
    conn.close()
    for t in TABLES:
        assert first[t] == second[t], f"table {t} changed after a re-run (duplicates appended?)"
