"""Reference solution for de-01-orders-pipeline.

Raw CSV -> sqlite staging -> cleaned `orders` -> `daily_revenue`, `customer_ltv`,
and an SCD type-2 `dim_customer`. Safe to run any number of times.
"""

from __future__ import annotations

import csv
import sqlite3
import sys
from datetime import datetime
from pathlib import Path

RAW_ORDER_COLS = ["order_id", "customer_id", "order_date", "amount", "currency", "status", "updated_at"]
RAW_CUSTOMER_COLS = ["customer_id", "name", "email", "address", "city", "updated_at"]
DATE_FORMATS = ["%Y-%m-%d", "%Y/%m/%d", "%m/%d/%Y"]


def parse_date(text: str | None) -> str | None:
    """Return an ISO date 'YYYY-MM-DD' or None if the value is not a real date."""
    if text is None:
        return None
    text = text.strip()
    if "T" in text:
        text = text.split("T", 1)[0]
    elif " " in text:
        text = text.split(" ", 1)[0]
    for fmt in DATE_FORMATS:
        try:
            return datetime.strptime(text, fmt).date().isoformat()
        except ValueError:
            continue
    return None


def _read_csv(path: Path) -> list[dict]:
    with open(path, newline="", encoding="utf-8") as fh:
        return list(csv.DictReader(fh))


def load_raw(conn: sqlite3.Connection, data_dir) -> dict:
    """(Re)create raw_orders, raw_customers and fx_rates from the CSV files."""
    data_dir = Path(data_dir)
    conn.execute("DROP TABLE IF EXISTS raw_orders")
    conn.execute("DROP TABLE IF EXISTS raw_customers")
    conn.execute("DROP TABLE IF EXISTS fx_rates")
    conn.execute(f"CREATE TABLE raw_orders ({', '.join(c + ' TEXT' for c in RAW_ORDER_COLS)})")
    conn.execute(f"CREATE TABLE raw_customers ({', '.join(c + ' TEXT' for c in RAW_CUSTOMER_COLS)})")
    conn.execute("CREATE TABLE fx_rates (date TEXT, currency TEXT, rate_to_usd REAL)")
    orders = _read_csv(data_dir / "orders.csv")
    customers = _read_csv(data_dir / "customers.csv")
    rates = _read_csv(data_dir / "fx_rates.csv")
    conn.executemany(
        f"INSERT INTO raw_orders VALUES ({', '.join('?' * len(RAW_ORDER_COLS))})",
        [[r[c] for c in RAW_ORDER_COLS] for r in orders],
    )
    conn.executemany(
        f"INSERT INTO raw_customers VALUES ({', '.join('?' * len(RAW_CUSTOMER_COLS))})",
        [[r[c] for c in RAW_CUSTOMER_COLS] for r in customers],
    )
    conn.executemany(
        "INSERT INTO fx_rates VALUES (?, ?, ?)",
        [(r["date"].strip(), r["currency"].strip().upper(), float(r["rate_to_usd"])) for r in rates],
    )
    conn.commit()
    return {"raw_orders": len(orders), "raw_customers": len(customers), "fx_rates": len(rates)}


def _rate(conn: sqlite3.Connection, currency: str, day: str) -> float | None:
    row = conn.execute(
        "SELECT rate_to_usd FROM fx_rates WHERE currency = ? AND date <= ? ORDER BY date DESC LIMIT 1",
        (currency, day),
    ).fetchone()
    return row[0] if row else None


def build_orders(conn: sqlite3.Connection) -> dict:
    """Dedupe raw orders (latest updated_at wins), validate, convert to USD."""
    conn.execute("DROP TABLE IF EXISTS orders")
    conn.execute("DROP TABLE IF EXISTS rejected_orders")
    conn.execute(
        "CREATE TABLE orders (order_id TEXT PRIMARY KEY, customer_id TEXT, order_date TEXT, amount REAL, "
        "currency TEXT, amount_usd REAL, status TEXT, updated_at TEXT)"
    )
    conn.execute("CREATE TABLE rejected_orders (order_id TEXT PRIMARY KEY, reason TEXT)")

    latest: dict[str, tuple] = {}
    cols = ", ".join(RAW_ORDER_COLS)
    for row in conn.execute(f"SELECT {cols} FROM raw_orders ORDER BY rowid"):
        rec = tuple((v or "").strip() for v in row)
        oid, upd = rec[0], rec[6]
        if oid not in latest or upd >= latest[oid][6]:
            latest[oid] = rec

    known_customers = {r[0].strip() for r in conn.execute("SELECT customer_id FROM raw_customers")}
    good, bad = [], []
    for oid in sorted(latest):
        _, cust, raw_date, raw_amount, raw_ccy, raw_status, upd = latest[oid]
        day = parse_date(raw_date)
        if day is None:
            bad.append((oid, "bad_date"))
            continue
        try:
            amount = float(raw_amount)
        except ValueError:
            amount = None
        if amount is None or amount <= 0:
            bad.append((oid, "bad_amount"))
            continue
        ccy = raw_ccy.upper()
        rate = _rate(conn, ccy, day)
        if rate is None:
            bad.append((oid, "unknown_currency"))
            continue
        if cust not in known_customers:
            bad.append((oid, "unknown_customer"))
            continue
        good.append((oid, cust, day, amount, ccy, round(amount * rate, 2), raw_status.lower(), upd))
    conn.executemany("INSERT INTO orders VALUES (?, ?, ?, ?, ?, ?, ?, ?)", good)
    conn.executemany("INSERT INTO rejected_orders VALUES (?, ?)", bad)
    conn.commit()
    return {"orders": len(good), "rejected_orders": len(bad)}


def build_daily_revenue(conn: sqlite3.Connection) -> int:
    conn.execute("DROP TABLE IF EXISTS daily_revenue")
    conn.execute(
        """
        CREATE TABLE daily_revenue AS
        SELECT order_date, COUNT(*) AS orders_count, ROUND(SUM(amount_usd), 2) AS revenue_usd
        FROM orders WHERE status = 'completed'
        GROUP BY order_date ORDER BY order_date
        """
    )
    conn.commit()
    return conn.execute("SELECT COUNT(*) FROM daily_revenue").fetchone()[0]


def build_dim_customer(conn: sqlite3.Connection) -> int:
    """SCD type 2 on (address, city); name/email take the latest value within a version."""
    conn.execute("DROP TABLE IF EXISTS dim_customer")
    conn.execute(
        "CREATE TABLE dim_customer (customer_key INTEGER PRIMARY KEY, customer_id TEXT, name TEXT, email TEXT, "
        "address TEXT, city TEXT, valid_from TEXT, valid_to TEXT, is_current INTEGER)"
    )
    rows = sorted(
        {tuple((v or "").strip() for v in r) for r in conn.execute(
            "SELECT customer_id, name, email, address, city, updated_at FROM raw_customers")},
        key=lambda r: (r[0], r[5]),
    )
    versions: list[dict] = []
    for cid, name, email, address, city, upd in rows:
        prev = versions[-1] if versions and versions[-1]["customer_id"] == cid else None
        if prev and (prev["address"], prev["city"]) == (address, city):
            prev["name"], prev["email"] = name, email
            continue
        if prev:
            prev["valid_to"] = upd[:10]
            prev["is_current"] = 0
        versions.append({"customer_id": cid, "name": name, "email": email, "address": address, "city": city,
                         "valid_from": upd[:10], "valid_to": None, "is_current": 1})
    conn.executemany(
        "INSERT INTO dim_customer VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
        [(i + 1, v["customer_id"], v["name"], v["email"], v["address"], v["city"], v["valid_from"],
          v["valid_to"], v["is_current"]) for i, v in enumerate(versions)],
    )
    conn.commit()
    return len(versions)


def build_customer_ltv(conn: sqlite3.Connection) -> int:
    conn.execute("DROP TABLE IF EXISTS customer_ltv")
    conn.execute(
        """
        CREATE TABLE customer_ltv AS
        SELECT d.customer_id,
               COUNT(o.order_id) AS orders_count,
               ROUND(COALESCE(SUM(o.amount_usd), 0), 2) AS ltv_usd,
               MIN(o.order_date) AS first_order_date,
               MAX(o.order_date) AS last_order_date
        FROM dim_customer d
        LEFT JOIN orders o ON o.customer_id = d.customer_id AND o.status = 'completed'
        WHERE d.is_current = 1
        GROUP BY d.customer_id ORDER BY d.customer_id
        """
    )
    conn.commit()
    return conn.execute("SELECT COUNT(*) FROM customer_ltv").fetchone()[0]


def run_pipeline(db_path, data_dir) -> dict:
    conn = sqlite3.connect(str(db_path))
    try:
        counts = load_raw(conn, data_dir)
        counts["dim_customer"] = build_dim_customer(conn)
        counts.update(build_orders(conn))
        counts["daily_revenue"] = build_daily_revenue(conn)
        counts["customer_ltv"] = build_customer_ltv(conn)
        return counts
    finally:
        conn.close()


if __name__ == "__main__":
    here = Path(__file__).resolve().parent
    db = sys.argv[1] if len(sys.argv) > 1 else "warehouse.db"
    data = sys.argv[2] if len(sys.argv) > 2 else here.parent / "data"
    for table, n in run_pipeline(db, data).items():
        print(f"{table:>16}: {n} rows")
