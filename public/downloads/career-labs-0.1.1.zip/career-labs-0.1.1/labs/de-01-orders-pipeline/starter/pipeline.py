"""de-01-orders-pipeline: YOUR SOLUTION GOES HERE.

Read ../README.md first. Fill in every function marked TODO, then run:

    python -m labgrade run de-01-orders-pipeline

`load_raw` and `run_pipeline` are already written for you.
"""

from __future__ import annotations

import csv
import sqlite3
import sys
from pathlib import Path

RAW_ORDER_COLS = ["order_id", "customer_id", "order_date", "amount", "currency", "status", "updated_at"]
RAW_CUSTOMER_COLS = ["customer_id", "name", "email", "address", "city", "updated_at"]


def parse_date(text: str | None) -> str | None:
    """Return an ISO date 'YYYY-MM-DD', or None if `text` is not a real date.

    Accept: 2024-03-05, 2024/03/05, 03/05/2024 (US month/day/year) and timestamps
    like 2024-03-05T23:29:00 (keep only the date). Strip spaces. Anything else
    (including impossible dates such as 2024-02-30) -> None.
    """
    # TODO: try each format with datetime.strptime and return .date().isoformat()
    raise NotImplementedError("parse_date")


def _read_csv(path: Path) -> list[dict]:
    with open(path, newline="", encoding="utf-8") as fh:
        return list(csv.DictReader(fh))


def load_raw(conn: sqlite3.Connection, data_dir) -> dict:
    """(Re)create raw_orders, raw_customers (all TEXT) and fx_rates from the CSV files."""
    data_dir = Path(data_dir)
    for table in ("raw_orders", "raw_customers", "fx_rates"):
        conn.execute(f"DROP TABLE IF EXISTS {table}")
    conn.execute(f"CREATE TABLE raw_orders ({', '.join(c + ' TEXT' for c in RAW_ORDER_COLS)})")
    conn.execute(f"CREATE TABLE raw_customers ({', '.join(c + ' TEXT' for c in RAW_CUSTOMER_COLS)})")
    conn.execute("CREATE TABLE fx_rates (date TEXT, currency TEXT, rate_to_usd REAL)")
    orders = _read_csv(data_dir / "orders.csv")
    customers = _read_csv(data_dir / "customers.csv")
    rates = _read_csv(data_dir / "fx_rates.csv")
    conn.executemany(f"INSERT INTO raw_orders VALUES ({', '.join('?' * len(RAW_ORDER_COLS))})",
                     [[r[c] for c in RAW_ORDER_COLS] for r in orders])
    conn.executemany(f"INSERT INTO raw_customers VALUES ({', '.join('?' * len(RAW_CUSTOMER_COLS))})",
                     [[r[c] for c in RAW_CUSTOMER_COLS] for r in customers])
    conn.executemany("INSERT INTO fx_rates VALUES (?, ?, ?)",
                     [(r["date"].strip(), r["currency"].strip().upper(), float(r["rate_to_usd"])) for r in rates])
    conn.commit()
    return {"raw_orders": len(orders), "raw_customers": len(customers), "fx_rates": len(rates)}


def build_orders(conn: sqlite3.Connection) -> dict:
    """Create `orders` and `rejected_orders` from raw_orders.

    orders(order_id TEXT PRIMARY KEY, customer_id, order_date, amount REAL, currency,
           amount_usd REAL, status, updated_at)
    rejected_orders(order_id TEXT PRIMARY KEY, reason TEXT)

    1. Strip spaces from every value. Keep ONE row per order_id: the latest updated_at.
    2. Validate that row, in this order, and reject with the first matching reason:
       bad_date, bad_amount (not a number or <= 0), unknown_currency (no rate on or
       before the order date), unknown_customer (id not in raw_customers).
    3. currency = upper case; status = lower case;
       amount_usd = round(amount * rate, 2) using the latest fx rate ON OR BEFORE order_date.
    Return {"orders": n_good, "rejected_orders": n_bad}.
    """
    # TODO
    raise NotImplementedError("build_orders")


def build_daily_revenue(conn: sqlite3.Connection) -> int:
    """Create daily_revenue(order_date, orders_count, revenue_usd) from COMPLETED orders.

    revenue_usd = ROUND(SUM(amount_usd), 2). Return the number of rows.
    """
    # TODO
    raise NotImplementedError("build_daily_revenue")


def build_dim_customer(conn: sqlite3.Connection) -> int:
    """Create dim_customer as an SCD type-2 table from raw_customers.

    Columns: customer_key INTEGER PRIMARY KEY (1, 2, 3... ordered by customer_id, valid_from),
    customer_id, name, email, address, city, valid_from, valid_to, is_current.

    - Strip spaces; drop exact duplicate rows; walk each customer's rows by updated_at.
    - A NEW version starts only when (address, city) changes.
      Other changes (name, email) update the current version in place.
    - valid_from = date part of the updated_at that started the version;
      valid_to = valid_from of the next version (NULL for the current one);
      is_current = 1 for the latest version, else 0.
    Return the number of rows.
    """
    # TODO
    raise NotImplementedError("build_dim_customer")


def build_customer_ltv(conn: sqlite3.Connection) -> int:
    """Create customer_ltv(customer_id, orders_count, ltv_usd, first_order_date, last_order_date).

    One row per current customer in dim_customer (even with no orders: 0, 0.0, NULL, NULL).
    Only COMPLETED orders count. ltv_usd rounded to cents. Return the number of rows.
    """
    # TODO
    raise NotImplementedError("build_customer_ltv")


def run_pipeline(db_path, data_dir) -> dict:
    """Run every step. Must be safe to run again on the same database (idempotent)."""
    conn = sqlite3.connect(str(db_path))
    try:
        counts = load_raw(conn, data_dir)
        counts["dim_customer"] = build_dim_customer(conn)
        counts.update(build_orders(conn))
        counts["daily_revenue"] = build_daily_revenue(conn)
        counts["customer_ltv"] = build_customer_ltv(conn)
        return counts
    finally:
        conn.close()


if __name__ == "__main__":
    here = Path(__file__).resolve().parent
    db = sys.argv[1] if len(sys.argv) > 1 else "warehouse.db"
    data = sys.argv[2] if len(sys.argv) > 2 else here.parent / "data"
    for table, n in run_pipeline(db, data).items():
        print(f"{table:>16}: {n} rows")
