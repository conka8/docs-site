# DE-02: SQL interview drill (8 questions)

## Scenario

These are the eight SQL patterns that come up again and again in data analyst and data
engineer interviews. Each one is a single `SELECT`, run against a small shop database
(users, orders, logins, employees, raw signups). The grader compares your result set
with the expected one: same columns, same order, numbers within 0.01.

## The database

```
users       (user_id, name, country, signup_date)
orders      (order_id, user_id, order_date, amount, status)      -- status: completed | refunded
logins      (user_id, login_date)                                -- may contain the same day twice
employees   (emp_id, name, dept, salary)
signups_raw (signup_id, email, created_at, source)               -- messy duplicate emails
```

The data is in `data/shop.sql`. Explore it:

```
python labs/de-02-sql-interview/data/query.py labs/de-02-sql-interview/starter/q1_running_total.sql
python labs/de-02-sql-interview/data/query.py --build shop.db      # then open shop.db in any SQLite tool
```

## Your task

Replace the placeholder in each `starter/qN_*.sql` file with one query. The header comment of
each file gives the exact columns, the sort order and the rounding.

| # | File | Pattern |
|---|---|---|
| 1 | `q1_running_total.sql` | running total, `SUM() OVER (ORDER BY)` |
| 2 | `q2_top_n_per_group.sql` | top-N per group with ties, `DENSE_RANK` |
| 3 | `q3_dedupe.sql` | dedupe, keep the earliest row, `ROW_NUMBER` |
| 4 | `q4_retention_cohort.sql` | signup cohorts and month-1 retention |
| 5 | `q5_gaps_and_islands.sql` | longest streak of consecutive days |
| 6 | `q6_month_over_month.sql` | growth vs previous month, `LAG` |
| 7 | `q7_second_order.sql` | time to second purchase |
| 8 | `q8_revenue_share.sql` | share of total, window over the whole result |

SQLite dialect: use `strftime('%Y-%m', d)` for months and `julianday(d)` for day arithmetic.

## Run the grader

```
python -m labgrade run de-02-sql-interview
python -m labgrade run de-02-sql-interview --test test_q5_gaps_and_islands   # just one question
```

## Points

| Graded check | Points | What it checks |
|---|---:|---|
| `test_q1_running_total` | 10 | Q1 daily March revenue with a running total (SUM OVER ORDER BY) |
| `test_q2_top_n_per_group` | 10 | Q2 top-2 distinct salaries per department, ties included (DENSE_RANK) |
| `test_q3_dedupe` | 10 | Q3 dedupe messy emails, keep the earliest signup (ROW_NUMBER) |
| `test_q4_retention_cohort` | 15 | Q4 month-1 retention by signup cohort |
| `test_q5_gaps_and_islands` | 15 | Q5 longest consecutive-day login streak per user (gaps and islands) |
| `test_q6_month_over_month` | 10 | Q6 month-over-month revenue growth (LAG) |
| `test_q7_second_order` | 15 | Q7 days between first and second completed order |
| `test_q8_revenue_share` | 15 | Q8 revenue share by country (window over the whole result) |
| **Total** | **100** | |

## Portfolio tip

Interviewers care about how you explain your SQL as much as the query. For each answer, add a
two-line comment: the pattern's name and why it works.

## For maintainers

`data/generate.py` rebuilds `shop.sql` (seeded). `grader/make_expected.py` recomputes the expected
results in plain Python (no SQL window functions), independently of `reference/`.
