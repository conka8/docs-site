"""Run a .sql file against the lab database and print the result as a table.

    python labs/de-02-sql-interview/data/query.py starter/q1_running_total.sql
    python labs/de-02-sql-interview/data/query.py --build shop.db   # write a real sqlite file to explore
"""

from __future__ import annotations

import argparse
import sqlite3
import sys
from pathlib import Path

SEED_SQL = Path(__file__).resolve().parent / "shop.sql"


def connect() -> sqlite3.Connection:
    conn = sqlite3.connect(":memory:")
    conn.executescript(SEED_SQL.read_text(encoding="utf-8"))
    return conn


def run_sql_file(conn: sqlite3.Connection, path) -> tuple[list[str], list[tuple]]:
    cur = conn.execute(Path(path).read_text(encoding="utf-8"))
    cols = [d[0] for d in cur.description] if cur.description else []
    return cols, cur.fetchall()


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("sql_file", nargs="?")
    ap.add_argument("--build", metavar="DB_FILE", help="write the dataset to a sqlite file and exit")
    args = ap.parse_args(argv)
    if args.build:
        disk = sqlite3.connect(args.build)
        disk.executescript(SEED_SQL.read_text(encoding="utf-8"))
        disk.close()
        print(f"wrote {args.build}")
        return 0
    if not args.sql_file:
        ap.error("give a .sql file or --build")
    cols, rows = run_sql_file(connect(), args.sql_file)
    widths = [max([len(str(c))] + [len(str(r[i])) for r in rows]) for i, c in enumerate(cols)]
    print("  ".join(str(c).ljust(w) for c, w in zip(cols, widths)))
    print("  ".join("-" * w for w in widths))
    for r in rows:
        print("  ".join(str(v).ljust(w) for v, w in zip(r, widths)))
    print(f"({len(rows)} rows)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
