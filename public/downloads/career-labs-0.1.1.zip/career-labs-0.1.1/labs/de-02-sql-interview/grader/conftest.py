import sqlite3
from pathlib import Path

import pytest

from labgrade.helpers import lab_dir_from, register_points_marker, solution_file

LAB_DIR = lab_dir_from(__file__)
SEED_SQL = LAB_DIR / "data" / "shop.sql"


def pytest_configure(config):
    register_points_marker(config)


@pytest.fixture
def db():
    conn = sqlite3.connect(":memory:")
    conn.executescript(SEED_SQL.read_text(encoding="utf-8"))
    yield conn
    conn.close()


@pytest.fixture
def run_answer(db):
    """Run the member's <name>.sql and return (column_names, rows)."""

    def _run(name: str):
        path = solution_file(LAB_DIR, f"{name}.sql")
        sql = path.read_text(encoding="utf-8")
        try:
            cur = db.execute(sql)
        except sqlite3.Warning:
            raise AssertionError(f"{path.name} must contain exactly ONE SELECT statement")
        except sqlite3.Error as exc:
            raise AssertionError(f"{path.name} failed to run: {exc}")
        cols = [c[0].lower() for c in cur.description] if cur.description else []
        return cols, [list(r) for r in cur.fetchall()]

    return _run
