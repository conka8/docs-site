"""Maintainer tool: compute grader/expected.json with plain Python (no window functions).

An independent oracle, so expected results don't come from the reference SQL.
Run after changing data/:  python labs/de-02-sql-interview/grader/make_expected.py
"""

from __future__ import annotations

import json
import sqlite3
from collections import defaultdict
from datetime import date, timedelta
from pathlib import Path

HERE = Path(__file__).resolve().parent
SEED_SQL = HERE.parent / "data" / "shop.sql"


def load(seed_sql: Path = SEED_SQL) -> dict[str, list[dict]]:
    conn = sqlite3.connect(":memory:")
    conn.row_factory = sqlite3.Row
    conn.executescript(seed_sql.read_text(encoding="utf-8"))
    tables = ["users", "orders", "logins", "employees", "signups_raw"]
    return {t: [dict(r) for r in conn.execute(f"SELECT * FROM {t}")] for t in tables}


def q1(d):
    by_day = defaultdict(float)
    for o in d["orders"]:
        if o["status"] == "completed" and "2024-03-01" <= o["order_date"] <= "2024-03-31":
            by_day[o["order_date"]] += o["amount"]
    rows, run = [], 0.0
    for day in sorted(by_day):
        run += by_day[day]
        rows.append([day, round(by_day[day], 2), round(run, 2)])
    return ["order_date", "revenue", "running_total"], rows


def q2(d):
    rows = []
    for dept in sorted({e["dept"] for e in d["employees"]}):
        emps = [e for e in d["employees"] if e["dept"] == dept]
        levels = sorted({e["salary"] for e in emps}, reverse=True)
        for e in emps:
            rank = levels.index(e["salary"]) + 1
            if rank <= 2:
                rows.append([dept, e["name"], e["salary"], rank])
    rows.sort(key=lambda r: (r[0], r[3], r[1]))
    return ["dept", "name", "salary", "salary_rank"], rows


def q3(d):
    groups = defaultdict(list)
    for s in d["signups_raw"]:
        groups[s["email"].strip().lower()].append(s)
    rows = []
    for email in sorted(groups):
        first = min(groups[email], key=lambda s: s["created_at"])
        rows.append([email, first["created_at"], first["source"], len(groups[email])])
    return ["email", "first_created_at", "first_source", "raw_rows"], rows


def q4(d):
    logins = defaultdict(set)
    for l in d["logins"]:
        logins[l["user_id"]].add(l["login_date"][:7])
    cohorts = defaultdict(lambda: [0, 0])
    for u in d["users"]:
        y, m = int(u["signup_date"][:4]), int(u["signup_date"][5:7])
        nxt = f"{y + (m == 12):04d}-{(m % 12) + 1:02d}"
        c = cohorts[u["signup_date"][:7]]
        c[0] += 1
        c[1] += nxt in logins[u["user_id"]]
    return (["cohort_month", "cohort_size", "retained_m1", "retention_pct"],
            [[k, v[0], v[1], round(100.0 * v[1] / v[0], 1)] for k, v in sorted(cohorts.items())])


def q5(d):
    days = defaultdict(set)
    for l in d["logins"]:
        days[l["user_id"]].add(date.fromisoformat(l["login_date"]))
    rows = []
    for uid in sorted(days):
        best = None
        ordered = sorted(days[uid])
        start = prev = ordered[0]
        for day in ordered[1:] + [None]:
            if day is not None and day == prev + timedelta(days=1):
                prev = day
                continue
            length = (prev - start).days + 1
            if best is None or length > best[2]:
                best = (start, prev, length)
            if day is not None:
                start = prev = day
        rows.append([uid, best[0].isoformat(), best[1].isoformat(), best[2]])
    return ["user_id", "streak_start", "streak_end", "streak_days"], rows


def q6(d):
    by_month = defaultdict(float)
    for o in d["orders"]:
        if o["status"] == "completed":
            by_month[o["order_date"][:7]] += o["amount"]
    rows, prev = [], None
    for m in sorted(by_month):
        rev = by_month[m]
        growth = None if prev is None else round(100.0 * (rev - prev) / prev, 1)
        rows.append([m, round(rev, 2), None if prev is None else round(prev, 2), growth])
        prev = rev
    return ["month", "revenue", "prev_revenue", "growth_pct"], rows


def q7(d):
    per_user = defaultdict(list)
    for o in d["orders"]:
        if o["status"] == "completed":
            per_user[o["user_id"]].append((o["order_date"], o["order_id"]))
    rows = []
    for uid in sorted(per_user):
        os_ = sorted(per_user[uid])
        if len(os_) >= 2:
            a, b = os_[0][0], os_[1][0]
            rows.append([uid, a, b, (date.fromisoformat(b) - date.fromisoformat(a)).days])
    return ["user_id", "first_order_date", "second_order_date", "days_between"], rows


def q8(d):
    country = {u["user_id"]: u["country"] for u in d["users"]}
    rev = defaultdict(float)
    for o in d["orders"]:
        if o["status"] == "completed":
            rev[country[o["user_id"]]] += o["amount"]
    total = sum(rev.values())
    rows = [[c, round(v, 2), round(100.0 * v / total, 2)] for c, v in rev.items()]
    rows.sort(key=lambda r: (-r[1], r[0]))
    return ["country", "revenue", "pct_of_total"], rows


QUESTIONS = {
    "q1_running_total": q1, "q2_top_n_per_group": q2, "q3_dedupe": q3, "q4_retention_cohort": q4,
    "q5_gaps_and_islands": q5, "q6_month_over_month": q6, "q7_second_order": q7, "q8_revenue_share": q8,
}


def compute(seed_sql: Path = SEED_SQL) -> dict:
    d = load(seed_sql)
    out = {}
    for name, fn in QUESTIONS.items():
        cols, rows = fn(d)
        out[name] = {"columns": cols, "rows": rows}
    return out


if __name__ == "__main__":
    path = HERE / "expected.json"
    path.write_text(json.dumps(compute(), indent=1) + "\n", encoding="utf-8")
    print(f"wrote {path}")
