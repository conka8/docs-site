"""Graded checks for de-02-sql-interview: each answer's result set must match exactly
(same columns, same order, numbers within 0.01)."""

import json
from pathlib import Path

import pytest

EXPECTED = json.loads((Path(__file__).parent / "expected.json").read_text(encoding="utf-8"))


def check(run_answer, name):
    cols, rows = run_answer(name)
    exp = EXPECTED[name]
    assert cols == exp["columns"], f"columns should be {exp['columns']}, got {cols}"
    assert len(rows) == len(exp["rows"]), f"expected {len(exp['rows'])} rows, got {len(rows)}"
    for i, (got, want) in enumerate(zip(rows, exp["rows"]), 1):
        assert got == pytest.approx(want, abs=0.011), f"row {i}: got {got}, expected {want}"


@pytest.mark.points(10)
def test_q1_running_total(run_answer):
    """Q1 daily March revenue with a running total (SUM OVER ORDER BY)"""
    check(run_answer, "q1_running_total")


@pytest.mark.points(10)
def test_q2_top_n_per_group(run_answer):
    """Q2 top-2 distinct salaries per department, ties included (DENSE_RANK)"""
    check(run_answer, "q2_top_n_per_group")


@pytest.mark.points(10)
def test_q3_dedupe(run_answer):
    """Q3 dedupe messy emails, keep the earliest signup (ROW_NUMBER)"""
    check(run_answer, "q3_dedupe")


@pytest.mark.points(15)
def test_q4_retention_cohort(run_answer):
    """Q4 month-1 retention by signup cohort"""
    check(run_answer, "q4_retention_cohort")


@pytest.mark.points(15)
def test_q5_gaps_and_islands(run_answer):
    """Q5 longest consecutive-day login streak per user (gaps and islands)"""
    check(run_answer, "q5_gaps_and_islands")


@pytest.mark.points(10)
def test_q6_month_over_month(run_answer):
    """Q6 month-over-month revenue growth (LAG)"""
    check(run_answer, "q6_month_over_month")


@pytest.mark.points(15)
def test_q7_second_order(run_answer):
    """Q7 days between first and second completed order"""
    check(run_answer, "q7_second_order")


@pytest.mark.points(15)
def test_q8_revenue_share(run_answer):
    """Q8 revenue share by country (window over the whole result)"""
    check(run_answer, "q8_revenue_share")
