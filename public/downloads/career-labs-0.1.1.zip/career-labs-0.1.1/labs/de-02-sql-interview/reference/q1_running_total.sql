-- Q1 running total: daily completed revenue in March 2024 with a running total.
SELECT order_date,
       ROUND(SUM(amount), 2) AS revenue,
       ROUND(SUM(SUM(amount)) OVER (ORDER BY order_date), 2) AS running_total
FROM orders
WHERE status = 'completed' AND order_date BETWEEN '2024-03-01' AND '2024-03-31'
GROUP BY order_date
ORDER BY order_date;
