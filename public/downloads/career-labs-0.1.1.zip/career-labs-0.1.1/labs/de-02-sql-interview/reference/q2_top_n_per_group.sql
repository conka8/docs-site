-- Q2 top-N per group: employees whose salary is one of the top 2 distinct salaries in their dept.
WITH ranked AS (
    SELECT dept, name, salary,
           DENSE_RANK() OVER (PARTITION BY dept ORDER BY salary DESC) AS salary_rank
    FROM employees
)
SELECT dept, name, salary, salary_rank
FROM ranked
WHERE salary_rank <= 2
ORDER BY dept, salary_rank, name;
