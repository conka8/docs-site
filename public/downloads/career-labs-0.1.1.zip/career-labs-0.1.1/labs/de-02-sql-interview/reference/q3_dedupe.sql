-- Q3 dedupe: one row per normalised email, keeping the earliest signup.
WITH cleaned AS (
    SELECT LOWER(TRIM(email)) AS email, created_at, source
    FROM signups_raw
), ranked AS (
    SELECT email, created_at, source,
           ROW_NUMBER() OVER (PARTITION BY email ORDER BY created_at) AS rn,
           COUNT(*) OVER (PARTITION BY email) AS raw_rows
    FROM cleaned
)
SELECT email, created_at AS first_created_at, source AS first_source, raw_rows
FROM ranked
WHERE rn = 1
ORDER BY email;
