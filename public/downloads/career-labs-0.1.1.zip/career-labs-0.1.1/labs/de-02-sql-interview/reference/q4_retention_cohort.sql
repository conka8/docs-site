-- Q4 retention: monthly signup cohorts and how many logged in during the NEXT calendar month.
WITH cohorts AS (
    SELECT user_id,
           strftime('%Y-%m', signup_date) AS cohort_month,
           strftime('%Y-%m', date(signup_date, 'start of month', '+1 month')) AS next_month
    FROM users
), retained AS (
    SELECT DISTINCT c.user_id
    FROM cohorts c
    JOIN logins l ON l.user_id = c.user_id AND strftime('%Y-%m', l.login_date) = c.next_month
)
SELECT c.cohort_month,
       COUNT(*) AS cohort_size,
       COUNT(r.user_id) AS retained_m1,
       ROUND(100.0 * COUNT(r.user_id) / COUNT(*), 1) AS retention_pct
FROM cohorts c
LEFT JOIN retained r ON r.user_id = c.user_id
GROUP BY c.cohort_month
ORDER BY c.cohort_month;
