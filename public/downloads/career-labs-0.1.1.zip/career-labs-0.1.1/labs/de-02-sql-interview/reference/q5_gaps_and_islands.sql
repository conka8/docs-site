-- Q5 gaps and islands: each user's longest run of consecutive login days.
WITH days AS (
    SELECT DISTINCT user_id, login_date FROM logins
), grouped AS (
    SELECT user_id, login_date,
           julianday(login_date) - ROW_NUMBER() OVER (PARTITION BY user_id ORDER BY login_date) AS grp
    FROM days
), streaks AS (
    SELECT user_id, MIN(login_date) AS streak_start, MAX(login_date) AS streak_end, COUNT(*) AS streak_days
    FROM grouped
    GROUP BY user_id, grp
), best AS (
    SELECT *, ROW_NUMBER() OVER (PARTITION BY user_id ORDER BY streak_days DESC, streak_start) AS rn
    FROM streaks
)
SELECT user_id, streak_start, streak_end, streak_days
FROM best
WHERE rn = 1
ORDER BY user_id;
