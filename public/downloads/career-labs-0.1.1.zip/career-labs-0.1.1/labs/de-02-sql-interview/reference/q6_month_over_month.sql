-- Q6 month-over-month growth of completed revenue.
WITH monthly AS (
    SELECT strftime('%Y-%m', order_date) AS month, SUM(amount) AS revenue
    FROM orders
    WHERE status = 'completed'
    GROUP BY 1
)
SELECT month,
       ROUND(revenue, 2) AS revenue,
       ROUND(LAG(revenue) OVER (ORDER BY month), 2) AS prev_revenue,
       ROUND(100.0 * (revenue - LAG(revenue) OVER (ORDER BY month)) / LAG(revenue) OVER (ORDER BY month), 1)
           AS growth_pct
FROM monthly
ORDER BY month;
