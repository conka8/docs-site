-- Q7 time to second purchase: for users with 2+ completed orders.
WITH ranked AS (
    SELECT user_id, order_date,
           ROW_NUMBER() OVER (PARTITION BY user_id ORDER BY order_date, order_id) AS n
    FROM orders
    WHERE status = 'completed'
)
SELECT a.user_id,
       a.order_date AS first_order_date,
       b.order_date AS second_order_date,
       CAST(julianday(b.order_date) - julianday(a.order_date) AS INTEGER) AS days_between
FROM ranked a
JOIN ranked b ON b.user_id = a.user_id AND b.n = 2
WHERE a.n = 1
ORDER BY a.user_id;
