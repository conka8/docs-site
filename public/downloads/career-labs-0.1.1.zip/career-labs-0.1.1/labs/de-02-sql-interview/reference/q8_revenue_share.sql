-- Q8 share of total completed revenue by user country.
SELECT u.country,
       ROUND(SUM(o.amount), 2) AS revenue,
       ROUND(100.0 * SUM(o.amount) / SUM(SUM(o.amount)) OVER (), 2) AS pct_of_total
FROM orders o
JOIN users u ON u.user_id = o.user_id
WHERE o.status = 'completed'
GROUP BY u.country
ORDER BY revenue DESC, u.country;
