-- Q1: Daily revenue from COMPLETED orders in March 2024 (2024-03-01..2024-03-31), with a running total.
--
-- Columns (exactly these, in this order): order_date, revenue, running_total
-- Sort by: order_date
-- Notes: revenue and running_total rounded to 2 decimals. Hint: SUM(...) OVER (ORDER BY ...).
--
-- Write ONE SELECT statement (CTEs with WITH are fine). Check it with:
--   python labs/de-02-sql-interview/data/query.py labs/de-02-sql-interview/starter/q1_running_total.sql

-- TODO: replace this placeholder with your query
SELECT 'TODO' AS todo;
