-- Q2: Employees whose salary is one of the TOP 2 DISTINCT salary levels in their department (ties all included).
--
-- Columns (exactly these, in this order): dept, name, salary, salary_rank
-- Sort by: dept, salary_rank, name
-- Notes: salary_rank is 1 for the highest salary level. Hint: DENSE_RANK.
--
-- Write ONE SELECT statement (CTEs with WITH are fine). Check it with:
--   python labs/de-02-sql-interview/data/query.py labs/de-02-sql-interview/starter/q2_top_n_per_group.sql

-- TODO: replace this placeholder with your query
SELECT 'TODO' AS todo;
