-- Q3: signups_raw has the same person several times (different case, extra spaces). Return one row per normalised email (lower case, trimmed), keeping the EARLIEST row.
--
-- Columns (exactly these, in this order): email, first_created_at, first_source, raw_rows
-- Sort by: email
-- Notes: raw_rows = how many raw rows that email had. Hint: ROW_NUMBER() OVER (PARTITION BY ...).
--
-- Write ONE SELECT statement (CTEs with WITH are fine). Check it with:
--   python labs/de-02-sql-interview/data/query.py labs/de-02-sql-interview/starter/q3_dedupe.sql

-- TODO: replace this placeholder with your query
SELECT 'TODO' AS todo;
