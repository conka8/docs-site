-- Q4: Group users by signup month (cohort). How many logged in at least once during the NEXT calendar month?
--
-- Columns (exactly these, in this order): cohort_month, cohort_size, retained_m1, retention_pct
-- Sort by: cohort_month
-- Notes: cohort_month like '2024-01'; retention_pct = 100 * retained / size rounded to 1 decimal.
--
-- Write ONE SELECT statement (CTEs with WITH are fine). Check it with:
--   python labs/de-02-sql-interview/data/query.py labs/de-02-sql-interview/starter/q4_retention_cohort.sql

-- TODO: replace this placeholder with your query
SELECT 'TODO' AS todo;
