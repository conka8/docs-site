-- Q5: For each user with logins, their LONGEST run of consecutive login days. logins may contain the same day twice.
--
-- Columns (exactly these, in this order): user_id, streak_start, streak_end, streak_days
-- Sort by: user_id
-- Notes: If two streaks tie, keep the earlier one. Hint: date minus ROW_NUMBER is constant inside a streak.
--
-- Write ONE SELECT statement (CTEs with WITH are fine). Check it with:
--   python labs/de-02-sql-interview/data/query.py labs/de-02-sql-interview/starter/q5_gaps_and_islands.sql

-- TODO: replace this placeholder with your query
SELECT 'TODO' AS todo;
