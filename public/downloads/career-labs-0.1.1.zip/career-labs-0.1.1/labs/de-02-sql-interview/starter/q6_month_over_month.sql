-- Q6: Completed revenue per month and growth versus the previous month.
--
-- Columns (exactly these, in this order): month, revenue, prev_revenue, growth_pct
-- Sort by: month
-- Notes: month like '2024-01'; money rounded to 2 decimals; growth_pct rounded to 1 decimal; NULL for the first month. Hint: LAG.
--
-- Write ONE SELECT statement (CTEs with WITH are fine). Check it with:
--   python labs/de-02-sql-interview/data/query.py labs/de-02-sql-interview/starter/q6_month_over_month.sql

-- TODO: replace this placeholder with your query
SELECT 'TODO' AS todo;
