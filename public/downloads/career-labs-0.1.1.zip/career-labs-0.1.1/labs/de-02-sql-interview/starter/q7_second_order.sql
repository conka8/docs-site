-- Q7: For users with at least 2 COMPLETED orders: date of their first and second order and the days between.
--
-- Columns (exactly these, in this order): user_id, first_order_date, second_order_date, days_between
-- Sort by: user_id
-- Notes: Order a user's orders by order_date, then order_id. days_between is a whole number.
--
-- Write ONE SELECT statement (CTEs with WITH are fine). Check it with:
--   python labs/de-02-sql-interview/data/query.py labs/de-02-sql-interview/starter/q7_second_order.sql

-- TODO: replace this placeholder with your query
SELECT 'TODO' AS todo;
