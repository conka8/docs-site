-- Q8: Completed revenue per user country and its share of the total.
--
-- Columns (exactly these, in this order): country, revenue, pct_of_total
-- Sort by: revenue DESC, country
-- Notes: revenue rounded to 2 decimals; pct_of_total = 100 * country / total rounded to 2 decimals. Hint: SUM(SUM(x)) OVER ().
--
-- Write ONE SELECT statement (CTEs with WITH are fine). Check it with:
--   python labs/de-02-sql-interview/data/query.py labs/de-02-sql-interview/starter/q8_revenue_share.sql

-- TODO: replace this placeholder with your query
SELECT 'TODO' AS todo;
