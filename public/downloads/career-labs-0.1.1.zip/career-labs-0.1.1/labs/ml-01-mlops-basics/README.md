# ML-01: MLOps basics from scratch (no numpy)

## Scenario

A subscription business wants a churn model, and the ML platform team wants it **reproducible
and monitored**. You'll build the whole loop in plain Python, so nothing is hidden behind a
library: a seeded split, feature scaling, logistic regression trained with gradient descent,
evaluation metrics, data-drift detection on next month's batch, and a model card.

- `data/train.csv`: 400 labelled customers (`tenure_months, monthly_spend, support_tickets, churned`)
- `data/new_batch.csv`: 200 new customers, unlabelled. There was a price increase...

## What you will practise

Reproducibility (seeds), train/test leakage (fit the scaler on train only), the maths of
logistic regression and its gradient, precision/recall/F1/ROC-AUC, the Population Stability
Index (PSI), and documenting a model with a model card.

## Your task

Edit `starter/mlops.py`. The exact rules the grader checks:

- **Split**: `idx = list(range(n))`, `random.Random(seed).shuffle(idx)`, `n_test = round(n * test_size)`.
  The first `n_test` shuffled indices are the test set.
- **Standardize**: mean and *population* std from the training rows only, and std 0 becomes 1.0.
- **Logistic regression**: weights and bias start at 0. For each epoch:
  1. `p = sigmoid(w.x + b)` for all rows.
  2. Append `log_loss(y, p)` to `loss_history`.
  3. `grad_w[j] = mean((p - y) * x[j]) + l2 * w[j]` and `grad_b = mean(p - y)`.
  4. Update both: `w -= lr * grad_w`, `b -= lr * grad_b`.
- **Metrics**: precision, recall and F1 are 0.0 when they would be 0/0. ROC-AUC counts ties as 0.5
  and is `None` with a single class.
- **PSI**: equal-width bins between the min and max of the *expected* (reference) values.
  `bin = int((v - min) / width)`, clamped to `[0, bins - 1]`, so out-of-range values go to the edge bins.
  Bin shares are floored at `eps = 1e-4`, then `PSI = sum((a - e) * ln(a / e))`.
  Status: `stable` < 0.1 <= `watch` < 0.25 <= `drift`.
- **Model card**: `run_experiment()` returns these keys:
  - `model_name`, `version`, `features`
  - `training_data`: `rows`, `train_rows`, `test_rows`, `positive_rate`
  - `hyperparameters`
  - `weights`: one entry per feature
  - `bias`
  - `metrics`: accuracy, precision, recall, f1 and roc_auc on the test set, rounded to 4 decimals
  - `drift`: raw features, all training rows vs the new batch
  - `intended_use`
  - `limitations`: a list

  Train on standardized features, and threshold the predictions at 0.5.

```
python labs/ml-01-mlops-basics/starter/mlops.py model_card.json
```

## Run the grader

```
python -m labgrade run ml-01-mlops-basics
```

## Points

| Graded check | Points | What it checks |
|---|---:|---|
| `test_load_csv` | 5 | load_csv returns features as floats, labels as ints (None if unlabelled) |
| `test_train_test_split` | 10 | train_test_split shuffles indices with random.Random(seed) exactly as specified |
| `test_standardize` | 10 | standardize fits mean/std (population) on TRAIN only and applies to both |
| `test_logistic_regression` | 15 | LogisticRegression follows the batch gradient-descent spec (weights, loss history, predict) |
| `test_classification_metrics` | 10 | confusion matrix, precision, recall, F1, accuracy (0.0 instead of dividing by zero) |
| `test_roc_auc` | 10 | ROC-AUC = chance a random positive scores above a random negative (ties = half) |
| `test_psi` | 15 | PSI with equal-width bins on the reference data, eps floor for empty bins |
| `test_drift_report` | 10 | drift_report flags monthly_spend (price increase) and nothing else |
| `test_model_card` | 15 | run_experiment trains end to end and returns a complete, JSON-serialisable model card |
| **Total** | **100** | |

## Portfolio tip

Add a short note on what the drift result means for the business. Spend moved after a price
increase, so a model trained before it is now scoring customers it has never seen. Then say
what you'd do: retrain, recalibrate, or monitor the churn rate.

## For maintainers

`data/generate.py` rebuilds both CSVs (seeded, byte-identical).
