"""Generate train.csv (labelled) and new_batch.csv (unlabelled, drifted) for ml-01-mlops-basics.

A subscription business wants to predict churn. new_batch.csv is next month's customers:
a price increase pushed monthly_spend up (that's the drift to detect); tenure and
support tickets look like before.

Run:  python labs/ml-01-mlops-basics/data/generate.py [--out DIR]
"""

from __future__ import annotations

import argparse
import math
import random
from pathlib import Path

SEED = 7
FEATURES = ["tenure_months", "monthly_spend", "support_tickets"]


def _row(rng: random.Random, spend_shift: float = 0.0) -> tuple[float, float, int]:
    tenure = rng.randint(1, 72)
    spend = round(min(200.0, max(10.0, rng.gauss(70 + spend_shift, 20))), 2)
    tickets = min(8, int(rng.expovariate(0.6)))
    return tenure, spend, tickets


def generate(out: Path) -> list[Path]:
    out.mkdir(parents=True, exist_ok=True)
    rng = random.Random(SEED)
    train = [",".join(FEATURES + ["churned"])]
    for _ in range(400):
        tenure, spend, tickets = _row(rng)
        z = -1.0 - 0.06 * (tenure - 36) + 0.03 * (spend - 70) + 0.7 * tickets - 0.8
        label = 1 if rng.random() < 1 / (1 + math.exp(-z)) else 0
        train.append(f"{tenure},{spend:.2f},{tickets},{label}")
    batch = [",".join(FEATURES)]
    for _ in range(200):
        tenure, spend, tickets = _row(rng, spend_shift=35.0)
        batch.append(f"{tenure},{spend:.2f},{tickets}")
    files = [out / "train.csv", out / "new_batch.csv"]
    files[0].write_text("\n".join(train) + "\n", encoding="utf-8")
    files[1].write_text("\n".join(batch) + "\n", encoding="utf-8")
    return files


if __name__ == "__main__":
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--out", default=str(Path(__file__).resolve().parent))
    for f in generate(Path(ap.parse_args().out)):
        print(f"wrote {f}")
