import pytest

from labgrade.helpers import lab_dir_from, load_solution, register_points_marker

LAB_DIR = lab_dir_from(__file__)


def pytest_configure(config):
    register_points_marker(config)


@pytest.fixture
def sol():
    """The member's mlops.py module."""
    return load_solution(LAB_DIR, "mlops")
