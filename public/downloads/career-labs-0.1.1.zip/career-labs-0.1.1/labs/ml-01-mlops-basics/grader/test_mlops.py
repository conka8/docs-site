"""Graded checks for ml-01-mlops-basics. Numbers are compared with small tolerances."""

import json
import math
import random
from pathlib import Path

import pytest

DATA = Path(__file__).resolve().parent.parent / "data"
TOY_X = [[0.5, 1.0], [1.5, -0.5], [-1.0, 0.3], [2.0, 2.0], [-0.7, -1.2], [0.1, 0.4]]
TOY_Y = [1, 1, 0, 1, 0, 0]


def oracle_logreg(X, y, lr, epochs, l2):
    """Independent implementation of the gradient-descent spec in the README."""
    w, b = [0.0] * len(X[0]), 0.0
    for _ in range(epochs):
        p = [1 / (1 + math.exp(-(sum(wi * xi for wi, xi in zip(w, r)) + b))) for r in X]
        d = [pi - yi for pi, yi in zip(p, y)]
        gw = [sum(di * r[j] for di, r in zip(d, X)) / len(X) + l2 * w[j] for j in range(len(w))]
        gb = sum(d) / len(X)
        w = [wi - lr * g for wi, g in zip(w, gw)]
        b -= lr * gb
    return w, b


@pytest.mark.points(5)
def test_load_csv(sol):
    """load_csv returns features as floats, labels as ints (None if unlabelled)"""
    X, y, features = sol.load_csv(DATA / "train.csv")
    assert features == ["tenure_months", "monthly_spend", "support_tickets"]
    assert len(X) == 400 and len(y) == 400
    assert X[0] == [42.0, 88.98, 0.0] and y[:3] == [0, 1, 0]
    Xn, yn, fn = sol.load_csv(DATA / "new_batch.csv")
    assert yn is None and len(Xn) == 200 and fn == features


@pytest.mark.points(10)
def test_train_test_split(sol):
    """train_test_split shuffles indices with random.Random(seed) exactly as specified"""
    X = [[i] for i in range(10)]
    y = list(range(10))
    Xtr, Xte, ytr, yte = sol.train_test_split(X, y, test_size=0.3, seed=7)
    idx = list(range(10))
    random.Random(7).shuffle(idx)
    assert yte == idx[:3] and ytr == idx[3:]
    assert Xte == [[i] for i in idx[:3]]
    again = sol.train_test_split(X, y, test_size=0.3, seed=7)
    assert again[3] == yte, "same seed must give the same split"
    assert sol.train_test_split(X, y, test_size=0.3, seed=8)[3] != yte
    assert sorted(ytr + yte) == y, "no row lost or duplicated"


@pytest.mark.points(10)
def test_standardize(sol):
    """standardize fits mean/std (population) on TRAIN only and applies to both"""
    Xtr_s, Xte_s, means, stds = sol.standardize([[1.0, 5.0], [3.0, 5.0]], [[5.0, 7.0]])
    assert means == pytest.approx([2.0, 5.0])
    assert stds == pytest.approx([1.0, 1.0]), "constant column: std must fall back to 1.0"
    assert Xtr_s == [pytest.approx([-1.0, 0.0]), pytest.approx([1.0, 0.0])]
    assert Xte_s == [pytest.approx([3.0, 2.0])]


@pytest.mark.points(15)
def test_logistic_regression(sol):
    """LogisticRegression follows the batch gradient-descent spec (weights, loss history, predict)"""
    model = sol.LogisticRegression(lr=0.5, epochs=200, l2=0.01).fit(TOY_X, TOY_Y)
    w, b = oracle_logreg(TOY_X, TOY_Y, 0.5, 200, 0.01)
    assert model.weights == pytest.approx(w, abs=1e-6)
    assert model.bias == pytest.approx(b, abs=1e-6)
    assert len(model.loss_history) == 200
    assert model.loss_history[0] == pytest.approx(math.log(2), abs=1e-9), "loss before the first update is ln 2"
    assert model.loss_history[-1] < model.loss_history[0]
    proba = model.predict_proba(TOY_X)
    assert all(0 < p < 1 for p in proba)
    assert model.predict(TOY_X) == [1 if p >= 0.5 else 0 for p in proba]
    assert model.predict(TOY_X, threshold=0.99) == [0] * 6 or max(proba) >= 0.99


@pytest.mark.points(10)
def test_classification_metrics(sol):
    """confusion matrix, precision, recall, F1, accuracy (0.0 instead of dividing by zero)"""
    y_true = [1, 1, 1, 0, 0, 0, 0, 1]
    y_pred = [1, 0, 1, 0, 1, 0, 0, 1]
    assert sol.confusion_matrix(y_true, y_pred) == {"tp": 3, "fp": 1, "tn": 3, "fn": 1}
    m = sol.classification_metrics(y_true, y_pred)
    assert m["accuracy"] == pytest.approx(0.75)
    assert m["precision"] == pytest.approx(0.75) and m["recall"] == pytest.approx(0.75)
    assert m["f1"] == pytest.approx(0.75)
    m2 = sol.classification_metrics([1, 1, 0], [0, 0, 0])
    assert (m2["precision"], m2["recall"], m2["f1"]) == (0.0, 0.0, 0.0)
    assert m2["accuracy"] == pytest.approx(1 / 3)


@pytest.mark.points(10)
def test_roc_auc(sol):
    """ROC-AUC = chance a random positive scores above a random negative (ties = half)"""
    assert sol.roc_auc([0, 0, 1, 1], [0.1, 0.4, 0.35, 0.8]) == pytest.approx(0.75)
    assert sol.roc_auc([0, 1], [0.5, 0.5]) == pytest.approx(0.5)
    assert sol.roc_auc([1, 1, 0, 0], [0.9, 0.8, 0.2, 0.1]) == pytest.approx(1.0)
    assert sol.roc_auc([0, 1, 0, 1, 0], [0.3, 0.3, 0.1, 0.7, 0.9]) == pytest.approx(4 / 6 - 1 / 12)
    assert sol.roc_auc([1, 1], [0.2, 0.3]) is None, "AUC is undefined with one class: return None"


@pytest.mark.points(15)
def test_psi(sol):
    """PSI with equal-width bins on the reference data, eps floor for empty bins"""
    expected = [1, 2, 3, 4]
    assert sol.psi(expected, expected, bins=2) == pytest.approx(0.0)
    value = 0.25 * math.log(1.5) + 0.25 * math.log(2)
    assert sol.psi(expected, [1, 1, 1, 4], bins=2) == pytest.approx(value, abs=1e-9)
    # values outside the reference range go to the edge bins; empty bins use eps=1e-4
    got = sol.psi([0, 10], [20, 20], bins=2)
    want = (1e-4 - 0.5) * math.log(1e-4 / 0.5) + (1 - 0.5) * math.log(1 / 0.5)
    assert got == pytest.approx(want, abs=1e-9)


@pytest.mark.points(10)
def test_drift_report(sol):
    """drift_report flags monthly_spend (price increase) and nothing else"""
    X, _, features = sol.load_csv(DATA / "train.csv")
    Xn, _, _ = sol.load_csv(DATA / "new_batch.csv")
    rep = sol.drift_report(X, Xn, features)
    assert set(rep) == set(features)
    assert rep["monthly_spend"]["status"] == "drift"
    assert rep["tenure_months"]["status"] == "stable" and rep["support_tickets"]["status"] == "stable"
    assert rep["monthly_spend"]["psi"] == pytest.approx(3.2416, abs=1e-3)
    assert rep["tenure_months"]["psi"] == pytest.approx(0.058, abs=1e-3)


@pytest.mark.points(15)
def test_model_card(sol, tmp_path):
    """run_experiment trains end to end and returns a complete, JSON-serialisable model card"""
    card = sol.run_experiment(DATA, seed=42, test_size=0.25, lr=0.1, epochs=500)
    out = sol.save_model_card(card, tmp_path / "model_card.json")
    assert json.loads(Path(out).read_text(encoding="utf-8")) == card
    for key in ["model_name", "version", "features", "training_data", "hyperparameters", "weights", "bias",
                "metrics", "drift", "intended_use", "limitations"]:
        assert key in card, f"model card is missing '{key}'"
    td = card["training_data"]
    assert (td["rows"], td["train_rows"], td["test_rows"]) == (400, 300, 100)
    assert td["positive_rate"] == pytest.approx(0.32)
    assert card["weights"] == pytest.approx({"tenure_months": -1.3751, "monthly_spend": 0.7288,
                                             "support_tickets": 1.0963}, abs=2e-3)
    assert card["bias"] == pytest.approx(-1.1152, abs=2e-3)
    assert card["metrics"] == pytest.approx({"accuracy": 0.83, "precision": 0.7407, "recall": 0.6667,
                                             "f1": 0.7018, "roc_auc": 0.8205}, abs=2e-3)
    assert card["drift"]["monthly_spend"]["status"] == "drift"
    assert isinstance(card["limitations"], list) and card["limitations"]
