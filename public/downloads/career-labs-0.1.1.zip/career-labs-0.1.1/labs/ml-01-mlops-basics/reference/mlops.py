"""Reference solution for ml-01-mlops-basics (pure Python, no numpy)."""

from __future__ import annotations

import csv
import json
import math
import random
import sys
from pathlib import Path


# ---------------------------------------------------------------- data
def load_csv(path, label: str = "churned"):
    """Return (X, y, feature_names). y is None when the file has no label column."""
    with open(path, newline="", encoding="utf-8") as fh:
        reader = csv.DictReader(fh)
        features = [c for c in reader.fieldnames if c != label]
        X, y = [], []
        has_label = label in reader.fieldnames
        for row in reader:
            X.append([float(row[f]) for f in features])
            if has_label:
                y.append(int(row[label]))
    return X, (y if has_label else None), features


def train_test_split(X, y, test_size: float = 0.25, seed: int = 42):
    idx = list(range(len(X)))
    random.Random(seed).shuffle(idx)
    n_test = round(len(X) * test_size)
    test, train = idx[:n_test], idx[n_test:]
    return [X[i] for i in train], [X[i] for i in test], [y[i] for i in train], [y[i] for i in test]


def standardize(X_train, X_test):
    cols = len(X_train[0])
    n = len(X_train)
    means = [sum(r[j] for r in X_train) / n for j in range(cols)]
    stds = []
    for j in range(cols):
        var = sum((r[j] - means[j]) ** 2 for r in X_train) / n
        stds.append(math.sqrt(var) if var > 0 else 1.0)

    def scale(X):
        return [[(r[j] - means[j]) / stds[j] for j in range(cols)] for r in X]

    return scale(X_train), scale(X_test), means, stds


# ---------------------------------------------------------------- model
def sigmoid(z: float) -> float:
    if z >= 0:
        return 1.0 / (1.0 + math.exp(-z))
    e = math.exp(z)
    return e / (1.0 + e)


def log_loss(y, p, eps: float = 1e-12) -> float:
    return -sum(t * math.log(max(q, eps)) + (1 - t) * math.log(max(1 - q, eps)) for t, q in zip(y, p)) / len(y)


class LogisticRegression:
    def __init__(self, lr: float = 0.1, epochs: int = 500, l2: float = 0.0):
        self.lr, self.epochs, self.l2 = lr, epochs, l2
        self.weights: list[float] = []
        self.bias = 0.0
        self.loss_history: list[float] = []

    def _z(self, row) -> float:
        return sum(w * x for w, x in zip(self.weights, row)) + self.bias

    def fit(self, X, y):
        n, cols = len(X), len(X[0])
        self.weights, self.bias, self.loss_history = [0.0] * cols, 0.0, []
        for _ in range(self.epochs):
            p = [sigmoid(self._z(r)) for r in X]
            self.loss_history.append(log_loss(y, p))
            diff = [pi - yi for pi, yi in zip(p, y)]
            grad_w = [sum(d * r[j] for d, r in zip(diff, X)) / n + self.l2 * self.weights[j] for j in range(cols)]
            grad_b = sum(diff) / n
            self.weights = [w - self.lr * g for w, g in zip(self.weights, grad_w)]
            self.bias -= self.lr * grad_b
        return self

    def predict_proba(self, X) -> list[float]:
        return [sigmoid(self._z(r)) for r in X]

    def predict(self, X, threshold: float = 0.5) -> list[int]:
        return [1 if p >= threshold else 0 for p in self.predict_proba(X)]


# ---------------------------------------------------------------- metrics
def confusion_matrix(y_true, y_pred) -> dict:
    cm = {"tp": 0, "fp": 0, "tn": 0, "fn": 0}
    for t, p in zip(y_true, y_pred):
        cm[("t" if t == p else "f") + ("p" if p == 1 else "n")] += 1
    return cm


def classification_metrics(y_true, y_pred) -> dict:
    cm = confusion_matrix(y_true, y_pred)
    tp, fp, tn, fn = cm["tp"], cm["fp"], cm["tn"], cm["fn"]
    total = tp + fp + tn + fn
    precision = tp / (tp + fp) if tp + fp else 0.0
    recall = tp / (tp + fn) if tp + fn else 0.0
    f1 = 2 * precision * recall / (precision + recall) if precision + recall else 0.0
    return {"accuracy": (tp + tn) / total if total else 0.0, "precision": precision, "recall": recall, "f1": f1}


def roc_auc(y_true, scores) -> float | None:
    pos = [s for t, s in zip(y_true, scores) if t == 1]
    neg = [s for t, s in zip(y_true, scores) if t == 0]
    if not pos or not neg:
        return None
    wins = 0.0
    for p in pos:
        for q in neg:
            wins += 1.0 if p > q else 0.5 if p == q else 0.0
    return wins / (len(pos) * len(neg))


# ---------------------------------------------------------------- drift
def psi(expected, actual, bins: int = 10, eps: float = 1e-4) -> float:
    lo, hi = min(expected), max(expected)
    width = (hi - lo) / bins

    def hist(values):
        counts = [0] * bins
        for v in values:
            i = 0 if width == 0 else int((v - lo) / width)
            counts[min(max(i, 0), bins - 1)] += 1
        return [max(c / len(values), eps) for c in counts]

    e, a = hist(expected), hist(actual)
    return sum((ai - ei) * math.log(ai / ei) for ei, ai in zip(e, a))


def drift_status(value: float) -> str:
    return "stable" if value < 0.1 else "watch" if value < 0.25 else "drift"


def drift_report(X_ref, X_new, features, bins: int = 10) -> dict:
    out = {}
    for j, name in enumerate(features):
        value = psi([r[j] for r in X_ref], [r[j] for r in X_new], bins)
        out[name] = {"psi": round(value, 4), "status": drift_status(value)}
    return out


# ---------------------------------------------------------------- experiment + model card
def run_experiment(data_dir, seed: int = 42, test_size: float = 0.25, lr: float = 0.1, epochs: int = 500,
                   l2: float = 0.0) -> dict:
    data_dir = Path(data_dir)
    X, y, features = load_csv(data_dir / "train.csv")
    X_new, _, _ = load_csv(data_dir / "new_batch.csv")
    Xtr, Xte, ytr, yte = train_test_split(X, y, test_size, seed)
    Xtr_s, Xte_s, means, stds = standardize(Xtr, Xte)
    model = LogisticRegression(lr, epochs, l2).fit(Xtr_s, ytr)
    proba = model.predict_proba(Xte_s)
    metrics = classification_metrics(yte, [1 if p >= 0.5 else 0 for p in proba])
    metrics["roc_auc"] = roc_auc(yte, proba)
    return {
        "model_name": "churn-logreg",
        "version": "1.0.0",
        "model_type": "logistic_regression",
        "features": features,
        "training_data": {"file": "train.csv", "rows": len(X), "train_rows": len(Xtr), "test_rows": len(Xte),
                          "positive_rate": round(sum(y) / len(y), 4)},
        "hyperparameters": {"lr": lr, "epochs": epochs, "l2": l2, "seed": seed, "test_size": test_size},
        "preprocessing": {"standardize_means": [round(m, 4) for m in means],
                          "standardize_stds": [round(s, 4) for s in stds]},
        "weights": {f: round(w, 4) for f, w in zip(features, model.weights)},
        "bias": round(model.bias, 4),
        "metrics": {k: round(v, 4) for k, v in metrics.items()},
        "drift": drift_report(X, X_new, features),
        "intended_use": "Rank existing subscribers by churn risk for retention outreach. Not for pricing or "
                        "credit decisions.",
        "limitations": [
            "Trained on 400 synthetic customers; re-validate on real data before use.",
            "Only three features; no seasonality or contract-type information.",
            "monthly_spend has drifted in the new batch (price increase): retrain before scoring it.",
        ],
    }


def save_model_card(card: dict, path) -> Path:
    path = Path(path)
    path.write_text(json.dumps(card, indent=2) + "\n", encoding="utf-8")
    return path


if __name__ == "__main__":
    card = run_experiment(Path(__file__).resolve().parent.parent / "data")
    out = save_model_card(card, sys.argv[1] if len(sys.argv) > 1 else "model_card.json")
    print(json.dumps({"metrics": card["metrics"], "drift": card["drift"]}, indent=2))
    print(f"model card written to {out}")
