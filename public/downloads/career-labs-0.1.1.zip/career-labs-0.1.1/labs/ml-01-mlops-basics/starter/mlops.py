"""ml-01-mlops-basics: YOUR SOLUTION GOES HERE (pure Python: no numpy, no scikit-learn).

Read ../README.md first. Fill in every function marked TODO, then run:

    python -m labgrade run ml-01-mlops-basics

`load_csv`, `sigmoid`, `log_loss` and `save_model_card` are done for you.
"""

from __future__ import annotations

import csv
import json
import math
import random  # noqa: F401
import sys
from pathlib import Path


# ---------------------------------------------------------------- data
def load_csv(path, label: str = "churned"):
    """Return (X, y, feature_names). y is None when the file has no label column."""
    with open(path, newline="", encoding="utf-8") as fh:
        reader = csv.DictReader(fh)
        features = [c for c in reader.fieldnames if c != label]
        X, y = [], []
        has_label = label in reader.fieldnames
        for row in reader:
            X.append([float(row[f]) for f in features])
            if has_label:
                y.append(int(row[label]))
    return X, (y if has_label else None), features


def train_test_split(X, y, test_size: float = 0.25, seed: int = 42):
    """Return (X_train, X_test, y_train, y_test).

    idx = list(range(len(X))); random.Random(seed).shuffle(idx); n_test = round(len(X) * test_size);
    the FIRST n_test shuffled indices are the test set, the rest the training set (in shuffled order).
    """
    # TODO
    raise NotImplementedError("train_test_split")


def standardize(X_train, X_test):
    """Return (X_train_scaled, X_test_scaled, means, stds).

    Means and POPULATION standard deviations come from X_train only. A column with std 0 uses 1.0.
    """
    # TODO
    raise NotImplementedError("standardize")


# ---------------------------------------------------------------- model
def sigmoid(z: float) -> float:
    if z >= 0:
        return 1.0 / (1.0 + math.exp(-z))
    e = math.exp(z)
    return e / (1.0 + e)


def log_loss(y, p, eps: float = 1e-12) -> float:
    return -sum(t * math.log(max(q, eps)) + (1 - t) * math.log(max(1 - q, eps)) for t, q in zip(y, p)) / len(y)


class LogisticRegression:
    """Batch gradient descent. See the README for the exact update rule."""

    def __init__(self, lr: float = 0.1, epochs: int = 500, l2: float = 0.0):
        self.lr, self.epochs, self.l2 = lr, epochs, l2
        self.weights: list[float] = []
        self.bias = 0.0
        self.loss_history: list[float] = []

    def fit(self, X, y):
        """Start from weights = 0, bias = 0. Each epoch:
        p = sigmoid(w.x + b) for every row; append log_loss(y, p) to loss_history (BEFORE updating);
        grad_w[j] = mean((p - y) * x[j]) + l2 * w[j]; grad_b = mean(p - y);
        w -= lr * grad_w; b -= lr * grad_b.  Return self.
        """
        # TODO
        raise NotImplementedError("LogisticRegression.fit")

    def predict_proba(self, X) -> list[float]:
        # TODO
        raise NotImplementedError("LogisticRegression.predict_proba")

    def predict(self, X, threshold: float = 0.5) -> list[int]:
        """1 if probability >= threshold else 0."""
        # TODO
        raise NotImplementedError("LogisticRegression.predict")


# ---------------------------------------------------------------- metrics
def confusion_matrix(y_true, y_pred) -> dict:
    """{"tp", "fp", "tn", "fn"} counts (positive class = 1)."""
    # TODO
    raise NotImplementedError("confusion_matrix")


def classification_metrics(y_true, y_pred) -> dict:
    """{"accuracy", "precision", "recall", "f1"}; any 0/0 gives 0.0."""
    # TODO
    raise NotImplementedError("classification_metrics")


def roc_auc(y_true, scores) -> float | None:
    """Share of (positive, negative) pairs where the positive scores higher; ties count 0.5.
    None when there are no positives or no negatives."""
    # TODO
    raise NotImplementedError("roc_auc")


# ---------------------------------------------------------------- drift
def psi(expected, actual, bins: int = 10, eps: float = 1e-4) -> float:
    """Population Stability Index of `actual` against `expected` (see README for the binning rule)."""
    # TODO
    raise NotImplementedError("psi")


def drift_report(X_ref, X_new, features, bins: int = 10) -> dict:
    """{feature: {"psi": rounded to 4 decimals, "status": "stable" (<0.1) | "watch" (<0.25) | "drift"}}"""
    # TODO
    raise NotImplementedError("drift_report")


# ---------------------------------------------------------------- experiment + model card
def run_experiment(data_dir, seed: int = 42, test_size: float = 0.25, lr: float = 0.1, epochs: int = 500,
                   l2: float = 0.0) -> dict:
    """Load train.csv + new_batch.csv, split, standardize, train, evaluate on the test set,
    check drift (raw features, all training rows vs the new batch) and return the model card dict
    described in the README."""
    # TODO
    raise NotImplementedError("run_experiment")


def save_model_card(card: dict, path) -> Path:
    path = Path(path)
    path.write_text(json.dumps(card, indent=2) + "\n", encoding="utf-8")
    return path


if __name__ == "__main__":
    card = run_experiment(Path(__file__).resolve().parent.parent / "data")
    out = save_model_card(card, sys.argv[1] if len(sys.argv) > 1 else "model_card.json")
    print(json.dumps({"metrics": card["metrics"], "drift": card["drift"]}, indent=2))
    print(f"model card written to {out}")
