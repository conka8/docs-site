# OPS-01: Incident drill (SLOs, error budgets and a broken config)

## Scenario

On 14 May 2024, `checkout-api` returned errors for over half an hour. You are on the incident
review. You have:

- `data/metrics.csv`: per-minute `requests`, `errors` and `p95_latency_ms` from 13:00 to 15:59 UTC;
- `data/deploys.csv`: every deploy that afternoon, across services;
- `data/app.log`: sampled application logs (one line per ~10 errors);
- `starter/service.yaml`: the deployment config, which the platform team says is wrong in
  several ways. Their validator is `provided/configcheck.py`.

The service has a **99.9% availability SLO** over 30 days, at about **43,200,000 requests a month**
(1,000 per minute). Work out how bad it was, when it started, what caused it, write the
postmortem summary, and fix the config.

## What you will practise

SLO maths (availability, error budget, burn rate), finding a sustained spike rather than a blip,
correlating with change events, log triage, writing blameless postmortems, and config validation.

## Your task

1. Edit `starter/drill.py` (the docstrings are the exact spec):

| Function | What it returns |
|---|---|
| `slo_report(metrics, slo, period_requests)` | availability, error budget, % of budget burned, burn rate |
| `first_error_spike(metrics, threshold=0.05, sustain_minutes=3)` | first minute of a *sustained* error spike |
| `recovery_minute(metrics, after, ...)` | when errors stayed low again |
| `find_deploy(deploys, spike_minute, service=None, lookback_minutes=30)` | the suspect deploy |
| `top_errors(log_path, start, end, n=3)` | most frequent error messages in the window |
| `postmortem(metrics, deploys, log_path, slo, period_requests)` | the summary dict below |

`postmortem` returns:

```
{"title", "severity": "SEV1" if peak error rate >= 25% else "SEV2",
 "start", "end", "duration_minutes", "trigger": <deploy row>, "detection_delay_minutes",
 "impact": {"failed_requests", "peak_error_rate_pct", "peak_minute", "budget_consumed_pct"},
 "top_errors": [[message, count], ...], "action_items": [at least 3 sentences]}
```

The incident window is `[start, end)`. `impact` numbers come from that window only, with
`budget_consumed_pct` measured against the 30-day budget.

2. Fix `starter/service.yaml` until this prints `config OK`:

```
python labs/ops-01-incident-drill/provided/configcheck.py labs/ops-01-incident-drill/starter/service.yaml
```

Use `app.log` to find the real port and health check path. Needs `pyyaml`.

## Run the grader

```
python -m labgrade run ops-01-incident-drill
```

## Points

| Graded check | Points | What it checks |
|---|---:|---|
| `test_load_metrics` | 5 | load_metrics returns typed rows from metrics.csv |
| `test_slo_report` | 15 | slo_report: availability, error budget, % of budget burned, burn rate |
| `test_first_error_spike` | 15 | first_error_spike ignores one-minute blips and needs a sustained run |
| `test_recovery_minute` | 5 | recovery_minute finds when errors stay below the threshold again |
| `test_find_deploy` | 10 | find_deploy correlates the spike with the latest deploy shortly before it |
| `test_top_errors` | 10 | top_errors counts ERROR messages inside [start, end) from app.log |
| `test_postmortem` | 15 | postmortem assembles the incident summary dict |
| `test_service_config_valid` | 15 | your service.yaml passes the platform team's validator |
| `test_service_config_matches_app` | 10 | service.yaml matches what the app really does (port and health path from app.log) |
| **Total** | **100** | |

## Portfolio tip

Turn your `postmortem()` output into a one-page markdown postmortem with a timeline, impact,
root cause, what went well, and action items with owners. Hiring managers for SRE roles read these.

## For maintainers

`data/generate.py` rebuilds the three data files (seeded, byte-identical).
