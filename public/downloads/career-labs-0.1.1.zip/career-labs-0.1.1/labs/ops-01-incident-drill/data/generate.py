"""Generate metrics.csv, deploys.csv and app.log for ops-01-incident-drill (deterministic, seed 99).

Story (2024-05-14, UTC): checkout-api v2.4.0 is deployed at 14:05. From 14:07 the error
rate jumps (database connection pool exhausted), a config change at 14:20 does not help,
and a rollback to v2.3.9 at 14:41 brings things back. A one-minute blip at 13:20 is noise.

Run:  python labs/ops-01-incident-drill/data/generate.py [--out DIR]
"""

from __future__ import annotations

import argparse
import random
from datetime import datetime, timedelta
from pathlib import Path

SEED = 99
START = datetime(2024, 5, 14, 13, 0)
MINUTES = 180
DEPLOYS = [
    ("2024-05-14T13:10:00Z", "search-api", "v1.8.0", "priya", "new ranking weights"),
    ("2024-05-14T14:05:00Z", "checkout-api", "v2.4.0", "marco", "async order confirmation emails"),
    ("2024-05-14T14:20:00Z", "checkout-api", "v2.4.0-cfg1", "marco", "raise request timeout to 10s"),
    ("2024-05-14T14:41:00Z", "checkout-api", "v2.3.9", "oncall-jen", "rollback to last good version"),
    ("2024-05-14T15:30:00Z", "web-frontend", "v5.2.1", "sam", "copy changes"),
]
INCIDENT_RATES = {7: 0.08, 8: 0.22, 9: 0.31, 10: 0.34}  # minutes after 14:00 -> error rate during ramp up
MSGS = [("db connection pool exhausted (max=10)", 6), ("upstream timeout calling payment-svc", 3),
        ("KeyError: 'shipping_tier'", 1)]


def error_rate(t: datetime, rng: random.Random) -> float:
    if t == datetime(2024, 5, 14, 13, 20):
        return 0.07
    if datetime(2024, 5, 14, 14, 7) <= t < datetime(2024, 5, 14, 14, 42):
        return INCIDENT_RATES.get(t.minute if t.hour == 14 else -1, 0.30 + rng.randint(0, 80) / 1000)
    if t == datetime(2024, 5, 14, 14, 42):
        return 0.06
    return rng.randint(0, 3) / 1000


def generate(out: Path) -> list[Path]:
    out.mkdir(parents=True, exist_ok=True)
    rng = random.Random(SEED)
    metrics = ["minute,requests,errors,p95_latency_ms"]
    log = []
    for i in range(MINUTES):
        t = START + timedelta(minutes=i)
        req = 1000 + rng.randint(-60, 60)
        rate = error_rate(t, rng)
        err = round(req * rate)
        lat = 180 + rng.randint(0, 40) + (int(2500 * rate) if rate > 0.05 else 0)
        metrics.append(f"{t:%Y-%m-%dT%H:%M},{req},{err},{lat}")
        # sample of error log lines: one line per 10 errors (log sampling), at least 1 if any
        for k in range((err + 9) // 10):
            if rate > 0.05 and t.hour == 14:
                msg = rng.choices([m for m, _ in MSGS], weights=[w for _, w in MSGS])[0]
            else:
                msg = "upstream timeout calling payment-svc"
            ts = t + timedelta(seconds=rng.randint(0, 59))
            log.append((ts, f'{ts:%Y-%m-%dT%H:%M:%S}Z ERROR checkout-api msg="{msg}" request_id={rng.getrandbits(32):08x}'))
        if i % 15 == 0:
            ts = t + timedelta(seconds=30)
            log.append((ts, f'{ts:%Y-%m-%dT%H:%M:%S}Z INFO checkout-api msg="heartbeat ok"'))
    for when, svc, version, *_ in DEPLOYS:
        if svc != "checkout-api":
            continue
        ts = datetime.strptime(when, "%Y-%m-%dT%H:%M:%SZ") + timedelta(seconds=20)
        log.append((ts, f'{ts:%Y-%m-%dT%H:%M:%S}Z INFO checkout-api msg="starting version {version}"'))
        log.append((ts + timedelta(seconds=1), f'{ts + timedelta(seconds=1):%Y-%m-%dT%H:%M:%S}Z INFO checkout-api msg="listening on :8080"'))
        log.append((ts + timedelta(seconds=2), f'{ts + timedelta(seconds=2):%Y-%m-%dT%H:%M:%S}Z INFO checkout-api msg="health endpoint ready at /health"'))
    log.sort(key=lambda x: x[0])

    files = [out / "metrics.csv", out / "deploys.csv", out / "app.log"]
    files[0].write_text("\n".join(metrics) + "\n", encoding="utf-8")
    files[1].write_text("time,service,version,author,change\n" + "".join(f"{','.join(d)}\n" for d in DEPLOYS),
                        encoding="utf-8")
    files[2].write_text("\n".join(line for _, line in log) + "\n", encoding="utf-8")
    return files


if __name__ == "__main__":
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--out", default=str(Path(__file__).resolve().parent))
    for f in generate(Path(ap.parse_args().out)):
        print(f"wrote {f}")
