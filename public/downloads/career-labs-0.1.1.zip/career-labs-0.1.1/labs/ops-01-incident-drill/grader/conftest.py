import importlib.util

import pytest

from labgrade.helpers import lab_dir_from, load_solution, register_points_marker

LAB_DIR = lab_dir_from(__file__)


def pytest_configure(config):
    register_points_marker(config)


@pytest.fixture
def sol():
    """The member's drill.py module."""
    return load_solution(LAB_DIR, "drill")


@pytest.fixture
def configcheck():
    """The platform team's validator from provided/ (never the member's copy)."""
    spec = importlib.util.spec_from_file_location("_provided_configcheck", LAB_DIR / "provided" / "configcheck.py")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod
