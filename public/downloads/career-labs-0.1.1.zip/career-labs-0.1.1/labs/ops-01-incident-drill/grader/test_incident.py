"""Graded checks for ops-01-incident-drill."""

import json
import re
from pathlib import Path

import pytest

from labgrade.helpers import solution_file

LAB = Path(__file__).resolve().parent.parent
DATA = LAB / "data"
MONTHLY_REQUESTS = 43_200_000  # 1000 req/min x 30 days


def m(minute, requests, errors):
    return {"minute": f"2024-05-14T10:{minute:02d}", "requests": requests, "errors": errors, "p95_latency_ms": 200}


@pytest.mark.points(5)
def test_load_metrics(sol):
    """load_metrics returns typed rows from metrics.csv"""
    rows = sol.load_metrics(DATA / "metrics.csv")
    assert len(rows) == 180
    assert rows[0] == {"minute": "2024-05-14T13:00", "requests": rows[0]["requests"], "errors": rows[0]["errors"],
                       "p95_latency_ms": rows[0]["p95_latency_ms"]}
    assert all(isinstance(r[k], int) for r in rows for k in ("requests", "errors", "p95_latency_ms"))
    assert rows[67] == {"minute": "2024-05-14T14:07", "requests": 980, "errors": 78, "p95_latency_ms": 396}


@pytest.mark.points(15)
def test_slo_report(sol):
    """slo_report: availability, error budget, % of budget burned, burn rate"""
    tiny = sol.slo_report([m(0, 1000, 1), m(1, 1000, 0)], slo=0.999)
    assert tiny == {"total_requests": 2000, "failed_requests": 1, "availability": 0.9995, "error_budget": 2,
                    "budget_consumed_pct": 50.0, "burn_rate": 0.5, "slo_met": True}
    full = sol.slo_report(sol.load_metrics(DATA / "metrics.csv"), slo=0.999, period_requests=MONTHLY_REQUESTS)
    assert full == {"total_requests": 179918, "failed_requests": 11930, "availability": 0.93369,
                    "error_budget": 43200, "budget_consumed_pct": 27.6, "burn_rate": 66.3, "slo_met": False}
    empty = sol.slo_report([m(0, 1000, 0)], slo=0.99, period_requests=0)
    assert empty["budget_consumed_pct"] is None, "a zero budget must give None, not a ZeroDivisionError"


@pytest.mark.points(15)
def test_first_error_spike(sol):
    """first_error_spike ignores one-minute blips and needs a sustained run"""
    rows = sol.load_metrics(DATA / "metrics.csv")
    assert sol.first_error_spike(rows) == "2024-05-14T14:07", "the 13:20 blip lasted one minute: not the incident"
    assert sol.first_error_spike(rows, sustain_minutes=1) == "2024-05-14T13:20"
    synthetic = [m(0, 100, 0), m(1, 100, 5), m(2, 100, 9), m(3, 100, 4), m(4, 100, 6), m(5, 100, 50), m(6, 100, 7)]
    assert sol.first_error_spike(synthetic, threshold=0.05, sustain_minutes=3) == "2024-05-14T10:04"
    assert sol.first_error_spike(synthetic, threshold=0.05, sustain_minutes=2) == "2024-05-14T10:01"
    assert sol.first_error_spike(synthetic, threshold=0.6) is None
    assert sol.first_error_spike([m(0, 0, 0)] * 3) is None, "0 requests must not divide by zero"


@pytest.mark.points(5)
def test_recovery_minute(sol):
    """recovery_minute finds when errors stay below the threshold again"""
    rows = sol.load_metrics(DATA / "metrics.csv")
    assert sol.recovery_minute(rows, "2024-05-14T14:07") == "2024-05-14T14:43"


@pytest.mark.points(10)
def test_find_deploy(sol):
    """find_deploy correlates the spike with the latest deploy shortly before it"""
    deploys = sol.load_deploys(DATA / "deploys.csv")
    d = sol.find_deploy(deploys, "2024-05-14T14:07")
    assert (d["service"], d["version"], d["time"]) == ("checkout-api", "v2.4.0", "2024-05-14T14:05:00Z")
    assert sol.find_deploy(deploys, "2024-05-14T14:07", service="search-api") is None
    assert sol.find_deploy(deploys, "2024-05-14T14:07", lookback_minutes=1) is None
    assert sol.find_deploy(deploys, "2024-05-14T14:25")["version"] == "v2.4.0-cfg1"


@pytest.mark.points(10)
def test_top_errors(sol):
    """top_errors counts ERROR messages inside [start, end) from app.log"""
    top = sol.top_errors(DATA / "app.log", "2024-05-14T14:07", "2024-05-14T14:43", n=3)
    assert [list(t) for t in top] == [["db connection pool exhausted (max=10)", 749],
                                     ["upstream timeout calling payment-svc", 328],
                                     ["KeyError: 'shipping_tier'", 100]]
    before = sol.top_errors(DATA / "app.log", "2024-05-14T13:00", "2024-05-14T14:00", n=5)
    assert [t[0] for t in before] == ["upstream timeout calling payment-svc"]


@pytest.mark.points(15)
def test_postmortem(sol):
    """postmortem assembles the incident summary dict"""
    pm = sol.postmortem(sol.load_metrics(DATA / "metrics.csv"), sol.load_deploys(DATA / "deploys.csv"),
                        DATA / "app.log", slo=0.999, period_requests=MONTHLY_REQUESTS)
    json.dumps(pm)  # must be JSON serialisable
    assert pm["start"] == "2024-05-14T14:07" and pm["end"] == "2024-05-14T14:43"
    assert pm["duration_minutes"] == 36
    assert pm["severity"] == "SEV1"
    assert pm["trigger"]["version"] == "v2.4.0"
    assert pm["detection_delay_minutes"] == 2
    assert pm["impact"]["failed_requests"] == 11613
    assert pm["impact"]["peak_error_rate_pct"] == 38.0
    assert pm["impact"]["peak_minute"] == "2024-05-14T14:28"
    assert pm["impact"]["budget_consumed_pct"] == 26.9
    assert pm["top_errors"][0][0] == "db connection pool exhausted (max=10)"
    assert isinstance(pm["action_items"], list) and len(pm["action_items"]) >= 3
    assert all(isinstance(a, str) and len(a) > 10 for a in pm["action_items"])
    assert pm["title"]


@pytest.mark.points(15)
def test_service_config_valid(configcheck):
    """your service.yaml passes the platform team's validator"""
    path = solution_file(LAB, "service.yaml")
    problems = configcheck.validate_file(path)
    assert problems == [], "configcheck found: " + "; ".join(problems)


@pytest.mark.points(10)
def test_service_config_matches_app(configcheck):
    """service.yaml matches what the app really does (port and health path from app.log)"""
    import yaml

    cfg = yaml.safe_load(solution_file(LAB, "service.yaml").read_text(encoding="utf-8"))
    log = (DATA / "app.log").read_text(encoding="utf-8")
    port = int(re.search(r'listening on :(\d+)', log).group(1))
    health = re.search(r'health endpoint ready at (\S+)"', log).group(1)
    assert cfg["container"]["port"] == port, f"app.log says the app listens on {port}"
    assert cfg["healthcheck"]["path"] == health, f"app.log says the health endpoint is {health}"
    assert cfg["healthcheck"]["port"] == port, "the health check must probe the app's port"
    assert configcheck.memory_mib(cfg["resources"]["requests"]["memory"]) <= \
        configcheck.memory_mib(cfg["resources"]["limits"]["memory"]), "memory request is above the limit"
    assert cfg["service"]["name"] == "checkout-api", "don't rename the service"
