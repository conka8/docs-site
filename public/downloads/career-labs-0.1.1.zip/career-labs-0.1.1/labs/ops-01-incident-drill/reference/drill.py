"""Reference solution for ops-01-incident-drill."""

from __future__ import annotations

import csv
import json
import re
import sys
from collections import Counter
from datetime import datetime, timedelta
from pathlib import Path

LOG_RE = re.compile(r'^(?P<ts>\S+)Z (?P<level>[A-Z]+) (?P<service>\S+) msg="(?P<msg>[^"]*)"')


def load_metrics(path) -> list[dict]:
    with open(path, newline="", encoding="utf-8") as fh:
        return [{"minute": r["minute"], "requests": int(r["requests"]), "errors": int(r["errors"]),
                 "p95_latency_ms": int(r["p95_latency_ms"])} for r in csv.DictReader(fh)]


def load_deploys(path) -> list[dict]:
    with open(path, newline="", encoding="utf-8") as fh:
        return [dict(r) for r in csv.DictReader(fh)]


def error_rate(row: dict) -> float:
    return row["errors"] / row["requests"] if row["requests"] else 0.0


def slo_report(metrics: list[dict], slo: float = 0.999, period_requests: int | None = None) -> dict:
    total = sum(m["requests"] for m in metrics)
    failed = sum(m["errors"] for m in metrics)
    period = period_requests if period_requests is not None else total
    budget = round((1 - slo) * period)
    ratio = failed / total if total else 0.0
    return {
        "total_requests": total,
        "failed_requests": failed,
        "availability": round(1 - ratio, 5),
        "error_budget": budget,
        "budget_consumed_pct": round(100.0 * failed / budget, 1) if budget else None,
        "burn_rate": round(ratio / (1 - slo), 1),
        "slo_met": (1 - ratio) >= slo,
    }


def _first_run(rows: list[dict], predicate, sustain: int) -> str | None:
    run = 0
    for i, row in enumerate(rows):
        run = run + 1 if predicate(row) else 0
        if run >= sustain:
            return rows[i - sustain + 1]["minute"]
    return None


def first_error_spike(metrics: list[dict], threshold: float = 0.05, sustain_minutes: int = 3) -> str | None:
    return _first_run(metrics, lambda r: error_rate(r) >= threshold, sustain_minutes)


def recovery_minute(metrics: list[dict], after: str, threshold: float = 0.05, sustain_minutes: int = 3) -> str | None:
    later = [m for m in metrics if m["minute"] > after]
    return _first_run(later, lambda r: error_rate(r) < threshold, sustain_minutes)


def _parse_minute(text: str) -> datetime:
    return datetime.strptime(text[:16], "%Y-%m-%dT%H:%M")


def find_deploy(deploys: list[dict], spike_minute: str, service: str | None = None,
                lookback_minutes: int = 30) -> dict | None:
    spike = _parse_minute(spike_minute)
    best = None
    for d in deploys:
        when = datetime.strptime(d["time"], "%Y-%m-%dT%H:%M:%SZ")
        if service and d["service"] != service:
            continue
        if spike - timedelta(minutes=lookback_minutes) <= when <= spike + timedelta(seconds=59):
            if when <= spike and (best is None or when > best[0]):
                best = (when, d)
    return best[1] if best else None


def top_errors(log_path, start: str, end: str, n: int = 3) -> list[list]:
    counts: Counter = Counter()
    for line in Path(log_path).read_text(encoding="utf-8").splitlines():
        m = LOG_RE.match(line)
        if m and m["level"] == "ERROR" and start <= m["ts"][:16] < end:
            counts[m["msg"]] += 1
    return [[msg, c] for msg, c in sorted(counts.items(), key=lambda kv: (-kv[1], kv[0]))[:n]]


def postmortem(metrics: list[dict], deploys: list[dict], log_path, slo: float = 0.999,
               period_requests: int | None = None, threshold: float = 0.05) -> dict:
    start = first_error_spike(metrics, threshold)
    if start is None:
        return {"title": "no incident found", "start": None}
    end = recovery_minute(metrics, start, threshold)
    window = [m for m in metrics if m["minute"] >= start and (end is None or m["minute"] < end)]
    report = slo_report(window, slo, period_requests)
    peak = max(window, key=error_rate)
    trigger = find_deploy(deploys, start)
    service = trigger["service"] if trigger else "unknown service"
    duration = int((_parse_minute(end) - _parse_minute(start)).total_seconds() // 60) if end else None
    peak_pct = round(100 * error_rate(peak), 1)
    return {
        "title": f"{service} elevated errors on {start[:10]}",
        "severity": "SEV1" if peak_pct >= 25 else "SEV2",
        "start": start,
        "end": end,
        "duration_minutes": duration,
        "trigger": trigger,
        "detection_delay_minutes": (
            int((_parse_minute(start) - datetime.strptime(trigger["time"], "%Y-%m-%dT%H:%M:%SZ")).total_seconds() // 60)
            if trigger else None
        ),
        "impact": {
            "failed_requests": report["failed_requests"],
            "peak_error_rate_pct": peak_pct,
            "peak_minute": peak["minute"],
            "budget_consumed_pct": report["budget_consumed_pct"],
        },
        "top_errors": top_errors(log_path, start, end or "9999"),
        "action_items": [
            "Alert on error-budget burn rate (fast burn > 14x over 5 minutes) so we page within 2 minutes.",
            "Raise DB_POOL_MAX and load-test connection usage of async email confirmations before re-release.",
            "Make rollback the first response to errors right after a deploy; document it in the runbook.",
            "Fix the port/health check/resource settings in service.yaml and validate configs in CI.",
        ],
    }


if __name__ == "__main__":
    data = Path(__file__).resolve().parent.parent / "data"
    pm = postmortem(load_metrics(data / "metrics.csv"), load_deploys(data / "deploys.csv"), data / "app.log",
                    period_requests=int(sys.argv[1]) if len(sys.argv) > 1 else 43_200_000)
    print(json.dumps(pm, indent=2))
