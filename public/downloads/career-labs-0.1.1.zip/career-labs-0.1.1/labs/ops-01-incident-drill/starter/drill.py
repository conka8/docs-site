"""ops-01-incident-drill: YOUR SOLUTION GOES HERE.

Read ../README.md first. Fill in every function marked TODO, fix service.yaml, then run:

    python -m labgrade run ops-01-incident-drill

`load_metrics`, `load_deploys` and `error_rate` are done for you.
Times are strings: metrics minutes look like "2024-05-14T14:07", deploy times like
"2024-05-14T14:05:00Z", log lines start with "2024-05-14T14:07:12Z ERROR ...".
"""

from __future__ import annotations

import csv
import json
import re
import sys
from collections import Counter  # noqa: F401
from datetime import datetime, timedelta  # noqa: F401
from pathlib import Path

LOG_RE = re.compile(r'^(?P<ts>\S+)Z (?P<level>[A-Z]+) (?P<service>\S+) msg="(?P<msg>[^"]*)"')


def load_metrics(path) -> list[dict]:
    with open(path, newline="", encoding="utf-8") as fh:
        return [{"minute": r["minute"], "requests": int(r["requests"]), "errors": int(r["errors"]),
                 "p95_latency_ms": int(r["p95_latency_ms"])} for r in csv.DictReader(fh)]


def load_deploys(path) -> list[dict]:
    with open(path, newline="", encoding="utf-8") as fh:
        return [dict(r) for r in csv.DictReader(fh)]


def error_rate(row: dict) -> float:
    return row["errors"] / row["requests"] if row["requests"] else 0.0


def slo_report(metrics: list[dict], slo: float = 0.999, period_requests: int | None = None) -> dict:
    """SLO / error-budget numbers for the given rows.

    Return {"total_requests", "failed_requests",
            "availability": 1 - failed/total rounded to 5 decimals,
            "error_budget": allowed failures in the period = round((1 - slo) * period_requests)
                            (period_requests defaults to total_requests),
            "budget_consumed_pct": 100 * failed / error_budget rounded to 1 decimal (None if budget is 0),
            "burn_rate": (failed/total) / (1 - slo) rounded to 1 decimal,
            "slo_met": availability >= slo (use the unrounded value)}
    """
    # TODO
    raise NotImplementedError("slo_report")


def first_error_spike(metrics: list[dict], threshold: float = 0.05, sustain_minutes: int = 3) -> str | None:
    """Minute that STARTS the first run of `sustain_minutes` consecutive minutes with error rate >= threshold."""
    # TODO
    raise NotImplementedError("first_error_spike")


def recovery_minute(metrics: list[dict], after: str, threshold: float = 0.05, sustain_minutes: int = 3) -> str | None:
    """First minute after `after` that starts a run of `sustain_minutes` minutes with error rate < threshold."""
    # TODO
    raise NotImplementedError("recovery_minute")


def find_deploy(deploys: list[dict], spike_minute: str, service: str | None = None,
                lookback_minutes: int = 30) -> dict | None:
    """The LATEST deploy at or before the spike minute and at most `lookback_minutes` before it.

    Optionally only for one `service`. None if nothing matches.
    """
    # TODO
    raise NotImplementedError("find_deploy")


def top_errors(log_path, start: str, end: str, n: int = 3) -> list[list]:
    """[[message, count], ...] for ERROR lines with start <= minute < end, most frequent first
    (ties: alphabetical), at most n items. Compare the first 16 characters of the timestamp."""
    # TODO
    raise NotImplementedError("top_errors")


def postmortem(metrics: list[dict], deploys: list[dict], log_path, slo: float = 0.999,
               period_requests: int | None = None, threshold: float = 0.05) -> dict:
    """Build the postmortem summary (see the README for every key).

    start = first_error_spike, end = recovery_minute, the incident window is [start, end).
    """
    # TODO
    raise NotImplementedError("postmortem")


if __name__ == "__main__":
    data = Path(__file__).resolve().parent.parent / "data"
    pm = postmortem(load_metrics(data / "metrics.csv"), load_deploys(data / "deploys.csv"), data / "app.log",
                    period_requests=int(sys.argv[1]) if len(sys.argv) > 1 else 43_200_000)
    print(json.dumps(pm, indent=2))
