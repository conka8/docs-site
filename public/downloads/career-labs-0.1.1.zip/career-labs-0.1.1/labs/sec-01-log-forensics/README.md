# SEC-01: Log forensics (SSH brute force and web attacks)

## Scenario

It's 09:00 on 14 March 2024 and the on-call engineer has flagged `web01`. You get two files:

- `data/auth.log`: sshd and sudo messages (syslog format);
- `data/access.log`: nginx access log (combined format).

Somewhere in there is an SSH brute force that worked, what the attacker did next, and a
separate burst of web attacks (path traversal and SQL injection, some URL-encoded twice).
There is also noise meant to fool you: a staff member who mistypes his password, a slow
scanner, and harmless URLs that *look* scary. Write `analyze.py` to find the incident and
produce a timeline JSON a SOC lead can read.

## What you will practise

Parsing syslog and nginx logs with regular expressions, sliding-window detection, linking
events across sources, URL decoding to beat evasion, and avoiding false positives.

## Your task

Edit `starter/analyze.py`. Every function's docstring is the exact spec.

| Function | What it returns |
|---|---|
| `parse_auth_log(source, year)` | events: `failed`, `accepted`, `sudo` |
| `detect_bruteforce(events, threshold=10, window_seconds=300)` | IPs with >= threshold failures inside any sliding window |
| `find_compromises(events, bruteforce)` | successful logins from those IPs (user, ip, time) |
| `post_compromise_activity(events, compromises)` | sudo commands the compromised account ran |
| `parse_access_log(source)` (given) | request dicts |
| `classify_request(path)` | `[]`, `["sqli"]`, `["path_traversal"]` |
| `find_web_attacks(requests)` | one entry per malicious request |
| `build_timeline(auth, access)` | `{"summary": {...}, "events": [...]}` |
| `write_timeline(timeline, path)` (given) | the JSON file |

`source` can be a file path, the whole log as a string, or a list of lines.

Run your analysis:

```
python labs/sec-01-log-forensics/starter/analyze.py incident_timeline.json
```

## Run the grader

```
python -m labgrade run sec-01-log-forensics
```

## Points

| Graded check | Points | What it checks |
|---|---:|---|
| `test_parse_auth_log` | 10 | parse_auth_log turns sshd/sudo lines into events (failed, accepted, sudo) |
| `test_bruteforce_ips` | 15 | detect_bruteforce finds the two fast attackers, not the slow scanner or bob's typos |
| `test_bruteforce_window_logic` | 10 | threshold and sliding window are applied exactly (>= threshold within window_seconds) |
| `test_compromise` | 15 | find_compromises reports the account taken over, from where and when |
| `test_post_compromise_activity` | 5 | post_compromise_activity lists the attacker's sudo commands (not alice's) |
| `test_parse_access_log` | 5 | parse_access_log reads nginx combined log lines |
| `test_classify_request` | 15 | classify_request decodes URLs (even double-encoded) and avoids false positives |
| `test_web_attacks` | 10 | find_web_attacks lists every malicious request from the access log |
| `test_timeline` | 10 | build_timeline merges everything into one ordered incident timeline with a summary |
| `test_write_timeline` | 5 | write_timeline saves valid JSON that round-trips |
| **Total** | **100** | |

## Going further (not graded)

- Map each event to MITRE ATT&CK (T1110 Brute Force, T1078 Valid Accounts, T1190 Exploit Public-Facing Application, T1136 Create Account).
- Write the containment steps: block the IPs, disable `deploy`, remove `sysupdate`, rotate keys, check `/tmp/x.sh`.

## For maintainers

`data/generate.py` rebuilds both logs (seeded, byte-identical). The IPs come from the
documentation ranges (RFC 5737), so they are not real hosts.
