"""Reference solution for sec-01-log-forensics."""

from __future__ import annotations

import json
import re
import sys
from collections import defaultdict
from datetime import datetime, timedelta
from pathlib import Path
from urllib.parse import unquote, unquote_plus

SYSLOG_RE = re.compile(r"^(?P<ts>[A-Z][a-z]{2}\s+\d{1,2} \d{2}:\d{2}:\d{2}) (?P<host>\S+) (?P<proc>[\w\-]+)(?:\[\d+\])?: (?P<msg>.*)$")
FAILED_RE = re.compile(r"^Failed (?P<method>\S+) for (?P<invalid>invalid user )?(?P<user>\S+) from (?P<ip>[\d.]+) port \d+")
ACCEPTED_RE = re.compile(r"^Accepted (?P<method>\S+) for (?P<user>\S+) from (?P<ip>[\d.]+) port \d+")
SUDO_RE = re.compile(r"^\s*(?P<user>\S+) : .*?COMMAND=(?P<cmd>.*)$")
ACCESS_RE = re.compile(
    r'^(?P<ip>\S+) \S+ \S+ \[(?P<ts>[^\]]+)\] "(?P<method>[A-Z]+) (?P<path>\S+) [^"]*" (?P<status>\d{3}) (?P<size>\d+|-)'
    r'(?: "(?P<ref>[^"]*)" "(?P<ua>[^"]*)")?'
)

SQLI_PATTERNS = [
    re.compile(r"'\s*(or|and)\s+'?\w+'?\s*=\s*'?\w+", re.I),   # ' OR '1'='1 / ' or 1=1
    re.compile(r"\bunion\b\s+(all\s+)?\bselect\b", re.I),
    re.compile(r"'\s*;\s*(drop|delete|insert|update|exec)\b", re.I),
    re.compile(r"'\s*(--|#)"),                                 # admin'--
    re.compile(r"\b(sleep|benchmark|pg_sleep)\s*\(", re.I),
    re.compile(r"\bwaitfor\s+delay\b", re.I),
    re.compile(r"\binformation_schema\b", re.I),
]
TRAVERSAL_PATTERNS = [
    re.compile(r"\.\.[/\\]"),
    re.compile(r"/etc/(passwd|shadow)\b"),
    re.compile(r"\x00"),
]


def _lines(source) -> list[str]:
    """Accept a file path, a whole log as one string, or a list of lines."""
    if isinstance(source, Path) or (isinstance(source, str) and "\n" not in source and Path(source).is_file()):
        return Path(source).read_text(encoding="utf-8").splitlines()
    if isinstance(source, str):
        return source.splitlines()
    return list(source)


def _iso(dt: datetime) -> str:
    return dt.strftime("%Y-%m-%dT%H:%M:%S")


def parse_auth_log(source, year: int = 2024) -> list[dict]:
    events = []
    for line in _lines(source):
        m = SYSLOG_RE.match(line.rstrip("\n"))
        if not m:
            continue
        when = _iso(datetime.strptime(f"{year} {m['ts']}", "%Y %b %d %H:%M:%S"))
        base = {"time": when, "host": m["host"], "process": m["proc"]}
        msg = m["msg"]
        if m["proc"] == "sshd":
            f = FAILED_RE.match(msg)
            if f:
                events.append({**base, "event": "failed", "user": f["user"], "ip": f["ip"],
                               "method": f["method"], "invalid_user": bool(f["invalid"])})
                continue
            a = ACCEPTED_RE.match(msg)
            if a:
                events.append({**base, "event": "accepted", "user": a["user"], "ip": a["ip"],
                               "method": a["method"], "invalid_user": False})
        elif m["proc"] == "sudo":
            s = SUDO_RE.match(msg)
            if s:
                events.append({**base, "event": "sudo", "user": s["user"], "ip": None, "command": s["cmd"].strip()})
    return events


def detect_bruteforce(events: list[dict], threshold: int = 10, window_seconds: int = 300) -> list[dict]:
    fails = defaultdict(list)
    for e in events:
        if e["event"] == "failed":
            fails[e["ip"]].append(e)
    found = []
    for ip, evs in fails.items():
        times = sorted(datetime.fromisoformat(e["time"]) for e in evs)
        best, j = 0, 0
        for i in range(len(times)):
            while times[i] - times[j] > timedelta(seconds=window_seconds):
                j += 1
            best = max(best, i - j + 1)
        if best >= threshold:
            found.append({"ip": ip, "failures": len(times), "first_seen": _iso(times[0]), "last_seen": _iso(times[-1]),
                          "max_in_window": best, "users_tried": sorted({e["user"] for e in evs})})
    return sorted(found, key=lambda r: (r["first_seen"], r["ip"]))


def find_compromises(events: list[dict], bruteforce: list[dict]) -> list[dict]:
    first = {b["ip"]: b["first_seen"] for b in bruteforce}
    out = []
    for e in events:
        if e["event"] == "accepted" and e["ip"] in first and e["time"] >= first[e["ip"]]:
            before = sum(1 for x in events if x["event"] == "failed" and x["ip"] == e["ip"] and x["time"] <= e["time"])
            out.append({"ip": e["ip"], "user": e["user"], "time": e["time"], "method": e["method"],
                        "failures_before": before})
    return sorted(out, key=lambda r: r["time"])


def post_compromise_activity(events: list[dict], compromises: list[dict]) -> list[dict]:
    out = []
    for c in compromises:
        for e in events:
            if e["event"] == "sudo" and e["user"] == c["user"] and e["time"] >= c["time"]:
                out.append({"time": e["time"], "user": e["user"], "command": e["command"]})
    return sorted(out, key=lambda r: r["time"])


def parse_access_log(source) -> list[dict]:
    out = []
    for line in _lines(source):
        m = ACCESS_RE.match(line.strip())
        if not m:
            continue
        dt = datetime.strptime(m["ts"].split()[0], "%d/%b/%Y:%H:%M:%S")
        out.append({"ip": m["ip"], "time": _iso(dt), "method": m["method"], "path": m["path"],
                    "status": int(m["status"]), "size": 0 if m["size"] == "-" else int(m["size"]),
                    "referrer": m["ref"] or "-", "user_agent": m["ua"] or ""})
    return out


def _decode(path: str) -> str:
    prev = path
    for _ in range(5):
        cur = unquote_plus(prev)
        if cur == prev:
            break
        prev = cur
    return prev


def classify_request(path: str) -> list[str]:
    text = _decode(path)
    tags = []
    if any(p.search(text) for p in TRAVERSAL_PATTERNS):
        tags.append("path_traversal")
    if any(p.search(text) for p in SQLI_PATTERNS):
        tags.append("sqli")
    return sorted(tags)


def find_web_attacks(requests: list[dict]) -> list[dict]:
    out = []
    for r in requests:
        for tag in classify_request(r["path"]):
            out.append({"time": r["time"], "ip": r["ip"], "method": r["method"], "path": r["path"],
                        "status": r["status"], "attack": tag})
    return sorted(out, key=lambda a: (a["time"], a["attack"]))


def build_timeline(auth_source, access_source, year: int = 2024, threshold: int = 10,
                   window_seconds: int = 300) -> dict:
    events = parse_auth_log(auth_source, year)
    brute = detect_bruteforce(events, threshold, window_seconds)
    comps = find_compromises(events, brute)
    post = post_compromise_activity(events, comps)
    attacks = find_web_attacks(parse_access_log(access_source))

    timeline = []
    for b in brute:
        timeline.append({"time": b["first_seen"], "source": "auth", "type": "bruteforce", "ip": b["ip"],
                         "detail": f"{b['failures']} failed SSH logins until {b['last_seen']}"})
    for c in comps:
        timeline.append({"time": c["time"], "source": "auth", "type": "compromise", "ip": c["ip"],
                         "detail": f"successful {c['method']} login as {c['user']}"})
    ip_of = {c["user"]: c["ip"] for c in comps}
    for p in post:
        timeline.append({"time": p["time"], "source": "auth", "type": "privilege_escalation",
                         "ip": ip_of.get(p["user"]), "detail": f"{p['user']} ran sudo {p['command']}"})
    for a in attacks:
        timeline.append({"time": a["time"], "source": "web", "type": a["attack"], "ip": a["ip"],
                         "detail": f"{a['method']} {a['path']} -> {a['status']}"})
    timeline.sort(key=lambda e: (e["time"], e["type"]))

    summary = {
        "bruteforce_ips": [b["ip"] for b in brute],
        "compromised_accounts": [{"user": c["user"], "ip": c["ip"], "time": c["time"]} for c in comps],
        "web_attacker_ips": sorted({a["ip"] for a in attacks}),
        "first_malicious_activity": timeline[0]["time"] if timeline else None,
        "successful_web_attacks": sum(1 for a in attacks if 200 <= a["status"] < 300),
    }
    return {"summary": summary, "events": timeline}


def write_timeline(timeline: dict, path) -> Path:
    path = Path(path)
    path.write_text(json.dumps(timeline, indent=2) + "\n", encoding="utf-8")
    return path


if __name__ == "__main__":
    data = Path(__file__).resolve().parent.parent / "data"
    report = build_timeline(data / "auth.log", data / "access.log")
    out = write_timeline(report, sys.argv[1] if len(sys.argv) > 1 else "incident_timeline.json")
    print(json.dumps(report["summary"], indent=2))
    print(f"timeline with {len(report['events'])} events written to {out}")
