"""sec-01-log-forensics: YOUR SOLUTION GOES HERE.

Read ../README.md first. Fill in every function marked TODO, then run:

    python -m labgrade run sec-01-log-forensics

`parse_access_log` and `write_timeline` are done for you; use them as examples.
"""

from __future__ import annotations

import json
import re
import sys
from collections import defaultdict  # noqa: F401  (you will probably want it)
from datetime import datetime, timedelta  # noqa: F401
from pathlib import Path
from urllib.parse import unquote_plus  # noqa: F401

# Example syslog line:
# Mar 14 04:03:41 web01 sshd[2391]: Accepted password for deploy from 203.0.113.45 port 51990 ssh2
SYSLOG_RE = re.compile(
    r"^(?P<ts>[A-Z][a-z]{2}\s+\d{1,2} \d{2}:\d{2}:\d{2}) (?P<host>\S+) (?P<proc>[\w\-]+)(?:\[\d+\])?: (?P<msg>.*)$"
)
ACCESS_RE = re.compile(
    r'^(?P<ip>\S+) \S+ \S+ \[(?P<ts>[^\]]+)\] "(?P<method>[A-Z]+) (?P<path>\S+) [^"]*" (?P<status>\d{3}) (?P<size>\d+|-)'
    r'(?: "(?P<ref>[^"]*)" "(?P<ua>[^"]*)")?'
)


def _lines(source) -> list[str]:
    """Accept a file path, a whole log as one string, or a list of lines."""
    if isinstance(source, Path) or (isinstance(source, str) and "\n" not in source and Path(source).is_file()):
        return Path(source).read_text(encoding="utf-8").splitlines()
    if isinstance(source, str):
        return source.splitlines()
    return list(source)


def _iso(dt: datetime) -> str:
    return dt.strftime("%Y-%m-%dT%H:%M:%S")


def parse_auth_log(source, year: int = 2024) -> list[dict]:
    """Parse auth.log into a list of event dicts (skip lines you don't recognise).

    Every event: {"time": "2024-03-14T04:03:41", "host": "web01", "process": "sshd"|"sudo", "event": ...}
      - "Failed password for [invalid user] X from IP ..." -> event "failed", user X, ip, method ("password"),
        invalid_user True/False
      - "Accepted <method> for X from IP ..."              -> event "accepted", user, ip, method, invalid_user False
      - sudo lines "  deploy : TTY=... ; COMMAND=/bin/x"   -> event "sudo", user, ip None, command "/bin/x"
    Syslog has no year, so use the `year` argument.
    """
    # TODO
    raise NotImplementedError("parse_auth_log")


def detect_bruteforce(events: list[dict], threshold: int = 10, window_seconds: int = 300) -> list[dict]:
    """IPs with at least `threshold` failed logins inside ANY sliding window of `window_seconds`.

    Return dicts sorted by first_seen:
      {"ip", "failures" (all failures from that IP), "first_seen", "last_seen",
       "max_in_window" (most failures inside one window), "users_tried" (sorted unique users)}
    Two failures exactly window_seconds apart are inside the same window.
    """
    # TODO
    raise NotImplementedError("detect_bruteforce")


def find_compromises(events: list[dict], bruteforce: list[dict]) -> list[dict]:
    """Successful logins from a brute-force IP at/after its first failure.

    Return [{"ip", "user", "time", "method", "failures_before"}] sorted by time, where
    failures_before = failed logins from that IP up to the successful login.
    """
    # TODO
    raise NotImplementedError("find_compromises")


def post_compromise_activity(events: list[dict], compromises: list[dict]) -> list[dict]:
    """sudo commands run by a compromised user at/after the compromise: [{"time", "user", "command"}]."""
    # TODO
    raise NotImplementedError("post_compromise_activity")


def parse_access_log(source) -> list[dict]:
    """Parse nginx 'combined' log lines (already done for you)."""
    out = []
    for line in _lines(source):
        m = ACCESS_RE.match(line.strip())
        if not m:
            continue
        dt = datetime.strptime(m["ts"].split()[0], "%d/%b/%Y:%H:%M:%S")
        out.append({"ip": m["ip"], "time": _iso(dt), "method": m["method"], "path": m["path"],
                    "status": int(m["status"]), "size": 0 if m["size"] == "-" else int(m["size"]),
                    "referrer": m["ref"] or "-", "user_agent": m["ua"] or ""})
    return out


def classify_request(path: str) -> list[str]:
    """Return a sorted list of attack tags for a request path: [], ["sqli"], ["path_traversal"] or both.

    Attackers URL-encode (%2e%2e%2f) and even double-encode (%252e) payloads: decode
    repeatedly (unquote_plus) until the text stops changing, THEN look for patterns.
    Avoid false positives: "O'Reilly", "union jobs", "v1..v2" are normal traffic.
    """
    # TODO
    raise NotImplementedError("classify_request")


def find_web_attacks(requests: list[dict]) -> list[dict]:
    """One dict per (request, attack tag): {"time", "ip", "method", "path", "status", "attack"}, by time."""
    # TODO
    raise NotImplementedError("find_web_attacks")


def build_timeline(auth_source, access_source, year: int = 2024, threshold: int = 10,
                   window_seconds: int = 300) -> dict:
    """Build the incident report: {"summary": {...}, "events": [...]}.

    events (sorted by time): {"time", "source": "auth"|"web", "type", "ip", "detail"} with type one of
      "bruteforce" (at first_seen, one per IP), "compromise", "privilege_escalation" (each sudo by the
      compromised user), "sqli", "path_traversal".
    summary: {"bruteforce_ips": [...], "compromised_accounts": [{"user", "ip", "time"}],
              "web_attacker_ips": sorted list, "first_malicious_activity": time of first event,
              "successful_web_attacks": number of attack requests with a 2xx status}
    """
    # TODO
    raise NotImplementedError("build_timeline")


def write_timeline(timeline: dict, path) -> Path:
    """Save the timeline as pretty JSON (already done for you)."""
    path = Path(path)
    path.write_text(json.dumps(timeline, indent=2) + "\n", encoding="utf-8")
    return path


if __name__ == "__main__":
    data = Path(__file__).resolve().parent.parent / "data"
    report = build_timeline(data / "auth.log", data / "access.log")
    out = write_timeline(report, sys.argv[1] if len(sys.argv) > 1 else "incident_timeline.json")
    print(json.dumps(report["summary"], indent=2))
    print(f"timeline with {len(report['events'])} events written to {out}")
