# SEC-02: Secure code review (fix the vulnerable shop backend)

## Scenario

A contractor delivered `vulnapp.py`, the helper functions behind a small shop's web server:
user lookup, product search, password storage, an API token check, file downloads,
session cookies and config loading. Everything *works*, but a pentest is booked for next
week. Review the code, find the vulnerabilities and fix them **without changing any
function name or signature**. Normal behaviour must keep working.

The grader runs real exploit attempts against your code: SQL injection, path traversal
(including URL-encoded and symlink tricks), a pickle cookie that runs code, a malicious YAML
tag, and a token check that fails open. All exploits are harmless and run in a temp folder.

## What you will practise

Recognising and fixing CWE-89 (SQL injection), CWE-22 (path traversal), CWE-916 (weak password
hashing), CWE-208 (timing side channels), CWE-287 (fail-open authentication) and CWE-502
(insecure deserialization). These are the questions AppSec interviews ask about.

## Your task

Edit `starter/vulnapp.py`. Requirements the grader checks:

- **SQL**: use `?` parameters everywhere. Searching for `100%` must find "100% Cotton Towel"
  (escape LIKE wildcards).
- **Passwords**: store `pbkdf2_sha256$<iterations>$<salt hex>$<hash hex>` (at least 100,000
  iterations, OWASP currently suggests 600,000; verify the current guidance) with a random
  16-byte salt per password, or an `scrypt$...` string. `verify_password` must compare with
  `hmac.compare_digest`.
- **API token**: if no token is configured, nobody gets in. Compare with `hmac.compare_digest`
  on bytes, so non-ASCII tokens work.
- **Downloads**: `safe_join` raises `ValueError` for anything that resolves outside the folder
  (`..`, absolute paths, symlinks). `handle_download` answers 403 for those.
- **Sessions**: no `pickle`. Use JSON in base64, and raise `ValueError` for bad cookies.
- **Config**: `yaml.safe_load`; raise `ValueError` if the result is not a mapping.

There's no `data/` folder in this lab: the grader builds its own temp files.
It needs `pyyaml` (`pip install pyyaml`).

## Run the grader

```
python -m labgrade run sec-02-secure-code-review
```

Before you fix anything, run it once. It's worth seeing the exploits succeed against the original code.

## Points

| Graded check | Points | What it checks |
|---|---:|---|
| `test_find_user_normal` | 5 | normal behaviour: create_user + find_user work for real usernames |
| `test_find_user_sql_injection` | 15 | SQL injection: find_user/create_user must use parameters, not string formatting |
| `test_search_products_sql_injection` | 10 | SQL injection in LIKE search: no UNION leaks; normal search still works |
| `test_password_hash_is_salted_and_slow` | 15 | password storage: pbkdf2_sha256 (>=100k iterations) or scrypt, random salt, no fast hash |
| `test_verify_password` | 5 | verify_password accepts the right password only |
| `test_api_token_check` | 10 | token check: constant-time compare, and fail closed when no token is configured |
| `test_safe_join_blocks_traversal` | 15 | path traversal: .., absolute paths and symlinks out of the folder are refused |
| `test_download_handler` | 10 | GET /download: normal files are served, encoded traversal gets 403 and leaks nothing |
| `test_session_no_pickle` | 10 | insecure deserialization: session cookies must not be unpickled |
| `test_config_safe_yaml` | 5 | insecure deserialization: YAML config must use safe loading |
| **Total** | **100** | |

## Going further (not graded)

Sign session cookies with `hmac.new(key, payload, "sha256")` so users can't edit them, add rate
limiting to logins, and write a one-page review report: finding, impact, fix, CWE.
