import sqlite3
import sys
import types

import pytest

from labgrade.helpers import lab_dir_from, load_solution, register_points_marker

LAB_DIR = lab_dir_from(__file__)


def pytest_configure(config):
    register_points_marker(config)


@pytest.fixture
def app():
    """The member's vulnapp.py module."""
    return load_solution(LAB_DIR, "vulnapp")


@pytest.fixture
def db(app):
    conn = sqlite3.connect(":memory:")
    app.init_db(conn)
    conn.executemany("INSERT INTO products (name, price) VALUES (?, ?)",
                     [("Blue Mug", 12.5), ("Red Mug", 13.0), ("Tea Pot", 30.0), ("100% Cotton Towel", 9.99)])
    conn.commit()
    yield conn
    conn.close()


@pytest.fixture
def pwned():
    """A harmless module an exploit payload tries to call. The list records any call."""
    calls = []
    mod = types.ModuleType("_pwn_sentinel")
    mod.trigger = lambda *a, **k: calls.append(a) or {"owned": True}
    sys.modules["_pwn_sentinel"] = mod
    yield calls
    sys.modules.pop("_pwn_sentinel", None)
