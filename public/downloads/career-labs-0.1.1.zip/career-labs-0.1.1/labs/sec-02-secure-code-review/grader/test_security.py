"""Graded checks for sec-02-secure-code-review: exploits must fail, normal use must work."""

import base64
import hashlib
import inspect
import os

import pytest

PICKLE_RCE = base64.urlsafe_b64encode(b"c_pwn_sentinel\ntrigger\n(tR.").decode()


def make_users(app, db):
    app.create_user(db, "admin", "S3cure!admin", role="admin")
    app.create_user(db, "alice", "alice-pass-123")


@pytest.mark.points(5)
def test_find_user_normal(app, db):
    """normal behaviour: create_user + find_user work for real usernames"""
    make_users(app, db)
    assert app.find_user(db, "alice") == {"id": 2, "username": "alice", "role": "user"}
    assert app.find_user(db, "admin")["role"] == "admin"
    assert app.find_user(db, "nobody") is None


@pytest.mark.points(15)
def test_find_user_sql_injection(app, db):
    """SQL injection: find_user/create_user must use parameters, not string formatting"""
    make_users(app, db)
    assert app.find_user(db, "' OR '1'='1") is None, "login bypass: ' OR '1'='1 returned a user"
    assert app.find_user(db, "nobody' UNION SELECT 1, 'x', 'admin'--") is None
    # a legit name with a quote must work (string formatting breaks on it)
    uid = app.create_user(db, "o'brien", "pw-o-brien-1")
    assert app.find_user(db, "o'brien")["id"] == uid
    app.create_user(db, "mallory', 'x', 'admin')--", "pw")
    assert app.find_user(db, "mallory', 'x', 'admin')--")["role"] == "user", "role was injected via username"


@pytest.mark.points(10)
def test_search_products_sql_injection(app, db):
    """SQL injection in LIKE search: no UNION leaks; normal search still works"""
    make_users(app, db)
    assert [p["name"] for p in app.search_products(db, "mug")] == ["Blue Mug", "Red Mug"]
    leak = app.search_products(db, "' UNION SELECT id, username || ':' || password_hash, 0 FROM users--")
    assert leak == [], "UNION injection leaked the users table"
    assert app.search_products(db, "' OR 1=1--") == []
    assert [p["name"] for p in app.search_products(db, "100%")] == ["100% Cotton Towel"]


@pytest.mark.points(15)
def test_password_hash_is_salted_and_slow(app):
    """password storage: pbkdf2_sha256 (>=100k iterations) or scrypt, random salt, no fast hash"""
    pw = "correct horse battery staple"
    h1, h2 = app.hash_password(pw), app.hash_password(pw)
    assert h1 != h2, "same password gave the same hash: no random salt"
    for fast in (hashlib.md5, hashlib.sha1, hashlib.sha256):
        assert fast(pw.encode()).hexdigest() not in h1, f"stored hash contains a plain {fast().name} of the password"
    algo = h1.split("$")[0]
    assert algo in ("pbkdf2_sha256", "scrypt"), "use format pbkdf2_sha256$<iterations>$<salt>$<hash> or scrypt$..."
    if algo == "pbkdf2_sha256":
        assert int(h1.split("$")[1]) >= 100_000, "too few PBKDF2 iterations"
        assert len(bytes.fromhex(h1.split("$")[2])) >= 16, "salt should be at least 16 random bytes"


@pytest.mark.points(5)
def test_verify_password(app):
    """verify_password accepts the right password only"""
    stored = app.hash_password("alice-pass-123")
    assert app.verify_password("alice-pass-123", stored) is True
    assert app.verify_password("alice-pass-124", stored) is False
    assert app.verify_password("", stored) is False


@pytest.mark.points(10)
def test_api_token_check(app):
    """token check: constant-time compare, and fail closed when no token is configured"""
    assert app.check_api_token("tok_live_abc123", "tok_live_abc123") is True
    assert app.check_api_token("tok_live_abc124", "tok_live_abc123") is False
    assert app.check_api_token("tok", "tok_live_abc123") is False
    assert app.check_api_token("anything", "") is False, "empty configured token must NOT let everyone in"
    assert app.check_api_token("anything", None) is False
    assert app.check_api_token(None, "tok_live_abc123") is False
    assert app.check_api_token("tökén-ü", "tökén-ü") is True, "non-ASCII tokens must not crash"
    src = inspect.getsource(app.check_api_token) + inspect.getsource(app.verify_password)
    assert "compare_digest" in src, "use hmac.compare_digest (or secrets.compare_digest) to compare secrets"


@pytest.mark.points(15)
def test_safe_join_blocks_traversal(app, tmp_path):
    """path traversal: .., absolute paths and symlinks out of the folder are refused"""
    base = tmp_path / "downloads"
    (base / "reports").mkdir(parents=True)
    (base / "reports" / "q1.txt").write_text("q1 numbers")
    (tmp_path / "secret.txt").write_text("TOP SECRET")
    assert app.safe_join(base, "reports/q1.txt").read_text() == "q1 numbers"
    assert app.safe_join(base, "reports/../reports/q1.txt").read_text() == "q1 numbers"
    for evil in ["../secret.txt", "reports/../../secret.txt", str(tmp_path / "secret.txt"), "/etc/passwd"]:
        with pytest.raises(ValueError):
            app.safe_join(base, evil)
    if hasattr(os, "symlink"):
        os.symlink(tmp_path / "secret.txt", base / "link.txt")
        with pytest.raises(ValueError):
            app.safe_join(base, "link.txt")


@pytest.mark.points(10)
def test_download_handler(app, tmp_path):
    """GET /download: normal files are served, encoded traversal gets 403 and leaks nothing"""
    base = tmp_path / "downloads"
    base.mkdir()
    (base / "price-list.txt").write_text("mugs 12.50")
    (tmp_path / "secret.txt").write_text("TOP SECRET")
    assert app.handle_download("file=price-list.txt", base) == (200, b"mugs 12.50")
    assert app.handle_download("file=missing.txt", base)[0] == 404
    assert app.handle_download("other=1", base)[0] == 400
    for q in ["file=../secret.txt", "file=..%2Fsecret.txt", "file=%2E%2E/secret.txt"]:
        status, body = app.handle_download(q, base)
        assert status == 403, f"{q} should be forbidden, got {status}"
        assert b"SECRET" not in body


@pytest.mark.points(10)
def test_session_no_pickle(app, pwned):
    """insecure deserialization: session cookies must not be unpickled"""
    cookie = app.dump_session({"user": "alice", "cart": [1, 2]})
    assert app.load_session(cookie) == {"user": "alice", "cart": [1, 2]}
    with pytest.raises(ValueError):
        app.load_session(PICKLE_RCE)
    assert pwned == [], "a crafted cookie executed code on the server (pickle RCE)"
    with pytest.raises(ValueError):
        app.load_session("not base64 !!")
    src = inspect.getsource(app.load_session)
    assert "pickle" not in src


@pytest.mark.points(5)
def test_config_safe_yaml(app, pwned):
    """insecure deserialization: YAML config must use safe loading"""
    pytest.importorskip("yaml")
    assert app.load_config("port: 8080\nhosts: [a, b]\n") == {"port": 8080, "hosts": ["a", "b"]}
    try:
        app.load_config("x: !!python/object/apply:_pwn_sentinel.trigger [1]\n")
    except ValueError:
        pass
    assert pwned == [], "a YAML tag executed code (use yaml.safe_load)"
    with pytest.raises(ValueError):
        app.load_config("- just\n- a list\n")
