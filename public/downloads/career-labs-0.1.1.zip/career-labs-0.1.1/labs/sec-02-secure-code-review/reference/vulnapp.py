"""vulnapp, fixed. Reference solution for sec-02-secure-code-review.

Every fix is marked with "FIX:" and the vulnerability class it addresses.
"""

from __future__ import annotations

import base64
import binascii
import hashlib
import hmac
import json
import secrets
import sqlite3
from pathlib import Path
from urllib.parse import parse_qs

PBKDF2_ITERATIONS = 600_000  # OWASP guidance for PBKDF2-HMAC-SHA256 (verify the current number)


# ---------------------------------------------------------------- database
def init_db(conn: sqlite3.Connection) -> None:
    conn.executescript(
        """
        CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY, username TEXT UNIQUE, password_hash TEXT, role TEXT);
        CREATE TABLE IF NOT EXISTS products (id INTEGER PRIMARY KEY, name TEXT, price REAL);
        """
    )


def create_user(conn: sqlite3.Connection, username: str, password: str, role: str = "user") -> int:
    """Insert a user with a hashed password and return its id."""
    # FIX (SQL injection, CWE-89): parameters, never string formatting
    cur = conn.execute(
        "INSERT INTO users (username, password_hash, role) VALUES (?, ?, ?)",
        (username, hash_password(password), role),
    )
    conn.commit()
    return cur.lastrowid


def find_user(conn: sqlite3.Connection, username: str) -> dict | None:
    """Return {"id", "username", "role"} for an exact username match, else None."""
    row = conn.execute("SELECT id, username, role FROM users WHERE username = ?", (username,)).fetchone()
    return {"id": row[0], "username": row[1], "role": row[2]} if row else None


def search_products(conn: sqlite3.Connection, term: str) -> list[dict]:
    """Products whose name contains `term` (case-insensitive): [{"id", "name", "price"}] by id."""
    # FIX (SQL injection): bind the pattern; escape LIKE wildcards so '%' and '_' are literal
    escaped = term.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")
    rows = conn.execute(
        "SELECT id, name, price FROM products WHERE name LIKE ? ESCAPE '\\' ORDER BY id",
        (f"%{escaped}%",),
    ).fetchall()
    return [{"id": r[0], "name": r[1], "price": r[2]} for r in rows]


# ---------------------------------------------------------------- passwords and tokens
def hash_password(password: str, salt: bytes | None = None) -> str:
    """Return 'pbkdf2_sha256$<iterations>$<salt hex>$<hash hex>'."""
    # FIX (weak hashing, CWE-916): random per-user salt + slow KDF instead of unsalted MD5
    salt = salt if salt is not None else secrets.token_bytes(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, PBKDF2_ITERATIONS)
    return f"pbkdf2_sha256${PBKDF2_ITERATIONS}${salt.hex()}${digest.hex()}"


def verify_password(password: str, stored: str) -> bool:
    try:
        algo, iterations, salt_hex, hash_hex = stored.split("$")
        if algo != "pbkdf2_sha256":
            return False
        digest = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), bytes.fromhex(salt_hex), int(iterations))
    except (ValueError, AttributeError):
        return False
    # FIX (timing attack, CWE-208): constant-time comparison
    return hmac.compare_digest(digest.hex(), hash_hex)


def check_api_token(provided: str | None, expected: str | None) -> bool:
    """True only if a token was configured and the provided one matches it."""
    # FIX (fail-open auth, CWE-287): no token configured means nobody gets in
    if not expected or not provided:
        return False
    # FIX (timing attack): compare_digest on bytes (works for non-ASCII too)
    return hmac.compare_digest(provided.encode("utf-8"), expected.encode("utf-8"))


# ---------------------------------------------------------------- file downloads
def safe_join(base_dir, requested: str) -> Path:
    """Path of `requested` inside `base_dir`; ValueError if it would escape."""
    # FIX (path traversal, CWE-22): resolve (follows .. and symlinks) and check containment
    if not requested or "\x00" in requested:
        raise ValueError("invalid file name")
    base = Path(base_dir).resolve()
    candidate = (base / requested).resolve()
    if candidate != base and base not in candidate.parents:
        raise ValueError("path escapes the download folder")
    return candidate


def handle_download(query_string: str, base_dir) -> tuple[int, bytes]:
    params = parse_qs(query_string)
    if "file" not in params:
        return 400, b"missing file parameter"
    try:
        path = safe_join(base_dir, params["file"][0])
    except ValueError:
        return 403, b"forbidden"
    if not path.is_file():
        return 404, b"not found"
    return 200, path.read_bytes()


# ---------------------------------------------------------------- sessions and config
def dump_session(data: dict) -> str:
    # FIX (insecure deserialization, CWE-502): JSON instead of pickle
    return base64.urlsafe_b64encode(json.dumps(data, separators=(",", ":")).encode("utf-8")).decode()


def load_session(cookie: str) -> dict:
    try:
        data = json.loads(base64.urlsafe_b64decode(cookie.encode()).decode("utf-8"))
    except (binascii.Error, UnicodeDecodeError, ValueError) as exc:
        raise ValueError("invalid session cookie") from exc
    if not isinstance(data, dict):
        raise ValueError("invalid session cookie")
    return data


def load_config(text: str) -> dict:
    import yaml

    # FIX (insecure deserialization): safe_load only builds plain data types
    try:
        data = yaml.safe_load(text)
    except yaml.YAMLError as exc:
        raise ValueError(f"invalid config: {exc}") from exc
    if not isinstance(data, dict):
        raise ValueError("config must be a mapping")
    return data
