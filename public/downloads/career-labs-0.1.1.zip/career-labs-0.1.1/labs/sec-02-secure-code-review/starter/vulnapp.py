"""vulnapp: the backend helpers of a tiny shop. IT WORKS... AND IT IS FULL OF HOLES.

Your job (see ../README.md): review this file, find the vulnerabilities and fix them
without breaking normal behaviour. Keep every function name and signature.

    python -m labgrade run sec-02-secure-code-review

Hint: there are at least 8 problems. Each function's docstring says what it SHOULD do.
"""

from __future__ import annotations

import base64
import hashlib
import os
import pickle
import sqlite3
from pathlib import Path
from urllib.parse import parse_qs


# ---------------------------------------------------------------- database
def init_db(conn: sqlite3.Connection) -> None:
    conn.executescript(
        """
        CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY, username TEXT UNIQUE, password_hash TEXT, role TEXT);
        CREATE TABLE IF NOT EXISTS products (id INTEGER PRIMARY KEY, name TEXT, price REAL);
        """
    )


def create_user(conn: sqlite3.Connection, username: str, password: str, role: str = "user") -> int:
    """Insert a user with a hashed password and return its id."""
    cur = conn.execute(
        f"INSERT INTO users (username, password_hash, role) VALUES ('{username}', '{hash_password(password)}', '{role}')"
    )
    conn.commit()
    return cur.lastrowid


def find_user(conn: sqlite3.Connection, username: str) -> dict | None:
    """Return {"id", "username", "role"} for an exact username match, else None."""
    row = conn.execute(f"SELECT id, username, role FROM users WHERE username = '{username}'").fetchone()
    return {"id": row[0], "username": row[1], "role": row[2]} if row else None


def search_products(conn: sqlite3.Connection, term: str) -> list[dict]:
    """Products whose name contains `term` (case-insensitive): [{"id", "name", "price"}] by id."""
    rows = conn.execute(
        f"SELECT id, name, price FROM products WHERE name LIKE '%{term}%' ORDER BY id"
    ).fetchall()
    return [{"id": r[0], "name": r[1], "price": r[2]} for r in rows]


# ---------------------------------------------------------------- passwords and tokens
def hash_password(password: str, salt: bytes | None = None) -> str:
    """Return a self-describing, salted, slow hash string for storage."""
    return hashlib.md5(password.encode()).hexdigest()


def verify_password(password: str, stored: str) -> bool:
    """True if `password` matches the stored hash."""
    return hash_password(password) == stored


def check_api_token(provided: str | None, expected: str | None) -> bool:
    """True only if a token was configured and the provided one matches it."""
    if not expected:
        return True  # no token configured yet: let everyone in during development
    return provided == expected


# ---------------------------------------------------------------- file downloads
def safe_join(base_dir, requested: str) -> Path:
    """Path of `requested` inside `base_dir`. Must never point outside base_dir."""
    return Path(os.path.join(base_dir, requested))


def handle_download(query_string: str, base_dir) -> tuple[int, bytes]:
    """Handle GET /download?file=<name>. Returns (HTTP status, body).

    400 if `file` is missing, 403 if the path is not allowed, 404 if it does not exist,
    200 + file bytes otherwise.
    """
    params = parse_qs(query_string)
    if "file" not in params:
        return 400, b"missing file parameter"
    path = safe_join(base_dir, params["file"][0])
    if not path.is_file():
        return 404, b"not found"
    return 200, path.read_bytes()


# ---------------------------------------------------------------- sessions and config
def dump_session(data: dict) -> str:
    """Serialise a session dict into a cookie-safe string."""
    return base64.urlsafe_b64encode(pickle.dumps(data)).decode()


def load_session(cookie: str) -> dict:
    """Parse a session cookie produced by dump_session. Raise ValueError if it is invalid."""
    return pickle.loads(base64.urlsafe_b64decode(cookie.encode()))


def load_config(text: str) -> dict:
    """Parse a YAML config file into a dict. Raise ValueError if it is invalid."""
    import yaml

    return yaml.load(text, Loader=yaml.UnsafeLoader)
