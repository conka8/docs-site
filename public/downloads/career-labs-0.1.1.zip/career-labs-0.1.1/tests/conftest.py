import sys

import pytest

from labgrade.core import discover_labs, run_lab

sys.dont_write_bytecode = True  # keep labs/ free of __pycache__ when meta-tests import lab files

LABS = discover_labs()
LAB_IDS = [lab.id for lab in LABS]
_CACHE: dict = {}


@pytest.fixture(scope="session")
def grade():
    """grade(lab_id, solution) -> LabResult, each combination run once per session."""

    def _grade(lab_id: str, solution: str):
        key = (lab_id, solution)
        if key not in _CACHE:
            _CACHE[key] = run_lab(lab_id, solution)
        return _CACHE[key]

    return _grade
