"""The example GitHub Classroom files must stay in sync with the graders."""

import json
from pathlib import Path

import yaml

from conftest import LAB_IDS
from labgrade.core import classroom_config, get_lab

ROOT = Path(__file__).resolve().parent.parent


def test_autograding_json_in_sync():
    committed = json.loads((ROOT / ".github" / "classroom" / "autograding.json").read_text(encoding="utf-8"))
    assert committed == classroom_config(LAB_IDS, "starter")
    assert sum(t["points"] for t in committed["tests"]) == 100 * len(LAB_IDS)
    for t in committed["tests"]:
        assert t["run"].startswith("python -m labgrade run ") and "--fail-under 100" in t["run"]


def test_workflow_matches_de01_points():
    wf = yaml.safe_load((ROOT / ".github" / "workflows" / "classroom.yml").read_text(encoding="utf-8"))
    steps = wf["jobs"]["run-autograding-tests"]["steps"]
    graders = [s for s in steps if str(s.get("uses", "")).startswith("classroom-resources/autograding-command-grader")]
    points = get_lab("de-01-orders-pipeline").static_points()
    assert {s["with"]["test-name"]: s["with"]["max-score"] for s in graders} == points
    for s in graders:
        assert f"--test {s['with']['test-name']} " in s["with"]["command"]
    reporter = [s for s in steps if str(s.get("uses", "")).startswith("classroom-resources/autograding-grading-reporter")]
    assert len(reporter) == 1
    runners = reporter[0]["with"]["runners"].split(",")
    assert runners == [s["id"] for s in graders]
    for r in runners:
        assert f"{r.upper()}_RESULTS" in reporter[0]["env"]
