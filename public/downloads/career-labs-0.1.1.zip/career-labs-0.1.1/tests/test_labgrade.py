"""Unit and CLI tests for the labgrade package itself (using small throwaway labs)."""

import json
import subprocess
import sys
from pathlib import Path

import pytest

from labgrade import __version__, cli, core, helpers
from labgrade.core import LabError, LabResult, TestResult, format_text, run_lab

ROOT = Path(__file__).resolve().parent.parent

FAKE_GRADER = '''
import pytest
from labgrade.helpers import load_solution, lab_dir_from

LAB = lab_dir_from(__file__)


@pytest.fixture
def sol():
    return load_solution(LAB, "solution")


@pytest.mark.points(30)
def test_add(sol):
    """add() adds numbers"""
    assert sol.add(2, 3) == 5, "2 + 3 should be 5"


@pytest.mark.points(50)
def test_sub(sol):
    """sub() subtracts"""
    assert sol.sub(5, 3) == 2, "5 - 3 should be 2"


def test_unmarked_is_one_point(sol):
    assert sol.VERSION == 1


@pytest.mark.points(19)
def test_fixture_error(sol, missing_fixture_name):
    pass
'''


@pytest.fixture
def fake_labs(tmp_path):
    lab = tmp_path / "labs" / "toy-01"
    (lab / "grader").mkdir(parents=True)
    (lab / "reference").mkdir()
    (lab / "starter").mkdir()
    (lab / "README.md").write_text("# Toy lab\n\nA tiny lab.\n")
    (lab / "grader" / "test_toy.py").write_text(FAKE_GRADER)
    (lab / "reference" / "solution.py").write_text("VERSION = 1\ndef add(a, b): return a + b\ndef sub(a, b): return a - b\n")
    (lab / "starter" / "solution.py").write_text("VERSION = 0\ndef add(a, b): return a + b\ndef sub(a, b):\n    raise NotImplementedError('sub')\n")
    broken = tmp_path / "labs" / "broken-01"
    (broken / "grader").mkdir(parents=True)
    (broken / "reference").mkdir()
    (broken / "grader" / "test_broken.py").write_text("def test_x(:\n    pass\n")
    empty = tmp_path / "labs" / "empty-01"
    (empty / "grader").mkdir(parents=True)
    (empty / "reference").mkdir()
    (tmp_path / "labs" / "not-a-lab").mkdir()
    return tmp_path / "labs"


# ---------------------------------------------------------------- discovery
def test_discover_and_static_points(fake_labs):
    labs = core.discover_labs(fake_labs)
    assert [l.id for l in labs] == ["broken-01", "empty-01", "toy-01"]
    toy = core.get_lab("toy-01", fake_labs)
    assert toy.title == "Toy lab"
    assert toy.static_points() == {"test_add": 30, "test_sub": 50, "test_unmarked_is_one_point": 1,
                                   "test_fixture_error": 19}
    assert toy.total_points() == 100
    assert core.get_lab("empty-01", fake_labs).title == "empty-01"


def test_unknown_lab_and_missing_dirs(fake_labs, tmp_path):
    with pytest.raises(LabError, match="unknown lab 'nope'.*toy-01"):
        core.get_lab("nope", fake_labs)
    with pytest.raises(LabError, match="labs folder not found"):
        core.discover_labs(tmp_path / "does-not-exist")
    with pytest.raises(LabError, match="solution folder not found"):
        run_lab("toy-01", str(tmp_path / "nowhere"), fake_labs)
    with pytest.raises(LabError, match="has no grader"):
        run_lab("empty-01", "reference", fake_labs)


def test_labs_dir_env_override(fake_labs, monkeypatch):
    monkeypatch.chdir(ROOT)
    monkeypatch.setenv("LABGRADE_LABS_DIR", str(fake_labs))
    assert core.labs_dir() == fake_labs.resolve()
    monkeypatch.delenv("LABGRADE_LABS_DIR")
    assert core.labs_dir() == ROOT / "labs"


def test_labs_dir_lookup_order(fake_labs, tmp_path, monkeypatch):
    other = tmp_path / "other-labs"
    other.mkdir()
    monkeypatch.delenv("LABGRADE_LABS_DIR", raising=False)
    monkeypatch.chdir(tmp_path)  # tmp_path/labs is the fake_labs folder
    assert core.labs_dir() == fake_labs.resolve()                      # ./labs in the current folder
    monkeypatch.setenv("LABGRADE_LABS_DIR", str(other))
    assert core.labs_dir() == other.resolve()                          # env beats ./labs
    assert core.labs_dir(str(fake_labs)) == fake_labs.resolve()        # --labs-dir beats env
    monkeypatch.delenv("LABGRADE_LABS_DIR")
    monkeypatch.chdir(other)                                           # no ./labs here
    assert core.labs_dir() == core.DEFAULT_LABS_DIR == ROOT / "labs"  # next to the package (source checkout)


def test_installed_package_finds_labs_in_current_folder(fake_labs, tmp_path, monkeypatch, capsys):
    # Simulate an installed console script: the package lives in site-packages, which has no labs/ folder.
    monkeypatch.setattr(core, "DEFAULT_LABS_DIR", tmp_path / "site-packages" / "labs")
    monkeypatch.delenv("LABGRADE_LABS_DIR", raising=False)
    monkeypatch.chdir(tmp_path)
    assert cli.main(["list"]) == 0
    assert "toy-01" in capsys.readouterr().out
    elsewhere = tmp_path / "elsewhere"
    elsewhere.mkdir()
    monkeypatch.chdir(elsewhere)
    assert cli.main(["list"]) == 2
    err = capsys.readouterr().err
    assert "labs folder not found" in err and "career-labs folder" in err and "--labs-dir" in err
    assert cli.main(["--labs-dir", str(fake_labs), "list"]) == 0


def test_pyyaml_is_a_required_dependency():
    import re

    text = (ROOT / "pyproject.toml").read_text(encoding="utf-8")
    deps = re.search(r"^dependencies = \[(.*?)\]", text, re.M | re.S).group(1)
    assert "pyyaml" in deps.lower() and "pytest" in deps
    assert "optional-dependencies" not in text


# ---------------------------------------------------------------- grading
def test_reference_and_partial_scores(fake_labs):
    ref = run_lab("toy-01", "reference", fake_labs)
    assert {t.name: t.outcome for t in ref.tests} == {
        "test_add": "passed", "test_sub": "passed", "test_unmarked_is_one_point": "passed",
        "test_fixture_error": "error"}
    assert (ref.score, ref.max_score) == (81, 100)
    assert ref.percent == 81.0 and not ref.crashed

    starter = run_lab("toy-01", "starter", fake_labs)
    by_name = {t.name: t for t in starter.tests}
    assert by_name["test_add"].earned == 30
    assert by_name["test_sub"].outcome == "failed" and by_name["test_sub"].earned == 0
    assert "NotImplementedError: sub" in by_name["test_sub"].message
    assert by_name["test_unmarked_is_one_point"].message == "AssertionError: assert 0 == 1"
    assert by_name["test_add"].description == "add() adds numbers"
    assert starter.score == 30


def test_custom_solution_path_and_only(fake_labs):
    path = fake_labs / "toy-01" / "reference"
    only = run_lab("toy-01", str(path), fake_labs, only="test_sub")
    assert [t.name for t in only.tests] == ["test_sub"]
    assert only.solution == str(path.resolve())
    assert only.score == only.max_score == 50
    assert run_lab("toy-01", "reference", fake_labs, only="test_nope").tests == []


def test_collection_error_is_reported_as_crash(fake_labs):
    result = run_lab("broken-01", "reference", fake_labs)
    assert result.crashed
    assert result.errors and "test_broken.py" in result.errors[0]["nodeid"]
    assert "GRADER ERROR" in format_text(result)


def test_timeout_becomes_lab_error(fake_labs, monkeypatch):
    def boom(*a, **k):
        raise subprocess.TimeoutExpired(cmd="pytest", timeout=1)

    monkeypatch.setattr(core.subprocess, "run", boom)
    with pytest.raises(LabError, match="timed out"):
        run_lab("toy-01", "reference", fake_labs, timeout=1)


def test_missing_report_becomes_lab_error(fake_labs, monkeypatch):
    monkeypatch.setattr(core.subprocess, "run",
                        lambda *a, **k: subprocess.CompletedProcess(a, 4, stdout="boom", stderr=""))
    with pytest.raises(LabError, match="did not produce a report"):
        run_lab("toy-01", "reference", fake_labs)


# ---------------------------------------------------------------- formatting
def _result(outcomes):
    r = LabResult(lab="x", solution="/s")
    for i, (o, pts) in enumerate(outcomes):
        r.tests.append(TestResult(name=f"test_{i}", points=pts, outcome=o, message="boom" if o != "passed" else "",
                                  description=f"check {i}"))
    return r


def test_format_text_and_to_dict():
    full = _result([("passed", 60), ("passed", 40)])
    text = format_text(full, "reference")
    assert "Score: 100/100 points (100%)" in text and "All checks passed" in text
    assert "(solution: reference)" in text and "check 0" in text
    part = _result([("passed", 60), ("failed", 30), ("error", 10)])
    text = format_text(part)
    assert "FAIL" in text and "ERR" in text and "-> boom" in text
    assert "Score: 60/100 points (60%)" in text and "Fix the FAIL and ERR lines" in text
    d = part.to_dict()
    assert d["score"] == 60 and d["max_score"] == 100 and d["passed"] == 1 and d["total_tests"] == 3
    assert d["tests"][1] == {"name": "test_1", "description": "check 1", "points": 30, "earned": 0,
                             "outcome": "failed", "message": "boom"}
    assert LabResult("x", "y").percent == 0.0 and LabResult("x", "y").crashed


# ---------------------------------------------------------------- helpers
def test_helpers_load_solution(tmp_path, monkeypatch):
    lab = tmp_path / "lab"
    (lab / "reference").mkdir(parents=True)
    (lab / "reference" / "mod.py").write_text("X = 42\n")
    (lab / "reference" / "q1.sql").write_text("SELECT 1;")
    custom = tmp_path / "mine"
    custom.mkdir()
    (custom / "mod.py").write_text("X = 7\n")
    monkeypatch.delenv(helpers.ENV_VAR, raising=False)
    assert helpers.solution_dir(lab) == (lab / "reference").resolve()
    assert helpers.load_solution(lab, "mod").X == 42
    assert helpers.solution_file(lab, "q1.sql").read_text() == "SELECT 1;"
    monkeypatch.setenv(helpers.ENV_VAR, str(custom))
    assert helpers.load_solution(lab, "mod").X == 7
    with pytest.raises(FileNotFoundError, match="expected your solution file"):
        helpers.load_solution(lab, "missing")
    with pytest.raises(FileNotFoundError):
        helpers.solution_file(lab, "q2.sql")
    assert helpers.lab_dir_from(lab / "grader" / "test_x.py") == lab.resolve()


def test_classroom_config(fake_labs):
    cfg = core.classroom_config(["toy-01"], "starter", fake_labs)
    assert [t["points"] for t in cfg["tests"]] == [30, 50, 1, 19]
    assert cfg["tests"][0]["run"] == ("python -m labgrade run toy-01 --solution starter --test test_add "
                                      "--fail-under 100")


# ---------------------------------------------------------------- CLI
def test_cli_list(fake_labs, capsys):
    assert cli.main(["--labs-dir", str(fake_labs), "list"]) == 0
    out = capsys.readouterr().out
    assert "toy-01" in out and "Toy lab" in out and "100" in out
    assert cli.main(["--labs-dir", str(fake_labs), "list", "--json"]) == 0
    rows = json.loads(capsys.readouterr().out)
    assert {"id": "toy-01", "title": "Toy lab", "tests": 4, "points": 100} in rows


def test_cli_list_real_labs(capsys):
    assert cli.main(["list", "--json"]) == 0
    rows = json.loads(capsys.readouterr().out)
    assert len(rows) == 6 and all(r["points"] == 100 for r in rows)


def test_cli_run_text_json_and_exit_codes(fake_labs, capsys):
    base = ["--labs-dir", str(fake_labs), "run", "toy-01"]
    assert cli.main(base + ["--solution", "starter"]) == 0
    assert "Score: 30/100" in capsys.readouterr().out
    assert cli.main(base + ["--solution", "starter", "--fail-under", "50"]) == 1
    capsys.readouterr()
    assert cli.main(base + ["--solution", "reference", "--fail-under", "80", "--json"]) == 0
    data = json.loads(capsys.readouterr().out)
    assert data["score"] == 81 and data["lab"] == "toy-01"
    assert cli.main(base + ["--solution", "reference", "--test", "test_add", "--fail-under", "100"]) == 0
    capsys.readouterr()
    assert cli.main(base + ["--test", "test_nope"]) == 2
    assert "no graded test named 'test_nope'" in capsys.readouterr().err


def test_cli_errors(fake_labs, capsys):
    assert cli.main(["--labs-dir", str(fake_labs), "run", "nope"]) == 2
    assert "Error: unknown lab" in capsys.readouterr().err
    assert cli.main(["--labs-dir", str(fake_labs), "run", "toy-01", "--solution", "/no/such/dir"]) == 2
    assert "solution folder not found" in capsys.readouterr().err
    assert cli.main(["--labs-dir", str(fake_labs), "run", "broken-01", "--solution", "reference"]) == 2
    with pytest.raises(SystemExit):
        cli.main([])


def test_cli_classroom(fake_labs, capsys):
    assert cli.main(["--labs-dir", str(fake_labs), "classroom", "toy-01"]) == 0
    cfg = json.loads(capsys.readouterr().out)
    assert len(cfg["tests"]) == 4
    assert cli.main(["--labs-dir", str(fake_labs), "classroom", "nope"]) == 2


def test_python_dash_m_entry_point():
    proc = subprocess.run([sys.executable, "-m", "labgrade", "--version"], cwd=ROOT, capture_output=True, text=True)
    assert proc.returncode == 0 and __version__ in proc.stdout
    proc = subprocess.run([sys.executable, "-m", "labgrade", "list"], cwd=ROOT, capture_output=True, text=True)
    assert proc.returncode == 0 and "de-01-orders-pipeline" in proc.stdout


def test_readme_uses_python3_venv_and_classroom_step():
    text = (ROOT / "README.md").read_text(encoding="utf-8")
    assert "python -m labgrade" not in text and "python3 -m labgrade run" in text
    assert "python3 -m venv .venv" in text and "`py`" in text
    assert "python3 -m labgrade classroom de-01-orders-pipeline > .github/classroom/autograding.json" in text
