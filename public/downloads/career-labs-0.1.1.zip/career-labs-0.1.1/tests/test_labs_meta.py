"""Meta-tests: every lab is consistent, gradable, documented and reproducible."""

import filecmp
import importlib.util
import json
import re
from pathlib import Path

import pytest

from conftest import LAB_IDS, LABS
from labgrade.core import get_lab

LABS_WITH_DATA = [lab.id for lab in LABS if (lab.path / "data" / "generate.py").is_file()]
POINT_ROW = re.compile(r"^\|\s*`(test_\w+)`\s*\|\s*(\d+)\s*\|")
TOTAL_ROW = re.compile(r"^\|\s*\*\*Total\*\*\s*\|\s*\*\*(\d+)\*\*\s*\|")


def _import_path(path: Path, name: str):
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def test_expected_labs_present():
    assert LAB_IDS == [
        "de-01-orders-pipeline", "de-02-sql-interview", "ml-01-mlops-basics",
        "ops-01-incident-drill", "sec-01-log-forensics", "sec-02-secure-code-review",
    ]


@pytest.mark.parametrize("lab_id", LAB_IDS)
def test_lab_structure(lab_id):
    lab = get_lab(lab_id)
    for sub in ("starter", "reference", "grader"):
        assert (lab.path / sub).is_dir(), f"{lab_id} is missing {sub}/"
    assert lab.readme.is_file()
    assert lab.grader_files(), "no grader/test_*.py"
    points = lab.static_points()
    assert 6 <= len(points) <= 12, f"{lab_id} has {len(points)} graded tests (want 6-12)"
    assert sum(points.values()) == 100
    assert all(p > 0 for p in points.values())
    # starter and reference provide the same files
    starter = sorted(p.name for p in (lab.path / "starter").iterdir() if p.is_file())
    reference = sorted(p.name for p in (lab.path / "reference").iterdir() if p.is_file())
    assert starter == reference, f"starter/ and reference/ differ: {starter} vs {reference}"


@pytest.mark.parametrize("lab_id", LAB_IDS)
def test_reference_scores_100(grade, lab_id):
    result = grade(lab_id, "reference")
    failing = [(t.name, t.message) for t in result.tests if t.outcome != "passed"]
    assert not result.crashed, result.errors
    assert failing == []
    assert result.score == result.max_score == 100
    assert result.percent == 100.0


@pytest.mark.parametrize("lab_id", LAB_IDS)
def test_starter_fails_without_crashing_the_grader(grade, lab_id):
    lab = get_lab(lab_id)
    result = grade(lab_id, "starter")
    assert not result.crashed, f"grader crashed on the starter: {result.errors}"
    assert {t.name for t in result.tests} == set(lab.static_points()), "every graded test must be reported"
    assert all(t.outcome in ("passed", "failed", "error") for t in result.tests)
    assert result.max_score == 100
    assert result.percent < 100
    assert all(t.message for t in result.tests if t.outcome != "passed"), "failures need a hint message"


@pytest.mark.parametrize("lab_id", LAB_IDS)
def test_runtime_points_match_static_points(grade, lab_id):
    result = grade(lab_id, "reference")
    assert {t.name: t.points for t in result.tests} == get_lab(lab_id).static_points()


@pytest.mark.parametrize("lab_id", LAB_IDS)
def test_readme_points_table_matches_grader(lab_id):
    lab = get_lab(lab_id)
    text = lab.readme.read_text(encoding="utf-8")
    rows = {m.group(1): int(m.group(2)) for line in text.splitlines() if (m := POINT_ROW.match(line))}
    totals = [int(m.group(1)) for line in text.splitlines() if (m := TOTAL_ROW.match(line))]
    assert rows == lab.static_points(), "README points table is out of date"
    assert totals == [sum(rows.values())] == [lab.total_points()]


@pytest.mark.parametrize("lab_id", LAB_IDS)
def test_readme_explains_how_to_grade(lab_id):
    text = get_lab(lab_id).readme.read_text(encoding="utf-8")
    assert text.startswith("# ")
    assert f"python -m labgrade run {lab_id}" in text
    assert "## Scenario" in text and "## Your task" in text


@pytest.mark.parametrize("lab_id", LAB_IDS)
def test_starter_python_files_import(lab_id):
    lab = get_lab(lab_id)
    for path in sorted((lab.path / "starter").glob("*.py")):
        _import_path(path, f"_starter_{lab_id.replace('-', '_')}_{path.stem}")


@pytest.mark.parametrize("lab_id", LABS_WITH_DATA)
def test_data_is_deterministic(lab_id, tmp_path):
    lab = get_lab(lab_id)
    gen = _import_path(lab.path / "data" / "generate.py", f"_gen_{lab_id.replace('-', '_')}")
    first = gen.generate(tmp_path / "a")
    second = gen.generate(tmp_path / "b")
    assert first, "generator produced no files"
    for f1, f2 in zip(first, second):
        assert f1.read_bytes() == f2.read_bytes(), f"{f1.name} differs between two runs"
        committed = lab.path / "data" / f1.name
        assert committed.is_file(), f"{committed} is not committed"
        assert filecmp.cmp(f1, committed, shallow=False), f"committed {f1.name} is stale: rerun generate.py"


def test_every_lab_except_code_review_has_data():
    assert set(LAB_IDS) - set(LABS_WITH_DATA) == {"sec-02-secure-code-review"}


@pytest.mark.parametrize("lab_id", ["de-01-orders-pipeline", "de-02-sql-interview"])
def test_expected_json_matches_independent_oracle(lab_id):
    lab = get_lab(lab_id)
    oracle = _import_path(lab.path / "grader" / "make_expected.py", f"_oracle_{lab_id.replace('-', '_')}")
    committed = json.loads((lab.path / "grader" / "expected.json").read_text(encoding="utf-8"))
    fresh = oracle.compute(lab.path / "data") if lab_id.startswith("de-01") else oracle.compute()
    assert json.loads(json.dumps(fresh)) == committed


def test_sec02_starter_is_actually_exploitable(grade):
    """The vulnerable starter must fail the exploit checks but pass the normal-behaviour checks."""
    result = {t.name: t.outcome for t in grade("sec-02-secure-code-review", "starter").tests}
    assert result["test_find_user_normal"] == "passed"
    assert result["test_verify_password"] == "passed"
    for exploit in ["test_find_user_sql_injection", "test_search_products_sql_injection",
                    "test_safe_join_blocks_traversal", "test_session_no_pickle", "test_config_safe_yaml"]:
        assert result[exploit] == "failed", exploit


def test_ops01_starter_config_is_broken_and_reference_is_valid():
    lab = get_lab("ops-01-incident-drill")
    check = _import_path(lab.path / "provided" / "configcheck.py", "_configcheck_meta")
    assert check.validate_file(lab.path / "reference" / "service.yaml") == []
    problems = check.validate_file(lab.path / "starter" / "service.yaml")
    assert len(problems) == 8
    assert any("8080" in p for p in problems) and any("/health" in p for p in problems)
    assert check.validate_service_config("not a dict") == ["config must be a YAML mapping"]
    assert check.cpu_millicores("500m") == 500 and check.cpu_millicores("1.5") == 1500
    assert check.cpu_millicores("2 cores") is None
    assert check.memory_mib("1Gi") == 1024 and check.memory_mib("256MB") is None
