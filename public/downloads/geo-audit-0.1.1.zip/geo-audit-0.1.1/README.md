# geo-audit

Find out if ChatGPT, Claude, Perplexity and Gemini recommend a local business when customers ask
"best dentist in Fresno?". You get a white-label report (HTML you can print to PDF) to send to prospects:
the business's score, which competitors the AIs name instead, which websites they trust, and what to fix.

Free and open source (MIT). Python 3.10+, no extra packages needed.

## Install

```bash
git clone <this repo> && cd geo-audit
python3 -m pip install .
```

(Or run without installing: `PYTHONPATH=src python3 -m geo_audit ...`)

## Try it free (no API keys)

The `fake` AI gives made-up but realistic answers so you can see the report:

```bash
geo-audit run --business "Smile Dental" --city "Fresno, CA" --category dentist \
  --website smiledental.com --providers fake,fake-gemini,fake-claude -o demo.html
```

Open `demo.html` in your browser. To make a PDF: File > Print > Save as PDF.
Demo reports carry a "Demo data: these answers are made up..." banner at the top (and `"demo": true` in JSON),
so nobody mistakes them for a real audit.

## Real audit

Add the API key of each AI tool you want to check (one is enough):

```bash
export OPENAI_API_KEY=sk-...          # ChatGPT
export ANTHROPIC_API_KEY=sk-ant-...   # Claude
export PERPLEXITY_API_KEY=pplx-...    # Perplexity
export GEMINI_API_KEY=...             # Gemini
```

Then:

```bash
geo-audit run --business "Smile Dental" --city "Fresno, CA" --category dentist \
  --website smiledental.com -o report.html \
  --brand-name "Your Agency" --brand-color "#0f766e" \
  --logo-url https://youragency.com/logo.png --agency-contact "you@agency.com | (555) 123-4567"
```

Every AI tool whose key is set is used. Pick some with `--providers openai,perplexity`.
If you pick an AI tool whose key is not set, geo-audit stops before asking anything and writes no report.
Cost: 10 questions per AI tool, so 40 short API calls for all four.

### Useful options

| Option | What it does |
|---|---|
| `--competitor "Valley Dental Care"` | a competitor you already know (repeat it, or use `--competitors "A;B"`) |
| `--question "Who does Invisalign in Fresno?"` | add your own question (repeat for more) |
| `--questions-file my_questions.txt` | use your own questions instead (see `examples/questions.txt`) |
| `--max-questions 12` | how many built-in questions to ask (default 10) |
| `--format json\|md\|csv` | other formats (also picked from the `-o` file name) |
| `--web-search` | let Claude and Gemini search the web before answering (Perplexity always does) |
| `--openai-model`, `--anthropic-model`, `--perplexity-model`, `--gemini-model` | change models |
| `--threshold 0.9` | how strict name matching is (0.5 to 1.0) |

See the questions before paying for anything:

```bash
geo-audit questions --business "Smile Dental" --city "Fresno, CA" --category dentist
```

Re-brand a saved audit without asking the AIs again (save it with `-o audit.json` first):

```bash
geo-audit report audit.json -o for-partner.html --brand-name "Partner Agency"
```

## 50 prospects at once

Make a CSV with columns `business,city,category,website` (optional `competitors`, separated by `;`).
See `examples/prospects.csv`.

```bash
geo-audit batch examples/prospects.csv -o reports/ --brand-name "Your Agency"
```

You get one report per business, plus `reports/summary.csv` sorted with the **lowest AI visibility first**:
those are the businesses that need help most, so contact them first. Rows with problems are skipped and listed.
CSVs saved by Excel as plain "CSV" work too. If you get an encoding error, save the file as "CSV UTF-8".

## Example output

From the free demo above (`--providers fake,fake-gemini,fake-claude`, made-up answers):

```
Asking Demo AI (fake) (10 questions)...
Asking Demo AI (gemini) (10 questions)...
Asking Demo AI (claude) (10 questions)...
Smile Dental: 58.3% AI visibility (grade B), mentioned in 14 of 24 answers. Report saved to demo.html
```

The report shows:

- **Headline score**: % of customer questions where the AI named the business, plus a grade (A to F).
- **Score per AI tool**: ChatGPT vs Claude vs Perplexity vs Gemini.
- **What to do next**: plain-English steps, e.g. "Get listed and reviewed on yelp.com and healthgrades.com",
  "Make your website easy for AI to quote (FAQ page + schema)", "You only show up on Perplexity".
- **Who AI recommends**: competitor leaderboard with average list position.
- **Websites the AI tools used as sources**: review sites, your site, others.
- **Question by question**: each AI's answer (shortened), whether you were named and at what spot.
- **How this was measured**, with the date.

## How it measures

- 10 questions by default: 8 that a new customer would ask (best, most trusted, open on weekends,
  affordable, top rated...) and 2 that name the business (to see if the AI knows it at all).
- The score only counts the 8 questions that **don't** name the business.
- A business counts as **mentioned** if its name is in the answer. Case, punctuation, "&" vs "and" and
  endings like LLC, Inc, Group or Clinic don't matter, and small typos are allowed. Part of the name is not
  enough: "Smile" alone doesn't count for "Smile Dental", and neither does "Big Smile Dental".
  The business's website in the answer also counts.
- **Position** is the business's spot when the answer is a numbered or bulleted list.
- **Competitors** are the other names in list items and bold text, plus your known competitors.
- **Sources** are links in the answer plus the citations the AI tool returns (Perplexity, Gemini with
  `--web-search`, Claude with `--web-search`, OpenAI search models), grouped by website.
- **Share of voice** is your mentions divided by your mentions plus your top 5 competitors' mentions.
- If one AI tool fails (bad key, outage), the others still run and the report says what failed.
  Calls are retried twice on rate limits (429) and server errors (5xx), with a 60-second timeout.

## Limits (be honest with clients)

- AI answers change by day, by account and by location. This is a snapshot, not a ranking guarantee.
- The answers come from the APIs, which are not identical to the ChatGPT / Perplexity / Gemini / Claude apps
  people use (the apps add personalization, the user's location and different search settings). The report
  says this in its "How this was measured" section. Use `--web-search` and search-capable models to get closer.
- Name matching is a heuristic. Very generic names ("Dental Care") can match other businesses; adjust
  `--threshold` or check the question-by-question section.
- Competitor names are pulled from list items and bold text; names written in plain sentences are only
  found if you pass them with `--competitor`.

## API details: verify against current docs

All endpoint URLs, headers, default model names and response field names live in one file:
[`src/geo_audit/constants.py`](src/geo_audit/constants.py). They were written from the providers' public
docs and **were not tested against the live APIs** (the tests never use the network).
Verify them against current docs before relying on the tool, in particular:

- OpenAI: `POST /v1/chat/completions`, reply in `choices[0].message.content`, web citations in
  `message.annotations[].url_citation` (search models only). Default model `gpt-4o-mini`.
- Anthropic: `POST /v1/messages` with `x-api-key` and `anthropic-version: 2023-06-01`, text in `content[]`
  blocks, citations in `content[].citations[].url`; web search tool type `web_search_20250305`.
  Default model `claude-sonnet-5-5`.
- Perplexity: `POST https://api.perplexity.ai/chat/completions`, model `sonar`, sources in top-level
  `citations` and `search_results`.
- Gemini: `POST /v1beta/models/{model}:generateContent` with `x-goog-api-key`, text in
  `candidates[0].content.parts[].text`, sources in `candidates[0].groundingMetadata.groundingChunks[].web`.
  Default model `gemini-2.5-flash`.

## For developers

```bash
python3 -m pytest -q      # needs pytest; no network, no keys, no sleeping
```

Code map: `questions.py` (templates), `providers.py` + `transport.py` (API calls, retries),
`matching.py` + `extract.py` + `analysis.py` (reading answers), `scoring.py`, `recommendations.py`,
`report.py` (HTML/JSON/MD/CSV), `batch.py`, `cli.py`. A Claude skill is in `skills/geo-audit/SKILL.md`.

Exit codes: `0` OK, `1` nothing could be measured (or some batch rows failed), `2` bad input, unreadable file
or a chosen AI tool has no API key (nothing is asked and no report is written).
