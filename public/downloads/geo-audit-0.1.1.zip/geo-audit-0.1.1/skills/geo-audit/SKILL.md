---
name: geo-audit
description: Run an AI-search visibility (GEO) audit for a local business. Asks ChatGPT, Claude, Perplexity and Gemini the questions customers ask ("best dentist in Fresno"), checks if the business is mentioned, which competitors and sources the AIs use, and writes a white-label HTML/PDF report with next steps. Use when someone wants a GEO/AEO audit, an "AI visibility" report, a lead-magnet audit for a prospect, or to audit a CSV list of local businesses.
---

# geo-audit

Use the `geo-audit` command line tool (Python 3.10+, no extra packages).
If `geo-audit` is not installed, run it from the project folder with `PYTHONPATH=src python3 -m geo_audit`.

## 1. Collect the inputs

Ask the user for anything missing:

- business name (exact, as on Google), city with state ("Fresno, CA"), category ("dentist", "plumber", "med spa")
- website domain (optional but recommended)
- known competitors (optional)
- agency branding (optional): brand name, hex color, logo URL, contact line

## 2. Check which AI tools are available

The tool uses every AI whose key is set: `OPENAI_API_KEY`, `ANTHROPIC_API_KEY`, `PERPLEXITY_API_KEY`,
`GEMINI_API_KEY`. Check with `env | grep -E 'OPENAI|ANTHROPIC|PERPLEXITY|GEMINI' | cut -d= -f1`
(never print key values). If none are set, offer the free demo with `--providers fake`
and say clearly that demo answers are made up.

Optionally preview the questions (free, no API calls):

```bash
geo-audit questions --business "Smile Dental" --city "Fresno, CA" --category dentist
```

## 3. Run the audit

```bash
geo-audit run --business "Smile Dental" --city "Fresno, CA" --category dentist \
  --website smiledental.com --competitor "Valley Dental Care" \
  --brand-name "Acme Agency" --brand-color "#0f766e" --agency-contact "hi@acme.com" \
  -o smile-dental-report.html
```

Also save JSON if the user may want to re-brand later: run again with `-o audit.json`, or re-render
an existing JSON with `geo-audit report audit.json -o report.html --brand-name "Other Agency"`.

For a list of prospects (CSV columns `business,city,category,website`, optional `competitors` with `;`):

```bash
geo-audit batch prospects.csv -o reports/ --brand-name "Acme Agency"
```

`reports/summary.csv` is sorted lowest visibility first (best prospects first).

## 4. Report back

Tell the user, in plain English:

- the headline score and grade, and which AI tools mention the business
- the top 3 competitors the AIs named instead
- the top 3 recommendations from the report
- the report file path, and that File > Print > Save as PDF makes the PDF
- any AI tool that failed (the report lists the error; usually a wrong or missing key)

Exit codes: 0 OK, 1 nothing measured / some batch rows failed, 2 bad input or no API key.

## Caveats to mention

AI answers vary by day, account and location, so the report is a snapshot. API answers can differ from
the consumer apps. Endpoint and field names live in `src/geo_audit/constants.py` and should be checked
against each provider's current docs.
