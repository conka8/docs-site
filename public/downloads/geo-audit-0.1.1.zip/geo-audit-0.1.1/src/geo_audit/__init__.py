"""geo-audit: does ChatGPT / Claude / Perplexity / Gemini recommend this local business?"""

__version__ = "0.1.1"
