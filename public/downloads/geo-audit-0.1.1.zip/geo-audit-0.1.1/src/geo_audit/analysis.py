"""Analyse one AI answer: mentioned? where in the list? which competitors? which sources?"""

from __future__ import annotations

import re
from dataclasses import asdict, dataclass, field

from .extract import bold_names, extract_bare_domains, extract_urls, list_items, url_domain
from .matching import (
    DEFAULT_THRESHOLD,
    core_name,
    core_tokens,
    domain_matches,
    find_in_text,
    names_match,
    normalize_domain,
    tokenize,
)

# Phrases that show the AI doesn't actually know the business (used on brand questions).
UNKNOWN_PHRASES = (
    "don't have specific information",
    "do not have specific information",
    "don't have information",
    "do not have information",
    "not familiar with",
    "couldn't find",
    "could not find",
    "no information about",
    "unable to find",
    "i'm not aware of",
    "i am not aware of",
    "don't have any information",
    "don't have details",
)


@dataclass
class Analysis:
    mentioned: bool = False
    match: str = ""  # "exact" | "fuzzy" | "list" | "domain" | ""
    matched_text: str = ""
    domain_mentions: int = 0
    position: int | None = None
    list_size: int = 0
    competitors: list[str] = field(default_factory=list)
    competitor_positions: dict = field(default_factory=dict)
    sources: list[str] = field(default_factory=list)
    domains: list[str] = field(default_factory=list)
    website_cited: bool = False
    unknown: bool = False

    def to_dict(self) -> dict:
        return asdict(self)


def _is_generic(name: str, city: str, category: str) -> bool:
    """'Fresno', 'Dentist', 'Fresno Dentists' are not businesses."""
    toks = set(tokenize(name))
    place = set(tokenize(city)) | set(tokenize(category))
    place |= {t + "s" for t in tokenize(category)} | {"best", "top", "rated", "near", "me", "in", "the", "and"}
    return bool(toks) and toks <= place


def business_matcher(business: str, city: str = "", threshold: float = DEFAULT_THRESHOLD):
    """Return ``is_business(name)`` that also accepts a trailing location: "Smile Dental of Fresno"."""
    place = set(tokenize(city)) | {"of", "in", "at"}

    def is_business(name: str) -> bool:
        if names_match(name, business, threshold):
            return True
        toks = core_tokens(name)
        trimmed = list(toks)
        while len(trimmed) > 1 and trimmed[-1] in place:
            trimmed.pop()
        return trimmed != toks and names_match(" ".join(trimmed), business, threshold)

    return is_business


def _mask(text: str, names: list[str]) -> str:
    """Blank out other businesses' names so "Big Smile Dental" can't count as "Smile Dental"."""
    for n in sorted(set(names), key=len, reverse=True):
        if n:
            text = re.sub(re.escape(n), " ", text, flags=re.IGNORECASE)
    return text


def find_competitors(
    text: str,
    business: str,
    *,
    known: list[str] | None = None,
    city: str = "",
    category: str = "",
    threshold: float = DEFAULT_THRESHOLD,
    items: list[str] | None = None,
) -> list[str]:
    """Other businesses named in the answer: list items, bold names, and known competitors. Deduped."""
    found: list[str] = []
    is_business = business_matcher(business, city, threshold)

    def add(name: str) -> None:
        if not name or is_business(name) or _is_generic(name, city, category):
            return
        for i, existing in enumerate(found):
            if names_match(existing, name, threshold):
                return
        found.append(name)

    for k in known or []:
        if find_in_text(text, k, threshold):
            add(k)
    for n in (items if items is not None else list_items(text)) + bold_names(text):
        # prefer the spelling from the known list
        canonical = next((k for k in known or [] if names_match(k, n, threshold)), n)
        add(canonical)
    return found


def analyze_answer(
    text: str,
    business: str,
    *,
    website: str = "",
    citations: list[str] | None = None,
    known_competitors: list[str] | None = None,
    city: str = "",
    category: str = "",
    threshold: float = DEFAULT_THRESHOLD,
    brand_question: bool = False,
) -> Analysis:
    text = text or ""
    a = Analysis()
    target_domain = normalize_domain(website)

    is_business = business_matcher(business, city, threshold)
    items = list_items(text, keep=is_business)
    a.list_size = len(items)
    for i, name in enumerate(items, 1):
        if is_business(name):
            a.mentioned, a.match, a.matched_text = True, "list", name
            if len(items) >= 2:
                a.position = i
            break

    other_names = [n for n in items + bold_names(text) if not is_business(n)]
    # website domain mentions in the text
    text_domains = extract_bare_domains(text)
    if target_domain:
        a.domain_mentions = sum(
            1 for m in re.finditer(r"[a-z0-9.-]+\.[a-z]{2,}", text.lower()) if domain_matches(m.group(0), target_domain)
        )

    # order of evidence: listed by name > named in prose > website named > fuzzy name
    if not a.mentioned:
        hit = find_in_text(_mask(text, other_names), business, threshold)
        if hit and hit[0] == "exact":
            a.mentioned, a.match, a.matched_text = True, hit[0], hit[1]
        elif a.domain_mentions:
            a.mentioned, a.match, a.matched_text = True, "domain", target_domain
        elif hit:
            a.mentioned, a.match, a.matched_text = True, hit[0], hit[1]

    # sources: provider citations + URLs in the text + bare domains
    sources: list[str] = []
    for u in list(citations or []) + extract_urls(text):
        if u and u not in sources:
            sources.append(u)
    a.sources = sources
    domains: list[str] = []
    for d in [url_domain(u) for u in sources] + text_domains:
        if d and d not in domains:
            domains.append(d)
    a.domains = domains
    if target_domain:
        a.website_cited = any(domain_matches(u, target_domain) for u in citations or []) or any(
            domain_matches(u, target_domain) for u in extract_urls(text)
        )

    a.competitors = find_competitors(
        text, business, known=known_competitors, city=city, category=category, threshold=threshold, items=items
    )
    if len(items) >= 2:
        for i, name in enumerate(items, 1):
            for c in a.competitors:
                if c not in a.competitor_positions and names_match(c, name, threshold):
                    a.competitor_positions[c] = i
    if brand_question:
        low = text.lower().replace("’", "'")
        a.unknown = (not text.strip()) or any(p in low for p in UNKNOWN_PHRASES)
    return a


def competitor_key(name: str) -> str:
    """Grouping key for the leaderboard."""
    return core_name(name) or " ".join(core_tokens(name))
