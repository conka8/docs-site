"""Run the audit: ask every question to every provider, analyse, score, recommend."""

from __future__ import annotations

import datetime as _dt
import time
from dataclasses import dataclass, field
from typing import Callable

from . import __version__
from .analysis import analyze_answer
from .matching import DEFAULT_THRESHOLD, normalize_domain
from .providers import FakeProvider, Provider
from .questions import generate_questions, question_kind
from .recommendations import build_recommendations
from .scoring import compute_scores


@dataclass
class AuditInput:
    business: str
    city: str
    category: str
    website: str = ""
    competitors: list[str] = field(default_factory=list)
    questions: list[str] | None = None  # None -> generated from templates
    extra_questions: list[str] = field(default_factory=list)
    max_questions: int = 10
    threshold: float = DEFAULT_THRESHOLD

    def validate(self) -> None:
        for label in ("business", "city", "category"):
            if not (getattr(self, label) or "").strip():
                raise ValueError(f"{label} is required")
        if not 0.5 <= self.threshold <= 1.0:
            raise ValueError("match threshold must be between 0.5 and 1.0")

    def resolved_questions(self) -> list[str]:
        if self.questions:
            return list(self.questions)
        return generate_questions(
            self.business, self.city, self.category, extra=self.extra_questions, max_questions=self.max_questions
        )


Progress = Callable[[str], None]


def run_audit(
    inp: AuditInput,
    providers: list[Provider],
    *,
    progress: Progress | None = None,
    now: _dt.datetime | None = None,
    clock: Callable[[], float] = time.monotonic,
) -> dict:
    """Ask, analyse and score. Never raises because of a provider: failures go into the rows."""
    inp.validate()
    if not providers:
        raise ValueError("no AI providers to ask")
    questions = inp.resolved_questions()
    say = progress or (lambda _msg: None)
    rows: list[dict] = []
    for p in providers:
        say(f"Asking {p.label} ({len(questions)} questions)...")
        for q in questions:
            kind = question_kind(q, inp.business)
            row = {
                "question": q,
                "kind": kind,
                "provider": p.name,
                "label": p.label,
                "model": p.model,
                "text": "",
                "citations": [],
                "error": None,
                "seconds": 0.0,
            }
            start = clock()
            try:
                ans = p.ask(q)
                row["text"] = ans.text
                row["citations"] = [c.to_dict() for c in ans.citations]
            except Exception as e:  # one failing provider/question must not kill the run
                row["error"] = str(e) or e.__class__.__name__
                say(f"  ! {p.label}: {row['error']}")
            row["seconds"] = round(clock() - start, 2)
            row["analysis"] = analyze_answer(
                row["text"],
                inp.business,
                website=inp.website,
                citations=[c["url"] for c in row["citations"]],
                known_competitors=inp.competitors,
                city=inp.city,
                category=inp.category,
                threshold=inp.threshold,
                brand_question=kind == "brand",
            ).to_dict()
            rows.append(row)
    provider_info = [{"name": p.name, "label": p.label, "model": p.model} for p in providers]
    scores = compute_scores(rows, provider_info, inp.business, inp.website, inp.threshold)
    when = now or _dt.datetime.now(_dt.timezone.utc)
    result = {
        "tool": "geo-audit",
        "version": __version__,
        "generated_at": when.isoformat(timespec="seconds"),
        "business": inp.business.strip(),
        "city": inp.city.strip(),
        "category": inp.category.strip(),
        "website": normalize_domain(inp.website),
        "competitors": list(inp.competitors),
        "questions": [{"text": q, "kind": question_kind(q, inp.business)} for q in questions],
        "providers": provider_info,
        "demo": any(isinstance(p, FakeProvider) for p in providers),
        "rows": rows,
        "scores": scores,
    }
    result["recommendations"] = build_recommendations(result)
    return result
