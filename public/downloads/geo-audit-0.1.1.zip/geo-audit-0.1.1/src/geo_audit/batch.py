"""Audit a whole prospect list from a CSV: one report per business plus a summary sorted by
lowest visibility first (the businesses that need help most = the best prospects)."""

from __future__ import annotations

import csv
import io
import re
from pathlib import Path
from typing import Callable

from .audit import AuditInput, run_audit
from .providers import Provider
from .questions import fill_placeholders
from .report import Branding, render

REQUIRED_COLUMNS = ("business", "city", "category")
COLUMN_ALIASES = {"name": "business", "business_name": "business", "company": "business",
                  "domain": "website", "url": "website", "site": "website", "niche": "category",
                  "industry": "category", "location": "city"}
SUMMARY_FIELDS = (
    "rank", "business", "city", "category", "website", "visibility", "grade", "avg_position",
    "share_of_voice", "top_competitor", "report_file", "status", "error",
)


class BatchError(ValueError):
    """The prospects file itself is unusable."""


def slugify(text: str, max_len: int = 50) -> str:
    s = re.sub(r"[^a-z0-9]+", "-", (text or "").lower()).strip("-")
    return (s[:max_len].strip("-")) or "business"


def _decode_csv(data: bytes, p: Path) -> str:
    """UTF-8 first; then Windows-1252, which is what Excel's plain "CSV" save uses on Windows."""
    for encoding in ("utf-8-sig", "cp1252"):
        try:
            return data.decode(encoding)
        except UnicodeDecodeError:
            continue
    raise BatchError(f'can\'t read {p}: unknown text encoding. In Excel use File > Save As > "CSV UTF-8" and try again')


def read_prospects(path: str | Path) -> list[dict]:
    """Read the CSV. Header names are case-insensitive; 'name'/'domain'/... aliases are accepted."""
    p = Path(path)
    try:
        data = p.read_bytes()
    except OSError as e:
        raise BatchError(f"can't read {p}: {e.strerror or e}") from e
    raw = _decode_csv(data, p)
    reader = csv.DictReader(io.StringIO(raw))
    if not reader.fieldnames:
        raise BatchError(f"{p} is empty")
    mapping = {}
    for f in reader.fieldnames:
        key = (f or "").strip().lower().replace(" ", "_")
        mapping[f] = COLUMN_ALIASES.get(key, key)
    missing = [c for c in REQUIRED_COLUMNS if c not in mapping.values()]
    if missing:
        raise BatchError(f"{p} is missing column(s): {', '.join(missing)} (need business,city,category[,website])")
    rows = []
    for i, rec in enumerate(reader, start=2):
        row = {"line": i}
        for f, v in rec.items():
            if f is None:
                continue
            row[mapping[f]] = (v or "").strip()
        if not any(row.get(c) for c in ("business", "city", "category", "website")):
            continue  # blank line
        rows.append(row)
    return rows


def _sort_key(item: dict):
    measured = item["status"] == "ok" and item["visibility"] != ""
    return (0 if measured else 1, float(item["visibility"]) if measured else 0.0, item["business"].lower())


def run_batch(
    prospects: list[dict],
    outdir: str | Path,
    make_providers: Callable[[dict], list[Provider]],
    *,
    fmt: str = "html",
    branding: Branding | None = None,
    max_questions: int = 10,
    threshold: float | None = None,
    questions: list[str] | None = None,
    progress: Callable[[str], None] | None = None,
) -> list[dict]:
    """Audit every row, keep going on errors, write ``summary.csv``. Returns the sorted summary rows."""
    out = Path(outdir)
    out.mkdir(parents=True, exist_ok=True)
    say = progress or (lambda _m: None)
    summary: list[dict] = []
    used_names: set[str] = set()
    for idx, row in enumerate(prospects, 1):
        business = row.get("business", "")
        item = {k: "" for k in SUMMARY_FIELDS}
        item.update({k: row.get(k, "") for k in ("business", "city", "category", "website")})
        say(f"[{idx}/{len(prospects)}] {business or '(no name)'}")
        try:
            missing = [c for c in REQUIRED_COLUMNS if not row.get(c)]
            if missing:
                raise ValueError(f"line {row.get('line', '?')}: missing {', '.join(missing)}")
            comps = [c.strip() for c in re.split(r"[;|]", row.get("competitors", "")) if c.strip()]
            inp = AuditInput(
                business=business,
                city=row["city"],
                category=row["category"],
                website=row.get("website", ""),
                competitors=comps,
                max_questions=max_questions,
                questions=[fill_placeholders(q, business, row["city"], row["category"]) for q in questions]
                if questions
                else None,
            )
            if threshold is not None:
                inp.threshold = threshold
            result = run_audit(inp, make_providers(row), progress=say)
            name = slugify(f"{business}-{row['city']}")
            base, n = name, 2
            while name in used_names:
                name, n = f"{base}-{n}", n + 1
            used_names.add(name)
            filename = f"{name}.{fmt}"
            (out / filename).write_text(render(result, fmt, branding), encoding="utf-8")
            s = result["scores"]
            rivals = [e for e in s["leaderboard"] if not e["is_business"]]
            item.update(
                {
                    "visibility": "" if s["visibility"] is None else s["visibility"],
                    "grade": s["grade"],
                    "avg_position": "" if s["avg_position"] is None else s["avg_position"],
                    "share_of_voice": "" if s["share_of_voice"] is None else s["share_of_voice"],
                    "top_competitor": rivals[0]["name"] if rivals else "",
                    "report_file": filename,
                    "status": "ok" if s["visibility"] is not None else "no answers",
                    "error": "" if s["visibility"] is not None else "every AI call failed",
                }
            )
        except Exception as e:  # keep going: one bad row must not stop the batch
            item.update({"status": "error", "error": str(e) or e.__class__.__name__})
            say(f"  ! skipped: {item['error']}")
        summary.append(item)
    summary.sort(key=_sort_key)
    for i, item in enumerate(summary, 1):
        item["rank"] = i
    with open(out / "summary.csv", "w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=SUMMARY_FIELDS, lineterminator="\n")
        w.writeheader()
        w.writerows(summary)
    return summary
