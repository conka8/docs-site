"""Command line: geo-audit run | batch | questions | report.

Exit codes: 0 = OK, 1 = ran but nothing could be measured (or some batch rows failed),
2 = bad input / setup problem (missing keys, unreadable file, bad option).
"""

from __future__ import annotations

import argparse
import json
import os
import re
import sys
from pathlib import Path
from typing import Mapping, TextIO

from . import __version__
from . import constants as C
from .audit import AuditInput, run_audit
from .batch import BatchError, read_prospects, run_batch, slugify
from .matching import DEFAULT_THRESHOLD
from .providers import available_providers, build_providers, load_fake_answers, parse_provider_list
from .questions import QuestionsError, generate_questions, load_questions_file
from .report import FORMATS, Branding, format_from_path, render, valid_color
from .transport import Sleep, Transport

EXIT_OK, EXIT_NOTHING, EXIT_USAGE = 0, 1, 2

NO_PROVIDER_HELP = (
    "No AI tools to ask. Set at least one API key, for example:\n"
    "  export OPENAI_API_KEY=sk-...        (ChatGPT)\n"
    "  export ANTHROPIC_API_KEY=sk-ant-... (Claude)\n"
    "  export PERPLEXITY_API_KEY=pplx-...  (Perplexity)\n"
    "  export GEMINI_API_KEY=...           (Gemini)\n"
    "or try a free demo with: --providers fake"
)


class UsageError(Exception):
    pass


def _add_provider_args(p: argparse.ArgumentParser) -> None:
    g = p.add_argument_group("AI tools")
    g.add_argument("--providers", help="comma list: openai,anthropic,perplexity,gemini,fake "
                   "(default: every tool whose API key is set)")
    for name in C.REAL_PROVIDERS:
        g.add_argument(f"--{name}-model", dest=f"{name}_model", metavar="MODEL",
                       help=f"model for {name} (default {C.DEFAULT_MODELS[name]})")
    g.add_argument("--web-search", action="store_true",
                   help="let Claude and Gemini search the web (Perplexity always does)")
    g.add_argument("--timeout", type=float, default=C.HTTP_TIMEOUT_SECONDS, help="seconds per AI call (default 60)")
    g.add_argument("--fake-answers", metavar="FILE", help="JSON file of canned answers for the fake provider")


def _add_question_args(p: argparse.ArgumentParser) -> None:
    g = p.add_argument_group("questions")
    g.add_argument("--questions-file", metavar="FILE",
                   help="use these questions instead of the built-in ones (.txt one per line, or .json list)")
    g.add_argument("--max-questions", type=int, default=10, help="how many built-in questions to ask (default 10)")
    g.add_argument("--threshold", type=float, default=DEFAULT_THRESHOLD,
                   help=f"name match strictness 0.5-1.0 (default {DEFAULT_THRESHOLD})")


def _add_output_args(p: argparse.ArgumentParser, *, single: bool = True) -> None:
    g = p.add_argument_group("report")
    if single:
        g.add_argument("-o", "--output", help="output file (default <business>-ai-visibility.html; '-' = print)")
    g.add_argument("--format", choices=FORMATS, help="html (default), json, md or csv; guessed from -o extension")
    g.add_argument("--brand-name", default="", help="your agency name, shown on the report")
    g.add_argument("--brand-color", default="", help="hex color like #0f766e")
    g.add_argument("--logo-url", default="", help="https:// link to your logo")
    g.add_argument("--agency-contact", default="", help="contact line, e.g. 'hello@agency.com | (555) 123-4567'")
    g.add_argument("-q", "--quiet", action="store_true", help="no progress messages")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="geo-audit",
        description="Check if ChatGPT, Claude, Perplexity and Gemini recommend a local business, "
        "and make a white-label report.",
    )
    parser.add_argument("--version", action="version", version=f"geo-audit {__version__}")
    sub = parser.add_subparsers(dest="command", metavar="COMMAND")

    run = sub.add_parser("run", help="audit one business")
    run.add_argument("--business", required=True, help='business name, e.g. "Smile Dental"')
    run.add_argument("--city", required=True, help='e.g. "Fresno, CA"')
    run.add_argument("--category", required=True, help="e.g. dentist, plumber, med spa")
    run.add_argument("--website", default="", help="e.g. smiledental.com")
    run.add_argument("--competitor", action="append", default=[], help="known competitor (repeat for more)")
    run.add_argument("--competitors", default="", help='known competitors separated by ";"')
    run.add_argument("--question", action="append", default=[], help="extra question to ask (repeat for more)")
    _add_question_args(run)
    _add_provider_args(run)
    _add_output_args(run)

    batch = sub.add_parser("batch", help="audit every business in a CSV (business,city,category,website)")
    batch.add_argument("csv", help="prospects CSV file")
    batch.add_argument("-o", "--outdir", default="geo-audit-reports", help="folder for reports (default geo-audit-reports)")
    _add_question_args(batch)
    _add_provider_args(batch)
    _add_output_args(batch, single=False)

    q = sub.add_parser("questions", help="show the questions that would be asked (no AI calls, free)")
    q.add_argument("--business", required=True)
    q.add_argument("--city", required=True)
    q.add_argument("--category", required=True)
    q.add_argument("--max-questions", type=int, default=10)

    rep = sub.add_parser("report", help="re-render a saved JSON audit (e.g. with different branding)")
    rep.add_argument("json_file", help="file written with --format json")
    _add_output_args(rep)
    return parser


def _branding(args) -> Branding:
    if args.brand_color and not valid_color(args.brand_color):
        raise UsageError(f"--brand-color must be a hex color like #0f766e (got {args.brand_color!r})")
    if args.logo_url and not args.logo_url.lower().startswith(("https://", "http://", "data:image/")):
        raise UsageError("--logo-url must start with https://")
    return Branding(args.brand_name, args.brand_color or "#2563eb", args.logo_url, args.agency_contact)


def _provider_names(args, env: Mapping[str, str]) -> list[str]:
    try:
        names = parse_provider_list(args.providers)
    except ValueError as e:
        raise UsageError(str(e)) from e
    if not names:
        names = available_providers(env)
    if not names:
        raise UsageError(NO_PROVIDER_HELP)
    # stop before asking anything (and before writing a report) if a chosen AI tool has no key
    missing = [n for n in names if n in C.PROVIDER_ENV and not (env.get(C.PROVIDER_ENV[n]) or "").strip()]
    if missing:
        labels = ", ".join(C.PROVIDER_LABELS.get(n, n) for n in missing)
        lines = [f"  export {C.PROVIDER_ENV[n]}=..." for n in missing]
        raise UsageError(
            f"no API key for {labels}. Nothing was asked and no report was written. "
            + ("Set these keys first:\n" if len(missing) > 1 else "Set the key first:\n")
            + "\n".join(lines) + f"\nor leave {', '.join(missing)} out of --providers."
        )
    return names


def _models(args) -> dict:
    return {n: getattr(args, f"{n}_model") for n in C.REAL_PROVIDERS if getattr(args, f"{n}_model", None)}


def _fake_answers(args) -> dict | None:
    if not args.fake_answers:
        return None
    try:
        return load_fake_answers(args.fake_answers)
    except ValueError as e:
        raise UsageError(str(e)) from e


def _check_numbers(args) -> None:
    if not 0.5 <= args.threshold <= 1.0:
        raise UsageError("--threshold must be between 0.5 and 1.0")
    if not 1 <= args.max_questions <= 50:
        raise UsageError("--max-questions must be between 1 and 50")
    if getattr(args, "timeout", 1) <= 0:
        raise UsageError("--timeout must be more than 0")


def _write(text: str, output: str, stdout: TextIO) -> None:
    if output == "-":
        stdout.write(text)
        return
    path = Path(output)
    if path.parent and not path.parent.exists():
        path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8")


def _cmd_run(args, env, transport, sleep, out, err) -> int:
    _check_numbers(args)
    branding = _branding(args)
    names = _provider_names(args, env)
    competitors = list(args.competitor) + [c.strip() for c in re.split(r"[;|]", args.competitors or "") if c.strip()]
    questions = None
    if args.questions_file:
        questions = load_questions_file(args.questions_file, args.business, args.city, args.category)
        questions += [q for q in args.question if q not in questions]
    inp = AuditInput(
        business=args.business,
        city=args.city,
        category=args.category,
        website=args.website,
        competitors=competitors,
        questions=questions,
        extra_questions=list(args.question),
        max_questions=args.max_questions,
        threshold=args.threshold,
    )
    try:
        inp.validate()
    except ValueError as e:
        raise UsageError(str(e)) from e
    providers = build_providers(
        names, env, models=_models(args), transport=transport, sleep=sleep, timeout=args.timeout,
        web_search=args.web_search, fake_answers=_fake_answers(args), business=args.business, city=args.city,
        category=args.category, website=args.website, competitors=competitors,
    )
    progress = None if args.quiet else (lambda m: print(m, file=err))
    result = run_audit(inp, providers, progress=progress)
    output = args.output
    fmt = args.format or (format_from_path(output) if output and output != "-" else "html")
    if not output:
        output = f"{slugify(args.business)}-ai-visibility.{fmt}"
    _write(render(result, fmt, branding), output, out)
    s = result["scores"]
    where = "" if output == "-" else f" Report saved to {output}"
    if s["visibility"] is None:
        print(f"{args.business}: no AI tool answered, so nothing was measured.{where}", file=err)
        for p in s["providers"]:
            for m in p["error_messages"]:
                print(f"  {p['label']}: {m}", file=err)
        return EXIT_NOTHING
    msg = (f"{args.business}: {s['visibility']:g}% AI visibility (grade {s['grade']}), "
           f"mentioned in {s['mentioned_answers']} of {s['scored_answers']} answers.{where}")
    print(msg, file=err if output == "-" else out)
    return EXIT_OK


def _cmd_batch(args, env, transport, sleep, out, err) -> int:
    _check_numbers(args)
    branding = _branding(args)
    names = _provider_names(args, env)
    fake = _fake_answers(args)
    try:
        prospects = read_prospects(args.csv)
    except BatchError as e:
        raise UsageError(str(e)) from e
    if not prospects:
        raise UsageError(f"{args.csv} has no prospects in it")
    questions = load_questions_file(args.questions_file) if args.questions_file else None
    fmt = args.format or "html"

    def make(row: dict):
        comps = [c.strip() for c in re.split(r"[;|]", row.get("competitors", "")) if c.strip()]
        return build_providers(
            names, env, models=_models(args), transport=transport, sleep=sleep, timeout=args.timeout,
            web_search=args.web_search, fake_answers=fake, business=row.get("business", ""),
            city=row.get("city", ""), category=row.get("category", ""), website=row.get("website", ""),
            competitors=comps,
        )

    progress = None if args.quiet else (lambda m: print(m, file=err))
    summary = run_batch(prospects, args.outdir, make, fmt=fmt, branding=branding, max_questions=args.max_questions,
                        threshold=args.threshold, questions=questions, progress=progress)
    ok = [s for s in summary if s["status"] == "ok"]
    bad = [s for s in summary if s["status"] != "ok"]
    print(f"Audited {len(ok)} of {len(summary)} businesses. Reports and summary.csv are in {args.outdir}/", file=out)
    if ok:
        print("Best prospects (lowest AI visibility first):", file=out)
        for s in ok[:5]:
            print(f"  {s['rank']}. {s['business']} ({s['city']}): {s['visibility']}%", file=out)
    for s in bad:
        print(f"  Skipped {s['business'] or '(no name)'}: {s['error']}", file=err)
    return EXIT_OK if not bad else EXIT_NOTHING


def _cmd_questions(args, out) -> int:
    try:
        qs = generate_questions(args.business, args.city, args.category, max_questions=args.max_questions)
    except QuestionsError as e:
        raise UsageError(str(e)) from e
    for i, q in enumerate(qs, 1):
        print(f"{i}. {q}", file=out)
    return EXIT_OK


def _cmd_report(args, out, err) -> int:
    branding = _branding(args)
    try:
        result = json.loads(Path(args.json_file).read_text(encoding="utf-8"))
    except OSError as e:
        raise UsageError(f"can't read {args.json_file}: {e.strerror or e}") from e
    except ValueError as e:
        raise UsageError(f"{args.json_file} is not valid JSON: {e}") from e
    if not isinstance(result, dict) or not {"business", "scores", "rows", "questions"} <= set(result):
        raise UsageError(f"{args.json_file} is not a geo-audit JSON file (run with --format json)")
    output = args.output or f"{slugify(result['business'])}-ai-visibility.{args.format or 'html'}"
    fmt = args.format or (format_from_path(output) if output != "-" else "html")
    _write(render(result, fmt, branding), output, out)
    if output != "-" and not args.quiet:
        print(f"Report saved to {output}", file=out)
    return EXIT_OK


def main(
    argv: list[str] | None = None,
    *,
    env: Mapping[str, str] | None = None,
    transport: Transport | None = None,
    sleep: Sleep | None = None,
    stdout: TextIO | None = None,
    stderr: TextIO | None = None,
) -> int:
    out = stdout or sys.stdout
    err = stderr or sys.stderr
    parser = build_parser()
    try:
        args = parser.parse_args(argv)
    except SystemExit as e:  # argparse exits on --help / bad options
        return int(e.code or 0)
    env = os.environ if env is None else env
    try:
        if args.command == "run":
            return _cmd_run(args, env, transport, sleep, out, err)
        if args.command == "batch":
            return _cmd_batch(args, env, transport, sleep, out, err)
        if args.command == "questions":
            return _cmd_questions(args, out)
        if args.command == "report":
            return _cmd_report(args, out, err)
        parser.print_help(out)
        return EXIT_USAGE
    except (UsageError, QuestionsError) as e:
        print(f"Error: {e}", file=err)
        return EXIT_USAGE
    except OSError as e:
        print(f"Error: {e}", file=err)
        return EXIT_USAGE
