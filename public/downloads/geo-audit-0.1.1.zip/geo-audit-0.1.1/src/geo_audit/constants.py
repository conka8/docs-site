"""Every third-party API detail lives here: endpoint URLs, headers, model names and response fields.

VERIFY AGAINST CURRENT DOCS. These values were written from memory of each provider's public
documentation and were not checked against the live services (the test suite never touches the
network). If a provider changes its API, this is the only file you should need to edit.
"""

from __future__ import annotations

# ---------------------------------------------------------------- HTTP behaviour
HTTP_TIMEOUT_SECONDS = 60.0
HTTP_MAX_RETRIES = 2  # extra attempts after the first one, on 429 / 5xx / network errors
HTTP_BACKOFF_SECONDS = 2.0  # wait = backoff * 2**attempt (or the server's Retry-After, capped)
HTTP_MAX_RETRY_AFTER_SECONDS = 30.0
RETRY_STATUSES = frozenset({429, 500, 502, 503, 504, 529})
USER_AGENT = "geo-audit/0.1"

# ---------------------------------------------------------------- OpenAI (Chat Completions)
OPENAI_ENV = "OPENAI_API_KEY"
OPENAI_URL = "https://api.openai.com/v1/chat/completions"
OPENAI_DEFAULT_MODEL = "gpt-4o-mini"
# reply text: choices[0].message.content
# web citations (search models only): choices[0].message.annotations[].url_citation.{url,title}
OPENAI_ANNOTATIONS_FIELD = "annotations"
OPENAI_URL_CITATION_FIELD = "url_citation"

# ---------------------------------------------------------------- Anthropic (Messages API)
ANTHROPIC_ENV = "ANTHROPIC_API_KEY"
ANTHROPIC_URL = "https://api.anthropic.com/v1/messages"
ANTHROPIC_VERSION = "2023-06-01"  # sent as the "anthropic-version" header
ANTHROPIC_DEFAULT_MODEL = "claude-sonnet-5-5"
ANTHROPIC_MAX_TOKENS = 1024
# Only sent with --web-search. Tool type string changes between versions: verify.
ANTHROPIC_WEB_SEARCH_TOOL = {"type": "web_search_20250305", "name": "web_search", "max_uses": 3}
# reply text: content[] blocks with type == "text" -> .text
# citations: text blocks' .citations[].url ; web_search_tool_result blocks' .content[].url
ANTHROPIC_SEARCH_RESULT_BLOCK = "web_search_tool_result"

# ---------------------------------------------------------------- Perplexity (OpenAI-compatible)
PERPLEXITY_ENV = "PERPLEXITY_API_KEY"
PERPLEXITY_URL = "https://api.perplexity.ai/chat/completions"
PERPLEXITY_DEFAULT_MODEL = "sonar"
# reply text: choices[0].message.content
# sources: top-level "citations" (list of URL strings) and/or "search_results" (list of {title,url,...})
PERPLEXITY_CITATIONS_FIELD = "citations"
PERPLEXITY_SEARCH_RESULTS_FIELD = "search_results"

# ---------------------------------------------------------------- Google Gemini (generateContent)
GEMINI_ENV = "GEMINI_API_KEY"
GEMINI_URL_TEMPLATE = "https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent"
GEMINI_API_KEY_HEADER = "x-goog-api-key"
GEMINI_DEFAULT_MODEL = "gemini-2.5-flash"
# Only sent with --web-search ("grounding with Google Search").
GEMINI_SEARCH_TOOL = {"google_search": {}}
# reply text: candidates[0].content.parts[].text
# sources: candidates[0].groundingMetadata.groundingChunks[].web.{uri,title}
GEMINI_GROUNDING_FIELD = "groundingMetadata"
GEMINI_GROUNDING_CHUNKS_FIELD = "groundingChunks"
# Grounding URIs are often redirect links; for these hosts we use the chunk title (usually the domain).
GEMINI_REDIRECT_HOSTS = ("vertexaisearch.cloud.google.com",)

# ---------------------------------------------------------------- provider registry
PROVIDER_LABELS = {
    "openai": "ChatGPT (OpenAI)",
    "anthropic": "Claude (Anthropic)",
    "perplexity": "Perplexity",
    "gemini": "Gemini (Google)",
    "fake": "Demo AI (fake)",
}
PROVIDER_ENV = {
    "openai": OPENAI_ENV,
    "anthropic": ANTHROPIC_ENV,
    "perplexity": PERPLEXITY_ENV,
    "gemini": GEMINI_ENV,
}
DEFAULT_MODELS = {
    "openai": OPENAI_DEFAULT_MODEL,
    "anthropic": ANTHROPIC_DEFAULT_MODEL,
    "perplexity": PERPLEXITY_DEFAULT_MODEL,
    "gemini": GEMINI_DEFAULT_MODEL,
    "fake": "canned-answers",
}
REAL_PROVIDERS = ("openai", "anthropic", "perplexity", "gemini")
