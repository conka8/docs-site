"""Pull structure out of an AI answer: listed business names (in order), bold names, URLs, domains."""

from __future__ import annotations

import re
from collections import Counter
from urllib.parse import urlparse

from .matching import normalize_domain, tokenize

# list markers: "1." "1)" "(1)" "-" "*" "+" "•" ; also markdown headings "### 1. Name"
_LIST_RE = re.compile(r"^(?P<indent>[ \t]*)(?:\(?\d{1,2}[.)]|[-*+•–])[ \t]+(?P<body>\S.*)$")
_HEADING_RE = re.compile(r"^(?P<indent>)#{1,6}[ \t]+(?:\d{1,2}[.)][ \t]*)?(?P<body>\S.*)$")
_BOLD_RE = re.compile(r"\*\*(?P<a>[^*\n]{2,80}?)\*\*|__(?P<b>[^_\n]{2,80}?)__")
_MD_LINK_RE = re.compile(r"\[([^\]\n]+)\]\((?:[^)\s]+)\)")
_CITE_MARK_RE = re.compile(r"\[\d{1,3}\]")
_URL_RE = re.compile(r"https?://[^\s<>\"'\]}]+", re.IGNORECASE)
_TRAILING_URL_PUNCT = ".,;:!?*_"
_BARE_DOMAIN_RE = re.compile(
    r"(?<![@\w.-])((?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+"
    r"(?:com|org|net|io|co|us|biz|info|health|dental|law|edu|gov|ai|app|ca|uk|au|me))(?![\w-])",
    re.IGNORECASE,
)

# separators that end a business name inside a list item: "Name - great reviews", "Name: ...", "Name (4.8 stars)"
_NAME_END_RE = re.compile(r"\s+[-–—|]\s+|:\s|:$|\s\(|,\s|\s+is\s+|\s+offers\s+|\s+has\s+|\.\s|\s+–|\s+—")

# words that make something a label / heading rather than a business name
_LABEL_WORDS = frozenset(
    """
    address phone rating ratings reviews review website hours location locations services service
    why pros cons price prices pricing cost note notes tip tips summary conclusion overview
    specialties specialty highlights highlight contact email features best top other others
    honorable mention mentions key considerations factors final verdict bottom line recommendation
    recommendations options option how what when where which who sources source disclaimer
    insurance availability open weekend weekends here there also consider look check ask
    monday tuesday wednesday thursday friday saturday sunday closed yes no important warning
    step steps example examples
    """.split()
)
_SMALL_WORDS = frozenset("of the and & at on in for a an by to de la del y or with".split())


def strip_markdown(text: str) -> str:
    """Remove the markdown decorations we care about (links keep their label, citation marks vanish)."""
    t = _MD_LINK_RE.sub(r"\1", text or "")
    t = _CITE_MARK_RE.sub("", t)
    t = t.replace("**", "").replace("__", "")
    t = re.sub(r"(?<!\w)[*_`](?=\S)|(?<=\S)[*_`](?!\w)", "", t)
    return t.strip()


def _clean_name(raw: str) -> str:
    name = strip_markdown(raw)
    name = re.sub(r"https?://\S+", "", name)
    m = _NAME_END_RE.search(name)
    if m:
        name = name[: m.start()]
    name = name.strip(" \t-–—:;,.!?\"'()[]#")
    return re.sub(r"\s+", " ", name)


def is_name_like(name: str, *, from_bold: bool = False) -> bool:
    """Heuristic: does this short string look like a business name (not a sentence or a label)?"""
    if not name or len(name) < 3 or len(name) > 70:
        return False
    words = name.split()
    if not words or len(words) > 8:
        return False
    if not (words[0][0].isupper() or words[0][0].isdigit()):
        return False
    first = tokenize(words[0])
    if first and first[0] in _LABEL_WORDS:
        return False
    toks = tokenize(name)
    if not toks or all(t in _LABEL_WORDS or t in _SMALL_WORDS for t in toks):
        return False
    if "?" in name:
        return False
    significant = [w for w in words if w.lower() not in _SMALL_WORDS]
    if not significant:
        return False
    if not any(w[0].isupper() for w in significant):
        return False
    capitalized = sum(1 for w in significant if w[0].isupper() or w[0].isdigit())
    ratio = capitalized / len(significant)
    return ratio >= (0.5 if from_bold else 0.75)


def list_items(text: str, keep=None) -> list[str]:
    """Top-level business names from numbered/bulleted lists (and numbered headings), in answer order.

    Sub-bullets (indented deeper than the shallowest list level) are ignored, so
    "- Phone: ..." under "1. **Smile Dental**" doesn't count as a business.
    ``keep(name) -> bool`` can force a candidate in even if it doesn't look like a name.
    """
    raw: list[tuple[int, str]] = []
    for line in (text or "").splitlines():
        m = _LIST_RE.match(line) or _HEADING_RE.match(line)
        if not m:
            continue
        indent = len(m.group("indent").replace("\t", "    "))
        raw.append((indent, m.group("body")))
    if not raw:
        return []
    top = min(i for i, _ in raw)
    names: list[str] = []
    for indent, body in raw:
        if indent > top + 1:
            continue
        bold = _BOLD_RE.search(body)
        # a bold name at the start of the item wins ("**Smile Dental** - ...")
        if bold and body.strip().startswith(("**", "__", "[**")):
            candidate = _clean_name(bold.group("a") or bold.group("b"))
            ok = is_name_like(candidate, from_bold=True)
        else:
            candidate = _clean_name(body)
            ok = is_name_like(candidate)
        if ok or (candidate and keep is not None and keep(candidate)):
            names.append(candidate)
    return names


def bold_names(text: str, min_words: int = 2) -> list[str]:
    """Name-like **bold** phrases anywhere in the answer, in order (at least ``min_words`` words,
    so a bold "**Fresno**" or "**Important**" in a sentence isn't taken for a business)."""
    out = []
    for m in _BOLD_RE.finditer(text or ""):
        candidate = _clean_name(m.group("a") or m.group("b"))
        if len(candidate.split()) >= min_words and is_name_like(candidate, from_bold=True):
            out.append(candidate)
    return out


def extract_urls(text: str) -> list[str]:
    """http(s) URLs found in the answer text (markdown links included), trailing punctuation removed."""
    urls = []
    for m in _URL_RE.finditer(text or ""):
        url = m.group(0).rstrip(_TRAILING_URL_PUNCT)
        while url.endswith(")") and url.count("(") < url.count(")"):
            url = url[:-1].rstrip(_TRAILING_URL_PUNCT)
        if url not in urls:
            urls.append(url)
    return urls


def extract_bare_domains(text: str) -> list[str]:
    """Domains written without http:// ("check yelp.com"), plus hosts of full URLs. Normalized, deduped."""
    found: list[str] = []
    for url in extract_urls(text):
        d = normalize_domain(url)
        if d and d not in found:
            found.append(d)
    without_urls = _URL_RE.sub(" ", text or "")
    for m in _BARE_DOMAIN_RE.finditer(without_urls):
        d = normalize_domain(m.group(1))
        if d and d not in found:
            found.append(d)
    return found


def url_domain(url: str) -> str:
    """Domain for grouping: 'https://www.yelp.com/biz/x' -> 'yelp.com'."""
    return normalize_domain(url)


def group_by_domain(urls: list[str]) -> dict[str, list[str]]:
    """{'yelp.com': ['https://yelp.com/a', ...], ...} keeping first-seen order."""
    groups: dict[str, list[str]] = {}
    for url in urls:
        d = url_domain(url)
        if not d:
            continue
        groups.setdefault(d, [])
        if url not in groups[d]:
            groups[d].append(url)
    return groups


def count_domains(domain_lists: list[list[str]]) -> Counter:
    """How many answers cited each domain (a domain counts once per answer)."""
    c: Counter = Counter()
    for doms in domain_lists:
        c.update(set(doms))
    return c


def is_url(value: str) -> bool:
    try:
        p = urlparse(value)
    except ValueError:
        return False
    return p.scheme in ("http", "https") and bool(p.netloc)
