"""Business-name normalization and matching ("is Smile Dental mentioned in this answer?").

Rules, in plain English:
- case, punctuation and "&" vs "and" don't matter;
- legal / generic endings are ignored: "Smile Dental Group LLC" == "Smile Dental";
- a leading "The" is ignored;
- small typos and spacing differences are allowed (difflib ratio >= threshold):
  "BrightSmile Dental" == "Bright Smile Dental", "Smiles Dental" == "Smile Dental";
- but part of the name is NOT enough: "Smile" alone does not match "Smile Dental".
"""

from __future__ import annotations

import re
import unicodedata
from difflib import SequenceMatcher
from urllib.parse import urlparse

DEFAULT_THRESHOLD = 0.9

# Words dropped from the END of a name before comparing (repeatedly: "Dental Group LLC" -> "Dental").
SUFFIX_WORDS = frozenset(
    """
    llc inc incorporated corp corporation co company ltd limited pllc pc plc lp llp pa
    dds dmd md dpm od dc esq
    group associates partners clinic clinics center centre office offices practice
    """.split()
)
LEADING_WORDS = frozenset({"the"})

_APOSTROPHES = str.maketrans({"’": "'", "‘": "'", "`": "'"})
_NON_WORD = re.compile(r"[^a-z0-9]+")


def _ascii_fold(text: str) -> str:
    return unicodedata.normalize("NFKD", text).encode("ascii", "ignore").decode("ascii")


def tokenize(text: str) -> list[str]:
    """Lowercase word tokens with '&' -> 'and' and apostrophes removed ("Joe's" -> "joes")."""
    t = _ascii_fold((text or "").translate(_APOSTROPHES)).lower()
    t = t.replace("&", " and ").replace("+", " and ")
    t = t.replace("'", "")
    return [tok for tok in _NON_WORD.split(t) if tok]


def normalize_name(name: str) -> str:
    """Normalized full name: 'Smile Dental Group, LLC' -> 'smile dental group llc'."""
    return " ".join(tokenize(name))


def core_tokens(name: str) -> list[str]:
    """Name tokens without leading 'the' and trailing legal/generic suffixes. Never empty if name isn't."""
    toks = tokenize(name)
    while len(toks) > 1 and toks[0] in LEADING_WORDS:
        toks = toks[1:]
    while len(toks) > 1 and (toks[-1] in SUFFIX_WORDS or toks[-1] == "and"):
        toks = toks[:-1]
    return toks


def core_name(name: str) -> str:
    """'The Smile Dental Group, LLC' -> 'smile dental'."""
    return " ".join(core_tokens(name))


def _squash(tokens: list[str]) -> str:
    return "".join(tokens)


def similarity(a: str, b: str) -> float:
    """0..1 similarity of two business names after normalization (spaces ignored)."""
    ca, cb = _squash(core_tokens(a)), _squash(core_tokens(b))
    if not ca or not cb:
        return 0.0
    if ca == cb:
        return 1.0
    return SequenceMatcher(None, ca, cb).ratio()


def names_match(a: str, b: str, threshold: float = DEFAULT_THRESHOLD) -> bool:
    """True if two whole names refer to the same business."""
    return similarity(a, b) >= threshold


def _find_subsequence(hay: list[str], needle: list[str]) -> int:
    n = len(needle)
    for i in range(len(hay) - n + 1):
        if hay[i : i + n] == needle:
            return i
    return -1


def find_in_text(text: str, name: str, threshold: float = DEFAULT_THRESHOLD) -> tuple[str, str] | None:
    """Look for a business name inside free text.

    Returns ``(how, matched_words)`` where how is "exact" or "fuzzy", or None if not found.
    """
    needle = core_tokens(name)
    if not needle:
        return None
    hay = tokenize(text)
    if not hay:
        return None
    pos = _find_subsequence(hay, needle)
    if pos >= 0:
        return "exact", " ".join(hay[pos : pos + len(needle)])
    target = _squash(needle)
    n = len(needle)
    best: tuple[float, str] | None = None
    for size in sorted({max(1, n - 1), n, n + 1}):
        if size > len(hay):
            continue
        for i in range(len(hay) - size + 1):
            window = hay[i : i + size]
            # ignore trailing suffix words inside the window ("smiles dental group")
            trimmed = list(window)
            while len(trimmed) > 1 and trimmed[-1] in SUFFIX_WORDS:
                trimmed.pop()
            cand = _squash(trimmed)
            # cheap length filter before difflib
            if abs(len(cand) - len(target)) > max(2, len(target) // 4):
                continue
            ratio = SequenceMatcher(None, cand, target).ratio()
            if ratio >= threshold and (best is None or ratio > best[0]):
                best = (ratio, " ".join(window))
    if best:
        return "fuzzy", best[1]
    return None


# ---------------------------------------------------------------- domains

def normalize_domain(value: str) -> str:
    """'https://www.SmileDental.com/about' -> 'smiledental.com'. Returns '' if nothing usable."""
    v = (value or "").strip().lower()
    if not v:
        return ""
    if "://" not in v:
        v = "http://" + v.lstrip("/")
    try:
        host = urlparse(v).hostname or ""
    except ValueError:
        return ""
    host = host.strip(".")
    for prefix in ("www.", "m."):
        if host.startswith(prefix) and host.count(".") >= 2:
            host = host[len(prefix) :]
    if "." not in host:
        return ""
    return host


def domain_matches(domain: str, target: str) -> bool:
    """True if ``domain`` is ``target`` or a subdomain of it."""
    d, t = normalize_domain(domain), normalize_domain(target)
    return bool(d and t and (d == t or d.endswith("." + t)))
