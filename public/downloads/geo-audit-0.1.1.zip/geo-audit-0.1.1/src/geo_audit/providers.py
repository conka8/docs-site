"""AI providers: OpenAI, Anthropic, Perplexity, Gemini, plus a ``fake`` one for demos and tests.

Every provider exposes ``ask(question) -> ProviderAnswer``. All HTTP goes through
``transport.post_json`` so a fake transport can stand in for the network.
"""

from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Mapping

from . import constants as C
from .extract import is_url
from .transport import ProviderError, Sleep, Transport, post_json


@dataclass
class Citation:
    url: str
    title: str = ""

    def to_dict(self) -> dict:
        return {"url": self.url, "title": self.title}


@dataclass
class ProviderAnswer:
    text: str
    citations: list[Citation] = field(default_factory=list)


class Provider:
    name = "base"

    def __init__(
        self,
        api_key: str = "",
        model: str | None = None,
        *,
        transport: Transport | None = None,
        sleep: Sleep | None = None,
        timeout: float = C.HTTP_TIMEOUT_SECONDS,
        max_retries: int = C.HTTP_MAX_RETRIES,
        web_search: bool = False,
    ):
        self.api_key = api_key
        self.model = model or C.DEFAULT_MODELS.get(self.name, "")
        self.transport = transport
        self.sleep = sleep
        self.timeout = timeout
        self.max_retries = max_retries
        self.web_search = web_search

    @property
    def label(self) -> str:
        return C.PROVIDER_LABELS.get(self.name, self.name)

    def _post(self, url: str, payload: dict, headers: dict) -> dict:
        if not self.api_key:
            env = C.PROVIDER_ENV.get(self.name, "an API key")
            raise ProviderError(f"{env} is not set")
        data = post_json(
            url,
            payload,
            headers,
            transport=self.transport,
            sleep=self.sleep,
            timeout=self.timeout,
            max_retries=self.max_retries,
        )
        if not isinstance(data, dict):
            raise ProviderError("unexpected reply (not a JSON object)")
        return data

    def ask(self, question: str) -> ProviderAnswer:  # pragma: no cover - abstract
        raise NotImplementedError


def _dedupe_citations(cites: list[Citation]) -> list[Citation]:
    seen: set[str] = set()
    out = []
    for c in cites:
        if c.url and c.url not in seen:
            seen.add(c.url)
            out.append(c)
    return out


def _chat_text(data: dict) -> str:
    try:
        content = data["choices"][0]["message"]["content"]
    except (KeyError, IndexError, TypeError) as e:
        raise ProviderError("unexpected reply: no choices[0].message.content") from e
    if isinstance(content, list):  # some compatible APIs return content parts
        content = "".join(p.get("text", "") for p in content if isinstance(p, dict))
    return content or ""


class OpenAIProvider(Provider):
    name = "openai"
    url = C.OPENAI_URL

    def build_request(self, question: str) -> tuple[str, dict, dict]:
        payload = {"model": self.model, "messages": [{"role": "user", "content": question}]}
        headers = {"Authorization": f"Bearer {self.api_key}"}
        return self.url, payload, headers

    def parse(self, data: dict) -> ProviderAnswer:
        text = _chat_text(data)
        cites: list[Citation] = []
        message = data["choices"][0].get("message") or {}
        for ann in message.get(C.OPENAI_ANNOTATIONS_FIELD) or []:
            if not isinstance(ann, dict):
                continue
            uc = ann.get(C.OPENAI_URL_CITATION_FIELD) or ann
            if isinstance(uc, dict) and is_url(str(uc.get("url", ""))):
                cites.append(Citation(uc["url"], str(uc.get("title") or "")))
        return ProviderAnswer(text, _dedupe_citations(cites))

    def ask(self, question: str) -> ProviderAnswer:
        url, payload, headers = self.build_request(question)
        return self.parse(self._post(url, payload, headers))


class PerplexityProvider(OpenAIProvider):
    name = "perplexity"
    url = C.PERPLEXITY_URL

    def parse(self, data: dict) -> ProviderAnswer:
        answer = super().parse(data)
        cites = list(answer.citations)
        for item in data.get(C.PERPLEXITY_CITATIONS_FIELD) or []:
            if isinstance(item, str) and is_url(item):
                cites.append(Citation(item))
            elif isinstance(item, dict) and is_url(str(item.get("url", ""))):
                cites.append(Citation(item["url"], str(item.get("title") or "")))
        for item in data.get(C.PERPLEXITY_SEARCH_RESULTS_FIELD) or []:
            if isinstance(item, dict) and is_url(str(item.get("url", ""))):
                cites.append(Citation(item["url"], str(item.get("title") or "")))
        return ProviderAnswer(answer.text, _dedupe_citations(cites))


class AnthropicProvider(Provider):
    name = "anthropic"

    def build_request(self, question: str) -> tuple[str, dict, dict]:
        payload: dict = {
            "model": self.model,
            "max_tokens": C.ANTHROPIC_MAX_TOKENS,
            "messages": [{"role": "user", "content": question}],
        }
        if self.web_search:
            payload["tools"] = [dict(C.ANTHROPIC_WEB_SEARCH_TOOL)]
        headers = {"x-api-key": self.api_key, "anthropic-version": C.ANTHROPIC_VERSION}
        return C.ANTHROPIC_URL, payload, headers

    def parse(self, data: dict) -> ProviderAnswer:
        blocks = data.get("content")
        if not isinstance(blocks, list):
            raise ProviderError("unexpected reply: no content blocks")
        texts: list[str] = []
        cites: list[Citation] = []
        for block in blocks:
            if not isinstance(block, dict):
                continue
            if block.get("type") == "text":
                texts.append(str(block.get("text", "")))
                for c in block.get("citations") or []:
                    if isinstance(c, dict) and is_url(str(c.get("url", ""))):
                        cites.append(Citation(c["url"], str(c.get("title") or "")))
            elif block.get("type") == C.ANTHROPIC_SEARCH_RESULT_BLOCK:
                for r in block.get("content") or []:
                    if isinstance(r, dict) and is_url(str(r.get("url", ""))):
                        cites.append(Citation(r["url"], str(r.get("title") or "")))
        return ProviderAnswer("".join(texts).strip(), _dedupe_citations(cites))

    def ask(self, question: str) -> ProviderAnswer:
        url, payload, headers = self.build_request(question)
        return self.parse(self._post(url, payload, headers))


class GeminiProvider(Provider):
    name = "gemini"

    def build_request(self, question: str) -> tuple[str, dict, dict]:
        payload: dict = {"contents": [{"role": "user", "parts": [{"text": question}]}]}
        if self.web_search:
            payload["tools"] = [dict(C.GEMINI_SEARCH_TOOL)]
        headers = {C.GEMINI_API_KEY_HEADER: self.api_key}
        return C.GEMINI_URL_TEMPLATE.format(model=self.model), payload, headers

    def parse(self, data: dict) -> ProviderAnswer:
        try:
            cand = data["candidates"][0]
        except (KeyError, IndexError, TypeError) as e:
            reason = ""
            fb = data.get("promptFeedback") if isinstance(data, dict) else None
            if isinstance(fb, dict) and fb.get("blockReason"):
                reason = f" (blocked: {fb['blockReason']})"
            raise ProviderError(f"unexpected reply: no candidates{reason}") from e
        parts = ((cand.get("content") or {}).get("parts")) or []
        text = "".join(str(p.get("text", "")) for p in parts if isinstance(p, dict)).strip()
        cites: list[Citation] = []
        meta = cand.get(C.GEMINI_GROUNDING_FIELD) or {}
        for chunk in meta.get(C.GEMINI_GROUNDING_CHUNKS_FIELD) or []:
            web = chunk.get("web") if isinstance(chunk, dict) else None
            if not isinstance(web, dict):
                continue
            uri, title = str(web.get("uri", "")), str(web.get("title") or "")
            if any(h in uri for h in C.GEMINI_REDIRECT_HOSTS) and title and "." in title and " " not in title:
                # redirect link: the title is the real site, e.g. "yelp.com"
                uri = "https://" + title.strip().lower()
            if is_url(uri):
                cites.append(Citation(uri, title))
        return ProviderAnswer(text, _dedupe_citations(cites))

    def ask(self, question: str) -> ProviderAnswer:
        url, payload, headers = self.build_request(question)
        return self.parse(self._post(url, payload, headers))


# ---------------------------------------------------------------- fake provider

def _pick(seed: str, n: int) -> int:
    return int(hashlib.sha256(seed.encode("utf-8")).hexdigest(), 16) % n


class FakeProvider(Provider):
    """Deterministic canned answers. No network, no key.

    ``answers`` maps a question (or a lowercase substring of it, or ``"*"`` for any question) to an
    answer string or to ``{"text": ..., "citations": [urls]}``. Questions without a canned answer get a generated,
    realistic-looking answer that depends on ``seed`` (so ``fake-a`` and ``fake-b`` differ).
    """

    name = "fake"

    def __init__(
        self,
        name: str = "fake",
        *,
        answers: Mapping[str, object] | None = None,
        business: str = "",
        city: str = "",
        category: str = "",
        website: str = "",
        competitors: list[str] | None = None,
        fail_with: str | None = None,
        seed: str | None = None,
    ):
        super().__init__(api_key="fake", model=C.DEFAULT_MODELS["fake"])
        self.name = name
        self.answers = {str(k).lower(): v for k, v in (answers or {}).items()}
        self.business = business or "Your Business"
        self.city = city or "your city"
        self.category = category or "business"
        self.website = website
        self.competitors = list(competitors or [])
        self.fail_with = fail_with
        self.seed = seed if seed is not None else name
        self.calls: list[str] = []

    @property
    def label(self) -> str:
        if self.name == "fake":
            return C.PROVIDER_LABELS["fake"]
        return f"Demo AI ({self.name.split('-', 1)[-1]})"

    def ask(self, question: str) -> ProviderAnswer:
        self.calls.append(question)
        if self.fail_with:
            raise ProviderError(self.fail_with)
        q = question.lower()
        canned = self.answers.get(q)
        if canned is None:
            for key, value in self.answers.items():
                if key and key != "*" and key in q:
                    canned = value
                    break
        if canned is None:
            canned = self.answers.get("*")  # catch-all answer
        if canned is not None:
            if isinstance(canned, dict):
                cites = [Citation(u) for u in canned.get("citations", []) if isinstance(u, str)]
                return ProviderAnswer(str(canned.get("text", "")), cites)
            return ProviderAnswer(str(canned))
        return self._generated(question)

    def _rivals(self) -> list[str]:
        city_word = self.city.split(",")[0].strip() or "City"
        cat = self.category.strip().title() or "Service"
        generated = [
            f"{city_word} Family {cat}",
            f"Valley {cat} Care",
            f"Sunrise {cat} Studio",
            f"Main Street {cat}",
        ]
        rivals = list(self.competitors) + [g for g in generated if g not in self.competitors]
        return rivals[:5]

    def _generated(self, question: str) -> ProviderAnswer:
        rivals = self._rivals()
        style = _pick(f"{self.seed}|{question}", 4)
        cat, city = self.category, self.city
        site = self.website
        biz_named = self.business.lower() in question.lower()
        cites = [Citation("https://www.yelp.com/search?find_desc=" + cat.replace(" ", "+"))]
        if biz_named:
            if style == 3:
                return ProviderAnswer(
                    f"I don't have specific information about {self.business}. "
                    f"Check recent reviews on Google or Yelp before you book.",
                    cites,
                )
            text = (
                f"{self.business} is a {cat} in {city}. Reviews are mostly positive: customers mention "
                f"friendly staff and short wait times. Some reviews mention billing questions."
            )
            if site:
                text += f" More details are on their website, {site}."
                cites.append(Citation(f"https://{site}/"))
            return ProviderAnswer(text, cites)
        if style == 0:  # numbered list, business 2nd
            names = [rivals[0], self.business, rivals[1], rivals[2]]
        elif style == 1:  # list without the business
            names = rivals[:4]
        elif style == 2:  # bulleted with bold names, business last
            lines = [f"Here are some well-reviewed options for a {cat} in {city}:", ""]
            for n in rivals[:3] + [self.business]:
                lines.append(f"- **{n}**: good reviews and convenient hours.")
            lines += ["", "Sources: https://www.healthgrades.com/ and https://www.yelp.com/"]
            cites.append(Citation("https://www.healthgrades.com/"))
            return ProviderAnswer("\n".join(lines), cites)
        else:  # prose, no list
            text = (
                f"Popular choices for a {cat} in {city} include **{rivals[0]}** and **{rivals[1]}**. "
                f"Read recent reviews and call ahead to check availability."
            )
            return ProviderAnswer(text, cites)
        lines = [f"Here are some top-rated options for a {cat} in {city}:", ""]
        for i, n in enumerate(names, 1):
            lines.append(f"{i}. **{n}** - known for friendly service (4.{8 - i % 3} stars)")
        lines += ["", "Always check recent reviews before booking."]
        if site and self.business in names:
            cites.append(Citation(f"https://{site}/"))
        return ProviderAnswer("\n".join(lines), cites)


def load_fake_answers(path: str | Path) -> dict:
    """JSON object {question or substring: answer text or {text, citations}}."""
    try:
        data = json.loads(Path(path).read_text(encoding="utf-8"))
    except OSError as e:
        raise ValueError(f"can't read fake answers file {path}: {e.strerror or e}") from e
    except ValueError as e:
        raise ValueError(f"{path} is not valid JSON: {e}") from e
    if not isinstance(data, dict):
        raise ValueError(f"{path} must be a JSON object of question -> answer")
    return data


# ---------------------------------------------------------------- registry

PROVIDER_CLASSES = {
    "openai": OpenAIProvider,
    "anthropic": AnthropicProvider,
    "perplexity": PerplexityProvider,
    "gemini": GeminiProvider,
}


def parse_provider_list(value: str | None) -> list[str]:
    """'openai, gemini' -> ['openai', 'gemini']. Raises ValueError on unknown names."""
    if not value:
        return []
    names: list[str] = []
    for raw in value.split(","):
        n = raw.strip().lower()
        if not n:
            continue
        if n not in PROVIDER_CLASSES and not (n == "fake" or n.startswith("fake-")):
            known = ", ".join(list(PROVIDER_CLASSES) + ["fake"])
            raise ValueError(f"unknown provider '{raw.strip()}'. Choose from: {known}")
        if n not in names:
            names.append(n)
    return names


def available_providers(env: Mapping[str, str]) -> list[str]:
    """Real providers whose API key env var is set."""
    return [n for n in C.REAL_PROVIDERS if (env.get(C.PROVIDER_ENV[n]) or "").strip()]


def build_providers(
    names: list[str],
    env: Mapping[str, str],
    *,
    models: Mapping[str, str] | None = None,
    transport: Transport | None = None,
    sleep: Sleep | None = None,
    timeout: float = C.HTTP_TIMEOUT_SECONDS,
    web_search: bool = False,
    fake_answers: Mapping[str, object] | None = None,
    business: str = "",
    city: str = "",
    category: str = "",
    website: str = "",
    competitors: list[str] | None = None,
) -> list[Provider]:
    """Create provider objects. A listed provider without a key is still created; its calls fail
    with a clear "KEY is not set" error that ends up in the report instead of crashing the run."""
    models = models or {}
    out: list[Provider] = []
    for n in names:
        if n == "fake" or n.startswith("fake-"):
            out.append(
                FakeProvider(
                    n,
                    answers=fake_answers,
                    business=business,
                    city=city,
                    category=category,
                    website=website,
                    competitors=competitors,
                )
            )
            continue
        cls = PROVIDER_CLASSES[n]
        out.append(
            cls(
                api_key=(env.get(C.PROVIDER_ENV[n]) or "").strip(),
                model=models.get(n) or None,
                transport=transport,
                sleep=sleep,
                timeout=timeout,
                web_search=web_search,
            )
        )
    return out
