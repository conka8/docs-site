"""Buyer-intent questions a real customer would type into ChatGPT, Perplexity, Gemini or Claude."""

from __future__ import annotations

import json
import re
from pathlib import Path

from .matching import core_tokens, tokenize

# "discovery" questions don't name the business: being mentioned there is real visibility.
DISCOVERY_TEMPLATES = (
    "What is the best {category} in {city}?",
    "Who is the most trusted {category} near {city}?",
    "Can you recommend a good {category} in {city}?",
    "Which {category} in {city} has the best reviews?",
    "Is there a {category} in {city} open on weekends?",
    "What is an affordable {category} in {city}?",
    "Top rated {category} near {city}",
    "I just moved to {city}. Which {category} should I go to?",
    "Which {category} in {city} do locals recommend?",
)
# "brand" questions name the business: they test whether the AI knows it at all.
BRAND_TEMPLATES = (
    "What do people say about {business} in {city}? Are their reviews good?",
    "Is {business} a good {category} in {city}?",
)
DEFAULT_MAX_QUESTIONS = 10
MIN_QUESTIONS, MAX_QUESTIONS = 1, 50


class QuestionsError(ValueError):
    """Bad questions file or bad input."""


def _key(question: str) -> str:
    return " ".join(tokenize(question))


def dedupe(questions: list[str]) -> list[str]:
    """Remove empty and duplicate questions (case/punctuation/spacing-insensitive), keep order."""
    seen: set[str] = set()
    out: list[str] = []
    for q in questions:
        q = re.sub(r"\s+", " ", (q or "").strip())
        k = _key(q)
        if not k or k in seen:
            continue
        seen.add(k)
        out.append(q)
    return out


def question_kind(question: str, business: str) -> str:
    """'brand' if the question names the business, else 'discovery'."""
    needle = core_tokens(business)
    hay = tokenize(question)
    n = len(needle)
    if n and any(hay[i : i + n] == needle for i in range(len(hay) - n + 1)):
        return "brand"
    return "discovery"


def generate_questions(
    business: str,
    city: str,
    category: str,
    *,
    extra: list[str] | None = None,
    max_questions: int = DEFAULT_MAX_QUESTIONS,
) -> list[str]:
    """Build ~8-12 deduped questions from templates, with ``extra`` custom questions first.

    Brand questions are always kept (the last 2 slots) so the report can show whether the AI knows
    the business; the rest are discovery questions.
    """
    for label, value in (("business", business), ("city", city), ("category", category)):
        if not (value or "").strip():
            raise QuestionsError(f"{label} is required")
    if not MIN_QUESTIONS <= max_questions <= MAX_QUESTIONS:
        raise QuestionsError(f"max questions must be between {MIN_QUESTIONS} and {MAX_QUESTIONS}")
    values = {"business": business.strip(), "city": city.strip(), "category": category.strip()}
    custom = dedupe(list(extra or []))
    taken = {_key(q) for q in custom}
    brand = [q for q in (t.format(**values) for t in BRAND_TEMPLATES) if _key(q) not in taken]
    discovery = [q for q in (t.format(**values) for t in DISCOVERY_TEMPLATES) if _key(q) not in taken]
    room_for_discovery = max(0, max_questions - len(custom) - len(brand))
    if max_questions <= len(brand):  # tiny budgets: discovery matters most
        brand, room_for_discovery = [], max_questions - len(custom)
    questions = dedupe(custom + discovery[: max(0, room_for_discovery)] + brand)
    return questions[:max_questions]


def fill_placeholders(question: str, business: str, city: str, category: str) -> str:
    """Fill {business} {city} {category}; leave anything else (odd braces) untouched."""
    out = question
    for key, value in (("business", business), ("city", city), ("category", category)):
        out = out.replace("{" + key + "}", value)
    return out


def load_questions_file(
    path: str | Path, business: str | None = None, city: str | None = None, category: str | None = None
) -> list[str]:
    """Read questions from a .txt (one per line, '#' comments) or .json (list of strings) file.

    ``{business}``, ``{city}`` and ``{category}`` placeholders are filled in when values are given
    (batch mode passes none and fills them per prospect).
    """
    p = Path(path)
    try:
        raw = p.read_text(encoding="utf-8")
    except OSError as e:
        raise QuestionsError(f"can't read questions file {p}: {e.strerror or e}") from e
    except UnicodeDecodeError as e:
        raise QuestionsError(f"can't read questions file {p}: save it as UTF-8 text and try again") from e
    if p.suffix.lower() == ".json":
        try:
            data = json.loads(raw)
        except ValueError as e:
            raise QuestionsError(f"{p} is not valid JSON: {e}") from e
        if isinstance(data, dict):
            data = data.get("questions")
        if not isinstance(data, list) or not all(isinstance(q, str) for q in data):
            raise QuestionsError(f"{p} must contain a JSON list of question strings")
        lines = data
    else:
        lines = [ln.strip() for ln in raw.splitlines()]
        lines = [ln for ln in lines if ln and not ln.startswith("#")]
    if business is not None or city is not None or category is not None:
        lines = [fill_placeholders(q, business or "", city or "", category or "") for q in lines]
    questions = dedupe(lines)
    if not questions:
        raise QuestionsError(f"{p} has no questions in it")
    return questions
