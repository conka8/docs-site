"""Rule-based, plain-English next steps from the audit numbers. No AI involved: same input, same advice."""

from __future__ import annotations

from .matching import normalize_domain

PRIORITY_ORDER = {"high": 0, "medium": 1, "low": 2}

# question keywords -> advice when NO provider mentioned the business for that kind of question
TOPIC_RULES = (
    (
        "hours",
        ("weekend", "open on", "open late", "hours", "saturday", "sunday", "emergency"),
        "Publish your opening hours everywhere",
        "When people asked about opening times (\"{q}\"), no AI named you. Put your exact hours, "
        "including weekends and holidays, on your website, Google Business Profile and every directory.",
    ),
    (
        "price",
        ("affordable", "cheap", "price", "cost", "budget", "insurance"),
        "Say what things cost",
        "When people asked about price (\"{q}\"), no AI named you. Add a pricing or \"what to expect\" "
        "page with starting prices, payment plans and insurance you accept, so AI tools have something to quote.",
    ),
    (
        "reviews",
        ("review", "trusted", "top rated", "best", "recommend"),
        "Get more (and more detailed) reviews",
        "For \"{q}\" and similar questions AI tools pick businesses with many recent, detailed reviews. "
        "Ask happy customers to mention the service they got and your city in their review.",
    ),
)


def _rec(rid: str, priority: str, title: str, detail: str) -> dict:
    return {"id": rid, "priority": priority, "title": title, "detail": detail}


def _names(items: list[str], limit: int = 5) -> str:
    items = list(items)[:limit]
    if len(items) <= 1:
        return "".join(items)
    return ", ".join(items[:-1]) + " and " + items[-1]


def build_recommendations(result: dict) -> list[dict]:
    """``result`` needs: business, website, scores (from compute_scores), rows."""
    business = result["business"]
    website = normalize_domain(result.get("website", ""))
    scores = result["scores"]
    rows = result.get("rows", [])
    recs: list[dict] = []
    vis = scores.get("visibility")
    answered = [p for p in scores["providers"] if p["scored"]]

    if vis is None:
        recs.append(
            _rec(
                "not_measured",
                "high",
                "We couldn't get answers from any AI tool",
                "Every AI call failed, so nothing was measured. Check the API keys and try again "
                "(the errors are listed under each AI tool below).",
            )
        )
    elif vis == 0:
        recs.append(
            _rec(
                "invisible",
                "high",
                f"AI assistants don't mention {business} yet",
                f"In {scores['scored_answers']} answers to questions your customers ask, none named you. "
                "The steps below are what usually changes that.",
            )
        )

    # review / directory sites the AIs leaned on while recommending other businesses
    dirs = [d for d in scores.get("top_domains", []) if d["is_directory"] and d["answers"] > d["with_business_mentioned"]]
    if dirs:
        recs.append(
            _rec(
                "get_listed",
                "high" if (vis or 0) < 50 else "medium",
                f"Get listed and reviewed on {_names([d['domain'] for d in dirs])}",
                "The AI tools used these sites as sources when they answered without naming you. "
                "Claim your profile on each one, fill in every field (hours, services, photos, website) "
                "and ask happy customers to leave a review there.",
            )
        )

    if website:
        cited = any(d["is_your_site"] for d in scores.get("top_domains", [])) or any(
            p.get("website_cited") for p in scores["providers"]
        )
        if not cited and answered:
            recs.append(
                _rec(
                    "website_not_cited",
                    "medium",
                    "Make your website easy for AI to quote",
                    f"None of the answers used {website} as a source. Add an FAQ page that answers the "
                    "questions in this report word for word, add LocalBusiness and FAQPage schema markup, "
                    "and write your city, services, hours and prices as plain text (not only in images).",
                )
            )
    else:
        recs.append(
            _rec(
                "no_website",
                "low",
                "Add your website to the next audit",
                "No website was given, so we couldn't check whether AI tools use it as a source. "
                "Run the audit again with --website yourdomain.com.",
            )
        )

    mentioning = [p for p in answered if p["mentioned"]]
    missing = [p for p in answered if not p["mentioned"]]
    if mentioning and missing:
        if len(mentioning) == 1:
            title = f"You only show up on {mentioning[0]['label']}"
        else:
            title = f"You don't show up on {_names([p['label'] for p in missing])}"
        recs.append(
            _rec(
                "missing_providers",
                "medium",
                title,
                f"{_names([p['label'] for p in missing])} never named you. Each AI tool reads different "
                "sources, so being listed on more review sites and directories (with the same name, "
                "address and phone everywhere) helps you show up on all of them.",
            )
        )

    avg = scores.get("avg_position")
    if avg is not None and avg > 3:
        recs.append(
            _rec(
                "low_position",
                "medium",
                "You're mentioned, but not near the top",
                f"When AI tools list options you come in at #{avg:g} on average. Businesses at the top "
                "usually have more reviews, more recent reviews and clearer service pages.",
            )
        )

    board = scores.get("leaderboard", [])
    biz = next((e for e in board if e["is_business"]), None)
    rivals = [e for e in board if not e["is_business"]]
    if rivals and biz is not None and rivals[0]["mentions"] > biz["mentions"] and (rivals[0]["share"] or 0) >= 30:
        top = rivals[0]
        recs.append(
            _rec(
                "competitor_leads",
                "medium",
                f"{top['name']} is the name AI gives most often",
                f"{top['name']} showed up in {top['share']:g}% of answers, you in {biz['share'] or 0:g}%. "
                "Look at what they do well: number of Google reviews, the directories they are on, and "
                "the questions their website answers.",
            )
        )

    # question topics where nobody named the business
    missed: dict[str, list[str]] = {}
    by_question: dict[str, list[dict]] = {}
    for r in rows:
        if not r.get("error") and r.get("kind", "discovery") == "discovery":
            by_question.setdefault(r["question"], []).append(r)
    for q, rs in by_question.items():
        if any(r["analysis"]["mentioned"] for r in rs):
            continue
        low = q.lower()
        for topic, words, _title, _detail in TOPIC_RULES:
            if any(w in low for w in words):
                missed.setdefault(topic, []).append(q)
                break
    for topic, _words, title, detail in TOPIC_RULES:
        if topic in missed:
            recs.append(_rec(f"topic_{topic}", "medium", title, detail.format(q=missed[topic][0])))

    labels = {p["name"]: p["label"] for p in scores["providers"]}
    unknown = sorted({labels.get(r["provider"], r.get("label", r["provider"])) for r in rows
                      if not r.get("error") and r.get("kind") == "brand" and r["analysis"].get("unknown")})
    if unknown:
        recs.append(
            _rec(
                "unknown_brand",
                "high",
                f"Some AI tools don't know who {business} is",
                f"Asked about you by name, {_names(unknown)} said they had no information. Make sure your "
                "business name, address and phone number are written exactly the same on your website, "
                "Google Business Profile and directories, and that your site says what you do and where.",
            )
        )

    for p in scores["providers"]:
        if p["errors"]:
            msg = p["error_messages"][0] if p["error_messages"] else "unknown error"
            recs.append(
                _rec(
                    f"error_{p['name']}",
                    "low",
                    f"{p['label']} could not be fully checked",
                    f"{p['errors']} of {p['asked']} questions failed ({msg}). Those answers are left out "
                    "of the scores. Run the audit again later to include them.",
                )
            )

    if vis is not None and vis >= 70:
        recs.append(
            _rec(
                "keep_going",
                "low",
                "Keep it up and check again monthly",
                "AI tools already recommend you often. AI answers change as new reviews and pages appear, "
                "so re-run this audit every month to catch drops early.",
            )
        )
    if not recs:
        recs.append(
            _rec(
                "monitor",
                "low",
                "Check again next month",
                "Nothing urgent stood out. Re-run this audit monthly to track changes.",
            )
        )
    recs.sort(key=lambda r: PRIORITY_ORDER.get(r["priority"], 9))
    return recs
