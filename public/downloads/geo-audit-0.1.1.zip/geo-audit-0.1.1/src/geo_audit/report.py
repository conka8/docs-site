"""Report writers: self-contained white-label HTML (print it to PDF), JSON, Markdown and CSV."""

from __future__ import annotations

import csv
import datetime as _dt
import io
import json
import re
from dataclasses import dataclass
from html import escape

FORMATS = ("html", "json", "md", "csv")
DEFAULT_COLOR = "#2563eb"
_COLOR_RE = re.compile(r"^#(?:[0-9a-fA-F]{3}|[0-9a-fA-F]{6})$")
EXCERPT_CHARS = 600
DEMO_NOTICE = "Demo data: these answers are made up by the built-in demo provider, not real AI answers."


@dataclass
class Branding:
    brand_name: str = ""
    brand_color: str = DEFAULT_COLOR
    logo_url: str = ""
    agency_contact: str = ""

    @property
    def color(self) -> str:
        c = (self.brand_color or "").strip()
        return c if _COLOR_RE.match(c) else DEFAULT_COLOR

    @property
    def safe_logo(self) -> str:
        u = (self.logo_url or "").strip()
        return u if u.lower().startswith(("https://", "http://", "data:image/")) else ""


def valid_color(value: str) -> bool:
    return bool(_COLOR_RE.match((value or "").strip()))


def format_from_path(path: str, default: str = "html") -> str:
    ext = path.rsplit(".", 1)[-1].lower() if "." in path else ""
    ext = {"htm": "html", "markdown": "md"}.get(ext, ext)
    return ext if ext in FORMATS else default


def excerpt(text: str, limit: int = EXCERPT_CHARS) -> str:
    t = (text or "").strip()
    if len(t) <= limit:
        return t
    cut = t[:limit].rsplit(" ", 1)[0]
    return cut + " ..."


def _fmt_pct(v) -> str:
    return "n/a" if v is None else f"{v:g}%"


def _fmt_pos(v) -> str:
    return "-" if v is None else f"#{v:g}"


def _date(result: dict) -> str:
    try:
        return _dt.datetime.fromisoformat(result["generated_at"]).strftime("%B %d, %Y").replace(" 0", " ")
    except (KeyError, ValueError):
        return result.get("generated_at", "")


def is_demo(result: dict) -> bool:
    """True when any answer came from the fake provider (older JSON files have no "demo" field)."""
    if result.get("demo"):
        return True
    return any(str(p.get("name", "")).startswith("fake") for p in result.get("providers", []))


# ---------------------------------------------------------------- JSON

def render_json(result: dict, branding: Branding | None = None) -> str:
    data = dict(result)
    data["demo"] = is_demo(result)
    if branding is not None:
        data["branding"] = {
            "brand_name": branding.brand_name,
            "brand_color": branding.color,
            "logo_url": branding.safe_logo,
            "agency_contact": branding.agency_contact,
        }
    return json.dumps(data, indent=2, ensure_ascii=False) + "\n"


# ---------------------------------------------------------------- CSV (one line per question x AI tool)

CSV_FIELDS = (
    "question", "question_type", "ai_tool", "model", "mentioned", "position", "competitors",
    "cited_domains", "website_cited", "error", "answer",
)


def render_csv(result: dict, branding: Branding | None = None) -> str:
    buf = io.StringIO()
    w = csv.writer(buf, lineterminator="\n")
    w.writerow(CSV_FIELDS)
    for r in result["rows"]:
        a = r["analysis"]
        w.writerow(
            [
                r["question"],
                r.get("kind", ""),
                r.get("label", r["provider"]),
                r.get("model", ""),
                "error" if r.get("error") else ("yes" if a["mentioned"] else "no"),
                a.get("position") or "",
                "; ".join(a.get("competitors", [])),
                "; ".join(a.get("domains", [])),
                "yes" if a.get("website_cited") else "no",
                r.get("error") or "",
                (r.get("text") or "").replace("\r", " "),
            ]
        )
    return buf.getvalue()


# ---------------------------------------------------------------- Markdown

def _md(text) -> str:
    return str(text).replace("|", "\\|").replace("\n", " ")


def render_markdown(result: dict, branding: Branding | None = None) -> str:
    b = branding or Branding()
    s = result["scores"]
    out = []
    if is_demo(result):
        out.append(f"> **{DEMO_NOTICE}**\n")
    title = f"# AI Visibility Report: {result['business']}"
    out.append(title)
    meta = f"{result['category']} in {result['city']}"
    if result.get("website"):
        meta += f" | {result['website']}"
    out.append(f"\n{meta}  \n{_date(result)}" + (f" | Prepared by {b.brand_name}" if b.brand_name else ""))
    out.append(
        f"\n## Score: {_fmt_pct(s['visibility'])} (grade {s['grade']})\n\n{s['grade_label']}. "
        f"Mentioned in {s['mentioned_answers']} of {s['scored_answers']} AI answers to customer questions."
    )
    out.append(
        f"\n- Average position when listed: {_fmt_pos(s['avg_position'])}"
        f"\n- Share of voice vs top competitors: {_fmt_pct(s['share_of_voice'])}"
    )
    out.append("\n## By AI tool\n\n| AI tool | Model | Mentioned | Visibility | Avg position | Errors |\n|---|---|---|---|---|---|")
    for p in s["providers"]:
        out.append(
            f"| {_md(p['label'])} | {_md(p['model'])} | {p['mentioned']}/{p['scored']} | {_fmt_pct(p['visibility'])} "
            f"| {_fmt_pos(p['avg_position'])} | {p['errors']} |"
        )
    out.append("\n## What to do next\n")
    for i, r in enumerate(result.get("recommendations", []), 1):
        out.append(f"{i}. **{_md(r['title'])}** ({r['priority']}): {_md(r['detail'])}")
    out.append("\n## Who AI recommends\n\n| Rank | Business | Mentioned in | Avg position |\n|---|---|---|---|")
    for e in s["leaderboard"][:10]:
        name = f"**{_md(e['name'])} (you)**" if e["is_business"] else _md(e["name"])
        out.append(f"| {e['rank']} | {name} | {_fmt_pct(e['share'])} | {_fmt_pos(e['avg_position'])} |")
    if s["top_domains"]:
        out.append("\n## Sources the AI tools used\n\n| Website | Answers citing it |\n|---|---|")
        for d in s["top_domains"]:
            out.append(f"| {_md(d['domain'])} | {d['answers']} |")
    out.append("\n## Question by question\n")
    for q in result["questions"]:
        out.append(f"### {_md(q['text'])}\n")
        for r in [r for r in result["rows"] if r["question"] == q["text"]]:
            a = r["analysis"]
            if r.get("error"):
                status = f"could not check ({_md(r['error'])})"
            elif a["mentioned"]:
                status = "mentioned" + (f" at #{a['position']}" if a.get("position") else "")
            else:
                status = "not mentioned"
            comp = f"; others named: {_md(', '.join(a['competitors']))}" if a.get("competitors") else ""
            out.append(f"- **{_md(r.get('label', r['provider']))}**: {status}{comp}")
        out.append("")
    out.append("---\n" + _method_text(result))
    if b.agency_contact:
        out.append(f"\nContact: {b.agency_contact}")
    return "\n".join(out) + "\n"


def _method_text(result: dict) -> str:
    n_q = len(result["questions"])
    labels = ", ".join(p["label"] for p in result["providers"])
    return (
        f"How this was measured: on {_date(result)} we asked {labels} {n_q} questions a customer might ask. "
        "The answers come from each company's API (developer access), not from the ChatGPT, Perplexity, Gemini "
        "or Claude apps. The apps can show different answers, because they add personalization, the person's "
        "location and different web search settings. "
        "A business counts as mentioned when its name appears in the answer (ignoring case, punctuation and "
        "endings like LLC or Group, allowing small typos) or its website is named. Visibility counts only "
        "questions that don't name the business. AI answers also change from day to day, "
        "so treat this as a snapshot."
    )


# ---------------------------------------------------------------- HTML

_CSS = """
:root{--brand:%(color)s;--ink:#1f2937;--muted:#6b7280;--line:#e5e7eb;--good:#15803d;--bad:#b91c1c;--warn:#b45309;--bg:#ffffff;--soft:#f9fafb}
*{box-sizing:border-box}
body{margin:0;background:var(--bg);color:var(--ink);font:15px/1.5 -apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Helvetica,Arial,sans-serif}
.wrap{max-width:960px;margin:0 auto;padding:24px 16px 48px}
header{display:flex;align-items:center;gap:16px;border-bottom:4px solid var(--brand);padding-bottom:16px;flex-wrap:wrap}
header img{max-height:56px;max-width:200px}
header .who{flex:1;min-width:220px}
header h1{margin:0;font-size:26px;line-height:1.2}
header .sub{color:var(--muted)}
.brand{font-weight:600;color:var(--brand)}
.hero{display:flex;gap:24px;align-items:center;margin:24px 0;flex-wrap:wrap}
.score{width:150px;height:150px;border-radius:50%%;border:10px solid var(--brand);display:flex;flex-direction:column;align-items:center;justify-content:center;flex:none}
.score .num{font-size:38px;font-weight:700;line-height:1}
.score .lbl{font-size:12px;color:var(--muted);text-transform:uppercase;letter-spacing:.05em}
.hero .text{flex:1;min-width:240px}
.hero h2{margin:0 0 6px;font-size:22px}
.kpis{display:flex;gap:12px;flex-wrap:wrap;margin-top:12px}
.kpi{background:var(--soft);border:1px solid var(--line);border-radius:8px;padding:8px 12px;min-width:140px}
.kpi b{display:block;font-size:20px}
.kpi span{font-size:12px;color:var(--muted)}
h2.sec{font-size:19px;margin:32px 0 10px;padding-bottom:4px;border-bottom:2px solid var(--line)}
table{width:100%%;border-collapse:collapse;font-size:14px}
th,td{text-align:left;padding:7px 8px;border-bottom:1px solid var(--line);vertical-align:top}
th{background:var(--soft);font-weight:600}
tr.you td{background:#fefce8;font-weight:600}
.bar{background:var(--line);border-radius:4px;height:8px;width:100px;display:inline-block;vertical-align:middle;margin-right:6px}
.bar i{display:block;height:8px;border-radius:4px;background:var(--brand)}
.yes{color:var(--good);font-weight:600}.no{color:var(--bad);font-weight:600}.err{color:var(--warn);font-weight:600}
.recs{list-style:none;padding:0;margin:0}
.recs li{border:1px solid var(--line);border-left:5px solid var(--brand);border-radius:6px;padding:10px 14px;margin:10px 0}
.recs li.high{border-left-color:var(--bad)}.recs li.low{border-left-color:var(--muted)}
.recs .t{font-weight:600}.tag{font-size:11px;text-transform:uppercase;letter-spacing:.05em;color:var(--muted);margin-left:6px}
.q{border:1px solid var(--line);border-radius:8px;margin:14px 0;padding:10px 14px}
.q h3{margin:0 0 6px;font-size:16px}
.q .kind{font-size:11px;color:var(--muted);text-transform:uppercase;letter-spacing:.05em}
.ans{border-top:1px dashed var(--line);padding:8px 0}
.ans .head{font-size:14px}
.excerpt{white-space:pre-wrap;background:var(--soft);border-radius:6px;padding:8px 10px;font-size:13px;margin-top:6px;overflow-wrap:anywhere}
.small{font-size:13px;color:var(--muted)}
.demo{background:#fef3c7;border:2px solid var(--warn);border-radius:8px;padding:10px 14px;margin:0 0 16px;font-weight:600}
footer{margin-top:36px;border-top:1px solid var(--line);padding-top:12px;font-size:13px;color:var(--muted)}
@media print{
  body{font-size:12px}.wrap{padding:0;max-width:none}
  .q,.recs li,tr,.hero{break-inside:avoid;page-break-inside:avoid}
  h2.sec{break-after:avoid;page-break-after:avoid}
  .score,.bar i,tr.you td,th,.demo{-webkit-print-color-adjust:exact;print-color-adjust:exact}
  a{color:inherit;text-decoration:none}
}
"""


def _e(value) -> str:
    return escape("" if value is None else str(value), quote=True)


def _bar(v) -> str:
    width = 0 if v is None else max(0, min(100, v))
    return f'<span class="bar"><i style="width:{width:g}%"></i></span>'


def render_html(result: dict, branding: Branding | None = None) -> str:
    b = branding or Branding()
    s = result["scores"]
    biz = result["business"]
    parts: list[str] = []
    add = parts.append
    title = f"AI Visibility Report: {biz}"
    add("<!doctype html>\n<html lang=\"en\"><head><meta charset=\"utf-8\">")
    add('<meta name="viewport" content="width=device-width, initial-scale=1">')
    add(f"<title>{_e(title)}</title><style>{_CSS % {'color': b.color}}</style></head><body><div class=\"wrap\">")

    if is_demo(result):
        add(f'<div class="demo">{_e(DEMO_NOTICE)}</div>')

    # header
    add("<header>")
    if b.safe_logo:
        add(f'<img src="{_e(b.safe_logo)}" alt="{_e(b.brand_name or "logo")}">')
    add('<div class="who">')
    add(f"<h1>AI Visibility Report: {_e(biz)}</h1>")
    sub = f"{_e(result['category'])} in {_e(result['city'])}"
    if result.get("website"):
        sub += f" &middot; {_e(result['website'])}"
    add(f'<div class="sub">{sub} &middot; {_e(_date(result))}</div>')
    if b.brand_name:
        add(f'<div class="sub">Prepared by <span class="brand">{_e(b.brand_name)}</span></div>')
    add("</div></header>")

    # hero
    add('<section class="hero">')
    add(f'<div class="score"><div class="num">{_e(_fmt_pct(s["visibility"]))}</div><div class="lbl">AI visibility</div></div>')
    add('<div class="text">')
    add(f"<h2>Grade {_e(s['grade'])}: {_e(s['grade_label'])}</h2>")
    add(
        f"<p>We asked {len(result['providers'])} AI assistant(s) {len(result['questions'])} questions your customers "
        f"ask. {_e(biz)} was named in <b>{s['mentioned_answers']} of {s['scored_answers']}</b> answers "
        "to questions that didn't mention you by name.</p>"
    )
    add('<div class="kpis">')
    add(f'<div class="kpi"><b>{_e(_fmt_pos(s["avg_position"]))}</b><span>average spot when listed</span></div>')
    add(f'<div class="kpi"><b>{_e(_fmt_pct(s["share_of_voice"]))}</b><span>share of voice vs top competitors</span></div>')
    add(f'<div class="kpi"><b>{len(s["providers_mentioning"])} of {len(s["providers"])}</b><span>AI tools that mention you</span></div>')
    add("</div></div></section>")

    # per provider
    add('<h2 class="sec">Your score in each AI tool</h2><table><thead><tr><th>AI tool</th><th>Model</th>'
        "<th>Mentioned</th><th>Visibility</th><th>Avg. spot</th><th>Status</th></tr></thead><tbody>")
    for p in s["providers"]:
        if p["errors"] and not p["answered"]:
            status = f'<span class="err">Could not check: {_e(p["error_messages"][0] if p["error_messages"] else "error")}</span>'
        elif p["errors"]:
            status = f'<span class="err">{p["errors"]} question(s) failed</span>'
        else:
            status = '<span class="yes">OK</span>'
        add(
            f"<tr><td>{_e(p['label'])}</td><td>{_e(p['model'])}</td><td>{p['mentioned']} of {p['scored']}</td>"
            f"<td>{_bar(p['visibility'])}{_e(_fmt_pct(p['visibility']))}</td><td>{_e(_fmt_pos(p['avg_position']))}</td>"
            f"<td>{status}</td></tr>"
        )
    add("</tbody></table>")

    # recommendations
    add('<h2 class="sec">What to do next</h2><ol class="recs">')
    for r in result.get("recommendations", []):
        add(
            f'<li class="{_e(r["priority"])}"><div class="t">{_e(r["title"])}<span class="tag">{_e(r["priority"])} priority</span></div>'
            f"<div>{_e(r['detail'])}</div></li>"
        )
    add("</ol>")

    # leaderboard
    add('<h2 class="sec">Who AI recommends</h2>')
    add('<p class="small">Businesses named in the same answers, ranked by how often they came up.</p>')
    add("<table><thead><tr><th>#</th><th>Business</th><th>Mentioned in</th><th>Avg. spot</th><th>AI tools</th></tr></thead><tbody>")
    for e in s["leaderboard"][:15]:
        cls = ' class="you"' if e["is_business"] else ""
        name = _e(e["name"]) + (" (you)" if e["is_business"] else "")
        add(
            f"<tr{cls}><td>{e['rank']}</td><td>{name}</td><td>{_bar(e['share'])}{_e(_fmt_pct(e['share']))}</td>"
            f"<td>{_e(_fmt_pos(e['avg_position']))}</td><td>{_e(', '.join(e['providers']) or '-')}</td></tr>"
        )
    add("</tbody></table>")

    # domains
    add('<h2 class="sec">Websites the AI tools used as sources</h2>')
    if s["top_domains"]:
        add("<table><thead><tr><th>Website</th><th>Answers citing it</th><th>Type</th><th>AI tools</th></tr></thead><tbody>")
        for d in s["top_domains"]:
            kind = "Your website" if d["is_your_site"] else ("Review / listing site" if d["is_directory"] else "Other")
            add(
                f"<tr><td>{_e(d['domain'])}</td><td>{d['answers']}</td><td>{_e(kind)}</td>"
                f"<td>{_e(', '.join(d['providers']))}</td></tr>"
            )
        add("</tbody></table>")
    else:
        add('<p class="small">The AI tools did not cite any websites in their answers.</p>')

    # per question
    add('<h2 class="sec">Question by question</h2>')
    for q in result["questions"]:
        kind = "names your business" if q["kind"] == "brand" else "customer question"
        add(f'<div class="q"><div class="kind">{_e(kind)}</div><h3>{_e(q["text"])}</h3>')
        for r in [r for r in result["rows"] if r["question"] == q["text"]]:
            a = r["analysis"]
            if r.get("error"):
                status = f'<span class="err">Could not check</span> <span class="small">{_e(r["error"])}</span>'
            elif a["mentioned"]:
                pos = f" at #{a['position']} of {a['list_size']}" if a.get("position") else ""
                status = f'<span class="yes">Mentioned{_e(pos)}</span>'
            else:
                status = '<span class="no">Not mentioned</span>'
            add(f'<div class="ans"><div class="head"><b>{_e(r.get("label", r["provider"]))}</b>: {status}</div>')
            if a.get("competitors"):
                add(f'<div class="small">Also named: {_e(", ".join(a["competitors"]))}</div>')
            if a.get("domains"):
                add(f'<div class="small">Sources: {_e(", ".join(a["domains"][:8]))}</div>')
            if r.get("text"):
                add(f'<div class="excerpt">{_e(excerpt(r["text"]))}</div>')
            add("</div>")
        add("</div>")

    # footer
    add(f"<footer><p><b>How this was measured.</b> {_e(_method_text(result))}</p>")
    add(f"<p>Generated {_e(_date(result))} with geo-audit {_e(result.get('version', ''))}.</p>")
    if b.brand_name or b.agency_contact:
        who = _e(b.brand_name) if b.brand_name else ""
        contact = _e(b.agency_contact) if b.agency_contact else ""
        add(f"<p>{who}{' &middot; ' if who and contact else ''}{contact}</p>")
    add("</footer></div></body></html>\n")
    return "\n".join(parts)


RENDERERS = {"html": render_html, "json": render_json, "md": render_markdown, "csv": render_csv}


def render(result: dict, fmt: str = "html", branding: Branding | None = None) -> str:
    if fmt not in RENDERERS:
        raise ValueError(f"unknown format '{fmt}'. Choose from: {', '.join(FORMATS)}")
    return RENDERERS[fmt](result, branding)
