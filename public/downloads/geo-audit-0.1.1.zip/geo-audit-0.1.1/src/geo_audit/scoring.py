"""Turn analysed answers into scores: visibility %, average position, share of voice, leaderboard, domains.

A *row* is one (question, provider) pair as a dict:
``{"question", "kind", "provider", "label", "model", "text", "citations", "error", "analysis": {...}}``.
Rows with an ``error`` are left out of every percentage (they are reported separately).

Visibility only counts "discovery" questions (the ones that don't name the business), because
an answer to "Is Smile Dental any good?" will repeat the name whether or not the AI knows it.
If every question names the business, all answers are used.
"""

from __future__ import annotations

from .matching import DEFAULT_THRESHOLD, names_match, normalize_domain, domain_matches

# Review / listing sites: being cited here means "get listed and reviewed there" is good advice.
DIRECTORY_DOMAINS = (
    "yelp.com", "google.com", "maps.google.com", "healthgrades.com", "zocdoc.com", "vitals.com",
    "webmd.com", "bbb.org", "angi.com", "angieslist.com", "homeadvisor.com", "thumbtack.com",
    "houzz.com", "yellowpages.com", "facebook.com", "nextdoor.com", "tripadvisor.com",
    "opentable.com", "avvo.com", "findlaw.com", "justia.com", "lawyers.com", "martindale.com",
    "realtor.com", "zillow.com", "trustpilot.com", "birdeye.com", "care.com", "doctor.com",
    "ratemds.com", "superpages.com", "mapquest.com", "foursquare.com", "expertise.com",
    "threebestrated.com", "bark.com", "porch.com", "reddit.com", "instagram.com", "linkedin.com",
    "usnews.com", "sharecare.com", "opencare.com", "1-800-dentist.com", "realself.com",
    "groupon.com", "doordash.com", "ubereats.com", "grubhub.com",
)


def is_directory(domain: str) -> bool:
    return any(domain_matches(domain, d) for d in DIRECTORY_DOMAINS)


def pct(part: int, whole: int) -> float | None:
    return round(100.0 * part / whole, 1) if whole else None


def _avg(values: list[int]) -> float | None:
    return round(sum(values) / len(values), 1) if values else None


def ok_rows(rows: list[dict]) -> list[dict]:
    return [r for r in rows if not r.get("error")]


def scored_rows(rows: list[dict]) -> list[dict]:
    """Successful discovery answers (or all successful answers if there are no discovery questions)."""
    good = ok_rows(rows)
    discovery = [r for r in good if r.get("kind", "discovery") == "discovery"]
    if discovery or not good:
        return discovery
    return good


def grade(visibility: float | None) -> tuple[str, str]:
    """(letter, plain-English label) for the headline."""
    if visibility is None:
        return "?", "Not measured"
    if visibility >= 70:
        return "A", "Strong: AI assistants recommend you often"
    if visibility >= 50:
        return "B", "Good: you show up in about half the answers"
    if visibility >= 30:
        return "C", "Fair: you show up sometimes"
    if visibility >= 10:
        return "D", "Weak: you rarely show up"
    return "F", "Invisible: AI assistants don't recommend you"


def provider_scores(rows: list[dict], providers: list[dict]) -> list[dict]:
    """One summary per provider, in the given provider order."""
    out = []
    for p in providers:
        mine = [r for r in rows if r["provider"] == p["name"]]
        scored = scored_rows(mine)
        mentioned = [r for r in scored if r["analysis"]["mentioned"]]
        positions = [r["analysis"]["position"] for r in mentioned if r["analysis"].get("position")]
        brand = [r for r in ok_rows(mine) if r.get("kind") == "brand"]
        errors = [r["error"] for r in mine if r.get("error")]
        out.append(
            {
                "name": p["name"],
                "label": p.get("label", p["name"]),
                "model": p.get("model", ""),
                "asked": len(mine),
                "answered": len(ok_rows(mine)),
                "scored": len(scored),
                "mentioned": len(mentioned),
                "visibility": pct(len(mentioned), len(scored)),
                "avg_position": _avg(positions),
                "brand_questions": len(brand),
                "brand_known": sum(1 for r in brand if not r["analysis"].get("unknown")),
                "errors": len(errors),
                "error_messages": sorted(set(errors)),
                "website_cited": sum(1 for r in ok_rows(mine) if r["analysis"].get("website_cited")),
            }
        )
    return out


def leaderboard(rows: list[dict], business: str, threshold: float = DEFAULT_THRESHOLD) -> list[dict]:
    """Business + competitors ranked by how many scored answers mention them."""
    scored = scored_rows(rows)
    total = len(scored)
    biz_rows = [r for r in scored if r["analysis"]["mentioned"]]
    entries: list[dict] = []
    for r in scored:
        positions = r["analysis"].get("competitor_positions") or {}
        for name in r["analysis"].get("competitors", []):
            entry = next((e for e in entries if names_match(e["name"], name, threshold)), None)
            if entry is None:
                entry = {"name": name, "is_business": False, "answers": set(), "positions": [], "providers": set()}
                entries.append(entry)
            key = (r["provider"], r["question"])
            if key not in entry["answers"]:
                entry["answers"].add(key)
                if positions.get(name):
                    entry["positions"].append(positions[name])
            entry["providers"].add(r.get("label", r["provider"]))
    board = [
        {
            "name": business,
            "is_business": True,
            "mentions": len(biz_rows),
            "share": pct(len(biz_rows), total),
            "avg_position": _avg([r["analysis"]["position"] for r in biz_rows if r["analysis"].get("position")]),
            "providers": sorted({r.get("label", r["provider"]) for r in biz_rows}),
        }
    ]
    for e in entries:
        board.append(
            {
                "name": e["name"],
                "is_business": False,
                "mentions": len(e["answers"]),
                "share": pct(len(e["answers"]), total),
                "avg_position": _avg(e["positions"]),
                "providers": sorted(e["providers"]),
            }
        )
    board.sort(key=lambda e: (-e["mentions"], e["avg_position"] if e["avg_position"] is not None else 99, not e["is_business"], e["name"].lower()))
    for i, e in enumerate(board, 1):
        e["rank"] = i
    return board


def share_of_voice(board: list[dict], top_n: int = 5) -> float | None:
    """Business mentions / (business + top-N competitor mentions), in %."""
    biz = next((e for e in board if e["is_business"]), None)
    rivals = [e for e in board if not e["is_business"]][:top_n]
    biz_m = biz["mentions"] if biz else 0
    total = biz_m + sum(e["mentions"] for e in rivals)
    return pct(biz_m, total)


def top_domains(rows: list[dict], website: str = "", limit: int = 15) -> list[dict]:
    """Domains the AIs cited, by number of answers citing them."""
    site = normalize_domain(website)
    counts: dict[str, dict] = {}
    for r in ok_rows(rows):
        for d in set(r["analysis"].get("domains", [])):
            entry = counts.setdefault(d, {"domain": d, "answers": 0, "providers": set(), "mentioned_business": 0})
            entry["answers"] += 1
            entry["providers"].add(r.get("label", r["provider"]))
            if r["analysis"]["mentioned"]:
                entry["mentioned_business"] += 1
    out = []
    for e in counts.values():
        out.append(
            {
                "domain": e["domain"],
                "answers": e["answers"],
                "providers": sorted(e["providers"]),
                "is_directory": is_directory(e["domain"]),
                "is_your_site": bool(site) and domain_matches(e["domain"], site),
                "with_business_mentioned": e["mentioned_business"],
            }
        )
    out.sort(key=lambda e: (-e["answers"], e["domain"]))
    return out[:limit]


def compute_scores(rows: list[dict], providers: list[dict], business: str, website: str = "",
                   threshold: float = DEFAULT_THRESHOLD) -> dict:
    scored = scored_rows(rows)
    mentioned = [r for r in scored if r["analysis"]["mentioned"]]
    positions = [r["analysis"]["position"] for r in mentioned if r["analysis"].get("position")]
    per_provider = provider_scores(rows, providers)
    board = leaderboard(rows, business, threshold)
    visibility = pct(len(mentioned), len(scored))
    letter, label = grade(visibility)
    return {
        "visibility": visibility,
        "grade": letter,
        "grade_label": label,
        "scored_answers": len(scored),
        "mentioned_answers": len(mentioned),
        "total_answers": len(rows),
        "failed_answers": len([r for r in rows if r.get("error")]),
        "avg_position": _avg(positions),
        "share_of_voice": share_of_voice(board),
        "providers_mentioning": [p["label"] for p in per_provider if p["mentioned"]],
        "providers": per_provider,
        "leaderboard": board,
        "top_domains": top_domains(rows, website),
    }
