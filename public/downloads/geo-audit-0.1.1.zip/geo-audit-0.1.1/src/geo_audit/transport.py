"""Tiny HTTP layer on urllib behind an injectable transport, so tests never touch the network.

A transport is any callable ``transport(HttpRequest) -> HttpResponse``. It returns error
statuses as responses and raises ``TransportError`` only for network problems / timeouts.
"""

from __future__ import annotations

import json
import socket
import time
import urllib.error
import urllib.request
from dataclasses import dataclass, field
from typing import Any, Callable

from . import constants as C


@dataclass
class HttpRequest:
    method: str
    url: str
    headers: dict = field(default_factory=dict)
    body: bytes | None = None
    timeout: float = C.HTTP_TIMEOUT_SECONDS

    def json(self) -> Any:
        return json.loads(self.body.decode("utf-8")) if self.body else None


@dataclass
class HttpResponse:
    status: int
    body: str
    headers: dict = field(default_factory=dict)


class TransportError(Exception):
    """Network problem or timeout (no HTTP status)."""

    def __init__(self, message: str, timeout: bool = False):
        super().__init__(message)
        self.timeout = timeout


class ProviderError(Exception):
    """An AI provider call failed for good (bad key, bad request, retries used up...)."""

    def __init__(self, message: str, status: int | None = None):
        super().__init__(message)
        self.status = status


Transport = Callable[[HttpRequest], HttpResponse]
Sleep = Callable[[float], None]


def urllib_transport(req: HttpRequest) -> HttpResponse:
    """Default transport: a real HTTP call with urllib."""
    request = urllib.request.Request(req.url, data=req.body, headers=req.headers, method=req.method)
    try:
        with urllib.request.urlopen(request, timeout=req.timeout) as resp:  # noqa: S310
            body = resp.read().decode("utf-8", errors="replace")
            return HttpResponse(resp.status, body, dict(resp.headers.items()))
    except urllib.error.HTTPError as e:
        try:
            body = e.read().decode("utf-8", errors="replace")
        except Exception:  # pragma: no cover - defensive
            body = ""
        return HttpResponse(e.code, body, dict(e.headers.items()) if e.headers else {})
    except (socket.timeout, TimeoutError) as e:
        raise TransportError(f"timed out after {req.timeout:g}s calling {req.url}", timeout=True) from e
    except (urllib.error.URLError, OSError) as e:
        reason = getattr(e, "reason", e)
        is_timeout = isinstance(reason, (socket.timeout, TimeoutError))
        raise TransportError(f"could not reach {req.url}: {reason}", timeout=is_timeout) from e


def _retry_after(resp: HttpResponse) -> float | None:
    for k, v in (resp.headers or {}).items():
        if k.lower() == "retry-after":
            try:
                return max(0.0, min(float(v), C.HTTP_MAX_RETRY_AFTER_SECONDS))
            except ValueError:
                return None
    return None


def error_message(body: str) -> str:
    """Pull a readable message out of a provider's JSON error body."""
    try:
        data = json.loads(body)
    except (ValueError, TypeError):
        return (body or "").strip()[:300]
    if isinstance(data, list) and data:
        data = data[0]
    if isinstance(data, dict):
        err = data.get("error", data)
        if isinstance(err, dict):
            msg = err.get("message") or err.get("type") or err.get("status")
            if msg:
                return str(msg)[:300]
        elif isinstance(err, str):
            return err[:300]
        if data.get("message"):
            return str(data["message"])[:300]
    return (body or "").strip()[:300]


def post_json(
    url: str,
    payload: Any,
    headers: dict | None = None,
    *,
    transport: Transport | None = None,
    sleep: Sleep | None = None,
    timeout: float = C.HTTP_TIMEOUT_SECONDS,
    max_retries: int = C.HTTP_MAX_RETRIES,
    backoff: float = C.HTTP_BACKOFF_SECONDS,
) -> Any:
    """POST JSON and return the decoded JSON reply.

    Retries up to ``max_retries`` times on 429/5xx and on network errors/timeouts.
    Raises ``ProviderError`` when the call fails for good.
    """
    transport = transport or urllib_transport
    sleep = sleep if sleep is not None else time.sleep
    all_headers = {"Content-Type": "application/json", "User-Agent": C.USER_AGENT}
    all_headers.update(headers or {})
    body = json.dumps(payload).encode("utf-8")
    last_problem = "unknown error"
    last_status: int | None = None
    for attempt in range(max_retries + 1):
        req = HttpRequest("POST", url, dict(all_headers), body, timeout)
        try:
            resp = transport(req)
        except TransportError as e:
            last_problem = str(e)
            last_status = None
            if attempt < max_retries:
                sleep(backoff * (2**attempt))
                continue
            raise ProviderError(f"{last_problem} (gave up after {attempt + 1} tries)") from e
        if resp.status in C.RETRY_STATUSES:
            last_status = resp.status
            last_problem = f"HTTP {resp.status}: {error_message(resp.body)}"
            if attempt < max_retries:
                wait = _retry_after(resp)
                sleep(wait if wait is not None else backoff * (2**attempt))
                continue
            raise ProviderError(f"{last_problem} (gave up after {attempt + 1} tries)", status=resp.status)
        if resp.status >= 400:
            raise ProviderError(f"HTTP {resp.status}: {error_message(resp.body)}", status=resp.status)
        try:
            return json.loads(resp.body)
        except ValueError as e:
            raise ProviderError(f"the reply was not valid JSON: {resp.body[:200]!r}", status=resp.status) from e
    raise ProviderError(last_problem, status=last_status)  # pragma: no cover - loop always returns/raises
