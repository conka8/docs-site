from __future__ import annotations

import json
from pathlib import Path

import pytest

from geo_audit.transport import HttpRequest, HttpResponse, TransportError

FIXTURES = Path(__file__).parent / "fixtures"


def load_fixture(name: str) -> dict:
    return json.loads((FIXTURES / name).read_text(encoding="utf-8"))


class FakeTransport:
    """Returns queued responses in order (the last one repeats). Items can be
    HttpResponse, a dict (-> 200 JSON), or an Exception to raise."""

    def __init__(self, *responses):
        self.responses = list(responses)
        self.requests: list[HttpRequest] = []

    def __call__(self, req: HttpRequest) -> HttpResponse:
        self.requests.append(req)
        item = self.responses.pop(0) if len(self.responses) > 1 else self.responses[0]
        if isinstance(item, Exception):
            raise item
        if isinstance(item, HttpResponse):
            return item
        if callable(item):
            return item(req)
        return HttpResponse(200, json.dumps(item))


class SleepRecorder:
    def __init__(self):
        self.calls: list[float] = []

    def __call__(self, seconds: float) -> None:
        self.calls.append(seconds)


@pytest.fixture
def fixtures_dir() -> Path:
    return FIXTURES


@pytest.fixture
def sleep() -> SleepRecorder:
    return SleepRecorder()


@pytest.fixture(autouse=True)
def no_network(monkeypatch):
    """Any accidental real HTTP call fails the test."""

    def boom(*a, **k):  # pragma: no cover - only hit on a bug
        raise AssertionError("tests must not use the network")

    monkeypatch.setattr("urllib.request.urlopen", boom)


def http_error(status: int, message: str = "nope", headers: dict | None = None) -> HttpResponse:
    return HttpResponse(status, json.dumps({"error": {"message": message}}), headers or {})


def timeout_error() -> TransportError:
    return TransportError("timed out after 60s", timeout=True)
