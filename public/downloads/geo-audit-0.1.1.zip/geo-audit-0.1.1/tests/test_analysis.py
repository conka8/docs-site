import pytest

from geo_audit.analysis import analyze_answer, business_matcher, competitor_key, find_competitors

BIZ = "Smile Dental"
KW = {"city": "Fresno, CA", "category": "dentist"}

LIST_ANSWER = """Here are the best dentists in Fresno, CA:

1. **Valley Dental Care** - great reviews (4.9)
   - Address: 123 Main St
2. **Smile Dental Group, LLC** – family friendly
3. [Big Smile Dental](https://bigsmile.com) - cosmetic
4. Fresno Family Dentistry: open Saturdays

Sources: https://www.yelp.com/biz/x, healthgrades.com [1]
"""


def test_list_answer_mentioned_with_position_and_competitors():
    a = analyze_answer(LIST_ANSWER, BIZ, website="smiledental.com", **KW)
    assert a.mentioned and a.match == "list"
    assert a.position == 2 and a.list_size == 4
    assert a.competitors == ["Valley Dental Care", "Big Smile Dental", "Fresno Family Dentistry"]
    assert a.competitor_positions == {"Valley Dental Care": 1, "Big Smile Dental": 3, "Fresno Family Dentistry": 4}
    assert a.domains == ["bigsmile.com", "yelp.com", "healthgrades.com"]
    assert not a.website_cited and a.domain_mentions == 0


def test_partial_name_in_other_business_is_not_a_mention():
    text = "I recommend **Big Smile Dental** and **Valley Dental Care**. A smile is important."
    a = analyze_answer(text, BIZ, **KW)
    assert not a.mentioned
    assert a.position is None
    assert a.competitors == ["Big Smile Dental", "Valley Dental Care"]


def test_word_smile_alone_is_not_a_mention():
    a = analyze_answer("Smile! Most dentists in Fresno are great.", BIZ, **KW)
    assert not a.mentioned


def test_prose_mention_has_no_position():
    a = analyze_answer("Many people like Smile Dental Group LLC near downtown.", BIZ, **KW)
    assert a.mentioned and a.match == "exact" and a.position is None


def test_fuzzy_mention():
    a = analyze_answer("Try BrightSmile Dental downtown.", "Bright Smile Dental")
    assert a.mentioned and a.match == "fuzzy"


def test_list_with_location_suffix_and_heading_format():
    text = "### 1. Smile Dental of Fresno\nGreat.\n### 2. Valley Dental Care\nOk."
    a = analyze_answer(text, BIZ, **KW)
    assert a.mentioned and a.position == 1 and a.competitors == ["Valley Dental Care"]


def test_single_item_list_gives_no_position():
    a = analyze_answer("- **Smile Dental**: modern office", BIZ, **KW)
    assert a.mentioned and a.position is None and a.list_size == 1


def test_business_last_in_bulleted_list():
    text = "- **Valley Dental Care**\n- **Fresno Family Dentistry**\n- **Bright Teeth**\n- **Smile Dental**"
    assert analyze_answer(text, BIZ, **KW).position == 4


def test_domain_mention_counts_and_marks_mentioned():
    text = "You can book at www.smiledental.com or https://smiledental.com/book. Email info@smiledental.com"
    a = analyze_answer(text, BIZ, website="https://www.smiledental.com/", **KW)
    assert a.domain_mentions == 3
    assert a.mentioned and a.match == "domain"
    assert a.website_cited  # URL to the site in the answer


def test_domain_mention_when_name_also_present_keeps_name_match():
    a = analyze_answer("Smile Dental (smiledental.com) is good.", BIZ, website="smiledental.com", **KW)
    assert a.match == "exact" and a.domain_mentions == 1


def test_provider_citations_are_sources_and_website_cited():
    a = analyze_answer(
        "Valley Dental Care is popular.",
        BIZ,
        website="smiledental.com",
        citations=["https://smiledental.com/about", "https://www.yelp.com/x", "https://www.yelp.com/x"],
        **KW,
    )
    assert a.sources == ["https://smiledental.com/about", "https://www.yelp.com/x"]
    assert a.domains == ["smiledental.com", "yelp.com"]
    assert a.website_cited
    assert not a.mentioned  # citing the site isn't naming the business in the answer


def test_known_competitors_found_in_prose_and_canonical_spelling():
    text = "valley dental care and fresno family dentistry inc are both fine."
    a = analyze_answer(text, BIZ, known_competitors=["Valley Dental Care", "Fresno Family Dentistry", "Nobody Dental"], **KW)
    assert a.competitors == ["Valley Dental Care", "Fresno Family Dentistry"]


def test_known_competitor_spelling_wins_over_list_spelling():
    text = "1. Valley Dental Care LLC\n2. Bright Place Dental"
    comps = find_competitors(text, BIZ, known=["Valley Dental Care"], **KW)
    assert comps == ["Valley Dental Care", "Bright Place Dental"]


def test_generic_names_are_not_competitors():
    text = "1. **Fresno Dentists**\n2. **Valley Dental Care**\n- **Fresno**"
    assert find_competitors(text, BIZ, **KW) == ["Valley Dental Care"]


def test_business_itself_is_never_a_competitor():
    text = "1. Smile Dental Group\n2. Valley Dental Care\n3. Smile Dental of Fresno"
    assert find_competitors(text, BIZ, **KW) == ["Valley Dental Care"]


def test_brand_question_unknown_detection():
    a = analyze_answer("I don’t have specific information about Smile Dental.", BIZ, brand_question=True, **KW)
    assert a.unknown
    assert analyze_answer("", BIZ, brand_question=True).unknown
    assert not analyze_answer("Smile Dental has great reviews.", BIZ, brand_question=True).unknown
    assert not analyze_answer("I couldn't find it", BIZ).unknown  # only checked on brand questions


def test_empty_answer():
    a = analyze_answer("", BIZ, website="smiledental.com")
    assert not a.mentioned and a.competitors == [] and a.sources == [] and a.position is None


def test_to_dict_roundtrip():
    d = analyze_answer(LIST_ANSWER, BIZ, **KW).to_dict()
    assert d["position"] == 2 and isinstance(d["competitors"], list)


@pytest.mark.parametrize(
    "name,ok",
    [("Smile Dental of Fresno", True), ("Smile Dental Fresno CA", True), ("Smile Dental", True),
     ("Fresno", False), ("Big Smile Dental", False)],
)
def test_business_matcher(name, ok):
    assert business_matcher(BIZ, "Fresno, CA")(name) is ok


def test_competitor_key():
    assert competitor_key("The Valley Dental Group LLC") == "valley dental"
