import datetime as dt

import pytest

from geo_audit.audit import AuditInput, run_audit
from geo_audit.providers import AnthropicProvider, FakeProvider, OpenAIProvider

from conftest import FakeTransport, http_error, load_fixture

NOW = dt.datetime(2026, 10, 28, 12, 0, tzinfo=dt.timezone.utc)


def inp(**kw):
    base = dict(business="Smile Dental", city="Fresno, CA", category="dentist", website="www.smiledental.com",
                competitors=["Valley Dental Care"])
    base.update(kw)
    return AuditInput(**base)


def test_run_audit_with_fake_providers_full_shape():
    answers = {
        "best dentist": "1. **Valley Dental Care**\n2. **Smile Dental**\nhttps://www.yelp.com/x",
        "trusted": "Valley Dental Care is trusted.",
    }
    ps = [FakeProvider("fake", answers=answers), FakeProvider("fake-b", answers=answers)]
    msgs = []
    r = run_audit(inp(questions=["What is the best dentist in Fresno?", "Most trusted dentist?", "Is Smile Dental good?"]),
                  ps, progress=msgs.append, now=NOW)
    assert r["generated_at"] == "2026-10-28T12:00:00+00:00"
    assert r["website"] == "smiledental.com"
    assert [q["kind"] for q in r["questions"]] == ["discovery", "discovery", "brand"]
    assert len(r["rows"]) == 6
    first = r["rows"][0]
    assert first["analysis"]["mentioned"] and first["analysis"]["position"] == 2
    assert first["analysis"]["competitors"] == ["Valley Dental Care"]
    s = r["scores"]
    assert s["visibility"] == 50.0 and s["scored_answers"] == 4
    assert r["recommendations"]
    assert any("Asking Demo AI (fake)" in m for m in msgs)


def test_partial_provider_failure_is_recorded_not_fatal(sleep):
    good = FakeTransport(load_fixture("openai_response.json"))
    bad = FakeTransport(http_error(500, "overloaded"))
    ps = [
        OpenAIProvider("k", transport=good, sleep=sleep),
        AnthropicProvider("k", transport=bad, sleep=sleep),
    ]
    r = run_audit(inp(questions=["Best dentist in Fresno?", "Top rated dentist near Fresno?"]), ps, now=NOW)
    errs = [row for row in r["rows"] if row["error"]]
    assert len(errs) == 2 and all(row["provider"] == "anthropic" for row in errs)
    assert "overloaded" in errs[0]["error"]
    by = {p["name"]: p for p in r["scores"]["providers"]}
    assert by["openai"]["visibility"] == 100.0  # "Smile Dental Group" is listed in the fixture
    assert by["anthropic"]["visibility"] is None and by["anthropic"]["errors"] == 2
    assert r["scores"]["visibility"] == 100.0
    assert any(rec["id"] == "error_anthropic" for rec in r["recommendations"])
    assert len(bad.requests) == 6  # 2 questions x (1 + 2 retries)
    assert sleep.calls  # backoff was requested, not actually slept


def test_unexpected_exception_in_provider_is_caught():
    class Broken(FakeProvider):
        def ask(self, question):
            raise RuntimeError()

    r = run_audit(inp(questions=["q?"]), [Broken()], now=NOW)
    assert r["rows"][0]["error"] == "RuntimeError"
    assert r["scores"]["visibility"] is None


def test_generated_questions_by_default():
    r = run_audit(inp(max_questions=6), [FakeProvider(business="Smile Dental", city="Fresno, CA", category="dentist")], now=NOW)
    assert len(r["questions"]) == 6
    assert r["rows"][0]["seconds"] >= 0


def test_extra_questions_are_included():
    r = run_audit(inp(extra_questions=["Who does Invisalign in Fresno?"], max_questions=4), [FakeProvider()], now=NOW)
    assert r["questions"][0]["text"] == "Who does Invisalign in Fresno?"


@pytest.mark.parametrize("kw,msg", [({"business": ""}, "business"), ({"city": " "}, "city"), ({"threshold": 0.2}, "threshold")])
def test_validation(kw, msg):
    with pytest.raises(ValueError, match=msg):
        run_audit(inp(**kw), [FakeProvider()])


def test_no_providers():
    with pytest.raises(ValueError, match="no AI providers"):
        run_audit(inp(), [])
