import csv

import pytest

from geo_audit.batch import BatchError, read_prospects, run_batch, slugify
from geo_audit.providers import FakeProvider


def test_read_prospects_aliases_and_blank_rows(fixtures_dir, tmp_path):
    rows = read_prospects(fixtures_dir / "prospects.csv")
    assert len(rows) == 4
    assert rows[0]["business"] == "Smile Dental" and rows[0]["competitors"] == "Valley Dental Care;Fresno Family Dentistry"
    assert rows[1]["business"] == "" and rows[1]["line"] == 3
    p = tmp_path / "p.csv"
    p.write_text("﻿Name,Location,Industry,Domain\nA Co,Austin,plumber,a.com\n,,,\n")
    rows = read_prospects(p)
    assert rows == [{"line": 2, "business": "A Co", "city": "Austin", "category": "plumber", "website": "a.com"}]


@pytest.mark.parametrize(
    "content,msg",
    [("", "is empty"), ("business,city\nA,B\n", "missing column")],
)
def test_read_prospects_bad_files(tmp_path, content, msg):
    p = tmp_path / "p.csv"
    p.write_text(content)
    with pytest.raises(BatchError, match=msg):
        read_prospects(p)


def test_read_prospects_missing_file(tmp_path):
    with pytest.raises(BatchError, match="can't read"):
        read_prospects(tmp_path / "nope.csv")


def test_slugify():
    assert slugify("Smile Dental - Fresno, CA") == "smile-dental-fresno-ca"
    assert slugify("!!!") == "business"
    assert len(slugify("x" * 200)) == 50


def _answers_for(row):
    # Smile Dental: always listed (100%), Glow: half, HVAC: never -> best prospect
    biz = row.get("business", "")
    if biz == "Smile Dental":
        return {"*": f"1. **Rival A**\n2. **{biz}**"}
    if biz == "Glow Med Spa":
        return {"best": f"1. **{biz}**\n2. **Rival B**", "*": "1. **Rival B**\n2. **Rival C**"}
    return {"*": "1. **Rival D**\n2. **Rival E**"}


def test_run_batch_sorts_lowest_visibility_first_and_continues_on_errors(fixtures_dir, tmp_path):
    prospects = read_prospects(fixtures_dir / "prospects.csv")
    seen_comps = {}

    def make(row):
        seen_comps[row["business"]] = row.get("competitors", "")
        return [FakeProvider("fake", answers=_answers_for(row))]

    msgs = []
    summary = run_batch(prospects, tmp_path / "out", make, max_questions=4, progress=msgs.append)
    assert [s["business"] for s in summary] == ["Cool Air HVAC", "Glow Med Spa", "Smile Dental", ""]
    assert [s["rank"] for s in summary] == [1, 2, 3, 4]
    assert summary[0]["visibility"] == 0.0 and summary[0]["top_competitor"] == "Rival D"
    assert summary[2]["visibility"] == 100.0
    bad = summary[-1]
    assert bad["status"] == "error" and "line 3: missing business" in bad["error"]
    files = sorted(p.name for p in (tmp_path / "out").iterdir())
    assert files == ["cool-air-hvac-phoenix-az.html", "glow-med-spa-miami-fl.html", "smile-dental-fresno-ca.html", "summary.csv"]
    with open(tmp_path / "out" / "summary.csv", newline="") as fh:
        rows = list(csv.DictReader(fh))
    assert [r["business"] for r in rows] == ["Cool Air HVAC", "Glow Med Spa", "Smile Dental", ""]
    assert rows[0]["report_file"] == "cool-air-hvac-phoenix-az.html"
    assert any("skipped" in m for m in msgs)
    assert seen_comps["Smile Dental"] == "Valley Dental Care;Fresno Family Dentistry"


def test_run_batch_provider_crash_and_all_failed(tmp_path):
    prospects = [
        {"line": 2, "business": "A", "city": "X", "category": "y"},
        {"line": 3, "business": "B", "city": "X", "category": "y"},
    ]

    def make(row):
        if row["business"] == "A":
            raise RuntimeError("no providers for A")
        return [FakeProvider(fail_with="HTTP 401")]

    summary = run_batch(prospects, tmp_path, make, fmt="json")
    by = {s["business"]: s for s in summary}
    assert by["A"]["status"] == "error" and by["A"]["error"] == "no providers for A"
    assert by["B"]["status"] == "no answers" and by["B"]["report_file"] == "b-x.json"
    assert (tmp_path / "b-x.json").exists()


def test_run_batch_duplicate_names_and_custom_questions(tmp_path):
    prospects = [{"business": "A", "city": "X", "category": "y"}, {"business": "A", "city": "X", "category": "y"}]
    calls = []

    def make(row):
        fp = FakeProvider(answers={"*": "nothing"})
        calls.append(fp)
        return [fp]

    summary = run_batch(prospects, tmp_path, make, fmt="md", questions=["Best {category} in {city}?", "Is {business} ok?"],
                        threshold=0.95)
    assert sorted(s["report_file"] for s in summary) == ["a-x-2.md", "a-x.md"]
    assert calls[0].calls == ["Best y in X?", "Is A ok?"]
