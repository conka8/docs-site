import csv
import io
import json
import subprocess
import sys
from pathlib import Path

import pytest

from geo_audit.cli import EXIT_NOTHING, EXIT_OK, EXIT_USAGE, main

from conftest import FakeTransport, http_error, load_fixture

BASE = ["run", "--business", "Smile Dental", "--city", "Fresno, CA", "--category", "dentist"]


def run(argv, env=None, transport=None, sleep=None):
    out, err = io.StringIO(), io.StringIO()
    code = main(argv, env=env if env is not None else {}, transport=transport, sleep=sleep or (lambda s: None),
                stdout=out, stderr=err)
    return code, out.getvalue(), err.getvalue()


@pytest.mark.parametrize("fmt", ["html", "json", "md", "csv"])
def test_run_fake_every_format(tmp_path, fmt):
    out_file = tmp_path / f"report.{fmt}"
    code, out, err = run(BASE + ["--website", "smiledental.com", "--providers", "fake,fake-b", "-o", str(out_file)])
    assert code == EXIT_OK, err
    assert out_file.exists() and out_file.stat().st_size > 100
    assert "AI visibility" in out and str(out_file) in out
    assert "Asking Demo AI (fake)" in err
    if fmt == "json":
        data = json.loads(out_file.read_text())
        assert data["business"] == "Smile Dental" and len(data["providers"]) == 2


def test_run_format_flag_overrides_extension_and_stdout(tmp_path):
    code, out, err = run(BASE + ["--providers", "fake", "-o", "-", "--format", "json", "-q"])
    assert code == EXIT_OK
    assert json.loads(out)["city"] == "Fresno, CA"
    assert "AI visibility" in err  # summary goes to stderr when the report goes to stdout


def test_run_default_output_name(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    code, out, _ = run(BASE + ["--providers", "fake", "-q"])
    assert code == EXIT_OK
    assert (tmp_path / "smile-dental-ai-visibility.html").exists()


def test_run_creates_output_folder(tmp_path):
    target = tmp_path / "new" / "dir" / "r.md"
    assert run(BASE + ["--providers", "fake", "-o", str(target), "-q"])[0] == EXIT_OK
    assert target.exists()


def test_run_with_branding_and_competitors_and_questions(tmp_path, fixtures_dir):
    out_file = tmp_path / "r.html"
    code, _, err = run(
        BASE
        + ["--providers", "fake", "--fake-answers", str(fixtures_dir / "fake_answers.json"),
           "--questions-file", str(fixtures_dir / "questions.txt"), "--question", "What is the best dentist?",
           "--competitor", "Valley Dental Care", "--competitors", "Fresno Family Dentistry; Other",
           "--brand-name", "Acme", "--brand-color", "#123abc", "--logo-url", "https://acme.test/l.png",
           "--agency-contact", "hi@acme.test", "-o", str(out_file), "-q"]
    )
    assert code == EXIT_OK, err
    html = out_file.read_text()
    assert "Acme" in html and "#123abc" in html and "hi@acme.test" in html
    assert "Best dentist in Fresno, CA for kids?" in html
    assert "What is the best dentist?" in html
    assert "<script>alert" not in html


def test_run_real_providers_via_fake_transport(tmp_path):
    def route(req):
        if "openai" in req.url:
            return FakeTransport(load_fixture("openai_response.json"))(req)
        if "anthropic" in req.url:
            return FakeTransport(load_fixture("anthropic_response.json"))(req)
        if "perplexity" in req.url:
            return FakeTransport(load_fixture("perplexity_response.json"))(req)
        return FakeTransport(load_fixture("gemini_response.json"))(req)

    ft = FakeTransport(route)
    env = {"OPENAI_API_KEY": "o", "ANTHROPIC_API_KEY": "a", "PERPLEXITY_API_KEY": "p", "GEMINI_API_KEY": "g"}
    out_file = tmp_path / "r.json"
    code, out, err = run(BASE + ["--max-questions", "3", "--anthropic-model", "claude-test", "--web-search",
                                 "-o", str(out_file), "-q"], env=env, transport=ft)
    assert code == EXIT_OK, err
    data = json.loads(out_file.read_text())
    assert [p["name"] for p in data["providers"]] == ["openai", "anthropic", "perplexity", "gemini"]
    assert data["providers"][1]["model"] == "claude-test"
    assert len(ft.requests) == 12
    assert data["scores"]["visibility"] == 100.0
    anthropic_body = next(r.json() for r in ft.requests if "anthropic" in r.url)
    assert anthropic_body["model"] == "claude-test" and "tools" in anthropic_body


def test_run_partial_failure_still_exit_0(tmp_path):
    def route(req):
        if "openai" in req.url:
            return http_error(401, "Incorrect API key")
        return FakeTransport(load_fixture("perplexity_response.json"))(req)

    env = {"OPENAI_API_KEY": "bad", "PERPLEXITY_API_KEY": "p"}
    out_file = tmp_path / "r.html"
    code, out, err = run(BASE + ["--max-questions", "2", "-o", str(out_file)], env=env, transport=FakeTransport(route))
    assert code == EXIT_OK
    assert "Incorrect API key" in err and "Incorrect API key" in out_file.read_text()


def test_run_all_providers_fail_exit_1(tmp_path):
    out_file = tmp_path / "r.html"
    code, out, err = run(BASE + ["--providers", "openai", "--max-questions", "2", "-o", str(out_file)],
                         env={"OPENAI_API_KEY": "bad"}, transport=FakeTransport(http_error(401, "Incorrect API key")))
    assert code == EXIT_NOTHING
    assert "nothing was measured" in err and "Incorrect API key" in err
    assert out_file.exists()  # the report still explains what went wrong


@pytest.mark.parametrize("cmd", ["run", "batch"])
def test_missing_api_key_fails_fast_exit_2(tmp_path, fixtures_dir, cmd):
    ft = FakeTransport(load_fixture("openai_response.json"))
    out_file = tmp_path / "r.html"
    if cmd == "run":
        argv = BASE + ["--providers", "openai,gemini", "-o", str(out_file)]
    else:
        argv = ["batch", str(fixtures_dir / "prospects.csv"), "-o", str(tmp_path / "o"), "--providers", "openai,gemini"]
    code, out, err = run(argv, env={"OPENAI_API_KEY": "o"}, transport=ft)
    assert code == EXIT_USAGE
    assert err.count("Error:") == 1 and "GEMINI_API_KEY" in err and "OPENAI_API_KEY" not in err
    assert "Traceback" not in err
    assert ft.requests == []  # nothing was asked
    assert not out_file.exists() and not (tmp_path / "o").exists()


def test_demo_banner_in_every_report_format(tmp_path):
    for fmt in ("html", "md", "json"):
        f = tmp_path / f"r.{fmt}"
        assert run(BASE + ["--providers", "fake", "-o", str(f), "-q"])[0] == EXIT_OK
        text = f.read_text()
        if fmt == "json":
            assert json.loads(text)["demo"] is True
        elif fmt == "md":
            assert text.splitlines()[0].startswith("> **Demo data: these answers are made up")
        else:
            assert '<div class="demo">Demo data: these answers are made up' in text


def test_real_report_has_no_demo_banner(tmp_path):
    env = {"OPENAI_API_KEY": "o"}
    for fmt in ("html", "md", "json"):
        f = tmp_path / f"r.{fmt}"
        code, _, err = run(BASE + ["--max-questions", "2", "-o", str(f), "-q"], env=env,
                           transport=FakeTransport(load_fixture("openai_response.json")))
        assert code == EXIT_OK, err
        text = f.read_text()
        assert "Demo data" not in text
        if fmt == "json":
            assert json.loads(text)["demo"] is False


def test_run_no_providers_configured_exit_2():
    code, out, err = run(BASE)
    assert code == EXIT_USAGE
    assert "OPENAI_API_KEY" in err and "--providers fake" in err


@pytest.mark.parametrize(
    "extra,msg",
    [
        (["--providers", "bing"], "unknown provider"),
        (["--providers", "fake", "--brand-color", "blue"], "hex color"),
        (["--providers", "fake", "--logo-url", "javascript:x"], "logo-url"),
        (["--providers", "fake", "--threshold", "2"], "threshold"),
        (["--providers", "fake", "--max-questions", "0"], "max-questions"),
        (["--providers", "fake", "--timeout", "0"], "timeout"),
        (["--providers", "fake", "--questions-file", "/nope/q.txt"], "can't read"),
        (["--providers", "fake", "--fake-answers", "/nope/a.json"], "can't read"),
    ],
)
def test_run_bad_input_exit_2(extra, msg):
    code, _, err = run(BASE + extra)
    assert code == EXIT_USAGE
    assert msg in err


def test_run_blank_business_exit_2():
    code, _, err = run(["run", "--business", " ", "--city", "X", "--category", "y", "--providers", "fake"])
    assert code == EXIT_USAGE and "business is required" in err


def test_argparse_errors_and_help(capsys):
    assert run(["run", "--city", "X"])[0] == 2  # missing required options
    assert run(["--help"])[0] == 0
    assert run(["--version"])[0] == 0
    code, out, _ = run([])
    assert code == EXIT_USAGE and "run" in out


def test_questions_command():
    code, out, _ = run(["questions", "--business", "Smile Dental", "--city", "Fresno, CA", "--category", "dentist",
                        "--max-questions", "4"])
    assert code == EXIT_OK
    lines = out.strip().splitlines()
    assert len(lines) == 4 and lines[0] == "1. What is the best dentist in Fresno, CA?"
    assert run(["questions", "--business", "a", "--city", "b", "--category", "c", "--max-questions", "99"])[0] == EXIT_USAGE


def test_report_command_rerenders_json(tmp_path):
    j = tmp_path / "a.json"
    assert run(BASE + ["--providers", "fake", "-o", str(j), "-q"])[0] == EXIT_OK
    html = tmp_path / "a.html"
    code, out, _ = run(["report", str(j), "-o", str(html), "--brand-name", "Reseller Co"])
    assert code == EXIT_OK and "Report saved" in out
    assert "Reseller Co" in html.read_text()
    code, out, _ = run(["report", str(j), "-o", "-", "--format", "md"])
    assert code == EXIT_OK and "\n# AI Visibility Report" in out


def test_report_command_default_name(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    assert run(BASE + ["--providers", "fake", "-o", "a.json", "-q"])[0] == EXIT_OK
    assert run(["report", "a.json", "-q"])[0] == EXIT_OK
    assert (tmp_path / "smile-dental-ai-visibility.html").exists()


@pytest.mark.parametrize("content,msg", [("{bad", "not valid JSON"), ('{"a": 1}', "not a geo-audit JSON"), ("[1]", "not a geo-audit")])
def test_report_command_bad_json(tmp_path, content, msg):
    p = tmp_path / "x.json"
    p.write_text(content)
    code, _, err = run(["report", str(p)])
    assert code == EXIT_USAGE and msg in err
    code, _, err = run(["report", str(tmp_path / "missing.json")])
    assert code == EXIT_USAGE and "can't read" in err


def test_batch_with_bad_row(tmp_path, fixtures_dir):
    outdir = tmp_path / "reports"
    code, out, err = run(["batch", str(fixtures_dir / "prospects.csv"), "-o", str(outdir), "--providers", "fake",
                          "--max-questions", "4", "--brand-name", "Acme"])
    assert code == EXIT_NOTHING  # finished, but one row was skipped
    assert "Audited 3 of 4" in out and "Best prospects" in out
    assert "Skipped (no name): line 3: missing business" in err
    rows = list(csv.DictReader(open(outdir / "summary.csv", newline="")))
    assert len(rows) == 4 and rows[-1]["status"] == "error"
    vis = [float(r["visibility"]) for r in rows if r["status"] == "ok"]
    assert vis == sorted(vis)
    reports = [p for p in outdir.iterdir() if p.suffix == ".html"]
    assert len(reports) == 3 and all("Acme" in p.read_text() for p in reports)


def test_batch_all_good_exit_0_and_formats(tmp_path, fixtures_dir):
    p = tmp_path / "p.csv"
    p.write_text("business,city,category,website\nA Dental,Austin,dentist,a.com\nB Dental,Austin,dentist,\n")
    code, out, _ = run(["batch", str(p), "-o", str(tmp_path / "o"), "--providers", "fake", "--format", "json",
                        "--questions-file", str(fixtures_dir / "questions.json"), "-q"])
    assert code == EXIT_OK
    data = json.loads((tmp_path / "o" / "a-dental-austin.json").read_text())
    assert [q["text"] for q in data["questions"]] == ["Best dentist in Austin?", "Is A Dental legit?"]


@pytest.mark.parametrize("content,msg", [("", "is empty"), ("business,city,category\n", "no prospects"), ("a,b\n1,2\n", "missing column")])
def test_batch_bad_csv_exit_2(tmp_path, content, msg):
    p = tmp_path / "p.csv"
    p.write_text(content)
    code, _, err = run(["batch", str(p), "-o", str(tmp_path / "o"), "--providers", "fake"])
    assert code == EXIT_USAGE and msg in err


def test_batch_excel_cp1252_csv(tmp_path):
    p = tmp_path / "p.csv"
    p.write_bytes("business,city,category\nCaf\u00e9 Dental,San Jos\u00e9,dentist\n".encode("cp1252"))
    code, out, err = run(["batch", str(p), "-o", str(tmp_path / "o"), "--providers", "fake", "-q"])
    assert code == EXIT_OK, err
    assert "Café Dental" in (tmp_path / "o" / "summary.csv").read_text(encoding="utf-8")


def test_batch_unreadable_encoding_exit_2(tmp_path):
    p = tmp_path / "p.csv"
    p.write_bytes(b"business,city,category\nA\x81\xff\x9d,B,c\n")  # not UTF-8, not Windows-1252
    code, out, err = run(["batch", str(p), "-o", str(tmp_path / "o"), "--providers", "fake"])
    assert code == EXIT_USAGE
    assert "CSV UTF-8" in err and "Traceback" not in err


def test_questions_file_not_utf8_exit_2(tmp_path):
    q = tmp_path / "q.txt"
    q.write_bytes(b"\xff\xfeB\x00e\x00s\x00t\x00")
    code, _, err = run(BASE + ["--providers", "fake", "--questions-file", str(q)])
    assert code == EXIT_USAGE and "UTF-8" in err


def test_batch_without_providers_exit_2(tmp_path, fixtures_dir):
    code, _, err = run(["batch", str(fixtures_dir / "prospects.csv"), "-o", str(tmp_path)])
    assert code == EXIT_USAGE and "No AI tools" in err


def test_python_dash_m_entry_point(tmp_path):
    src = Path(__file__).resolve().parents[1] / "src"
    proc = subprocess.run(
        [sys.executable, "-m", "geo_audit", "questions", "--business", "A", "--city", "B", "--category", "c"],
        capture_output=True, text=True, env={"PYTHONPATH": str(src), "PATH": ""}, timeout=60,
    )
    assert proc.returncode == 0 and "1. What is the best c in B?" in proc.stdout
    proc = subprocess.run([sys.executable, "-m", "geo_audit", "run", "--business", "A", "--city", "B", "--category", "c"],
                          capture_output=True, text=True, env={"PYTHONPATH": str(src), "PATH": ""}, timeout=60, cwd=tmp_path)
    assert proc.returncode == 2 and "No AI tools" in proc.stderr
