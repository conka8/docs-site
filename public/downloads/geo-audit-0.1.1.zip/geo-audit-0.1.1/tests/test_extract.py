from collections import Counter

import pytest

from geo_audit.extract import (
    bold_names,
    count_domains,
    extract_bare_domains,
    extract_urls,
    group_by_domain,
    is_name_like,
    is_url,
    list_items,
    strip_markdown,
    url_domain,
)

NUMBERED = """Here are the best dentists in Fresno:

1. **Valley Dental Care** - great reviews (4.9 stars)
   - Address: 123 Main St
   - Phone: (559) 555-0100
2. **Smile Dental Group, LLC** – family friendly
3. [Big Smile Dental](https://bigsmile.example.com) - cosmetic work
4. Fresno Family Dentistry: open Saturdays

Always read reviews.
"""


@pytest.mark.parametrize(
    "text,expected",
    [
        (NUMBERED, ["Valley Dental Care", "Smile Dental Group", "Big Smile Dental", "Fresno Family Dentistry"]),
        ("1) Valley Dental Care\n2) Smile Dental\n", ["Valley Dental Care", "Smile Dental"]),
        ("- **Valley Dental Care**: gentle\n- **Smile Dental**: modern\n", ["Valley Dental Care", "Smile Dental"]),
        ("* Valley Dental Care, open late\n* Smile Dental is nice\n", ["Valley Dental Care", "Smile Dental"]),
        ("• Valley Dental Care\n• Smile Dental\n", ["Valley Dental Care", "Smile Dental"]),
        ("### 1. Valley Dental Care\nText\n### 2. Smile Dental\nText", ["Valley Dental Care", "Smile Dental"]),
        ("1. __Valley Dental Care__ — good\n2. __Smile Dental__", ["Valley Dental Care", "Smile Dental"]),
        ("1. **Valley Dental Care** [1][2]\n2. **Smile Dental** [3]", ["Valley Dental Care", "Smile Dental"]),
        ("  1. Valley Dental Care\n  2. Smile Dental\n", ["Valley Dental Care", "Smile Dental"]),
        ("No list here. Just Smile Dental.", []),
        ("", []),
    ],
)
def test_list_items_varied_markdown(text, expected):
    assert list_items(text) == expected


def test_list_items_ignores_sub_bullets_and_label_lines():
    text = "1. **Valley Dental Care**\n    - Rating: 4.9\n    - Website: valley.com\n2. **Smile Dental**\n"
    assert list_items(text) == ["Valley Dental Care", "Smile Dental"]


def test_list_items_ignores_advice_bullets():
    text = "Tips:\n- Check reviews on Google\n- Ask about insurance\n- consider location\n"
    assert list_items(text) == []


def test_list_items_keep_forces_candidate():
    text = "1. best smile dental\n2. Valley Dental Care\n"
    assert list_items(text) == ["Valley Dental Care"]
    assert list_items(text, keep=lambda n: n.lower() == "best smile dental") == ["best smile dental", "Valley Dental Care"]


def test_bold_names():
    text = "Try **Valley Dental Care** or **Smile Dental**. **Important:** call first. **Fresno** is big. **4.8 stars**"
    assert bold_names(text) == ["Valley Dental Care", "Smile Dental"]
    assert bold_names("**Zocdoc** works", min_words=1) == ["Zocdoc"]


@pytest.mark.parametrize(
    "name,ok",
    [
        ("Valley Dental Care", True),
        ("Joe's Plumbing & Heating", True),
        ("Check reviews on Google", False),
        ("Address", False),
        ("Why choose them?", False),
        ("ok", False),
        ("x" * 80, False),
        ("one two three four five six seven eight nine", False),
        ("of the and", False),
        ("123 456", False),
        ("valley dental care", False),
    ],
)
def test_is_name_like(name, ok):
    assert is_name_like(name) is ok


def test_strip_markdown():
    assert strip_markdown("**[Smile Dental](https://x.com)** [1]") == "Smile Dental"
    assert strip_markdown("*Smile* `Dental`") == "Smile Dental"


def test_extract_urls_trims_punctuation_and_dedupes():
    text = (
        "See https://www.yelp.com/biz/a, and (https://healthgrades.com/x). "
        "Also [link](https://zocdoc.com/d) and https://www.yelp.com/biz/a."
        " Wiki: https://en.wikipedia.org/wiki/Fresno_(city)"
    )
    assert extract_urls(text) == [
        "https://www.yelp.com/biz/a",
        "https://healthgrades.com/x",
        "https://zocdoc.com/d",
        "https://en.wikipedia.org/wiki/Fresno_(city)",
    ]
    assert extract_urls("") == []


def test_extract_bare_domains():
    text = "Check Yelp.com and www.healthgrades.com or https://zocdoc.com/x. Email info@smiledental.com. v1.2 e.g. ok"
    assert extract_bare_domains(text) == ["zocdoc.com", "yelp.com", "healthgrades.com"]


def test_group_by_domain_and_url_domain():
    urls = ["https://www.yelp.com/a", "https://yelp.com/b", "https://m.yelp.com/a", "https://zocdoc.com/x",
            "https://www.yelp.com/a", "not a url"]
    groups = group_by_domain(urls)
    assert list(groups) == ["yelp.com", "zocdoc.com"]
    assert groups["yelp.com"] == ["https://www.yelp.com/a", "https://yelp.com/b", "https://m.yelp.com/a"]
    assert url_domain("https://www.Example.com/x") == "example.com"


def test_count_domains_counts_once_per_answer():
    c = count_domains([["yelp.com", "yelp.com", "zocdoc.com"], ["yelp.com"], []])
    assert c == Counter({"yelp.com": 2, "zocdoc.com": 1})


def test_is_url():
    assert is_url("https://x.com/a")
    assert not is_url("x.com")
    assert not is_url("ftp://x.com")
    assert not is_url("http://[bad")
