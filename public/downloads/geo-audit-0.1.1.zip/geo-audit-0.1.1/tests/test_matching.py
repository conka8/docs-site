import pytest

from geo_audit.matching import (
    core_name,
    core_tokens,
    domain_matches,
    find_in_text,
    names_match,
    normalize_domain,
    normalize_name,
    similarity,
    tokenize,
)


def test_tokenize_handles_case_punctuation_ampersand_and_apostrophes():
    assert tokenize("Joe's Plumbing & Heating, Inc.") == ["joes", "plumbing", "and", "heating", "inc"]
    assert tokenize("Joe’s") == ["joes"]
    assert tokenize("Café Olé") == ["cafe", "ole"]
    assert tokenize("A+B Dental") == ["a", "and", "b", "dental"]
    assert tokenize("") == []
    assert tokenize(None) == []


def test_normalize_name():
    assert normalize_name("Smile Dental Group, LLC") == "smile dental group llc"
    assert normalize_name("  SMILE   dental ") == "smile dental"


@pytest.mark.parametrize(
    "raw,expected",
    [
        ("Smile Dental Group LLC", "smile dental"),
        ("The Smile Dental Group, Inc.", "smile dental"),
        ("Smith & Associates", "smith"),
        ("Smith and Associates PLLC", "smith"),
        ("Dr. Lee DDS", "dr lee"),
        ("The Clinic", "clinic"),  # never strip to nothing
        ("Group", "group"),
        ("Valley Dental Care", "valley dental care"),
    ],
)
def test_core_name_strips_suffixes(raw, expected):
    assert core_name(raw) == expected


def test_core_tokens_never_empty_for_nonempty_name():
    assert core_tokens("LLC") == ["llc"]
    assert core_tokens("") == []


@pytest.mark.parametrize(
    "a,b",
    [
        ("Smile Dental Group LLC", "Smile Dental"),
        ("smile dental", "SMILE DENTAL"),
        ("Smile-Dental", "Smile Dental"),
        ("Bright Smile Dental", "BrightSmile Dental"),
        ("Smiles Dental", "Smile Dental"),
        ("Joe's Plumbing & Heating", "Joes Plumbing and Heating"),
        ("The Smile Dental", "Smile Dental, Inc."),
    ],
)
def test_names_match_true(a, b):
    assert names_match(a, b)


@pytest.mark.parametrize(
    "a,b",
    [
        ("Smile", "Smile Dental"),
        ("Big Smile Dental", "Smile Dental"),
        ("Smile Dentistry", "Smile Dental"),
        ("Valley Dental Care", "Smile Dental"),
        ("", "Smile Dental"),
    ],
)
def test_names_match_false(a, b):
    assert not names_match(a, b)


def test_similarity_bounds():
    assert similarity("Smile Dental", "Smile Dental LLC") == 1.0
    assert similarity("", "x") == 0.0
    assert 0 < similarity("Smile Dentistry", "Smile Dental") < 0.9


def test_threshold_is_adjustable():
    assert not names_match("Smile Dentistry", "Smile Dental")
    assert names_match("Smile Dentistry", "Smile Dental", threshold=0.7)


def test_find_in_text_exact_and_suffix():
    assert find_in_text("We love Smile Dental Group LLC downtown.", "Smile Dental")[0] == "exact"
    assert find_in_text("we love SMILE DENTAL!", "Smile Dental Group, LLC")[0] == "exact"


def test_find_in_text_fuzzy():
    how, words = find_in_text("Try BrightSmile Dental downtown.", "Bright Smile Dental")
    assert how == "fuzzy" and words == "brightsmile dental"
    assert find_in_text("Smiles Dental is great", "Smile Dental")[0] == "fuzzy"


def test_find_in_text_no_false_positive_on_partial_name():
    assert find_in_text("Keep a smile on your face. Dental care matters.", "Smile Dental") is None
    assert find_in_text("Smile! You deserve it.", "Smile Dental") is None
    assert find_in_text("", "Smile Dental") is None
    assert find_in_text("anything", "") is None


def test_find_in_text_ampersand_vs_and():
    assert find_in_text("Call Smith and Sons Plumbing today", "Smith & Sons Plumbing")


@pytest.mark.parametrize(
    "value,expected",
    [
        ("https://www.SmileDental.com/about?x=1", "smiledental.com"),
        ("smiledental.com", "smiledental.com"),
        ("www.smiledental.com/", "smiledental.com"),
        ("http://m.yelp.com/biz/x", "yelp.com"),
        ("https://maps.google.com/?q=1", "maps.google.com"),
        ("www.com", "www.com"),
        ("localhost", ""),
        ("", ""),
        ("http://[bad", ""),
    ],
)
def test_normalize_domain(value, expected):
    assert normalize_domain(value) == expected


def test_domain_matches():
    assert domain_matches("https://www.smiledental.com/x", "smiledental.com")
    assert domain_matches("blog.smiledental.com", "https://smiledental.com")
    assert not domain_matches("notsmiledental.com", "smiledental.com")
    assert not domain_matches("", "smiledental.com")
