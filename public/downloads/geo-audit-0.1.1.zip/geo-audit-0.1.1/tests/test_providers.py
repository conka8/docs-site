import json

import pytest

from geo_audit import constants as C
from geo_audit.providers import (
    AnthropicProvider,
    Citation,
    FakeProvider,
    GeminiProvider,
    OpenAIProvider,
    PerplexityProvider,
    available_providers,
    build_providers,
    load_fake_answers,
    parse_provider_list,
)
from geo_audit.transport import HttpResponse, ProviderError

from conftest import FakeTransport, http_error, load_fixture, timeout_error


def make(cls, response, sleep, **kw):
    ft = FakeTransport(*response) if isinstance(response, tuple) else FakeTransport(response)
    return cls(api_key="KEY", transport=ft, sleep=sleep, **kw), ft


# ------------------------------------------------ OpenAI

def test_openai_request_shape(sleep):
    p, ft = make(OpenAIProvider, load_fixture("openai_response.json"), sleep)
    p.ask("best dentist in Fresno?")
    req = ft.requests[0]
    assert req.url == C.OPENAI_URL == "https://api.openai.com/v1/chat/completions"
    assert req.headers["Authorization"] == "Bearer KEY"
    assert req.json() == {"model": C.OPENAI_DEFAULT_MODEL, "messages": [{"role": "user", "content": "best dentist in Fresno?"}]}


def test_openai_response_parsing_with_annotations(sleep):
    p, _ = make(OpenAIProvider, load_fixture("openai_response.json"), sleep, model="gpt-x")
    ans = p.ask("q")
    assert ans.text.startswith("Here are some of the best dentists")
    assert ans.citations == [Citation("https://www.healthgrades.com/dentist/fresno", "Healthgrades")]
    assert p.model == "gpt-x"


def test_openai_content_parts_and_missing_choices(sleep):
    p, _ = make(OpenAIProvider, {"choices": [{"message": {"content": [{"type": "text", "text": "a"}, {"text": "b"}]}}]}, sleep)
    assert p.ask("q").text == "ab"
    p, _ = make(OpenAIProvider, {"choices": []}, sleep)
    with pytest.raises(ProviderError, match="no choices"):
        p.ask("q")


def test_openai_null_content_is_empty(sleep):
    p, _ = make(OpenAIProvider, {"choices": [{"message": {"content": None}}]}, sleep)
    assert p.ask("q").text == ""


# ------------------------------------------------ Perplexity

def test_perplexity_request_and_citations(sleep):
    p, ft = make(PerplexityProvider, load_fixture("perplexity_response.json"), sleep)
    ans = p.ask("best dentist?")
    req = ft.requests[0]
    assert req.url == "https://api.perplexity.ai/chat/completions"
    assert req.json()["model"] == "sonar"
    assert req.headers["Authorization"] == "Bearer KEY"
    assert [c.url for c in ans.citations] == [
        "https://www.yelp.com/biz/valley-dental",
        "https://smiledental.com/about",
        "https://www.healthgrades.com/fresno",
    ]
    assert "Smile Dental" in ans.text


def test_perplexity_without_citation_fields(sleep):
    p, _ = make(PerplexityProvider, {"choices": [{"message": {"content": "hi"}}], "citations": ["not a url", {"url": "https://a.com"}]}, sleep)
    ans = p.ask("q")
    assert ans.text == "hi" and [c.url for c in ans.citations] == ["https://a.com"]


# ------------------------------------------------ Anthropic

def test_anthropic_request_shape(sleep):
    p, ft = make(AnthropicProvider, load_fixture("anthropic_response.json"), sleep)
    p.ask("best dentist?")
    req = ft.requests[0]
    assert req.url == "https://api.anthropic.com/v1/messages"
    assert req.headers["x-api-key"] == "KEY"
    assert req.headers["anthropic-version"] == C.ANTHROPIC_VERSION
    body = req.json()
    assert body == {
        "model": "claude-sonnet-5-5",
        "max_tokens": C.ANTHROPIC_MAX_TOKENS,
        "messages": [{"role": "user", "content": "best dentist?"}],
    }


def test_anthropic_web_search_adds_tool(sleep):
    p, ft = make(AnthropicProvider, load_fixture("anthropic_response.json"), sleep, web_search=True)
    p.ask("q")
    assert ft.requests[0].json()["tools"] == [C.ANTHROPIC_WEB_SEARCH_TOOL]


def test_anthropic_response_parsing(sleep):
    p, _ = make(AnthropicProvider, load_fixture("anthropic_response.json"), sleep)
    ans = p.ask("q")
    assert ans.text == "Top options in Fresno include **Valley Dental Care** and **Smile Dental**."
    assert [c.url for c in ans.citations] == ["https://www.zocdoc.com/dentists/fresno", "https://www.yelp.com/biz/smile-dental-fresno"]


def test_anthropic_bad_reply(sleep):
    p, _ = make(AnthropicProvider, {"type": "message"}, sleep)
    with pytest.raises(ProviderError, match="no content"):
        p.ask("q")


# ------------------------------------------------ Gemini

def test_gemini_request_shape(sleep):
    p, ft = make(GeminiProvider, load_fixture("gemini_response.json"), sleep, model="gemini-test")
    p.ask("best dentist?")
    req = ft.requests[0]
    assert req.url == "https://generativelanguage.googleapis.com/v1beta/models/gemini-test:generateContent"
    assert req.headers[C.GEMINI_API_KEY_HEADER] == "KEY"
    assert "KEY" not in req.url
    assert req.json() == {"contents": [{"role": "user", "parts": [{"text": "best dentist?"}]}]}


def test_gemini_web_search_adds_google_search_tool(sleep):
    p, ft = make(GeminiProvider, load_fixture("gemini_response.json"), sleep, web_search=True)
    p.ask("q")
    assert ft.requests[0].json()["tools"] == [{"google_search": {}}]


def test_gemini_response_and_grounding(sleep):
    p, _ = make(GeminiProvider, load_fixture("gemini_response.json"), sleep)
    ans = p.ask("q")
    assert "**Valley Dental Care**" in ans.text and "**Smile Dental**" in ans.text
    assert [c.url for c in ans.citations] == ["https://yelp.com", "https://www.healthgrades.com/fresno-dentists"]


def test_gemini_blocked_prompt(sleep):
    p, _ = make(GeminiProvider, {"promptFeedback": {"blockReason": "SAFETY"}}, sleep)
    with pytest.raises(ProviderError, match="blocked: SAFETY"):
        p.ask("q")


# ------------------------------------------------ shared error behaviour

@pytest.mark.parametrize("cls", [OpenAIProvider, AnthropicProvider, PerplexityProvider, GeminiProvider])
def test_each_provider_retries_429_then_succeeds(cls, sleep):
    good = {
        OpenAIProvider: load_fixture("openai_response.json"),
        PerplexityProvider: load_fixture("perplexity_response.json"),
        AnthropicProvider: load_fixture("anthropic_response.json"),
        GeminiProvider: load_fixture("gemini_response.json"),
    }[cls]
    p, ft = make(cls, (http_error(429), http_error(503), good), sleep)
    assert p.ask("q").text
    assert len(ft.requests) == 3 and len(sleep.calls) == 2


@pytest.mark.parametrize("cls", [OpenAIProvider, AnthropicProvider, PerplexityProvider, GeminiProvider])
def test_each_provider_reports_auth_error(cls, sleep):
    p, ft = make(cls, http_error(401, "bad key"), sleep)
    with pytest.raises(ProviderError, match="401"):
        p.ask("q")
    assert len(ft.requests) == 1


@pytest.mark.parametrize("cls", [OpenAIProvider, AnthropicProvider, PerplexityProvider, GeminiProvider])
def test_each_provider_timeout(cls, sleep):
    p, ft = make(cls, timeout_error(), sleep, timeout=3)
    with pytest.raises(ProviderError, match="timed out"):
        p.ask("q")
    assert all(r.timeout == 3 for r in ft.requests)


def test_missing_key_fails_without_http(sleep):
    ft = FakeTransport({"x": 1})
    p = OpenAIProvider(api_key="", transport=ft, sleep=sleep)
    with pytest.raises(ProviderError, match="OPENAI_API_KEY is not set"):
        p.ask("q")
    assert ft.requests == []


def test_non_object_reply(sleep):
    p, _ = make(OpenAIProvider, HttpResponse(200, json.dumps([1, 2])), sleep)
    with pytest.raises(ProviderError, match="not a JSON object"):
        p.ask("q")


def test_labels():
    assert OpenAIProvider("k").label == "ChatGPT (OpenAI)"
    assert FakeProvider().label == "Demo AI (fake)"
    assert FakeProvider("fake-gemini").label == "Demo AI (gemini)"


# ------------------------------------------------ fake provider

def test_fake_canned_exact_and_substring():
    fp = FakeProvider(answers={"Best dentist?": "A", "weekends": {"text": "B", "citations": ["https://y.com", 3]}})
    assert fp.ask("best dentist?").text == "A"
    ans = fp.ask("Open on WEEKENDS?")
    assert ans.text == "B" and ans.citations == [Citation("https://y.com")]
    assert fp.calls == ["best dentist?", "Open on WEEKENDS?"]
    assert FakeProvider(answers={"*": "any", "x": "X"}).ask("other").text == "any"
    assert FakeProvider(answers={"*": "any", "x": "X"}).ask("an x").text == "X"


def test_fake_generated_is_deterministic_and_seeded():
    kw = dict(business="Smile Dental", city="Fresno, CA", category="dentist", website="smiledental.com")
    a, b, c = FakeProvider("fake", **kw), FakeProvider("fake", **kw), FakeProvider("fake-x", **kw)
    qs = [f"question {i}" for i in range(12)]
    assert [a.ask(q).text for q in qs] == [b.ask(q).text for q in qs]
    assert [a.ask(q).text for q in qs] != [c.ask(q).text for q in qs]


def test_fake_generated_uses_known_competitors():
    fp = FakeProvider(business="Smile Dental", city="Fresno", category="dentist", competitors=["Rival Dental"])
    texts = " ".join(fp.ask(f"best dentist {i}").text for i in range(10))
    assert "Rival Dental" in texts


def test_fake_brand_questions():
    fp = FakeProvider(business="Smile Dental", city="Fresno", category="dentist", website="smiledental.com")
    texts = [fp.ask(f"Is Smile Dental good? {i}") for i in range(10)]
    assert any("don't have specific information" in t.text for t in texts)
    assert any(any("smiledental.com" in c.url for c in t.citations) for t in texts)


def test_fake_fail_with():
    with pytest.raises(ProviderError, match="down"):
        FakeProvider(fail_with="down").ask("q")


def test_load_fake_answers(fixtures_dir, tmp_path):
    assert "best dentist" in load_fake_answers(fixtures_dir / "fake_answers.json")
    (tmp_path / "list.json").write_text("[1]")
    (tmp_path / "bad.json").write_text("{")
    for name, msg in (("list.json", "JSON object"), ("bad.json", "not valid JSON"), ("missing.json", "can't read")):
        with pytest.raises(ValueError, match=msg):
            load_fake_answers(tmp_path / name)


# ------------------------------------------------ registry

def test_parse_provider_list():
    assert parse_provider_list("OpenAI, gemini,,openai,fake-b") == ["openai", "gemini", "fake-b"]
    assert parse_provider_list(None) == []
    with pytest.raises(ValueError, match="unknown provider 'bing'"):
        parse_provider_list("openai,bing")


def test_available_providers_from_env():
    env = {"OPENAI_API_KEY": "x", "GEMINI_API_KEY": " ", "PERPLEXITY_API_KEY": "p"}
    assert available_providers(env) == ["openai", "perplexity"]
    assert available_providers({}) == []


def test_build_providers(sleep):
    ft = FakeTransport({})
    ps = build_providers(
        ["anthropic", "openai", "fake"], {"ANTHROPIC_API_KEY": "a"}, models={"anthropic": "claude-x"},
        transport=ft, sleep=sleep, timeout=9, web_search=True, business="B",
    )
    assert [p.name for p in ps] == ["anthropic", "openai", "fake"]
    assert ps[0].model == "claude-x" and ps[0].api_key == "a" and ps[0].timeout == 9 and ps[0].web_search
    assert ps[1].api_key == "" and ps[1].model == C.OPENAI_DEFAULT_MODEL
    assert isinstance(ps[2], FakeProvider) and ps[2].business == "B"
