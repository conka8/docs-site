import pytest

from geo_audit.questions import (
    BRAND_TEMPLATES,
    DISCOVERY_TEMPLATES,
    QuestionsError,
    dedupe,
    fill_placeholders,
    generate_questions,
    load_questions_file,
    question_kind,
)


def test_default_generation_has_8_to_12_questions_with_inputs_filled():
    qs = generate_questions("Smile Dental", "Fresno, CA", "dentist")
    assert 8 <= len(qs) <= 12
    assert qs[0] == "What is the best dentist in Fresno, CA?"
    assert any("open on weekends" in q for q in qs)
    assert any("affordable" in q for q in qs)
    assert any("Smile Dental" in q and "reviews" in q for q in qs)
    assert all("{" not in q for q in qs)
    assert len(set(q.lower() for q in qs)) == len(qs)


def test_brand_questions_are_kept_at_the_end():
    qs = generate_questions("Smile Dental", "Fresno, CA", "dentist", max_questions=5)
    assert len(qs) == 5
    assert [question_kind(q, "Smile Dental") for q in qs] == ["discovery"] * 3 + ["brand"] * 2


def test_tiny_budget_prefers_discovery():
    qs = generate_questions("Smile Dental", "Fresno, CA", "dentist", max_questions=2)
    assert len(qs) == 2
    assert all(question_kind(q, "Smile Dental") == "discovery" for q in qs)


def test_max_questions_upper_bound_uses_all_templates():
    qs = generate_questions("Smile Dental", "Fresno, CA", "dentist", max_questions=50)
    assert len(qs) == len(DISCOVERY_TEMPLATES) + len(BRAND_TEMPLATES)


def test_extra_questions_come_first_and_are_deduped():
    qs = generate_questions(
        "Smile Dental", "Fresno, CA", "dentist",
        extra=["Who does Invisalign in Fresno?", "who does invisalign in fresno", "What is the best dentist in Fresno, CA"],
    )
    assert qs[0] == "Who does Invisalign in Fresno?"
    assert sum("invisalign" in q.lower() for q in qs) == 1
    assert sum(q.lower().startswith("what is the best dentist") for q in qs) == 1
    assert len(qs) == 10


@pytest.mark.parametrize("field", ["business", "city", "category"])
def test_missing_input_raises(field):
    kwargs = {"business": "Smile Dental", "city": "Fresno", "category": "dentist"}
    kwargs[field] = "  "
    with pytest.raises(QuestionsError, match=field):
        generate_questions(**kwargs)


@pytest.mark.parametrize("n", [0, 51])
def test_bad_max_questions(n):
    with pytest.raises(QuestionsError):
        generate_questions("a", "b", "c", max_questions=n)


def test_dedupe():
    assert dedupe(["Best dentist?", "best  DENTIST", "", "  ", "Other"]) == ["Best dentist?", "Other"]


def test_question_kind():
    assert question_kind("Is Smile Dental good?", "Smile Dental LLC") == "brand"
    assert question_kind("Best smile dental care tips?", "Smile Dental") == "brand"
    assert question_kind("Best dentist in Fresno?", "Smile Dental") == "discovery"


def test_fill_placeholders_leaves_unknown_braces():
    assert fill_placeholders("{business} in {city} {x}", "A", "B", "C") == "A in B {x}"


def test_load_questions_txt(fixtures_dir):
    qs = load_questions_file(fixtures_dir / "questions.txt", "Smile Dental", "Fresno", "dentist")
    assert qs == [
        "Best dentist in Fresno for kids?",
        "Who does emergency dentist work in Fresno?",
        "Is Smile Dental open late?",
    ]


def test_load_questions_txt_without_values_keeps_placeholders(fixtures_dir):
    qs = load_questions_file(fixtures_dir / "questions.txt")
    assert qs[0] == "Best {category} in {city} for kids?"


def test_load_questions_json(fixtures_dir, tmp_path):
    assert load_questions_file(fixtures_dir / "questions.json", "X", "Y", "Z") == ["Best Z in Y?", "Is X legit?"]
    p = tmp_path / "q.json"
    p.write_text('{"questions": ["a?"]}')
    assert load_questions_file(p) == ["a?"]


@pytest.mark.parametrize(
    "name,content,msg",
    [
        ("bad.json", "{nope", "not valid JSON"),
        ("bad2.json", '{"questions": [1, 2]}', "JSON list"),
        ("empty.txt", "# only a comment\n\n", "no questions"),
    ],
)
def test_load_questions_bad_files(tmp_path, name, content, msg):
    p = tmp_path / name
    p.write_text(content)
    with pytest.raises(QuestionsError, match=msg):
        load_questions_file(p)


def test_load_questions_missing_file(tmp_path):
    with pytest.raises(QuestionsError, match="can't read"):
        load_questions_file(tmp_path / "nope.txt")
