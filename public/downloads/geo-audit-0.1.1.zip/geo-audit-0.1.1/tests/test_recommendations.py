from geo_audit.recommendations import build_recommendations
from geo_audit.scoring import compute_scores

from test_scoring import row

PROVIDERS = [{"name": "a", "label": "ChatGPT", "model": "m"}, {"name": "b", "label": "Gemini", "model": "m"}]


def recs_for(rows, website="smile.com", providers=PROVIDERS, business="Smile Dental"):
    result = {"business": business, "website": website, "rows": rows,
              "scores": compute_scores(rows, providers, business, website)}
    recs = build_recommendations(result)
    return {r["id"]: r for r in recs}, recs


def test_invisible_with_directory_sources_says_get_listed():
    rows = [
        row("a", "What is the best dentist?", competitors=["Rival"], domains=["yelp.com", "healthgrades.com"]),
        row("b", "What is the best dentist?", competitors=["Rival"], domains=["yelp.com"]),
    ]
    by, recs = recs_for(rows)
    assert "invisible" in by and by["invisible"]["priority"] == "high"
    assert "get_listed" in by
    assert "yelp.com" in by["get_listed"]["title"] and "healthgrades.com" in by["get_listed"]["title"]
    assert by["get_listed"]["priority"] == "high"
    assert recs[0]["priority"] == "high"  # sorted by priority
    assert [r["priority"] for r in recs] == sorted([r["priority"] for r in recs], key=["high", "medium", "low"].index)


def test_directory_that_already_mentions_you_is_not_recommended():
    rows = [row("a", "q", True, 1, domains=["yelp.com"], website_cited=True)]
    by, _ = recs_for(rows)
    assert "get_listed" not in by


def test_no_website_citations_recommends_faq_schema():
    rows = [row("a", "q", True, 1, domains=["yelp.com"])]
    by, _ = recs_for(rows)
    assert "website_not_cited" in by
    assert "FAQ" in by["website_not_cited"]["detail"] and "schema" in by["website_not_cited"]["detail"]


def test_website_cited_means_no_faq_rec():
    rows = [row("a", "q", True, 1, domains=["smile.com"], website_cited=True)]
    by, _ = recs_for(rows)
    assert "website_not_cited" not in by


def test_no_website_given():
    by, _ = recs_for([row("a", "q", True, 1)], website="")
    assert "no_website" in by and by["no_website"]["priority"] == "low"
    assert "website_not_cited" not in by


def test_mentioned_on_only_one_provider():
    rows = [row("a", "q1", True, 1), row("a", "q2", True, 1), row("b", "q1"), row("b", "q2")]
    by, _ = recs_for(rows)
    assert by["missing_providers"]["title"] == "You only show up on ChatGPT"
    assert "Gemini" in by["missing_providers"]["detail"]


def test_missing_on_one_of_three_providers():
    providers = PROVIDERS + [{"name": "c", "label": "Claude", "model": "m"}]
    rows = [row("a", "q1", True, 1), row("b", "q1", True, 2), row("c", "q1")]
    by, _ = recs_for(rows, providers=providers)
    assert by["missing_providers"]["title"] == "You don't show up on Claude"


def test_low_position():
    rows = [row("a", "q1", True, 5), row("b", "q1", True, 4)]
    by, _ = recs_for(rows)
    assert "low_position" in by and "#4.5" in by["low_position"]["detail"]
    by2, _ = recs_for([row("a", "q1", True, 1)])
    assert "low_position" not in by2


def test_competitor_leads():
    rows = [row("a", f"q{i}", i == 0, 1 if i == 0 else None, ["Valley Dental Care"]) for i in range(4)]
    by, _ = recs_for(rows)
    assert by["competitor_leads"]["title"].startswith("Valley Dental Care")
    assert "100%" in by["competitor_leads"]["detail"] and "25%" in by["competitor_leads"]["detail"]


def test_topic_rules():
    rows = [
        row("a", "Is there a dentist open on weekends?"),
        row("a", "What is an affordable dentist?"),
        row("a", "Which dentist has the best reviews?"),
        row("a", "Which dentist do locals recommend?", True, 1),
    ]
    by, _ = recs_for(rows)
    assert "topic_hours" in by and "weekends" in by["topic_hours"]["detail"]
    assert "topic_price" in by
    assert "topic_reviews" in by


def test_topic_rule_not_fired_when_some_provider_mentions():
    rows = [row("a", "Is there a dentist open on weekends?", True, 1), row("b", "Is there a dentist open on weekends?")]
    by, _ = recs_for(rows)
    assert "topic_hours" not in by


def test_unknown_brand():
    rows = [row("a", "q", True, 1), row("b", "Is Smile Dental good?", True, kind="brand", unknown=True)]
    by, _ = recs_for(rows)
    assert "unknown_brand" in by and "Gemini" in by["unknown_brand"]["detail"]


def test_provider_errors_and_not_measured():
    rows = [row("a", "q", error="ANTHROPIC_API_KEY is not set")]
    by, _ = recs_for(rows, providers=PROVIDERS[:1])
    assert "not_measured" in by
    assert "error_a" in by and "ANTHROPIC_API_KEY" in by["error_a"]["detail"]
    assert "invisible" not in by


def test_strong_visibility_keep_going():
    rows = [row("a", "q1", True, 1, domains=["smile.com"], website_cited=True),
            row("b", "q1", True, 1, domains=["smile.com"], website_cited=True)]
    by, recs = recs_for(rows)
    assert "keep_going" in by
    assert "invisible" not in by and "missing_providers" not in by


def test_always_at_least_one_recommendation():
    rows = [row("a", "q1", True, 1, domains=["smile.com"], website_cited=True),
            row("a", "q2", False, None, domains=["smile.com"], website_cited=True)]
    _, recs = recs_for(rows, providers=PROVIDERS[:1])
    assert recs  # 50%: nothing urgent, but never empty
    assert {r["id"] for r in recs} == {"monitor"}
