import csv
import datetime as dt
import io
import json
from html.parser import HTMLParser

import pytest

from geo_audit.audit import AuditInput, run_audit
from geo_audit.providers import FakeProvider
from geo_audit.report import (
    CSV_FIELDS,
    DEFAULT_COLOR,
    Branding,
    excerpt,
    format_from_path,
    render,
    render_csv,
    render_html,
    render_json,
    render_markdown,
    valid_color,
)

NOW = dt.datetime(2026, 10, 28, 9, 30, tzinfo=dt.timezone.utc)
EVIL = "<script>alert('pwned')</script>"


@pytest.fixture
def result():
    answers = {
        "best dentist": {
            "text": f"1. **Valley Dental Care** {EVIL}\n2. **Smile Dental**\n3. **Bright & <b>Bold</b> Dental**",
            "citations": ["https://www.yelp.com/biz/x", "https://smiledental.com/"],
        },
        "weekends": "Fresno Family Dentistry | open Saturdays",
    }
    providers = [FakeProvider("fake", answers=answers), FakeProvider("fake-b", fail_with="HTTP 401: bad <key>")]
    inp = AuditInput(
        business="Smile Dental", city="Fresno, CA", category="dentist", website="smiledental.com",
        questions=["What is the best dentist in Fresno, CA?", "Dentist open on weekends?", "Is Smile Dental good?"],
    )
    return run_audit(inp, providers, now=NOW)


class _Collector(HTMLParser):
    def __init__(self):
        super().__init__()
        self.tags = []
        self.text = []

    def handle_starttag(self, tag, attrs):
        self.tags.append(tag)

    def handle_data(self, data):
        self.text.append(data)


def test_html_escapes_llm_content(result):
    html = render_html(result)
    assert "<script>" not in html
    assert "&lt;script&gt;alert(&#x27;pwned&#x27;)&lt;/script&gt;" in html
    assert "<b>Bold</b>" not in html
    assert "bad &lt;key&gt;" in html
    p = _Collector()
    p.feed(html)
    assert "script" not in p.tags


def test_html_escapes_business_and_branding():
    answers = {"q": "x"}
    r = run_audit(AuditInput(business='Joe"s <Diner>', city="A&B", category="diner", questions=["q?"]),
                  [FakeProvider(answers=answers)], now=NOW)
    b = Branding(brand_name="<i>Agency</i>", brand_color="red;}</style><script>", logo_url="javascript:alert(1)",
                 agency_contact="<a href=x>call</a>")
    html = render_html(r, b)
    assert "<i>Agency</i>" not in html and "&lt;i&gt;Agency&lt;/i&gt;" in html
    assert "Joe&quot;s &lt;Diner&gt;" in html and "A&amp;B" in html
    assert "javascript:" not in html and "<img" not in html
    assert "</style><script>" not in html and f"--brand:{DEFAULT_COLOR}" in html
    assert "&lt;a href=x&gt;call&lt;/a&gt;" in html


def test_html_contents_and_white_label(result):
    b = Branding("Acme Growth", "#0f766e", "https://acme.test/logo.png", "hi@acme.test | 555-0100")
    html = render_html(result, b)
    assert html.startswith("<!doctype html>")
    assert "<title>AI Visibility Report: Smile Dental</title>" in html
    assert "--brand:#0f766e" in html
    assert '<img src="https://acme.test/logo.png" alt="Acme Growth">' in html
    assert "Prepared by" in html and "Acme Growth" in html and "hi@acme.test | 555-0100" in html
    for section in ("Your score in each AI tool", "What to do next", "Who AI recommends",
                    "Websites the AI tools used as sources", "Question by question", "How this was measured"):
        assert section in html
    assert "@media print" in html
    assert "October 28, 2026" in html
    assert "Could not check" in html  # failed provider shown, not hidden
    assert "Valley Dental Care" in html and "yelp.com" in html
    assert "(you)" in html
    assert "Mentioned at #2 of 3" in html
    assert "http" not in html.split("<style>")[1].split("</style>")[0]  # no external CSS


def test_html_without_branding_or_sources():
    r = run_audit(AuditInput(business="X Co", city="Y", category="z", questions=["q?"]), [FakeProvider(answers={"q": "no"})], now=NOW)
    html = render_html(r)
    assert "Prepared by" not in html and "<img" not in html
    assert "did not cite any websites" in html


def test_json_roundtrip_and_branding(result):
    data = json.loads(render_json(result, Branding("Acme", "bad")))
    assert data["business"] == "Smile Dental"
    assert data["scores"]["visibility"] == result["scores"]["visibility"]
    assert data["branding"] == {"brand_name": "Acme", "brand_color": DEFAULT_COLOR, "logo_url": "", "agency_contact": ""}
    assert "branding" not in json.loads(render_json(result))


def test_markdown(result):
    md = render_markdown(result, Branding("Acme", agency_contact="hi@acme.test"))
    assert md.startswith("> **Demo data:")  # the fake provider was used
    assert "\n# AI Visibility Report: Smile Dental\n" in md
    assert "## Score:" in md and "## By AI tool" in md and "## What to do next" in md
    assert "**Smile Dental (you)**" in md
    assert "Fresno Family Dentistry \\| open" not in md  # answers aren't dumped in md, only statuses
    assert "could not check (HTTP 401: bad <key>)" in md
    assert "Prepared by Acme" in md and "Contact: hi@acme.test" in md
    assert "How this was measured" in md


def test_method_text_explains_api_vs_apps(result):
    for text in (render_html(result), render_markdown(result)):
        assert "API" in text and "not from the ChatGPT, Perplexity, Gemini or Claude apps" in text
        assert "personalization" in text and "location" in text and "day to day" in text


def test_demo_flag_and_banner_for_old_json(result):
    old = {k: v for k, v in result.items() if k != "demo"}  # JSON saved before the "demo" field existed
    assert json.loads(render_json(old))["demo"] is True
    assert "Demo data" in render_html(old)
    real = dict(old, providers=[{"name": "openai", "label": "ChatGPT (OpenAI)", "model": "m"}])
    assert json.loads(render_json(real))["demo"] is False
    assert "Demo data" not in render_html(real) and "Demo data" not in render_markdown(real)


def test_markdown_escapes_pipes_in_tables():
    r = run_audit(AuditInput(business="A|B Dental", city="X", category="y", questions=["q?"]), [FakeProvider(answers={"q": "A|B Dental"})], now=NOW)
    md = render_markdown(r)
    assert "A\\|B Dental (you)" in md


def test_csv(result):
    text = render_csv(result)
    rows = list(csv.DictReader(io.StringIO(text)))
    assert tuple(rows[0].keys()) == CSV_FIELDS
    assert len(rows) == len(result["rows"]) == 6
    first = rows[0]
    assert first["mentioned"] == "yes" and first["position"] == "2"
    assert "Valley Dental Care" in first["competitors"]
    assert "yelp.com" in first["cited_domains"] and first["website_cited"] == "yes"
    assert EVIL in first["answer"]  # CSV keeps raw text; it's data, not HTML
    errs = [r for r in rows if r["mentioned"] == "error"]
    assert len(errs) == 3 and "401" in errs[0]["error"]


def test_render_dispatch_and_unknown(result):
    for fmt in ("html", "json", "md", "csv"):
        assert render(result, fmt)
    with pytest.raises(ValueError, match="unknown format"):
        render(result, "pdf")


@pytest.mark.parametrize(
    "path,fmt",
    [("r.html", "html"), ("r.HTM", "html"), ("r.json", "json"), ("r.md", "md"), ("r.markdown", "md"),
     ("r.csv", "csv"), ("r.pdf", "html"), ("report", "html")],
)
def test_format_from_path(path, fmt):
    assert format_from_path(path) == fmt


def test_excerpt():
    assert excerpt("short") == "short"
    long = "word " * 200
    out = excerpt(long, 50)
    assert out.endswith(" ...") and len(out) <= 55
    assert excerpt(None) == ""


def test_valid_color_and_branding_props():
    assert valid_color("#abc") and valid_color("#A1B2C3")
    assert not valid_color("red") and not valid_color("#12345") and not valid_color("")
    assert Branding(logo_url="data:image/png;base64,xx").safe_logo.startswith("data:image/")
    assert Branding(logo_url="ftp://x").safe_logo == ""
