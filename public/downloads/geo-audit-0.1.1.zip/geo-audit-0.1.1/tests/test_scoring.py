import pytest

from geo_audit.scoring import (
    compute_scores,
    grade,
    is_directory,
    leaderboard,
    pct,
    provider_scores,
    scored_rows,
    share_of_voice,
    top_domains,
)


def row(provider, question, mentioned=False, position=None, competitors=(), positions=None, domains=(),
        kind="discovery", error=None, website_cited=False, unknown=False):
    return {
        "question": question,
        "kind": kind,
        "provider": provider,
        "label": provider.upper(),
        "model": "m",
        "text": "",
        "citations": [],
        "error": error,
        "analysis": {
            "mentioned": mentioned,
            "position": position,
            "competitors": list(competitors),
            "competitor_positions": dict(positions or {}),
            "domains": list(domains),
            "website_cited": website_cited,
            "unknown": unknown,
        },
    }


PROVIDERS = [{"name": "a", "label": "A", "model": "m"}, {"name": "b", "label": "B", "model": "m"}]


def sample_rows():
    return [
        row("a", "q1", True, 2, ["Rival One", "Rival Two"], {"Rival One": 1, "Rival Two": 3}, ["yelp.com", "smile.com"]),
        row("a", "q2", True, 1, ["Rival One"], {"Rival One": 2}, ["yelp.com"]),
        row("a", "q3", False, None, ["Rival One LLC"], {}, ["healthgrades.com"]),
        row("a", "brand", True, None, [], {}, ["smile.com"], kind="brand"),
        row("b", "q1", False, None, ["Rival One"], {"Rival One": 1}, ["yelp.com"]),
        row("b", "q2", True, 4, ["Rival Three"], {"Rival Three": 1}, []),
        row("b", "q3", error="HTTP 500: boom"),
        row("b", "brand", True, None, [], {}, [], kind="brand", unknown=True),
    ]


def test_pct_and_grade():
    assert pct(1, 3) == 33.3 and pct(0, 0) is None
    assert grade(None)[0] == "?"
    assert [grade(v)[0] for v in (100, 70, 69.9, 50, 30, 10, 9.9, 0)] == ["A", "A", "B", "B", "C", "D", "F", "F"]


def test_scored_rows_excludes_brand_and_errors():
    rows = sample_rows()
    assert len(scored_rows(rows)) == 5
    only_brand = [row("a", "x", True, kind="brand"), row("a", "y", kind="brand", error="e")]
    assert len(scored_rows(only_brand)) == 1  # falls back to all successful answers
    assert scored_rows([]) == []


def test_compute_scores_overall_math():
    s = compute_scores(sample_rows(), PROVIDERS, "Smile Dental", "smile.com")
    assert s["scored_answers"] == 5
    assert s["mentioned_answers"] == 3
    assert s["visibility"] == 60.0
    assert s["grade"] == "B"
    assert s["avg_position"] == round((2 + 1 + 4) / 3, 1)
    assert s["total_answers"] == 8 and s["failed_answers"] == 1
    assert s["providers_mentioning"] == ["A", "B"]


def test_provider_scores():
    ps = {p["name"]: p for p in provider_scores(sample_rows(), PROVIDERS)}
    a, b = ps["a"], ps["b"]
    assert (a["asked"], a["answered"], a["scored"], a["mentioned"], a["visibility"]) == (4, 4, 3, 2, 66.7)
    assert a["avg_position"] == 1.5 and a["errors"] == 0
    assert a["brand_questions"] == 1 and a["brand_known"] == 1
    assert (b["asked"], b["answered"], b["scored"], b["mentioned"], b["visibility"]) == (4, 3, 2, 1, 50.0)
    assert b["errors"] == 1 and b["error_messages"] == ["HTTP 500: boom"]
    assert b["brand_known"] == 0


def test_provider_with_only_errors_has_no_visibility():
    rows = [row("a", "q1", error="x"), row("a", "q2", error="x")]
    p = provider_scores(rows, PROVIDERS[:1])[0]
    assert p["visibility"] is None and p["errors"] == 2 and p["error_messages"] == ["x"]


def test_leaderboard_groups_fuzzy_names_and_ranks():
    board = leaderboard(sample_rows(), "Smile Dental")
    names = [e["name"] for e in board]
    assert names[0] == "Rival One"  # 4 scored answers (q1 a, q2 a, q3 a as "Rival One LLC", q1 b)
    rival = board[0]
    assert rival["mentions"] == 4 and rival["share"] == 80.0
    assert rival["avg_position"] == round((1 + 2 + 1) / 3, 1)
    assert rival["providers"] == ["A", "B"]
    you = next(e for e in board if e["is_business"])
    assert you["mentions"] == 3 and you["share"] == 60.0 and you["rank"] == 2
    assert [e["rank"] for e in board] == list(range(1, len(board) + 1))
    assert {"Rival Two", "Rival Three"} <= set(names)


def test_leaderboard_counts_a_competitor_once_per_answer():
    rows = [row("a", "q1", competitors=["X Dental", "X Dental LLC"])]
    board = leaderboard(rows, "Smile Dental")
    x = next(e for e in board if e["name"] == "X Dental")
    assert x["mentions"] == 1


def test_share_of_voice():
    board = leaderboard(sample_rows(), "Smile Dental")
    # you 3, rivals: Rival One 4, Rival Two 1, Rival Three 1
    assert share_of_voice(board) == pct(3, 3 + 4 + 1 + 1)
    assert share_of_voice(board, top_n=1) == pct(3, 7)
    assert share_of_voice([{"is_business": True, "mentions": 0}]) is None
    assert share_of_voice([]) is None


def test_top_domains():
    doms = top_domains(sample_rows(), "smile.com")
    by = {d["domain"]: d for d in doms}
    assert doms[0]["domain"] == "yelp.com" and by["yelp.com"]["answers"] == 3
    assert by["yelp.com"]["is_directory"] and not by["yelp.com"]["is_your_site"]
    assert by["yelp.com"]["with_business_mentioned"] == 2
    assert by["smile.com"]["is_your_site"] and by["smile.com"]["answers"] == 2
    assert by["healthgrades.com"]["providers"] == ["A"]
    assert len(top_domains(sample_rows(), limit=1)) == 1


@pytest.mark.parametrize("d,ok", [("yelp.com", True), ("maps.google.com", True), ("m.yelp.com", True), ("smile.com", False)])
def test_is_directory(d, ok):
    assert is_directory(d) is ok


def test_compute_scores_all_failed():
    rows = [row("a", "q1", error="x")]
    s = compute_scores(rows, PROVIDERS[:1], "Biz")
    assert s["visibility"] is None and s["grade"] == "?" and s["share_of_voice"] is None
