import re
from pathlib import Path

import yaml

SKILL = Path(__file__).resolve().parents[1] / "skills" / "geo-audit" / "SKILL.md"


def test_skill_frontmatter_is_valid():
    text = SKILL.read_text(encoding="utf-8")
    m = re.match(r"^---\n(.*?)\n---\n(.+)", text, re.S)
    assert m, "SKILL.md must start with YAML frontmatter"
    meta = yaml.safe_load(m.group(1))
    assert re.fullmatch(r"[a-z0-9-]{1,64}", meta["name"]) and meta["name"] == "geo-audit"
    assert 0 < len(meta["description"]) <= 1024
    assert "geo-audit run" in m.group(2)
