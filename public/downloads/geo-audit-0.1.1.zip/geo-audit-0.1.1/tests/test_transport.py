import io
import json
import socket
import urllib.error

import pytest

from geo_audit import transport as T
from geo_audit.transport import HttpRequest, HttpResponse, ProviderError, TransportError, error_message, post_json

from conftest import FakeTransport, http_error, timeout_error


def test_post_json_success_sends_json_and_headers(sleep):
    ft = FakeTransport({"ok": True})
    assert post_json("https://x.test/a", {"q": 1}, {"X-Key": "k"}, transport=ft, sleep=sleep, timeout=7) == {"ok": True}
    req = ft.requests[0]
    assert req.method == "POST" and req.url == "https://x.test/a" and req.timeout == 7
    assert req.headers["Content-Type"] == "application/json" and req.headers["X-Key"] == "k"
    assert "User-Agent" in req.headers
    assert req.json() == {"q": 1}
    assert sleep.calls == []


def test_retry_on_429_then_success_uses_retry_after(sleep):
    ft = FakeTransport(http_error(429, "slow down", {"Retry-After": "3"}), {"ok": 1})
    assert post_json("https://x", {}, transport=ft, sleep=sleep) == {"ok": 1}
    assert len(ft.requests) == 2
    assert sleep.calls == [3.0]


def test_retry_after_is_capped_and_bad_values_fall_back(sleep):
    ft = FakeTransport(http_error(429, "", {"retry-after": "9999"}), http_error(503, "", {"Retry-After": "soon"}), {"ok": 1})
    post_json("https://x", {}, transport=ft, sleep=sleep, backoff=1.5)
    assert sleep.calls == [30.0, 3.0]  # cap, then backoff * 2**1


def test_retries_5xx_max_two_then_gives_up(sleep):
    ft = FakeTransport(http_error(500, "boom"))
    with pytest.raises(ProviderError) as ei:
        post_json("https://x", {}, transport=ft, sleep=sleep, backoff=1)
    assert len(ft.requests) == 3  # first try + 2 retries
    assert sleep.calls == [1, 2]
    assert ei.value.status == 500
    assert "boom" in str(ei.value) and "3 tries" in str(ei.value)


def test_no_retry_on_4xx(sleep):
    ft = FakeTransport(http_error(401, "invalid x-api-key"))
    with pytest.raises(ProviderError, match="HTTP 401: invalid x-api-key") as ei:
        post_json("https://x", {}, transport=ft, sleep=sleep)
    assert len(ft.requests) == 1 and sleep.calls == [] and ei.value.status == 401


def test_timeout_is_retried_then_reported(sleep):
    ft = FakeTransport(timeout_error())
    with pytest.raises(ProviderError, match="timed out"):
        post_json("https://x", {}, transport=ft, sleep=sleep)
    assert len(ft.requests) == 3 and len(sleep.calls) == 2


def test_timeout_then_success(sleep):
    ft = FakeTransport(timeout_error(), {"ok": 2})
    assert post_json("https://x", {}, transport=ft, sleep=sleep) == {"ok": 2}


def test_invalid_json_reply(sleep):
    ft = FakeTransport(HttpResponse(200, "<html>oops</html>"))
    with pytest.raises(ProviderError, match="not valid JSON"):
        post_json("https://x", {}, transport=ft, sleep=sleep)


def test_max_retries_zero(sleep):
    ft = FakeTransport(http_error(429))
    with pytest.raises(ProviderError):
        post_json("https://x", {}, transport=ft, sleep=sleep, max_retries=0)
    assert len(ft.requests) == 1 and sleep.calls == []


@pytest.mark.parametrize(
    "body,expected",
    [
        ('{"error": {"message": "bad key", "type": "auth"}}', "bad key"),
        ('{"error": {"type": "overloaded_error"}}', "overloaded_error"),
        ('{"error": "plain"}', "plain"),
        ('[{"error": {"message": "gemini style", "status": "INVALID"}}]', "gemini style"),
        ('{"message": "top"}', "top"),
        ("not json", "not json"),
        ("", ""),
    ],
)
def test_error_message(body, expected):
    assert error_message(body) == expected


# ------------------------------------------------ the real urllib transport, with urlopen faked

class _Resp:
    def __init__(self, status, body, headers):
        self.status = status
        self._body = body
        self.headers = headers

    def read(self):
        return self._body

    def __enter__(self):
        return self

    def __exit__(self, *a):
        return False


def test_urllib_transport_success(monkeypatch):
    seen = {}

    def fake_urlopen(request, timeout):
        seen["url"], seen["timeout"], seen["method"] = request.full_url, timeout, request.get_method()
        seen["data"] = request.data
        return _Resp(200, b'{"a": 1}', {"Content-Type": "application/json"})

    monkeypatch.setattr(T.urllib.request, "urlopen", fake_urlopen)
    resp = T.urllib_transport(HttpRequest("POST", "https://x.test/", {"A": "b"}, b"{}", 5))
    assert resp.status == 200 and json.loads(resp.body) == {"a": 1}
    assert seen == {"url": "https://x.test/", "timeout": 5, "method": "POST", "data": b"{}"}


def test_urllib_transport_http_error_becomes_response(monkeypatch):
    def fake_urlopen(request, timeout):
        raise urllib.error.HTTPError(request.full_url, 429, "Too Many", {"Retry-After": "1"}, io.BytesIO(b'{"error":{}}'))

    monkeypatch.setattr(T.urllib.request, "urlopen", fake_urlopen)
    resp = T.urllib_transport(HttpRequest("POST", "https://x.test/"))
    assert resp.status == 429 and resp.headers["Retry-After"] == "1"


@pytest.mark.parametrize(
    "exc,is_timeout",
    [
        (socket.timeout("timed out"), True),
        (urllib.error.URLError(socket.timeout("timed out")), True),
        (urllib.error.URLError("Name or service not known"), False),
        (ConnectionResetError("reset"), False),
    ],
)
def test_urllib_transport_network_errors(monkeypatch, exc, is_timeout):
    def fake_urlopen(request, timeout):
        raise exc

    monkeypatch.setattr(T.urllib.request, "urlopen", fake_urlopen)
    with pytest.raises(TransportError) as ei:
        T.urllib_transport(HttpRequest("POST", "https://x.test/", timeout=2))
    assert ei.value.timeout is is_timeout
