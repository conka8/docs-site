# ghl-agency-kit

The delivery layer for AI agencies on GoHighLevel: set up a new client from a plan file, send a white-label
weekly results report, and back up / compare a client's configuration.
It works next to the GHL MCP servers you may already use; it is not another MCP server.

Free and open source (MIT). Python 3.10+, no dependencies besides PyYAML.

## Install

```bash
pip install .        # from this folder (not on PyPI yet)
ghl-kit --version
```

## Connect a client sub-account

1. In the client's sub-account: **Settings > Private Integrations > Create new integration**.
   Give it read access to contacts, opportunities, calendars, conversations, workflows and locations,
   plus write access to custom fields, custom values and tags if you will use `onboard`.
2. Copy the token and the sub-account (location) id, then:

```bash
export GHL_TOKEN=paste-the-token-here
export GHL_LOCATION_ID=paste-the-location-id-here
```

An OAuth access token works too. You can also pass `--token` and `--location-id`.

## Try it without an account (demo data)

Every command accepts `--fake-api demo` (built-in demo dental clinic) or `--fake-api FOLDER` (a folder with
`state.json`, see `examples/demo-api/`). Nothing is sent anywhere. Every report, onboarding report and snapshot made
this way starts with "Demo data from the built-in fake GoHighLevel account, not a real client." (and has `"demo": true`
in JSON), so a demo can't be mistaken for a real client's numbers. The files in `examples/output/` are demo output.

```bash
ghl-kit --fake-api demo report --from 2026-10-01 --to 2026-10-07 --compare-previous \
  --brand-name "Peak AI Agency" --brand-color "#0f766e" --client-name "Bright Smile Dental" -o report.html
ghl-kit --fake-api demo onboard examples/plan.yaml --dry-run
ghl-kit --fake-api demo snapshot export -o before.json
ghl-kit demo-data ./my-demo        # writes my-demo/state.json you can edit
```

## 1. Weekly client report

```bash
ghl-kit report --from 2026-10-01 --to 2026-10-07 --compare-previous \
  --brand-name "Your Agency" --brand-color "#0a7cff" --logo-url "https://your.site/logo.png" \
  --client-name "Bright Smile Dental" --timezone America/Chicago -o report.html
```

Output formats: `-o report.html` (email-friendly, prints to PDF from the browser), `-o report.md`, `-o report.json`
(or `--format`). Example highlights from the demo data:

```
- Your AI assistant booked 14 appointments, up 40% vs last week.
- 25 new leads came in, up 39% vs last week.
- 10 of 13 finished appointments showed up (77% show rate).
- You won 3 deals worth $5,480, up 99% vs last week.
- There is $15,000 in open pipeline across 6 opportunities.
- 42 conversations had activity, up 35% vs last week.
```

What the numbers mean:

| Metric | Definition |
|---|---|
| New leads | contacts added in the period |
| Appointments booked | appointments starting in the period, not cancelled |
| Show rate | showed / (showed + no-shows) |
| Booking rate | appointments booked / new leads |
| Won value | opportunities marked won in the period (status change date) |
| Pipeline value | value of all open opportunities right now |
| Conversations | conversations whose last message is in the period |

Empty weeks are fine: rates show "n/a" instead of dividing by zero. `--assistant-name "Sara"` changes the wording,
`--currency-symbol €` changes money formatting.

## 2. Onboard a new client

Write a plan (full example: `examples/plan.yaml`):

```yaml
client: Bright Smile Dental
custom_fields:
  - {name: Insurance Provider, type: SINGLE_OPTIONS, options: [Delta Dental, Aetna, "No insurance"]}
tags: [new-lead, ai-booked]
custom_values:
  - {name: Booking Link, value: "https://brightsmile.example/book"}
pipelines:
  - {name: Patient Pipeline, stages: [New Lead, Contacted, Booked, Showed]}
calendars: [New Patient Consult]
snapshot: Dental AI Snapshot v3
workflows: [AI Appointment Setter, Missed Call Text Back]
```

```bash
ghl-kit onboard plan.yaml --dry-run                      # shows what would happen, changes nothing
ghl-kit onboard plan.yaml -o onboarding.html --brand-name "Your Agency"
```

- Custom fields, tags and custom values are **created** through the API. If one with the same name exists it is
  reported as `exists` and left alone, so running the command twice is safe.
- Pipelines, calendars, snapshot import, phone number, A2P 10DLC registration and AI agent setup become a
  **checklist**. ghl-kit reads the account and marks pipelines, calendars and the snapshot's workflows as
  `verified`, `partial` (e.g. missing stages, draft workflows) or `not found`; the rest are `manual check`.
- Without `--dry-run`, onboard writes to the account right away and first prints
  `Writing to the GoHighLevel account <location id>... (use --dry-run to preview)`.
- Exit code 1 if anything failed to create; add `--strict` to also fail while checklist items are open.

## 3. Configuration backup and diff

```bash
ghl-kit snapshot export -o before.json
# ... a week later, or after someone "just changed one thing" ...
ghl-kit snapshot export -o after.json
ghl-kit snapshot diff before.json after.json            # text; --format md / json
ghl-kit snapshot diff before.json after.json --exit-code   # exit 1 when something changed (for cron/CI)
```

```
Pipelines:
  ~ Patient Pipeline
      stage 'Showed Up' name: 'Showed' -> 'Showed Up'
Tags:
  + no-show-follow-up
Calendars:
  - Cleaning
Workflows:
  ~ Missed Call Text Back
      status: 'draft' -> 'published'

1 added, 1 removed, 2 changed.
```

Items are matched by id, then by name (so you can also compare a client account against your template account).
The export covers pipelines and stages, custom fields, tags, custom values, calendars and workflow names/status.
It is a JSON backup for comparison, not a GHL "Snapshot" you can load back.

## Claude skills

`skills/ghl-weekly-report/SKILL.md` and `skills/ghl-onboard-client/SKILL.md` teach Claude (Claude Code, Cowork,
OpenClaw) to run these commands for you. Copy the folders into your skills directory (e.g. `~/.claude/skills/`).

## Limits and things to verify

- **Verify against current GHL API v2 docs.** Every path, query parameter and field name lives in
  `src/ghl_kit/endpoints.py`. They are best knowledge (Oct 2026) and were tested only against the built-in fake API,
  not a live account. If GHL changes something, fix it there.
- Reports page through all contacts, opportunities and conversations of the sub-account, so very large accounts
  take longer. Rate limits (429) are retried automatically using the `Retry-After` header. Reads are also retried
  on server errors (5xx). Creates (POST) are only retried on a 429 with `Retry-After`, never on a server error,
  so a hiccup can't create the same field twice: just run `onboard` again (existing items are skipped).
- Calendar events are read per calendar; appointments on user-only calendars that are not listed by
  `/calendars/` are not counted.
- Conversation counts use the last-message date: a conversation that continued into this week counts in this
  week only.
- Pipeline value is a "right now" number, so it has no week-over-week change.
- Phone numbers, A2P registration and AI agent configuration can't be read through the API: they stay `manual check`.
- Sub-account creation and snapshot loading need agency-level access and are left as checklist steps.

## Development

```bash
cd ghl-agency-kit && ../.venv/bin/python -m pytest -q
```

Tests use a fake GHL API (no network, no keys) plus one real `http.server` on 127.0.0.1 to exercise `urllib`.
