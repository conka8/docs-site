> **Demo data from the built-in fake GoHighLevel account, not a real client.**

# Configuration changes

From: Bright Smile Dental (2026-10-29T14:08:43Z)  
To: Bright Smile Dental (2026-10-08T09:00:00Z)

| Resource | Added | Removed | Changed |
|---|---|---|---|
| Pipelines | 0 | 0 | 1 |
| Custom fields | 0 | 0 | 0 |
| Tags | 1 | 0 | 0 |
| Custom values | 0 | 0 | 0 |
| Calendars | 0 | 1 | 0 |
| Workflows | 0 | 0 | 1 |

## Pipelines

- Changed: **Patient Pipeline**
  - stage 'Showed Up' name: 'Showed' -> 'Showed Up'

## Tags

- Added: **no-show-follow-up**

## Calendars

- Removed: **Cleaning**

## Workflows

- Changed: **Missed Call Text Back**
  - status: 'draft' -> 'published'
