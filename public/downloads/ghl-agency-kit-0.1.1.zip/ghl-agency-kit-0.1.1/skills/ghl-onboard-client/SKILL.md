---
name: ghl-onboard-client
description: Onboards a new client into a GoHighLevel sub-account with the ghl-kit CLI. Writes a plan file, creates custom fields, tags and custom values without duplicates, and checks pipelines, calendars, snapshot workflows, phone, A2P and AI agent setup into a checklist. Use when an agency says "set up a new client", "onboard this account", or asks what is still missing in a client's GHL setup.
---

# Onboard a client in GoHighLevel

Use the `ghl-kit onboard` command (package `ghl-agency-kit`). It creates what the API supports and
produces a checklist for the steps that must be done by hand. Do not call the GHL API yourself.

## Steps

1. Confirm `GHL_TOKEN` (Private Integration token with locations/customFields, customValues, tags write
   scopes plus read scopes for opportunities, calendars, workflows) and `GHL_LOCATION_ID` are set.
   If not, ask the user. Never echo the token.
2. Interview the user briefly, then write `plan.yaml`:

```yaml
client: Bright Smile Dental
custom_fields:
  - {name: Preferred Dentist, type: TEXT}
  - {name: Insurance Provider, type: SINGLE_OPTIONS, options: [Delta Dental, Aetna, "No insurance"]}
tags: [new-lead, ai-booked]
custom_values:
  - {name: Booking Link, value: "https://example.com/book"}
pipelines:
  - {name: Patient Pipeline, stages: [New Lead, Contacted, Booked, Showed, Treatment Accepted]}
calendars: [New Patient Consult]
snapshot: Dental AI Snapshot v3
workflows: [AI Appointment Setter, Missed Call Text Back]   # what the snapshot should create
phone_number: "+1 512 555 0100"
ai_agent: Front-desk Conversation AI
manual_steps:
  - {title: Connect Google Business Profile, how_to: "Settings > Integrations > Google"}
```

   Field types: TEXT, LARGE_TEXT, NUMERICAL, PHONE, MONETORY, CHECKBOX, SINGLE_OPTIONS, MULTIPLE_OPTIONS,
   FLOAT, TIME, DATE, TEXTBOX_LIST, FILE_UPLOAD, SIGNATURE, RADIO. Quote option values like "Yes"/"No".
3. Always dry-run first and show the user the result:
   `ghl-kit onboard plan.yaml --dry-run`
4. After the user agrees, apply it and save the report:
   `ghl-kit onboard plan.yaml -o onboarding.html --brand-name "Your Agency" --client-name "Client"`
   Running it again is safe: existing items are reported as "exists", nothing is duplicated.
5. Walk the user through every checklist item that is not "verified", using the "How" line.
   Pipelines, calendars, snapshot import, phone number, A2P 10DLC and the AI agent are done in the GHL UI.
   Re-run step 4 afterwards; use `--strict` to get exit code 1 while anything is still open.

## Before/after backup

Suggest `ghl-kit snapshot export -o before.json` before onboarding and `ghl-kit snapshot export -o after.json`
after, then `ghl-kit snapshot diff before.json after.json --format md` to show the client exactly what changed.

## Errors

- Exit 2 "Setup needed": missing token or location id. Exit 2 "Error": bad plan file (the message says which line/item).
- Exit 1: a create failed (see the "failed" rows: often a missing write scope) or `--strict` found open items.
