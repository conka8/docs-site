---
name: ghl-weekly-report
description: Builds a white-label weekly results report (leads, booked and showed appointments, won deals, pipeline value, conversations, week-over-week changes) for a GoHighLevel client sub-account using the ghl-kit CLI. Use when an agency asks for a client report, weekly/monthly results, proof-of-value email, or "how did the AI assistant do this week" for a GHL account.
---

# GHL weekly client report

You produce client-facing results reports with the `ghl-kit` command line tool (package `ghl-agency-kit`).
Do not call the GoHighLevel API yourself and do not invent numbers: every figure comes from `ghl-kit`.

## Before you start

1. Check the tool is installed: `ghl-kit --version`. If not: run `pip install .` in the ghl-agency-kit folder.
2. Check the credentials are set for the client's sub-account:
   - `GHL_TOKEN`: a Private Integration token (or OAuth access token) with read scopes for contacts,
     opportunities, calendars, conversations and locations.
   - `GHL_LOCATION_ID`: the sub-account id.
   If either is missing, ask the user for it. Never print the token back.
3. Ask for (or infer) the period. Default: the last full Monday-Sunday week. Dates are `YYYY-MM-DD`, `--to` is inclusive.
4. Ask for branding if the user has not given it: agency name, brand color (hex), logo URL, client name.

## Run it

```bash
ghl-kit report --from 2026-10-01 --to 2026-10-07 --compare-previous \
  --brand-name "Your Agency" --brand-color "#0a7cff" --logo-url "https://.../logo.png" \
  --client-name "Client Name" --timezone America/Chicago -o report.html
ghl-kit report --from 2026-10-01 --to 2026-10-07 --compare-previous --format json -o report.json
```

- Use the client's time zone with `--timezone` so "Monday" means the client's Monday.
- `--assistant-name "Sara"` changes "Your AI assistant booked ..." to "Sara booked ...".
- No account handy (demo, testing): add `--fake-api demo` before `report`.

## After it runs

1. Read `report.json` and write a short (3-5 sentence) note to the client in plain English:
   lead with the best number, mention one thing to improve (no-shows, low booking rate), suggest one next step.
   Use only numbers that appear in the JSON. If a rate is `null` there was no data for it: say so, don't compute one.
2. Give the user `report.html`. It is email-friendly (tables, inline styles) and prints to PDF from the browser.
3. If the command fails:
   - exit code 2 + "Setup needed": a missing token or location id. Tell the user which one.
   - "rejected the token (401)": the token is wrong or expired.
   - "not allowed (403)": the token is missing a scope; name the scope from the message.
   - "too many requests (429)": wait a minute and run again.

## Definitions (repeat these if the client asks)

- Booking rate = appointments booked / new leads. Show rate = showed / (showed + no-shows).
- Won value = deals marked won during the period. Pipeline value = open opportunities right now.
- Conversations = conversations whose last message falls in the period.
