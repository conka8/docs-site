"""ghl-agency-kit: onboarding, client reports and config backup/diff for GoHighLevel agencies."""
__version__ = "0.1.1"
