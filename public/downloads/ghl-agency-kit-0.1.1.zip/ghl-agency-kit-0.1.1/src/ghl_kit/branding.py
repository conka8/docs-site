"""White-label options and the demo-data notice shared by the outputs."""
from __future__ import annotations

import html
import re
from dataclasses import dataclass

_HEX = re.compile(r"^#(?:[0-9a-fA-F]{3}|[0-9a-fA-F]{4}|[0-9a-fA-F]{6}|[0-9a-fA-F]{8})$")
_NAMED = re.compile(r"^[a-zA-Z]{3,20}$")
DEMO_NOTICE = "Demo data from the built-in fake GoHighLevel account, not a real client."
DEMO_BANNER_STYLE = ("background:#fef3c7;border:2px solid #b26a00;border-radius:8px;padding:10px 14px;"
                     "font-weight:700;color:#1b1b1b;margin:0 0 16px")


@dataclass
class Branding:
    brand_name: str = ""
    brand_color: str = "#2a78d6"
    logo_url: str = ""
    client_name: str = ""

    def __post_init__(self):
        self.brand_color = validate_color(self.brand_color or "#2a78d6")
        self.logo_url = validate_logo_url(self.logo_url or "")


def validate_color(value: str) -> str:
    value = value.strip()
    if _HEX.match(value) or _NAMED.match(value):
        return value
    raise ValueError(f"--brand-color must be a hex color like #0a7cff or a color name like teal, not {value!r}")


def validate_logo_url(value: str) -> str:
    value = value.strip()
    if not value:
        return ""
    if value.startswith(("https://", "http://", "data:image/")):
        return value
    raise ValueError(f"--logo-url must start with https:// (or be a data:image/ URL), not {value!r}")


def esc(value) -> str:
    return html.escape("" if value is None else str(value), quote=True)


def demo_banner_html(demo: bool) -> str:
    return f'<div class="demo" style="{DEMO_BANNER_STYLE}">{esc(DEMO_NOTICE)}</div>' if demo else ""


def demo_md_line(demo: bool) -> list[str]:
    """First line(s) for Markdown/text outputs."""
    return [f"> **{DEMO_NOTICE}**", ""] if demo else []
