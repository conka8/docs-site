"""Command line interface: `ghl-kit onboard | report | snapshot export | snapshot diff | demo-data`."""
from __future__ import annotations

import argparse
import json
import os
import sys
from datetime import timezone
from pathlib import Path

from . import __version__
from . import endpoints as ep
from .branding import Branding
from .client import ConfigError, GHLClient, GHLError

EXIT_OK, EXIT_FAIL, EXIT_USAGE = 0, 1, 2


def _add_conn(p: argparse.ArgumentParser, default):
    p.add_argument("--token", default=default, help=f"API token (default: ${ep.TOKEN_ENV})")
    p.add_argument("--location-id", default=default, help=f"sub-account id (default: ${ep.LOCATION_ENV})")
    p.add_argument("--fake-api", default=default, metavar="DIR",
                   help="demo/testing: answer API calls from DIR/state.json (or the word 'demo') instead of GoHighLevel")


def _add_brand(p: argparse.ArgumentParser):
    p.add_argument("--brand-name", default="", help="your agency name (white-label)")
    p.add_argument("--brand-color", default="#2a78d6", help="header color, e.g. #0a7cff")
    p.add_argument("--logo-url", default="", help="https:// URL of your logo")
    p.add_argument("--client-name", default="", help="client name shown on the report")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="ghl-kit",
        description="Client onboarding, weekly reports and config backup/diff for GoHighLevel agencies.")
    parser.add_argument("--version", action="version", version=f"ghl-kit {__version__}")
    _add_conn(parser, None)
    conn = argparse.ArgumentParser(add_help=False)
    _add_conn(conn, argparse.SUPPRESS)
    sub = parser.add_subparsers(dest="command", metavar="COMMAND")

    p = sub.add_parser("onboard", parents=[conn], help="set up a client sub-account from a plan file")
    p.add_argument("plan", help="plan file (.yaml or .json)")
    p.add_argument("--dry-run", action="store_true", help="show what would happen, change nothing")
    p.add_argument("-o", "--output", help="write the report here (.md, .html or .json)")
    p.add_argument("--format", choices=("md", "html", "json"), help="report format (default: from -o, else md)")
    p.add_argument("--strict", action="store_true", help="exit 1 if any checklist item is not verified")
    _add_brand(p)

    p = sub.add_parser("report", parents=[conn], help="client results report for a date range")
    p.add_argument("--from", dest="date_from", required=True, help="first day, YYYY-MM-DD")
    p.add_argument("--to", dest="date_to", required=True, help="last day, YYYY-MM-DD (inclusive)")
    p.add_argument("--compare-previous", action="store_true", help="compare with the period just before")
    p.add_argument("-o", "--output", help="write the report here (.html, .md or .json)")
    p.add_argument("--format", choices=("html", "md", "json"), help="default: from -o, else md")
    p.add_argument("--timezone", default="UTC", help="IANA time zone for day boundaries, e.g. America/Chicago")
    p.add_argument("--assistant-name", default="Your AI assistant", help='used in highlights ("... booked 14 appointments")')
    p.add_argument("--currency-symbol", default="$")
    _add_brand(p)

    p = sub.add_parser("snapshot", help="export or compare configuration backups")
    ssub = p.add_subparsers(dest="snap_command", metavar="ACTION")
    e = ssub.add_parser("export", parents=[conn], help="save pipelines, fields, tags, values, calendars, workflows")
    e.add_argument("-o", "--output", required=True, help="output JSON file")
    d = ssub.add_parser("diff", help="compare two snapshot files")
    d.add_argument("a", help="older snapshot")
    d.add_argument("b", help="newer snapshot")
    d.add_argument("--format", choices=("text", "md", "json"), default="text")
    d.add_argument("-o", "--output", help="write the diff to a file")
    d.add_argument("--exit-code", action="store_true", help="exit 1 when there are differences")

    p = sub.add_parser("demo-data", help="write the demo sub-account to DIR/state.json for --fake-api DIR")
    p.add_argument("directory")
    return parser


def make_client(args, env=None) -> GHLClient:
    env = os.environ if env is None else env
    fake = getattr(args, "fake_api", None)
    if fake:
        from .fake import load_fake_api
        transport = load_fake_api(fake, getattr(args, "location_id", None))
        location = getattr(args, "location_id", None) or getattr(transport, "location_id", None) \
            or getattr(getattr(transport, "fallback", None), "location_id", None) or "fake-location"
        return GHLClient(getattr(args, "token", None) or "fake-token", location, transport=transport, demo=True)
    return GHLClient.from_env(env, token=getattr(args, "token", None), location_id=getattr(args, "location_id", None))


def _write(text: str, output: str | None, out) -> None:
    if output:
        Path(output).parent.mkdir(parents=True, exist_ok=True)
        Path(output).write_text(text, encoding="utf-8")
        print(f"Wrote {output}", file=out)
    else:
        out.write(text)


def _fmt_from(args, default: str, allowed: tuple) -> str:
    if args.format:
        return args.format
    if args.output:
        ext = Path(args.output).suffix.lower().lstrip(".")
        ext = {"markdown": "md", "htm": "html", "txt": "text"}.get(ext, ext)
        if ext in allowed:
            return ext
    return default


def _branding(args) -> Branding:
    return Branding(args.brand_name, args.brand_color, args.logo_url, args.client_name)


def cmd_onboard(args, out, env) -> int:
    from . import onboard
    branding = _branding(args)
    plan = onboard.load_plan(args.plan)
    client = make_client(args, env)
    if not args.dry_run:
        where = "the fake demo account" if client.demo else "the GoHighLevel account"
        print(f"Writing to {where} {client.location_id}... (use --dry-run to preview)", file=sys.stderr)
    result = onboard.run_onboarding(client, plan, dry_run=args.dry_run)
    fmt = _fmt_from(args, "md", ("md", "html", "json"))
    text = {"md": onboard.render_markdown, "json": onboard.render_json}.get(fmt, None)
    text = text(result) if text else onboard.render_html(result, branding)
    _write(text, args.output, out)
    if args.output:
        verified = len(result.checklist) - len(result.open_items)
        print(f"{len(result.actions)} API items ({len(result.failed)} failed); "
              f"checklist {verified}/{len(result.checklist)} verified.", file=out)
    if result.failed:
        return EXIT_FAIL
    if args.strict and result.open_items:
        return EXIT_FAIL
    return EXIT_OK


def cmd_report(args, out, env) -> int:
    from . import report
    from .timeutil import parse_day
    branding = _branding(args)
    period = report.Period(parse_day(args.date_from), parse_day(args.date_to))
    tz = _timezone(args.timezone)
    client = make_client(args, env)
    rep = report.run_report(client, period, tz, args.compare_previous, assistant=args.assistant_name,
                            currency=args.currency_symbol)
    fmt = _fmt_from(args, "md", ("html", "md", "json"))
    if fmt == "html":
        text = report.render_html(rep, branding)
    elif fmt == "json":
        text = report.render_json(rep)
    else:
        text = report.render_markdown(rep, branding)
    _write(text, args.output, out)
    if args.output:
        for h in rep["highlights"]:
            print(f"- {h}", file=out)
    return EXIT_OK


def _timezone(name: str):
    if not name or name.upper() == "UTC":
        return timezone.utc
    try:
        from zoneinfo import ZoneInfo
        return ZoneInfo(name)
    except Exception as exc:  # noqa: BLE001
        raise ValueError(f"Unknown time zone '{name}'. Use a name like America/New_York or UTC.") from exc


def cmd_snapshot(args, out, env) -> int:
    from . import snapshot
    if args.snap_command == "export":
        client = make_client(args, env)
        snap = snapshot.export_snapshot(client)
        _write(json.dumps(snap, indent=2) + "\n", args.output, out)
        counts = ", ".join(f"{len(snap[k])} {k.replace('_', ' ')}" for k in snapshot.RESOURCE_TYPES)
        print(f"Saved {counts}.", file=out)
        return EXIT_OK
    if args.snap_command == "diff":
        a, b = snapshot.load_snapshot(args.a), snapshot.load_snapshot(args.b)
        diff = snapshot.diff_snapshots(a, b)
        render = {"text": snapshot.render_text, "md": snapshot.render_markdown, "json": snapshot.render_json}[args.format]
        _write(render(diff), args.output, out)
        return EXIT_FAIL if (args.exit_code and snapshot.has_differences(diff)) else EXIT_OK
    print("Choose an action: ghl-kit snapshot export -o snap.json  |  ghl-kit snapshot diff a.json b.json",
          file=sys.stderr)
    return EXIT_USAGE


def cmd_demo_data(args, out, env) -> int:
    from .demo import build_demo_state
    d = Path(args.directory)
    d.mkdir(parents=True, exist_ok=True)
    (d / "state.json").write_text(json.dumps(build_demo_state(), indent=2) + "\n", encoding="utf-8")
    print(f"Wrote {d / 'state.json'}. Try: ghl-kit --fake-api {d} report --from 2026-10-01 --to 2026-10-07 "
          f"--compare-previous", file=out)
    return EXIT_OK


def main(argv=None, env=None, out=None) -> int:
    out = out or sys.stdout
    parser = build_parser()
    try:
        args = parser.parse_args(argv)
    except SystemExit as exc:  # argparse already printed the message
        return int(exc.code or 0)
    handlers = {"onboard": cmd_onboard, "report": cmd_report, "snapshot": cmd_snapshot, "demo-data": cmd_demo_data}
    if not args.command:
        parser.print_help(out)
        return EXIT_USAGE
    try:
        return handlers[args.command](args, out, env)
    except ConfigError as exc:
        print(f"Setup needed: {exc}", file=sys.stderr)
        return EXIT_USAGE
    except GHLError as exc:
        print(f"GoHighLevel error: {exc}", file=sys.stderr)
        return EXIT_FAIL
    except (ValueError, FileNotFoundError) as exc:
        print(f"Error: {exc}", file=sys.stderr)
        return EXIT_USAGE
    except OSError as exc:
        print(f"Error: {exc}", file=sys.stderr)
        return EXIT_FAIL
