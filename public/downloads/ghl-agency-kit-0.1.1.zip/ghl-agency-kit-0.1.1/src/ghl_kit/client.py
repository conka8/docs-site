"""Small GoHighLevel API v2 client: auth headers, pagination, 429 retries, readable errors.

HTTP goes through a *transport* function so tests (and the --fake-api demo mode) can replace it:

    transport(method, url, headers, body_bytes_or_None, timeout) -> (status, headers_dict, body_bytes)
"""
from __future__ import annotations

import email.utils
import json
import os
import time
import urllib.error
import urllib.parse
import urllib.request
from datetime import datetime, timezone
from typing import Any, Callable, Iterator

from . import __version__
from . import endpoints as ep

Transport = Callable[[str, str, dict, "bytes | None", float], "tuple[int, dict, bytes]"]


class GHLError(Exception):
    """Any problem talking to GoHighLevel. `status` is the HTTP status (0 if no response)."""

    def __init__(self, message: str, status: int = 0, path: str = ""):
        super().__init__(message)
        self.status = status
        self.path = path


class GHLAuthError(GHLError):
    pass


class GHLForbidden(GHLError):
    pass


class GHLNotFound(GHLError):
    pass


class GHLRateLimited(GHLError):
    pass


class ConfigError(Exception):
    """Missing token / location id or other local setup problem."""


def urllib_transport(method: str, url: str, headers: dict, body: bytes | None, timeout: float = 30.0):
    req = urllib.request.Request(url, data=body, headers=headers, method=method)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:  # noqa: S310 (https only in practice)
            return resp.status, dict(resp.headers.items()), resp.read()
    except urllib.error.HTTPError as exc:
        hdrs = dict(exc.headers.items()) if exc.headers else {}
        return exc.code, hdrs, exc.read() or b""
    except urllib.error.URLError as exc:
        raise GHLError(f"Could not reach GoHighLevel at {url}: {exc.reason}") from exc


def _header(headers: dict, name: str) -> str | None:
    for key, value in (headers or {}).items():
        if key.lower() == name.lower():
            return value
    return None


def parse_retry_after(value: str | None, now: datetime | None = None) -> float | None:
    """Seconds to wait from a Retry-After header (seconds or HTTP date). None if unusable."""
    if value is None:
        return None
    value = str(value).strip()
    try:
        secs = float(value)
        return max(0.0, secs)
    except ValueError:
        pass
    try:
        when = email.utils.parsedate_to_datetime(value)
    except (TypeError, ValueError, IndexError):
        return None
    if when is None:
        return None
    if when.tzinfo is None:
        when = when.replace(tzinfo=timezone.utc)
    now = now or datetime.now(timezone.utc)
    return max(0.0, (when - now).total_seconds())


def _error_message(body: bytes) -> str:
    try:
        data = json.loads(body.decode("utf-8"))
    except (ValueError, UnicodeDecodeError):
        text = body.decode("utf-8", "replace").strip()
        return text[:300]
    if isinstance(data, dict):
        msg = data.get("message") or data.get("error") or data.get("msg")
        if isinstance(msg, list):
            msg = "; ".join(str(m) for m in msg)
        if msg:
            return str(msg)
    return json.dumps(data)[:300]


class GHLClient:
    def __init__(
        self,
        token: str,
        location_id: str,
        transport: Transport | None = None,
        base_url: str = ep.BASE_URL,
        sleep: Callable[[float], None] = time.sleep,
        max_retries: int = 4,
        timeout: float = 30.0,
        max_pages: int = 500,
        max_wait: float = 120.0,
        demo: bool = False,
    ):
        if not token:
            raise ConfigError(missing_token_message())
        if not location_id:
            raise ConfigError(missing_location_message())
        self.token = token
        self.location_id = location_id
        self.transport = transport or urllib_transport
        self.base_url = base_url.rstrip("/")
        self.sleep = sleep
        self.max_retries = max_retries
        self.timeout = timeout
        self.max_pages = max_pages
        self.max_wait = max_wait
        # demo = answers come from the built-in fake account; every output then says so
        self.demo = bool(demo or getattr(self.transport, "is_fake", False))

    @classmethod
    def from_env(cls, env: dict | None = None, token: str | None = None, location_id: str | None = None, **kw):
        env = os.environ if env is None else env
        token = token or env.get(ep.TOKEN_ENV, "").strip()
        location_id = location_id or env.get(ep.LOCATION_ENV, "").strip()
        return cls(token, location_id, **kw)

    # ---- low level ---------------------------------------------------------------------
    def headers(self, with_body: bool = False) -> dict:
        h = {
            "Authorization": f"Bearer {self.token}",
            "Version": ep.API_VERSION,
            "Accept": "application/json",
            "User-Agent": f"ghl-agency-kit/{__version__}",
        }
        if with_body:
            h["Content-Type"] = "application/json"
        return h

    def build_url(self, path: str, params: dict | None = None) -> str:
        path = path.replace("{locationId}", urllib.parse.quote(self.location_id, safe=""))
        url = self.base_url + path
        clean = {k: v for k, v in (params or {}).items() if v is not None}
        if clean:
            url += "?" + urllib.parse.urlencode(clean, doseq=True)
        return url

    def request(self, method: str, path: str, params: dict | None = None, json_body: Any = None,
                idempotent: bool | None = None) -> dict:
        """One API call. Safe calls (GET, and searches marked ``idempotent``) are retried on 429 and 5xx.
        Other POSTs (creates) are only retried on 429 with a Retry-After header, because after a 5xx the
        item may already exist and a retry could create it twice."""
        url = self.build_url(path, params)
        body = json.dumps(json_body).encode("utf-8") if json_body is not None else None
        headers = self.headers(with_body=body is not None)
        safe = (method.upper() != "POST") if idempotent is None else idempotent
        attempt = 0
        while True:
            status, resp_headers, resp_body = self.transport(method, url, headers, body, self.timeout)
            if status == 429 or status in (500, 502, 503, 504):
                wait = parse_retry_after(_header(resp_headers, "Retry-After")) if status == 429 else None
                if not safe and wait is None:
                    if status == 429:
                        raise GHLRateLimited(
                            f"GoHighLevel answered 'too many requests' (429) for {method} {path}. "
                            f"Wait a minute and run the command again.", status, path)
                    raise GHLError(f"GoHighLevel server error {status} for {method} {path}: "
                                   f"{_error_message(resp_body)}. Not retried, so nothing is created twice: "
                                   f"run the command again (items that exist are skipped).", status, path)
                if attempt >= self.max_retries:
                    if status == 429:
                        raise GHLRateLimited(
                            f"GoHighLevel kept answering 'too many requests' (429) for {method} {path} "
                            f"after {attempt} retries. Wait a minute and run the command again.",
                            status, path)
                    raise GHLError(f"GoHighLevel server error {status} for {method} {path}: "
                                   f"{_error_message(resp_body)}", status, path)
                if wait is None:
                    wait = min(2 ** attempt, 30)
                self.sleep(min(wait, self.max_wait))
                attempt += 1
                continue
            break
        if 200 <= status < 300:
            if not resp_body:
                return {}
            try:
                data = json.loads(resp_body.decode("utf-8"))
            except (ValueError, UnicodeDecodeError) as exc:
                raise GHLError(f"GoHighLevel returned something that is not JSON for {method} {path}.",
                               status, path) from exc
            return data if isinstance(data, dict) else {"data": data}
        detail = _error_message(resp_body)
        if status == 401:
            raise GHLAuthError(
                f"GoHighLevel rejected the token (401 Unauthorized) for {method} {path}. "
                f"Check that {ep.TOKEN_ENV} is a valid Private Integration token or OAuth access token "
                f"for this sub-account and that it has not expired. Server said: {detail}", status, path)
        if status == 403:
            raise GHLForbidden(
                f"The token is not allowed to do {method} {path} (403 Forbidden). "
                f"Give the Private Integration the needed scope (for example contacts.readonly, "
                f"opportunities.readonly, calendars.readonly, locations/customFields.write) and check "
                f"that {ep.LOCATION_ENV} is a sub-account this token belongs to. Server said: {detail}",
                status, path)
        if status == 404:
            raise GHLNotFound(
                f"GoHighLevel says {method} {path} was not found (404). Check {ep.LOCATION_ENV} "
                f"('{self.location_id}'); if it is right, the endpoint may have moved: see endpoints.py. "
                f"Server said: {detail}", status, path)
        raise GHLError(f"GoHighLevel error {status} for {method} {path}: {detail}", status, path)

    # ---- pagination --------------------------------------------------------------------
    def paginate(self, endpoint: ep.Endpoint, params: dict | None = None, body: dict | None = None) -> Iterator[dict]:
        params = dict(params or {})
        body = dict(body) if body is not None else None
        if endpoint.location_param:
            if endpoint.method == "GET":
                params.setdefault(endpoint.location_param, self.location_id)
            else:
                body = body if body is not None else {}
                body.setdefault(endpoint.location_param, self.location_id)
        style = endpoint.paging
        if style not in ep.PAGING_STYLES:
            raise ValueError(f"unknown paging style {style!r}")
        size = endpoint.page_size
        if endpoint.limit_param and style != "page_body":
            params.setdefault(endpoint.limit_param, size)
        page = 1
        seen_cursors: set = set()
        for _ in range(self.max_pages):
            if style == "page":
                params[endpoint.page_param] = page
            if style == "page_body":
                body = body if body is not None else {}
                body[endpoint.page_param] = page
                body[endpoint.limit_param or "pageLimit"] = size
            data = self.request(endpoint.method, endpoint.path, params, body, idempotent=True)  # reads
            items = data.get(endpoint.items_key, []) if endpoint.items_key else []
            if not isinstance(items, list):
                items = []
            yield from items
            if style == "none" or not items or len(items) < size:
                return
            if style in ("page", "page_body"):
                page += 1
                continue
            if style == "cursor_meta":
                meta = data.get("meta") or {}
                cursor = {param: meta.get(key) for key, param in endpoint.cursor_map if meta.get(key) is not None}
                if not cursor:
                    return
            else:  # last_item
                last = items[-1]
                value = None
                for f in endpoint.last_item_fields:
                    v = last.get(f)
                    if isinstance(v, list):
                        v = v[0] if v else None
                    if v not in (None, ""):
                        value = v
                        break
                if value is None:
                    return
                cursor = {endpoint.last_item_param: value}
            key = tuple(sorted((k, str(v)) for k, v in cursor.items()))
            if key in seen_cursors:
                return  # server repeated a cursor: stop instead of looping forever
            seen_cursors.add(key)
            params.update(cursor)
        raise GHLError(f"Stopped after {self.max_pages} pages of {endpoint.path}; raise max_pages if needed.")

    def get_list(self, endpoint: ep.Endpoint, params: dict | None = None, body: dict | None = None) -> list[dict]:
        return list(self.paginate(endpoint, params, body))

    # ---- resources ---------------------------------------------------------------------
    def location(self) -> dict:
        data = self.request("GET", ep.LOCATION.path)
        return data.get(ep.LOCATION.item_key) or data

    def list_contacts(self) -> list[dict]:
        return self.get_list(ep.CONTACTS_LIST)

    def search_contacts(self, filters: list | None = None, **extra) -> list[dict]:
        body = dict(extra)
        if filters:
            body["filters"] = filters
        return self.get_list(ep.CONTACTS_SEARCH, body=body)

    def search_opportunities(self, **params) -> list[dict]:
        return self.get_list(ep.OPPORTUNITIES_SEARCH, params)

    def pipelines(self) -> list[dict]:
        return self.get_list(ep.PIPELINES)

    def calendars(self) -> list[dict]:
        return self.get_list(ep.CALENDARS)

    def calendar_events(self, calendar_id: str, start_ms: int, end_ms: int) -> list[dict]:
        return self.get_list(ep.CALENDAR_EVENTS, {
            ep.EVENTS_CALENDAR_PARAM: calendar_id, ep.EVENTS_START_PARAM: start_ms, ep.EVENTS_END_PARAM: end_ms,
        })

    def custom_fields(self) -> list[dict]:
        return self.get_list(ep.CUSTOM_FIELDS)

    def custom_values(self) -> list[dict]:
        return self.get_list(ep.CUSTOM_VALUES)

    def tags(self) -> list[dict]:
        return self.get_list(ep.TAGS)

    def workflows(self) -> list[dict]:
        return self.get_list(ep.WORKFLOWS)

    def conversations(self) -> list[dict]:
        return self.get_list(ep.CONVERSATIONS_SEARCH)

    def create_custom_field(self, name: str, data_type: str = "TEXT", placeholder: str | None = None,
                            options: list | None = None) -> dict:
        body: dict[str, Any] = {ep.BODY_FIELD_NAME: name, ep.BODY_FIELD_TYPE: data_type}
        if placeholder:
            body[ep.BODY_FIELD_PLACEHOLDER] = placeholder
        if options:
            body[ep.BODY_FIELD_OPTIONS] = list(options)
        data = self.request("POST", ep.CREATE_CUSTOM_FIELD.path, json_body=body)
        return data.get(ep.CREATE_CUSTOM_FIELD.item_key) or data

    def create_custom_value(self, name: str, value: str) -> dict:
        data = self.request("POST", ep.CREATE_CUSTOM_VALUE.path,
                            json_body={ep.BODY_VALUE_NAME: name, ep.BODY_VALUE_VALUE: value})
        return data.get(ep.CREATE_CUSTOM_VALUE.item_key) or data

    def create_tag(self, name: str) -> dict:
        data = self.request("POST", ep.CREATE_TAG.path, json_body={ep.BODY_TAG_NAME: name})
        return data.get(ep.CREATE_TAG.item_key) or data


def missing_token_message() -> str:
    return (f"{ep.TOKEN_ENV} is not set. In the client's sub-account open Settings > Private Integrations, "
            f"create a token with the scopes you need, then run:  export {ep.TOKEN_ENV}=your-token  "
            f"(or pass --token).")


def missing_location_message() -> str:
    return (f"{ep.LOCATION_ENV} is not set. Copy the sub-account (location) id from Settings > Business Profile "
            f"or from the URL (/location/<id>/...), then run:  export {ep.LOCATION_ENV}=the-id  "
            f"(or pass --location-id).")
