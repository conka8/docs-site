"""Deterministic demo sub-account so every command can be shown without a GHL account.

Use it with:  ghl-kit --fake-api demo report --from 2026-10-01 --to 2026-10-07 --compare-previous
or write it to a folder with:  ghl-kit demo-data ./demo-api   (then edit state.json and use --fake-api ./demo-api)
"""
from __future__ import annotations

import random
from datetime import datetime, timedelta, timezone

from .timeutil import iso

DEMO_LOCATION = {"id": "demo-location", "name": "Bright Smile Dental", "timezone": "America/Chicago"}


def _at(day: datetime, rng: random.Random) -> datetime:
    return day + timedelta(hours=rng.randint(8, 19), minutes=rng.choice((0, 15, 30, 45)))


def build_demo_state(seed: int = 7) -> dict:
    rng = random.Random(seed)
    this_week = datetime(2026, 10, 1, tzinfo=timezone.utc)
    prev_week = datetime(2026, 9, 24, tzinfo=timezone.utc)
    stages = [("stg-new", "New Lead"), ("stg-contacted", "Contacted"), ("stg-booked", "Booked"),
              ("stg-showed", "Showed"), ("stg-won", "Treatment Accepted")]
    pipelines = [{
        "id": "pl-patients", "name": "Patient Pipeline",
        "stages": [{"id": sid, "name": name, "position": i} for i, (sid, name) in enumerate(stages)],
    }]
    calendars = [
        {"id": "cal-consult", "name": "New Patient Consult", "calendarType": "round_robin", "isActive": True,
         "slotDuration": 30},
        {"id": "cal-cleaning", "name": "Cleaning", "calendarType": "event", "isActive": True, "slotDuration": 60},
    ]
    contacts, events, opportunities, conversations = [], [], [], []
    n = 0

    def add_contacts(start: datetime, count: int):
        nonlocal n
        for _ in range(count):
            n += 1
            contacts.append({"id": f"ct-{n:03d}", "firstName": f"Lead{n}", "locationId": DEMO_LOCATION["id"],
                             "dateAdded": iso(_at(start + timedelta(days=rng.randint(0, 6)), rng)),
                             "source": rng.choice(["Facebook Ad", "Google", "Website chat", "Referral"])})

    add_contacts(datetime(2026, 9, 10, tzinfo=timezone.utc), 12)
    add_contacts(prev_week, 18)
    add_contacts(this_week, 25)

    def add_events(start: datetime, statuses: list[str]):
        for i, status in enumerate(statuses):
            events.append({
                "id": f"ev-{start:%m%d}-{i}", "calendarId": rng.choice(["cal-consult", "cal-consult", "cal-cleaning"]),
                "title": "Consultation", "appointmentStatus": status,
                "contactId": rng.choice(contacts)["id"],
                "startTime": iso(_at(start + timedelta(days=rng.randint(0, 6)), rng)),
                "dateAdded": iso(start - timedelta(days=1)),
            })

    add_events(prev_week, ["showed"] * 7 + ["noshow"] * 2 + ["confirmed"] + ["cancelled"])
    add_events(this_week, ["showed"] * 10 + ["noshow"] * 3 + ["confirmed"] + ["cancelled"])

    o = 0

    def add_opps(start: datetime, specs: list[tuple[str, str, float]]):
        nonlocal o
        for status, stage, value in specs:
            o += 1
            created = _at(start + timedelta(days=rng.randint(0, 3)), rng)
            changed = created + timedelta(days=rng.randint(0, 3))
            opportunities.append({
                "id": f"op-{o:03d}", "name": f"Patient {o}", "pipelineId": "pl-patients", "pipelineStageId": stage,
                "status": status, "monetaryValue": value, "createdAt": iso(created), "updatedAt": iso(changed),
                "lastStatusChangeAt": iso(changed), "contactId": contacts[o % len(contacts)]["id"],
            })

    add_opps(prev_week, [("won", "stg-won", 1800), ("won", "stg-won", 950), ("lost", "stg-contacted", 1200),
                         ("open", "stg-booked", 2400), ("open", "stg-new", 900)])
    add_opps(this_week, [("won", "stg-won", 3200), ("won", "stg-won", 1500), ("won", "stg-won", 780),
                         ("lost", "stg-new", 600), ("open", "stg-new", 1100), ("open", "stg-contacted", 2600),
                         ("open", "stg-booked", 4100), ("open", "stg-showed", 3900), ("abandoned", "stg-new", 0)])

    for start, count in ((prev_week, 31), (this_week, 42)):
        for i in range(count):
            conversations.append({
                "id": f"cv-{start:%m%d}-{i}", "contactId": rng.choice(contacts)["id"],
                "lastMessageDate": iso(_at(start + timedelta(days=rng.randint(0, 6)), rng)),
                "lastMessageType": rng.choice(["TYPE_SMS", "TYPE_WEBCHAT", "TYPE_FACEBOOK", "TYPE_EMAIL"]),
                "type": "TYPE_PHONE",
            })

    return {
        "location": dict(DEMO_LOCATION),
        "contacts": contacts,
        "opportunities": opportunities,
        "pipelines": pipelines,
        "calendars": calendars,
        "events": events,
        "customFields": [{"id": "cf-1", "name": "Preferred Dentist", "fieldKey": "contact.preferred_dentist",
                          "dataType": "TEXT"}],
        "customValues": [{"id": "cv-1", "name": "Business Phone", "fieldKey": "{{ custom_values.business_phone }}",
                          "value": "+1 512 555 0100"}],
        "tags": [{"id": "tg-1", "name": "new-lead"}, {"id": "tg-2", "name": "ai-booked"}],
        "workflows": [
            {"id": "wf-1", "name": "AI Appointment Setter", "status": "published"},
            {"id": "wf-2", "name": "Missed Call Text Back", "status": "draft"},
            {"id": "wf-3", "name": "Review Request", "status": "published"},
        ],
        "conversations": conversations,
    }
