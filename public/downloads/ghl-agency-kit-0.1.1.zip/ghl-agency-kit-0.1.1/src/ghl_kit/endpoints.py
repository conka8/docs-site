"""Every GoHighLevel (LeadConnector) API v2 path, query parameter and field name used by ghl-kit.

VERIFY AGAINST CURRENT GHL API v2 DOCS (https://marketplace.gohighlevel.com/docs/).
These values are best knowledge as of Oct 2026 and have not been checked against a live
account by the authors of this file. If GoHighLevel renames a path or a field, change it
here and nowhere else: the rest of the package only refers to the names below.
"""
from __future__ import annotations

from dataclasses import dataclass, field

BASE_URL = "https://services.leadconnectorhq.com"
API_VERSION = "2021-07-28"
TOKEN_ENV = "GHL_TOKEN"
LOCATION_ENV = "GHL_LOCATION_ID"

# Pagination styles understood by GHLClient.paginate():
#   none         one request, no paging
#   cursor_meta  response "meta" carries cursor values that are sent back as query params
#                (contacts list / opportunities search use startAfterId + startAfter)
#   page         ?page=N&limit=M in the query string
#   page_body    {"page": N, "pageLimit": M} in a JSON body (POST search endpoints)
#   last_item    a query param is set from a field of the last item of the previous page
#                (conversations search: startAfterDate = last item's sort value)
PAGING_STYLES = ("none", "cursor_meta", "page", "page_body", "last_item")


@dataclass(frozen=True)
class Endpoint:
    name: str
    method: str
    path: str                       # may contain {locationId}
    items_key: str | None = None    # key of the list in list/search responses
    item_key: str | None = None     # key of the object in create responses
    location_param: str | None = None  # query (GET) or body (POST) key carrying the location id
    paging: str = "none"
    limit_param: str | None = None
    page_param: str = "page"
    page_size: int = 100
    # cursor_meta: ((meta key, query param), ...)
    cursor_map: tuple[tuple[str, str], ...] = ()
    # last_item: query param + candidate fields on the last item (first non-empty wins)
    last_item_param: str | None = None
    last_item_fields: tuple[str, ...] = field(default=())


LOCATION = Endpoint("location", "GET", "/locations/{locationId}", item_key="location")

CONTACTS_LIST = Endpoint(
    "contacts", "GET", "/contacts/", items_key="contacts", location_param="locationId",
    paging="cursor_meta", limit_param="limit", page_size=100,
    cursor_map=(("startAfterId", "startAfterId"), ("startAfter", "startAfter")),
)
CONTACTS_SEARCH = Endpoint(
    "contacts_search", "POST", "/contacts/search", items_key="contacts", location_param="locationId",
    paging="page_body", limit_param="pageLimit", page_size=100,
)
OPPORTUNITIES_SEARCH = Endpoint(
    "opportunities", "GET", "/opportunities/search", items_key="opportunities",
    location_param="location_id", paging="cursor_meta", limit_param="limit", page_size=100,
    cursor_map=(("startAfterId", "startAfterId"), ("startAfter", "startAfter")),
)
PIPELINES = Endpoint("pipelines", "GET", "/opportunities/pipelines", items_key="pipelines",
                     location_param="locationId")
CALENDARS = Endpoint("calendars", "GET", "/calendars/", items_key="calendars", location_param="locationId")
CALENDAR_EVENTS = Endpoint("calendar_events", "GET", "/calendars/events", items_key="events",
                           location_param="locationId")
CUSTOM_FIELDS = Endpoint("custom_fields", "GET", "/locations/{locationId}/customFields", items_key="customFields")
CREATE_CUSTOM_FIELD = Endpoint("create_custom_field", "POST", "/locations/{locationId}/customFields",
                               item_key="customField")
CUSTOM_VALUES = Endpoint("custom_values", "GET", "/locations/{locationId}/customValues", items_key="customValues")
CREATE_CUSTOM_VALUE = Endpoint("create_custom_value", "POST", "/locations/{locationId}/customValues",
                               item_key="customValue")
TAGS = Endpoint("tags", "GET", "/locations/{locationId}/tags", items_key="tags")
CREATE_TAG = Endpoint("create_tag", "POST", "/locations/{locationId}/tags", item_key="tag")
WORKFLOWS = Endpoint("workflows", "GET", "/workflows/", items_key="workflows", location_param="locationId")
CONVERSATIONS_SEARCH = Endpoint(
    "conversations", "GET", "/conversations/search", items_key="conversations", location_param="locationId",
    paging="last_item", limit_param="limit", page_size=100,
    last_item_param="startAfterDate", last_item_fields=("sort", "lastMessageDate"),
)

ALL_ENDPOINTS = (
    LOCATION, CONTACTS_LIST, CONTACTS_SEARCH, OPPORTUNITIES_SEARCH, PIPELINES, CALENDARS, CALENDAR_EVENTS,
    CUSTOM_FIELDS, CREATE_CUSTOM_FIELD, CUSTOM_VALUES, CREATE_CUSTOM_VALUE, TAGS, CREATE_TAG, WORKFLOWS,
    CONVERSATIONS_SEARCH,
)

# Query params of /calendars/events (times are epoch milliseconds).
EVENTS_CALENDAR_PARAM = "calendarId"
EVENTS_START_PARAM = "startTime"
EVENTS_END_PARAM = "endTime"

# ---- field names on returned objects -------------------------------------------------
F_ID = "id"
F_NAME = "name"
F_CONTACT_CREATED = "dateAdded"
F_OPP_STATUS = "status"
F_OPP_VALUE = "monetaryValue"
F_OPP_PIPELINE = "pipelineId"
F_OPP_STAGE = "pipelineStageId"
F_OPP_CREATED = "createdAt"
F_OPP_STATUS_CHANGED = ("lastStatusChangeAt", "updatedAt")  # first present wins
F_PIPELINE_STAGES = "stages"
F_STAGE_POSITION = "position"
F_EVENT_STATUS = "appointmentStatus"
F_EVENT_START = "startTime"
F_EVENT_CREATED = "dateAdded"
F_CONV_LAST_MESSAGE = "lastMessageDate"
F_FIELD_KEY = "fieldKey"
F_FIELD_TYPE = "dataType"
F_VALUE = "value"
F_WORKFLOW_STATUS = "status"

OPP_WON = "won"
OPP_LOST = "lost"
OPP_OPEN = "open"
OPP_ABANDONED = "abandoned"
EVENT_SHOWED = "showed"
EVENT_NOSHOW = "noshow"
EVENT_CANCELLED = "cancelled"
EVENT_INVALID = "invalid"
WORKFLOW_PUBLISHED = "published"

# Custom field data types accepted by POST /locations/{id}/customFields.
CUSTOM_FIELD_TYPES = (
    "TEXT", "LARGE_TEXT", "NUMERICAL", "PHONE", "MONETORY", "CHECKBOX", "SINGLE_OPTIONS",
    "MULTIPLE_OPTIONS", "FLOAT", "TIME", "DATE", "TEXTBOX_LIST", "FILE_UPLOAD", "SIGNATURE", "RADIO",
)
OPTION_FIELD_TYPES = ("SINGLE_OPTIONS", "MULTIPLE_OPTIONS", "CHECKBOX", "RADIO")
# Body keys for creates.
BODY_FIELD_NAME = "name"
BODY_FIELD_TYPE = "dataType"
BODY_FIELD_PLACEHOLDER = "placeholder"
BODY_FIELD_OPTIONS = "options"
BODY_VALUE_NAME = "name"
BODY_VALUE_VALUE = "value"
BODY_TAG_NAME = "name"
