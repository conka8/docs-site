"""Fake GoHighLevel API for tests and demos (no account, no network).

Two pieces:

* ``FakeTransport``: a route table keyed by ``"METHOD /path?sorted=query"``. A route value is a
  response dict ``{"status": 200, "headers": {...}, "body": {...}}`` (or a list of them, served in
  order: handy for "429 then 200"). Every call is recorded in ``.calls``.
* ``FakeGHL``: an in-memory sub-account built from a ``state`` dict (contacts, opportunities,
  pipelines, calendars, events, customFields, customValues, tags, workflows, conversations).
  It understands the endpoints in endpoints.py, pages results and stores creates, so onboarding
  is idempotent across runs against the same object.

``load_fake_api(dir)`` builds a transport from a folder holding ``state.json`` and/or ``routes.json``.
"""
from __future__ import annotations

import json
import urllib.parse
from pathlib import Path
from typing import Any

from . import endpoints as ep
from .timeutil import parse_ts, to_ms


def route_key(method: str, url: str, params: dict | None = None) -> str:
    parsed = urllib.parse.urlsplit(url)
    query = urllib.parse.parse_qsl(parsed.query, keep_blank_values=True)
    if params:
        query += [(k, str(v)) for k, v in params.items()]
    query.sort()
    key = f"{method.upper()} {parsed.path or '/'}"
    if query:
        key += "?" + urllib.parse.urlencode(query)
    return key


def _response(status: int = 200, body: Any = None, headers: dict | None = None):
    raw = b"" if body is None else (body if isinstance(body, bytes) else json.dumps(body).encode("utf-8"))
    return status, dict(headers or {}), raw


class RecordingMixin:
    is_fake = True  # GHLClient marks everything made through a fake transport as demo data

    def _record(self, method, url, headers, body):
        parsed = urllib.parse.urlsplit(url)
        try:
            parsed_body = json.loads(body.decode("utf-8")) if body else None
        except ValueError:
            parsed_body = body
        call = {
            "method": method.upper(),
            "path": parsed.path,
            "query": dict(urllib.parse.parse_qsl(parsed.query, keep_blank_values=True)),
            "headers": dict(headers),
            "body": parsed_body,
            "url": url,
        }
        self.calls.append(call)
        return call

    @property
    def writes(self) -> list[dict]:
        return [c for c in self.calls if c["method"] in ("POST", "PUT", "PATCH", "DELETE")]


class FakeTransport(RecordingMixin):
    def __init__(self, routes: dict | None = None, fallback=None):
        self.routes: dict[str, Any] = {}
        self.calls: list[dict] = []
        self.fallback = fallback
        for key, value in (routes or {}).items():
            method, _, rest = key.partition(" ")
            self.routes[route_key(method, rest)] = value

    def add(self, method: str, path: str, body: Any = None, status: int = 200, headers: dict | None = None,
            query: dict | None = None):
        key = route_key(method, path, query)
        resp = {"status": status, "body": body, "headers": headers or {}}
        existing = self.routes.get(key)
        if existing is None:
            self.routes[key] = resp
        elif isinstance(existing, list):
            existing.append(resp)
        else:
            self.routes[key] = [existing, resp]
        return self

    def __call__(self, method, url, headers, body, timeout=30.0):
        self._record(method, url, headers, body)
        key = route_key(method, url)
        if key in self.routes:
            value = self.routes[key]
            if isinstance(value, list):
                value = value.pop(0) if len(value) > 1 else value[0]
            if callable(value):
                return value(method, url, headers, body)
            return _response(value.get("status", 200), value.get("body"), value.get("headers"))
        if self.fallback is not None:
            # the fallback records its own calls; drop ours to avoid double counting
            self.calls.pop()
            return self.fallback(method, url, headers, body, timeout)
        return _response(404, {"message": f"fake API has no route for {key}"})


def _norm(name: Any) -> str:
    return " ".join(str(name or "").split()).casefold()


class FakeGHL(RecordingMixin):
    """Stateful fake of one GHL sub-account."""

    COLLECTIONS = ("contacts", "opportunities", "pipelines", "calendars", "events", "customFields",
                   "customValues", "tags", "workflows", "conversations")

    def __init__(self, state: dict | None = None, location_id: str | None = None):
        state = json.loads(json.dumps(state or {}))  # deep copy
        self.location = state.get("location") or {"id": location_id or "demo-location", "name": "Demo Client"}
        if location_id:
            self.location["id"] = location_id
        self.data: dict[str, list] = {k: list(state.get(k) or []) for k in self.COLLECTIONS}
        self.calls: list[dict] = []
        self._next_id = 1

    @property
    def location_id(self) -> str:
        return self.location["id"]

    def _new_id(self, prefix: str) -> str:
        self._next_id += 1
        return f"{prefix}-new-{self._next_id}"

    def __call__(self, method, url, headers, body, timeout=30.0):
        call = self._record(method, url, headers, body)
        if not str(headers.get("Authorization", "")).startswith("Bearer "):
            return _response(401, {"message": "Invalid JWT"})
        path, q, payload = call["path"], call["query"], call["body"] or {}
        loc = f"/locations/{self.location_id}"
        m = method.upper()
        try:
            if m == "GET" and path == loc:
                return _response(200, {"location": self.location})
            if path.startswith("/locations/") and not path.startswith(loc):
                return _response(404, {"message": "Location not found"})
            if m == "GET" and path == ep.CONTACTS_LIST.path:
                return self._cursor_page("contacts", q, ep.F_CONTACT_CREATED)
            if m == "POST" and path == ep.CONTACTS_SEARCH.path:
                items = self.data["contacts"]
                page, size = int(payload.get("page", 1)), int(payload.get("pageLimit", 20))
                chunk = items[(page - 1) * size: page * size]
                return _response(200, {"contacts": chunk, "total": len(items)})
            if m == "GET" and path == ep.OPPORTUNITIES_SEARCH.path:
                return self._cursor_page("opportunities", q, ep.F_OPP_CREATED)
            if m == "GET" and path == ep.PIPELINES.path:
                return _response(200, {"pipelines": self.data["pipelines"]})
            if m == "GET" and path == ep.CALENDARS.path:
                return _response(200, {"calendars": self.data["calendars"]})
            if m == "GET" and path == ep.CALENDAR_EVENTS.path:
                return self._events(q)
            if m == "GET" and path == ep.WORKFLOWS.path:
                return _response(200, {"workflows": self.data["workflows"]})
            if m == "GET" and path == ep.CONVERSATIONS_SEARCH.path:
                return self._conversations(q)
            for coll, single in (("customFields", "customField"), ("customValues", "customValue"), ("tags", "tag")):
                if path == f"{loc}/{coll}":
                    if m == "GET":
                        return _response(200, {coll: self.data[coll]})
                    if m == "POST":
                        return self._create(coll, single, payload)
        except (ValueError, TypeError) as exc:
            return _response(422, {"message": str(exc)})
        return _response(404, {"message": f"fake GHL has no handler for {m} {path}"})

    def _create(self, coll: str, single: str, payload: dict):
        name = payload.get("name")
        if not name:
            return _response(422, {"message": ["name should not be empty"]})
        if any(_norm(i.get("name")) == _norm(name) for i in self.data[coll]):
            return _response(400, {"message": f"{single} with this name already exists"})
        item = {"id": self._new_id(single), "locationId": self.location_id, **payload}
        if coll == "customFields":
            item.setdefault("fieldKey", "contact." + _norm(name).replace(" ", "_"))
        if coll == "customValues":
            item.setdefault("fieldKey", "{{ custom_values." + _norm(name).replace(" ", "_") + " }}")
        self.data[coll].append(item)
        return _response(201, {single: item})

    def _cursor_page(self, coll: str, q: dict, date_field: str):
        size = int(q.get("limit", 20))
        items = sorted(self.data[coll], key=lambda i: (to_ms(parse_ts(i.get(date_field)) or parse_ts(0)), i["id"]))
        start = 0
        after_id = q.get("startAfterId")
        if after_id:
            ids = [i["id"] for i in items]
            start = ids.index(after_id) + 1 if after_id in ids else len(items)
        chunk = items[start:start + size]
        more = start + size < len(items)
        meta: dict[str, Any] = {"total": len(items), "currentPage": start // max(size, 1) + 1}
        if chunk:
            meta["startAfterId"] = chunk[-1]["id"]
            meta["startAfter"] = to_ms(parse_ts(chunk[-1].get(date_field)) or parse_ts(0))
        meta["nextPageUrl"] = "fake://next" if more else None
        return _response(200, {coll: chunk, "meta": meta})

    def _events(self, q: dict):
        cal = q.get("calendarId")
        if not cal:
            return _response(422, {"message": "calendarId, userId or groupId is required"})
        lo, hi = int(q.get("startTime", 0)), int(q.get("endTime", 2 ** 62))
        out = []
        for e in self.data["events"]:
            start = parse_ts(e.get(ep.F_EVENT_START))
            if e.get("calendarId") == cal and start is not None and lo <= to_ms(start) < hi:
                out.append(e)
        return _response(200, {"events": out})

    def _conversations(self, q: dict):
        size = int(q.get("limit", 20))
        items = []
        for c in self.data["conversations"]:
            ms = to_ms(parse_ts(c.get(ep.F_CONV_LAST_MESSAGE)) or parse_ts(0))
            items.append({**c, "sort": [ms]})
        items.sort(key=lambda c: c["sort"][0], reverse=True)
        after = q.get("startAfterDate")
        if after:
            items = [c for c in items if c["sort"][0] < int(float(after))]
        return _response(200, {"conversations": items[:size], "total": len(items)})


def load_fake_api(directory: str | Path, location_id: str | None = None):
    """Transport for `--fake-api DIR` (state.json and/or routes.json) or the word 'demo'."""
    if str(directory) == "demo":
        from .demo import build_demo_state
        return FakeGHL(build_demo_state(), location_id)
    d = Path(directory)
    if not d.is_dir():
        raise FileNotFoundError(f"--fake-api folder not found: {d}")
    fallback = None
    state_file = d / "state.json"
    if state_file.exists():
        fallback = FakeGHL(json.loads(state_file.read_text(encoding="utf-8")), location_id)
    routes_file = d / "routes.json"
    routes = json.loads(routes_file.read_text(encoding="utf-8")) if routes_file.exists() else {}
    if fallback is None and not routes:
        raise FileNotFoundError(f"{d} has neither state.json nor routes.json")
    if not routes:
        return fallback
    return FakeTransport(routes, fallback=fallback)
