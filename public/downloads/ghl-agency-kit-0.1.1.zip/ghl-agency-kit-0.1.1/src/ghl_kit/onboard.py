"""`ghl-kit onboard`: set up a new client sub-account from a plan file.

Creates what the API can create (custom fields, tags, custom values) without duplicates and
produces a checklist for the steps that have to be done by hand in GoHighLevel, each one
checked against the sub-account's current configuration.
"""
from __future__ import annotations

import json
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from . import endpoints as ep
from .branding import Branding, demo_banner_html, demo_md_line, esc
from .client import GHLClient, GHLError

# status values
CREATED, EXISTS, WOULD_CREATE, FAILED = "created", "exists", "would create", "failed"
VERIFIED, NOT_FOUND, PARTIAL, MANUAL, UNCHECKED = "verified", "not found", "partial", "manual check", "could not check"


class PlanError(ValueError):
    pass


@dataclass
class Plan:
    client_name: str = ""
    custom_fields: list[dict] = field(default_factory=list)
    tags: list[str] = field(default_factory=list)
    custom_values: list[dict] = field(default_factory=list)
    pipelines: list[dict] = field(default_factory=list)
    calendars: list[dict] = field(default_factory=list)
    workflows: list[str] = field(default_factory=list)
    snapshot: str = ""
    phone_number: str = ""
    ai_agent: str = ""
    a2p: bool = True
    manual_steps: list[dict] = field(default_factory=list)


@dataclass
class Action:
    kind: str
    name: str
    status: str
    detail: str = ""


@dataclass
class CheckItem:
    title: str
    status: str
    detail: str = ""
    how_to: str = ""


@dataclass
class OnboardResult:
    client_name: str
    location_id: str
    dry_run: bool
    actions: list[Action]
    checklist: list[CheckItem]
    generated_at: str = ""
    demo: bool = False

    @property
    def failed(self) -> list[Action]:
        return [a for a in self.actions if a.status == FAILED]

    @property
    def open_items(self) -> list[CheckItem]:
        return [c for c in self.checklist if c.status != VERIFIED]

    def to_dict(self) -> dict:
        return {
            "demo": self.demo,
            "client_name": self.client_name, "location_id": self.location_id, "dry_run": self.dry_run,
            "generated_at": self.generated_at,
            "actions": [asdict(a) for a in self.actions], "checklist": [asdict(c) for c in self.checklist],
        }


def norm(name: Any) -> str:
    return " ".join(str(name or "").split()).casefold()


def _s(value) -> str:
    """str() that undoes YAML 1.1 surprises: unquoted yes/no/on/off become booleans."""
    if isinstance(value, bool):
        return "Yes" if value else "No"
    return "" if value is None else str(value)


def _as_list(value, key: str) -> list:
    if value is None:
        return []
    if not isinstance(value, list):
        raise PlanError(f"'{key}' must be a list in the plan file")
    return value


def parse_plan(data: Any) -> Plan:
    if not isinstance(data, dict):
        raise PlanError("The plan file must be a YAML/JSON mapping (key: value lines).")
    plan = Plan(client_name=str(data.get("client") or data.get("client_name") or ""))
    for i, f in enumerate(_as_list(data.get("custom_fields"), "custom_fields"), 1):
        if isinstance(f, str):
            f = {"name": f}
        if not isinstance(f, dict) or not f.get("name"):
            raise PlanError(f"custom_fields item {i} needs a name")
        dtype = str(f.get("type") or f.get("dataType") or "TEXT").upper()
        if dtype not in ep.CUSTOM_FIELD_TYPES:
            raise PlanError(f"custom field '{f['name']}': type {dtype} is not one of {', '.join(ep.CUSTOM_FIELD_TYPES)}")
        options = f.get("options") or []
        if dtype in ep.OPTION_FIELD_TYPES and dtype != "CHECKBOX" and not options:
            raise PlanError(f"custom field '{f['name']}' is {dtype} and needs a list of options")
        plan.custom_fields.append({"name": str(f["name"]), "type": dtype, "options": [_s(o) for o in options],
                                   "placeholder": str(f.get("placeholder") or "")})
    for i, t in enumerate(_as_list(data.get("tags"), "tags"), 1):
        name = t.get("name") if isinstance(t, dict) else t
        if not name:
            raise PlanError(f"tags item {i} is empty")
        plan.tags.append(_s(name))
    for i, v in enumerate(_as_list(data.get("custom_values"), "custom_values"), 1):
        if not isinstance(v, dict) or not v.get("name"):
            raise PlanError(f"custom_values item {i} needs a name and a value")
        plan.custom_values.append({"name": str(v["name"]), "value": _s(v.get("value"))})
    for i, p in enumerate(_as_list(data.get("pipelines"), "pipelines"), 1):
        if isinstance(p, str):
            p = {"name": p}
        if not isinstance(p, dict) or not p.get("name"):
            raise PlanError(f"pipelines item {i} needs a name")
        plan.pipelines.append({"name": str(p["name"]), "stages": [str(s) for s in _as_list(p.get("stages"), "stages")]})
    for i, c in enumerate(_as_list(data.get("calendars"), "calendars"), 1):
        if isinstance(c, str):
            c = {"name": c}
        if not isinstance(c, dict) or not c.get("name"):
            raise PlanError(f"calendars item {i} needs a name")
        plan.calendars.append({"name": str(c["name"])})
    plan.workflows = [str(w.get("name") if isinstance(w, dict) else w)
                      for w in _as_list(data.get("workflows"), "workflows")]
    plan.snapshot = str(data.get("snapshot") or "")
    plan.phone_number = str(data.get("phone_number") or "")
    plan.ai_agent = str(data.get("ai_agent") or "")
    plan.a2p = bool(data.get("a2p_registration", True))
    for i, s in enumerate(_as_list(data.get("manual_steps"), "manual_steps"), 1):
        if isinstance(s, str):
            s = {"title": s}
        if not isinstance(s, dict) or not s.get("title"):
            raise PlanError(f"manual_steps item {i} needs a title")
        plan.manual_steps.append({"title": str(s["title"]), "how_to": str(s.get("how_to") or "")})
    return plan


def load_plan(path: str | Path) -> Plan:
    p = Path(path)
    if not p.exists():
        raise PlanError(f"Plan file not found: {p}")
    text = p.read_text(encoding="utf-8")
    if p.suffix.lower() == ".json":
        try:
            data = json.loads(text)
        except ValueError as exc:
            raise PlanError(f"{p} is not valid JSON: {exc}") from exc
    else:
        import yaml
        try:
            data = yaml.safe_load(text)
        except yaml.YAMLError as exc:
            raise PlanError(f"{p} is not valid YAML: {exc}") from exc
    return parse_plan(data)


def _safe_read(fn, label: str, errors: dict):
    try:
        return fn()
    except GHLError as exc:
        errors[label] = str(exc)
        return None


def run_onboarding(client: GHLClient, plan: Plan, dry_run: bool = False) -> OnboardResult:
    actions: list[Action] = []
    errors: dict[str, str] = {}

    fields = _safe_read(client.custom_fields, "custom fields", errors) if plan.custom_fields else []
    for f in plan.custom_fields:
        if fields is None:
            actions.append(Action("custom field", f["name"], FAILED, errors["custom fields"]))
            continue
        match = next((x for x in fields if norm(x.get(ep.F_NAME)) == norm(f["name"])), None)
        if match:
            detail = ""
            if match.get(ep.F_FIELD_TYPE) and str(match.get(ep.F_FIELD_TYPE)).upper() != f["type"]:
                detail = f"type in account is {match.get(ep.F_FIELD_TYPE)}, plan says {f['type']}"
            actions.append(Action("custom field", f["name"], EXISTS, detail))
        elif dry_run:
            actions.append(Action("custom field", f["name"], WOULD_CREATE, f["type"]))
        else:
            try:
                created = client.create_custom_field(f["name"], f["type"], f["placeholder"] or None, f["options"] or None)
                fields.append(created)
                actions.append(Action("custom field", f["name"], CREATED, created.get(ep.F_FIELD_KEY, "")))
            except GHLError as exc:
                actions.append(Action("custom field", f["name"], FAILED, str(exc)))

    tags = _safe_read(client.tags, "tags", errors) if plan.tags else []
    for t in plan.tags:
        if tags is None:
            actions.append(Action("tag", t, FAILED, errors["tags"]))
            continue
        if any(norm(x.get(ep.F_NAME)) == norm(t) for x in tags):
            actions.append(Action("tag", t, EXISTS))
        elif dry_run:
            actions.append(Action("tag", t, WOULD_CREATE))
        else:
            try:
                tags.append(client.create_tag(t))
                actions.append(Action("tag", t, CREATED))
            except GHLError as exc:
                actions.append(Action("tag", t, FAILED, str(exc)))

    values = _safe_read(client.custom_values, "custom values", errors) if plan.custom_values else []
    for v in plan.custom_values:
        if values is None:
            actions.append(Action("custom value", v["name"], FAILED, errors["custom values"]))
            continue
        match = next((x for x in values if norm(x.get(ep.F_NAME)) == norm(v["name"])), None)
        if match:
            current = "" if match.get(ep.F_VALUE) is None else str(match.get(ep.F_VALUE))
            detail = "" if current == v["value"] else f"left unchanged; account has {current!r}, plan says {v['value']!r}"
            actions.append(Action("custom value", v["name"], EXISTS, detail))
        elif dry_run:
            actions.append(Action("custom value", v["name"], WOULD_CREATE, v["value"]))
        else:
            try:
                values.append(client.create_custom_value(v["name"], v["value"]))
                actions.append(Action("custom value", v["name"], CREATED, v["value"]))
            except GHLError as exc:
                actions.append(Action("custom value", v["name"], FAILED, str(exc)))

    checklist = build_checklist(client, plan)
    return OnboardResult(plan.client_name or client.location_id, client.location_id, dry_run, actions, checklist,
                         datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC"), demo=getattr(client, "demo", False))


def build_checklist(client: GHLClient, plan: Plan) -> list[CheckItem]:
    items: list[CheckItem] = []
    errors: dict[str, str] = {}
    pipelines = _safe_read(client.pipelines, "pipelines", errors) if plan.pipelines else []
    for p in plan.pipelines:
        title = f"Pipeline '{p['name']}'"
        how = ("Opportunities > Pipelines > Create pipeline (or import the snapshot), "
               "then add the stages in this order: " + ", ".join(p["stages"]) if p["stages"] else
               "Opportunities > Pipelines > Create pipeline (or import the snapshot).")
        if pipelines is None:
            items.append(CheckItem(title, UNCHECKED, errors["pipelines"], how))
            continue
        found = next((x for x in pipelines if norm(x.get(ep.F_NAME)) == norm(p["name"])), None)
        if not found:
            items.append(CheckItem(title, NOT_FOUND, "No pipeline with this name in the sub-account.", how))
            continue
        have = {norm(s.get(ep.F_NAME)) for s in found.get(ep.F_PIPELINE_STAGES) or []}
        missing = [s for s in p["stages"] if norm(s) not in have]
        if missing:
            items.append(CheckItem(title, PARTIAL, "Missing stages: " + ", ".join(missing), how))
        else:
            n = len(found.get(ep.F_PIPELINE_STAGES) or [])
            items.append(CheckItem(title, VERIFIED, f"Found with {n} stages."))

    calendars = _safe_read(client.calendars, "calendars", errors) if plan.calendars else []
    for c in plan.calendars:
        title = f"Calendar '{c['name']}'"
        how = "Calendars > Calendar settings > Create calendar; set availability and connect the team's Google/Outlook calendar."
        if calendars is None:
            items.append(CheckItem(title, UNCHECKED, errors["calendars"], how))
        elif any(norm(x.get(ep.F_NAME)) == norm(c["name"]) for x in calendars):
            items.append(CheckItem(title, VERIFIED, "Found."))
        else:
            items.append(CheckItem(title, NOT_FOUND, "No calendar with this name.", how))

    if plan.snapshot or plan.workflows:
        title = f"Snapshot '{plan.snapshot}' imported" if plan.snapshot else "Workflows in place"
        how = ("Agency view > Account Snapshots > Load snapshot into this sub-account."
               if plan.snapshot else "Automation > Workflows: build or import the missing workflows.")
        if not plan.workflows:
            items.append(CheckItem(title, MANUAL, "Can't be checked automatically. List the workflows this snapshot "
                                   "creates under 'workflows:' in the plan so ghl-kit can look for them.", how))
        else:
            wfs = _safe_read(client.workflows, "workflows", errors)
            if wfs is None:
                items.append(CheckItem(title, UNCHECKED, errors["workflows"], how))
            else:
                by_name = {norm(w.get(ep.F_NAME)): w for w in wfs}
                missing = [w for w in plan.workflows if norm(w) not in by_name]
                drafts = [w for w in plan.workflows if norm(w) in by_name and
                          str(by_name[norm(w)].get(ep.F_WORKFLOW_STATUS, "")).lower() != ep.WORKFLOW_PUBLISHED]
                if len(missing) == len(plan.workflows):
                    items.append(CheckItem(title, NOT_FOUND, "None of the expected workflows were found: "
                                           + ", ".join(missing), how))
                elif missing or drafts:
                    parts = []
                    if missing:
                        parts.append("missing: " + ", ".join(missing))
                    if drafts:
                        parts.append("not published yet: " + ", ".join(drafts))
                    text = "; ".join(parts)
                    items.append(CheckItem(title, PARTIAL, text[:1].upper() + text[1:],
                                           how + " Publish draft workflows in Automation > Workflows."))
                else:
                    items.append(CheckItem(title, VERIFIED, f"All {len(plan.workflows)} expected workflows found and published."))

    items.append(CheckItem(
        "Phone number" + (f" ({plan.phone_number})" if plan.phone_number else ""), MANUAL,
        "Phone numbers are not checked through the API.",
        "Settings > Phone Numbers > Add number (or port the client's number); set call forwarding and missed-call text back."))
    if plan.a2p:
        items.append(CheckItem(
            "A2P 10DLC registration (US texting)", MANUAL, "Registration status is not available through the API.",
            "Settings > Phone Numbers > Trust Center: submit the brand and campaign. Texts to US numbers can be "
            "blocked until it is approved."))
    items.append(CheckItem(
        "AI agent setup" + (f" ({plan.ai_agent})" if plan.ai_agent else ""), MANUAL,
        "AI agent configuration is not checked through the API.",
        "AI Agents (Conversation AI / Voice AI): set the bot's goal, business info, booking calendar and hand-off "
        "rules, then send yourself a test message."))
    for s in plan.manual_steps:
        items.append(CheckItem(s["title"], MANUAL, "", s["how_to"]))
    return items


STATUS_ICON = {CREATED: "[+]", EXISTS: "[=]", WOULD_CREATE: "[ ]", FAILED: "[!]", VERIFIED: "[x]", NOT_FOUND: "[ ]",
               PARTIAL: "[~]", MANUAL: "[ ]", UNCHECKED: "[?]"}


def _md_cell(text: str) -> str:
    return str(text).replace("|", "\\|").replace("\n", " ")


def _mode(result: OnboardResult, dry_label: str) -> str:
    if result.dry_run:
        return f"{dry_label}: nothing was changed in GoHighLevel."
    if result.demo:
        return "Changes were applied to the fake demo account only (nothing was sent to GoHighLevel)."
    return "Changes were applied."


def render_markdown(result: OnboardResult) -> str:
    lines = demo_md_line(result.demo) + [f"# Onboarding report: {result.client_name}", ""]
    mode = _mode(result, "DRY RUN")
    lines += [f"Sub-account: `{result.location_id}`  ", f"Generated: {result.generated_at}  ", f"{mode}", ""]
    created = sum(a.status == CREATED for a in result.actions)
    exists = sum(a.status == EXISTS for a in result.actions)
    would = sum(a.status == WOULD_CREATE for a in result.actions)
    lines += ["## Summary", "",
              f"- Created: {created}" + (f", would create: {would}" if result.dry_run else ""),
              f"- Already there: {exists}",
              f"- Failed: {len(result.failed)}",
              f"- Checklist: {len(result.checklist) - len(result.open_items)} of {len(result.checklist)} verified", ""]
    lines += ["## Created through the API", ""]
    if result.actions:
        lines += ["| Type | Name | Result | Details |", "|---|---|---|---|"]
        for a in result.actions:
            lines.append(f"| {a.kind} | {_md_cell(a.name)} | {a.status} | {_md_cell(a.detail)} |")
    else:
        lines.append("Nothing to create in this plan.")
    lines += ["", "## Checklist", ""]
    for c in result.checklist:
        box = "x" if c.status == VERIFIED else " "
        lines.append(f"- [{box}] **{c.title}**: {c.status}" + (f". {c.detail}" if c.detail else ""))
        if c.how_to and c.status != VERIFIED:
            lines.append(f"  - How: {c.how_to}")
    lines.append("")
    return "\n".join(lines)


_COLORS = {CREATED: "#1a7f37", EXISTS: "#52514e", WOULD_CREATE: "#2a78d6", FAILED: "#c62828", VERIFIED: "#1a7f37",
           NOT_FOUND: "#c62828", PARTIAL: "#b26a00", MANUAL: "#52514e", UNCHECKED: "#b26a00"}


def render_html(result: OnboardResult, branding: Branding | None = None) -> str:
    b = branding or Branding()
    logo = f'<img src="{esc(b.logo_url)}" alt="" style="max-height:40px;vertical-align:middle;margin-right:12px">' if b.logo_url else ""
    rows = "".join(
        f"<tr><td>{esc(a.kind)}</td><td>{esc(a.name)}</td>"
        f'<td><span class="pill" style="color:{_COLORS.get(a.status, "#333")}">{esc(a.status)}</span></td>'
        f"<td>{esc(a.detail)}</td></tr>" for a in result.actions) or '<tr><td colspan="4">Nothing to create in this plan.</td></tr>'
    checks = "".join(
        f'<li><span class="pill" style="color:{_COLORS.get(c.status, "#333")}">{esc(c.status)}</span> '
        f"<strong>{esc(c.title)}</strong>" + (f"<div class=\"muted\">{esc(c.detail)}</div>" if c.detail else "")
        + (f'<div class="how">How: {esc(c.how_to)}</div>' if c.how_to and c.status != VERIFIED else "") + "</li>"
        for c in result.checklist)
    mode = _mode(result, "Dry run")
    return f"""<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Onboarding: {esc(result.client_name)}</title>
<style>
body{{font-family:-apple-system,Segoe UI,Roboto,Helvetica,Arial,sans-serif;color:#1b1b1b;background:#fff;margin:0;padding:24px;line-height:1.45}}
.wrap{{max-width:860px;margin:0 auto}}
header{{border-bottom:4px solid {b.brand_color};padding-bottom:12px;margin-bottom:20px}}
h1{{font-size:22px;margin:8px 0}} h2{{font-size:17px;margin-top:28px}}
table{{border-collapse:collapse;width:100%;font-size:14px}} td,th{{border-bottom:1px solid #e3e3e0;padding:6px 8px;text-align:left;vertical-align:top}}
.pill{{font-weight:600;font-size:12px;text-transform:uppercase;letter-spacing:.03em}}
ul{{list-style:none;padding:0}} li{{padding:8px 0;border-bottom:1px solid #eee}}
.muted{{color:#52514e;font-size:13px}} .how{{font-size:13px;margin-top:2px}}
footer{{margin-top:32px;color:#6b6a66;font-size:12px}}
@media print{{body{{padding:0}}}}
</style></head><body><div class="wrap">
{demo_banner_html(result.demo)}<header>{logo}<strong>{esc(b.brand_name)}</strong><h1>Onboarding report: {esc(result.client_name)}</h1>
<div class="muted">Sub-account {esc(result.location_id)} &middot; {esc(result.generated_at)} &middot; {esc(mode)}</div></header>
<h2>Created through the API</h2>
<table><thead><tr><th>Type</th><th>Name</th><th>Result</th><th>Details</th></tr></thead><tbody>{rows}</tbody></table>
<h2>Checklist ({len(result.checklist) - len(result.open_items)} of {len(result.checklist)} verified)</h2>
<ul>{checks}</ul>
<footer>{esc(("Prepared by " + b.brand_name) if b.brand_name else "Generated with ghl-agency-kit")}</footer>
</div></body></html>
"""


def render_json(result: OnboardResult) -> str:
    return json.dumps(result.to_dict(), indent=2)
