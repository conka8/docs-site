"""`ghl-kit report`: weekly client results pulled from GHL, rendered as white-label HTML / Markdown / JSON.

Metric definitions (also in README):
  new_leads            contacts whose dateAdded is in the period
  appointments_booked  calendar events starting in the period, excluding cancelled/invalid
  showed / no_show     events starting in the period with appointmentStatus showed / noshow
  booking_rate         appointments_booked / new_leads
  show_rate            showed / (showed + no_show)
  won_count/won_value  opportunities marked won whose status changed in the period
  lost_count           same for lost
  opportunities_created opportunities created in the period
  pipeline_value       current total monetaryValue of open opportunities (a "right now" number)
  conversations        conversations whose last message is in the period
"""
from __future__ import annotations

import json
from dataclasses import dataclass
from datetime import date, datetime, timedelta, timezone, tzinfo
from typing import Any

from . import endpoints as ep
from .branding import Branding, demo_banner_html, demo_md_line, esc
from .client import GHLClient
from .timeutil import day_window, parse_ts, to_ms

COUNT_METRICS = ("new_leads", "appointments_booked", "showed", "no_show", "cancelled", "opportunities_created",
                 "won_count", "lost_count", "conversations")
COMPARABLE = COUNT_METRICS + ("won_value", "booking_rate", "show_rate")
# metrics where going down is good news
LOWER_IS_BETTER = {"no_show", "cancelled", "lost_count"}
LABELS = {
    "new_leads": "New leads", "appointments_booked": "Appointments booked", "showed": "Showed up",
    "no_show": "No-shows", "cancelled": "Cancelled", "booking_rate": "Booking rate", "show_rate": "Show rate",
    "opportunities_created": "New opportunities", "won_count": "Deals won", "won_value": "Won value",
    "lost_count": "Deals lost", "open_count": "Open opportunities", "pipeline_value": "Pipeline value",
    "conversations": "Conversations",
}


@dataclass
class Period:
    start: date
    end: date

    def __post_init__(self):
        if self.end < self.start:
            raise ValueError(f"--to ({self.end}) is before --from ({self.start}).")

    @property
    def days(self) -> int:
        return (self.end - self.start).days + 1

    def previous(self) -> "Period":
        return Period(self.start - timedelta(days=self.days), self.start - timedelta(days=1))

    def label(self) -> str:
        return f"{self.start:%b} {self.start.day} - {self.end:%b} {self.end.day}, {self.end.year}"


def _in(ts, lo: datetime, hi: datetime) -> bool:
    dt = parse_ts(ts)
    return dt is not None and lo <= dt < hi


def _money(v) -> float:
    try:
        return float(v or 0)
    except (TypeError, ValueError):
        return 0.0


def _status_changed(opp: dict):
    for f in ep.F_OPP_STATUS_CHANGED:
        if opp.get(f):
            return opp.get(f)
    return opp.get(ep.F_OPP_CREATED)


def ratio(num: float, den: float) -> float | None:
    return None if not den else num / den


def compute_metrics(data: dict, lo: datetime, hi: datetime) -> dict:
    """Pure metric math over raw GHL lists for the window [lo, hi)."""
    contacts = data.get("contacts") or []
    events = data.get("events") or []
    opps = data.get("opportunities") or []
    convs = data.get("conversations") or []
    m: dict[str, Any] = {}
    m["new_leads"] = sum(_in(c.get(ep.F_CONTACT_CREATED), lo, hi) for c in contacts)
    in_window = [e for e in events if _in(e.get(ep.F_EVENT_START), lo, hi)]
    status = [str(e.get(ep.F_EVENT_STATUS) or "").lower() for e in in_window]
    m["cancelled"] = sum(s == ep.EVENT_CANCELLED for s in status)
    m["appointments_booked"] = sum(s not in (ep.EVENT_CANCELLED, ep.EVENT_INVALID) for s in status)
    m["showed"] = sum(s == ep.EVENT_SHOWED for s in status)
    m["no_show"] = sum(s == ep.EVENT_NOSHOW for s in status)
    m["booking_rate"] = ratio(m["appointments_booked"], m["new_leads"])
    m["show_rate"] = ratio(m["showed"], m["showed"] + m["no_show"])
    m["opportunities_created"] = sum(_in(o.get(ep.F_OPP_CREATED), lo, hi) for o in opps)
    won = [o for o in opps if str(o.get(ep.F_OPP_STATUS)).lower() == ep.OPP_WON and _in(_status_changed(o), lo, hi)]
    lost = [o for o in opps if str(o.get(ep.F_OPP_STATUS)).lower() == ep.OPP_LOST and _in(_status_changed(o), lo, hi)]
    m["won_count"] = len(won)
    m["won_value"] = sum(_money(o.get(ep.F_OPP_VALUE)) for o in won)
    m["lost_count"] = len(lost)
    open_ = [o for o in opps if str(o.get(ep.F_OPP_STATUS)).lower() == ep.OPP_OPEN]
    m["open_count"] = len(open_)
    m["pipeline_value"] = sum(_money(o.get(ep.F_OPP_VALUE)) for o in open_)
    m["conversations"] = sum(_in(c.get(ep.F_CONV_LAST_MESSAGE), lo, hi) for c in convs)
    return m


def stage_breakdown(opps: list[dict], pipelines: list[dict]) -> list[dict]:
    """Open opportunities per pipeline stage, in pipeline/stage order. Unknown stages go last."""
    order: dict[str, tuple] = {}
    names: dict[str, tuple[str, str]] = {}
    for pi, p in enumerate(pipelines or []):
        stages = sorted(p.get(ep.F_PIPELINE_STAGES) or [], key=lambda s: s.get(ep.F_STAGE_POSITION, 0))
        for si, s in enumerate(stages):
            order[s.get(ep.F_ID)] = (pi, si)
            names[s.get(ep.F_ID)] = (str(p.get(ep.F_NAME) or ""), str(s.get(ep.F_NAME) or ""))
    rows: dict[str, dict] = {}
    for o in opps or []:
        if str(o.get(ep.F_OPP_STATUS)).lower() != ep.OPP_OPEN:
            continue
        sid = o.get(ep.F_OPP_STAGE) or "?"
        pname, sname = names.get(sid, ("Other", "Unknown stage"))
        row = rows.setdefault(sid, {"pipeline": pname, "stage": sname, "count": 0, "value": 0.0})
        row["count"] += 1
        row["value"] += _money(o.get(ep.F_OPP_VALUE))
    ranked = sorted(rows.items(), key=lambda kv: (order.get(kv[0], (10 ** 6, 0)), kv[1]["stage"]))
    return [row for _, row in ranked]


def deltas(cur: dict, prev: dict) -> dict:
    out = {}
    for k in COMPARABLE:
        c, p = cur.get(k), prev.get(k)
        if c is None or p is None:
            out[k] = {"current": c, "previous": p, "change": None, "pct": None}
            continue
        change = c - p
        out[k] = {"current": c, "previous": p, "change": change, "pct": (change / p * 100.0) if p else None}
    return out


def fmt_money(v: float, symbol: str = "$") -> str:
    v = float(v or 0)
    s = f"{v:,.0f}" if abs(v - round(v)) < 0.005 else f"{v:,.2f}"
    return f"-{symbol}{s[1:]}" if s.startswith("-") else f"{symbol}{s}"


def fmt_pct(v: float | None) -> str:
    return "n/a" if v is None else f"{v * 100:.0f}%"


def _plural(n: int, word: str, plural: str | None = None) -> str:
    return f"{n} {word if n == 1 else (plural or word + 's')}"


def change_phrase(cur, prev, period_word: str, lower_is_better: bool = False) -> str:
    if prev is None or cur is None:
        return ""
    if cur == prev:
        return f"the same as {period_word}"
    if prev == 0:
        return f"up from 0 {period_word}"
    pct = (cur - prev) / prev * 100
    return f"{'up' if pct > 0 else 'down'} {abs(pct):.0f}% vs {period_word}"


def build_highlights(m: dict, prev: dict | None, period_word: str, assistant: str = "Your AI assistant",
                     currency: str = "$") -> list[str]:
    def with_change(text: str, key: str) -> str:
        if prev is None:
            return text + "."
        ph = change_phrase(m.get(key), prev.get(key), period_word)
        return f"{text}, {ph}." if ph else text + "."

    out = []
    if m["appointments_booked"]:
        out.append(with_change(f"{assistant} booked {_plural(m['appointments_booked'], 'appointment')}",
                               "appointments_booked"))
    else:
        out.append("No appointments were booked in this period. Worth checking the booking link and follow-ups.")
    if m["new_leads"]:
        out.append(with_change(f"{_plural(m['new_leads'], 'new lead')} came in", "new_leads"))
    else:
        out.append("No new leads came in during this period.")
    if m["show_rate"] is not None:
        total = m["showed"] + m["no_show"]
        out.append(f"{m['showed']} of {total} finished appointments showed up ({fmt_pct(m['show_rate'])} show rate).")
    if m["won_count"]:
        out.append(with_change(f"You won {_plural(m['won_count'], 'deal')} worth {fmt_money(m['won_value'], currency)}",
                               "won_value"))
    if m["open_count"]:
        out.append(f"There is {fmt_money(m['pipeline_value'], currency)} in open pipeline across "
                   f"{_plural(m['open_count'], 'opportunity', 'opportunities')}.")
    if m["conversations"]:
        out.append(with_change(f"{_plural(m['conversations'], 'conversation')} had activity", "conversations"))
    return out


def fetch_data(client: GHLClient, lo: datetime, hi: datetime) -> dict:
    calendars = client.calendars()
    events: list[dict] = []
    for cal in calendars:
        events += client.calendar_events(cal.get(ep.F_ID), to_ms(lo), to_ms(hi))
    return {
        "contacts": client.list_contacts(),
        "opportunities": client.search_opportunities(),
        "pipelines": client.pipelines(),
        "calendars": calendars,
        "events": events,
        "conversations": client.conversations(),
    }


def build_report(data: dict, period: Period, tz: tzinfo = timezone.utc, compare_previous: bool = False,
                 location: dict | None = None, assistant: str = "Your AI assistant", currency: str = "$") -> dict:
    lo, hi = day_window(period.start, period.end, tz)
    metrics = compute_metrics(data, lo, hi)
    prev_metrics = None
    prev_period = None
    if compare_previous:
        prev_period = period.previous()
        plo, phi = day_window(prev_period.start, prev_period.end, tz)
        prev_metrics = compute_metrics(data, plo, phi)
    period_word = "last week" if period.days == 7 else f"the previous {period.days} days"
    return {
        "location": location or {},
        "period": {"from": period.start.isoformat(), "to": period.end.isoformat(), "days": period.days,
                   "label": period.label(), "timezone": str(tz)},
        "previous_period": ({"from": prev_period.start.isoformat(), "to": prev_period.end.isoformat()}
                            if prev_period else None),
        "metrics": metrics,
        "previous_metrics": prev_metrics,
        "deltas": deltas(metrics, prev_metrics) if prev_metrics is not None else None,
        "stages": stage_breakdown(data.get("opportunities") or [], data.get("pipelines") or []),
        "highlights": build_highlights(metrics, prev_metrics, period_word, assistant, currency),
        "currency": currency,
    }


def run_report(client: GHLClient, period: Period, tz: tzinfo = timezone.utc, compare_previous: bool = False,
               **kw) -> dict:
    fetch_from = period.previous() if compare_previous else period
    lo, _ = day_window(fetch_from.start, fetch_from.end, tz)
    _, hi = day_window(period.start, period.end, tz)
    data = fetch_data(client, lo, hi)
    try:
        location = client.location()
    except Exception:  # noqa: BLE001 - the name is cosmetic, never fail the report for it
        location = {"id": client.location_id}
    rep = build_report(data, period, tz, compare_previous, location, **kw)
    return {"demo": bool(getattr(client, "demo", False)), **rep}


# ---- rendering ---------------------------------------------------------------------------

def _value(key: str, v, currency: str) -> str:
    if v is None:
        return "n/a"
    if key in ("booking_rate", "show_rate"):
        return fmt_pct(v)
    if key in ("won_value", "pipeline_value"):
        return fmt_money(v, currency)
    return f"{v:,}" if isinstance(v, int) else str(v)


def _delta_text(key: str, d: dict | None) -> tuple[str, str]:
    """(text, tone) where tone is good / bad / flat / ''."""
    if not d or d.get("change") is None:
        return "", ""
    change, pct = d["change"], d["pct"]
    is_rate = key in ("booking_rate", "show_rate")
    if change == 0 or (is_rate and round(abs(change) * 100) == 0):
        return "no change", "flat"
    good = (change < 0) if key in LOWER_IS_BETTER else (change > 0)
    arrow = "▲" if change > 0 else "▼"
    if is_rate:
        pts = round(abs(change) * 100)
        txt = f"{arrow} {pts} pt" + ("" if pts == 1 else "s")
    elif pct is None:
        txt = f"{arrow} new"
    else:
        txt = f"{arrow} {abs(pct):.0f}%"
    return txt, ("good" if good else "bad")


CARD_KEYS = ("new_leads", "appointments_booked", "show_rate", "booking_rate", "won_value", "pipeline_value",
             "conversations", "no_show")


def render_html(report: dict, branding: Branding | None = None) -> str:
    b = branding or Branding()
    cur = report.get("currency", "$")
    m, dl = report["metrics"], report.get("deltas") or {}
    client = b.client_name or report.get("location", {}).get("name") or "your business"
    color = b.brand_color
    tone_color = {"good": "#1a7f37", "bad": "#c62828", "flat": "#6b6a66", "": "#6b6a66"}
    cards = []
    for key in CARD_KEYS:
        txt, tone = _delta_text(key, dl.get(key))
        if key == "pipeline_value":
            txt, tone = f"{m.get('open_count', 0)} open right now", ""
        elif txt:
            txt += "" if txt == "no change" else " vs previous"
        sub = f'<div style="font-size:12px;color:{tone_color[tone]};margin-top:4px">{esc(txt)}</div>' if txt else ""
        cards.append(
            f'<td class="card" style="width:25%;padding:6px;vertical-align:top"><div style="border:1px solid #e3e3e0;border-radius:8px;padding:12px">'
            f'<div style="font-size:12px;color:#52514e">{esc(LABELS[key])}</div>'
            f'<div style="font-size:24px;font-weight:700;color:#0b0b0b">{esc(_value(key, m.get(key), cur))}</div>{sub}</div></td>')
    card_rows = "".join("<tr>" + "".join(cards[i:i + 4]) + "</tr>" for i in range(0, len(cards), 4))
    hl = "".join(f'<li style="margin:6px 0">{esc(h)}</li>' for h in report["highlights"])
    stages = report.get("stages") or []
    max_count = max((s["count"] for s in stages), default=0) or 1
    stage_rows = "".join(
        f'<tr><td style="padding:6px 8px;border-bottom:1px solid #eee">{esc(s["stage"])}'
        f'<div style="font-size:11px;color:#6b6a66">{esc(s["pipeline"])}</div></td>'
        f'<td style="padding:6px 8px;border-bottom:1px solid #eee;width:45%">'
        f'<div title="{esc(s["stage"])}: {s["count"]}" style="background:{esc(color)};height:12px;border-radius:0 4px 4px 0;'
        f'width:{max(2, round(s["count"] / max_count * 100))}%"></div></td>'
        f'<td style="padding:6px 8px;border-bottom:1px solid #eee;text-align:right">{s["count"]}</td>'
        f'<td style="padding:6px 8px;border-bottom:1px solid #eee;text-align:right">{esc(fmt_money(s["value"], cur))}</td></tr>'
        for s in stages)
    stage_block = (
        '<h2 style="font-size:16px;margin:24px 0 8px">Open opportunities by stage</h2>'
        '<table role="presentation" style="width:100%;border-collapse:collapse;font-size:14px">'
        '<tr><th style="text-align:left;padding:6px 8px">Stage</th><th></th><th style="text-align:right;padding:6px 8px">Count</th>'
        f'<th style="text-align:right;padding:6px 8px">Value</th></tr>{stage_rows}</table>'
    ) if stages else '<p style="color:#52514e">No open opportunities right now.</p>'
    logo = (f'<img src="{esc(b.logo_url)}" alt="{esc(b.brand_name)}" style="max-height:44px;display:block;margin-bottom:8px">'
            if b.logo_url else "")
    brand = f'<div style="font-weight:700;font-size:15px;color:#fff">{esc(b.brand_name)}</div>' if b.brand_name else ""
    prev = report.get("previous_period")
    compare = (f' &middot; compared with {esc(prev["from"])} to {esc(prev["to"])}' if prev else "")
    footer = f"Prepared for {esc(client)} by {esc(b.brand_name)}." if b.brand_name else f"Prepared for {esc(client)}."
    return f"""<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>{esc(client)} results {esc(report['period']['label'])}</title>
<style>@media print {{ body {{ background:#fff !important }} .shell {{ box-shadow:none !important }} }}
@media (max-width:600px) {{ td.card {{ display:block; width:auto !important }} }}</style></head>
<body style="margin:0;padding:24px 12px;background:#f4f4f2;font-family:-apple-system,Segoe UI,Roboto,Helvetica,Arial,sans-serif;color:#1b1b1b">
<table role="presentation" class="shell" style="max-width:680px;width:100%;margin:0 auto;background:#fff;border-radius:10px;border-collapse:collapse;overflow:hidden">
<tr><td style="background:{esc(color)};padding:20px 24px">{logo}{brand}
<div style="font-size:22px;font-weight:700;color:#fff;margin-top:4px">Your results: {esc(report['period']['label'])}</div>
<div style="font-size:13px;color:#fff;opacity:.9">{esc(client)}{compare}</div></td></tr>
<tr><td style="padding:20px 24px">{demo_banner_html(bool(report.get("demo")))}
<h2 style="font-size:16px;margin:0 0 8px">Highlights</h2><ul style="padding-left:20px;margin:0">{hl}</ul>
<h2 style="font-size:16px;margin:24px 0 8px">The numbers</h2>
<table role="presentation" style="width:100%;border-collapse:collapse">{card_rows}</table>
{stage_block}
<p style="font-size:12px;color:#6b6a66;margin-top:24px">Booking rate = appointments booked / new leads. Show rate = showed / (showed + no-shows).
Pipeline value is the total of open opportunities today.</p>
</td></tr>
<tr><td style="padding:14px 24px;border-top:1px solid #eee;font-size:12px;color:#6b6a66">{footer}</td></tr>
</table></body></html>
"""


def render_markdown(report: dict, branding: Branding | None = None) -> str:
    b = branding or Branding()
    cur = report.get("currency", "$")
    client = b.client_name or report.get("location", {}).get("name") or "your business"
    m, dl = report["metrics"], report.get("deltas") or {}
    lines = demo_md_line(bool(report.get("demo"))) + [f"# {client}: results {report['period']['label']}", ""]
    if b.brand_name:
        lines += [f"Prepared by {b.brand_name}", ""]
    lines += ["## Highlights", ""] + [f"- {h}" for h in report["highlights"]] + ["", "## The numbers", ""]
    head = "| Metric | This period |" + (" Previous | Change |" if dl else "")
    lines += [head, "|---|---|" + ("---|---|" if dl else "")]
    for key in ("new_leads", "appointments_booked", "showed", "no_show", "cancelled", "booking_rate", "show_rate",
                "opportunities_created", "won_count", "won_value", "lost_count", "open_count", "pipeline_value",
                "conversations"):
        row = f"| {LABELS[key]} | {_value(key, m.get(key), cur)} |"
        if dl:
            d = dl.get(key)
            row += (f" {_value(key, d['previous'], cur)} | {_delta_text(key, d)[0] or '-'} |" if d else " - | - |")
        lines.append(row)
    if report.get("stages"):
        lines += ["", "## Open opportunities by stage", "", "| Pipeline | Stage | Count | Value |", "|---|---|---|---|"]
        lines += [f"| {s['pipeline']} | {s['stage']} | {s['count']} | {fmt_money(s['value'], cur)} |"
                  for s in report["stages"]]
    lines.append("")
    return "\n".join(lines)


def render_json(report: dict) -> str:
    return json.dumps({"demo": bool(report.get("demo")), **report}, indent=2, default=str)
