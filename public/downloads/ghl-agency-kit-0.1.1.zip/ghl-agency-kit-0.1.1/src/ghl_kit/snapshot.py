"""`ghl-kit snapshot export|diff`: back up a sub-account's configuration and see what changed.

This is a JSON backup of configuration you can read through the API, not a GHL "Snapshot"
(the agency feature). It does not contain contacts, conversations or workflow steps.
"""
from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from . import __version__
from . import endpoints as ep
from .branding import DEMO_NOTICE, demo_md_line
from .client import GHLClient

RESOURCE_TYPES = ("pipelines", "custom_fields", "tags", "custom_values", "calendars", "workflows")
# fields compared per resource type (id and name are always kept)
FIELDS = {
    "pipelines": ("name",),
    "custom_fields": ("name", "fieldKey", "dataType"),
    "tags": ("name",),
    "custom_values": ("name", "fieldKey", "value"),
    "calendars": ("name", "calendarType", "isActive", "slotDuration", "description"),
    "workflows": ("name", "status"),
}
STAGE_FIELDS = ("name", "position")


def _pick(item: dict, fields: tuple) -> dict:
    out = {"id": item.get(ep.F_ID)}
    for f in fields:
        if f in item:
            out[f] = item[f]
    out.setdefault("name", item.get(ep.F_NAME))
    return out


def export_snapshot(client: GHLClient) -> dict:
    try:
        location = client.location()
    except Exception:  # noqa: BLE001 - cosmetic only
        location = {}
    pipelines = []
    for p in client.pipelines():
        row = _pick(p, FIELDS["pipelines"])
        stages = sorted(p.get(ep.F_PIPELINE_STAGES) or [], key=lambda s: s.get(ep.F_STAGE_POSITION, 0))
        row["stages"] = [_pick(s, STAGE_FIELDS) for s in stages]
        pipelines.append(row)
    return {
        "meta": {
            "tool": f"ghl-agency-kit {__version__}",
            "exported_at": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
            "location_id": client.location_id,
            "location_name": location.get("name", ""),
            "demo": bool(getattr(client, "demo", False)),
        },
        "pipelines": pipelines,
        "custom_fields": [_pick(x, FIELDS["custom_fields"]) for x in client.custom_fields()],
        "tags": [_pick(x, FIELDS["tags"]) for x in client.tags()],
        "custom_values": [_pick(x, FIELDS["custom_values"]) for x in client.custom_values()],
        "calendars": [_pick(x, FIELDS["calendars"]) for x in client.calendars()],
        "workflows": [_pick(x, FIELDS["workflows"]) for x in client.workflows()],
    }


def load_snapshot(path: str | Path) -> dict:
    p = Path(path)
    if not p.exists():
        raise FileNotFoundError(f"Snapshot file not found: {p}")
    try:
        data = json.loads(p.read_text(encoding="utf-8"))
    except ValueError as exc:
        raise ValueError(f"{p} is not a valid JSON snapshot: {exc}") from exc
    if not isinstance(data, dict) or not any(k in data for k in RESOURCE_TYPES):
        raise ValueError(f"{p} does not look like a ghl-kit snapshot (no pipelines/custom_fields/tags/... keys)")
    return data


def _norm(v: Any) -> str:
    return " ".join(str(v or "").split()).casefold()


def _label(item: dict) -> str:
    return str(item.get("name") or item.get("id") or "?")


def diff_items(a: list[dict], b: list[dict], fields: tuple, nested: dict | None = None) -> dict:
    """Pair items by id, then by name; return added / removed / changed."""
    a, b = list(a or []), list(b or [])
    pairs: list[tuple[dict, dict, str]] = []
    b_by_id = {x.get("id"): x for x in b if x.get("id")}
    used_b: set[int] = set()
    rest_a = []
    for x in a:
        y = b_by_id.get(x.get("id")) if x.get("id") else None
        if y is not None and id(y) not in used_b:
            pairs.append((x, y, "id"))
            used_b.add(id(y))
        else:
            rest_a.append(x)
    rest_b = [y for y in b if id(y) not in used_b]
    b_by_name: dict[str, list[dict]] = {}
    for y in rest_b:
        b_by_name.setdefault(_norm(y.get("name")), []).append(y)
    removed = []
    for x in rest_a:
        cands = b_by_name.get(_norm(x.get("name"))) or []
        if cands and x.get("name"):
            y = cands.pop(0)
            pairs.append((x, y, "name"))
            used_b.add(id(y))
        else:
            removed.append(x)
    added = [y for y in b if id(y) not in used_b]
    changed = []
    for x, y, how in pairs:
        changes = []
        for f in fields:
            if x.get(f) != y.get(f) and not (how == "name" and f == "name"):
                changes.append({"field": f, "from": x.get(f), "to": y.get(f)})
        entry: dict[str, Any] = {"id": y.get("id"), "name": _label(y), "matched_by": how, "changes": changes}
        for key, sub_fields in (nested or {}).items():
            sub = diff_items(x.get(key) or [], y.get(key) or [], sub_fields)
            if sub["added"] or sub["removed"] or sub["changed"]:
                entry[key] = sub
        if changes or any(k in entry for k in (nested or {})):
            changed.append(entry)
    return {
        "added": [{"id": y.get("id"), "name": _label(y)} for y in added],
        "removed": [{"id": x.get("id"), "name": _label(x)} for x in removed],
        "changed": changed,
    }


def diff_snapshots(a: dict, b: dict) -> dict:
    result: dict[str, Any] = {"from": a.get("meta", {}), "to": b.get("meta", {}), "resources": {}}
    for rt in RESOURCE_TYPES:
        nested = {"stages": STAGE_FIELDS} if rt == "pipelines" else None
        result["resources"][rt] = diff_items(a.get(rt) or [], b.get(rt) or [], FIELDS[rt], nested)
    return result


def is_demo(diff: dict) -> bool:
    """True when either snapshot came from the fake demo account."""
    return bool((diff.get("from") or {}).get("demo") or (diff.get("to") or {}).get("demo"))


def has_differences(diff: dict) -> bool:
    return any(r["added"] or r["removed"] or r["changed"] for r in diff["resources"].values())


def summary_counts(diff: dict) -> dict:
    return {rt: {k: len(v[k]) for k in ("added", "removed", "changed")} for rt, v in diff["resources"].items()}


def _fmt(v) -> str:
    return json.dumps(v) if not isinstance(v, str) else repr(v)


def _change_lines(entry: dict, indent: str) -> list[str]:
    lines = []
    for c in entry["changes"]:
        lines.append(f"{indent}{c['field']}: {_fmt(c['from'])} -> {_fmt(c['to'])}")
    stages = entry.get("stages")
    if stages:
        for s in stages["added"]:
            lines.append(f"{indent}stage added: {s['name']}")
        for s in stages["removed"]:
            lines.append(f"{indent}stage removed: {s['name']}")
        for s in stages["changed"]:
            for c in s["changes"]:
                lines.append(f"{indent}stage '{s['name']}' {c['field']}: {_fmt(c['from'])} -> {_fmt(c['to'])}")
    return lines


def _title(rt: str) -> str:
    return rt.replace("_", " ").capitalize()


def render_text(diff: dict) -> str:
    lines = [DEMO_NOTICE, ""] if is_demo(diff) else []
    if not has_differences(diff):
        return "\n".join(lines + ["No differences.", ""])
    for rt, r in diff["resources"].items():
        if not (r["added"] or r["removed"] or r["changed"]):
            continue
        lines.append(f"{_title(rt)}:")
        lines += [f"  + {x['name']}" for x in r["added"]]
        lines += [f"  - {x['name']}" for x in r["removed"]]
        for e in r["changed"]:
            lines.append(f"  ~ {e['name']}")
            lines += _change_lines(e, "      ")
    counts = summary_counts(diff)
    total = {k: sum(c[k] for c in counts.values()) for k in ("added", "removed", "changed")}
    lines.append(f"\n{total['added']} added, {total['removed']} removed, {total['changed']} changed.")
    return "\n".join(lines) + "\n"


def render_markdown(diff: dict) -> str:
    a, b = diff.get("from", {}), diff.get("to", {})
    lines = demo_md_line(is_demo(diff)) + ["# Configuration changes", "",
             f"From: {a.get('location_name') or a.get('location_id') or 'snapshot A'} ({a.get('exported_at', '?')})  ",
             f"To: {b.get('location_name') or b.get('location_id') or 'snapshot B'} ({b.get('exported_at', '?')})", ""]
    if not has_differences(diff):
        return "\n".join(lines + ["No differences.", ""])
    lines += ["| Resource | Added | Removed | Changed |", "|---|---|---|---|"]
    for rt, c in summary_counts(diff).items():
        lines.append(f"| {_title(rt)} | {c['added']} | {c['removed']} | {c['changed']} |")
    for rt, r in diff["resources"].items():
        if not (r["added"] or r["removed"] or r["changed"]):
            continue
        lines += ["", f"## {_title(rt)}", ""]
        lines += [f"- Added: **{x['name']}**" for x in r["added"]]
        lines += [f"- Removed: **{x['name']}**" for x in r["removed"]]
        for e in r["changed"]:
            lines.append(f"- Changed: **{e['name']}**")
            lines += [f"  - {line.strip()}" for line in _change_lines(e, "")]
    lines.append("")
    return "\n".join(lines)


def render_json(diff: dict) -> str:
    return json.dumps({"demo": is_demo(diff), **diff, "has_differences": has_differences(diff), "summary": summary_counts(diff)}, indent=2)
