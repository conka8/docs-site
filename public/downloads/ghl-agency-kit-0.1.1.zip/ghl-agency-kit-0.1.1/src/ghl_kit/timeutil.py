"""Timestamp helpers: GHL mixes ISO strings and epoch milliseconds."""
from __future__ import annotations

from datetime import date, datetime, time, timedelta, timezone, tzinfo


def parse_ts(value) -> datetime | None:
    """Parse an ISO string, epoch seconds or epoch milliseconds into an aware UTC datetime."""
    if value is None or value == "":
        return None
    if isinstance(value, datetime):
        return value if value.tzinfo else value.replace(tzinfo=timezone.utc)
    if isinstance(value, bool):
        return None
    if isinstance(value, (int, float)):
        num = float(value)
    else:
        text = str(value).strip()
        try:
            num = float(text)
        except ValueError:
            num = None
        if num is None:
            if text.endswith("Z") or text.endswith("z"):
                text = text[:-1] + "+00:00"
            try:
                dt = datetime.fromisoformat(text)
            except ValueError:
                try:
                    dt = datetime.fromisoformat(text.replace(" ", "T", 1))
                except ValueError:
                    return None
            if dt.tzinfo is None:
                dt = dt.replace(tzinfo=timezone.utc)
            return dt.astimezone(timezone.utc)
    if num > 1e11:  # milliseconds
        num /= 1000.0
    try:
        return datetime.fromtimestamp(num, tz=timezone.utc)
    except (OverflowError, OSError, ValueError):
        return None


def to_ms(dt: datetime) -> int:
    return int(dt.timestamp() * 1000)


def iso(dt: datetime) -> str:
    return dt.astimezone(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.000Z")


def day_window(start: date, end: date, tz: tzinfo) -> tuple[datetime, datetime]:
    """[start 00:00, end+1 00:00) in tz, returned as aware datetimes."""
    lo = datetime.combine(start, time.min).replace(tzinfo=tz)
    hi = datetime.combine(end + timedelta(days=1), time.min).replace(tzinfo=tz)
    return lo, hi


def parse_day(text: str) -> date:
    try:
        return date.fromisoformat(str(text).strip())
    except ValueError as exc:
        raise ValueError(f"'{text}' is not a date. Use YYYY-MM-DD, for example 2026-10-01.") from exc
