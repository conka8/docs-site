import json
from pathlib import Path

import pytest

from ghl_kit.client import GHLClient
from ghl_kit.fake import FakeGHL

FIX = Path(__file__).parent / "fixtures"


@pytest.fixture
def state():
    return json.loads((FIX / "api" / "state.json").read_text(encoding="utf-8"))


@pytest.fixture
def fake(state):
    return FakeGHL(state)


@pytest.fixture
def sleeps():
    return []


@pytest.fixture
def client(fake, sleeps):
    return GHLClient("test-token", "loc-123", transport=fake, sleep=sleeps.append)


@pytest.fixture
def fixtures_dir():
    return FIX
