import io
import json
import runpy
import shutil
import sys

import pytest

from ghl_kit.cli import main

FROM_TO = ["--from", "2026-10-01", "--to", "2026-10-07"]
DEMO = "Demo data from the built-in fake GoHighLevel account, not a real client."


@pytest.fixture
def api(tmp_path, fixtures_dir):
    d = tmp_path / "api"
    shutil.copytree(fixtures_dir / "api", d)
    return str(d)


def run(argv, env=None):
    out = io.StringIO()
    code = main(argv, env=env if env is not None else {}, out=out)
    return code, out.getvalue()


def test_no_command_prints_help():
    code, out = run([])
    assert code == 2 and "onboard" in out


def test_version(capsys):
    assert run(["--version"])[0] == 0
    assert "ghl-kit 0.1.1" in capsys.readouterr().out


def test_missing_token_error(capsys):
    code, _ = run(["report"] + FROM_TO, env={})
    assert code == 2
    err = capsys.readouterr().err
    assert "GHL_TOKEN is not set" in err and "Private Integrations" in err


def test_missing_location_error(capsys):
    code, _ = run(["snapshot", "export", "-o", "x.json"], env={"GHL_TOKEN": "abc"})
    assert code == 2 and "GHL_LOCATION_ID is not set" in capsys.readouterr().err


def test_api_error_exit_code(capsys, monkeypatch):
    import ghl_kit.client as client_mod
    monkeypatch.setattr(client_mod, "urllib_transport", lambda *a: (401, {}, b'{"message":"Invalid JWT"}'))
    code, _ = run(["report"] + FROM_TO, env={"GHL_TOKEN": "bad", "GHL_LOCATION_ID": "loc"})
    assert code == 1
    assert "GoHighLevel error: GoHighLevel rejected the token" in capsys.readouterr().err


def test_report_formats(api, tmp_path):
    code, out = run(["--fake-api", api, "report"] + FROM_TO + ["--compare-previous"])
    assert code == 0 and out.startswith(f"> **{DEMO}**\n\n# Acme Roofing: results")
    html = tmp_path / "r.html"
    code, out = run(["--fake-api", api, "report"] + FROM_TO + [
        "-o", str(html), "--brand-name", "Peak AI", "--brand-color", "#ff6600", "--client-name", "Acme <Roof>"])
    assert code == 0 and "Wrote" in out and "- Your AI assistant booked 4 appointments." in out
    page = html.read_text()
    assert "Peak AI" in page and "#ff6600" in page and "Acme &lt;Roof&gt;" in page
    js = tmp_path / "r.json"
    assert run(["--fake-api", api, "report"] + FROM_TO + ["-o", str(js)])[0] == 0
    assert json.loads(js.read_text())["metrics"]["new_leads"] == 3
    code, out = run(["--fake-api", api, "report"] + FROM_TO + ["--format", "json"])
    assert json.loads(out)["period"]["days"] == 7


def test_report_options_after_subcommand(api):
    code, out = run(["report", "--fake-api", api, "--location-id", "loc-123"] + FROM_TO)
    assert code == 0 and "Acme Roofing" in out


def test_report_timezone_and_bad_inputs(api, capsys):
    assert run(["--fake-api", api, "report"] + FROM_TO + ["--timezone", "America/Chicago"])[0] == 0
    assert run(["--fake-api", api, "report"] + FROM_TO + ["--timezone", "Mars/Base"])[0] == 2
    assert "Unknown time zone" in capsys.readouterr().err
    assert run(["--fake-api", api, "report", "--from", "10/01/2026", "--to", "2026-10-07"])[0] == 2
    assert run(["--fake-api", api, "report", "--from", "2026-10-07", "--to", "2026-10-01"])[0] == 2
    assert run(["--fake-api", api, "report"] + FROM_TO + ["--brand-color", "red;x"])[0] == 2
    assert run(["--fake-api", str(api) + "-missing", "report"] + FROM_TO)[0] == 2
    assert run(["report"])[0] == 2  # argparse: --from/--to required


def test_report_demo_mode():
    code, out = run(["--fake-api", "demo", "report"] + FROM_TO + ["--compare-previous"])
    assert code == 0
    assert "Your AI assistant booked 14 appointments, up 40% vs last week." in out


def test_onboard_dry_run_and_real(api, fixtures_dir, tmp_path):
    plan = str(fixtures_dir / "plan.yaml")
    code, out = run(["--fake-api", api, "onboard", plan, "--dry-run"])
    assert code == 0 and "DRY RUN" in out and "would create" in out
    report = tmp_path / "onb.html"
    code, out = run(["--fake-api", api, "onboard", plan, "-o", str(report), "--brand-name", "Peak"])
    assert code == 0 and "checklist 2/9 verified" in out
    assert "Peak" in report.read_text()
    code, out = run(["--fake-api", api, "onboard", plan, "--format", "json"])
    assert json.loads(out)["actions"][0]["status"] == "exists"
    assert run(["--fake-api", api, "onboard", plan, "--strict", "--dry-run"])[0] == 1


def test_onboard_bad_plan(api, tmp_path, capsys):
    p = tmp_path / "p.yaml"
    p.write_text("custom_fields: [{name: X, type: NOPE}]")
    assert run(["--fake-api", api, "onboard", str(p)])[0] == 2
    assert "not one of" in capsys.readouterr().err
    assert run(["--fake-api", api, "onboard", str(tmp_path / "missing.yaml")])[0] == 2


def test_onboard_failure_exit_code(tmp_path, fixtures_dir, state):
    d = tmp_path / "api"
    d.mkdir()
    (d / "state.json").write_text(json.dumps(state))
    (d / "routes.json").write_text(json.dumps({"POST /locations/loc-123/tags": {"status": 422, "body": {"message": "no"}}}))
    code, out = run(["--fake-api", str(d), "onboard", str(fixtures_dir / "plan.yaml")])
    assert code == 1 and "| tag | ai-booked | failed |" in out


def test_snapshot_export_and_diff(api, tmp_path):
    a = tmp_path / "a.json"
    code, out = run(["--fake-api", api, "snapshot", "export", "-o", str(a)])
    assert code == 0 and "Saved 1 pipelines, 1 custom fields, 1 tags" in out
    data = json.loads(a.read_text())
    data["tags"].append({"id": "t9", "name": "new-tag"})
    data["pipelines"][0]["stages"][0]["name"] = "Fresh Lead"
    b = tmp_path / "b.json"
    b.write_text(json.dumps(data))
    code, out = run(["snapshot", "diff", str(a), str(a), "--exit-code"])
    assert code == 0 and out == f"{DEMO}\n\nNo differences.\n"
    code, out = run(["snapshot", "diff", str(a), str(b)])
    assert code == 0 and "+ new-tag" in out
    code, out = run(["snapshot", "diff", str(a), str(b), "--exit-code"])
    assert code == 1
    code, out = run(["snapshot", "diff", str(a), str(b), "--format", "md"])
    assert "# Configuration changes" in out and "stage 'Fresh Lead' name" in out
    code, out = run(["snapshot", "diff", str(a), str(b), "--format", "json"])
    assert json.loads(out)["has_differences"] is True
    md = tmp_path / "d.md"
    assert run(["snapshot", "diff", str(a), str(b), "--format", "md", "-o", str(md)])[0] == 0
    assert md.read_text().startswith(f"> **{DEMO}**\n\n# Configuration changes")


def test_snapshot_errors(tmp_path, capsys):
    assert run(["snapshot"])[0] == 2
    assert run(["snapshot", "diff", str(tmp_path / "x.json"), str(tmp_path / "y.json")])[0] == 2
    assert "not found" in capsys.readouterr().err


def test_demo_data_command(tmp_path):
    code, out = run(["demo-data", str(tmp_path / "demo")])
    assert code == 0 and (tmp_path / "demo" / "state.json").exists()
    code, out = run(["--fake-api", str(tmp_path / "demo"), "report"] + FROM_TO)
    assert code == 0 and "Bright Smile Dental" in out


def test_python_dash_m(monkeypatch, capsys):
    monkeypatch.setattr(sys, "argv", ["ghl_kit", "--version"])
    with pytest.raises(SystemExit) as info:
        runpy.run_module("ghl_kit", run_name="__main__")
    assert info.value.code == 0
    assert "ghl-kit 0.1.1" in capsys.readouterr().out


def test_demo_banner_in_every_output(api, fixtures_dir, tmp_path, capsys):
    plan = str(fixtures_dir / "plan.yaml")
    for fmt in ("html", "md", "json"):
        rep = tmp_path / f"r.{fmt}"
        onb = tmp_path / f"o.{fmt}"
        assert run(["--fake-api", "demo", "report"] + FROM_TO + ["-o", str(rep)])[0] == 0
        assert run(["--fake-api", api, "onboard", plan, "--dry-run", "-o", str(onb)])[0] == 0
        for f in (rep, onb):
            text = f.read_text()
            if fmt == "json":
                assert json.loads(text)["demo"] is True
            elif fmt == "md":
                assert text.splitlines()[0] == f"> **{DEMO}**"
            else:
                assert f'<div class="demo"' in text and DEMO in text
    snap = tmp_path / "s.json"
    assert run(["--fake-api", "demo", "snapshot", "export", "-o", str(snap)])[0] == 0
    assert json.loads(snap.read_text())["meta"]["demo"] is True
    code, out = run(["snapshot", "diff", str(snap), str(snap), "--format", "json"])
    assert json.loads(out)["demo"] is True


def test_onboard_says_where_it_writes(api, fixtures_dir, capsys):
    plan = str(fixtures_dir / "plan.yaml")
    code, out = run(["--fake-api", api, "onboard", plan])
    assert code == 0
    err = capsys.readouterr().err
    assert "Writing to the fake demo account loc-123... (use --dry-run to preview)" in err
    assert "applied to the fake demo account only" in out
    code, _ = run(["--fake-api", api, "onboard", plan, "--dry-run"])
    assert "Writing to" not in capsys.readouterr().err


def test_onboard_real_account_message(fixtures_dir, monkeypatch, capsys):
    from ghl_kit import cli
    from ghl_kit.client import GHLClient
    from ghl_kit.fake import FakeGHL

    fake = FakeGHL(json.loads((fixtures_dir / "api" / "state.json").read_text()))

    def real_looking(method, url, headers, body, timeout=30.0):  # not marked as fake
        return fake(method, url, headers, body, timeout)

    monkeypatch.setattr(cli, "make_client", lambda args, env=None: GHLClient("t", "loc-123", transport=real_looking))
    code, out = run(["onboard", str(fixtures_dir / "plan.yaml")])
    assert code == 0
    assert "Writing to the GoHighLevel account loc-123... (use --dry-run to preview)" in capsys.readouterr().err
    assert DEMO not in out and "Changes were applied." in out
