import json
import threading
from datetime import datetime, timedelta, timezone
from email.utils import format_datetime
from http.server import BaseHTTPRequestHandler, HTTPServer

import pytest

from ghl_kit import endpoints as ep
from ghl_kit.client import (ConfigError, GHLAuthError, GHLClient, GHLError, GHLForbidden, GHLNotFound,
                            GHLRateLimited, parse_retry_after, urllib_transport)
from ghl_kit.fake import FakeTransport, route_key


def make(transport, sleeps=None, **kw):
    return GHLClient("tok", "loc-1", transport=transport, sleep=(sleeps.append if sleeps is not None else lambda s: None), **kw)


def test_headers_and_url():
    ft = FakeTransport().add("GET", "/opportunities/pipelines", {"pipelines": [{"id": "p"}]}, query={"locationId": "loc-1"})
    c = make(ft)
    assert c.pipelines() == [{"id": "p"}]
    call = ft.calls[0]
    assert call["headers"]["Authorization"] == "Bearer tok"
    assert call["headers"]["Version"] == "2021-07-28"
    assert call["headers"]["Accept"] == "application/json"
    assert "Content-Type" not in call["headers"]
    assert call["url"].startswith("https://services.leadconnectorhq.com/opportunities/pipelines?")


def test_build_url_quotes_location_and_drops_none():
    c = make(FakeTransport())
    assert c.build_url("/locations/{locationId}/tags", {"a": None, "b": 2}) == \
        "https://services.leadconnectorhq.com/locations/loc-1/tags?b=2"


def test_cursor_pagination_across_pages():
    ft = FakeTransport()
    page1 = [{"id": f"c{i}"} for i in range(100)]
    ft.add("GET", "/contacts/", {"contacts": page1, "meta": {"startAfterId": "c99", "startAfter": 1700}},
           query={"locationId": "loc-1", "limit": 100})
    ft.add("GET", "/contacts/", {"contacts": [{"id": "c100"}, {"id": "c101"}], "meta": {"startAfterId": "c101"}},
           query={"locationId": "loc-1", "limit": 100, "startAfterId": "c99", "startAfter": 1700})
    out = make(ft).list_contacts()
    assert [c["id"] for c in out] == [f"c{i}" for i in range(102)]
    assert len(ft.calls) == 2
    assert ft.calls[1]["query"]["startAfterId"] == "c99"


def test_cursor_pagination_with_stateful_fake(client, fake, state):
    import dataclasses
    small = dataclasses.replace(ep.OPPORTUNITIES_SEARCH, page_size=2)
    items = client.get_list(small)
    assert sorted(o["id"] for o in items) == sorted(o["id"] for o in state["opportunities"])
    # 6 items in pages of 2: the 3rd page is full, so one more (empty) page is requested
    assert len(fake.calls) == 4
    assert all(c["query"]["location_id"] == "loc-123" for c in fake.calls)


def test_cursor_pagination_stops_on_repeated_cursor():
    ft = FakeTransport()
    page = {"contacts": [{"id": "x"}], "meta": {"startAfterId": "x"}}
    import dataclasses
    e = dataclasses.replace(ep.CONTACTS_LIST, page_size=1)
    ft.routes[route_key("GET", "/contacts/?limit=1&locationId=loc-1")] = {"body": page}
    ft.routes[route_key("GET", "/contacts/?limit=1&locationId=loc-1&startAfterId=x")] = {"body": page}
    out = make(ft).get_list(e)
    assert len(out) == 2


def test_page_pagination():
    import dataclasses
    e = dataclasses.replace(ep.WORKFLOWS, paging="page", limit_param="limit", page_size=2)
    ft = FakeTransport()
    ft.add("GET", "/workflows/", {"workflows": [{"id": 1}, {"id": 2}]}, query={"locationId": "loc-1", "limit": 2, "page": 1})
    ft.add("GET", "/workflows/", {"workflows": [{"id": 3}]}, query={"locationId": "loc-1", "limit": 2, "page": 2})
    assert [w["id"] for w in make(ft).get_list(e)] == [1, 2, 3]


def test_page_body_pagination(client, fake, state):
    import dataclasses
    e = dataclasses.replace(ep.CONTACTS_SEARCH, page_size=4)
    out = client.get_list(e)
    assert len(out) == len(state["contacts"])
    posts = [c for c in fake.calls if c["method"] == "POST"]
    assert [p["body"]["page"] for p in posts] == [1, 2]
    assert posts[0]["body"]["locationId"] == "loc-123"
    assert posts[0]["body"]["pageLimit"] == 4
    assert posts[0]["headers"]["Content-Type"] == "application/json"


def test_search_contacts_passes_filters(client, fake):
    client.search_contacts(filters=[{"field": "dateAdded", "operator": "range", "value": {"gte": "x"}}])
    assert fake.calls[0]["body"]["filters"][0]["field"] == "dateAdded"


def test_last_item_pagination(client, fake, state):
    import dataclasses
    e = dataclasses.replace(ep.CONVERSATIONS_SEARCH, page_size=2)
    out = client.get_list(e)
    assert len(out) == len(state["conversations"])
    assert "startAfterDate" not in fake.calls[0]["query"]
    assert fake.calls[1]["query"]["startAfterDate"] == str(out[1]["sort"][0])


def test_last_item_pagination_stops_without_cursor_field():
    import dataclasses
    e = dataclasses.replace(ep.CONVERSATIONS_SEARCH, page_size=1)
    ft = FakeTransport().add("GET", "/conversations/search", {"conversations": [{"id": "a"}]},
                             query={"locationId": "loc-1", "limit": 1})
    assert make(ft).get_list(e) == [{"id": "a"}]


def test_max_pages_guard():
    import dataclasses
    e = dataclasses.replace(ep.WORKFLOWS, paging="page", limit_param="limit", page_size=1)

    def endless(method, url, headers, body):
        return 200, {}, json.dumps({"workflows": [{"id": url}]}).encode()

    class T(FakeTransport):
        def __call__(self, method, url, headers, body, timeout=30):
            return endless(method, url, headers, body)

    with pytest.raises(GHLError, match="Stopped after 3 pages"):
        make(T(), max_pages=3).get_list(e)


def test_unknown_paging_style():
    import dataclasses
    e = dataclasses.replace(ep.WORKFLOWS, paging="weird")
    with pytest.raises(ValueError):
        make(FakeTransport()).get_list(e)


def test_429_retry_uses_retry_after():
    sleeps = []
    ft = FakeTransport()
    ft.add("GET", "/workflows/", {"message": "Too many"}, status=429, headers={"Retry-After": "7"}, query={"locationId": "loc-1"})
    ft.add("GET", "/workflows/", {"workflows": [{"id": "w"}]}, query={"locationId": "loc-1"})
    assert make(ft, sleeps).workflows() == [{"id": "w"}]
    assert sleeps == [7.0]
    assert len(ft.calls) == 2


def test_429_lowercase_header_and_http_date():
    sleeps = []
    when = format_datetime(datetime.now(timezone.utc) + timedelta(seconds=30), usegmt=True)
    ft = FakeTransport()
    ft.add("GET", "/workflows/", {}, status=429, headers={"retry-after": when}, query={"locationId": "loc-1"})
    ft.add("GET", "/workflows/", {"workflows": []}, query={"locationId": "loc-1"})
    make(ft, sleeps).workflows()
    assert 25 <= sleeps[0] <= 31


def test_429_without_header_backs_off_and_gives_up():
    sleeps = []
    ft = FakeTransport().add("GET", "/workflows/", {"message": "slow down"}, status=429, query={"locationId": "loc-1"})
    with pytest.raises(GHLRateLimited, match="too many requests"):
        make(ft, sleeps, max_retries=3).workflows()
    assert sleeps == [1, 2, 4]


def test_retry_after_capped_by_max_wait():
    sleeps = []
    ft = FakeTransport()
    ft.add("GET", "/workflows/", {}, status=429, headers={"Retry-After": "9999"}, query={"locationId": "loc-1"})
    ft.add("GET", "/workflows/", {"workflows": []}, query={"locationId": "loc-1"})
    make(ft, sleeps, max_wait=60).workflows()
    assert sleeps == [60]


def test_server_error_retried_then_raises():
    sleeps = []
    ft = FakeTransport().add("GET", "/workflows/", {"message": "boom"}, status=502, query={"locationId": "loc-1"})
    with pytest.raises(GHLError, match="server error 502.*boom"):
        make(ft, sleeps, max_retries=2).workflows()
    assert len(sleeps) == 2


def test_parse_retry_after():
    assert parse_retry_after("3") == 3.0
    assert parse_retry_after("-1") == 0.0
    assert parse_retry_after(None) is None
    assert parse_retry_after("soon") is None
    now = datetime(2026, 10, 1, tzinfo=timezone.utc)
    assert parse_retry_after("Thu, 01 Oct 2026 00:00:10 GMT", now=now) == 10


@pytest.mark.parametrize("status,exc,needle", [
    (401, GHLAuthError, "rejected the token"),
    (403, GHLForbidden, "not allowed"),
    (404, GHLNotFound, "not found"),
    (422, GHLError, "error 422"),
])
def test_error_statuses(status, exc, needle):
    ft = FakeTransport().add("GET", "/workflows/", {"message": ["bad thing", "other"]}, status=status,
                             query={"locationId": "loc-1"})
    with pytest.raises(exc) as info:
        make(ft).workflows()
    msg = str(info.value)
    assert needle in msg
    assert "bad thing; other" in msg
    assert info.value.status == status
    assert info.value.path == "/workflows/"


def test_401_message_mentions_env_var(client, fake):
    c = GHLClient("tok", "loc-123", transport=lambda *a: (401, {}, b'{"message":"Invalid JWT"}'))
    with pytest.raises(GHLAuthError) as info:
        c.tags()
    assert "GHL_TOKEN" in str(info.value) and "Invalid JWT" in str(info.value)


def test_non_json_success_and_error_bodies():
    c = GHLClient("t", "l", transport=lambda *a: (200, {}, b"<html>"))
    with pytest.raises(GHLError, match="not JSON"):
        c.request("GET", "/x")
    c = GHLClient("t", "l", transport=lambda *a: (400, {}, b"plain failure"))
    with pytest.raises(GHLError, match="plain failure"):
        c.request("GET", "/x")
    c = GHLClient("t", "l", transport=lambda *a: (204, {}, b""))
    assert c.request("DELETE", "/x") == {}
    c = GHLClient("t", "l", transport=lambda *a: (200, {}, b"[1,2]"))
    assert c.request("GET", "/x") == {"data": [1, 2]}


def test_missing_token_and_location():
    with pytest.raises(ConfigError, match="GHL_TOKEN is not set"):
        GHLClient.from_env({})
    with pytest.raises(ConfigError, match="GHL_LOCATION_ID is not set"):
        GHLClient.from_env({"GHL_TOKEN": "x"})
    c = GHLClient.from_env({"GHL_TOKEN": " x ", "GHL_LOCATION_ID": "loc"})
    assert c.token == "x" and c.location_id == "loc"


def test_resource_methods(client, fake):
    assert client.location()["name"] == "Acme Roofing"
    assert len(client.custom_fields()) == 1
    assert len(client.custom_values()) == 1
    assert client.tags()[0]["name"] == "storm-lead"
    assert len(client.calendars()) == 2
    assert len(client.workflows()) == 2
    ev = client.calendar_events("cal1", 0, 2 ** 50)
    assert {e["id"] for e in ev} == {"e1", "e2", "e3", "e6", "e7"}
    tag = client.create_tag("vip")
    assert tag["name"] == "vip"
    cf = client.create_custom_field("Budget", "MONETORY", placeholder="$", options=None)
    assert cf["dataType"] == "MONETORY" and fake.writes[-1]["body"]["placeholder"] == "$"
    cv = client.create_custom_value("Owner", "Ann")
    assert cv["value"] == "Ann"


class _Handler(BaseHTTPRequestHandler):
    seen = []

    def do_GET(self):  # noqa: N802
        _Handler.seen.append({"path": self.path, "auth": self.headers.get("Authorization"),
                              "version": self.headers.get("Version")})
        if self.path.startswith("/locations/loc-1/tags"):
            body = json.dumps({"tags": [{"id": "t", "name": "hot"}]}).encode()
            self.send_response(200)
        else:
            body = b'{"message":"nope"}'
            self.send_response(404)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, *a):
        pass


def test_real_local_http_server_through_urllib():
    server = HTTPServer(("127.0.0.1", 0), _Handler)
    t = threading.Thread(target=server.serve_forever, kwargs={"poll_interval": 0.02}, daemon=True)
    t.start()
    try:
        base = f"http://127.0.0.1:{server.server_address[1]}"
        c = GHLClient("tok", "loc-1", base_url=base)  # default urllib transport
        assert c.tags() == [{"id": "t", "name": "hot"}]
        assert _Handler.seen[-1]["auth"] == "Bearer tok"
        assert _Handler.seen[-1]["version"] == "2021-07-28"
        with pytest.raises(GHLNotFound):
            c.workflows()
    finally:
        server.shutdown()
        server.server_close()


def test_urllib_transport_connection_error():
    server = HTTPServer(("127.0.0.1", 0), _Handler)
    port = server.server_address[1]
    server.server_close()  # nothing listens on this port now
    with pytest.raises(GHLError, match="Could not reach"):
        urllib_transport("GET", f"http://127.0.0.1:{port}/x", {}, None, 2)


def test_post_not_retried_on_server_error():
    sleeps = []
    ft = FakeTransport().add("POST", "/locations/loc-1/tags", {"message": "boom"}, status=502)
    with pytest.raises(GHLError, match="server error 502.*Not retried"):
        make(ft, sleeps).create_tag("x")
    assert len(ft.calls) == 1 and sleeps == []


def test_post_retried_only_on_429_with_retry_after():
    sleeps = []
    ft = FakeTransport()
    ft.add("POST", "/locations/loc-1/tags", {}, status=429, headers={"Retry-After": "3"})
    ft.add("POST", "/locations/loc-1/tags", {"tag": {"id": "t", "name": "x"}})
    assert make(ft, sleeps).create_tag("x") == {"id": "t", "name": "x"}
    assert sleeps == [3.0] and len(ft.calls) == 2
    ft = FakeTransport().add("POST", "/locations/loc-1/tags", {}, status=429)  # no Retry-After
    with pytest.raises(GHLRateLimited):
        make(ft, sleeps).create_tag("x")
    assert len(ft.calls) == 1


def test_search_post_still_retried_on_server_error(fake):
    sleeps, calls = [], []

    def flaky(method, url, headers, body, timeout=30.0):  # searches are reads, so a retry is safe
        calls.append(method)
        if len(calls) == 1:
            return 503, {}, b'{"message": "boom"}'
        return fake(method, url, headers, body, timeout)

    c = GHLClient("tok", "loc-123", transport=flaky, sleep=sleeps.append)
    assert isinstance(c.search_contacts(), list)
    assert calls[:2] == ["POST", "POST"] and sleeps == [1]


def test_demo_flag():
    assert make(FakeTransport()).demo is True
    assert make(lambda *a: (200, {}, b"{}")).demo is False
    assert make(lambda *a: (200, {}, b"{}"), demo=True).demo is True
