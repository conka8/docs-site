import json

import pytest

from ghl_kit.client import GHLClient
from ghl_kit.demo import build_demo_state
from ghl_kit.fake import FakeGHL, FakeTransport, load_fake_api, route_key


def test_route_key_sorts_query():
    assert route_key("get", "https://h/x?b=2&a=1") == "GET /x?a=1&b=2"
    assert route_key("POST", "/x", {"z": 1}) == "POST /x?z=1"


def test_fake_transport_unmatched_route_and_constructor_routes():
    ft = FakeTransport({"GET /a?y=2&x=1": {"body": {"ok": True}}})
    assert ft("GET", "https://h/a?x=1&y=2", {}, None)[0] == 200
    status, _, body = ft("GET", "https://h/missing", {}, None)
    assert status == 404 and b"no route for GET /missing" in body
    assert len(ft.calls) == 2


def test_fake_transport_callable_route():
    ft = FakeTransport({"GET /c": lambda m, u, h, b: (418, {}, b"{}")})
    assert ft("GET", "http://h/c", {}, None)[0] == 418


def test_fake_ghl_requires_bearer(state):
    status, _, _ = FakeGHL(state)("GET", "http://h/workflows/?locationId=loc-123", {}, None)
    assert status == 401


def test_fake_ghl_errors(state):
    g = FakeGHL(state)
    h = {"Authorization": "Bearer x"}
    assert g("GET", "http://h/locations/other/tags", h, None)[0] == 404
    assert g("GET", "http://h/nowhere", h, None)[0] == 404
    assert g("GET", "http://h/calendars/events?locationId=loc-123", h, None)[0] == 422
    assert g("POST", "http://h/locations/loc-123/tags", h, b'{"name": ""}')[0] == 422
    assert g("POST", "http://h/locations/loc-123/tags", h, b'{"name": "STORM-LEAD"}')[0] == 400
    assert g("GET", "http://h/contacts/?limit=2&startAfterId=unknown", h, None)[2] .startswith(b'{"contacts": []')


def test_demo_state_is_deterministic_and_reportable():
    a, b = build_demo_state(), build_demo_state()
    assert a == b
    c = GHLClient("t", "demo-location", transport=FakeGHL(a))
    assert len(c.list_contacts()) == len(a["contacts"]) == 55
    assert len(c.conversations()) == len(a["conversations"])


def test_load_fake_api(tmp_path, state):
    assert isinstance(load_fake_api("demo"), FakeGHL)
    with pytest.raises(FileNotFoundError):
        load_fake_api(tmp_path / "missing")
    with pytest.raises(FileNotFoundError, match="neither"):
        load_fake_api(tmp_path)
    (tmp_path / "state.json").write_text(json.dumps(state))
    t = load_fake_api(tmp_path, "loc-xyz")
    assert isinstance(t, FakeGHL) and t.location_id == "loc-xyz"
    (tmp_path / "routes.json").write_text(json.dumps({"GET /workflows/?locationId=loc-xyz&limit=1": {"body": {}}}))
    t2 = load_fake_api(tmp_path, "loc-xyz")
    assert isinstance(t2, FakeTransport) and isinstance(t2.fallback, FakeGHL)
    # routes-only folder
    only = tmp_path / "only"
    only.mkdir()
    (only / "routes.json").write_text(json.dumps({"GET /x": {"body": {"a": 1}}}))
    t3 = load_fake_api(only)
    assert t3.fallback is None
