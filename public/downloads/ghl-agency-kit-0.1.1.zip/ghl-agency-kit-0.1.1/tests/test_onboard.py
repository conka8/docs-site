import json

import pytest

from ghl_kit import onboard
from ghl_kit.branding import Branding
from ghl_kit.client import GHLClient
from ghl_kit.fake import FakeGHL, FakeTransport
from ghl_kit.onboard import (CREATED, EXISTS, FAILED, MANUAL, NOT_FOUND, PARTIAL, UNCHECKED, VERIFIED,
                             WOULD_CREATE, PlanError, load_plan, parse_plan, run_onboarding)


@pytest.fixture
def plan(fixtures_dir):
    return load_plan(fixtures_dir / "plan.yaml")


def by(result, kind=None):
    return {(a.kind, a.name): a.status for a in result.actions if kind is None or a.kind == kind}


def checks(result):
    return {c.title: c for c in result.checklist}


def test_load_plan(plan):
    assert plan.client_name == "Acme Roofing"
    assert plan.custom_fields[1] == {"name": "Insurance Claim", "type": "SINGLE_OPTIONS",
                                     "options": ["Yes", "No", "Not sure"], "placeholder": ""}
    assert plan.tags == ["storm-lead", "ai-booked"]
    assert plan.calendars == [{"name": "Free Roof Inspection"}, {"name": "Emergency Repair"}]
    assert plan.workflows == ["AI Appointment Setter", "Missed Call Text Back"]


def test_load_plan_json(tmp_path):
    p = tmp_path / "p.json"
    p.write_text(json.dumps({"client": "X", "tags": [{"name": "a"}], "custom_fields": ["Notes"]}))
    plan = load_plan(p)
    assert plan.tags == ["a"] and plan.custom_fields[0]["type"] == "TEXT"


@pytest.mark.parametrize("data,msg", [
    ([1, 2], "mapping"),
    ({"tags": "a,b"}, "must be a list"),
    ({"tags": [""]}, "empty"),
    ({"custom_fields": [{"type": "TEXT"}]}, "needs a name"),
    ({"custom_fields": [{"name": "A", "type": "BLOB"}]}, "not one of"),
    ({"custom_fields": [{"name": "A", "type": "single_options"}]}, "needs a list of options"),
    ({"custom_values": ["x"]}, "name and a value"),
    ({"pipelines": [{}]}, "needs a name"),
    ({"calendars": [{"x": 1}]}, "needs a name"),
    ({"manual_steps": [{}]}, "needs a title"),
])
def test_plan_validation(data, msg):
    with pytest.raises(PlanError, match=msg):
        parse_plan(data)


def test_load_plan_errors(tmp_path):
    with pytest.raises(PlanError, match="not found"):
        load_plan(tmp_path / "missing.yaml")
    bad = tmp_path / "bad.yaml"
    bad.write_text("tags: [a, b\n")
    with pytest.raises(PlanError, match="not valid YAML"):
        load_plan(bad)
    badj = tmp_path / "bad.json"
    badj.write_text("{")
    with pytest.raises(PlanError, match="not valid JSON"):
        load_plan(badj)


def test_first_run_creates_then_second_run_all_exists(client, fake, plan):
    first = run_onboarding(client, plan)
    assert by(first) == {
        ("custom field", "Roof Type"): EXISTS,
        ("custom field", "Insurance Claim"): CREATED,
        ("tag", "storm-lead"): EXISTS,
        ("tag", "ai-booked"): CREATED,
        ("custom value", "Business Phone"): EXISTS,
        ("custom value", "Booking Link"): CREATED,
    }
    posts = fake.writes
    assert len(posts) == 3
    cf_post = next(p for p in posts if p["path"].endswith("/customFields"))
    assert cf_post["body"] == {"name": "Insurance Claim", "dataType": "SINGLE_OPTIONS", "options": ["Yes", "No", "Not sure"]}
    n_writes = len(fake.writes)

    second = run_onboarding(client, plan)
    assert set(by(second).values()) == {EXISTS}
    assert len(fake.writes) == n_writes  # nothing new written
    assert not second.failed


def test_name_matching_ignores_case_and_spaces(client, fake):
    plan = parse_plan({"tags": ["  STORM-lead "], "custom_fields": [{"name": "roof   type"}]})
    res = run_onboarding(client, plan)
    assert set(by(res).values()) == {EXISTS}
    assert fake.writes == []


def test_dry_run_makes_no_writes(client, fake, plan):
    res = run_onboarding(client, plan, dry_run=True)
    assert fake.writes == []
    assert all(c["method"] == "GET" for c in fake.calls)
    assert by(res)[("custom field", "Insurance Claim")] == WOULD_CREATE
    assert by(res)[("tag", "storm-lead")] == EXISTS
    assert res.dry_run
    assert "DRY RUN" in onboard.render_markdown(res)


def test_checklist_verification(client, plan):
    res = run_onboarding(client, plan, dry_run=True)
    c = checks(res)
    assert c["Pipeline 'Roofing Jobs'"].status == VERIFIED
    assert c["Pipeline 'Insurance Claims'"].status == NOT_FOUND
    assert c["Calendar 'Free Roof Inspection'"].status == VERIFIED
    assert c["Calendar 'Emergency Repair'"].status == NOT_FOUND
    snap = c["Snapshot 'Roofing Snapshot v2' imported"]
    assert snap.status == PARTIAL and "Missed Call Text Back" in snap.detail and "published" in snap.detail
    assert c["AI agent setup (Roof Bot)"].status == MANUAL
    assert c["A2P 10DLC registration (US texting)"].status == MANUAL
    assert c["Phone number"].status == MANUAL
    assert c["Connect Google Business Profile"].how_to == "Settings > Integrations"
    assert len(res.open_items) == len(res.checklist) - 2


def test_checklist_partial_pipeline_and_workflow_states(client, fake):
    plan = parse_plan({
        "pipelines": [{"name": "Roofing Jobs", "stages": ["New Lead", "Signed Contract"]}],
        "workflows": ["AI Appointment Setter"],
        "a2p_registration": False,
    })
    c = checks(run_onboarding(client, plan))
    assert c["Pipeline 'Roofing Jobs'"].status == PARTIAL
    assert "Signed Contract" in c["Pipeline 'Roofing Jobs'"].detail
    assert c["Workflows in place"].status == VERIFIED
    assert not any("A2P" in t for t in c)

    none = checks(run_onboarding(client, parse_plan({"workflows": ["Nope"], "snapshot": "S"})))
    assert none["Snapshot 'S' imported"].status == NOT_FOUND

    nowf = checks(run_onboarding(client, parse_plan({"snapshot": "S"})))
    assert nowf["Snapshot 'S' imported"].status == MANUAL


def test_custom_value_difference_is_reported_not_overwritten(client, fake):
    plan = parse_plan({"custom_values": [{"name": "Business Phone", "value": "+1 999"}]})
    res = run_onboarding(client, plan)
    a = res.actions[0]
    assert a.status == EXISTS and "+1 999" in a.detail and "+1 555 0100" in a.detail
    assert fake.writes == []


def test_create_failure_is_reported(state):
    ghl = FakeGHL(state, "loc-123")
    ft = FakeTransport(fallback=ghl)
    ft.add("POST", "/locations/loc-123/tags", {"message": "tag limit reached"}, status=422)
    c = GHLClient("t", "loc-123", transport=ft, sleep=lambda s: None)
    res = run_onboarding(c, parse_plan({"tags": ["brand-new"]}))
    assert res.actions[0].status == FAILED and "tag limit reached" in res.actions[0].detail
    assert res.failed


def test_read_failure_marks_items(state):
    ghl = FakeGHL(state, "loc-123")
    ft = FakeTransport(fallback=ghl)
    for path, q in (("/locations/loc-123/customFields", None), ("/locations/loc-123/tags", None),
                    ("/locations/loc-123/customValues", None), ("/opportunities/pipelines", {"locationId": "loc-123"}),
                    ("/calendars/", {"locationId": "loc-123"}), ("/workflows/", {"locationId": "loc-123"})):
        ft.add("GET", path, {"message": "scope missing"}, status=403, query=q)
    c = GHLClient("t", "loc-123", transport=ft, sleep=lambda s: None)
    plan = parse_plan({"custom_fields": ["A"], "tags": ["b"], "custom_values": [{"name": "c", "value": "1"}],
                       "pipelines": ["P"], "calendars": ["C"], "workflows": ["W"]})
    res = run_onboarding(c, plan)
    assert {a.status for a in res.actions} == {FAILED}
    statuses = {c.title: c.status for c in res.checklist}
    assert statuses["Pipeline 'P'"] == UNCHECKED
    assert statuses["Calendar 'C'"] == UNCHECKED
    assert statuses["Workflows in place"] == UNCHECKED


def test_render_markdown_and_json(client, plan):
    res = run_onboarding(client, plan)
    md = onboard.render_markdown(res)
    assert "# Onboarding report: Acme Roofing" in md
    assert "| custom field | Insurance Claim | created |" in md
    assert "- [x] **Pipeline 'Roofing Jobs'**" in md
    assert "- [ ] **Calendar 'Emergency Repair'**: not found" in md
    assert "How: Calendars >" in md
    data = json.loads(onboard.render_json(res))
    assert data["location_id"] == "loc-123" and len(data["actions"]) == 6


def test_render_markdown_no_actions(client):
    md = onboard.render_markdown(run_onboarding(client, parse_plan({})))
    assert "Nothing to create" in md


def test_render_html_escapes_and_brands(client):
    plan = parse_plan({"client": "<b>Evil & Co</b>", "tags": ["<img src=x onerror=alert(1)>"]})
    res = run_onboarding(client, plan, dry_run=True)
    page = onboard.render_html(res, Branding("Agency <X>", "#ff0066", "https://cdn.example/logo.png"))
    assert "<b>Evil" not in page and "&lt;b&gt;Evil &amp; Co&lt;/b&gt;" in page
    assert "<img src=x" not in page
    assert "#ff0066" in page and 'src="https://cdn.example/logo.png"' in page
    assert "Prepared by Agency &lt;X&gt;" in page
    empty = onboard.render_html(run_onboarding(client, parse_plan({})))
    assert "Nothing to create" in empty and "Generated with ghl-agency-kit" in empty


def test_demo_flag_and_banner(client, plan):
    res = run_onboarding(client, plan)
    assert res.demo is True  # fake transport
    assert json.loads(onboard.render_json(res))["demo"] is True
    assert onboard.render_markdown(res).startswith("> **Demo data from the built-in fake GoHighLevel account")
    page = onboard.render_html(res)
    assert '<div class="demo"' in page and "Changes were applied." not in page
    assert "applied to the fake demo account only" in page
    res.demo = False
    assert "Demo data" not in onboard.render_html(res) and "Changes were applied." in onboard.render_markdown(res)
