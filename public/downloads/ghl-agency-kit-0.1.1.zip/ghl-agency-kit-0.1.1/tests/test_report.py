import json
from datetime import date, datetime, timezone

import pytest

from ghl_kit import report
from ghl_kit.branding import Branding, validate_color, validate_logo_url
from ghl_kit.report import (Period, build_highlights, build_report, change_phrase, compute_metrics, deltas,
                            fmt_money, fmt_pct, ratio, run_report, stage_breakdown)
from ghl_kit.timeutil import day_window, parse_day, parse_ts

UTC = timezone.utc
P = Period(date(2026, 10, 1), date(2026, 10, 7))


def window(p=P, tz=UTC):
    return day_window(p.start, p.end, tz)


def test_period():
    assert P.days == 7
    prev = P.previous()
    assert (prev.start, prev.end) == (date(2026, 9, 24), date(2026, 9, 30))
    assert P.label() == "Oct 1 - Oct 7, 2026"
    with pytest.raises(ValueError, match="before"):
        Period(date(2026, 10, 7), date(2026, 10, 1))


def test_parse_ts_variants():
    assert parse_ts("2026-10-01T09:00:00.000Z") == datetime(2026, 10, 1, 9, tzinfo=UTC)
    assert parse_ts("2026-10-01 09:00:00") == datetime(2026, 10, 1, 9, tzinfo=UTC)
    assert parse_ts("2026-10-01T04:00:00-05:00") == datetime(2026, 10, 1, 9, tzinfo=UTC)
    ms = int(datetime(2026, 10, 1, 9, tzinfo=UTC).timestamp() * 1000)
    assert parse_ts(ms) == parse_ts(str(ms)) == parse_ts(ms / 1000) == datetime(2026, 10, 1, 9, tzinfo=UTC)
    assert parse_ts(None) is None and parse_ts("") is None and parse_ts("garbage") is None and parse_ts(True) is None
    assert parse_ts(datetime(2026, 1, 1)) == datetime(2026, 1, 1, tzinfo=UTC)
    with pytest.raises(ValueError, match="YYYY-MM-DD"):
        parse_day("10/01/2026")


def test_compute_metrics_math(state):
    m = compute_metrics(state, *window())
    assert m["new_leads"] == 3  # c4 at Oct 8 00:00 is outside the window
    assert (m["appointments_booked"], m["showed"], m["no_show"], m["cancelled"]) == (4, 2, 1, 1)
    assert m["booking_rate"] == pytest.approx(4 / 3)
    assert m["show_rate"] == pytest.approx(2 / 3)
    assert m["opportunities_created"] == 3
    assert (m["won_count"], m["won_value"]) == (2, 1500.5)
    assert m["lost_count"] == 1  # o3 falls back to updatedAt
    assert (m["open_count"], m["pipeline_value"]) == (2, 5000)
    assert m["conversations"] == 3  # incl. the epoch-ms timestamp


def test_previous_period_metrics_and_deltas(state):
    prev = compute_metrics(state, *window(P.previous()))
    assert (prev["new_leads"], prev["appointments_booked"], prev["won_value"], prev["conversations"]) == (1, 1, 700, 1)
    cur = compute_metrics(state, *window())
    d = deltas(cur, prev)
    assert d["new_leads"] == {"current": 3, "previous": 1, "change": 2, "pct": 200.0}
    assert d["appointments_booked"]["pct"] == 300.0
    assert d["no_show"] == {"current": 1, "previous": 0, "change": 1, "pct": None}  # from zero: no percentage
    assert d["show_rate"]["previous"] == 1.0
    assert "pipeline_value" not in d  # a "right now" number, not comparable


def test_zero_data_is_safe():
    m = compute_metrics({}, *window())
    assert m["new_leads"] == 0 and m["booking_rate"] is None and m["show_rate"] is None
    assert m["won_value"] == 0 and m["pipeline_value"] == 0
    d = deltas(m, compute_metrics({}, *window(P.previous())))
    assert d["new_leads"]["pct"] is None and d["new_leads"]["change"] == 0
    assert d["show_rate"]["change"] is None
    hl = build_highlights(m, None, "last week")
    assert hl[0].startswith("No appointments were booked")
    assert hl[1] == "No new leads came in during this period."
    assert len(hl) == 2
    rep = build_report({}, P, compare_previous=True)
    html = report.render_html(rep)
    assert "n/a" in html and "No open opportunities right now." in html
    md = report.render_markdown(rep)
    assert "| Booking rate | n/a | n/a | - |" in md


def test_bad_values_ignored():
    data = {"opportunities": [{"status": "won", "monetaryValue": "abc", "createdAt": "2026-10-02T00:00:00Z"},
                              {"status": "open", "monetaryValue": None}],
            "events": [{"appointmentStatus": None, "startTime": "nonsense"}]}
    m = compute_metrics(data, *window())
    assert m["won_count"] == 1 and m["won_value"] == 0  # falls back to createdAt for status change
    assert m["appointments_booked"] == 0


def test_timezone_changes_day_boundaries(state):
    from zoneinfo import ZoneInfo
    chicago = ZoneInfo("America/Chicago")
    # c3 at Oct 7 23:59 UTC is Oct 7 18:59 in Chicago (inside); c4 at Oct 8 00:00 UTC is Oct 7 19:00 (inside too)
    m = compute_metrics(state, *window(tz=chicago))
    assert m["new_leads"] == 4


def test_ratio_and_formatting():
    assert ratio(1, 0) is None and ratio(1, 4) == 0.25
    assert fmt_money(1500.5) == "$1,500.50" and fmt_money(2000) == "$2,000" and fmt_money(-5, "€") == "-€5"
    assert fmt_pct(None) == "n/a" and fmt_pct(0.666) == "67%"


def test_change_phrase():
    assert change_phrase(14, 10, "last week") == "up 40% vs last week"
    assert change_phrase(5, 10, "last week") == "down 50% vs last week"
    assert change_phrase(3, 3, "last week") == "the same as last week"
    assert change_phrase(3, 0, "last week") == "up from 0 last week"
    assert change_phrase(3, None, "last week") == ""


def test_highlight_sentence_matches_spec():
    m = compute_metrics({}, *window())
    m.update(appointments_booked=14)
    prev = dict(m, appointments_booked=10)
    hl = build_highlights(m, prev, "last week")
    assert hl[0] == "Your AI assistant booked 14 appointments, up 40% vs last week."
    one = build_highlights(dict(m, appointments_booked=1), None, "last week", assistant="Sara")
    assert one[0] == "Sara booked 1 appointment."


def test_stage_breakdown_order_and_unknown(state):
    opps = state["opportunities"] + [{"status": "open", "pipelineStageId": "zzz", "monetaryValue": 10}]
    rows = stage_breakdown(opps, state["pipelines"])
    assert [r["stage"] for r in rows] == ["New Lead", "Quote Sent", "Unknown stage"]
    assert rows[0] == {"pipeline": "Roofing Jobs", "stage": "New Lead", "count": 1, "value": 2000.0}
    assert stage_breakdown([], []) == []


def test_run_report_end_to_end(client, fake):
    rep = run_report(client, P, compare_previous=True)
    assert rep["location"]["name"] == "Acme Roofing"
    assert rep["metrics"]["appointments_booked"] == 4
    assert rep["previous_metrics"]["appointments_booked"] == 1
    assert rep["previous_period"] == {"from": "2026-09-24", "to": "2026-09-30"}
    ev_calls = [c for c in fake.calls if c["path"] == "/calendars/events"]
    assert {c["query"]["calendarId"] for c in ev_calls} == {"cal1", "cal2"}
    lo = int(datetime(2026, 9, 24, tzinfo=UTC).timestamp() * 1000)
    assert all(int(c["query"]["startTime"]) == lo for c in ev_calls)
    assert rep["highlights"][0] == "Your AI assistant booked 4 appointments, up 300% vs last week."
    assert all(c["method"] == "GET" for c in fake.calls)


def test_run_report_survives_location_error(state):
    from ghl_kit.client import GHLClient
    from ghl_kit.fake import FakeGHL, FakeTransport
    ft = FakeTransport(fallback=FakeGHL(state, "loc-123")).add("GET", "/locations/loc-123", {"m": 1}, status=403)
    rep = run_report(GHLClient("t", "loc-123", transport=ft), P)
    assert rep["location"] == {"id": "loc-123"} and rep["deltas"] is None


def test_html_escaping_and_branding(state):
    rep = build_report(state, P, compare_previous=True, location={"name": "<script>x</script>"})
    page = report.render_html(rep, Branding("Agency & Co", "#123abc", "https://x.example/l.png?a=1&b=2",
                                            client_name='Joe\'s "Roofing" <b>'))
    assert "<script>x</script>" not in page
    assert "Joe&#x27;s &quot;Roofing&quot; &lt;b&gt;" in page
    assert "background:#123abc" in page
    assert 'src="https://x.example/l.png?a=1&amp;b=2"' in page
    assert "Prepared for Joe&#x27;s" in page and "by Agency &amp; Co." in page
    assert "▲ 200%" in page  # new leads 1 -> 3
    assert "▲ new" in page   # no-shows from 0
    # no-shows going up is bad news: red
    assert "#c62828" in page
    # location name used when client name not given, and escaped
    page2 = report.render_html(rep)
    assert "&lt;script&gt;x&lt;/script&gt;" in page2


def test_render_markdown_and_json(state):
    rep = build_report(state, P, compare_previous=True, location={"name": "Acme"})
    md = report.render_markdown(rep, Branding("My Agency"))
    assert md.startswith("# Acme: results Oct 1 - Oct 7, 2026")
    assert "Prepared by My Agency" in md
    assert "| New leads | 3 | 1 | ▲ 200% |" in md
    assert "| Won value | $1,500.50 | $700 | ▲ 114% |" in md
    assert "| Roofing Jobs | Quote Sent | 1 | $3,000 |" in md
    data = json.loads(report.render_json(rep))
    assert data["metrics"]["won_value"] == 1500.5
    assert data["deltas"]["new_leads"]["pct"] == 200.0
    md_single = report.render_markdown(build_report(state, P))
    assert "| New leads | 3 |" in md_single and "Previous" not in md_single


def test_delta_text_rates():
    assert report._delta_text("show_rate", {"change": 0.001, "pct": 1}) == ("no change", "flat")
    assert report._delta_text("show_rate", {"change": -0.01, "pct": -1}) == ("▼ 1 pt", "bad")
    assert report._delta_text("no_show", {"change": -2, "pct": -50.0}) == ("▼ 50%", "good")
    assert report._delta_text("new_leads", None) == ("", "")


def test_period_word_for_non_week():
    p = Period(date(2026, 10, 1), date(2026, 10, 3))
    rep = build_report({"contacts": [{"dateAdded": "2026-10-02T00:00:00Z"}]}, p, compare_previous=True)
    assert "the previous 3 days" in rep["highlights"][1]


@pytest.mark.parametrize("bad", ["red;background:url(x)", "#12", "url(x)", "1px solid", "#zzzzzz"])
def test_brand_color_validation(bad):
    with pytest.raises(ValueError, match="brand-color"):
        validate_color(bad)


def test_brand_color_accepts_hex_and_names():
    assert validate_color(" #0a7cff ") == "#0a7cff"
    assert validate_color("teal") == "teal"
    assert Branding(brand_color="").brand_color == "#2a78d6"


def test_logo_url_validation():
    assert validate_logo_url("") == ""
    assert validate_logo_url("data:image/png;base64,xx").startswith("data:")
    with pytest.raises(ValueError, match="logo-url"):
        validate_logo_url("javascript:alert(1)")
    with pytest.raises(ValueError):
        Branding(logo_url="ftp://x")


def test_demo_flag_from_client(client, state):
    rep = report.run_report(client, P)
    assert rep["demo"] is True  # fake transport
    assert "Demo data from the built-in fake GoHighLevel account" in report.render_html(rep)
    assert report.render_markdown(rep).startswith("> **Demo data from the built-in fake GoHighLevel account")
    assert json.loads(report.render_json(rep))["demo"] is True
    real = build_report(state, P)  # no "demo" key: rendered as real data
    assert "Demo data" not in report.render_html(real) and "Demo data" not in report.render_markdown(real)
    assert json.loads(report.render_json(real))["demo"] is False
