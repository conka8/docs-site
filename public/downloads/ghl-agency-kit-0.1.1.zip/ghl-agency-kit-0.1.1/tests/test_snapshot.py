import copy
import json

import pytest

from ghl_kit import snapshot
from ghl_kit.snapshot import diff_items, diff_snapshots, export_snapshot, has_differences, load_snapshot


@pytest.fixture
def snap(client):
    return export_snapshot(client)


def test_export_structure(snap, fake):
    assert snap["meta"]["location_id"] == "loc-123"
    assert snap["meta"]["location_name"] == "Acme Roofing"
    assert snap["meta"]["tool"] == "ghl-agency-kit 0.1.1"
    assert [s["name"] for s in snap["pipelines"][0]["stages"]] == ["New Lead", "Inspection Booked", "Quote Sent", "Won"]
    assert snap["custom_fields"] == [{"id": "cf1", "name": "Roof Type", "fieldKey": "contact.roof_type", "dataType": "TEXT"}]
    assert snap["custom_values"][0]["value"] == "+1 555 0100"
    assert snap["calendars"][0] == {"id": "cal1", "name": "Free Roof Inspection", "calendarType": "event", "isActive": True}
    assert snap["workflows"][1] == {"id": "w2", "name": "Missed Call Text Back", "status": "draft"}
    assert snap["tags"] == [{"id": "t1", "name": "storm-lead"}]
    assert fake.writes == []
    json.dumps(snap)  # serialisable


def test_export_stage_order_by_position(client, fake):
    fake.data["pipelines"][0]["stages"].reverse()
    s = export_snapshot(client)
    assert [x["position"] for x in s["pipelines"][0]["stages"]] == [0, 1, 2, 3]


def test_no_differences(snap):
    d = diff_snapshots(snap, copy.deepcopy(snap))
    assert not has_differences(d)
    assert snapshot.render_text(d).endswith("\n\nNo differences.\n")  # after the demo notice
    real = diff_snapshots({"tags": []}, {"tags": []})
    assert snapshot.render_text(real) == "No differences.\n"
    assert "Demo data" not in snapshot.render_markdown(real) and json.loads(snapshot.render_json(real))["demo"] is False
    assert "No differences." in snapshot.render_markdown(d)
    assert json.loads(snapshot.render_json(d))["has_differences"] is False


def test_adds_removes_renames_and_stage_changes(snap):
    b = copy.deepcopy(snap)
    b["tags"].append({"id": "t2", "name": "vip"})
    b["custom_fields"] = []
    b["workflows"][1]["status"] = "published"
    b["calendars"][0]["name"] = "Roof Inspection (Free)"  # rename, same id
    stages = b["pipelines"][0]["stages"]
    stages[1]["name"] = "Inspection Scheduled"           # stage rename
    stages.append({"id": "s5", "name": "Paid", "position": 4})  # stage added
    del stages[2]                                          # stage removed (Quote Sent)
    d = diff_snapshots(snap, b)
    r = d["resources"]
    assert r["tags"]["added"] == [{"id": "t2", "name": "vip"}]
    assert r["custom_fields"]["removed"] == [{"id": "cf1", "name": "Roof Type"}]
    assert r["workflows"]["changed"][0]["changes"] == [{"field": "status", "from": "draft", "to": "published"}]
    cal = r["calendars"]["changed"][0]
    assert cal["matched_by"] == "id"
    assert cal["changes"] == [{"field": "name", "from": "Free Roof Inspection", "to": "Roof Inspection (Free)"}]
    pl = r["pipelines"]["changed"][0]
    assert pl["changes"] == []
    assert pl["stages"]["added"] == [{"id": "s5", "name": "Paid"}]
    assert pl["stages"]["removed"] == [{"id": "s3", "name": "Quote Sent"}]
    assert pl["stages"]["changed"][0]["changes"] == [{"field": "name", "from": "Inspection Booked", "to": "Inspection Scheduled"}]
    assert has_differences(d)
    counts = snapshot.summary_counts(d)
    assert counts["tags"] == {"added": 1, "removed": 0, "changed": 0}

    text = snapshot.render_text(d)
    assert "Tags:\n  + vip" in text
    assert "  - Roof Type" in text
    assert "stage added: Paid" in text and "stage removed: Quote Sent" in text
    assert "stage 'Inspection Scheduled' name: 'Inspection Booked' -> 'Inspection Scheduled'" in text
    assert "status: 'draft' -> 'published'" in text
    assert text.strip().endswith("1 added, 1 removed, 3 changed.")

    md = snapshot.render_markdown(d)
    assert "| Tags | 1 | 0 | 0 |" in md and "- Added: **vip**" in md and "  - stage added: Paid" in md
    js = json.loads(snapshot.render_json(d))
    assert js["summary"]["pipelines"]["changed"] == 1


def test_stage_reorder_detected():
    a = [{"id": "p", "name": "P", "stages": [{"id": "1", "name": "A", "position": 0}, {"id": "2", "name": "B", "position": 1}]}]
    b = [{"id": "p", "name": "P", "stages": [{"id": "1", "name": "A", "position": 1}, {"id": "2", "name": "B", "position": 0}]}]
    d = diff_items(a, b, ("name",), {"stages": ("name", "position")})
    assert len(d["changed"][0]["stages"]["changed"]) == 2


def test_name_fallback_when_ids_differ():
    # e.g. comparing a client account with the agency's template account
    a = [{"id": "x1", "name": "Hot Lead"}, {"id": "x2", "name": "Cold"}]
    b = [{"id": "y1", "name": "hot  lead"}, {"id": "y9", "name": "Warm"}]
    d = diff_items(a, b, ("name",))
    assert d["changed"] == []  # matched by name; name compare skipped for name matches
    assert d["removed"] == [{"id": "x2", "name": "Cold"}]
    assert d["added"] == [{"id": "y9", "name": "Warm"}]


def test_items_without_ids_or_names():
    d = diff_items([{"name": None}], [{"id": None, "name": None}], ("name",))
    assert len(d["removed"]) == 1 and len(d["added"]) == 1
    assert d["removed"][0]["name"] == "?"


def test_load_snapshot_errors(tmp_path, snap):
    with pytest.raises(FileNotFoundError):
        load_snapshot(tmp_path / "nope.json")
    bad = tmp_path / "bad.json"
    bad.write_text("{oops")
    with pytest.raises(ValueError, match="not a valid JSON"):
        load_snapshot(bad)
    other = tmp_path / "other.json"
    other.write_text('{"hello": 1}')
    with pytest.raises(ValueError, match="does not look like"):
        load_snapshot(other)
    good = tmp_path / "good.json"
    good.write_text(json.dumps(snap))
    assert load_snapshot(good)["tags"] == snap["tags"]
