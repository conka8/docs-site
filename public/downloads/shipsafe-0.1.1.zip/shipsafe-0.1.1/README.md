# shipsafe

**Run this before you launch.** shipsafe checks apps built with Lovable, Bolt, Cursor or Claude Code
(Next.js / Vite + Supabase / Firebase + OpenAI / Anthropic, on Vercel / Netlify) for the mistakes that
hurt beginners: leaked API keys, database tables anyone can read, open Firebase rules, AI endpoints
anyone can use on your bill, and admin pages with no login. Every problem comes with a plain-English
explanation and a **fix prompt** you paste straight back into your AI coding tool.

Free and open source (MIT). No account, no API key, nothing is uploaded: the folder scan runs fully
on your computer.

## Install

You need Python 3.10 or newer.

From inside the downloaded `shipsafe` folder:

```bash
pipx install .                   # or: python3 -m pip install .   (Windows: py -m pip install .)
```

shipsafe is not on PyPI. Install it from this folder, not with `pip install shipsafe`.

Optional: `pip install pyyaml` if you want full YAML support in `shipsafe.yml` (a simple built-in reader
is used otherwise).

## Quickstart

First try it on the demo app (a deliberately leaky app with fake keys), from inside the `shipsafe` folder:

```bash
python3 examples/make_demo_app.py ./demo          # Windows: py examples/make_demo_app.py ./demo
shipsafe scan ./demo/leaky_next
```

Then check your own app:

```bash
# 1. Check your project folder
shipsafe scan ./my-app

# 2. Make a shareable HTML report (open it in a browser; "Print > Save as PDF" for a PDF)
shipsafe scan ./my-app --format html -o report.html

# 3. Check the live site (only sites you own)
shipsafe url https://my-app.vercel.app

# See every check
shipsafe rules
```

Using Claude Code? Copy `skills/shipsafe-audit/` into `.claude/skills/` and say *"audit my app before launch"*.
Claude runs shipsafe and walks you through each fix.

## Example output

```text
shipsafe 0.1.0 - launch safety check
Target: ./my-app
Grade:  F  (score 0/100)  Do not launch yet: fix the critical items first.
Found:  3 critical, 4 high, 2 medium, 1 low, 1 info

1. [CRITICAL] Secret key in a public environment variable: NEXT_PUBLIC_OPENAI_API_KEY  (SS-PUBLIC-ENV-SECRET)
   Where: .env.local:4
   Found: NEXT_PUBLIC_OPENAI_API_KEY=sk-p…
   Why it matters: Variables starting with NEXT_PUBLIC_, VITE_, REACT_APP_ or EXPO_PUBLIC_ are
   copied into the JavaScript every visitor downloads, so this secret is visible to the whole internet.
   Fix prompt (copy the next line and paste it into your AI coding tool):
     The environment variable NEXT_PUBLIC_OPENAI_API_KEY (in .env.local:4) holds a secret, but its prefix makes it public in the browser. Please rename it without the public prefix, ...

2. [HIGH] Database table without Row Level Security: messages  (SS-RLS-MISSING)
   Where: supabase/migrations/20240101000000_init.sql:12
   ...
```

Secrets are **never** printed in full: reports show the first 4 characters followed by `…`. Quoted values
next to names like `apiKey`, `token`, `secret`, `password` or `auth` are masked the same way in the `Found:` lines.

Every report ends with: *shipsafe runs a fixed set of checks for common launch mistakes. A clean result
is not a full security audit or proof that the app is secure.*

## Options

| Option | What it does |
|---|---|
| `--format text\|json\|md\|html` | Report format (default `text`). |
| `-o FILE` | Write the report to a file. |
| `--fail-on critical\|high\|medium\|low\|never` | Exit code 1 when a finding this bad or worse exists (default `critical`). Useful in CI. |
| `--ignore-rule ID` | Hide a rule, repeatable (e.g. `--ignore-rule SS-XSS-INNERHTML`). |
| `--brand-name`, `--brand-color`, `--logo-url` | White-label the HTML report (your community name, color, logo). |
| `--include-build` | `scan` only: also scan `dist/`, `build/`, `.next/`, `out/`. |
| `--probe-supabase` | `url` only: test which Supabase tables can be read with the public key (see below). |
| `--max-scripts N`, `--max-script-kb N`, `--timeout S` | `url` only: limits for downloading JavaScript. |
| `--config FILE` | Settings file (default: `shipsafe.yml` in the scanned folder). |

Exit codes: `0` = OK, `1` = findings at or above `--fail-on`, `2` = error (bad folder, folder with no source
files, site unreachable...).

**Silencing a false alarm** on one line:

```ts
const demo = "sk_test_..."; // shipsafe-ignore                      (all rules on this line)
const demo = "sk_test_..."; // shipsafe-ignore SS-SECRET-STRIPE-TEST (one rule)
// shipsafe-ignore-next-line SS-XSS-INNERHTML
```

`-- shipsafe-ignore` works in SQL, `# shipsafe-ignore` in env/YAML files, and `shipsafe-ignore-file` anywhere
in a file silences file-level findings (like an admin page with no login check).

**`shipsafe.yml`** (optional, in the project root):

```yaml
fail_on: high
include_build: false
ignore_rules:
  - SS-XSS-INNERHTML
ignore_paths:
  - "scripts/*"
brand_name: Vibe Coding Academy
brand_color: "#7c3aed"
```

**CI:** copy `examples/.github/workflows/shipsafe.yml` into your repo. It fails the build on high/critical
findings and attaches the HTML report.

**Demo for a video:** `python3 examples/make_demo_app.py ./demo` creates a deliberately leaky app with fake
keys; then run `shipsafe scan ./demo/leaky_next --format html -o report.html`. The script uses the fake
apps in `tests/fixtures`, so run it from a full copy of the shipsafe folder.

## What it checks

`shipsafe scan <folder>` skips `node_modules`, `.git`, build folders (unless `--include-build`), lock files,
binary files and files over 2 MB.

| Rule | Severity | Problem |
|---|---|---|
| `SS-SECRET-OPENAI` | critical | OpenAI key (`sk-`, `sk-proj-`) in code |
| `SS-SECRET-ANTHROPIC` | critical | Anthropic key (`sk-ant-`) in code |
| `SS-SECRET-STRIPE-LIVE` | critical | Stripe `sk_live_` / `rk_live_` key |
| `SS-SECRET-STRIPE-TEST` | low | Stripe `sk_test_` key |
| `SS-SECRET-AWS` | critical | AWS access key (`AKIA…`) |
| `SS-SECRET-GITHUB` | critical | GitHub token (`ghp_`, `github_pat_`) |
| `SS-SECRET-GOOGLE` | medium (low in Firebase config) | Google API key (`AIza…`) |
| `SS-SECRET-SLACK` | high | Slack token (`xoxb-`/`xoxp-`) or webhook |
| `SS-SECRET-SENDGRID` | critical | SendGrid key (`SG.`) |
| `SS-SECRET-TWILIO` | high | Twilio API key / auth token |
| `SS-SECRET-PRIVATE-KEY` | critical | `-----BEGIN … PRIVATE KEY-----` block |
| `SS-SECRET-PASSWORD` | low | `password = "…"`-style hard-coded value |
| `SS-SECRET-CLIENT-APIKEY` | medium (high next to an AI SDK) | `apiKey: "…"` with a long literal value in browser code |
| `SS-SUPABASE-SERVICE-ROLE` | critical | Supabase `service_role` JWT (decoded, not verified) or `sb_secret_` key |
| `SS-SUPABASE-ANON-KEY` | info | Supabase anon key: public by design, shown for context only |
| `SS-PUBLIC-ENV-SECRET` | critical | A secret in a `NEXT_PUBLIC_` / `VITE_` / `REACT_APP_` / `EXPO_PUBLIC_` variable |
| `SS-PUBLIC-ENV-SECRET-NAME` | high | Browser code reads e.g. `import.meta.env.VITE_OPENAI_API_KEY` |
| `SS-ENV-NOT-IGNORED` | high | `.env`, `.env.local`, `.env.production`… not in `.gitignore` |
| `SS-GITIGNORE-MISSING` | medium | No `.gitignore` |
| `SS-RLS-MISSING` | high | `create table` with no `enable row level security` (any `.sql` file) |
| `SS-RLS-NO-POLICY` | medium | RLS on but no `create policy` (locks everyone out) |
| `SS-RLS-OPEN-POLICY` | high | `using (true)` / `with check (true)` on insert, update, delete or all |
| `SS-STORAGE-PUBLIC-BUCKET` | medium | Public bucket in SQL or `createBucket(…, { public: true })` |
| `SS-AI-ENDPOINT-NO-AUTH` | high | Server route calling OpenAI/Anthropic/Gemini with no login check |
| `SS-AI-ENDPOINT-NO-RATELIMIT` | medium | Same, with no rate limiting (cost blow-up) |
| `SS-AI-CALL-FROM-BROWSER` | high | AI API called from browser code / `dangerouslyAllowBrowser` |
| `SS-ADMIN-NO-AUTH` | high | Admin page/route with no auth check (layouts and `middleware.ts` count) |
| `SS-FIREBASE-OPEN-RULES` | critical | Firebase rules allowing writes `if true` |
| `SS-FIREBASE-TEST-MODE` | high | Firebase test-mode rule `if request.time < …` |
| `SS-FIREBASE-PUBLIC-READ` | medium | Firebase rules allowing reads `if true` |
| `SS-CORS-WILDCARD-CREDENTIALS` | medium | `Access-Control-Allow-Origin: *` together with credentials |
| `SS-XSS-INNERHTML` | low | `dangerouslySetInnerHTML` / `innerHTML =` / `v-html` with a non-literal value |

Hard-coded secrets in server-only code (API routes, edge functions) are reported one level lower than in
browser code. Secrets in test files are always `low`. A git-ignored `.env.local` holding server secrets
is fine and is not reported.

`shipsafe url <https://app>` (outside-in check of a deployed app) reports:

| Rule | Severity | Problem |
|---|---|---|
| all secret / JWT rules above | as above | Keys found in the homepage or its same-origin JavaScript files (max 20 files, 2 MB each) |
| `SS-EXPOSED-FILE` | critical | `/.env`, `/.env.local`, `/.env.production` or `/.git/config` downloadable (single-page-app fallbacks are recognised and ignored) |
| `SS-HEADER-CSP` / `SS-HEADER-FRAME` / `SS-HEADER-HSTS` | low | Missing Content-Security-Policy, X-Frame-Options/frame-ancestors, Strict-Transport-Security (https only) |
| `SS-SUPABASE-TABLE-READABLE` | high | With `--probe-supabase`: a table returned rows using only the public anon key |

### Only scan apps you own

`shipsafe url` sends ordinary GET requests, like a browser. `--probe-supabase` goes further: it lists the
tables of the Supabase project found in the site's code (`GET {supabase}/rest/v1/` with the anon key) and
tries `GET /rest/v1/<table>?select=*&limit=1` on each. It reports column names, never row values, but this
is exactly what an attacker would do. **Only run it on apps you own or have written permission to test.**
It is off by default.

**Verify against current docs:** the Supabase REST paths, the anon/`service_role` JWT `role` claim and the
`sb_publishable_` / `sb_secret_` key prefixes are Supabase behaviour that can change. They live in one
place (`src/shipsafe/url_scan.py` constants and `src/shipsafe/patterns.py`). Newer Supabase projects may
refuse the table listing for the anon key; shipsafe then falls back to table names found in your code
(`.from("table")`).

## Limits (read this)

- It's a fast pattern-based checklist, not a full security audit. A clean report doesn't prove an app is
  safe. A finding can also be a false alarm: read the "why" and decide.
- Auth / rate-limit detection is a keyword heuristic (`getUser`, `auth(`, `clerk`, `ratelimit`, `upstash`…).
  A route that imports a rate limiter but never calls it will pass; a custom auth helper with an
  unusual name will be flagged.
- `middleware.ts` with an auth call is assumed to protect all Next.js routes, even if its `matcher`
  excludes some.
- SQL parsing is regex-based: tables created inside functions, `DO` blocks or by dashboard clicks (not in
  migration files) are not seen. Use `--probe-supabase` on the live app for the real picture.
- URL mode only reads scripts linked from the homepage; lazily loaded chunks and other pages aren't fetched.
- Generic password detection is deliberately conservative and only reports `low`.

## Development

```bash
cd shipsafe && ../.venv/bin/python -m pytest -q
```

Tests never touch the network: URL mode is tested with a fake transport and a local `http.server` on
127.0.0.1. Fake keys are generated at test time so the repo holds no secret-looking strings.
