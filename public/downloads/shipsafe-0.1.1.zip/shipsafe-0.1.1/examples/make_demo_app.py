"""Create a deliberately leaky demo app (with FAKE keys) to show shipsafe in a screen recording.

    python3 examples/make_demo_app.py ./demo         # writes ./demo/leaky_next
    shipsafe scan ./demo/leaky_next --format html -o report.html

Other demo apps: clean_next, firebase_app, vite_app (pass the name as 2nd argument).
"""

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT / "src"), str(ROOT / "tests")]


def main() -> int:
    if len(sys.argv) < 2:
        print(__doc__)
        return 2
    # The demo apps are the test fixtures (tests/fixtures) filled with fake keys by tests/fakes.py,
    # so this script needs the whole shipsafe folder, including tests/.
    if not (ROOT / "tests" / "fakes.py").is_file():
        print(f"Can't find {ROOT / 'tests'}. Run this from a full copy of the shipsafe folder "
              "(the demo apps live in tests/fixtures).", file=sys.stderr)
        return 2
    from fakes import FIXTURES, materialize

    name = sys.argv[2] if len(sys.argv) > 2 else "leaky_next"
    if not (FIXTURES / name).is_dir():
        names = ", ".join(sorted(p.name for p in FIXTURES.iterdir() if p.is_dir()))
        print(f"Unknown demo app {name!r}. Choose one of: {names}", file=sys.stderr)
        return 2
    path = materialize(name, Path(sys.argv[1]))
    print(f"Demo app written to {path} (all keys in it are fake)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
