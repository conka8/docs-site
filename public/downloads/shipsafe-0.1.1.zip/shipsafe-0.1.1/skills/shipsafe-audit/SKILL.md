---
name: shipsafe-audit
description: Runs the shipsafe launch safety check on the current project (leaked API keys, Supabase tables without Row Level Security, open Firebase rules, AI endpoints without login or rate limits, unprotected admin pages) and walks the user through fixing each problem in plain English. Use before deploying or launching an app, when the user asks "is my app safe to launch", "audit my app", "check for leaked keys", or after adding Supabase, Firebase, Stripe or OpenAI/Anthropic code.
---

# shipsafe audit: check the app before launch

The user is usually not a developer. Speak plainly, one problem at a time, and never print a full
secret key back to them.

## 1. Run the scan

From the project root:

```bash
shipsafe scan . --format json -o shipsafe-report.json
```

If `shipsafe` is not installed, install it from the downloaded shipsafe folder (the one that holds
`pyproject.toml`; ask the user where it is if you can't find it):

```bash
python3 -m pip install <path-to-shipsafe-folder>     # Windows: py -m pip install <path-to-shipsafe-folder>
```

shipsafe is not published on PyPI. Never run `pip install shipsafe` or `pipx install shipsafe`: a package
with that name on PyPI would be someone else's code. If installing from the folder is not possible, tell
the user and stop.

If shipsafe says "Nothing was scanned", you are in the wrong folder: run it from the project root.

Exit code 1 means critical problems were found. That is expected, not a crash. Exit code 2 is a
real error: show the message.

Also make an HTML report the user can open and keep:

```bash
shipsafe scan . --format html -o shipsafe-report.html
```

## 2. Explain the result

Read `shipsafe-report.json`. Tell the user:

- the grade (A to F) and the number of critical / high / medium / low findings;
- that shipsafe only runs a fixed set of checks: a good grade is not a full security audit;
- in one sentence, what that means for launching ("Don't launch yet, two keys are exposed").

Then go through findings **in the order given** (most severe first). For each one:

1. Say the title and the `why` text in your own words, one or two sentences.
2. Say where it is (`location`). Show only the redacted `evidence`; never open the file to show the full key.
3. Ask: "Want me to fix this now?"
4. If yes, follow the finding's `fix_prompt` as your instructions and make the change.
   Keep changes small and focused, and don't refactor unrelated code.
5. For leaked keys, explain that removing the key from code is not enough: the user must
   **rotate** it (create a new key, delete the old one) in the provider dashboard. Give the exact
   menu path from the fix prompt. You cannot do this step for them.

Skip `info` findings unless the user asks. They are informational (for example: the Supabase anon key is
public by design).

## 3. Re-run until clean

After fixing, run `shipsafe scan .` again and repeat until there are no critical or high findings.
If a finding is a false positive, add an inline comment on that line instead of deleting the check:

```ts
const demoKey = "..."; // shipsafe-ignore SS-SECRET-STRIPE-TEST
```

or pass `--ignore-rule RULE-ID` (also possible in `shipsafe.yml`). Say what you ignored and why.

## 4. Optional: check the live site

If the app is already deployed **and the user owns it**, run:

```bash
shipsafe url https://their-app.example.com
```

This checks the public JavaScript for keys, looks for exposed `/.env` or `/.git/config`, and
checks security headers. Only add `--probe-supabase` when the user confirms it is their own app;
it tries to read each Supabase table with the public key, which is what an attacker would do.

## Rules

- Never paste full secrets into the chat, commit messages or files.
- Don't commit or push for the user unless they ask.
- Don't disable Row Level Security or security rules to "make things work".
- Finish with a short summary: what was fixed, what the user still has to do by hand (rotating keys,
  setting environment variables in Vercel/Netlify/Supabase), and the new grade.
