"""shipsafe: a plain-English "run this before you launch" safety check for vibe-coded apps."""

__version__ = "0.1.1"

from .findings import Finding, ScanResult, redact  # noqa: E402
from .local_scan import ScanError, scan_directory  # noqa: E402
from .url_scan import scan_url  # noqa: E402

__all__ = ["__version__", "Finding", "ScanResult", "ScanError", "redact", "scan_directory", "scan_url"]
