"""Command line: ``shipsafe scan <dir>``, ``shipsafe url <https://app>``, ``shipsafe rules``."""

from __future__ import annotations

import argparse
import os
import sys

from . import __version__
from .config import ConfigError, find_config, load_config
from .findings import FAIL_ON_CHOICES
from .local_scan import ScanError, scan_directory
from .report import FORMATS, is_valid_color, is_valid_logo_url, render, score_and_grade
from .rules import RULES
from .transport import Transport, make_urllib_transport
from .url_scan import MAX_SCRIPT_BYTES, MAX_SCRIPTS, scan_url

EXIT_OK, EXIT_FINDINGS, EXIT_ERROR = 0, 1, 2


def _output_args(p: argparse.ArgumentParser) -> None:
    g = p.add_argument_group("output")
    g.add_argument("--format", "-f", choices=FORMATS, default=None, help="report format (default: text)")
    g.add_argument("-o", "--output", metavar="FILE", help="write the report to FILE instead of the screen")
    g.add_argument("--fail-on", choices=FAIL_ON_CHOICES, default=None,
                   help="exit with code 1 when a finding this severe (or worse) exists (default: critical)")
    g.add_argument("--ignore-rule", action="append", default=[], metavar="ID",
                   help="hide findings for this rule id (repeatable), e.g. --ignore-rule SS-XSS-INNERHTML")
    g.add_argument("--brand-name", default=None, help="your name or community name on the HTML report")
    g.add_argument("--brand-color", default=None, help="header color for the HTML report, e.g. '#ff6600'")
    g.add_argument("--logo-url", default=None, help="logo image URL for the HTML report")
    g.add_argument("--config", metavar="FILE", help="settings file (default: shipsafe.yml in the scanned folder)")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="shipsafe",
        description="Run this before you launch: finds leaked keys, open databases and unprotected AI "
        "endpoints in vibe-coded apps, and gives you a fix prompt for each problem.",
    )
    parser.add_argument("--version", action="version", version=f"shipsafe {__version__}")
    sub = parser.add_subparsers(dest="command", metavar="COMMAND")

    scan = sub.add_parser("scan", help="check a project folder on your computer")
    scan.add_argument("directory", nargs="?", default=".", help="project folder (default: current folder)")
    scan.add_argument("--include-build", action="store_true",
                      help="also scan build output folders (dist, build, .next, out)")
    _output_args(scan)

    url = sub.add_parser("url", help="check a live website (only sites you own)")
    url.add_argument("url", help="full address, e.g. https://myapp.vercel.app")
    url.add_argument("--probe-supabase", action="store_true",
                     help="try reading each Supabase table with the public key (only on apps you own)")
    url.add_argument("--max-scripts", type=int, default=MAX_SCRIPTS, help=f"max scripts to download ({MAX_SCRIPTS})")
    url.add_argument("--max-script-kb", type=int, default=MAX_SCRIPT_BYTES // 1024,
                     help=f"max size per script in KB ({MAX_SCRIPT_BYTES // 1024})")
    url.add_argument("--timeout", type=float, default=15.0, help="seconds to wait per request (15)")
    _output_args(url)

    sub.add_parser("rules", help="list every check shipsafe runs")
    return parser


def _merge_config(args: argparse.Namespace, config: dict) -> dict:
    return {
        "fmt": args.format or "text",
        "fail_on": args.fail_on or config.get("fail_on") or "critical",
        "ignore_rules": list(config.get("ignore_rules", [])) + list(args.ignore_rule),
        "ignore_paths": list(config.get("ignore_paths", [])),
        "brand_name": args.brand_name if args.brand_name is not None else (config.get("brand_name") or ""),
        "brand_color": args.brand_color if args.brand_color is not None else (config.get("brand_color") or ""),
        "logo_url": args.logo_url if args.logo_url is not None else (config.get("logo_url") or ""),
    }


def _err(msg: str) -> int:
    print(f"shipsafe: error: {msg}", file=sys.stderr)
    return EXIT_ERROR


def main(argv: list[str] | None = None, transport: Transport | None = None) -> int:
    parser = build_parser()
    try:
        args = parser.parse_args(argv)
    except SystemExit as exc:  # argparse exits on --help / bad arguments
        return int(exc.code or 0)
    if not args.command:
        parser.print_help()
        return EXIT_ERROR

    if args.command == "rules":
        for rule in RULES.values():
            print(f"{rule.id:<30} {rule.severity:<8} {rule.title}")
        return EXIT_OK

    config: dict = {}
    config_path = args.config
    if not config_path and args.command == "scan" and os.path.isdir(args.directory):
        config_path = find_config(args.directory)
    if config_path:
        try:
            config = load_config(config_path)
        except (OSError, ConfigError) as exc:
            return _err(f"could not read config: {exc}")
    opts = _merge_config(args, config)
    if opts["fail_on"] not in FAIL_ON_CHOICES:
        return _err(f"fail_on must be one of {', '.join(FAIL_ON_CHOICES)}")
    unknown = [r for r in opts["ignore_rules"] if r.upper() not in RULES]
    if unknown:
        return _err(f"unknown rule id(s): {', '.join(unknown)}. Run 'shipsafe rules' to see them.")
    if opts["brand_color"] and not is_valid_color(opts["brand_color"]):
        return _err("--brand-color must be a hex color like #ff6600 or a color name like teal")
    if opts["logo_url"] and not is_valid_logo_url(opts["logo_url"]):
        return _err("--logo-url must start with https://, http:// or data:image/")

    try:
        if args.command == "scan":
            include_build = args.include_build or bool(config.get("include_build"))
            result = scan_directory(args.directory, include_build=include_build,
                                    ignore_rules=opts["ignore_rules"], ignore_paths=opts["ignore_paths"])
        else:
            if args.max_scripts < 0 or args.max_script_kb <= 0 or args.timeout <= 0:
                return _err("--max-scripts, --max-script-kb and --timeout must be positive")
            t = transport or make_urllib_transport(timeout=args.timeout)
            result = scan_url(args.url, transport=t, probe_supabase_tables=args.probe_supabase,
                              max_scripts=args.max_scripts, max_script_bytes=args.max_script_kb * 1024,
                              ignore_rules=opts["ignore_rules"])
    except ScanError as exc:
        return _err(str(exc))
    if args.command == "scan" and result.files_scanned == 0:
        return _err(f"Nothing was scanned in {args.directory}: no source files found. Check the folder path.")

    output = render(result, opts["fmt"], **(
        {"brand_name": opts["brand_name"], "brand_color": opts["brand_color"], "logo_url": opts["logo_url"]}
        if opts["fmt"] == "html" else {}
    ))
    if args.output:
        try:
            with open(args.output, "w", encoding="utf-8") as fh:
                fh.write(output)
        except OSError as exc:
            return _err(f"could not write {args.output}: {exc}")
        score, grade = score_and_grade(result)
        counts = result.counts()
        print(f"Report written to {args.output}: grade {grade} ({score}/100), "
              f"{counts['critical']} critical, {counts['high']} high, {counts['medium']} medium, {counts['low']} low.")
    else:
        sys.stdout.write(output)
    return EXIT_FINDINGS if result.should_fail(opts["fail_on"]) else EXIT_OK


if __name__ == "__main__":  # pragma: no cover
    sys.exit(main())
