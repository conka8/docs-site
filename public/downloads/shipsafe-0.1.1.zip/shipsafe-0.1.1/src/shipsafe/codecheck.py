"""Source-code checks: AI endpoints, admin routes, Firebase rules, CORS and raw HTML."""

from __future__ import annotations

import posixpath
import re

from .findings import Finding
from .patterns import (
    PUBLIC_REF_RE, find_client_api_keys, is_secret_env_name, line_of, line_starts, public_prefix, scrub,
)
from .rules import make_finding

CODE_EXTS = {".ts", ".tsx", ".js", ".jsx", ".mjs", ".cjs", ".vue", ".svelte", ".astro"}
BACKEND_EXTS = {".py", ".rb", ".go", ".php", ".java", ".rs", ".cs", ".ex", ".exs", ".kt"}

SERVER_PATH_RE = re.compile(
    r"/(?:api|server|backend|functions|lambda|lambdas|scripts|migrations|edge-functions)/"
    r"|/route\.[cm]?[jt]sx?$|/middleware\.[jt]s$|\.server\.[jt]sx?$|/server\.[cm]?[jt]s$|/actions\.[jt]s$"
)
CLIENT_PATH_RE = re.compile(
    r"/(?:components|public|static|hooks|app|pages|src|assets|dist|build|out|views|screens|\.next/static)/"
)
TEST_PATH_RE = re.compile(
    r"(?:^|/)(?:__tests__|tests?|spec|specs|__mocks__|e2e|cypress|playwright|mocks?)/"
    r"|\.(?:test|spec)\.[a-z]+$|(?:^|/)test_[^/]+\.py$"
)
USE_CLIENT_RE = re.compile(r"""\A(?:\s|//[^\n]*\n|/\*.*?\*/)*["']use client["']""", re.S)
USE_SERVER_RE = re.compile(r"""\A(?:\s|//[^\n]*\n|/\*.*?\*/)*["']use server["']|["']server-only["']""", re.S)

# ---------------------------------------------------------------- AI calls
AI_PROVIDERS = [
    ("OpenAI", re.compile(
        r"""["'](?:npm:|https://esm\.sh/|https://deno\.land/x/)?(?:openai|@ai-sdk/openai)(?:@[^"']*)?["']|api\.openai\.com""")),
    ("Anthropic", re.compile(
        r"""["'](?:npm:|https://esm\.sh/)?(?:@anthropic-ai/sdk|@ai-sdk/anthropic)(?:@[^"']*)?["']|api\.anthropic\.com""")),
    ("Gemini", re.compile(
        r"""["'](?:npm:|https://esm\.sh/)?(?:@google/generative-ai|@google/genai|@ai-sdk/google)(?:@[^"']*)?["']"""
        r"""|generativelanguage\.googleapis\.com""")),
]
AI_HOST_RE = re.compile(r"api\.openai\.com|api\.anthropic\.com|generativelanguage\.googleapis\.com")
BROWSER_FLAG_RE = re.compile(r"dangerouslyAllowBrowser\s*:\s*(?:true|!0)|anthropic-dangerous-direct-browser-access")

AUTH_RE = re.compile(
    r"getUser\s*\(|getSession\s*\(|getServerSession|getClaims\s*\(|\bauth\s*\(|currentUser\s*\(|clerk|"
    r"verifyIdToken|jwt\.verify|jwtVerify|\bverify\w*\s*\(|requireAuth|requireUser|requireAdmin|withAuth|"
    r"isAuthenticated|ensureAuth|authMiddleware|passport\.authenticate|getToken\s*\(|supabase\.auth|"
    r"firebase-admin/auth|context\.auth|request\.auth|"
    r"headers(?:\.get\(\s*|\[\s*|\.)[\"']?authorization|"
    r"useAuth|useUser\b|useSession|ProtectedRoute|RequireAuth|AuthGuard|isAdmin|SignedIn|RedirectToSignIn|"
    r"withPageAuth|getAuth\s*\(\s*\)\.currentUser|onAuthStateChanged|\bsession\s*\.\s*user",
    re.I,
)
RATELIMIT_RE = re.compile(
    r"rate.?limit|upstash|limiter|express-rate-limit|throttle|slowDown|arcjet|rateLimiter", re.I
)
EXPRESS_RE = re.compile(
    r"\bexpress\s*\(\s*\)|express\.Router\s*\(|new\s+Hono\s*\(|\bfastify\s*\(|"
    r"\b(?:app|router|server)\.(?:post|get|put|patch|delete|all|use)\s*\(\s*[\"'`]/|"
    r"functions\.https\.on(?:Request|Call)|\bonRequest\s*\(|\bonCall\s*\(|Deno\.serve\s*\(|\bserve\s*\(\s*async"
)

# ------------------------------------------------------------- web checks
ORIGIN_STAR_RE = re.compile(
    r"""Access-Control-Allow-Origin["']?\s*[:=,]\s*(?:["']value["']\s*:\s*)?["']?\*|\borigin\s*:\s*["']\*["']""",
    re.I,
)
CREDENTIALS_RE = re.compile(
    r"""Access-Control-Allow-Credentials["']?\s*[:=,]\s*(?:["']value["']\s*:\s*)?["']?true"""
    r"""|(?<![A-Za-z])credentials\s*:\s*true""",
    re.I,
)
DANGEROUS_HTML_RE = re.compile(r"dangerouslySetInnerHTML\s*=\s*\{\{\s*__html\s*:\s*(?P<expr>[^\n]*?)\s*\}\}")
INNER_HTML_RE = re.compile(r"\.(?:inner|outer)HTML\s*\+?=\s*(?P<expr>[^;\n]+)")
VHTML_RE = re.compile(r"""\bv-html\s*=\s*["'](?P<expr>[^"']+)["']""")
_LITERAL_RE = re.compile(r"""\s*(?:"[^"\\]*"|'[^'\\]*'|`[^`$\\]*`)\s*,?\s*$""")

# ---------------------------------------------------------------- firebase
FIREBASE_ALLOW_RE = re.compile(r"\ballow\s+(?P<verbs>[a-z ,]+?)\s*(?::\s*if\s+(?P<cond>[^;]+))?;", re.I)
FIREBASE_TEST_MODE_RE = re.compile(r"request\.time\s*<")
RTDB_RULE_RE = re.compile(r"""["']\.(?P<verb>read|write)["']\s*:\s*(?:true|["']true["'])""")


def is_code_file(relpath: str) -> bool:
    return posixpath.splitext(relpath)[1].lower() in CODE_EXTS


def is_test_file(relpath: str) -> bool:
    return bool(TEST_PATH_RE.search(relpath.lower()))


def file_kind(relpath: str, text: str) -> str:
    """Classify a file as "client" (ships to the browser), "server" or "unknown"."""
    p = "/" + relpath.lower()
    ext = posixpath.splitext(p)[1]
    head = text[:2000]
    if USE_CLIENT_RE.match(head):
        return "client"
    if USE_SERVER_RE.search(head):
        return "server"
    if SERVER_PATH_RE.search(p) or ext in BACKEND_EXTS:
        return "server"
    if CLIENT_PATH_RE.search(p) or ext in (".html", ".htm", ".vue", ".svelte"):
        return "client"
    return "unknown"


def server_route_kind(relpath: str, text: str) -> str | None:
    """Return a label when this file is a server endpoint (API route, edge function, Express app...)."""
    p = "/" + relpath.replace("\\", "/")
    if re.search(r"/app/(?:.*/)?route\.[cm]?[jt]sx?$", p):
        return "Next.js route handler"
    if re.search(r"/pages/api/", p):
        return "Next.js API route"
    if re.search(r"/supabase/functions/[^/]+/index\.[jt]sx?$", p):
        return "Supabase Edge Function"
    if re.search(r"/netlify/(?:edge-)?functions/", p):
        return "Netlify function"
    if re.match(r"/api/", p):
        return "Vercel function"
    if is_code_file(relpath) and EXPRESS_RE.search(text):
        return "server handler"
    if is_code_file(relpath) and USE_SERVER_RE.search(text[:2000]):
        return "server action"
    return None


def ai_provider_matches(text: str) -> list[tuple[str, int]]:
    """List (provider, offset) for every AI SDK import or API host found in ``text``."""
    found = []
    for name, regex in AI_PROVIDERS:
        m = regex.search(text)
        if m:
            found.append((name, m.start()))
    return found


def has_auth(text: str) -> bool:
    return bool(AUTH_RE.search(text))


def has_ratelimit(text: str) -> bool:
    return bool(RATELIMIT_RE.search(text))


def _loc(relpath: str, starts: list[int], offset: int) -> tuple[str, int]:
    line = line_of(starts, offset)
    return f"{relpath}:{line}", line


def _line_text(text: str, starts: list[int], line: int, offset: int | None = None, limit: int = 140) -> str:
    """The source line around ``offset`` (bounded, so minified one-line bundles stay fast), secrets redacted."""
    start = starts[line - 1]
    end = starts[line] - 1 if line < len(starts) else len(text)
    if end - start > limit and offset is not None:
        start = max(start, offset - limit // 3)
        end = min(end, start + limit)
    snippet = " ".join(text[start : min(end, start + limit * 4)].split())
    if len(snippet) > limit:
        snippet = snippet[: limit - 1] + "\u2026"
    return scrub(snippet)


def check_ai_endpoint(relpath: str, text: str, global_auth: bool = False, global_ratelimit: bool = False) -> list[Finding]:
    route = server_route_kind(relpath, text)
    if not route:
        return []
    providers = ai_provider_matches(text)
    if not providers:
        return []
    starts = line_starts(text)
    provider, offset = min(providers, key=lambda p: p[1])
    provider_text = " / ".join(sorted({p for p, _ in providers}))
    location, line = _loc(relpath, starts, offset)
    evidence = _line_text(text, starts, line, offset)
    out = []
    # Next.js middleware only protects Next.js routes.
    nextish = route.startswith("Next.js") or route == "server action"
    if not has_auth(text) and not (global_auth and nextish):
        out.append(make_finding("SS-AI-ENDPOINT-NO-AUTH", location, evidence, file=relpath, line=line,
                                provider=provider_text))
    if not has_ratelimit(text) and not (global_ratelimit and nextish):
        out.append(make_finding("SS-AI-ENDPOINT-NO-RATELIMIT", location, evidence, file=relpath, line=line,
                                provider=provider_text))
    return out


def check_browser_ai(location_base: str, text: str, kind: str, file: str | None = None) -> list[Finding]:
    """AI SDK / API host used from browser code (key must live in the browser)."""
    starts = line_starts(text)
    m = BROWSER_FLAG_RE.search(text)
    if not m and kind == "client":
        m = AI_HOST_RE.search(text)
    if not m:
        return []
    providers = ai_provider_matches(text)
    provider_text = " / ".join(sorted({p for p, _ in providers})) or "the AI provider"
    location, line = _loc(location_base, starts, m.start())
    return [make_finding("SS-AI-CALL-FROM-BROWSER", location, _line_text(text, starts, line, m.start()), file=file,
                         line=line, provider=provider_text)]


def check_client_api_keys(relpath: str, text: str) -> list[Finding]:
    """Long literal ``apiKey: "..."`` values in browser code (high when the file also uses an AI SDK)."""
    hits = find_client_api_keys(text)
    if not hits:
        return []
    severity = "high" if ai_provider_matches(text) else None
    starts = line_starts(text)
    out = []
    for offset, value in hits:
        location, line = _loc(relpath, starts, offset)
        out.append(make_finding("SS-SECRET-CLIENT-APIKEY", location, _line_text(text, starts, line, offset),
                                severity=severity, file=relpath, line=line, raw=value))
    return out


def check_public_env_refs(relpath: str, text: str) -> list[Finding]:
    out = []
    starts = line_starts(text)
    seen = set()
    for m in PUBLIC_REF_RE.finditer(text):
        name = m.group("name")
        if name in seen or not is_secret_env_name(name):
            continue
        seen.add(name)
        location, line = _loc(relpath, starts, m.start())
        out.append(make_finding("SS-PUBLIC-ENV-SECRET-NAME", location, name, file=relpath, line=line, name=name,
                                prefixes=public_prefix(name) or ""))
    return out


ADMIN_ROUTE_RE = re.compile(
    r"(?:^|/)(?:src/)?(?:app|pages|routes|views|screens|api)/(?:.*/)?[^/]*admin[^/]*(?:/|\.[a-z]+$)", re.I
)


def is_admin_route(relpath: str) -> bool:
    p = relpath.replace("\\", "/")
    if not is_code_file(p) or "admin" not in p.lower() or is_test_file(p):
        return False
    if not ADMIN_ROUTE_RE.search(p):
        return False
    name = posixpath.basename(p).lower()
    # In the Next.js app router only page/route files are reachable; layouts protect them.
    if re.search(r"(?:^|/)app/", p) and not re.search(r"(?:^|/)pages/", p):
        stem = name.split(".")[0]
        return stem in ("page", "route")
    if name.split(".")[0] in ("layout", "_layout", "loading", "error", "not-found"):
        return False
    return True


def check_admin_route(relpath: str, text: str, layouts: dict[str, str], global_auth: bool = False) -> list[Finding]:
    """``layouts`` maps directory (relative) -> concatenated text of layout files in that directory."""
    if not is_admin_route(relpath) or has_auth(text) or global_auth:
        return []
    d = posixpath.dirname(relpath)
    while d:
        if has_auth(layouts.get(d, "")):
            return []
        d = posixpath.dirname(d)
    if has_auth(layouts.get("", "")):
        return []
    evidence = "no login or admin-role check found in this file, its layouts or middleware"
    return [make_finding("SS-ADMIN-NO-AUTH", relpath, evidence, file=relpath, line=None)]


def check_cors(relpath: str, text: str) -> list[Finding]:
    origin = ORIGIN_STAR_RE.search(text)
    if not origin or not CREDENTIALS_RE.search(text):
        return []
    starts = line_starts(text)
    location, line = _loc(relpath, starts, origin.start())
    return [make_finding("SS-CORS-WILDCARD-CREDENTIALS", location, _line_text(text, starts, line, origin.start()), file=relpath,
                         line=line)]


def _is_literal(expr: str) -> bool:
    return bool(_LITERAL_RE.fullmatch(expr))


def check_raw_html(relpath: str, text: str) -> list[Finding]:
    out = []
    starts = line_starts(text)
    for regex in (DANGEROUS_HTML_RE, INNER_HTML_RE, VHTML_RE):
        for m in regex.finditer(text):
            expr = m.group("expr").strip()
            if not expr or _is_literal(expr):
                continue
            if regex is INNER_HTML_RE and expr in ('""', "''", "``"):
                continue
            location, line = _loc(relpath, starts, m.start())
            out.append(make_finding("SS-XSS-INNERHTML", location, _line_text(text, starts, line, m.start()), file=relpath,
                                    line=line))
    return out


def check_firebase_rules(relpath: str, text: str) -> list[Finding]:
    out = []
    starts = line_starts(text)
    name = posixpath.basename(relpath).lower()
    if name.endswith(".json"):
        for m in RTDB_RULE_RE.finditer(text):
            rule = "SS-FIREBASE-OPEN-RULES" if m.group("verb") == "write" else "SS-FIREBASE-PUBLIC-READ"
            location, line = _loc(relpath, starts, m.start())
            out.append(make_finding(rule, location, _line_text(text, starts, line, m.start()), file=relpath, line=line))
        return out
    for m in FIREBASE_TEST_MODE_RE.finditer(text):
        location, line = _loc(relpath, starts, m.start())
        out.append(make_finding("SS-FIREBASE-TEST-MODE", location, _line_text(text, starts, line, m.start()), file=relpath,
                                line=line))
    for m in FIREBASE_ALLOW_RE.finditer(text):
        cond = (m.group("cond") or "true").strip()
        if cond.lower() != "true":
            continue
        verbs = {v.strip().lower() for v in re.split(r"[,\s]+", m.group("verbs")) if v.strip()}
        rule = (
            "SS-FIREBASE-OPEN-RULES"
            if verbs & {"write", "create", "update", "delete"}
            else "SS-FIREBASE-PUBLIC-READ"
        )
        location, line = _loc(relpath, starts, m.start())
        out.append(make_finding(rule, location, _line_text(text, starts, line, m.start()), file=relpath, line=line))
    return out


def is_firebase_rules_file(relpath: str) -> bool:
    name = posixpath.basename(relpath).lower()
    return name.endswith(".rules") or name in ("database.rules.json", "firebase.rules.json")
