"""Optional ``shipsafe.yml`` config file.

Supported keys::

    fail_on: high              # critical | high | medium | low | never
    include_build: false
    ignore_rules: [SS-XSS-INNERHTML]
    ignore_paths:
      - "scripts/*"
    brand_name: My Academy
    brand_color: "#ff6600"

PyYAML is used when installed; otherwise a small built-in parser handles this simple format.
"""

from __future__ import annotations

import os

CONFIG_NAMES = ("shipsafe.yml", "shipsafe.yaml")
KNOWN_KEYS = {"fail_on", "include_build", "ignore_rules", "ignore_paths", "brand_name", "brand_color", "logo_url"}


class ConfigError(Exception):
    pass


def _scalar(value: str):
    v = value.strip()
    if len(v) >= 2 and v[0] == v[-1] and v[0] in "\"'":
        return v[1:-1]
    low = v.lower()
    if low in ("true", "yes", "on"):
        return True
    if low in ("false", "no", "off"):
        return False
    if low in ("", "null", "~"):
        return None
    if v.startswith("[") and v.endswith("]"):
        return [_scalar(x) for x in v[1:-1].split(",") if x.strip()]
    return v


def _strip_comment(line: str) -> str:
    """Remove a ``#`` comment unless it is inside quotes."""
    quote = ""
    for i, c in enumerate(line):
        if quote:
            if c == quote:
                quote = ""
        elif c in "\"'":
            quote = c
        elif c == "#" and (i == 0 or line[i - 1].isspace()):
            return line[:i]
    return line


def parse_simple_yaml(text: str) -> dict:
    """Parse flat ``key: value`` and ``key:`` + ``- item`` lists. Enough for shipsafe.yml."""
    data: dict = {}
    current: str | None = None
    for lineno, raw in enumerate(text.splitlines(), 1):
        line = _strip_comment(raw).rstrip()
        if not line.strip():
            continue
        stripped = line.strip()
        if stripped.startswith("- ") or stripped == "-":
            if current is None or not isinstance(data.get(current), list):
                raise ConfigError(f"line {lineno}: list item without a key")
            data[current].append(_scalar(stripped[1:]))
            continue
        if ":" not in stripped or line[0].isspace():
            raise ConfigError(f"line {lineno}: expected 'key: value'")
        key, _, value = stripped.partition(":")
        key = key.strip()
        if value.strip():
            data[key] = _scalar(value)
            current = None
        else:
            data[key] = []
            current = key
    return data


def load_config(path: str) -> dict:
    with open(path, encoding="utf-8") as fh:
        text = fh.read()
    try:
        import yaml  # type: ignore

        data = yaml.safe_load(text) or {}
    except ImportError:
        data = parse_simple_yaml(text)
    except Exception as exc:  # yaml.YAMLError
        raise ConfigError(f"{path}: {exc}") from exc
    if not isinstance(data, dict):
        raise ConfigError(f"{path}: expected a mapping of settings")
    unknown = set(data) - KNOWN_KEYS
    if unknown:
        raise ConfigError(f"{path}: unknown setting(s): {', '.join(sorted(unknown))}")
    for key in ("ignore_rules", "ignore_paths"):
        val = data.get(key)
        if val is None:
            data.pop(key, None)
        elif isinstance(val, str):
            data[key] = [val]
        elif not isinstance(val, list):
            raise ConfigError(f"{path}: {key} must be a list")
        else:
            data[key] = [str(x) for x in val]
    return data


def find_config(directory: str) -> str | None:
    for name in CONFIG_NAMES:
        path = os.path.join(directory, name)
        if os.path.isfile(path):
            return path
    return None
