"""Core data types: severities, findings, scan results and redaction."""

from __future__ import annotations

from dataclasses import dataclass, field

SEVERITIES = ("critical", "high", "medium", "low", "info")
SEVERITY_RANK = {"critical": 4, "high": 3, "medium": 2, "low": 1, "info": 0}
FAIL_ON_CHOICES = ("critical", "high", "medium", "low", "never")

ELLIPSIS = "…"


def redact(value: str) -> str:
    """Show only the first 4 characters of a secret followed by an ellipsis.

    Very short values (8 chars or fewer) only keep their first character so the
    redacted form never gives most of the secret away.
    """
    value = (value or "").strip()
    if not value:
        return ""
    keep = 4 if len(value) > 8 else 1
    return value[:keep] + ELLIPSIS


def severity_at_least(severity: str, threshold: str) -> bool:
    """True when ``severity`` is as bad as or worse than ``threshold``."""
    if threshold == "never":
        return False
    return SEVERITY_RANK[severity] >= SEVERITY_RANK[threshold]


@dataclass
class Finding:
    rule_id: str
    severity: str
    title: str
    why: str
    location: str
    evidence: str
    fix_prompt: str
    file: str | None = None
    line: int | None = None
    # Internal: hash of the raw match, used for de-duplication. Never the secret itself.
    fingerprint: str = field(default="", repr=False)

    @property
    def rank(self) -> int:
        return SEVERITY_RANK[self.severity]

    def to_dict(self) -> dict:
        return {
            "id": self.rule_id,
            "severity": self.severity,
            "title": self.title,
            "why": self.why,
            "location": self.location,
            "file": self.file,
            "line": self.line,
            "evidence": self.evidence,
            "fix_prompt": self.fix_prompt,
        }


def sort_findings(findings: list[Finding]) -> list[Finding]:
    return sorted(findings, key=lambda f: (-f.rank, f.file or f.location, f.line or 0, f.rule_id))


@dataclass
class ScanResult:
    target: str
    mode: str  # "scan" (local folder) or "url"
    findings: list[Finding] = field(default_factory=list)
    files_scanned: int = 0
    skipped: dict[str, int] = field(default_factory=dict)
    notes: list[str] = field(default_factory=list)

    def counts(self) -> dict[str, int]:
        counts = {s: 0 for s in SEVERITIES}
        for f in self.findings:
            counts[f.severity] += 1
        return counts

    def worst(self) -> str | None:
        if not self.findings:
            return None
        return max(self.findings, key=lambda f: f.rank).severity

    def should_fail(self, fail_on: str) -> bool:
        return any(severity_at_least(f.severity, fail_on) for f in self.findings if f.severity != "info")
