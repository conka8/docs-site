"""A small .gitignore matcher (enough to decide whether .env files are ignored)."""

from __future__ import annotations

import os
import re
from dataclasses import dataclass


@dataclass(frozen=True)
class IgnorePattern:
    regex: re.Pattern
    negate: bool
    base: str  # directory (relative to scan root, "" for root) that holds the .gitignore


def _glob_to_regex(glob: str) -> str:
    out = []
    i = 0
    while i < len(glob):
        c = glob[i]
        if glob.startswith("**/", i):
            out.append("(?:.*/)?")
            i += 3
            continue
        if glob.startswith("/**", i) and i + 3 == len(glob):
            out.append("/.*")
            i += 3
            continue
        if glob.startswith("**", i):
            out.append(".*")
            i += 2
            continue
        if c == "*":
            out.append("[^/]*")
        elif c == "?":
            out.append("[^/]")
        elif c == "[":
            j = glob.find("]", i + 1)
            if j == -1:
                out.append(re.escape(c))
            else:
                cls = glob[i + 1 : j].replace("\\", "\\\\")
                if cls.startswith("!"):
                    cls = "^" + cls[1:]
                out.append(f"[{cls}]")
                i = j
        elif c == "\\" and i + 1 < len(glob):
            out.append(re.escape(glob[i + 1]))
            i += 1
        else:
            out.append(re.escape(c))
        i += 1
    return "".join(out)


def parse_gitignore(text: str, base: str = "") -> list[IgnorePattern]:
    patterns: list[IgnorePattern] = []
    for raw in text.splitlines():
        line = raw.rstrip()
        if not line or line.startswith("#"):
            continue
        negate = line.startswith("!")
        if negate:
            line = line[1:]
        dir_only = line.endswith("/")
        line = line.rstrip("/")
        if not line:
            continue
        anchored = "/" in line
        line = line.lstrip("/")
        body = _glob_to_regex(line)
        tail = "/.*" if dir_only else "(?:/.*)?"
        prefix = "^" if anchored else "^(?:.*/)?"
        patterns.append(IgnorePattern(re.compile(prefix + body + tail + "$"), negate, base))
    return patterns


def is_ignored(relpath: str, patterns: list[IgnorePattern]) -> bool:
    """Return True when ``relpath`` (POSIX, relative to scan root) is ignored by ``patterns``."""
    relpath = relpath.replace(os.sep, "/")
    ignored = False
    for pat in patterns:
        if pat.base:
            if not relpath.startswith(pat.base + "/"):
                continue
            sub = relpath[len(pat.base) + 1 :]
        else:
            sub = relpath
        if pat.regex.match(sub):
            ignored = not pat.negate
    return ignored


def load_gitignores(root: str, relpaths: list[str]) -> list[IgnorePattern]:
    """Load the root .gitignore and any nested .gitignore files found during the walk."""
    patterns: list[IgnorePattern] = []
    gitignores = sorted((p for p in relpaths if p == ".gitignore" or p.endswith("/.gitignore")), key=lambda p: p.count("/"))
    for rel in gitignores:
        base = rel.rsplit("/", 1)[0] if "/" in rel else ""
        try:
            with open(os.path.join(root, rel), encoding="utf-8", errors="replace") as fh:
                patterns.extend(parse_gitignore(fh.read(), base))
        except OSError:
            continue
    return patterns
