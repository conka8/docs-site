"""``shipsafe scan <dir>``: walk a project folder and run every local check."""

from __future__ import annotations

import fnmatch
import os
import posixpath
import re

from . import codecheck
from .findings import Finding, ScanResult, redact, sort_findings
from .gitignore import is_ignored, load_gitignores
from .patterns import (
    PUBLIC_ASSIGN_RE,
    SecretHit,
    find_secrets,
    is_placeholder,
    line_of,
    line_starts,
    public_env_value_is_secret,
    public_prefix,
    scrub,
)
from .rules import RULES, fingerprint, make_finding
from .sqlcheck import SqlState, check_js_buckets

MAX_FILE_SIZE = 2 * 1024 * 1024
ALWAYS_SKIP_DIRS = {
    "node_modules", ".git", ".hg", ".svn", ".venv", "venv", "__pycache__", ".turbo", ".cache", ".pytest_cache",
    ".mypy_cache", ".ruff_cache",
    ".vercel", ".netlify", "coverage", ".pnpm-store", ".yarn", ".idea", ".vscode", ".expo", "Pods",
}
BUILD_DIRS = {"dist", "build", ".next", "out", ".output", ".svelte-kit", ".nuxt", ".astro"}
SKIP_FILES = {"package-lock.json", "yarn.lock", "pnpm-lock.yaml", "bun.lockb", "bun.lock", "shipsafe.yml", "shipsafe.yaml"}
BINARY_EXTS = {
    ".png", ".jpg", ".jpeg", ".gif", ".webp", ".ico", ".bmp", ".tiff", ".avif", ".pdf", ".zip", ".gz", ".tgz",
    ".bz2", ".xz", ".7z", ".rar", ".woff", ".woff2", ".ttf", ".otf", ".eot", ".mp3", ".mp4", ".mov", ".avi",
    ".webm", ".wav", ".ogg", ".flac", ".wasm", ".exe", ".dll", ".so", ".dylib", ".bin", ".class", ".jar",
    ".pyc", ".sqlite", ".db", ".psd", ".sketch", ".fig", ".heic",
}
ENV_EXAMPLE_SUFFIXES = (".example", ".sample", ".template", ".dist", ".defaults", ".schema")
ENV_LINE_RE = re.compile(r"^[ \t]*(?:export[ \t]+)?(?P<name>[A-Za-z_][A-Za-z0-9_]*)[ \t]*=[ \t]*(?P<value>.*)$", re.M)
IGNORE_RE = re.compile(r"shipsafe-ignore(?!-next-line|-file)(?P<rules>(?:[ \t:]+SS-[A-Z0-9-]+)*)")
IGNORE_NEXT_RE = re.compile(r"shipsafe-ignore-next-line(?P<rules>(?:[ \t:]+SS-[A-Z0-9-]+)*)")


class ScanError(Exception):
    """Raised for problems the user must fix (missing folder, bad URL...)."""


def is_env_file(relpath: str) -> bool:
    name = posixpath.basename(relpath)
    is_env = name == ".env" or name.startswith(".env.") or (name.endswith(".env") and len(name) > 4)
    return is_env and not name.endswith(ENV_EXAMPLE_SUFFIXES)


def is_env_like(relpath: str) -> bool:
    name = posixpath.basename(relpath)
    return name == ".env" or name.startswith(".env.") or name.endswith(".env")


def is_binary(data: bytes, relpath: str) -> bool:
    if posixpath.splitext(relpath)[1].lower() in BINARY_EXTS:
        return True
    return b"\x00" in data[:8192]


def walk(root: str, include_build: bool = False, ignore_paths: tuple[str, ...] = ()) -> tuple[list[str], dict[str, int]]:
    """Return (relative file paths, skipped-directory counts)."""
    skip_dirs = set(ALWAYS_SKIP_DIRS)
    if not include_build:
        skip_dirs |= BUILD_DIRS
    files: list[str] = []
    skipped: dict[str, int] = {}
    for dirpath, dirnames, filenames in os.walk(root):
        rel_dir = os.path.relpath(dirpath, root).replace(os.sep, "/")
        rel_dir = "" if rel_dir == "." else rel_dir
        keep = []
        for d in sorted(dirnames):
            rel = f"{rel_dir}/{d}" if rel_dir else d
            if d in skip_dirs or _matches_any(rel, ignore_paths):
                key = "build_dirs" if d in BUILD_DIRS else "ignored_dirs"
                skipped[key] = skipped.get(key, 0) + 1
                continue
            if os.path.islink(os.path.join(dirpath, d)):
                continue
            keep.append(d)
        dirnames[:] = keep
        for f in sorted(filenames):
            rel = f"{rel_dir}/{f}" if rel_dir else f
            if _matches_any(rel, ignore_paths):
                skipped["ignored_files"] = skipped.get("ignored_files", 0) + 1
                continue
            files.append(rel)
    return files, skipped


def _matches_any(relpath: str, globs: tuple[str, ...]) -> bool:
    return any(fnmatch.fnmatch(relpath, g) or fnmatch.fnmatch(posixpath.basename(relpath), g) for g in globs)


def _adjust_secret_severity(hit: SecretHit, kind: str, test_file: bool) -> tuple[str | None, str]:
    """Return (severity override, title suffix) for a hard-coded secret."""
    severity = hit.severity
    suffix = ""
    if test_file and hit.rule_id != "SS-SUPABASE-ANON-KEY":
        return "low", " (in a test file)"
    if kind == "server" and hit.rule_id not in ("SS-SECRET-PRIVATE-KEY", "SS-SUPABASE-ANON-KEY"):
        if (severity or RULES[hit.rule_id].severity) == "critical":
            severity = "high"
            suffix = " (server code)"
    return severity, suffix


def _hit_findings(relpath: str, text: str, hits: list[SecretHit], kind: str, test_file: bool) -> list[Finding]:
    starts = line_starts(text)
    out = []
    for hit in hits:
        line = line_of(starts, hit.start)
        severity, suffix = _adjust_secret_severity(hit, kind, test_file)
        evidence = hit.value if hit.rule_id == "SS-SECRET-PRIVATE-KEY" else redact(hit.value)
        finding = make_finding(hit.rule_id, f"{relpath}:{line}", evidence, severity=severity, file=relpath, line=line,
                               raw=hit.value, title_suffix=suffix)
        if kind == "env" and hit.rule_id != "SS-SUPABASE-ANON-KEY":
            finding.title += " (in a .env file that git will upload)"
            finding.fix_prompt = ENV_FILE_FIX.replace("{location}", finding.location)
        out.append(finding)
    return out


ENV_FILE_FIX = (
    "A secret value is stored in {location}, and that file is not ignored by git, so it gets uploaded together "
    "with my code. Please add this file to .gitignore, give me the command to stop tracking it without deleting "
    "my local copy (git rm --cached), and remind me to put the value in my hosting provider's environment "
    "variable settings instead (Vercel, Netlify or Supabase secrets). Then tell me how to rotate this key, "
    "because it may already have been exposed."
)


def _public_assign_findings(relpath: str, text: str, matches: list[re.Match]) -> list[Finding]:
    starts = line_starts(text)
    out = []
    for m in matches:
        line = line_of(starts, m.start())
        name, value = m.group("name"), m.group("value").strip().strip("\"'`")
        out.append(make_finding("SS-PUBLIC-ENV-SECRET", f"{relpath}:{line}", f"{name}={redact(value)}", file=relpath,
                                line=line, raw=value, name=name))
    return out


def scan_env_file(relpath: str, text: str, ignored_by_git: bool) -> list[Finding]:
    out: list[Finding] = []
    public_matches = []
    other_hits: list[SecretHit] = []
    for m in ENV_LINE_RE.finditer(text):
        name = m.group("name")
        raw_value = m.group("value")
        value = raw_value.strip()
        if value[:1] in ("'", '"'):
            q = value[0]
            end = value.find(q, 1)
            value = value[1:end] if end != -1 else value[1:]
        else:
            value = value.split(" #", 1)[0].strip()
        value_offset = m.start("value") + raw_value.find(value) if value else m.start("value")
        if public_prefix(name):
            if public_env_value_is_secret(name, value):
                public_matches.append(_EnvMatch(name, value, m.start()))
                continue
            # anon keys etc. are fine but worth an info line
            for hit in find_secrets(value):
                if hit.rule_id == "SS-SUPABASE-ANON-KEY":
                    other_hits.append(SecretHit(hit.rule_id, value_offset + hit.start, value_offset + hit.end, hit.value))
            continue
        if ignored_by_git:
            continue  # a git-ignored .env is exactly where server secrets belong
        for hit in find_secrets(value):
            other_hits.append(SecretHit(hit.rule_id, value_offset + hit.start, value_offset + hit.end, hit.value,
                                        hit.severity))
        if not find_secrets(value) and re.search(r"PASSWORD|PASSWD|SECRET", name.upper()) and len(value) >= 6:
            if not is_placeholder(value):
                other_hits.append(SecretHit("SS-SECRET-PASSWORD", value_offset, value_offset + len(value), value))
    out.extend(_public_assign_findings(relpath, text, public_matches))  # type: ignore[arg-type]
    out.extend(_hit_findings(relpath, text, other_hits, "env", False))
    return out


class _EnvMatch:
    """Duck-types the bits of ``re.Match`` used by ``_public_assign_findings``."""

    def __init__(self, name: str, value: str, start: int):
        self._g = {"name": name, "value": value}
        self._start = start

    def group(self, key: str) -> str:
        return self._g[key]

    def start(self) -> int:
        return self._start


def scan_text_file(relpath: str, text: str) -> list[Finding]:
    """Secret checks for a non-.env text file."""
    kind = codecheck.file_kind(relpath, text)
    test_file = codecheck.is_test_file(relpath)
    public_matches = [
        m for m in PUBLIC_ASSIGN_RE.finditer(text) if public_env_value_is_secret(m.group("name"), m.group("value"))
    ]
    hits = find_secrets(text)
    if public_matches:
        spans = [m.span("value") for m in public_matches]
        hits = [h for h in hits if not any(h.start < e and s < h.end for s, e in spans)]
    out = _public_assign_findings(relpath, text, public_matches)
    if test_file:
        for f in out:
            f.severity = "low"
            f.title += " (in a test file)"
    out.extend(_hit_findings(relpath, text, hits, kind, test_file))
    return out


def _apply_inline_ignores(findings: list[Finding], texts: dict[str, str]) -> list[Finding]:
    kept = []
    line_cache: dict[str, list[str]] = {}
    for f in findings:
        if f.file and f.file in texts:
            lines = line_cache.setdefault(f.file, texts[f.file].splitlines())
            if f.line is None:
                if any("shipsafe-ignore-file" in ln for ln in lines):
                    continue
            elif 1 <= f.line <= len(lines):
                if _suppressed(lines[f.line - 1], IGNORE_RE, f.rule_id):
                    continue
                if f.line >= 2 and _suppressed(lines[f.line - 2], IGNORE_NEXT_RE, f.rule_id):
                    continue
        kept.append(f)
    return kept


def _suppressed(line: str, regex: re.Pattern, rule_id: str) -> bool:
    m = regex.search(line)
    if not m:
        return False
    rules = re.findall(r"SS-[A-Z0-9-]+", m.group("rules") or "")
    return not rules or rule_id in rules


MAX_PER_RULE_PER_FILE = 10


def cap_per_file(findings: list[Finding], limit: int = MAX_PER_RULE_PER_FILE) -> tuple[list[Finding], int]:
    """Keep at most ``limit`` findings per (rule, file) so one minified bundle can't flood the report."""
    counts: dict[tuple[str, str], int] = {}
    kept = []
    for f in findings:
        key = (f.rule_id, f.file or f.location)
        counts[key] = counts.get(key, 0) + 1
        if counts[key] <= limit:
            kept.append(f)
    return kept, len(findings) - len(kept)


def dedupe(findings: list[Finding], by_value: bool = False) -> list[Finding]:
    seen = set()
    out = []
    for f in findings:
        key = (f.rule_id, f.fingerprint) if by_value else (f.rule_id, f.location, f.fingerprint)
        if key in seen:
            continue
        seen.add(key)
        out.append(f)
    return out


def scan_directory(
    root: str,
    include_build: bool = False,
    ignore_rules: tuple[str, ...] | list[str] = (),
    ignore_paths: tuple[str, ...] | list[str] = (),
    max_file_size: int = MAX_FILE_SIZE,
) -> ScanResult:
    if not os.path.isdir(root):
        raise ScanError(f"Folder not found: {root}")
    root = os.path.abspath(root)
    files, skipped = walk(root, include_build, tuple(ignore_paths))
    result = ScanResult(target=root, mode="scan", skipped=skipped)
    texts: dict[str, str] = {}
    for rel in files:
        if posixpath.basename(rel) in SKIP_FILES:
            continue
        path = os.path.join(root, rel)
        try:
            size = os.path.getsize(path)
        except OSError:
            continue
        if size > max_file_size:
            skipped["too_large"] = skipped.get("too_large", 0) + 1
            continue
        try:
            with open(path, "rb") as fh:
                data = fh.read()
        except OSError:
            skipped["unreadable"] = skipped.get("unreadable", 0) + 1
            continue
        if is_binary(data, rel):
            skipped["binary"] = skipped.get("binary", 0) + 1
            continue
        texts[rel] = data.decode("utf-8", errors="replace")
    result.files_scanned = len(texts)

    patterns = load_gitignores(root, files)
    has_root_gitignore = ".gitignore" in files
    findings: list[Finding] = []

    # Cross-file context: Next.js middleware and layouts.
    global_auth = global_rl = False
    layouts: dict[str, str] = {}
    for rel, text in texts.items():
        base = posixpath.basename(rel)
        stem = base.split(".")[0]
        if re.fullmatch(r"(?:src/)?middleware\.[jt]s", rel):
            global_auth = global_auth or codecheck.has_auth(text)
            global_rl = global_rl or codecheck.has_ratelimit(text)
        if codecheck.is_code_file(rel) and stem.lstrip("_+") == "layout":
            d = posixpath.dirname(rel)
            layouts[d] = layouts.get(d, "") + "\n" + text

    sql = SqlState()
    for rel in sorted(texts):
        text = texts[rel]
        lower = rel.lower()
        if is_env_like(rel) and not lower.endswith((".js", ".ts")):
            if is_env_file(rel):
                ignored = is_ignored(rel, patterns)
                if not ignored:
                    findings.append(make_finding("SS-ENV-NOT-IGNORED", rel, posixpath.basename(rel), file=rel))
                findings.extend(scan_env_file(rel, text, ignored))
            else:
                # .env.example and friends are committed on purpose: any real key in them is leaked.
                findings.extend(scan_env_file(rel, text, False))
            continue
        findings.extend(scan_text_file(rel, text))
        if codecheck.is_test_file(rel):
            continue  # test data is not deployed: only the secret checks above apply
        if lower.endswith(".sql"):
            sql.add_file(rel, text)
            continue
        if codecheck.is_firebase_rules_file(rel):
            findings.extend(codecheck.check_firebase_rules(rel, text))
            continue
        if codecheck.is_code_file(rel) or lower.endswith((".html", ".htm")):
            kind = codecheck.file_kind(rel, text)
            findings.extend(codecheck.check_ai_endpoint(rel, text, global_auth, global_rl))
            findings.extend(codecheck.check_admin_route(rel, text, layouts, global_auth))
            if kind == "client" or "dangerouslyAllowBrowser" in text:
                if not codecheck.server_route_kind(rel, text):
                    findings.extend(codecheck.check_browser_ai(rel, text, kind, file=rel))
            if kind != "server":
                findings.extend(codecheck.check_public_env_refs(rel, text))
            if kind == "client" and not codecheck.server_route_kind(rel, text):
                findings.extend(codecheck.check_client_api_keys(rel, text))
            findings.extend(codecheck.check_raw_html(rel, text))
            findings.extend(check_js_buckets(rel, text))
        if codecheck.is_code_file(rel) or posixpath.basename(lower) in ("vercel.json", "netlify.toml", "_headers"):
            findings.extend(codecheck.check_cors(rel, text))
    findings.extend(sql.finish())

    if not has_root_gitignore:
        findings.append(make_finding("SS-GITIGNORE-MISSING", ".gitignore", "(file not found)", file=None))

    findings = _apply_inline_ignores(findings, texts)
    ignore = {r.upper() for r in ignore_rules}
    findings = [f for f in findings if f.rule_id not in ignore]
    for f in findings:
        f.evidence = scrub(f.evidence) if f.rule_id not in ("SS-SECRET-PRIVATE-KEY",) else f.evidence
    findings, dropped = cap_per_file(sort_findings(dedupe(findings)))
    if dropped:
        result.notes.append(f"{dropped} repeated finding(s) hidden (max {MAX_PER_RULE_PER_FILE} per rule per file).")
    result.findings = findings
    if not texts:
        result.notes.append("No readable text files were found in this folder.")
    return result


__all__ = ["scan_directory", "ScanError", "walk", "is_binary", "is_env_file", "fingerprint"]
