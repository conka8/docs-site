"""Secret detection: provider key patterns, JWT decoding, placeholders and scrubbing.

Everything here works on plain text and returns character offsets, so the same
code is used for local files and for JavaScript bundles fetched from a URL.
"""

from __future__ import annotations

import base64
import binascii
import json
import re
from dataclasses import dataclass
from typing import Callable

from .findings import ELLIPSIS, redact

PUBLIC_PREFIXES = ("NEXT_PUBLIC_", "VITE_", "REACT_APP_", "EXPO_PUBLIC_")
_PREFIX_ALT = "NEXT_PUBLIC|VITE|REACT_APP|EXPO_PUBLIC"

PLACEHOLDER_WORDS = (
    "example", "your", "xxxx", "placeholder", "dummy", "changeme", "change_me", "change-me",
    "replace", "insert", "here", "redacted", "todo", "<", ">", "...", "***", "fake",
)


def is_placeholder(value: str) -> bool:
    """Heuristic for obvious placeholder values such as ``sk-your-key-here``."""
    v = value.lower()
    if any(word in v for word in PLACEHOLDER_WORDS):
        return True
    body = re.sub(r"^[a-z]{2,4}[-_](?:[a-z]+[-_])?", "", v)
    if len(body) >= 6 and len(set(body)) <= 3:  # sk-aaaaaaaa, 0000000000
        return True
    return False


def _mixed_case_digit(s: str) -> bool:
    return any(c.isdigit() for c in s) and any(c.isupper() for c in s) and any(c.islower() for c in s)


def _letter_digit(s: str) -> bool:
    return any(c.isdigit() for c in s) and any(c.isalpha() for c in s)


def _not_example(s: str) -> bool:
    return "EXAMPLE" not in s.upper()


@dataclass(frozen=True)
class SecretPattern:
    rule_id: str
    regex: re.Pattern
    validator: Callable[[str], bool] | None = None
    group: str = "key"


SECRET_PATTERNS: list[SecretPattern] = [
    SecretPattern("SS-SECRET-ANTHROPIC", re.compile(r"(?<![\w-])(?P<key>sk-ant-[A-Za-z0-9_\-]{20,})"), _letter_digit),
    SecretPattern(
        "SS-SECRET-OPENAI",
        re.compile(r"(?<![\w-])(?P<key>sk-(?!ant-)(?:proj-|svcacct-|admin-)?[A-Za-z0-9_\-]{20,})"),
        lambda s: _mixed_case_digit(s) and "--" not in s,
    ),
    SecretPattern("SS-SECRET-STRIPE-LIVE", re.compile(r"(?<![\w-])(?P<key>(?:sk|rk)_live_[A-Za-z0-9]{16,})"), _letter_digit),
    SecretPattern("SS-SECRET-STRIPE-TEST", re.compile(r"(?<![\w-])(?P<key>(?:sk|rk)_test_[A-Za-z0-9]{16,})"), _letter_digit),
    SecretPattern("SS-SECRET-AWS", re.compile(r"(?<![A-Za-z0-9])(?P<key>(?:AKIA|ASIA)[0-9A-Z]{16})(?![A-Za-z0-9])"), _not_example),
    SecretPattern(
        "SS-SECRET-GITHUB",
        re.compile(r"(?<![\w-])(?P<key>gh[pousr]_[A-Za-z0-9]{36}|github_pat_[A-Za-z0-9_]{22,})(?![A-Za-z0-9])"),
    ),
    SecretPattern("SS-SECRET-GOOGLE", re.compile(r"(?<![\w-])(?P<key>AIza[0-9A-Za-z_\-]{35})(?![\w-])")),
    SecretPattern("SS-SECRET-SLACK", re.compile(r"(?<![\w-])(?P<key>xox[bp]-[0-9A-Za-z\-]{10,})")),
    SecretPattern(
        "SS-SECRET-SLACK",
        re.compile(r"(?P<key>https://hooks\.slack\.com/services/T[A-Za-z0-9]+/B[A-Za-z0-9]+/[A-Za-z0-9]{16,})"),
    ),
    SecretPattern("SS-SECRET-SENDGRID", re.compile(r"(?<![\w-])(?P<key>SG\.[A-Za-z0-9_\-]{22}\.[A-Za-z0-9_\-]{43})(?![\w-])")),
    SecretPattern("SS-SECRET-TWILIO", re.compile(r"(?<![A-Za-z0-9])(?P<key>SK[0-9a-fA-F]{32})(?![A-Za-z0-9])"), _letter_digit),
    SecretPattern(
        "SS-SECRET-TWILIO",
        re.compile(r"(?i)twilio\w*auth\w*token\w*[\"']?\s*[:=]\s*[\"']?(?P<key>[0-9a-f]{32})(?![0-9a-f])"),
    ),
    SecretPattern("SS-SUPABASE-SERVICE-ROLE", re.compile(r"(?<![\w-])(?P<key>sb_secret_[A-Za-z0-9_\-]{16,})")),
]

SB_PUBLISHABLE_RE = re.compile(r"(?<![\w-])(?P<key>sb_publishable_[A-Za-z0-9_\-]{16,})")
JWT_RE = re.compile(r"(?<![\w-])(?P<key>eyJ[A-Za-z0-9_\-]{5,}\.eyJ[A-Za-z0-9_\-]{5,}\.[A-Za-z0-9_\-]{5,})")
PRIVATE_KEY_RE = re.compile(
    r"-----BEGIN (?P<kind>(?:RSA |EC |DSA |OPENSSH |PGP |ENCRYPTED )?PRIVATE KEY(?: BLOCK)?)-----"
    r"(?P<body>.*?)(?:-----END [A-Z ]*PRIVATE KEY(?: BLOCK)?-----|\Z)",
    re.S,
)
PASSWORD_RE = re.compile(
    r"""(?<![A-Za-z0-9_.\-])(?P<name>[A-Za-z0-9_.\-]{0,40}?(?:password|passwd|pwd|secret)[A-Za-z0-9_\-]{0,40})"""
    r"""["']?\s*[:=]\s*["'](?P<key>[^"'\s]{6,200})["']""",
    re.I,
)
PASSWORD_NAME_EXCLUDE = (
    "label", "placeholder", "field", "input", "hint", "msg", "message", "error", "regex", "pattern",
    "type", "name", "url", "path", "route", "policy", "min", "max", "length", "strength", "reset",
    "forgot", "confirm", "show", "hide", "toggle", "visible", "icon", "class", "style", "text", "title",
    "description", "header", "manager", "rule", "valid", "secretary",
)

# Env-var names that look like they hold a secret, and ones that are public by design.
SECRET_NAME_RE = re.compile(
    r"SECRET|SERVICE_ROLE|PRIVATE|PASSWORD|PASSWD|OPENAI|ANTHROPIC|CLAUDE|GEMINI|GROQ|MISTRAL|PERPLEXITY|"
    r"DEEPSEEK|REPLICATE|ELEVENLABS|RESEND|SENDGRID|MAILGUN|POSTMARK|TWILIO_AUTH|AWS_SECRET|STRIPE_SK|"
    r"ADMIN_KEY|ACCESS_TOKEN|AUTH_TOKEN|API_TOKEN|BOT_TOKEN"
)
SAFE_NAME_RE = re.compile(
    r"ANON|PUBLISHABLE|PUBLIC_KEY|SITE_KEY|_URL$|_URI$|_ENDPOINT$|_HOST$|MEASUREMENT_ID|APP_ID|PROJECT_ID|"
    r"AUTH_DOMAIN|STORAGE_BUCKET|SENDER_ID|DSN|_MODEL$|_REGION$|_ORG(ANIZATION)?(_ID)?$"
)
PUBLIC_ASSIGN_RE = re.compile(
    rf"""(?<![\w.])(?P<name>(?:{_PREFIX_ALT})_[A-Z0-9_]+)["']?[ \t]*[:=][ \t]*["'`]?(?P<value>[^\s"'`#,;]*)"""
)
PUBLIC_REF_RE = re.compile(
    rf"""(?:process\.env|import\.meta\.env)(?:\.|\[\s*["'])(?P<name>(?:{_PREFIX_ALT})_[A-Z0-9_]+)"""
)
FIREBASE_CONTEXT_RE = re.compile(r"firebase|authDomain|messagingSenderId", re.I)


def is_secret_env_name(name: str) -> bool:
    upper = name.upper()
    return bool(SECRET_NAME_RE.search(upper)) and not SAFE_NAME_RE.search(upper)


def public_prefix(name: str) -> str | None:
    for p in PUBLIC_PREFIXES:
        if name.startswith(p):
            return p
    return None


# --------------------------------------------------------------------- JWTs
def b64url_decode(segment: str) -> bytes:
    segment = segment.strip()
    padding = "=" * (-len(segment) % 4)
    return base64.urlsafe_b64decode(segment + padding)


def decode_jwt(token: str) -> tuple[dict, dict] | None:
    """Decode a JWT's header and payload without verifying the signature."""
    parts = token.strip().split(".")
    if len(parts) != 3:
        return None
    try:
        header = json.loads(b64url_decode(parts[0]))
        payload = json.loads(b64url_decode(parts[1]))
    except (ValueError, binascii.Error, UnicodeDecodeError):
        return None
    if not isinstance(header, dict) or not isinstance(payload, dict):
        return None
    return header, payload


def jwt_role(token: str) -> str | None:
    decoded = decode_jwt(token)
    if not decoded:
        return None
    role = decoded[1].get("role")
    return role if isinstance(role, str) else None


def jwt_ref(token: str) -> str | None:
    decoded = decode_jwt(token)
    if not decoded:
        return None
    ref = decoded[1].get("ref")
    return ref if isinstance(ref, str) else None


# ------------------------------------------------------------------- finder
@dataclass
class SecretHit:
    rule_id: str
    start: int
    end: int
    value: str
    severity: str | None = None  # override of the rule's default severity

    def overlaps(self, other: "SecretHit") -> bool:
        return self.start < other.end and other.start < self.end


def _password_hit(m: re.Match) -> bool:
    raw_name = m.group("name")
    name = raw_name.lower()
    value = m.group("key")
    words = {w.lower() for w in re.findall(r"[A-Z]?[a-z]+|[A-Z]+(?![a-z])|\d+", raw_name)}
    if words & set(PASSWORD_NAME_EXCLUDE):
        return False
    if is_placeholder(value):
        return False
    low = value.lower()
    if low.startswith(("process.env", "import.meta", "deno.env", "env(", "${", "{{", "%", "$", "/", "http")):
        return False
    if re.fullmatch(r"[A-Z0-9_]+", value):  # names of other env vars
        return False
    if value.isalpha():  # labels such as "Passwort"
        return False
    if low == name.strip("._-"):
        return False
    return True


def find_secrets(text: str) -> list[SecretHit]:
    """Return every secret-looking value in ``text`` (provider keys, JWTs, private keys, passwords)."""
    hits: list[SecretHit] = []
    key_blocks: list[SecretHit] = []
    for m in PRIVATE_KEY_RE.finditer(text):
        header = f"-----BEGIN {m.group('kind')}-----"
        key_blocks.append(SecretHit("SS-SECRET-PRIVATE-KEY", m.start(), m.end(), header))
    hits.extend(key_blocks)

    def inside_key_block(start: int, end: int) -> bool:
        return any(b.start <= start and end <= b.end for b in key_blocks)

    firebase_context = bool(FIREBASE_CONTEXT_RE.search(text))
    for pat in SECRET_PATTERNS:
        for m in pat.regex.finditer(text):
            value = m.group(pat.group)
            start, end = m.span(pat.group)
            if inside_key_block(start, end) or is_placeholder(value):
                continue
            if pat.validator and not pat.validator(value):
                continue
            severity = None
            if pat.rule_id == "SS-SECRET-GOOGLE" and firebase_context:
                severity = "low"
            hits.append(SecretHit(pat.rule_id, start, end, value, severity))

    for m in JWT_RE.finditer(text):
        token = m.group("key")
        role = jwt_role(token)
        if role == "service_role":
            hits.append(SecretHit("SS-SUPABASE-SERVICE-ROLE", m.start("key"), m.end("key"), token))
        elif role == "anon":
            hits.append(SecretHit("SS-SUPABASE-ANON-KEY", m.start("key"), m.end("key"), token))
    for m in SB_PUBLISHABLE_RE.finditer(text):
        hits.append(SecretHit("SS-SUPABASE-ANON-KEY", m.start("key"), m.end("key"), m.group("key")))

    for m in PASSWORD_RE.finditer(text):
        if not _password_hit(m):
            continue
        hit = SecretHit("SS-SECRET-PASSWORD", m.start("key"), m.end("key"), m.group("key"))
        if inside_key_block(hit.start, hit.end) or any(hit.overlaps(h) for h in hits):
            continue
        hits.append(hit)

    hits.sort(key=lambda h: h.start)
    return hits


# Quoted values assigned to secret-sounding names (apiKey: "...", token = '...'). Used to mask evidence
# even when the value doesn't match a known provider pattern.
SENSITIVE_ASSIGN_RE = re.compile(
    r"""(?<![A-Za-z0-9_])(?P<name>[A-Za-z0-9_\-]*(?:api[_\-]?key|token|secret|passw(?:or)?d|pwd|authorization|auth(?![a-z]))"""
    r"""[A-Za-z0-9_\-]*)["']?\s*[:=]\s*(?P<q>["'`])(?P<value>[^"'`\n]+)(?:(?P=q)|$)""",
    re.I,
)
SENSITIVE_NAME_EXCLUDE = ("domain", "url", "uri", "endpoint", "host", "label", "placeholder", "type", "name")
# A long literal API key in browser code: apiKey: "Zx9Q...". Known provider keys are matched elsewhere.
CLIENT_APIKEY_RE = re.compile(r"""(?<![A-Za-z0-9_])api[_\-]?key["']?\s*[:=]\s*["'`](?P<key>[A-Za-z0-9_\-.]{20,})["'`]""", re.I)


def mask_sensitive_assignments(text: str) -> str:
    """Mask quoted values assigned to names like apiKey, token, secret or password."""

    def repl(m: re.Match) -> str:
        value = m.group("value")
        name = m.group("name").lower()
        if (ELLIPSIS in value or len(value.strip()) < 4 or any(w in name for w in SENSITIVE_NAME_EXCLUDE)
                or value.startswith(("process.env", "import.meta", "Deno.env", "${"))):
            return m.group(0)
        s, e = m.span("value")
        return m.group(0)[: s - m.start()] + redact(value) + m.group(0)[e - m.start():]

    return SENSITIVE_ASSIGN_RE.sub(repl, text)


def find_client_api_keys(text: str) -> list[tuple[int, str]]:
    """(offset, value) of long literal ``apiKey: "..."`` values that no provider pattern recognises."""
    known = find_secrets(text)
    out = []
    for m in CLIENT_APIKEY_RE.finditer(text):
        value = m.group("key")
        s, e = m.span("key")
        if is_placeholder(value) or not _letter_digit(value) or any(h.start < e and s < h.end for h in known):
            continue
        if value.startswith(("pk_", "sb_publishable_", "phc_")) or JWT_RE.fullmatch(value):
            continue  # public by design
        out.append((s, value))
    return out


def scrub(text: str) -> str:
    """Redact every secret-looking value in a piece of text (used for evidence snippets)."""
    if not text:
        return text
    spans: list[tuple[int, int, str]] = []
    for h in find_secrets(text):
        replacement = h.value if h.rule_id == "SS-SECRET-PRIVATE-KEY" else redact(h.value)
        spans.append((h.start, h.end, replacement))
    # Be aggressive: anything shaped like a key or JWT gets redacted even if it failed validation.
    for pat in SECRET_PATTERNS + [SecretPattern("jwt", JWT_RE)]:
        for m in pat.regex.finditer(text):
            s, e = m.span(pat.group)
            if not any(s < e2 and s2 < e for s2, e2, _ in spans):
                spans.append((s, e, redact(m.group(pat.group))))
    out = text
    for s, e, rep in sorted(spans, key=lambda x: x[0], reverse=True):
        out = out[:s] + rep + out[e:]
    return mask_sensitive_assignments(out)


def public_env_value_is_secret(name: str, value: str) -> bool:
    """Decide whether a NEXT_PUBLIC_/VITE_/... variable holds something that must stay private."""
    value = value.strip().strip("\"'`")
    if not value or is_placeholder(value):
        return False
    if value.startswith(("process.env", "import.meta", "${", "$", "{{")):
        return False
    for hit in find_secrets(value):
        if hit.rule_id in ("SS-SECRET-GOOGLE", "SS-SUPABASE-ANON-KEY", "SS-SECRET-PASSWORD"):
            continue
        return True
    if is_secret_env_name(name) and len(value) >= 12 and " " not in value:
        if jwt_role(value) == "anon" or value.startswith(("pk_", "sb_publishable_")):
            return False
        return True
    return False


def line_starts(text: str) -> list[int]:
    starts = [0]
    idx = text.find("\n")
    while idx != -1:
        starts.append(idx + 1)
        idx = text.find("\n", idx + 1)
    return starts


def line_of(starts: list[int], offset: int) -> int:
    """1-based line number for a character offset (binary search on ``line_starts``)."""
    lo, hi = 0, len(starts) - 1
    while lo < hi:
        mid = (lo + hi + 1) // 2
        if starts[mid] <= offset:
            lo = mid
        else:
            hi = mid - 1
    return lo + 1
