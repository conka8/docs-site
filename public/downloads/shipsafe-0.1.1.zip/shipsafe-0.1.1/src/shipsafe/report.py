"""Render a ScanResult as text, JSON, Markdown or a self-contained HTML report."""

from __future__ import annotations

import html
import json
import re
import textwrap
from datetime import datetime, timezone

from . import __version__
from .findings import SEVERITIES, ScanResult

FORMATS = ("text", "json", "md", "html")
WEIGHTS = {"critical": 30, "high": 12, "medium": 5, "low": 1, "info": 0}
SEVERITY_LABEL = {"critical": "CRITICAL", "high": "HIGH", "medium": "MEDIUM", "low": "LOW", "info": "INFO"}
SEVERITY_COLOR = {"critical": "#b91c1c", "high": "#c2410c", "medium": "#a16207", "low": "#2563eb", "info": "#6b7280"}
DEFAULT_BRAND_COLOR = "#4f46e5"
NO_FINDINGS = "No problems found by shipsafe's checks."
SCOPE_NOTE = (
    "shipsafe runs a fixed set of checks for common launch mistakes. "
    "A clean result is not a full security audit or proof that the app is secure."
)
_COLOR_RE = re.compile(r"^(?:#[0-9a-fA-F]{3,8}|[a-zA-Z]{3,20})$")


def score_and_grade(result: ScanResult) -> tuple[int, str]:
    counts = result.counts()
    score = max(0, 100 - sum(WEIGHTS[s] * n for s, n in counts.items()))
    if score >= 90:
        grade = "A"
    elif score >= 80:
        grade = "B"
    elif score >= 70:
        grade = "C"
    elif score >= 60:
        grade = "D"
    else:
        grade = "F"
    if counts["critical"]:
        grade = "F"
    elif counts["high"] and grade in ("A", "B"):
        grade = "C"
    return score, grade


def verdict(grade: str) -> str:
    return {
        "A": "No serious problems found by shipsafe's checks.",
        "B": "Nearly there: fix the items below when you can.",
        "C": "Fix the high-priority items before you launch.",
        "D": "Several serious problems: fix these before you launch.",
        "F": "Do not launch yet: fix the critical items first.",
    }[grade]


def is_valid_color(color: str) -> bool:
    return bool(_COLOR_RE.match(color or ""))


def is_valid_logo_url(url: str) -> bool:
    return url.startswith(("https://", "http://", "data:image/"))


def _summary_dict(result: ScanResult) -> dict:
    score, grade = score_and_grade(result)
    return {"score": score, "grade": grade, "verdict": verdict(grade), "counts": result.counts()}


# ---------------------------------------------------------------------- text
def render_text(result: ScanResult) -> str:
    s = _summary_dict(result)
    lines = [
        f"shipsafe {__version__} - launch safety check",
        f"Target: {result.target}",
        f"Grade:  {s['grade']}  (score {s['score']}/100)  {s['verdict']}",
        "Found:  " + ", ".join(f"{n} {sev}" for sev, n in s["counts"].items()),
        "",
    ]
    if not result.findings:
        lines.append(NO_FINDINGS)
    wrap = lambda t, ind: textwrap.fill(t, width=100, initial_indent=ind, subsequent_indent=ind)  # noqa: E731
    for i, f in enumerate(result.findings, 1):
        lines.append(f"{i}. [{SEVERITY_LABEL[f.severity]}] {f.title}  ({f.rule_id})")
        lines.append(f"   Where: {f.location}")
        if f.evidence:
            lines.append(f"   Found: {f.evidence}")
        lines.append(wrap("Why it matters: " + f.why, "   "))
        lines.append("   Fix prompt (copy the next line and paste it into your AI coding tool):")
        lines.append("     " + " ".join(f.fix_prompt.split()))
        lines.append("")
    if result.notes:
        lines.append("Notes:")
        lines.extend(f"  - {n}" for n in result.notes)
    lines.append(_scan_stats(result))
    lines.append(SCOPE_NOTE)
    return "\n".join(lines).rstrip() + "\n"


def _scan_stats(result: ScanResult) -> str:
    noun = "file(s)" if result.mode == "scan" else "page/script(s)"
    parts = [f"Checked {result.files_scanned} {noun}"]
    if result.skipped:
        parts.append("skipped " + ", ".join(f"{v} {k.replace('_', ' ')}" for k, v in sorted(result.skipped.items())))
    return "; ".join(parts) + "."


# ---------------------------------------------------------------------- json
def render_json(result: ScanResult) -> str:
    data = {
        "tool": "shipsafe",
        "version": __version__,
        "target": result.target,
        "mode": result.mode,
        **_summary_dict(result),
        "files_scanned": result.files_scanned,
        "skipped": result.skipped,
        "notes": result.notes,
        "findings": [f.to_dict() for f in result.findings],
    }
    return json.dumps(data, indent=2, ensure_ascii=False) + "\n"


# ------------------------------------------------------------------ markdown
def _md_cell(text: str) -> str:
    return text.replace("|", "\\|").replace("\n", " ")


def render_markdown(result: ScanResult) -> str:
    s = _summary_dict(result)
    out = [
        f"# shipsafe report: grade {s['grade']} ({s['score']}/100)",
        "",
        f"**Target:** `{result.target}`  ",
        f"**Verdict:** {s['verdict']}",
        "",
        "| Severity | Count |",
        "|---|---|",
    ]
    out += [f"| {sev} | {n} |" for sev, n in s["counts"].items()]
    out.append("")
    if not result.findings:
        out.append(NO_FINDINGS)
    else:
        out += ["| # | Severity | Problem | Where |", "|---|---|---|---|"]
        for i, f in enumerate(result.findings, 1):
            out.append(f"| {i} | {f.severity} | {_md_cell(f.title)} | `{_md_cell(f.location)}` |")
        out.append("")
    for i, f in enumerate(result.findings, 1):
        out += [
            f"## {i}. {f.title}",
            "",
            f"- **Severity:** {f.severity}",
            f"- **Rule:** `{f.rule_id}`",
            f"- **Where:** `{f.location}`",
        ]
        if f.evidence:
            out.append(f"- **Found:** `{f.evidence.replace('`', chr(39))}`")
        out += ["", f"**Why it matters:** {f.why}", "", "**Fix prompt** (paste into your AI coding tool):", "",
                "```text", f.fix_prompt.replace("```", "'''"), "```", ""]
    if result.notes:
        out += ["## Notes", ""] + [f"- {n}" for n in result.notes] + [""]
    out.append(f"_{_scan_stats(result)} Generated by shipsafe {__version__}._")
    out += ["", f"_{SCOPE_NOTE}_"]
    return "\n".join(out) + "\n"


# ---------------------------------------------------------------------- html
_CSS = """
:root{--brand:%(brand)s;--ink:#111827;--muted:#4b5563;--line:#e5e7eb;--bg:#f9fafb}
*{box-sizing:border-box}body{margin:0;font:15px/1.55 -apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Helvetica,Arial,sans-serif;color:var(--ink);background:var(--bg)}
header{background:var(--brand);color:#fff;padding:24px 16px}header .wrap{display:flex;gap:16px;align-items:center}
header img{max-height:44px;max-width:160px;background:#fff;border-radius:6px;padding:4px}
header h1{margin:0;font-size:22px}header p{margin:2px 0 0;opacity:.9;word-break:break-all}
.wrap{max-width:900px;margin:0 auto;padding:0 16px}
.summary{display:flex;flex-wrap:wrap;gap:16px;align-items:center;background:#fff;border:1px solid var(--line);border-radius:12px;padding:20px;margin:20px 0}
.grade{width:84px;height:84px;border-radius:50%%;display:flex;align-items:center;justify-content:center;font-size:44px;font-weight:700;color:#fff;flex:none}
.g-A{background:#15803d}.g-B{background:#4d7c0f}.g-C{background:#a16207}.g-D{background:#c2410c}.g-F{background:#b91c1c}
.verdict{font-size:18px;font-weight:600;margin:0 0 6px}.chips{display:flex;flex-wrap:wrap;gap:6px}
.chip{border-radius:999px;padding:2px 10px;font-size:13px;font-weight:600;color:#fff}
.sev-critical{background:#b91c1c}.sev-high{background:#c2410c}.sev-medium{background:#a16207}.sev-low{background:#2563eb}.sev-info{background:#6b7280}
.finding{background:#fff;border:1px solid var(--line);border-left:6px solid var(--sev);border-radius:10px;padding:16px;margin:14px 0;break-inside:avoid}
.finding h2{font-size:17px;margin:6px 0}.meta{color:var(--muted);font-size:13px;word-break:break-all}
code{background:#f3f4f6;border-radius:4px;padding:1px 5px;font-size:13px;word-break:break-all}
.fixbox{position:relative;margin-top:10px}.fixbox pre{white-space:pre-wrap;word-wrap:break-word;background:#f3f4f6;border:1px solid var(--line);border-radius:8px;padding:12px;margin:6px 0 0;font:13px/1.5 ui-monospace,SFMono-Regular,Menlo,Consolas,monospace}
button.copy{background:var(--brand);color:#fff;border:0;border-radius:6px;padding:6px 12px;font-weight:600;cursor:pointer}
.notes{color:var(--muted);font-size:14px}footer{color:var(--muted);font-size:13px;padding:20px 0 40px}
@media print{body{background:#fff}button.copy{display:none}header{-webkit-print-color-adjust:exact;print-color-adjust:exact}.finding{border-left-width:4px}}
"""

_JS = """
function copyFix(id,btn){var t=document.getElementById(id).innerText;
function done(){var o=btn.textContent;btn.textContent='Copied!';setTimeout(function(){btn.textContent=o},1500)}
if(navigator.clipboard){navigator.clipboard.writeText(t).then(done,function(){sel(id);})}else{sel(id)}}
function sel(id){var r=document.createRange();r.selectNodeContents(document.getElementById(id));var s=window.getSelection();s.removeAllRanges();s.addRange(r)}
"""


def render_html(result: ScanResult, brand_name: str = "", brand_color: str = "", logo_url: str = "") -> str:
    e = html.escape
    s = _summary_dict(result)
    color = brand_color if is_valid_color(brand_color) else DEFAULT_BRAND_COLOR
    title_brand = brand_name.strip() or "shipsafe"
    logo = f'<img src="{e(logo_url, quote=True)}" alt="logo">' if logo_url and is_valid_logo_url(logo_url) else ""
    chips = "".join(
        f'<span class="chip sev-{sev}">{n} {sev}</span>' for sev, n in s["counts"].items() if n or sev != "info"
    )
    cards = []
    for i, f in enumerate(result.findings, 1):
        evidence = f'<div class="meta">Found: <code>{e(f.evidence)}</code></div>' if f.evidence else ""
        cards.append(
            f'<section class="finding" style="--sev:{SEVERITY_COLOR[f.severity]}">'
            f'<span class="chip sev-{f.severity}">{SEVERITY_LABEL[f.severity]}</span> '
            f'<span class="meta">{e(f.rule_id)}</span>'
            f"<h2>{i}. {e(f.title)}</h2>"
            f'<div class="meta">Where: <code>{e(f.location)}</code></div>{evidence}'
            f"<p><strong>Why it matters:</strong> {e(f.why)}</p>"
            f'<div class="fixbox"><strong>Fix prompt</strong> (paste into your AI coding tool) '
            f'<button class="copy" type="button" onclick="copyFix(\'fix-{i}\',this)">Copy fix prompt</button>'
            f'<pre id="fix-{i}">{e(f.fix_prompt)}</pre></div></section>'
        )
    if not cards:
        cards.append(f'<section class="finding" style="--sev:#15803d"><h2>{e(NO_FINDINGS)}</h2></section>')
    notes = ""
    if result.notes:
        notes = '<div class="notes"><h3>Notes</h3><ul>' + "".join(f"<li>{e(n)}</li>" for n in result.notes) + "</ul></div>"
    generated = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")
    by = f"{e(brand_name.strip())} &middot; " if brand_name.strip() else ""
    return (
        "<!DOCTYPE html>\n<html lang=\"en\"><head><meta charset=\"utf-8\">"
        '<meta name="viewport" content="width=device-width,initial-scale=1">'
        f"<title>{e(title_brand)} launch safety report</title>"
        f"<style>{_CSS % {'brand': color}}</style></head><body>"
        f'<header><div class="wrap">{logo}<div><h1>{e(title_brand)} launch safety report</h1>'
        f"<p>{e(result.target)}</p></div></div></header>"
        '<main class="wrap">'
        f'<div class="summary"><div class="grade g-{s["grade"]}">{s["grade"]}</div><div>'
        f'<p class="verdict">{e(s["verdict"])}</p><p class="meta">Score {s["score"]}/100</p>'
        f'<div class="chips">{chips}</div></div></div>'
        + "".join(cards)
        + notes
        + f"<footer>{by}{e(_scan_stats(result))} Generated {generated} by shipsafe {__version__}. "
        "Automated checks catch common mistakes but are not a full security audit.</footer>"
        f"</main><script>{_JS}</script></body></html>\n"
    )


def render(result: ScanResult, fmt: str = "text", **branding: str) -> str:
    if fmt == "text":
        return render_text(result)
    if fmt == "json":
        return render_json(result)
    if fmt == "md":
        return render_markdown(result)
    if fmt == "html":
        return render_html(result, **branding)
    raise ValueError(f"Unknown format {fmt!r}; choose one of {', '.join(FORMATS)}")


__all__ = ["render", "render_text", "render_json", "render_markdown", "render_html", "score_and_grade", "SEVERITIES"]
