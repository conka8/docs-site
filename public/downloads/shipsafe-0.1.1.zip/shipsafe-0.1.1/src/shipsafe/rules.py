"""The rule catalog: every check shipsafe can report, in plain English.

Each rule has a default severity, a title, a one-or-two sentence "why this matters"
and a fix prompt the user can paste into their AI coding tool (Lovable, Bolt,
Cursor, Claude Code...). Fix prompts use ``{placeholders}`` filled per finding.
"""

from __future__ import annotations

import hashlib
from dataclasses import dataclass

from .findings import Finding

ENV_PREFIX_TEXT = "NEXT_PUBLIC_, VITE_, REACT_APP_ or EXPO_PUBLIC_"


@dataclass(frozen=True)
class Rule:
    id: str
    severity: str
    title: str
    why: str
    fix: str
    category: str


def _secret_rule(rule_id: str, severity: str, provider: str, env_name: str, rotate_where: str, why: str) -> Rule:
    fix = (
        f"My {provider} secret is hard-coded in {{location}}. Please remove it from the code and read it "
        f"from a server-only environment variable called {env_name} (no {ENV_PREFIX_TEXT} prefix, because "
        f"those prefixes ship the value to every visitor's browser). Only use it inside server code such as "
        f"API routes or server functions, never in components or pages that run in the browser. Make sure "
        f".env files are listed in .gitignore. Then give me step-by-step instructions to rotate (revoke and "
        f"recreate) this key in {rotate_where}, because the old key must be treated as leaked."
    )
    return Rule(rule_id, severity, f"{provider} key found in your code", why, fix, "secrets")


_RULES: list[Rule] = [
    # ------------------------------------------------------------------ secrets
    _secret_rule(
        "SS-SECRET-OPENAI", "critical", "OpenAI", "OPENAI_API_KEY", "the OpenAI dashboard (API keys page)",
        "Anyone who finds this key can copy it and run up your OpenAI bill. Keys left in code or in your "
        "website's JavaScript are found by bots within hours.",
    ),
    _secret_rule(
        "SS-SECRET-ANTHROPIC", "critical", "Anthropic (Claude)", "ANTHROPIC_API_KEY",
        "the Anthropic Console (API keys page)",
        "Anyone who finds this key can use Claude on your account and you pay the bill.",
    ),
    _secret_rule(
        "SS-SECRET-STRIPE-LIVE", "critical", "Stripe live", "STRIPE_SECRET_KEY", "the Stripe dashboard (Developers > API keys)",
        "A live Stripe secret key lets someone issue refunds, read your customers' details and move money "
        "on your account.",
    ),
    Rule(
        "SS-SECRET-STRIPE-TEST", "low", "Stripe test key found in your code",
        "Test keys can't move real money, but they show where your real keys will end up. Keep them out of "
        "the code too so you don't swap in a live key later by accident.",
        "There is a Stripe test key hard-coded in {location}. Please move it to a server-only environment "
        "variable called STRIPE_SECRET_KEY and read it with process.env on the server. Do not change any "
        "payment logic.",
        "secrets",
    ),
    _secret_rule(
        "SS-SECRET-AWS", "critical", "AWS", "AWS_ACCESS_KEY_ID / AWS_SECRET_ACCESS_KEY",
        "the AWS console (IAM > Users > Security credentials)",
        "An AWS access key can be used to start expensive servers or read your files on your account.",
    ),
    _secret_rule(
        "SS-SECRET-GITHUB", "critical", "GitHub", "GITHUB_TOKEN", "GitHub (Settings > Developer settings > Tokens)",
        "A GitHub token can let someone read or change your private code.",
    ),
    Rule(
        "SS-SECRET-GOOGLE", "medium", "Google API key found in your code",
        "Google keys (including Firebase web keys) are often meant to be public, but an unrestricted key "
        "can be used by anyone for paid Google APIs such as Maps or Gemini on your bill.",
        "A Google API key is in {location}. If it is a Firebase web config key, leave it in place but tell "
        "me step by step how to restrict it in Google Cloud Console (APIs & Services > Credentials) to my "
        "website's domain and only the APIs I use. If it is a Gemini or other paid API key, move it to a "
        "server-only environment variable and make the API call from a server route instead of the browser.",
        "secrets",
    ),
    _secret_rule(
        "SS-SECRET-SLACK", "high", "Slack", "SLACK_BOT_TOKEN (or SLACK_WEBHOOK_URL)", "your Slack app settings",
        "A Slack token or webhook lets anyone post messages into your workspace, or read it.",
    ),
    _secret_rule(
        "SS-SECRET-SENDGRID", "critical", "SendGrid", "SENDGRID_API_KEY", "the SendGrid dashboard (Settings > API Keys)",
        "Spammers love leaked email keys: they can send mail as you and get your domain blacklisted.",
    ),
    _secret_rule(
        "SS-SECRET-TWILIO", "high", "Twilio", "TWILIO_AUTH_TOKEN / TWILIO_API_KEY",
        "the Twilio console (Account > API keys & tokens)",
        "A Twilio key lets someone send SMS or make calls on your account, which can cost a lot quickly.",
    ),
    Rule(
        "SS-SECRET-PRIVATE-KEY", "critical", "Private key file committed in your project",
        "A private key is like the master password for a server or service account. Anyone with it can "
        "pretend to be you.",
        "A private key is stored in {location}. Please remove this file (or the key inside it) from the "
        "project, add the file name to .gitignore, and load the key at runtime from an environment variable "
        "on the server instead. Then tell me how to generate a new key and revoke the old one, because it "
        "has to be treated as leaked.",
        "secrets",
    ),
    Rule(
        "SS-SECRET-PASSWORD", "low", "Password or secret written directly in the code",
        "Passwords in code end up in Git history and in screenshots. If this is a real password, change it.",
        "There is a hard-coded password or secret value in {location}. Please move it to a server-only "
        "environment variable, read it with process.env (or Deno.env.get in edge functions), and remove the "
        "literal value from the code.",
        "secrets",
    ),
    Rule(
        "SS-SECRET-CLIENT-APIKEY", "medium", "API key written directly in browser code",
        "This file runs in the visitor's browser, so anyone can copy this key. Some keys are public by design "
        "(for example search-only or map keys); a secret key here can be used on your account and your bill.",
        "There is an API key written directly in browser code in {location}. If it is a secret key, please move "
        "the call that uses it into a server route that reads the key from a server-only environment variable "
        "(no {prefixes} prefix), and have the browser call my route instead. Then tell me how to rotate the "
        "old key in the provider's dashboard. If the provider says this key is meant to be public, tell me so "
        "and add a // shipsafe-ignore SS-SECRET-CLIENT-APIKEY comment on that line.",
        "secrets",
    ),
    # ----------------------------------------------------------------- supabase
    Rule(
        "SS-SUPABASE-SERVICE-ROLE", "critical", "Supabase service_role key is exposed",
        "The service_role key skips all your database security rules (RLS). Anyone who has it can read, "
        "change or delete every row in every table.",
        "My Supabase service_role key is exposed in {location}. Please remove it from all browser code and "
        "public environment variables. The browser must only use the anon (public) key via "
        "NEXT_PUBLIC_SUPABASE_ANON_KEY or VITE_SUPABASE_ANON_KEY. If some code really needs admin access, "
        "move it into a server-only API route or a Supabase Edge Function that reads SUPABASE_SERVICE_ROLE_KEY "
        "from a server-only environment variable and checks the user is logged in first. Then tell me how "
        "to roll the service_role key (JWT secret / API keys) in the Supabase dashboard.",
        "supabase",
    ),
    Rule(
        "SS-SUPABASE-ANON-KEY", "info", "Supabase anon (public) key found",
        "This is the public key and it is fine for it to be in your website. Your data is protected only by "
        "Row Level Security policies, so make sure every table has them.",
        "No change needed for the anon key itself. Please double-check that every table in my Supabase "
        "database has Row Level Security enabled with policies that only let users see their own data.",
        "supabase",
    ),
    Rule(
        "SS-RLS-MISSING", "high", "Database table without Row Level Security: {table}",
        "Without Row Level Security, anyone with your public anon key (which is in your website) can read "
        "and change every row in this table, for example all your users' data.",
        "In my Supabase database the table \"{table}\" (created in {location}) does not have Row Level "
        "Security enabled. Please write a new SQL migration that runs "
        "\"alter table {table} enable row level security;\" and adds policies so that logged-in users can "
        "only select, insert, update and delete their own rows (for example using auth.uid() = user_id). "
        "Explain each policy in one sentence.",
        "supabase",
    ),
    Rule(
        "SS-RLS-NO-POLICY", "medium", "Row Level Security is on but there are no policies: {table}",
        "With RLS on and no policies, nobody can read or write this table through the API, not even your "
        "own logged-in users. That's safe but usually means parts of your app silently show no data.",
        "The Supabase table \"{table}\" (in {location}) has Row Level Security enabled but no policies, so "
        "the app cannot read or write it. Please add a migration with policies that let each logged-in "
        "user access only their own rows (auth.uid() = user_id), or tell me if this table is meant to be "
        "used only from the server.",
        "supabase",
    ),
    Rule(
        "SS-RLS-OPEN-POLICY", "high", "Database policy lets anyone change data: {table}",
        "A policy with \"using (true)\" or \"with check (true)\" on insert, update or delete means anyone "
        "can add, edit or wipe rows in this table, not just the owner.",
        "In {location} the Supabase policy on \"{table}\" uses (true) for {command}, which lets anyone do "
        "this to any row. Please replace it with a policy that only allows the row's owner, for example "
        "\"using (auth.uid() = user_id)\" and \"with check (auth.uid() = user_id)\", in a new migration. "
        "Keep public read access only if the app really needs it.",
        "supabase",
    ),
    Rule(
        "SS-STORAGE-PUBLIC-BUCKET", "medium", "Public storage bucket",
        "Files in a public bucket can be downloaded by anyone who has (or guesses) the link. That's fine "
        "for logos, not for invoices, IDs or private uploads.",
        "A Supabase storage bucket is created as public in {location}. If it holds user uploads or private "
        "files, please make it private and serve files with signed URLs (createSignedUrl) after checking "
        "the user is allowed to see them. If it only holds public images, tell me so and leave it.",
        "supabase",
    ),
    # ---------------------------------------------------------- env / git files
    Rule(
        "SS-PUBLIC-ENV-SECRET", "critical", "Secret key in a public environment variable: {name}",
        "Variables starting with NEXT_PUBLIC_, VITE_, REACT_APP_ or EXPO_PUBLIC_ are copied into the "
        "JavaScript every visitor downloads, so this secret is visible to the whole internet.",
        "The environment variable {name} (in {location}) holds a secret, but its prefix makes it public in "
        "the browser. Please rename it without the public prefix, use it only in server code (API routes, "
        "server actions or edge functions), and change any browser code that used it to call that server "
        "route instead. Then tell me how to rotate this key, because it has already been exposed.",
        "env",
    ),
    Rule(
        "SS-PUBLIC-ENV-SECRET-NAME", "high", "Browser code reads a secret-looking public variable: {name}",
        "Your browser code uses {name}. Because of the public prefix, whatever key you put in it is shipped "
        "to every visitor and can be copied.",
        "My browser code in {location} reads {name}. Please move the call that needs this key into a server "
        "route (for example app/api/.../route.ts or a Supabase Edge Function), read the key there from a "
        "server-only variable without the {prefixes} prefix, and have the browser call my own route instead.",
        "env",
    ),
    Rule(
        "SS-ENV-NOT-IGNORED", "high", "Your {file} file is not in .gitignore",
        "Files like .env hold your passwords and API keys. If they are not ignored, they get uploaded to "
        "GitHub with your code, where bots scan for keys all day.",
        "Please add {file} (and every .env* file except .env.example) to my .gitignore. If {file} was "
        "already committed, give me the git commands to remove it from the repository without deleting my "
        "local copy (git rm --cached), and remind me to rotate every key that was inside it.",
        "env",
    ),
    Rule(
        "SS-GITIGNORE-MISSING", "medium", "No .gitignore file",
        "Without a .gitignore, secret files like .env and huge folders like node_modules get uploaded "
        "with your code.",
        "My project has no .gitignore file. Please create one suited to this project that ignores "
        "node_modules, build output (dist, build, .next), log files and all .env* files except .env.example.",
        "env",
    ),
    # ------------------------------------------------------------ AI endpoints
    Rule(
        "SS-AI-ENDPOINT-NO-AUTH", "high", "AI endpoint with no login check",
        "Anyone on the internet can call this endpoint and use your {provider} credits. People find these "
        "routes and use them as free AI.",
        "My server route {location} calls {provider} but never checks who is calling it. Please add an "
        "authentication check at the very top of the handler (for example with Supabase "
        "supabase.auth.getUser(), Clerk auth(), or NextAuth getServerSession()) and return a 401 error when "
        "there is no logged-in user. Don't change the AI logic itself.",
        "ai",
    ),
    Rule(
        "SS-AI-ENDPOINT-NO-RATELIMIT", "medium", "AI endpoint with no rate limit (cost blow-up risk)",
        "Even logged-in users (or a bug in a loop) can call this route thousands of times and leave you "
        "with a huge {provider} bill overnight.",
        "My server route {location} calls {provider} without any rate limiting. Please add a per-user (or "
        "per-IP) rate limit, for example with @upstash/ratelimit (10 requests per minute), returning a 429 "
        "error when it is exceeded. Also set a monthly spending limit in my {provider} dashboard and tell "
        "me where that setting is.",
        "ai",
    ),
    Rule(
        "SS-AI-CALL-FROM-BROWSER", "high", "Your app calls the AI provider straight from the browser",
        "To call {provider} from the browser, the API key has to be in the browser too, where anyone can "
        "open developer tools and copy it.",
        "My app calls {provider} directly from browser code in {location}. Please move this call into a "
        "server route (Next.js app/api/.../route.ts, a Supabase Edge Function or a Netlify/Vercel function) "
        "that reads the API key from a server-only environment variable, checks the user is logged in, and "
        "returns only the result. Update the browser code to call my route instead and remove "
        "dangerouslyAllowBrowser if it is set.",
        "ai",
    ),
    Rule(
        "SS-ADMIN-NO-AUTH", "high", "Admin page or route with no login check",
        "If an admin page doesn't check who's visiting, anyone who types the address can see or change "
        "admin data.",
        "The admin page/route {location} has no authentication or role check. Please protect it so only "
        "logged-in users with an admin role can open it: check the session on the server (middleware, a "
        "layout, or at the top of the route), and redirect or return 403 for everyone else. Store the "
        "admin role in the database, not in the browser.",
        "auth",
    ),
    # ---------------------------------------------------------------- firebase
    Rule(
        "SS-FIREBASE-OPEN-RULES", "critical", "Firebase rules let anyone write to your database or storage",
        "With these rules anyone on the internet can add, change or delete your data or files, no login "
        "needed.",
        "My Firebase security rules in {location} allow writes for everyone. Please rewrite them so users "
        "must be signed in (request.auth != null) and can only write their own documents/files (for "
        "example request.auth.uid == userId). Explain each rule in one sentence and tell me how to deploy "
        "them with firebase deploy --only firestore:rules,storage.",
        "firebase",
    ),
    Rule(
        "SS-FIREBASE-TEST-MODE", "high", "Firebase is still in \"test mode\"",
        "Test-mode rules let anyone read and write everything until a date, and then lock everyone out, "
        "including your own app.",
        "My Firebase rules in {location} still use the test-mode rule \"if request.time < ...\". Please "
        "replace it with real rules that require sign-in (request.auth != null) and only let users access "
        "their own data, then tell me how to deploy the new rules.",
        "firebase",
    ),
    Rule(
        "SS-FIREBASE-PUBLIC-READ", "medium", "Firebase rules let anyone read data",
        "Anyone can download everything covered by this rule. That's fine for public blog posts, not for "
        "user profiles, orders or messages.",
        "My Firebase rules in {location} allow public reads. Please limit reads to signed-in users and to "
        "their own data, unless this collection is truly meant to be public. Tell me which collections "
        "you kept public and why.",
        "firebase",
    ),
    # --------------------------------------------------------------- web misc
    Rule(
        "SS-CORS-WILDCARD-CREDENTIALS", "medium", "CORS allows any website, with credentials",
        "Allowing every website (*) together with cookies/credentials can let other sites make requests "
        "as your logged-in users, or the browser will block it and your app breaks.",
        "In {location} my CORS setup allows origin \"*\" together with credentials. Please replace \"*\" "
        "with an explicit list of my own domains (production and localhost for development) and keep "
        "credentials only if the app needs cookies.",
        "web",
    ),
    Rule(
        "SS-XSS-INNERHTML", "low", "Raw HTML is inserted into the page",
        "If this HTML ever contains text written by a user, they could run their own JavaScript on your "
        "site and steal other users' sessions.",
        "In {location} my code inserts raw HTML (dangerouslySetInnerHTML / innerHTML). If that content can "
        "come from users or the database, please sanitize it with DOMPurify before inserting it, or render "
        "it as plain text instead.",
        "web",
    ),
    # ------------------------------------------------------------------ URL mode
    Rule(
        "SS-EXPOSED-FILE", "critical", "Secret file is downloadable from your website: {path}",
        "Anyone can download {path} from your live site. These files usually contain passwords and API keys.",
        "My live site serves {path} at {location}. Please make sure this file is not deployed: remove it "
        "from the public/static folder, add it to .gitignore and to the hosting ignore list, and redeploy. "
        "Then tell me how to rotate every key that was in it, because it has been public.",
        "web",
    ),
    Rule(
        "SS-HEADER-CSP", "low", "No Content-Security-Policy header",
        "A Content-Security-Policy limits what scripts can run on your site, which makes many attacks "
        "much harder.",
        "My site {location} sends no Content-Security-Policy header. Please add a starter policy in my "
        "hosting config (vercel.json headers, netlify.toml or next.config.js headers) that allows my own "
        "domain plus the services I really use (Supabase, Stripe, analytics). Start in report-only mode "
        "so nothing breaks.",
        "headers",
    ),
    Rule(
        "SS-HEADER-FRAME", "low", "Your site can be embedded in other sites (clickjacking)",
        "Without X-Frame-Options or a frame-ancestors rule, another site can show your app inside an "
        "invisible frame and trick users into clicking buttons.",
        "My site {location} has no X-Frame-Options header and no frame-ancestors in its CSP. Please add "
        "\"X-Frame-Options: DENY\" (or \"Content-Security-Policy: frame-ancestors 'none'\") in my hosting "
        "config.",
        "headers",
    ),
    Rule(
        "SS-HEADER-HSTS", "low", "No Strict-Transport-Security header",
        "HSTS tells browsers to always use HTTPS for your site, so nobody on public Wi-Fi can downgrade the "
        "connection.",
        "My site {location} has no Strict-Transport-Security header. Please add "
        "\"Strict-Transport-Security: max-age=63072000; includeSubDomains\" in my hosting config.",
        "headers",
    ),
    Rule(
        "SS-SUPABASE-TABLE-READABLE", "high", "Anyone can read the {table} table",
        "Using only the public key from your website, shipsafe was able to read rows from this table. "
        "Anyone else can do the same and download the data.",
        "My Supabase table \"{table}\" can be read by anyone with the anon key ({location}). Please enable "
        "Row Level Security on it and add a select policy that only lets users read their own rows "
        "(auth.uid() = user_id), or only public columns if the data is meant to be public.",
        "supabase",
    ),
]

RULES: dict[str, Rule] = {r.id: r for r in _RULES}


def fill(template: str, ctx: dict) -> str:
    """Replace ``{key}`` placeholders without choking on other braces."""
    for key, value in ctx.items():
        template = template.replace("{" + key + "}", str(value))
    return template


def fingerprint(raw: str) -> str:
    return hashlib.sha256(raw.encode("utf-8", "replace")).hexdigest()[:16]


def make_finding(
    rule_id: str,
    location: str,
    evidence: str = "",
    *,
    severity: str | None = None,
    file: str | None = None,
    line: int | None = None,
    raw: str = "",
    title_suffix: str = "",
    **ctx,
) -> Finding:
    rule = RULES[rule_id]
    ctx = dict(ctx)
    ctx.setdefault("location", location)
    if file is not None:
        ctx.setdefault("file", file)
    ctx.setdefault("provider", "the AI provider")
    ctx.setdefault("prefixes", ENV_PREFIX_TEXT)
    return Finding(
        rule_id=rule.id,
        severity=severity or rule.severity,
        title=fill(rule.title, ctx) + title_suffix,
        why=fill(rule.why, ctx),
        location=location,
        evidence=evidence,
        fix_prompt=fill(rule.fix, ctx),
        file=file,
        line=line,
        fingerprint=fingerprint(raw or f"{rule_id}|{location}|{evidence}"),
    )
