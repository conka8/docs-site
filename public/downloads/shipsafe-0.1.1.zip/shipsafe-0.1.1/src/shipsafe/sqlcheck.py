"""Supabase / Postgres migration checks: Row Level Security, open policies, public buckets."""

from __future__ import annotations

import re
from dataclasses import dataclass, field

from .findings import Finding
from .patterns import line_of, line_starts
from .rules import make_finding

_IDENT = r'(?:"[^"]+"|[A-Za-z_][\w$]*)'
_QUALIFIED = rf"(?P<table>{_IDENT}(?:\s*\.\s*{_IDENT})?)"

CREATE_TABLE_RE = re.compile(
    rf"\bcreate\s+(?:or\s+replace\s+)?(?:unlogged\s+)?table\s+(?:if\s+not\s+exists\s+)?{_QUALIFIED}", re.I
)
RLS_RE = re.compile(
    rf"\balter\s+table\s+(?:if\s+exists\s+)?(?:only\s+)?{_QUALIFIED}\s+(?P<action>enable|disable)\s+row\s+level\s+security",
    re.I,
)
POLICY_RE = re.compile(
    rf"\bcreate\s+policy\s+(?:\"[^\"]*\"|[\w$]+)\s+on\s+{_QUALIFIED}(?P<body>[^;]*)", re.I
)
POLICY_CMD_RE = re.compile(r"\bfor\s+(select|insert|update|delete|all)\b", re.I)
USING_TRUE_RE = re.compile(r"\busing\s*\(\s*\(?\s*true\s*\)?\s*\)", re.I)
CHECK_TRUE_RE = re.compile(r"\bwith\s+check\s*\(\s*\(?\s*true\s*\)?\s*\)", re.I)
BUCKET_INSERT_RE = re.compile(
    r"\binsert\s+into\s+storage\.buckets\s*\((?P<cols>[^)]*)\)\s*values\s*(?P<vals>[^;]*)", re.I
)
BUCKET_UPDATE_RE = re.compile(r"\bupdate\s+storage\.buckets\s+set\s+[^;]*\bpublic\s*=\s*true", re.I)
# JS / TS: supabase.storage.createBucket('x', { public: true })
CREATE_BUCKET_JS_RE = re.compile(
    r"\b(?:createBucket|updateBucket)\s*\(\s*[\"'`][^\"'`]*[\"'`]\s*,\s*\{[^}]*\bpublic\s*:\s*true", re.S
)


def strip_sql_comments(sql: str) -> str:
    """Blank out -- and /* */ comments while keeping offsets and newlines intact."""
    out = list(sql)
    i, n = 0, len(sql)
    in_str = False
    while i < n:
        c = sql[i]
        if in_str:
            if c == "'":
                in_str = False
            i += 1
            continue
        if c == "'":
            in_str = True
            i += 1
            continue
        if sql.startswith("--", i):
            j = sql.find("\n", i)
            j = n if j == -1 else j
            for k in range(i, j):
                out[k] = " "
            i = j
            continue
        if sql.startswith("/*", i):
            j = sql.find("*/", i + 2)
            j = n if j == -1 else j + 2
            for k in range(i, j):
                if out[k] != "\n":
                    out[k] = " "
            i = j
            continue
        i += 1
    return "".join(out)


def normalize_table(name: str) -> tuple[str, str]:
    """Return (schema, table) lower-cased, unquoted; schema defaults to public."""
    parts = [p.strip().strip('"') for p in re.split(r"\s*\.\s*", name.strip())]
    if len(parts) == 1:
        return "public", parts[0].lower()
    return parts[0].lower(), parts[1].lower()


@dataclass
class _Loc:
    file: str
    line: int


@dataclass
class SqlState:
    """Accumulates tables / RLS / policies across all migration files."""

    tables: dict[tuple[str, str], _Loc] = field(default_factory=dict)
    rls: dict[tuple[str, str], bool] = field(default_factory=dict)
    policies: set[tuple[str, str]] = field(default_factory=set)
    findings: list[Finding] = field(default_factory=list)

    def add_file(self, relpath: str, text: str) -> None:
        clean = strip_sql_comments(text)
        starts = line_starts(text)

        def loc(offset: int) -> _Loc:
            return _Loc(relpath, line_of(starts, offset))

        events: list[tuple[int, str, re.Match]] = []
        for m in CREATE_TABLE_RE.finditer(clean):
            events.append((m.start(), "create", m))
        for m in RLS_RE.finditer(clean):
            events.append((m.start(), "rls", m))
        for m in POLICY_RE.finditer(clean):
            events.append((m.start(), "policy", m))
        for _, kind, m in sorted(events, key=lambda e: e[0]):
            key = normalize_table(m.group("table"))
            if kind == "create":
                self.tables.setdefault(key, loc(m.start()))
            elif kind == "rls":
                self.rls[key] = m.group("action").lower() == "enable"
            else:
                self.policies.add(key)
                self._check_policy(m, key, loc(m.start()))

        for m in BUCKET_INSERT_RE.finditer(clean):
            cols = [c.strip().strip('"').lower() for c in m.group("cols").split(",")]
            if "public" in cols and re.search(r"\btrue\b", m.group("vals"), re.I):
                lo = loc(m.start())
                self.findings.append(
                    make_finding("SS-STORAGE-PUBLIC-BUCKET", f"{lo.file}:{lo.line}", _snippet(text, m.start()),
                                 file=lo.file, line=lo.line)
                )
        for m in BUCKET_UPDATE_RE.finditer(clean):
            lo = loc(m.start())
            self.findings.append(
                make_finding("SS-STORAGE-PUBLIC-BUCKET", f"{lo.file}:{lo.line}", _snippet(text, m.start()),
                             file=lo.file, line=lo.line)
            )

    def _check_policy(self, m: re.Match, key: tuple[str, str], lo: _Loc) -> None:
        body = m.group("body")
        cmd_m = POLICY_CMD_RE.search(body)
        command = cmd_m.group(1).lower() if cmd_m else "all"
        if command == "select":
            return
        open_using = bool(USING_TRUE_RE.search(body)) and command in ("update", "delete", "all")
        open_check = bool(CHECK_TRUE_RE.search(body)) and command in ("insert", "update", "all")
        if open_using or open_check:
            table = key[1] if key[0] == "public" else f"{key[0]}.{key[1]}"
            self.findings.append(
                make_finding(
                    "SS-RLS-OPEN-POLICY", f"{lo.file}:{lo.line}", _snippet(m.string, m.start()),
                    file=lo.file, line=lo.line, table=table, command=command.upper(),
                )
            )

    def finish(self) -> list[Finding]:
        out = list(self.findings)
        for key, lo in self.tables.items():
            schema, table = key
            if schema != "public":
                continue  # only the public schema is exposed through the Supabase API by default
            location = f"{lo.file}:{lo.line}"
            if not self.rls.get(key, False):
                out.append(make_finding("SS-RLS-MISSING", location, f"create table {table}", file=lo.file,
                                        line=lo.line, table=table))
            elif key not in self.policies:
                out.append(make_finding("SS-RLS-NO-POLICY", location, f"create table {table}", file=lo.file,
                                        line=lo.line, table=table))
        return out


def _snippet(text: str, offset: int, limit: int = 140) -> str:
    end = text.find("\n", offset, offset + limit * 4)
    end = min(len(text), offset + limit * 4) if end == -1 else end
    snippet = " ".join(text[offset:end].split())
    return snippet if len(snippet) <= limit else snippet[: limit - 1] + "…"


def check_js_buckets(relpath: str, text: str) -> list[Finding]:
    out = []
    starts = line_starts(text)
    for m in CREATE_BUCKET_JS_RE.finditer(text):
        line = line_of(starts, m.start())
        out.append(make_finding("SS-STORAGE-PUBLIC-BUCKET", f"{relpath}:{line}", _snippet(text, m.start()),
                                file=relpath, line=line))
    return out
