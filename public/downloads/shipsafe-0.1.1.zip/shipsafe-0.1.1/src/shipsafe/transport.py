"""Tiny HTTP layer: every request goes through an injectable ``transport`` function.

A transport is ``transport(method, url, headers) -> HttpResponse``. Tests pass a fake
one; the default uses ``urllib.request``.
"""

from __future__ import annotations

import urllib.error
import urllib.request
from dataclasses import dataclass, field
from typing import Callable, Mapping
from urllib.parse import urlparse

USER_AGENT = "shipsafe/0.1"
DEFAULT_TIMEOUT = 15.0
DEFAULT_MAX_BYTES = 5 * 1024 * 1024
LOCAL_HOSTS = {"127.0.0.1", "localhost", "::1"}


class TransportError(Exception):
    """The request could not be made at all (DNS, refused connection, timeout...)."""


@dataclass
class HttpResponse:
    status: int
    headers: dict[str, str] = field(default_factory=dict)
    body: bytes = b""
    url: str = ""

    def header(self, name: str) -> str | None:
        return self.headers.get(name.lower())

    def text(self) -> str:
        return self.body.decode("utf-8", errors="replace")


Transport = Callable[[str, str, Mapping[str, str]], HttpResponse]


def _lower_headers(msg) -> dict[str, str]:
    out: dict[str, str] = {}
    if msg is None:
        return out
    for k, v in msg.items():
        k = k.lower()
        out[k] = f"{out[k]}, {v}" if k in out else v
    return out


def make_urllib_transport(timeout: float = DEFAULT_TIMEOUT, max_bytes: int = DEFAULT_MAX_BYTES) -> Transport:
    def transport(method: str, url: str, headers: Mapping[str, str]) -> HttpResponse:
        req_headers = {"User-Agent": USER_AGENT, "Accept": "*/*"}
        req_headers.update(headers or {})
        req = urllib.request.Request(url, method=method, headers=req_headers)
        handlers = []
        if urlparse(url).hostname in LOCAL_HOSTS:
            handlers.append(urllib.request.ProxyHandler({}))
        opener = urllib.request.build_opener(*handlers)
        try:
            with opener.open(req, timeout=timeout) as resp:
                body = resp.read(max_bytes)
                return HttpResponse(resp.status, _lower_headers(resp.headers), body, resp.geturl())
        except urllib.error.HTTPError as exc:
            try:
                body = exc.read(max_bytes)
            except Exception:  # pragma: no cover - defensive
                body = b""
            return HttpResponse(exc.code, _lower_headers(exc.headers), body, url)
        except (urllib.error.URLError, OSError, ValueError) as exc:
            reason = getattr(exc, "reason", exc)
            raise TransportError(f"Could not reach {url}: {reason}") from exc

    return transport
