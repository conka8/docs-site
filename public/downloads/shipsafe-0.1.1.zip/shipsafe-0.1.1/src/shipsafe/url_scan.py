"""``shipsafe url <https://app>``: check a deployed app from the outside.

Only run this against apps you own or have written permission to test.
"""

from __future__ import annotations

import json
import re
from html.parser import HTMLParser
from urllib.parse import quote, urljoin, urlparse

from . import codecheck
from .findings import Finding, ScanResult, redact, sort_findings
from .local_scan import ScanError, dedupe
from .patterns import JWT_RE, SB_PUBLISHABLE_RE, find_secrets, jwt_ref, jwt_role, line_of, line_starts, scrub
from .rules import make_finding
from .transport import HttpResponse, Transport, TransportError, make_urllib_transport

# --- constants that depend on third-party behaviour (verify against current docs) ---
EXPOSED_PATHS = ("/.env", "/.env.local", "/.env.production", "/.git/config")
NOT_FOUND_PROBE_PATH = "/__shipsafe_not_found_check__"
SUPABASE_REST_PATH = "/rest/v1/"  # PostgREST root: returns an OpenAPI description listing exposed tables
SUPABASE_TABLE_QUERY = "{base}/rest/v1/{table}?select=*&limit=1"
SUPABASE_URL_RE = re.compile(r"https://[a-z0-9][a-z0-9-]*\.supabase\.(?:co|in)\b")
FROM_TABLE_RE = re.compile(r"""\.from\(\s*["'`]([A-Za-z_][A-Za-z0-9_]*)["'`]\s*\)""")
MAX_SCRIPTS = 20
MAX_SCRIPT_BYTES = 2 * 1024 * 1024
MAX_PROBE_TABLES = 50


class _ScriptCollector(HTMLParser):
    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.srcs: list[str] = []
        self.meta_csp = ""

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        a = {k.lower(): (v or "") for k, v in attrs}
        if tag == "script" and a.get("src"):
            self.srcs.append(a["src"])
        elif tag == "link" and a.get("href"):
            rel = a.get("rel", "").lower()
            if "modulepreload" in rel or ("preload" in rel and a.get("as", "").lower() == "script"):
                self.srcs.append(a["href"])
        elif tag == "meta" and a.get("http-equiv", "").lower() == "content-security-policy":
            self.meta_csp = a.get("content", "")


def extract_scripts(html_text: str, base_url: str, max_scripts: int = MAX_SCRIPTS) -> tuple[list[str], int, str]:
    """Return (same-origin script URLs, number of skipped cross-origin scripts, meta CSP)."""
    parser = _ScriptCollector()
    try:
        parser.feed(html_text)
    except Exception:  # pragma: no cover - HTMLParser is lenient, but be safe
        pass
    base = urlparse(base_url)
    out: list[str] = []
    cross = 0
    for src in parser.srcs:
        full = urljoin(base_url, src.strip())
        parsed = urlparse(full)
        if parsed.scheme not in ("http", "https") or parsed.netloc != base.netloc:
            cross += 1
            continue
        full = full.split("#", 1)[0]
        if full not in out:
            out.append(full)
    return out[:max_scripts], cross, parser.meta_csp


def _looks_like_html(body: bytes) -> bool:
    head = body[:1024].lstrip().lower()
    return head.startswith((b"<!doctype html", b"<html", b"<head", b"<body")) or b"<html" in head


ENV_LINE_RE = re.compile(r"^\s*(?:export\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*)$", re.M)


def exposed_file_evidence(path: str, resp: HttpResponse, home_body: bytes, fallback_body: bytes | None) -> str | None:
    """Return redacted evidence if ``resp`` really is the sensitive file, else None."""
    if resp.status != 200:
        return None
    body = resp.body.strip()
    if not body:
        return None
    if body == home_body.strip() or (fallback_body is not None and body == fallback_body.strip()):
        return None  # single-page-app fallback: the server returns index.html for every path
    if _looks_like_html(body) or "text/html" in (resp.header("content-type") or "").lower():
        return None
    text = resp.body.decode("utf-8", errors="replace")
    if path.startswith("/.env"):
        m = ENV_LINE_RE.search(text)
        if not m:
            return None
        count = len(ENV_LINE_RE.findall(text))
        return f"{m.group(1)}={redact(m.group(2).strip().strip(chr(34) + chr(39)))} ({count} variable(s) in file)"
    if path.endswith(".git/config"):
        if "[core]" in text or "repositoryformatversion" in text:
            return "[core] repositoryformatversion… (your Git repository is downloadable)"
        return None
    return scrub(text.splitlines()[0][:80])


def _origin(url: str) -> str:
    p = urlparse(url)
    return f"{p.scheme}://{p.netloc}"


def check_headers(resp: HttpResponse, url: str, meta_csp: str = "") -> list[Finding]:
    out = []
    csp = (resp.header("content-security-policy") or "") + " " + meta_csp
    if not csp.strip():
        out.append(make_finding("SS-HEADER-CSP", url, "content-security-policy: (missing)"))
    if not resp.header("x-frame-options") and "frame-ancestors" not in csp.lower():
        out.append(make_finding("SS-HEADER-FRAME", url, "x-frame-options: (missing)"))
    if urlparse(url).scheme == "https" and not resp.header("strict-transport-security"):
        out.append(make_finding("SS-HEADER-HSTS", url, "strict-transport-security: (missing)"))
    return out


def secret_findings_for_text(location_base: str, text: str) -> list[Finding]:
    """Secret / JWT checks for code that is served to the browser."""
    starts = line_starts(text)
    out = []
    for hit in find_secrets(text):
        if hit.rule_id == "SS-SECRET-PASSWORD":
            continue  # too noisy in minified bundles
        line = line_of(starts, hit.start)
        evidence = hit.value if hit.rule_id == "SS-SECRET-PRIVATE-KEY" else redact(hit.value)
        out.append(make_finding(hit.rule_id, f"{location_base}:{line}", evidence, severity=hit.severity,
                                raw=hit.value, line=line, title_suffix=" (in your live website's code)"
                                if hit.rule_id != "SS-SUPABASE-ANON-KEY" else ""))
    return out


def _pick_supabase(texts: list[tuple[str, str]]) -> tuple[str | None, str | None, list[str]]:
    urls: list[str] = []
    keys: list[str] = []
    tables: list[str] = []
    for _, text in texts:
        for m in SUPABASE_URL_RE.finditer(text):
            if m.group(0) not in urls:
                urls.append(m.group(0))
        for m in JWT_RE.finditer(text):
            tok = m.group("key")
            if jwt_role(tok) == "anon" and tok not in keys:
                keys.append(tok)
        for m in SB_PUBLISHABLE_RE.finditer(text):
            if m.group("key") not in keys:
                keys.append(m.group("key"))
        for m in FROM_TABLE_RE.finditer(text):
            if "storage" in text[max(0, m.start() - 14) : m.start()]:
                continue
            if m.group(1) not in tables:
                tables.append(m.group(1))
    if not urls or not keys:
        return (urls[0] if urls else None), (keys[0] if keys else None), tables
    for url in urls:
        ref = urlparse(url).hostname.split(".")[0]
        for key in keys:
            if jwt_ref(key) == ref:
                return url, key, tables
    return urls[0], keys[0], tables


def probe_supabase(transport: Transport, base: str, key: str, table_hints: list[str]) -> tuple[list[Finding], list[str]]:
    """Ask PostgREST which tables exist, then try to read one row from each with the anon key."""
    headers = {"apikey": key, "Accept": "application/json"}
    if key.startswith("eyJ"):
        headers["Authorization"] = f"Bearer {key}"
    notes: list[str] = []
    findings: list[Finding] = []
    tables: list[str] = []
    try:
        root = transport("GET", base.rstrip("/") + SUPABASE_REST_PATH, headers)
    except TransportError as exc:
        return [], [f"Supabase probe failed: {exc}"]
    if root.status == 200:
        try:
            spec = json.loads(root.text())
            for path in (spec.get("paths") or {}) if isinstance(spec, dict) else {}:
                name = path.strip("/")
                if name and "/" not in name and not name.startswith("rpc"):
                    tables.append(name)
        except ValueError:
            notes.append("Supabase table listing was not valid JSON.")
    else:
        notes.append(
            f"Supabase did not list tables for the anon key (HTTP {root.status}); "
            "trying table names found in your app's code instead."
        )
    for t in table_hints:
        if t not in tables:
            tables.append(t)
    if not tables:
        notes.append("No Supabase table names found to test.")
    for table in tables[:MAX_PROBE_TABLES]:
        url = SUPABASE_TABLE_QUERY.format(base=base.rstrip("/"), table=quote(table, safe=""))
        try:
            resp = transport("GET", url, headers)
        except TransportError as exc:
            notes.append(f"Could not test table {table}: {exc}")
            continue
        if resp.status != 200:
            continue
        try:
            rows = json.loads(resp.text())
        except ValueError:
            continue
        if isinstance(rows, list) and rows:
            cols = sorted(rows[0].keys()) if isinstance(rows[0], dict) else []
            col_text = ", ".join(cols[:8]) + (", …" if len(cols) > 8 else "")
            evidence = f"GET /rest/v1/{table} returned data (columns: {col_text or 'unknown'})"
            findings.append(make_finding("SS-SUPABASE-TABLE-READABLE", f"{base}/rest/v1/{table}", evidence,
                                         table=table, raw=f"{base}|{table}"))
    notes.append(f"Supabase probe tested {min(len(tables), MAX_PROBE_TABLES)} table(s) on {base}.")
    return findings, notes


def scan_url(
    url: str,
    transport: Transport | None = None,
    probe_supabase_tables: bool = False,
    max_scripts: int = MAX_SCRIPTS,
    max_script_bytes: int = MAX_SCRIPT_BYTES,
    ignore_rules: tuple[str, ...] | list[str] = (),
) -> ScanResult:
    parsed = urlparse(url)
    if parsed.scheme not in ("http", "https") or not parsed.netloc:
        raise ScanError(f"Not a web address: {url!r}. Use the full address, e.g. https://myapp.vercel.app")
    transport = transport or make_urllib_transport()
    result = ScanResult(target=url, mode="url")
    try:
        home = transport("GET", url, {})
    except TransportError as exc:
        raise ScanError(str(exc)) from exc
    if home.status >= 400:
        raise ScanError(f"{url} answered with HTTP {home.status}; check the address and try again.")
    final_url = home.url or url
    origin = _origin(final_url)
    home_text = home.text()
    findings: list[Finding] = []

    scripts, cross, meta_csp = extract_scripts(home_text, final_url, max_scripts)
    findings.extend(check_headers(home, final_url, meta_csp))
    texts: list[tuple[str, str]] = [(final_url, home_text)]
    if cross:
        result.notes.append(f"Skipped {cross} script(s) hosted on other domains.")
    for script_url in scripts:
        try:
            resp = transport("GET", script_url, {})
        except TransportError as exc:
            result.notes.append(f"Could not download {script_url}: {exc}")
            continue
        if resp.status != 200:
            result.notes.append(f"{script_url} answered HTTP {resp.status}.")
            continue
        body = resp.body
        if len(body) > max_script_bytes:
            result.notes.append(f"Only the first {max_script_bytes // 1024} KB of {script_url} were checked.")
            body = body[:max_script_bytes]
        texts.append((script_url, body.decode("utf-8", errors="replace")))
    result.files_scanned = len(texts)
    if not scripts:
        result.notes.append("No JavaScript files found on the homepage (the app may load them in another way).")

    for loc, text in texts:
        findings.extend(secret_findings_for_text(loc, text))
        if loc != final_url or "<script" in text:
            findings.extend(codecheck.check_browser_ai(loc, text, "client"))

    # Exposed dotfiles, with SPA fallback detection.
    fallback: bytes | None = None
    try:
        nf = transport("GET", origin + NOT_FOUND_PROBE_PATH, {})
        if nf.status == 200:
            fallback = nf.body
    except TransportError:
        pass
    for path in EXPOSED_PATHS:
        try:
            resp = transport("GET", origin + path, {})
        except TransportError:
            continue
        evidence = exposed_file_evidence(path, resp, home.body, fallback)
        if evidence:
            findings.append(make_finding("SS-EXPOSED-FILE", origin + path, evidence, path=path))

    sb_url, sb_key, tables = _pick_supabase(texts)
    if sb_url and sb_key:
        if probe_supabase_tables:
            probe_findings, notes = probe_supabase(transport, sb_url, sb_key, tables)
            findings.extend(probe_findings)
            result.notes.extend(notes)
        else:
            result.notes.append(
                f"Found a Supabase project ({sb_url}) and its public anon key. Re-run with --probe-supabase "
                "to test which tables anyone can read (only on apps you own)."
            )

    ignore = {r.upper() for r in ignore_rules}
    findings = [f for f in findings if f.rule_id not in ignore]
    for f in findings:
        if f.rule_id != "SS-SECRET-PRIVATE-KEY":
            f.evidence = scrub(f.evidence)
    result.findings = sort_findings(dedupe(findings, by_value=True))
    return result
