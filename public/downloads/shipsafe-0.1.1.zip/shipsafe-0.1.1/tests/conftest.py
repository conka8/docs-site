from __future__ import annotations

from pathlib import Path

import pytest

from fakes import SECRETS, materialize


@pytest.fixture
def secrets() -> dict[str, str]:
    return dict(SECRETS)


@pytest.fixture
def make_app(tmp_path):
    def _make(name: str) -> Path:
        return materialize(name, tmp_path)

    return _make


@pytest.fixture
def leaky(make_app) -> Path:
    return make_app("leaky_next")


@pytest.fixture
def clean(make_app) -> Path:
    return make_app("clean_next")


@pytest.fixture
def firebase(make_app) -> Path:
    return make_app("firebase_app")


@pytest.fixture
def vite(make_app) -> Path:
    return make_app("vite_app")


@pytest.fixture
def write(tmp_path):
    """Write files into a fresh project folder: write({'a/b.ts': 'text'}) -> folder path."""

    def _write(files: dict[str, str | bytes], root: Path | None = None) -> Path:
        root = root or tmp_path / "proj"
        for rel, content in files.items():
            p = root / rel
            p.parent.mkdir(parents=True, exist_ok=True)
            if isinstance(content, bytes):
                p.write_bytes(content)
            else:
                p.write_text(content, encoding="utf-8")
        root.mkdir(parents=True, exist_ok=True)
        return root

    return _write


__all__ = ["materialize"]
