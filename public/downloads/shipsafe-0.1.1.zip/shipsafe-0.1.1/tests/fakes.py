"""Fake credentials for tests.

They are generated at test time (never stored in the repo) so that fixture files
don't trip GitHub push protection or other secret scanners.
"""

from __future__ import annotations

import base64
import json
import os
import random
import string
from pathlib import Path

from shipsafe.patterns import is_placeholder

ALNUM = string.ascii_letters + string.digits
UPPER_DIGITS = string.ascii_uppercase + string.digits
HEX = "0123456789abcdef"
SUPABASE_REF = "abcdefghijklmnopqrst"
FIXTURES = Path(__file__).parent / "fixtures"


def b64url(data: bytes | dict) -> str:
    if isinstance(data, dict):
        data = json.dumps(data, separators=(",", ":")).encode()
    return base64.urlsafe_b64encode(data).rstrip(b"=").decode()


def make_jwt(role: str, ref: str = SUPABASE_REF, seed: int = 7) -> str:
    rng = random.Random(seed)
    header = {"alg": "HS256", "typ": "JWT"}
    payload = {"iss": "supabase", "ref": ref, "role": role, "iat": 1700000000, "exp": 2000000000}
    sig = "".join(rng.choice(ALNUM + "-_") for _ in range(43))
    return f"{b64url(header)}.{b64url(payload)}.{sig}"


def _rand(rng: random.Random, n: int, alphabet: str = ALNUM) -> str:
    while True:
        s = "".join(rng.choice(alphabet) for _ in range(n))
        if alphabet == ALNUM and not (any(c.isdigit() for c in s) and any(c.isupper() for c in s) and any(c.islower() for c in s)):
            continue
        if not is_placeholder(s):
            return s


def build_secrets(seed: int = 2026) -> dict[str, str]:
    rng = random.Random(seed)
    r = lambda n, a=ALNUM: _rand(rng, n, a)  # noqa: E731
    secrets = {
        "OPENAI_KEY": "sk-" + "proj-" + r(48),
        "OPENAI_KEY2": "sk-" + r(48),
        "OPENAI_KEY3": "sk-" + "proj-" + r(56),
        "ANTHROPIC_KEY": "sk-" + "ant-" + "api03-" + r(86),
        "STRIPE_LIVE": "sk_" + "live_" + r(32),
        "STRIPE_LIVE2": "sk_" + "live_" + r(32),
        "STRIPE_TEST": "sk_" + "test_" + r(32),
        "STRIPE_PK": "pk_" + "live_" + r(32),
        "AWS_KEY": "AK" + "IA" + r(16, UPPER_DIGITS),
        "GITHUB_TOKEN": "gh" + "p_" + r(36),
        "GITHUB_TOKEN2": "gh" + "p_" + r(36),
        "GOOGLE_KEY": "AI" + "za" + r(35),
        "SLACK_TOKEN": "xo" + "xb-" + r(12, "0123456789") + "-" + r(12, "0123456789") + "-" + r(24),
        "SENDGRID_KEY": "S" + "G." + r(22) + "." + r(43),
        "TWILIO_KEY": "S" + "K" + r(32, HEX),
        "PRIVATE_KEY_BODY": r(64) + r(64),
        "PASSWORD": "pw" + r(10) + "!9",
        "PASSWORD2": "Adm" + r(9) + "#7",
        "SERVICE_ROLE_JWT": make_jwt("service_role", seed=11),
        "ANON_JWT": make_jwt("anon", seed=12),
        # Not a known provider format: only the generic apiKey check (and evidence masking) catches it.
        "CLIENT_APIKEY": r(32),
    }
    return secrets


SECRETS = build_secrets()
# Values that must never be printed in full by any report format.
NEVER_PRINT = [k for k in SECRETS if k not in ("ANON_JWT", "STRIPE_PK")]


def materialize(name: str, dest: Path, secrets: dict[str, str] | None = None) -> Path:
    """Copy a fixture app to ``dest``: ``dot-x`` files become ``.x`` and ``__SS_KEY__`` tokens get fake secrets."""
    src = FIXTURES / name
    target = dest / name
    for dirpath, _dirnames, filenames in os.walk(src):
        rel = Path(dirpath).relative_to(src)
        out_dir = target / rel
        out_dir.mkdir(parents=True, exist_ok=True)
        for fn in filenames:
            out_name = "." + fn[4:] if fn.startswith("dot-") else fn
            text = (Path(dirpath) / fn).read_text(encoding="utf-8")
            for key, value in (secrets or SECRETS).items():
                text = text.replace(f"__SS_{key}__", value)
            assert "__SS_" not in text, f"unknown placeholder in {fn}"
            (out_dir / out_name).write_text(text, encoding="utf-8")
    return target
