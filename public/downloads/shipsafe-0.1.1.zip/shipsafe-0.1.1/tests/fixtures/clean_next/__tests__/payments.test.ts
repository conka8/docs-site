const stripeKey = "__SS_STRIPE_TEST__";
const openaiKey = "__SS_OPENAI_KEY2__";

test("uses test keys only", () => {
  expect(stripeKey.startsWith("sk_test_")).toBe(true);
  expect(openaiKey.length).toBeGreaterThan(20);
});
