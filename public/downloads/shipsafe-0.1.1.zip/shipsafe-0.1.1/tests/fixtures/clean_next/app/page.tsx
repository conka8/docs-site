import { createClient } from "@/lib/supabase";

export default async function Home() {
  const supabase = createClient();
  const { data: posts } = await supabase.from("posts").select("id, title");
  return <main>{posts?.map((p) => <h2 key={p.id}>{p.title}</h2>)}</main>;
}
