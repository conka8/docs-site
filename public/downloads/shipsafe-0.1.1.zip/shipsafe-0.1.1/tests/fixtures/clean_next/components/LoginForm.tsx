"use client";
import { z } from "zod";

const schema = z.object({ email: z.string().email(), password: z.string().min(8) });
const passwordLabel = "Password1";
const passwordMinLength = "12345678";

export function LoginForm() {
  return (
    <form className="sk-loading-spinner-container-wrapper-outer">
      <label htmlFor="password">{passwordLabel}</label>
      <input id="password" type="password" name="password" />
    </form>
  );
}
