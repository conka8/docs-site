export function Welcome() {
  return <div dangerouslySetInnerHTML={{ __html: "<b>Welcome back</b>" }} />;
}
export function clear(el: HTMLElement) {
  el.innerHTML = "";
}
