// The anon key is public by design; RLS protects the data.
export const SUPABASE_ANON_KEY = "__SS_ANON_JWT__";
