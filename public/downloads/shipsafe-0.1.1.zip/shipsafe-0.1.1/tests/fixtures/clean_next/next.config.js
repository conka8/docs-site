/** @type {import('next').NextConfig} */
module.exports = {
  env: { NEXT_PUBLIC_APP_NAME: "Clean", NEXT_PUBLIC_SITE_URL: process.env.NEXT_PUBLIC_SITE_URL },
};
