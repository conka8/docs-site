create table public.posts (
  id bigserial primary key,
  user_id uuid references auth.users not null,
  title text not null
);
alter table public.posts enable row level security;
-- Public read is intended for blog posts
create policy "Posts are public" on public.posts for select using (true);
create policy "Owners insert" on public.posts for insert with check (auth.uid() = user_id);
create policy "Owners update" on public.posts for update using (auth.uid() = user_id);
create policy "Owners delete" on public.posts for delete using (auth.uid() = user_id);

create table private.jobs (id bigserial primary key);

insert into storage.buckets (id, name, public) values ('receipts', 'receipts', false);
