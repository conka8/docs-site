const { onRequest } = require("firebase-functions/v2/https");
const OpenAI = require("openai");

const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

exports.chat = onRequest(async (req, res) => {
  const completion = await openai.chat.completions.create({ model: "gpt-4o-mini", messages: req.body.messages });
  res.json(completion.choices[0].message);
});
