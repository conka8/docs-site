import { initializeApp } from "firebase/app";

const firebaseConfig = {
  apiKey: "__SS_GOOGLE_KEY__",
  authDomain: "demo-app.firebaseapp.com",
  projectId: "demo-app",
  messagingSenderId: "1234567890",
  appId: "1:1234567890:web:abcdef123456",
};

export const app = initializeApp(firebaseConfig);
