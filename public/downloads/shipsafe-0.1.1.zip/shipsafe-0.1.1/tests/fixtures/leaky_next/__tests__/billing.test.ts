import { charge } from "../lib/billing";

const key = "__SS_OPENAI_KEY3__";

test("charges", async () => {
  expect(await charge(key, 100)).toBe(true);
});
