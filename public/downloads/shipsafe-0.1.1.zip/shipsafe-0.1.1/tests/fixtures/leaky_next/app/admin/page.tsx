import { createClient } from "@supabase/supabase-js";

export default async function AdminPage() {
  const supabase = createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!);
  const { data: users } = await supabase.from("profiles").select("*");
  return <pre>{JSON.stringify(users, null, 2)}</pre>;
}
