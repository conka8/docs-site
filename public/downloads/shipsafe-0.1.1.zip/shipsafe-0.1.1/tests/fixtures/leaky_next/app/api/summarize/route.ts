import Anthropic from "@anthropic-ai/sdk";
import { createClient } from "@/lib/supabase/server";

const anthropic = new Anthropic();

export async function POST(req: Request) {
  const supabase = createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return new Response("Unauthorized", { status: 401 });
  const { text } = await req.json();
  const msg = await anthropic.messages.create({
    model: "claude-sonnet-5-5",
    max_tokens: 512,
    messages: [{ role: "user", content: text }],
  });
  return Response.json(msg);
}
