import { supabase } from "@/lib/supabase";

export default async function Home() {
  const { data } = await supabase.from("messages").select("*");
  return <main>{data?.length} messages</main>;
}
