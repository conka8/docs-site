"use client";
import Anthropic from "@anthropic-ai/sdk";

const claude = new Anthropic({ apiKey: "__SS_CLIENT_APIKEY__" });

export default claude;
