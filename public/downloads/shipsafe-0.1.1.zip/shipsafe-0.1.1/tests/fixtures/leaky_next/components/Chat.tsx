"use client";
import OpenAI from "openai";

const openai = new OpenAI({ apiKey: process.env.NEXT_PUBLIC_OPENAI_API_KEY, dangerouslyAllowBrowser: true });

export async function ask(question: string) {
  const res = await openai.chat.completions.create({ model: "gpt-4o-mini", messages: [{ role: "user", content: question }] });
  return res.choices[0].message.content;
}
