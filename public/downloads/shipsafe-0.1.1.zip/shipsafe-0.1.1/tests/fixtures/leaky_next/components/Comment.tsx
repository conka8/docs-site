export function Comment({ comment }: { comment: { body: string } }) {
  return <div className="comment" dangerouslySetInnerHTML={{ __html: comment.body }} />;
}
