"use client";
import { supabase } from "@/lib/supabase";

export async function ensureBucket() {
  await supabase.storage.createBucket("uploads", { public: true });
}
