// Third-party keys, pasted in while prototyping
export const ANTHROPIC_KEY = "__SS_ANTHROPIC_KEY__";
export const GITHUB_TOKEN = "__SS_GITHUB_TOKEN__";
export const AWS_ACCESS_KEY_ID = "__SS_AWS_KEY__";
export const SENDGRID_KEY = "__SS_SENDGRID_KEY__";
export const SLACK_TOKEN = "__SS_SLACK_TOKEN__";
export const TWILIO_API_KEY = "__SS_TWILIO_KEY__";
export const MAPS_KEY = "__SS_GOOGLE_KEY__";
export const STRIPE_TEST_KEY = "__SS_STRIPE_TEST__";
const adminPassword = "__SS_PASSWORD2__";
export const legacyKey = "__SS_OPENAI_KEY2__"; // shipsafe-ignore
export const legacyStripe = "__SS_STRIPE_LIVE2__"; // shipsafe-ignore SS-SECRET-OPENAI
// shipsafe-ignore-next-line SS-SECRET-GITHUB
export const ciToken = "__SS_GITHUB_TOKEN2__";
export function checkAdmin(pw: string) { return pw === adminPassword; }
