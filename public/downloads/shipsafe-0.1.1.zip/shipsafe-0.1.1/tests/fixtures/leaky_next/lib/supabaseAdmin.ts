"use client";
import { createClient } from "@supabase/supabase-js";

// TODO: move this to the server later
export const supabaseAdmin = createClient(
  "https://abcdefghijklmnopqrst.supabase.co",
  "__SS_SERVICE_ROLE_JWT__"
);
