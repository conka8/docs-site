-- profiles: RLS on, but the update policy is wide open
create table public.profiles (
  id uuid primary key references auth.users,
  email text,
  is_admin boolean default false
);
alter table public.profiles enable row level security;
create policy "Anyone can update profiles" on public.profiles for update using (true);
create policy "Profiles are readable" on public.profiles for select using (true);

-- messages: no RLS at all
create table messages (
  id bigserial primary key,
  user_id uuid,
  body text
);

-- audit_log: RLS on but no policies
create table if not exists "audit_log" (id bigserial primary key, action text);
alter table "audit_log" enable row level security;

/* comments: anyone can insert */
create table comments (id bigserial primary key, body text);
alter table comments enable row level security;
create policy "insert comments" on comments for insert with check (true);

create table scratch (id int); -- shipsafe-ignore

insert into storage.buckets (id, name, public) values ('avatars', 'avatars', true);
