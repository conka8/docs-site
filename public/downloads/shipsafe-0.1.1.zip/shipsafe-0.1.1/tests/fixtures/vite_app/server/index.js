import express from "express";
import rateLimit from "express-rate-limit";
import Anthropic from "@anthropic-ai/sdk";

const app = express();
const anthropic = new Anthropic();
app.use(express.json());
app.use(rateLimit({ windowMs: 60_000, max: 20 }));

app.post("/api/chat", async (req, res) => {
  const msg = await anthropic.messages.create({ model: "claude-sonnet-5-5", max_tokens: 256, messages: req.body.messages });
  res.json(msg);
});

app.listen(3001);
