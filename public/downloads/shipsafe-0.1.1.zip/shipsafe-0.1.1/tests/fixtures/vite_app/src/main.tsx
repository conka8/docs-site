import React from "react";
import ReactDOM from "react-dom/client";
import App from "./App";

const params = new URLSearchParams(location.search);
document.getElementById("flash")!.innerHTML = params.get("message") ?? "";

ReactDOM.createRoot(document.getElementById("root")!).render(<App />);
