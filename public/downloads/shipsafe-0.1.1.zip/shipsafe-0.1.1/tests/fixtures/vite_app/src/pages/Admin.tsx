import { supabase } from "../lib/supabase";

export default function Admin() {
  const deleteUser = (id: string) => supabase.from("profiles").delete().eq("id", id);
  return <button onClick={() => deleteUser("1")}>Delete user</button>;
}
