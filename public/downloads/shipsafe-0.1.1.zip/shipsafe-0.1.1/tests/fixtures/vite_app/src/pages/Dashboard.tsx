import { useAuth } from "../hooks/useAuth";

export default function Dashboard() {
  const { user } = useAuth();
  return <p>Hello {user?.email}</p>;
}
