import json
import os
import subprocess
import sys
from pathlib import Path

import pytest

from shipsafe.cli import EXIT_ERROR, EXIT_FINDINGS, EXIT_OK, main
from shipsafe.config import ConfigError, find_config, load_config, parse_simple_yaml
from shipsafe.transport import HttpResponse

ROOT = Path(__file__).resolve().parents[1]


def run(argv, capsys):
    code = main(argv)
    out = capsys.readouterr()
    return code, out.out, out.err


# ------------------------------------------------------------------ exit codes
def test_leaky_fails_by_default(leaky, capsys):
    code, out, _ = run(["scan", str(leaky)], capsys)
    assert code == EXIT_FINDINGS
    assert "Grade:  F" in out and "[CRITICAL]" in out


def test_clean_passes_by_default(clean, capsys):
    code, out, _ = run(["scan", str(clean)], capsys)
    assert code == EXIT_OK and "Grade:  A" in out


@pytest.mark.parametrize(
    "fail_on, expected",
    [("critical", EXIT_OK), ("high", EXIT_OK), ("medium", EXIT_OK), ("low", EXIT_FINDINGS), ("never", EXIT_OK)],
)
def test_fail_on_clean(clean, capsys, fail_on, expected):
    assert run(["scan", str(clean), "--fail-on", fail_on], capsys)[0] == expected


@pytest.mark.parametrize(
    "fail_on, expected",
    [("critical", EXIT_OK), ("high", EXIT_FINDINGS), ("medium", EXIT_FINDINGS), ("never", EXIT_OK)],
)
def test_fail_on_threshold(write, capsys, fail_on, expected):
    root = write({".gitignore": "x", "app/admin/page.tsx": "export default () => null"})  # one high finding
    assert run(["scan", str(root), "--fail-on", fail_on], capsys)[0] == expected


def test_info_never_fails(write, capsys):
    from fakes import SECRETS

    root = write({".gitignore": "x", "lib/a.ts": f'k = "{SECRETS["ANON_JWT"]}"'})
    assert run(["scan", str(root), "--fail-on", "low"], capsys)[0] == EXIT_OK


def test_ignore_rule_flag_changes_exit_code(write, capsys):
    root = write({".gitignore": "x", "app/admin/page.tsx": "export default () => null"})
    assert run(["scan", str(root), "--fail-on", "high"], capsys)[0] == EXIT_FINDINGS
    code, out, _ = run(["scan", str(root), "--fail-on", "high", "--ignore-rule", "SS-ADMIN-NO-AUTH",
                        "--ignore-rule", "SS-XSS-INNERHTML"], capsys)
    assert code == EXIT_OK and "No problems found" in out


def test_unknown_ignore_rule(clean, capsys):
    code, _, err = run(["scan", str(clean), "--ignore-rule", "SS-NOPE"], capsys)
    assert code == EXIT_ERROR and "unknown rule id" in err


# ------------------------------------------------------------------ formats / output
@pytest.mark.parametrize("fmt, marker", [("text", "Grade:"), ("json", '"tool": "shipsafe"'), ("md", "# shipsafe report"),
                                         ("html", "<!DOCTYPE html>")])
def test_formats_to_stdout(leaky, capsys, fmt, marker):
    code, out, _ = run(["scan", str(leaky), "--format", fmt], capsys)
    assert code == EXIT_FINDINGS and marker in out


def test_json_output_parses(leaky, capsys):
    _, out, _ = run(["scan", str(leaky), "-f", "json"], capsys)
    data = json.loads(out)
    assert data["mode"] == "scan" and data["counts"]["critical"] >= 5
    assert all(f["fix_prompt"] for f in data["findings"])


def test_output_file_html_with_branding(leaky, tmp_path, capsys):
    target = tmp_path / "report.html"
    code, out, _ = run(["scan", str(leaky), "--format", "html", "-o", str(target), "--brand-name", "Vibe Academy",
                        "--brand-color", "#123abc", "--logo-url", "https://example.org/l.png"], capsys)
    assert code == EXIT_FINDINGS
    assert out.startswith(f"Report written to {target}: grade F")
    html = target.read_text(encoding="utf-8")
    assert "Vibe Academy" in html and "--brand:#123abc" in html and "https://example.org/l.png" in html


def test_output_file_unwritable(leaky, tmp_path, capsys):
    code, _, err = run(["scan", str(leaky), "-o", str(tmp_path / "missing-dir" / "r.txt")], capsys)
    assert code == EXIT_ERROR and "could not write" in err


def test_bad_brand_color_and_logo(clean, capsys):
    assert run(["scan", str(clean), "--brand-color", "url(x)"], capsys)[0] == EXIT_ERROR
    assert run(["scan", str(clean), "--logo-url", "javascript:x"], capsys)[0] == EXIT_ERROR


def test_include_build_flag(write, capsys):
    from fakes import SECRETS

    root = write({".gitignore": "x", "dist/app.js": f'k="{SECRETS["OPENAI_KEY"]}"'})
    assert run(["scan", str(root)], capsys)[0] == EXIT_OK
    assert run(["scan", str(root), "--include-build"], capsys)[0] == EXIT_FINDINGS


# ------------------------------------------------------------------ errors / misc commands
def test_missing_directory(tmp_path, capsys):
    code, _, err = run(["scan", str(tmp_path / "nope")], capsys)
    assert code == EXIT_ERROR and "Folder not found" in err


def test_no_command_prints_help(capsys):
    code, out, _ = run([], capsys)
    assert code == EXIT_ERROR and "usage" in out.lower()


def test_bad_arguments(capsys):
    assert run(["scan", ".", "--format", "pdf"], capsys)[0] == 2
    assert run(["scan", ".", "--fail-on", "sometimes"], capsys)[0] == 2
    assert run(["--help"], capsys)[0] == 0
    code, out, _ = run(["--version"], capsys)
    assert code == 0 and "shipsafe 0.1.1" in out


def test_rules_command(capsys):
    code, out, _ = run(["rules"], capsys)
    assert code == EXIT_OK and "SS-RLS-MISSING" in out and "SS-EXPOSED-FILE" in out


def test_scan_defaults_to_current_folder(clean, capsys, monkeypatch):
    monkeypatch.chdir(clean)
    assert run(["scan"], capsys)[0] == EXIT_OK


# ------------------------------------------------------------------ url command
def fake_site(url="https://app.example.com"):
    def transport(method, u, headers):
        if u == url:
            return HttpResponse(200, {"content-type": "text/html"}, b"<html>hi</html>", u)
        return HttpResponse(404, {}, b"", u)

    return transport


def test_url_command(capsys):
    code, out, _ = main(["url", "https://app.example.com", "--fail-on", "low"], transport=fake_site()), *capsys.readouterr()
    assert code == EXIT_FINDINGS
    assert "SS-HEADER-CSP" in out and "Target: https://app.example.com" in out


def test_url_command_bad_url(capsys):
    code = main(["url", "notaurl"], transport=fake_site())
    assert code == EXIT_ERROR and "Not a web address" in capsys.readouterr().err


def test_url_command_bad_numbers(capsys):
    assert main(["url", "https://app.example.com", "--max-script-kb", "0"], transport=fake_site()) == EXIT_ERROR
    assert main(["url", "https://app.example.com", "--timeout", "-1"], transport=fake_site()) == EXIT_ERROR


def test_url_command_json(capsys):
    main(["url", "https://app.example.com", "-f", "json"], transport=fake_site())
    data = json.loads(capsys.readouterr().out)
    assert data["mode"] == "url" and data["grade"] == "A"


# ------------------------------------------------------------------ config file
def test_config_file_in_scanned_folder(write, capsys):
    root = write({".gitignore": "x", "app/admin/page.tsx": "export default () => null",
                  "shipsafe.yml": "fail_on: high\nignore_rules:\n  - SS-XSS-INNERHTML\nbrand_name: Cfg Brand\n"})
    assert run(["scan", str(root)], capsys)[0] == EXIT_FINDINGS  # fail_on high from config
    assert run(["scan", str(root), "--fail-on", "critical"], capsys)[0] == EXIT_OK  # flag wins
    _, out, _ = run(["scan", str(root), "-f", "html"], capsys)
    assert "Cfg Brand" in out


def test_config_ignore_paths_and_include_build(write, capsys):
    from fakes import SECRETS

    root = write({".gitignore": "x", "dist/a.js": f'k="{SECRETS["OPENAI_KEY"]}"', "scripts/seed.ts": f'k="{SECRETS["OPENAI_KEY"]}"',
                  "shipsafe.yaml": "include_build: true\nignore_paths: [\"scripts/*\"]\n"})
    code, out, _ = run(["scan", str(root), "-f", "json"], capsys)
    assert [f["location"] for f in json.loads(out)["findings"]] == ["dist/a.js:1"]


def test_explicit_config_and_errors(write, tmp_path, capsys):
    root = write({".gitignore": "x"})
    bad = tmp_path / "bad.yml"
    bad.write_text("nonsense_key: 1\n")
    code, _, err = run(["scan", str(root), "--config", str(bad)], capsys)
    assert code == EXIT_ERROR and "unknown setting" in err
    code, _, err = run(["scan", str(root), "--config", str(tmp_path / "missing.yml")], capsys)
    assert code == EXIT_ERROR
    bad.write_text("fail_on: sometimes\n")
    assert run(["scan", str(root), "--config", str(bad)], capsys)[0] == EXIT_ERROR


def test_load_config_variants(tmp_path):
    p = tmp_path / "shipsafe.yml"
    p.write_text("ignore_rules: SS-XSS-INNERHTML\nignore_paths:\n")
    assert load_config(str(p)) == {"ignore_rules": ["SS-XSS-INNERHTML"]}
    p.write_text("- a\n- b\n")
    with pytest.raises(ConfigError):
        load_config(str(p))
    p.write_text("ignore_rules: 5\n")
    with pytest.raises(ConfigError):
        load_config(str(p))
    p.write_text("fail_on: [unclosed\n")
    with pytest.raises(ConfigError):
        load_config(str(p))
    assert find_config(str(tmp_path)) == str(p)
    assert find_config(str(tmp_path / "nope")) is None


def test_simple_yaml_fallback_parser():
    text = "# comment\nfail_on: high  # trailing\ninclude_build: yes\nbrand_name: \"My # Brand\"\nignore_rules:\n" \
           "  - SS-A\n  - 'SS-B'\nignore_paths: [a/*, b]\nlogo_url: ~\n"
    assert parse_simple_yaml(text) == {
        "fail_on": "high", "include_build": True, "brand_name": "My # Brand", "ignore_rules": ["SS-A", "SS-B"],
        "ignore_paths": ["a/*", "b"], "logo_url": None,
    }
    assert parse_simple_yaml("x: false\ny: off\nz: plain") == {"x": False, "y": False, "z": "plain"}
    with pytest.raises(ConfigError):
        parse_simple_yaml("- orphan\n")
    with pytest.raises(ConfigError):
        parse_simple_yaml("no colon here\n")
    with pytest.raises(ConfigError):
        parse_simple_yaml("  indented: 1\n")


def test_load_config_without_pyyaml(tmp_path, monkeypatch):
    import builtins

    real_import = builtins.__import__

    def fake_import(name, *args, **kwargs):
        if name == "yaml":
            raise ImportError("no yaml")
        return real_import(name, *args, **kwargs)

    monkeypatch.setattr(builtins, "__import__", fake_import)
    p = tmp_path / "shipsafe.yml"
    p.write_text("fail_on: low\nignore_rules:\n  - SS-XSS-INNERHTML\n")
    assert load_config(str(p)) == {"fail_on": "low", "ignore_rules": ["SS-XSS-INNERHTML"]}


# ------------------------------------------------------------------ python -m shipsafe
def test_python_dash_m(clean):
    env = dict(os.environ, PYTHONPATH=str(ROOT / "src"))
    proc = subprocess.run([sys.executable, "-m", "shipsafe", "scan", str(clean), "-f", "json"], capture_output=True,
                          text=True, env=env, timeout=60)
    assert proc.returncode == 0, proc.stderr
    assert json.loads(proc.stdout)["grade"] == "A"
    proc = subprocess.run([sys.executable, "-m", "shipsafe", "scan", str(clean / "nope")], capture_output=True,
                          text=True, env=env, timeout=60)
    assert proc.returncode == 2 and "Folder not found" in proc.stderr


def test_make_demo_app_script(tmp_path):
    script = ROOT / "examples" / "make_demo_app.py"
    proc = subprocess.run([sys.executable, str(script), str(tmp_path)], capture_output=True, text=True, timeout=60)
    assert proc.returncode == 0, proc.stderr
    assert (tmp_path / "leaky_next" / ".env.local").is_file()
    assert main(["scan", str(tmp_path / "leaky_next"), "--format", "json", "-o", str(tmp_path / "r.json")]) == EXIT_FINDINGS
    proc = subprocess.run([sys.executable, str(script)], capture_output=True, text=True, timeout=60)
    assert proc.returncode == 2


def test_inline_ignore_in_env_file(write, capsys):
    from fakes import SECRETS

    root = write({".gitignore": "node_modules", ".env": f"NEXT_PUBLIC_OPENAI_API_KEY={SECRETS['OPENAI_KEY']} # shipsafe-ignore\n"})
    code, out, _ = run(["scan", str(root), "-f", "json"], capsys)
    assert [f["id"] for f in json.loads(out)["findings"]] == ["SS-ENV-NOT-IGNORED"]


def test_skill_and_workflow_files_exist():
    skill = (ROOT / "skills" / "shipsafe-audit" / "SKILL.md").read_text(encoding="utf-8")
    assert skill.startswith("---\nname: shipsafe-audit\ndescription: ")
    front = skill.split("---")[1]
    desc = front.split("description:", 1)[1].strip()
    assert len(desc) <= 1024
    assert (ROOT / "examples" / ".github" / "workflows" / "shipsafe.yml").is_file()


# ------------------------------------------------------------------ nothing to scan
@pytest.mark.parametrize("files", [{}, {"node_modules/x.js": "y", "logo.png": b"\x89PNG\x00\x00"}])
def test_scan_with_no_source_files_is_an_error(write, tmp_path, capsys, files):
    root = write(files)
    report = tmp_path / "report.html"
    code, out, err = run(["scan", str(root), "--format", "html", "-o", str(report)], capsys)
    assert code == EXIT_ERROR
    assert f"Nothing was scanned in {root}: no source files found. Check the folder path." in err
    assert "Grade" not in out and not report.exists()


def test_make_demo_app_works_from_a_fresh_copy(tmp_path):
    import shutil

    copy = tmp_path / "shipsafe"
    shutil.copytree(ROOT, copy, ignore=shutil.ignore_patterns("__pycache__", ".pytest_cache", "*.egg-info", "build"))
    proc = subprocess.run([sys.executable, str(copy / "examples" / "make_demo_app.py"), str(tmp_path / "demo")],
                          capture_output=True, text=True, timeout=60, cwd=tmp_path)
    assert proc.returncode == 0, proc.stderr
    assert (tmp_path / "demo" / "leaky_next" / "components" / "Chat.tsx").is_file()
    proc = subprocess.run([sys.executable, str(copy / "examples" / "make_demo_app.py"), str(tmp_path / "d2"), "nope"],
                          capture_output=True, text=True, timeout=60, cwd=tmp_path)
    assert proc.returncode == 2 and "Unknown demo app" in proc.stderr and "leaky_next" in proc.stderr
    shutil.rmtree(copy / "tests")
    proc = subprocess.run([sys.executable, str(copy / "examples" / "make_demo_app.py"), str(tmp_path / "d3")],
                          capture_output=True, text=True, timeout=60, cwd=tmp_path)
    assert proc.returncode == 2 and "full copy of the shipsafe folder" in proc.stderr


def test_docs_do_not_point_at_pypi():
    skill = (ROOT / "skills" / "shipsafe-audit" / "SKILL.md").read_text(encoding="utf-8")
    assert "pipx install shipsafe`" not in skill.replace("Never run `pip install shipsafe` or `pipx install shipsafe`", "")
    assert "python3 -m pip install <path-to-shipsafe-folder>" in skill and "py -m pip install" in skill
    readme = (ROOT / "README.md").read_text(encoding="utf-8")
    assert "pipx install ./shipsafe" not in readme and "pipx install ." in readme
    workflow = (ROOT / "examples" / ".github" / "workflows" / "shipsafe.yml").read_text(encoding="utf-8")
    assert "run: pip install shipsafe" not in workflow
    assert "make_demo_app.py ./demo" in readme.split("## Quickstart", 1)[1].split("```", 2)[1]
