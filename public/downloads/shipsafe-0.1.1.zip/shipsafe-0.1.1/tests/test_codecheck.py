import pytest

from shipsafe import codecheck as cc


@pytest.mark.parametrize(
    "path, text, kind",
    [
        ("components/Button.tsx", "", "client"),
        ("lib/util.ts", '"use client";\nexport {}', "client"),
        ("lib/util.ts", "// comment\n'use client'\n", "client"),
        ("lib/actions.ts", '"use server";', "server"),
        ("lib/db.ts", 'import "server-only";', "server"),
        ("app/api/chat/route.ts", "", "server"),
        ("pages/api/x.ts", "", "server"),
        ("supabase/functions/a/index.ts", "", "server"),
        ("netlify/functions/a.js", "", "server"),
        ("server/index.js", "", "server"),
        ("backend/main.py", "", "server"),
        ("src/App.tsx", "", "client"),
        ("index.html", "", "client"),
        ("lib/util.ts", "", "unknown"),
    ],
)
def test_file_kind(path, text, kind):
    assert cc.file_kind(path, text) == kind


@pytest.mark.parametrize(
    "path, expected",
    [
        ("__tests__/a.ts", True),
        ("src/a.test.tsx", True),
        ("src/a.spec.js", True),
        ("tests/x.py", True),
        ("e2e/login.ts", True),
        ("src/latest.ts", False),
        ("src/contest/x.ts", False),
    ],
)
def test_is_test_file(path, expected):
    assert cc.is_test_file(path) is expected


@pytest.mark.parametrize(
    "path, text, expected",
    [
        ("app/api/chat/route.ts", "", "Next.js route handler"),
        ("src/app/(main)/api/x/route.js", "", "Next.js route handler"),
        ("pages/api/hello.ts", "", "Next.js API route"),
        ("supabase/functions/gen/index.ts", "", "Supabase Edge Function"),
        ("netlify/functions/ai.mjs", "", "Netlify function"),
        ("api/chat.ts", "", "Vercel function"),
        ("server/app.ts", "const app = new Hono();", "server handler"),
        ("srv/main.js", "const app = express();", "server handler"),
        ("srv/main.js", "router.post('/chat', h)", "server handler"),
        ("lib/actions.ts", '"use server";\nexport async function x() {}', "server action"),
        ("components/Chat.tsx", "export {}", None),
        ("README.md", "app.post('/x')", None),
    ],
)
def test_server_route_kind(path, text, expected):
    assert cc.server_route_kind(path, text) == expected


AI_ROUTE = 'import OpenAI from "openai";\nexport async function POST(req) { return openai.chat.completions.create({}); }\n'


def ids(findings):
    return sorted(f.rule_id for f in findings)


def test_ai_endpoint_unprotected():
    f = cc.check_ai_endpoint("app/api/chat/route.ts", AI_ROUTE)
    assert ids(f) == ["SS-AI-ENDPOINT-NO-AUTH", "SS-AI-ENDPOINT-NO-RATELIMIT"]
    assert f[0].location == "app/api/chat/route.ts:1"
    assert "OpenAI" in f[0].why


@pytest.mark.parametrize(
    "guard",
    [
        "const { data: { user } } = await supabase.auth.getUser();",
        "const session = await getServerSession(authOptions);",
        "const { userId } = auth();",
        "const token = req.headers.get('authorization');",
        "jwt.verify(token, secret);",
        "import { currentUser } from '@clerk/nextjs/server';",
    ],
)
def test_ai_endpoint_auth_signs(guard):
    f = cc.check_ai_endpoint("app/api/chat/route.ts", AI_ROUTE + guard)
    assert ids(f) == ["SS-AI-ENDPOINT-NO-RATELIMIT"]


@pytest.mark.parametrize("rl", ["import { Ratelimit } from '@upstash/ratelimit';", "rateLimit({ max: 5 })", "const limiter = x"])
def test_ai_endpoint_ratelimit_signs(rl):
    f = cc.check_ai_endpoint("app/api/chat/route.ts", AI_ROUTE + rl + "\nawait supabase.auth.getUser()")
    assert f == []


def test_outbound_authorization_header_is_not_an_auth_check():
    text = 'const r = await fetch("https://api.anthropic.com/v1/messages", { headers: { Authorization: `Bearer ${k}` } });'
    f = cc.check_ai_endpoint("supabase/functions/x/index.ts", text)
    assert "SS-AI-ENDPOINT-NO-AUTH" in ids(f)
    assert "Anthropic" in f[0].fix_prompt


def test_gemini_and_deno_imports_detected():
    for imp in ['import { GoogleGenerativeAI } from "@google/generative-ai";', 'import OpenAI from "npm:openai@4";',
                'import OpenAI from "https://esm.sh/openai@4.0.0";']:
        assert cc.ai_provider_matches(imp), imp


def test_global_middleware_protects_next_routes_only():
    assert cc.check_ai_endpoint("app/api/chat/route.ts", AI_ROUTE, global_auth=True, global_ratelimit=True) == []
    f = cc.check_ai_endpoint("supabase/functions/x/index.ts", 'import OpenAI from "npm:openai";', global_auth=True)
    assert "SS-AI-ENDPOINT-NO-AUTH" in ids(f)


def test_non_route_or_non_ai_files_ignored():
    assert cc.check_ai_endpoint("lib/ai.ts", AI_ROUTE) == []
    assert cc.check_ai_endpoint("app/api/x/route.ts", "export function GET() {}") == []


def test_browser_ai():
    f = cc.check_browser_ai("components/Chat.tsx", "new OpenAI({ dangerouslyAllowBrowser: true })", "unknown")
    assert ids(f) == ["SS-AI-CALL-FROM-BROWSER"]
    f = cc.check_browser_ai("src/ai.ts", 'fetch("https://api.anthropic.com/v1/messages")', "client")
    assert ids(f) == ["SS-AI-CALL-FROM-BROWSER"]
    assert cc.check_browser_ai("lib/ai.ts", 'fetch("https://api.openai.com/v1")', "unknown") == []
    assert cc.check_browser_ai("bundle.js", "x={dangerouslyAllowBrowser:!0}", "client")


def test_public_env_refs():
    text = "a = import.meta.env.VITE_OPENAI_API_KEY; b = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY; " \
           "c = process.env['REACT_APP_STRIPE_SECRET']; d = import.meta.env.VITE_OPENAI_API_KEY"
    f = cc.check_public_env_refs("src/x.ts", text)
    assert [x.evidence for x in f] == ["VITE_OPENAI_API_KEY", "REACT_APP_STRIPE_SECRET"]
    assert "VITE_" in f[0].fix_prompt


@pytest.mark.parametrize(
    "path, expected",
    [
        ("app/admin/page.tsx", True),
        ("src/app/(dash)/admin/users/page.tsx", True),
        ("app/admin/layout.tsx", False),
        ("app/admin/components/Table.tsx", False),
        ("app/api/admin/route.ts", True),
        ("pages/admin.tsx", True),
        ("pages/admin/index.jsx", True),
        ("pages/api/admin/stats.ts", True),
        ("src/pages/Admin.tsx", True),
        ("src/routes/admin/+page.svelte", True),
        ("components/AdminPanel.tsx", False),
        ("lib/admin.ts", False),
        ("app/admin/page.test.tsx", False),
        ("docs/admin.md", False),
    ],
)
def test_is_admin_route(path, expected):
    assert cc.is_admin_route(path) is expected


def test_admin_route_protection():
    page = "export default function P() { return <h1/> }"
    assert ids(cc.check_admin_route("app/admin/page.tsx", page, {})) == ["SS-ADMIN-NO-AUTH"]
    assert cc.check_admin_route("app/admin/page.tsx", page + "\nconst s = await getSession()", {}) == []
    assert cc.check_admin_route("app/admin/users/page.tsx", page, {"app/admin": "await supabase.auth.getUser()"}) == []
    assert cc.check_admin_route("app/admin/page.tsx", page, {"": "useSession()"}) == []
    assert cc.check_admin_route("app/admin/page.tsx", page, {}, global_auth=True) == []
    assert cc.check_admin_route("app/admin/page.tsx", page, {"app/other": "getUser()"})


def test_cors():
    assert ids(cc.check_cors("srv.js", "app.use(cors({ origin: '*', credentials: true }))")) == ["SS-CORS-WILDCARD-CREDENTIALS"]
    assert ids(cc.check_cors("vercel.json", '{"key": "Access-Control-Allow-Origin", "value": "*"},'
                             '{"key": "Access-Control-Allow-Credentials", "value": "true"}'))
    assert cc.check_cors("srv.js", "cors({ origin: '*' })") == []
    assert cc.check_cors("srv.js", "cors({ origin: 'https://a.com', credentials: true })") == []
    assert cc.check_cors("srv.js", "axios.get(u, { withCredentials: true }); h['Access-Control-Allow-Origin'] = 'https://a'") == []


@pytest.mark.parametrize(
    "text, hits",
    [
        ("<div dangerouslySetInnerHTML={{ __html: post.body }} />", 1),
        ('<div dangerouslySetInnerHTML={{ __html: "<b>hi</b>" }} />', 0),
        ("<div dangerouslySetInnerHTML={{ __html: `<b>${name}</b>` }} />", 1),
        ("el.innerHTML = userInput;", 1),
        ("el.innerHTML += more;", 1),
        ("el.innerHTML = '';", 0),
        ("el.innerHTML = '<p>static</p>';", 0),
        ('<div v-html="comment.body"></div>', 1),
    ],
)
def test_raw_html(text, hits):
    assert len(cc.check_raw_html("c.tsx", text)) == hits


def test_raw_html_evidence_is_scrubbed():
    from fakes import SECRETS

    text = f'el.innerHTML = render("{SECRETS["OPENAI_KEY"]}")'
    f = cc.check_raw_html("c.js", text)
    assert SECRETS["OPENAI_KEY"] not in f[0].evidence


def test_firebase_rules():
    rules = """
    match /a/{x} { allow read, write: if true; }
    match /b/{x} { allow read: if true; }
    match /c/{x} { allow read; }
    match /d/{x} { allow create: if true; }
    match /e/{x} { allow read, write: if request.auth != null; }
    match /f/{x} { allow read, write: if request.time < timestamp.date(2025, 1, 1); }
    """
    f = cc.check_firebase_rules("firestore.rules", rules)
    got = sorted((x.rule_id, x.line) for x in f)
    assert got == [
        ("SS-FIREBASE-OPEN-RULES", 2),
        ("SS-FIREBASE-OPEN-RULES", 5),
        ("SS-FIREBASE-PUBLIC-READ", 3),
        ("SS-FIREBASE-PUBLIC-READ", 4),
        ("SS-FIREBASE-TEST-MODE", 7),
    ]


def test_realtime_database_rules():
    f = cc.check_firebase_rules("database.rules.json", '{"rules": {".read": true, ".write": "true"}}')
    assert ids(f) == ["SS-FIREBASE-OPEN-RULES", "SS-FIREBASE-PUBLIC-READ"]
    assert cc.check_firebase_rules("database.rules.json", '{"rules": {".read": "auth != null"}}') == []


def test_is_firebase_rules_file():
    assert cc.is_firebase_rules_file("firestore.rules")
    assert cc.is_firebase_rules_file("firebase/storage.rules")
    assert cc.is_firebase_rules_file("database.rules.json")
    assert not cc.is_firebase_rules_file("rules.ts")


# ------------------------------------------------------------------ literal apiKey in browser code
def test_client_api_key_check():
    key = "Zx9Qa8Wb7Ec6Rd5Tf4Yg3Uh2Ij1Ok0Pl"
    plain = cc.check_client_api_keys("components/Map.tsx", f'"use client";\nconst m = init({{ apiKey: "{key}" }});\n')
    assert [(f.rule_id, f.severity, f.location) for f in plain] == [
        ("SS-SECRET-CLIENT-APIKEY", "medium", "components/Map.tsx:2")]
    assert key not in plain[0].evidence and "Zx9Q…" in plain[0].evidence
    ai = cc.check_client_api_keys("components/B.tsx", f'import OpenAI from "openai";\nnew OpenAI({{ apiKey: "{key}" }});')
    assert [f.severity for f in ai] == ["high"]
    assert cc.check_client_api_keys("components/C.tsx", "new OpenAI({ apiKey: process.env.X })") == []
