import pytest

from shipsafe.gitignore import is_ignored, load_gitignores, parse_gitignore


@pytest.mark.parametrize(
    "rules, path, expected",
    [
        (".env", ".env", True),
        (".env", "apps/web/.env", True),
        (".env", ".env.local", False),
        (".env*", ".env.local", True),
        (".env*\n!.env.example", ".env.example", False),
        (".env*\n!.env.example", ".env.production", True),
        ("*.local", ".env.local", True),
        (".env*.local", ".env.development.local", True),
        ("/.env", ".env", True),
        ("/.env", "sub/.env", False),
        ("config/.env", "config/.env", True),
        ("config/.env", "other/config/.env", False),
        ("**/.env", "a/b/.env", True),
        ("secrets/", "secrets/.env", True),
        ("secrets/", "secrets", False),
        ("node_modules", "node_modules/x/.env", True),
        (".env.[lp]*", ".env.local", True),
        (".env.[!l]*", ".env.local", False),
        ("# comment\n\n.env", ".env", True),
        ("\\#weird", "#weird", True),
        ("logs/**", "logs/a/b.txt", True),
        ("a?c", "abc", True),
    ],
)
def test_matching(rules, path, expected):
    assert is_ignored(path, parse_gitignore(rules)) is expected


def test_nested_gitignore_applies_to_its_own_folder(tmp_path):
    (tmp_path / "web").mkdir()
    (tmp_path / ".gitignore").write_text("node_modules\n")
    (tmp_path / "web" / ".gitignore").write_text(".env.local\n")
    patterns = load_gitignores(str(tmp_path), [".gitignore", "web/.gitignore"])
    assert is_ignored("web/.env.local", patterns)
    assert not is_ignored(".env.local", patterns)


def test_missing_gitignore_file_is_skipped(tmp_path):
    assert load_gitignores(str(tmp_path), [".gitignore"]) == []
