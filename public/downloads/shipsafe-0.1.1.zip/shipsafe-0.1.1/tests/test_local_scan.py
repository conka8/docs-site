import os

import pytest

from fakes import SECRETS
from shipsafe import scan_directory
from shipsafe.findings import SEVERITY_RANK
from shipsafe.local_scan import MAX_FILE_SIZE, ScanError, is_binary, is_env_file, walk
from shipsafe.rules import RULES

URL_ONLY_RULES = {"SS-EXPOSED-FILE", "SS-HEADER-CSP", "SS-HEADER-FRAME", "SS-HEADER-HSTS", "SS-SUPABASE-TABLE-READABLE"}


def by_rule(result):
    out = {}
    for f in result.findings:
        out.setdefault(f.rule_id, []).append(f)
    return out


def locs(result, rule_id):
    return sorted(f.location for f in result.findings if f.rule_id == rule_id)


# ------------------------------------------------------------------ leaky app
def test_leaky_app_expected_findings(leaky):
    r = scan_directory(str(leaky))
    got = by_rule(r)
    expected_locations = {
        "SS-PUBLIC-ENV-SECRET": [".env.local:3", ".env.local:4"],
        "SS-SECRET-STRIPE-LIVE": [".env.local:5", "lib/integrations.ts:12"],
        "SS-SECRET-PASSWORD": [".env.local:6", "lib/integrations.ts:10"],
        "SS-SUPABASE-ANON-KEY": [".env.local:2"],
        "SS-SUPABASE-SERVICE-ROLE": ["lib/supabaseAdmin.ts:7"],
        "SS-SECRET-PRIVATE-KEY": ["keys/service-account.json:4"],
        "SS-SECRET-ANTHROPIC": ["lib/integrations.ts:2"],
        "SS-SECRET-GITHUB": ["lib/integrations.ts:3"],
        "SS-SECRET-AWS": ["lib/integrations.ts:4"],
        "SS-SECRET-SENDGRID": ["lib/integrations.ts:5"],
        "SS-SECRET-SLACK": ["lib/integrations.ts:6"],
        "SS-SECRET-TWILIO": ["lib/integrations.ts:7"],
        "SS-SECRET-GOOGLE": ["lib/integrations.ts:8"],
        "SS-SECRET-STRIPE-TEST": ["lib/integrations.ts:9"],
        "SS-SECRET-OPENAI": ["__tests__/billing.test.ts:3"],
        "SS-ENV-NOT-IGNORED": [".env.local"],
        "SS-GITIGNORE-MISSING": [".gitignore"],
        "SS-AI-ENDPOINT-NO-AUTH": ["app/api/chat/route.ts:1", "supabase/functions/generate/index.ts:3"],
        "SS-AI-ENDPOINT-NO-RATELIMIT": [
            "app/api/chat/route.ts:1", "app/api/summarize/route.ts:1", "supabase/functions/generate/index.ts:3",
        ],
        "SS-AI-CALL-FROM-BROWSER": ["components/Chat.tsx:4"],
        "SS-SECRET-CLIENT-APIKEY": ["components/Assistant.tsx:4"],
        "SS-PUBLIC-ENV-SECRET-NAME": ["components/Chat.tsx:4"],
        "SS-ADMIN-NO-AUTH": ["app/admin/page.tsx"],
        "SS-RLS-OPEN-POLICY": [
            "supabase/migrations/20240101000000_init.sql:25", "supabase/migrations/20240101000000_init.sql:8",
        ],
        "SS-RLS-MISSING": ["supabase/migrations/20240101000000_init.sql:12"],
        "SS-RLS-NO-POLICY": ["supabase/migrations/20240101000000_init.sql:19"],
        "SS-STORAGE-PUBLIC-BUCKET": ["components/Upload.tsx:5", "supabase/migrations/20240101000000_init.sql:29"],
        "SS-CORS-WILDCARD-CREDENTIALS": ["pages/api/proxy.ts:4"],
        "SS-XSS-INNERHTML": ["components/Comment.tsx:2"],
        "SS-FIREBASE-TEST-MODE": ["firestore.rules:5"],
        "SS-FIREBASE-OPEN-RULES": ["storage.rules:5"],
    }
    assert {k: sorted(f.location for f in v) for k, v in got.items()} == {k: sorted(v) for k, v in expected_locations.items()}


def test_leaky_severities(leaky):
    r = scan_directory(str(leaky))
    sev = {(f.rule_id, f.location): f.severity for f in r.findings}
    assert sev[("SS-PUBLIC-ENV-SECRET", ".env.local:3")] == "critical"
    assert sev[("SS-SUPABASE-SERVICE-ROLE", "lib/supabaseAdmin.ts:7")] == "critical"
    assert sev[("SS-SECRET-OPENAI", "__tests__/billing.test.ts:3")] == "low"  # test file
    assert sev[("SS-SUPABASE-ANON-KEY", ".env.local:2")] == "info"
    assert sev[("SS-SECRET-GOOGLE", "lib/integrations.ts:8")] == "medium"
    assert r.should_fail("critical")
    stripe_env = next(f for f in r.findings if f.location == ".env.local:5")
    assert stripe_env.title.endswith("(in a .env file that git will upload)")
    assert "git rm --cached" in stripe_env.fix_prompt and ".env.local:5" in stripe_env.fix_prompt
    stripe_code = next(f for f in r.findings if f.location == "lib/integrations.ts:12")
    assert "Stripe dashboard" in stripe_code.fix_prompt


def test_leaky_findings_sorted_by_severity(leaky):
    r = scan_directory(str(leaky))
    ranks = [SEVERITY_RANK[f.severity] for f in r.findings]
    assert ranks == sorted(ranks, reverse=True)


def test_every_finding_is_complete(leaky):
    for f in scan_directory(str(leaky)).findings:
        assert f.rule_id in RULES
        assert f.severity in SEVERITY_RANK
        assert f.title and f.why and f.fix_prompt and f.location
        assert "{" not in f.title and "{location}" not in f.fix_prompt and "{table}" not in f.fix_prompt
        assert "{name}" not in f.fix_prompt and "{provider}" not in f.why and "{file}" not in f.fix_prompt


def test_inline_ignore_comments(leaky):
    r = scan_directory(str(leaky))
    lines = {f.location for f in r.findings}
    assert "lib/integrations.ts:11" not in lines  # "// shipsafe-ignore" (all rules)
    assert "lib/integrations.ts:12" in lines  # ignore for another rule id does not hide Stripe
    assert "lib/integrations.ts:14" not in lines  # shipsafe-ignore-next-line SS-SECRET-GITHUB
    assert not any("scratch" in f.title for f in r.findings)  # SQL "-- shipsafe-ignore"


def test_ignore_file_comment(write):
    root = write({".gitignore": "x", "app/admin/page.tsx": "// shipsafe-ignore-file\nexport default () => null"})
    assert scan_directory(str(root)).findings == []


def test_ignore_rules_option(leaky):
    r = scan_directory(str(leaky), ignore_rules=["ss-xss-innerhtml", "SS-GITIGNORE-MISSING"])
    assert "SS-XSS-INNERHTML" not in by_rule(r)
    assert "SS-GITIGNORE-MISSING" not in by_rule(r)


def test_ignore_paths_option(leaky):
    r = scan_directory(str(leaky), ignore_paths=["lib/*", "supabase"])
    assert not any(f.location.startswith(("lib/", "supabase/")) for f in r.findings)
    assert r.skipped.get("ignored_files") and r.skipped.get("ignored_dirs")


# ------------------------------------------------------------------ clean app
def test_clean_app_has_no_high_or_critical(clean):
    r = scan_directory(str(clean))
    bad = [(f.rule_id, f.location) for f in r.findings if SEVERITY_RANK[f.severity] >= SEVERITY_RANK["medium"]]
    assert bad == []
    assert not r.should_fail("critical") and not r.should_fail("high") and not r.should_fail("medium")


def test_clean_app_exact_findings(clean):
    r = scan_directory(str(clean))
    assert sorted((f.rule_id, f.location, f.severity) for f in r.findings) == [
        ("SS-SECRET-OPENAI", "__tests__/payments.test.ts:2", "low"),
        ("SS-SECRET-STRIPE-TEST", "__tests__/payments.test.ts:1", "low"),
        ("SS-SUPABASE-ANON-KEY", ".env.local:2", "info"),
        ("SS-SUPABASE-ANON-KEY", "lib/anon.ts:2", "info"),
    ]


def test_gitignored_env_secrets_are_not_flagged(clean):
    r = scan_directory(str(clean))
    assert not any(f.file == ".env.local" and f.rule_id != "SS-SUPABASE-ANON-KEY" for f in r.findings)


# ------------------------------------------------------------------ firebase / vite
def test_firebase_app(firebase):
    r = scan_directory(str(firebase))
    assert sorted((f.rule_id, f.location, f.severity) for f in r.findings) == [
        ("SS-AI-ENDPOINT-NO-AUTH", "functions/index.js:2", "high"),
        ("SS-AI-ENDPOINT-NO-RATELIMIT", "functions/index.js:2", "medium"),
        ("SS-FIREBASE-OPEN-RULES", "storage.rules:5", "critical"),
        ("SS-FIREBASE-PUBLIC-READ", "database.rules.json:3", "medium"),
        ("SS-FIREBASE-PUBLIC-READ", "firestore.rules:8", "medium"),
        ("SS-FIREBASE-TEST-MODE", "firestore.rules:5", "high"),
        ("SS-SECRET-GOOGLE", "src/firebase.ts:4", "low"),
    ]


def test_vite_app(vite):
    r = scan_directory(str(vite))
    assert sorted((f.rule_id, f.location, f.severity) for f in r.findings) == [
        ("SS-ADMIN-NO-AUTH", "src/pages/Admin.tsx", "high"),
        ("SS-AI-CALL-FROM-BROWSER", "src/lib/ai.ts:2", "high"),
        ("SS-AI-ENDPOINT-NO-AUTH", "server/index.js:3", "high"),
        ("SS-CORS-WILDCARD-CREDENTIALS", "vercel.json:4", "medium"),
        ("SS-ENV-NOT-IGNORED", ".env", "high"),
        ("SS-PUBLIC-ENV-SECRET", ".env:3", "critical"),
        ("SS-PUBLIC-ENV-SECRET-NAME", "src/lib/ai.ts:5", "high"),
        ("SS-SUPABASE-ANON-KEY", ".env:2", "info"),
        ("SS-XSS-INNERHTML", "src/main.tsx:6", "low"),
    ]


def test_fixtures_cover_every_local_rule(leaky, clean, firebase, vite):
    seen = set()
    for app in (leaky, clean, firebase, vite):
        seen |= {f.rule_id for f in scan_directory(str(app)).findings}
    assert seen == set(RULES) - URL_ONLY_RULES


# ------------------------------------------------------------------ walking / skipping
def test_node_modules_and_git_are_skipped(write):
    key = SECRETS["OPENAI_KEY"]
    root = write({
        ".gitignore": "node_modules\n",
        "node_modules/openai/index.js": f'const k = "{key}";',
        ".git/config": f"token = {key}",
        "src/ok.ts": "export const x = 1;",
    })
    r = scan_directory(str(root))
    assert r.findings == []
    assert r.skipped["ignored_dirs"] == 2


def test_build_dirs_skipped_unless_included(write):
    key = SECRETS["STRIPE_LIVE"]
    root = write({".gitignore": "dist\n", "dist/assets/index-abc.js": f'var k="{key}";',
                  ".next/static/chunks/main.js": f'var k="{key}";'})
    assert scan_directory(str(root)).findings == []
    r = scan_directory(str(root), include_build=True)
    assert sorted(f.location for f in r.findings) == [".next/static/chunks/main.js:1", "dist/assets/index-abc.js:1"]
    assert all(f.severity == "critical" for f in r.findings)


def test_binary_and_large_files_skipped(write):
    key = SECRETS["OPENAI_KEY"]
    big = ("x" * 1000 + "\n") * (MAX_FILE_SIZE // 1000 + 10) + f'k="{key}"'
    root = write({
        ".gitignore": "x",
        "assets/blob.dat": b"\x00\x01binary" + key.encode(),
        "assets/logo.png": key.encode(),
        "data/huge.js": big,
    })
    r = scan_directory(str(root))
    assert r.findings == []
    assert r.skipped["binary"] == 2
    assert r.skipped["too_large"] == 1
    assert r.files_scanned == 1  # only .gitignore


def test_custom_max_file_size(write):
    root = write({".gitignore": "x", "a.ts": f'k = "{SECRETS["OPENAI_KEY"]}"'})
    assert scan_directory(str(root), max_file_size=10).findings == []


def test_lockfiles_skipped(write):
    root = write({".gitignore": "x", "package-lock.json": f'"k": "{SECRETS["OPENAI_KEY"]}"'})
    assert scan_directory(str(root)).findings == []


def test_server_code_secret_downgraded_to_high(write):
    root = write({".gitignore": "x", "app/api/pay/route.ts": f'const stripe = "{SECRETS["STRIPE_LIVE"]}";'})
    (f,) = scan_directory(str(root)).findings
    assert f.severity == "high" and f.title.endswith("(server code)")


def test_client_code_secret_stays_critical(write):
    root = write({".gitignore": "x", "src/App.tsx": f'const key = "{SECRETS["OPENAI_KEY"]}";'})
    (f,) = scan_directory(str(root)).findings
    assert f.severity == "critical" and f.rule_id == "SS-SECRET-OPENAI"


def test_public_env_in_config_files(write):
    root = write({".gitignore": "x", "netlify.toml": f'[build.environment]\nVITE_OPENAI_KEY = "{SECRETS["OPENAI_KEY"]}"\n'})
    (f,) = scan_directory(str(root)).findings
    assert f.rule_id == "SS-PUBLIC-ENV-SECRET" and f.location == "netlify.toml:2"


def test_env_example_with_real_key_is_flagged(write):
    root = write({".gitignore": ".env*\n!.env.example", ".env.example": f"OPENAI_API_KEY={SECRETS['OPENAI_KEY']}\n"})
    (f,) = scan_directory(str(root)).findings
    assert f.rule_id == "SS-SECRET-OPENAI" and f.location == ".env.example:1"


@pytest.mark.parametrize("name", [".env", ".env.local", ".env.production", ".env.development.local", "prod.env"])
def test_env_files_not_in_gitignore(write, name):
    root = write({".gitignore": "node_modules\n", name: "PORT=3000\n"})
    (f,) = scan_directory(str(root)).findings
    assert f.rule_id == "SS-ENV-NOT-IGNORED" and name in f.title and name in f.fix_prompt


def test_env_values_quoted_and_exported(write):
    root = write({".env.local": f"export NEXT_PUBLIC_OPENAI_API_KEY=\"{SECRETS['OPENAI_KEY']}\" # comment\n"
                                f"REACT_APP_STRIPE_KEY='{SECRETS['STRIPE_LIVE']}'\n", ".gitignore": ".env*"})
    r = scan_directory(str(root))
    assert [(f.rule_id, f.line) for f in r.findings] == [("SS-PUBLIC-ENV-SECRET", 1), ("SS-PUBLIC-ENV-SECRET", 2)]


def test_middleware_auth_protects_routes(write):
    root = write({
        ".gitignore": "x",
        "middleware.ts": "export async function middleware(req) { const { data } = await supabase.auth.getUser(); }",
        "app/admin/page.tsx": "export default function A() { return null }",
        "app/api/chat/route.ts": 'import OpenAI from "openai";\n',
    })
    r = scan_directory(str(root))
    assert [f.rule_id for f in r.findings] == ["SS-AI-ENDPOINT-NO-RATELIMIT"]


def test_test_files_skip_code_checks(write):
    root = write({
        ".gitignore": "x",
        "__tests__/admin/page.test.tsx": "<div dangerouslySetInnerHTML={{ __html: x }} />",
        "tests/fixtures/db.sql": "create table t (id int);",
        "tests/fixtures/firestore.rules": "allow read, write: if true;",
    })
    assert scan_directory(str(root)).findings == []


def test_missing_folder_raises(tmp_path):
    with pytest.raises(ScanError):
        scan_directory(str(tmp_path / "nope"))


def test_empty_folder(tmp_path):
    r = scan_directory(str(tmp_path))
    assert [f.rule_id for f in r.findings] == ["SS-GITIGNORE-MISSING"]
    assert r.notes


def test_walk_and_helpers(write):
    root = write({"a.txt": "x", "node_modules/b.txt": "y", "dist/c.js": "z", "src/d.ts": "w"})
    files, skipped = walk(str(root))
    assert files == ["a.txt", "src/d.ts"]
    files, _ = walk(str(root), include_build=True)
    assert "dist/c.js" in files
    assert is_binary(b"abc\x00", "x.txt") and is_binary(b"abc", "x.woff2") and not is_binary(b"abc", "x.ts")
    assert is_env_file(".env") and is_env_file("web/.env.local") and not is_env_file(".env.example")
    assert not is_env_file("environment.ts")


def test_symlinked_dirs_not_followed(write, tmp_path):
    root = write({".gitignore": "x", "real/a.ts": f'k="{SECRETS["OPENAI_KEY"]}"'})
    try:
        os.symlink(root / "real", root / "link")
    except OSError:
        pytest.skip("symlinks not supported")
    r = scan_directory(str(root))
    assert [f.location for f in r.findings] == ["real/a.ts:1"]


def test_repeated_findings_capped_per_file(write):
    root = write({".gitignore": "x", "src/a.js": "el.innerHTML = x;\n" * 30})
    r = scan_directory(str(root))
    assert len(r.findings) == 10
    assert any("20 repeated finding" in n for n in r.notes)


def test_minified_one_line_bundle_evidence_is_short(write):
    line = "var a=1;" * 5000 + "el.innerHTML=userText;" + "var b=2;" * 5000
    root = write({".gitignore": "x", "src/bundle.js": line})
    (f,) = scan_directory(str(root)).findings
    assert "innerHTML=userText" in f.evidence and len(f.evidence) <= 140


def test_client_api_key_only_in_browser_code(write):
    key = "Zx9Qa8Wb7Ec6Rd5Tf4Yg3Uh2Ij1Ok0Pl"
    code = f'import OpenAI from "openai";\nconst client = new OpenAI({{ apiKey: "{key}" }});\n'
    root = write({
        ".gitignore": "node_modules",
        "components/B.tsx": '"use client";\n' + code,
        "app/api/chat/route.ts": code + "export async function POST() { await getUser(); ratelimit(); }\n",
        "components/Ok.tsx": '"use client";\n' + code.replace(");\n", "); // shipsafe-ignore SS-SECRET-CLIENT-APIKEY\n"),
    })
    r = scan_directory(str(root))
    hits = [(f.location, f.severity) for f in r.findings if f.rule_id == "SS-SECRET-CLIENT-APIKEY"]
    assert hits == [("components/B.tsx:3", "high")]
    assert all(key not in f.evidence for f in r.findings)


def test_evidence_masks_named_secret_near_raw_html(write):
    root = write({".gitignore": "x", "components/A.tsx": (
        '"use client";\nexport const A = () => <div dangerouslySetInnerHTML={{ __html: render({ token: '
        '"mysupersecretvalue_9988776655" }) }} />;\n')})
    [f] = [f for f in scan_directory(str(root)).findings if f.rule_id == "SS-XSS-INNERHTML"]
    assert "mysupersecretvalue" not in f.evidence and 'token: "mysu…"' in f.evidence
