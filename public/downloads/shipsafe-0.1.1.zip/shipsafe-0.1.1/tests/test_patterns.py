import pytest

from fakes import SECRETS, b64url, make_jwt
from shipsafe.findings import ELLIPSIS, redact, severity_at_least
from shipsafe.patterns import (
    decode_jwt,
    find_secrets,
    is_placeholder,
    is_secret_env_name,
    jwt_ref,
    jwt_role,
    line_of,
    line_starts,
    public_env_value_is_secret,
    public_prefix,
    scrub,
)


def rule_ids(text):
    return [h.rule_id for h in find_secrets(text)]


# --------------------------------------------------------------- redaction
def test_redact_keeps_first_four_chars():
    assert redact("sk-proj-abcdefghijklmnop") == "sk-p" + ELLIPSIS


def test_redact_short_values_keep_one_char():
    assert redact("hunter2") == "h" + ELLIPSIS
    assert redact("12345678") == "1" + ELLIPSIS


def test_redact_empty():
    assert redact("") == ""
    assert redact("   ") == ""
    assert redact(None) == ""


def test_severity_at_least():
    assert severity_at_least("critical", "high")
    assert severity_at_least("high", "high")
    assert not severity_at_least("medium", "high")
    assert not severity_at_least("critical", "never")


# ---------------------------------------------------------- provider keys
@pytest.mark.parametrize(
    "key, rule",
    [
        ("OPENAI_KEY", "SS-SECRET-OPENAI"),
        ("OPENAI_KEY2", "SS-SECRET-OPENAI"),
        ("ANTHROPIC_KEY", "SS-SECRET-ANTHROPIC"),
        ("STRIPE_LIVE", "SS-SECRET-STRIPE-LIVE"),
        ("STRIPE_TEST", "SS-SECRET-STRIPE-TEST"),
        ("AWS_KEY", "SS-SECRET-AWS"),
        ("GITHUB_TOKEN", "SS-SECRET-GITHUB"),
        ("GOOGLE_KEY", "SS-SECRET-GOOGLE"),
        ("SLACK_TOKEN", "SS-SECRET-SLACK"),
        ("SENDGRID_KEY", "SS-SECRET-SENDGRID"),
        ("TWILIO_KEY", "SS-SECRET-TWILIO"),
        ("SERVICE_ROLE_JWT", "SS-SUPABASE-SERVICE-ROLE"),
        ("ANON_JWT", "SS-SUPABASE-ANON-KEY"),
    ],
)
def test_each_provider_pattern_is_detected(key, rule):
    hits = find_secrets(f'const value = "{SECRETS[key]}";')
    assert [h.rule_id for h in hits] == [rule]
    assert hits[0].value == SECRETS[key]


def test_anthropic_key_is_not_reported_as_openai():
    assert rule_ids(SECRETS["ANTHROPIC_KEY"]) == ["SS-SECRET-ANTHROPIC"]


def test_github_fine_grained_pat():
    pat = "github_" + "pat_" + "11ABCDEFG0" + "a1B2c3D4e5F6g7H8i9J0kLmNoPqRsTuVwXyZ"
    assert rule_ids(f"token={pat}") == ["SS-SECRET-GITHUB"]


def test_slack_webhook_url():
    url = "https://hooks.slack.com/services/" + "T0123ABCD/B0456EFGH/" + "abcdefGHIJKL0123456789xy"
    assert rule_ids(url) == ["SS-SECRET-SLACK"]


def test_twilio_auth_token_assignment():
    assert rule_ids('TWILIO_AUTH_TOKEN: "0123456789abcdef0123456789abcdef"') == ["SS-SECRET-TWILIO"]


def test_supabase_new_style_keys():
    secret = "sb_" + "secret_" + "AbCdEf0123456789xyzXYZ"
    publishable = "sb_" + "publishable_" + "AbCdEf0123456789xyzXYZ"
    assert rule_ids(secret) == ["SS-SUPABASE-SERVICE-ROLE"]
    assert rule_ids(publishable) == ["SS-SUPABASE-ANON-KEY"]


def test_google_key_is_low_in_firebase_config():
    text = f'const firebaseConfig = {{ apiKey: "{SECRETS["GOOGLE_KEY"]}", authDomain: "x.firebaseapp.com" }};'
    hits = find_secrets(text)
    assert hits[0].rule_id == "SS-SECRET-GOOGLE" and hits[0].severity == "low"
    assert find_secrets(f'key = "{SECRETS["GOOGLE_KEY"]}"')[0].severity is None


def test_private_key_block_detected_and_body_not_double_reported():
    body = "MIIEv" + SECRETS["PRIVATE_KEY_BODY"]
    text = f"-----BEGIN RSA PRIVATE KEY-----\n{body}\nAKIA{'A' * 16}\n-----END RSA PRIVATE KEY-----\n"
    hits = find_secrets(text)
    assert [h.rule_id for h in hits] == ["SS-SECRET-PRIVATE-KEY"]
    assert hits[0].value == "-----BEGIN RSA PRIVATE KEY-----"


def test_private_key_without_end_marker():
    hits = find_secrets("-----BEGIN OPENSSH PRIVATE KEY-----\nabc")
    assert [h.rule_id for h in hits] == ["SS-SECRET-PRIVATE-KEY"]


@pytest.mark.parametrize(
    "text",
    [
        "className='sk-loading-spinner-container-wrapper'",  # css class, no digits/uppercase
        "OPENAI_API_KEY=sk-your-key-here",
        "sk-proj-xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx",
        "AKIAIOSFODNN7EXAMPLE",  # AWS documentation example key
        "task-a1B2c3D4e5F6g7H8i9J0kLmNoPq",  # 'sk-' inside a word
        "sk_live_your_live_key_here",
        "process.env.OPENAI_API_KEY",
        "pk_live_" + "a1B2c3D4e5F6g7H8i9J0",  # publishable keys are public
    ],
)
def test_no_false_positives(text):
    assert rule_ids(text) == []


# --------------------------------------------------------------- passwords
@pytest.mark.parametrize(
    "text",
    [
        'const adminPassword = "Hunter2!xyz";',
        'DB_PASSWORD: "abc123!!"',
        "jwtSecret = 'mys3cr3t-value'",
        '{"client_secret": "a1b2c3d4e5f6"}',
    ],
)
def test_password_heuristic_hits(text):
    assert rule_ids(text) == ["SS-SECRET-PASSWORD"]


@pytest.mark.parametrize(
    "text",
    [
        '"password": "Passwort"',  # translation label: letters only
        'passwordMinLength: "12345678"',
        'const passwordLabel = "Password1";',
        'password: "${DB_PASSWORD}"',
        "password: process.env.DB_PASSWORD",
        '<input type="password" name="password" />',
        'secret: "JWT_SECRET"',
        'password: "your-password-here"',
        'password = "abc"',  # too short
        'secretary: "bob12345"',
    ],
)
def test_password_heuristic_misses(text):
    assert rule_ids(text) == []


# -------------------------------------------------------------------- JWTs
def test_decode_jwt_roundtrip():
    header, payload = decode_jwt(make_jwt("service_role"))
    assert header["alg"] == "HS256"
    assert payload["role"] == "service_role"
    assert jwt_role(make_jwt("anon")) == "anon"
    assert jwt_ref(make_jwt("anon", ref="myref")) == "myref"


@pytest.mark.parametrize("token", ["", "abc", "a.b", "a.b.c", "eyJ.eyJ.sig", b64url(b"[1]") + "." + b64url(b"[2]") + ".sig"])
def test_decode_jwt_rejects_garbage(token):
    assert decode_jwt(token) is None
    assert jwt_role(token) is None
    assert jwt_ref(token) is None


def test_jwt_without_role_is_ignored():
    token = b64url({"alg": "HS256"}) + "." + b64url({"sub": "user-123456"}) + ".signaturesig"
    assert find_secrets(token) == []
    assert jwt_role(token) is None


def test_jwt_with_other_role_is_ignored():
    assert find_secrets(make_jwt("authenticated")) == []


# ------------------------------------------------------------------- misc
def test_is_placeholder():
    assert is_placeholder("sk-your-key")
    assert is_placeholder("<API_KEY>")
    assert is_placeholder("sk-aaaaaaaaaaaa")
    assert is_placeholder("change-me")
    assert not is_placeholder(SECRETS["OPENAI_KEY"])


def test_env_name_helpers():
    assert is_secret_env_name("NEXT_PUBLIC_OPENAI_API_KEY")
    assert is_secret_env_name("VITE_SUPABASE_SERVICE_ROLE_KEY")
    assert not is_secret_env_name("NEXT_PUBLIC_SUPABASE_ANON_KEY")
    assert not is_secret_env_name("VITE_OPENAI_BASE_URL")
    assert not is_secret_env_name("NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY")
    assert public_prefix("EXPO_PUBLIC_X") == "EXPO_PUBLIC_"
    assert public_prefix("REACT_APP_X") == "REACT_APP_"
    assert public_prefix("SECRET") is None


@pytest.mark.parametrize(
    "name, value, expected",
    [
        ("NEXT_PUBLIC_OPENAI_API_KEY", SECRETS["OPENAI_KEY"], True),
        ("NEXT_PUBLIC_SB_KEY", SECRETS["SERVICE_ROLE_JWT"], True),
        ("VITE_STRIPE", SECRETS["STRIPE_LIVE"], True),
        ("REACT_APP_JWT_SECRET", "a-long-random-secret-value-123", True),
        ("NEXT_PUBLIC_SUPABASE_ANON_KEY", SECRETS["ANON_JWT"], False),
        ("NEXT_PUBLIC_FIREBASE_API_KEY", SECRETS["GOOGLE_KEY"], False),
        ("NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY", SECRETS["STRIPE_PK"], False),
        ("NEXT_PUBLIC_OPENAI_API_KEY", "", False),
        ("NEXT_PUBLIC_OPENAI_API_KEY", "process.env.OPENAI_API_KEY", False),
        ("NEXT_PUBLIC_OPENAI_API_KEY", "sk-your-key-here", False),
        ("EXPO_PUBLIC_SECRET_THING", "${SECRET_THING}", False),
        ("NEXT_PUBLIC_SITE_URL", "https://example.org", False),
    ],
)
def test_public_env_value_is_secret(name, value, expected):
    assert public_env_value_is_secret(name, value) is expected


def test_scrub_redacts_all_secret_shapes():
    text = " ".join(SECRETS[k] for k in ("OPENAI_KEY", "STRIPE_LIVE", "SERVICE_ROLE_JWT", "ANON_JWT", "AWS_KEY"))
    text += ' password: "Hunter2!xyz"'
    out = scrub(text)
    for k in ("OPENAI_KEY", "STRIPE_LIVE", "SERVICE_ROLE_JWT", "ANON_JWT", "AWS_KEY"):
        assert SECRETS[k] not in out
        assert SECRETS[k][:4] + ELLIPSIS in out
    assert "Hunter2!xyz" not in out


def test_scrub_is_aggressive_for_unvalidated_shapes():
    # fails the OpenAI validator (no uppercase) but still looks like a key: redact anyway
    out = scrub("token sk-abcdefghijklmnopqrstuvwxyz0123")
    assert "abcdefghijklmnop" not in out


def test_scrub_empty():
    assert scrub("") == ""


def test_line_helpers():
    text = "a\nbb\n\nccc"
    starts = line_starts(text)
    assert starts == [0, 2, 5, 6]
    assert line_of(starts, 0) == 1
    assert line_of(starts, 3) == 2
    assert line_of(starts, 5) == 3
    assert line_of(starts, 8) == 4


# ------------------------------------------------------------------ masking named values
@pytest.mark.parametrize("line, expected", [
    ('render({ token: "mysupersecretvalue_9988776655" })', 'render({ token: "mysu…" })'),
    ('new OpenAI({ apiKey: "Zx9Qa8Wb7Ec6Rd5Tf4Yg3Uh2Ij1Ok0Pl" });', 'new OpenAI({ apiKey: "Zx9Q…" });'),
    ("const API_KEY = 'abcdefghij123'", "const API_KEY = 'abcd…'"),
    ('client_secret="qwertyuiop12"', 'client_secret="qwer…"'),
    ('db_password: "hunter2hunter2"', 'db_password: "hunt…"'),
    ('headers: { Authorization: "Bearer abcdefghijklmnop" }', 'headers: { Authorization: "Bear…" }'),
    ('const auth = "abcdefghijkl', 'const auth = "abcd…'),  # snippet cut off before the closing quote
    ('const authToken = `tok_abcdefghij`', 'const authToken = `tok_…`'),
])
def test_scrub_masks_values_of_secret_sounding_names(line, expected):
    from shipsafe.patterns import scrub

    assert scrub(line) == expected


@pytest.mark.parametrize("line", [
    'authDomain: "my-app.firebaseapp.com"',
    'author: "Jane Doe"',
    "apiKey: process.env.OPENAI_API_KEY",
    'tokenUrl: "https://example.com/oauth/token"',
    'password: ""',
    'const title = "Hello world"',
])
def test_scrub_leaves_ordinary_values_alone(line):
    from shipsafe.patterns import scrub

    assert scrub(line) == line


def test_find_client_api_keys():
    from shipsafe.patterns import find_client_api_keys

    text = (
        'a({ apiKey: "Zx9Qa8Wb7Ec6Rd5Tf4Yg3Uh2Ij1Ok0Pl" })\n'
        f'b({{ apiKey: "{SECRETS["GOOGLE_KEY"]}" }})\n'       # known provider pattern: reported by its own rule
        'c({ apiKey: "your-api-key-goes-here-123" })\n'     # placeholder
        'd({ apiKey: "short1" })\n'                          # too short
        'e({ apiKey: "pk_live_abcdefghijklmnop1234" })\n'   # publishable by design
        'f({ api_key: "abcdefghijklmnopqrstuvwxyz" })\n'    # no digits: not key-shaped
    )
    assert [v for _, v in find_client_api_keys(text)] == ["Zx9Qa8Wb7Ec6Rd5Tf4Yg3Uh2Ij1Ok0Pl"]
