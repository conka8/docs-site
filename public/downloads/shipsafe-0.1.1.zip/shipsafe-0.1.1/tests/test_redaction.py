"""No full secret may ever appear in any output format, for any fixture or scan mode."""

import json

import pytest

from fakes import NEVER_PRINT, SECRETS
from shipsafe import scan_directory, scan_url
from shipsafe.cli import main
from shipsafe.report import FORMATS, render
from shipsafe.transport import HttpResponse

ALL_FIXTURES = ["leaky_next", "clean_next", "firebase_app", "vite_app"]


def assert_no_secrets(text):
    for key in NEVER_PRINT:
        value = SECRETS[key]
        assert value not in text, f"{key} leaked in output"
        # also no long chunk of it (e.g. a JWT signature or key body)
        assert value[6:30] not in text, f"part of {key} leaked in output"


@pytest.mark.parametrize("fixture", ALL_FIXTURES)
@pytest.mark.parametrize("fmt", FORMATS)
def test_local_reports_never_contain_secrets(make_app, fixture, fmt):
    result = scan_directory(str(make_app(fixture)))
    out = render(result, fmt)
    assert_no_secrets(out)


@pytest.mark.parametrize("fmt", FORMATS)
def test_redacted_prefix_is_shown(leaky, fmt):
    out = render(scan_directory(str(leaky)), fmt)
    if fmt == "json":
        out = json.loads(out)
        out = json.dumps(out, ensure_ascii=False)
    for key in ("STRIPE_LIVE", "ANTHROPIC_KEY", "AWS_KEY", "SERVICE_ROLE_JWT"):
        assert SECRETS[key][:4] + "…" in out


def test_anon_key_also_redacted(leaky):
    out = render(scan_directory(str(leaky)), "text")
    assert SECRETS["ANON_JWT"] not in out


@pytest.mark.parametrize("fmt", FORMATS)
def test_cli_stdout_never_contains_secrets(leaky, capsys, fmt):
    main(["scan", str(leaky), "--format", fmt])
    assert_no_secrets(capsys.readouterr().out)


@pytest.mark.parametrize("fmt", FORMATS)
def test_url_reports_never_contain_secrets(fmt):
    site = "https://app.example.com"
    bundle = " ".join(f'"{SECRETS[k]}"' for k in NEVER_PRINT if k not in ("PRIVATE_KEY_BODY", "PASSWORD", "PASSWORD2"))
    env = f"OPENAI_API_KEY={SECRETS['OPENAI_KEY']}\n"
    routes = {
        site: HttpResponse(200, {"content-type": "text/html"}, b'<script src="/a.js"></script>'),
        site + "/a.js": HttpResponse(200, {}, bundle.encode()),
        site + "/.env": HttpResponse(200, {"content-type": "text/plain"}, env.encode()),
    }

    def transport(method, url, headers):
        return routes.get(url) or HttpResponse(404, {}, b"", url)

    out = render(scan_url(site, transport=transport), fmt)
    assert_no_secrets(out)
    assert "SS-EXPOSED-FILE" in out
