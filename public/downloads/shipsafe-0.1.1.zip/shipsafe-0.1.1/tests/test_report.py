import json

import pytest

from shipsafe.findings import Finding, ScanResult
from shipsafe.report import (
    DEFAULT_BRAND_COLOR,
    is_valid_color,
    is_valid_logo_url,
    render,
    render_html,
    render_json,
    render_markdown,
    render_text,
    score_and_grade,
)
from shipsafe.rules import make_finding


def result_with(*severities, mode="scan"):
    findings = []
    for i, sev in enumerate(severities):
        findings.append(make_finding("SS-XSS-INNERHTML", f"a.tsx:{i + 1}", "x", severity=sev, file="a.tsx", line=i + 1))
    return ScanResult(target="/tmp/app", mode=mode, findings=findings, files_scanned=3)


@pytest.mark.parametrize(
    "sevs, score, grade",
    [
        ((), 100, "A"),
        (("info", "info"), 100, "A"),
        (("low",), 99, "A"),
        (("medium",), 95, "A"),
        (("medium", "medium", "medium"), 85, "B"),
        (("high",), 88, "C"),
        (("high", "high"), 76, "C"),
        (("high", "high", "medium", "medium"), 66, "D"),
        (("high", "high", "high", "high"), 52, "F"),
        (("critical",), 70, "F"),
        (("critical",) * 5, 0, "F"),
    ],
)
def test_score_and_grade(sevs, score, grade):
    assert score_and_grade(result_with(*sevs)) == (score, grade)


def test_text_report():
    r = result_with("high", "low")
    r.notes.append("a note")
    r.skipped = {"binary": 2}
    out = render_text(r)
    assert "Grade:  C" in out
    assert "1. [HIGH] Raw HTML is inserted into the page  (SS-XSS-INNERHTML)" in out
    assert "Where: a.tsx:1" in out and "Fix prompt (copy the next line" in out
    assert "\n     In a.tsx:1 my code inserts raw HTML" in out  # whole prompt on one line
    assert "a note" in out and "skipped 2 binary" in out


def test_text_report_empty():
    out = render_text(ScanResult(target="x", mode="url"))
    assert "No problems found" in out and "page/script(s)" in out


def test_json_report_is_valid_and_complete():
    data = json.loads(render_json(result_with("critical", "info")))
    assert data["tool"] == "shipsafe" and data["grade"] == "F"
    assert data["counts"] == {"critical": 1, "high": 0, "medium": 0, "low": 0, "info": 1}
    f = data["findings"][0]
    assert set(f) == {"id", "severity", "title", "why", "location", "file", "line", "evidence", "fix_prompt"}
    assert "fingerprint" not in f


def test_markdown_report():
    r = result_with("medium")
    r.findings[0].title = "pipe | title"
    r.findings[0].evidence = "a `tick` here"
    r.findings[0].fix_prompt = "do this ``` now"
    out = render_markdown(r)
    assert out.startswith("# shipsafe report: grade A (95/100)")
    assert "pipe \\| title" in out
    assert "```text\ndo this ''' now\n```" in out
    assert "a 'tick' here" in out


def test_markdown_empty_and_notes():
    r = ScanResult(target="x", mode="scan", notes=["n1"])
    out = render_markdown(r)
    assert "No problems found" in out and "## Notes" in out and "- n1" in out


def test_html_report_structure():
    out = render_html(result_with("critical", "high", "low"), brand_name="Vibe Academy", brand_color="#ff6600",
                      logo_url="https://example.org/logo.png")
    assert out.startswith("<!DOCTYPE html>")
    assert "<style>" in out and "--brand:#ff6600" in out
    assert "Vibe Academy launch safety report" in out
    assert '<img src="https://example.org/logo.png"' in out
    assert 'class="grade g-F"' in out
    assert out.count('class="finding"') == 3
    assert out.count("Copy fix prompt") == 3 and 'id="fix-1"' in out
    assert "@media print" in out
    assert "<link" not in out  # self-contained: no external stylesheets
    # sorted order preserved: critical card first
    assert out.index("CRITICAL") < out.index(">HIGH<") < out.index(">LOW<")


def test_html_escapes_everything():
    f = Finding("SS-XSS-INNERHTML", "low", "<script>alert(1)</script>", "why <b>", "a<x>.tsx:1",
                '<img src=x onerror=alert(1)>', "fix </pre><script>bad()</script>", "a.tsx", 1)
    r = ScanResult(target="<target>", mode="scan", findings=[f], notes=["<note>"])
    out = render_html(r, brand_name="<b>Evil</b>", brand_color="red;}</style><script>x()</script>",
                      logo_url='https://x.org/" onerror="alert(1)')
    assert "<img src=x" not in out and "&lt;img src=x onerror=alert(1)&gt;" in out
    assert "<script>alert(1)</script>" not in out and "<script>bad()</script>" not in out
    assert "<b>Evil</b>" not in out and "&lt;b&gt;Evil&lt;/b&gt;" in out
    assert "&lt;target&gt;" in out and "&lt;note&gt;" in out
    assert f"--brand:{DEFAULT_BRAND_COLOR}" in out  # invalid color rejected
    assert 'onerror="alert(1)' not in out
    assert out.count("<script>") == 1  # only our own copy-button script


def test_html_empty_and_bad_logo():
    out = render_html(ScanResult(target="x", mode="scan"), logo_url="javascript:alert(1)")
    assert "No problems found" in out and "javascript:" not in out and "shipsafe launch safety report" in out


def test_render_dispatch():
    r = result_with("low")
    assert render(r, "text") == render_text(r)
    assert render(r, "json") == render_json(r)
    assert render(r, "md") == render_markdown(r)
    assert render(r, "html", brand_name="X").startswith("<!DOCTYPE html>")
    with pytest.raises(ValueError):
        render(r, "pdf")


def test_color_and_logo_validation():
    assert is_valid_color("#fff") and is_valid_color("#FF6600") and is_valid_color("teal")
    assert not is_valid_color("#ff66001122") and not is_valid_color("red;") and not is_valid_color("")
    assert is_valid_logo_url("https://a/b.png") and is_valid_logo_url("data:image/png;base64,AAA")
    assert not is_valid_logo_url("javascript:alert(1)")


# ------------------------------------------------------------------ honest wording
def test_verdicts_do_not_overclaim():
    from shipsafe.report import NO_FINDINGS, SCOPE_NOTE, verdict

    assert verdict("A") == "No serious problems found by shipsafe's checks."
    for grade in "ABCDF":
        assert "good to launch" not in verdict(grade).lower()
    empty = ScanResult(target="x", mode="scan", files_scanned=3)
    for fmt in FORMATS_WITH_SCOPE:
        out = render(empty, fmt)
        assert NO_FINDINGS in out and SCOPE_NOTE in out and "Nice work" not in out
    html_out = render_html(empty)
    assert "No problems found by shipsafe&#x27;s checks." in html_out and "not a full security audit" in html_out


def test_scope_note_also_shown_with_findings():
    from shipsafe.report import SCOPE_NOTE

    r = result_with("high")
    assert render_text(r).rstrip().endswith(SCOPE_NOTE)
    assert SCOPE_NOTE in render_markdown(r)


FORMATS_WITH_SCOPE = ("text", "md")
