from shipsafe.sqlcheck import SqlState, check_js_buckets, normalize_table, strip_sql_comments


def run(*files):
    state = SqlState()
    for i, text in enumerate(files):
        state.add_file(f"supabase/migrations/{i:03d}.sql", text)
    return state.finish()


def ids(findings):
    return sorted(f.rule_id for f in findings)


def test_table_without_rls():
    f = run("create table todos (id int);")
    assert ids(f) == ["SS-RLS-MISSING"]
    assert f[0].title.endswith("todos")
    assert f[0].location == "supabase/migrations/000.sql:1"
    assert "todos" in f[0].fix_prompt


def test_rls_enabled_in_a_later_migration_counts():
    assert run("create table public.todos (id int);",
               "alter table todos enable row level security;\n"
               "create policy p on todos for select using (auth.uid() = user_id);") == []


def test_rls_without_policy():
    assert ids(run("create table t (id int); alter table t enable row level security;")) == ["SS-RLS-NO-POLICY"]


def test_rls_disabled_again():
    sql = "create table t (id int);\nalter table t enable row level security;\nalter table t disable row level security;"
    assert ids(run(sql)) == ["SS-RLS-MISSING"]


def test_quoted_and_schema_names_normalize():
    assert normalize_table('public."Todos"') == ("public", "todos")
    assert normalize_table("t") == ("public", "t")
    assert normalize_table('"private" . jobs') == ("private", "jobs")
    sql = 'create table if not exists "public"."Todos" (id int);\nalter table only public.todos enable row level security;\n' \
          'create policy "x" on "Todos" for all using (auth.uid() = owner);'
    assert run(sql) == []


def test_non_public_schema_ignored():
    assert run("create table private.jobs (id int);") == []


def test_commented_out_sql_is_ignored():
    sql = "-- create table ghost (id int);\n/* create table ghost2 (id int);\n */ select 1;"
    assert run(sql) == []


def test_comment_markers_inside_strings_survive():
    clean = strip_sql_comments("select '--not a comment' as x; -- real comment\nselect 2;")
    assert "--not a comment" in clean
    assert "real comment" not in clean
    assert clean.count("\n") == 1


def test_open_policies():
    sql = """
create table t (id int);
alter table t enable row level security;
create policy a on t for update using (true);
create policy b on t for delete using ( true );
create policy c on t for insert with check (true);
create policy d on t using (true);
create policy e on t for select using (true);
create policy f on t for update using (auth.uid() = id) with check (auth.uid() = id);
"""
    f = run(sql)
    open_ = [x for x in f if x.rule_id == "SS-RLS-OPEN-POLICY"]
    assert [x.line for x in open_] == [4, 5, 6, 7]
    assert "UPDATE" in open_[0].fix_prompt and "ALL" in open_[3].fix_prompt


def test_storage_objects_open_insert_policy():
    f = run('create policy "uploads" on storage.objects for insert with check (true);')
    assert ids(f) == ["SS-RLS-OPEN-POLICY"]
    assert "storage.objects" in f[0].title


def test_public_bucket_sql():
    assert ids(run("insert into storage.buckets (id, name, public) values ('a', 'a', true);")) == ["SS-STORAGE-PUBLIC-BUCKET"]
    assert run("insert into storage.buckets (id, name, public) values ('a', 'a', false);") == []
    assert run("insert into storage.buckets (id, name) values ('a', 'a');") == []
    assert ids(run("update storage.buckets set public = true where id = 'a';")) == ["SS-STORAGE-PUBLIC-BUCKET"]


def test_public_bucket_js():
    js = 'await supabase.storage.createBucket("docs", {\n  public: true,\n  fileSizeLimit: 1024\n});'
    f = check_js_buckets("lib/x.ts", js)
    assert ids(f) == ["SS-STORAGE-PUBLIC-BUCKET"] and f[0].line == 1
    assert check_js_buckets("lib/x.ts", 'createBucket("docs", { public: false })') == []
