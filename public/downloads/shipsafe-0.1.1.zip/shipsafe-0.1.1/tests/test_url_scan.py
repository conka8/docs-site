import json
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

import pytest

from fakes import SECRETS, SUPABASE_REF, make_jwt
from shipsafe import scan_url
from shipsafe.local_scan import ScanError
from shipsafe.transport import USER_AGENT, HttpResponse, TransportError, make_urllib_transport
from shipsafe.url_scan import (
    NOT_FOUND_PROBE_PATH,
    exposed_file_evidence,
    extract_scripts,
    probe_supabase,
)

SITE = "https://app.example.com"
SB = f"https://{SUPABASE_REF}.supabase.co"
SECURE_HEADERS = {
    "content-type": "text/html",
    "content-security-policy": "default-src 'self'; frame-ancestors 'none'",
    "strict-transport-security": "max-age=63072000",
    "x-frame-options": "DENY",
}

HOME = """<!doctype html><html><head>
<link rel="modulepreload" href="/assets/vendor-1.js">
<script type="module" src="/assets/index-abc.js"></script>
<script src="https://cdn.other.com/widget.js"></script>
<script src="//cdn.other.com/x.js"></script>
</head><body><div id="root"></div>
<script>window.__CONFIG__ = {}</script></body></html>"""

BUNDLE = (
    f'const sb=createClient("{SB}","{SECRETS["ANON_JWT"]}");'
    f'const o=new OpenAI({{apiKey:"{SECRETS["OPENAI_KEY"]}",dangerouslyAllowBrowser:!0}});\n'
    'sb.from("profiles").select("*");sb.from("orders").select();sb.storage.from("avatars").upload(f);'
)


class FakeWeb:
    """An injectable transport: maps URLs to responses and records every request."""

    def __init__(self, routes=None, default=None):
        self.routes = dict(routes or {})
        self.default = default
        self.calls = []

    def __call__(self, method, url, headers):
        self.calls.append((method, url, dict(headers)))
        resp = self.routes.get(url)
        if resp is None and self.default is not None:
            resp = self.default(url) if callable(self.default) else self.default
        if resp is None:
            return HttpResponse(404, {"content-type": "text/plain"}, b"Not found", url)
        if isinstance(resp, Exception):
            raise resp
        if resp.url == "":
            resp.url = url
        return resp

    def urls(self):
        return [u for _, u, _ in self.calls]


def ok(body, headers=None, status=200):
    return HttpResponse(status, headers or {"content-type": "application/javascript"}, body.encode() if isinstance(body, str) else body)


def site(**overrides):
    home = HttpResponse(200, {"content-type": "text/html"}, HOME.encode())
    routes = {
        SITE: home,
        SITE + "/assets/index-abc.js": ok(BUNDLE),
        SITE + "/assets/vendor-1.js": ok("export const x = 1;"),
    }
    routes.update(overrides)
    return FakeWeb(routes)


def ids(result):
    return sorted(f.rule_id for f in result.findings)


# ------------------------------------------------------------------ bundles
def test_bundle_secrets_and_jwts_found():
    web = site()
    r = scan_url(SITE, transport=web)
    got = {(f.rule_id, f.location) for f in r.findings}
    assert ("SS-SECRET-OPENAI", SITE + "/assets/index-abc.js:1") in got
    assert ("SS-SUPABASE-ANON-KEY", SITE + "/assets/index-abc.js:1") in got
    assert ("SS-AI-CALL-FROM-BROWSER", SITE + "/assets/index-abc.js:1") in got
    openai = next(f for f in r.findings if f.rule_id == "SS-SECRET-OPENAI")
    assert openai.severity == "critical" and "live website" in openai.title
    assert openai.evidence == SECRETS["OPENAI_KEY"][:4] + "…"


def test_only_same_origin_scripts_fetched():
    web = site()
    scan_url(SITE, transport=web)
    assert not any("cdn.other.com" in u for u in web.urls())
    assert SITE + "/assets/vendor-1.js" in web.urls()


def test_user_agent_set_by_default_transport_only():
    assert USER_AGENT == "shipsafe/0.1"


def test_service_role_in_bundle_is_critical():
    web = site(**{SITE + "/assets/index-abc.js": ok(f'k="{SECRETS["SERVICE_ROLE_JWT"]}"')})
    r = scan_url(SITE, transport=web)
    f = next(f for f in r.findings if f.rule_id == "SS-SUPABASE-SERVICE-ROLE")
    assert f.severity == "critical"


def test_duplicate_secret_across_bundles_reported_once():
    body = f'k="{SECRETS["STRIPE_LIVE"]}"'
    web = site(**{SITE + "/assets/index-abc.js": ok(body), SITE + "/assets/vendor-1.js": ok(body)})
    r = scan_url(SITE, transport=web)
    assert ids(r).count("SS-SECRET-STRIPE-LIVE") == 1


def test_script_count_and_size_caps():
    many = "".join(f'<script src="/s{i}.js"></script>' for i in range(10))
    routes = {SITE: ok(f"<html>{many}</html>", {"content-type": "text/html"})}
    for i in range(10):
        routes[f"{SITE}/s{i}.js"] = ok("x" * 50 + f' k="{SECRETS["STRIPE_LIVE"]}"' if i == 0 else "y")
    web = FakeWeb(routes)
    r = scan_url(SITE, transport=web, max_scripts=3, max_script_bytes=20)
    fetched = [u for u in web.urls() if u.endswith(".js")]
    assert fetched == [f"{SITE}/s0.js", f"{SITE}/s1.js", f"{SITE}/s2.js"]
    assert "SS-SECRET-STRIPE-LIVE" not in ids(r)  # beyond the byte cap
    assert any("first 0 KB" in n or "were checked" in n for n in r.notes)


def test_script_errors_become_notes():
    web = site(**{SITE + "/assets/index-abc.js": TransportError("boom"),
                  SITE + "/assets/vendor-1.js": ok("", status=500)})
    r = scan_url(SITE, transport=web)
    assert any("boom" in n for n in r.notes) and any("HTTP 500" in n for n in r.notes)


def test_no_scripts_note():
    web = FakeWeb({SITE: ok("<html><body>hi</body></html>", SECURE_HEADERS)})
    r = scan_url(SITE, transport=web)
    assert r.findings == []
    assert any("No JavaScript" in n for n in r.notes)


def test_inline_script_in_homepage_scanned():
    html = f'<html><script>window.KEY="{SECRETS["OPENAI_KEY"]}"</script></html>'
    r = scan_url(SITE, transport=FakeWeb({SITE: ok(html, SECURE_HEADERS)}))
    assert [f.location for f in r.findings] == [SITE + ":1"]


def test_extract_scripts_helper():
    srcs, cross, csp = extract_scripts(
        '<script src="a.js"></script><script src="/a.js#x"></script><link rel="preload" as="script" href="/p.js">'
        '<link rel="stylesheet" href="/s.css"><script src="data:text/javascript,1"></script>'
        '<meta http-equiv="Content-Security-Policy" content="default-src \'self\'">',
        SITE + "/", 10,
    )
    assert srcs == [SITE + "/a.js", SITE + "/p.js"]
    assert cross == 1 and csp == "default-src 'self'"


def test_redirect_final_url_used_for_origin():
    home = HttpResponse(200, {"content-type": "text/html"}, b'<script src="/m.js"></script>', "https://www.example.com/")
    web = FakeWeb({SITE: home, "https://www.example.com/m.js": ok("x")})
    scan_url(SITE, transport=web)
    assert "https://www.example.com/m.js" in web.urls()


# ------------------------------------------------------------------ headers
def test_missing_security_headers_low():
    r = scan_url(SITE, transport=site())
    headers = [f for f in r.findings if f.rule_id.startswith("SS-HEADER-")]
    assert sorted(f.rule_id for f in headers) == ["SS-HEADER-CSP", "SS-HEADER-FRAME", "SS-HEADER-HSTS"]
    assert all(f.severity == "low" for f in headers)


def test_headers_present():
    web = site(**{SITE: HttpResponse(200, SECURE_HEADERS, HOME.encode())})
    r = scan_url(SITE, transport=web)
    assert not any(f.rule_id.startswith("SS-HEADER-") for f in r.findings)


def test_frame_ancestors_counts_and_no_hsts_on_http():
    url = "http://localhost:3000"
    web = FakeWeb({url: ok("<html></html>", {"content-security-policy": "frame-ancestors 'self'"})})
    r = scan_url(url, transport=web)
    assert ids(r) == []


def test_meta_csp_counts():
    html = '<meta http-equiv="Content-Security-Policy" content="default-src \'self\'">'
    r = scan_url(SITE, transport=FakeWeb({SITE: ok(html, {"x-frame-options": "DENY", "strict-transport-security": "x"})}))
    assert ids(r) == []


# ------------------------------------------------------------------ exposed files
ENV_BODY = f"OPENAI_API_KEY={SECRETS['OPENAI_KEY']}\nDATABASE_URL=postgres://u:p@h/db\n"


def test_exposed_env_file_detected():
    web = site(**{SITE + "/.env": ok(ENV_BODY, {"content-type": "text/plain"})})
    r = scan_url(SITE, transport=web)
    f = next(f for f in r.findings if f.rule_id == "SS-EXPOSED-FILE")
    assert f.severity == "critical" and f.location == SITE + "/.env"
    assert f.evidence.startswith("OPENAI_API_KEY=sk-p…") and "2 variable" in f.evidence
    assert SECRETS["OPENAI_KEY"] not in f.evidence


def test_exposed_git_config_detected():
    cfg = "[core]\n\trepositoryformatversion = 0\n[remote \"origin\"]\n\turl = git@github.com:me/app.git\n"
    r = scan_url(SITE, transport=site(**{SITE + "/.git/config": ok(cfg, {"content-type": "text/plain"})}))
    assert [f.location for f in r.findings if f.rule_id == "SS-EXPOSED-FILE"] == [SITE + "/.git/config"]


def test_spa_fallback_is_not_reported():
    """Every unknown path returns index.html with 200: must not be flagged."""
    home = HttpResponse(200, {"content-type": "text/html"}, HOME.encode())
    web = site()
    web.default = lambda url: HttpResponse(200, {"content-type": "text/html"}, HOME.encode(), url)
    web.routes[SITE] = home
    r = scan_url(SITE, transport=web)
    assert "SS-EXPOSED-FILE" not in ids(r)
    assert SITE + NOT_FOUND_PROBE_PATH in web.urls()


def test_spa_fallback_detected_by_baseline_even_if_not_html():
    # a catch-all route answering plain "KEY=value" text for every path is not a real .env leak
    web = site()
    web.default = lambda url: HttpResponse(200, {"content-type": "text/plain"}, b"STATUS=ok\nREGION=eu\n", url)
    r = scan_url(SITE, transport=web)
    assert "SS-EXPOSED-FILE" not in ids(r)


def test_exposed_file_evidence_rules():
    home = b"<html>home</html>"
    assert exposed_file_evidence("/.env", ok(ENV_BODY), home, None)
    assert exposed_file_evidence("/.env", ok(ENV_BODY, status=403), home, None) is None
    assert exposed_file_evidence("/.env", ok(""), home, None) is None
    assert exposed_file_evidence("/.env", ok("<html>home</html>"), home, None) is None
    assert exposed_file_evidence("/.env", ok("<!DOCTYPE html><p>404</p>"), home, None) is None
    assert exposed_file_evidence("/.env", ok("KEY=1", {"content-type": "text/html"}), home, None) is None
    assert exposed_file_evidence("/.env", ok("just some text"), home, None) is None
    assert exposed_file_evidence("/.git/config", ok("nothing here"), home, None) is None
    assert exposed_file_evidence("/.env", ok("A=1"), home, b"A=1") is None


def test_exposed_file_transport_errors_ignored():
    web = site(**{SITE + "/.env": TransportError("reset"), SITE + NOT_FOUND_PROBE_PATH: TransportError("x")})
    r = scan_url(SITE, transport=web)
    assert "SS-EXPOSED-FILE" not in ids(r)


# ------------------------------------------------------------------ supabase probe
OPENAPI = json.dumps({"swagger": "2.0", "paths": {"/": {}, "/profiles": {}, "/secrets": {}, "/rpc/do_thing": {}}})


def supabase_routes(listing=None):
    return {
        SB + "/rest/v1/": listing or ok(OPENAPI, {"content-type": "application/json"}),
        SB + "/rest/v1/profiles?select=*&limit=1": ok(json.dumps([{"id": 1, "email": "a@b.c", "full_name": "A"}])),
        SB + "/rest/v1/secrets?select=*&limit=1": ok("[]"),
        SB + "/rest/v1/orders?select=*&limit=1": ok(json.dumps([{"id": 9, "total": 5}])),
    }


def test_probe_is_off_by_default():
    web = site(**supabase_routes())
    r = scan_url(SITE, transport=web)
    assert not any("supabase.co" in u for u in web.urls())
    assert any("--probe-supabase" in n for n in r.notes)
    assert "SS-SUPABASE-TABLE-READABLE" not in ids(r)


def test_probe_reports_readable_tables():
    web = site(**supabase_routes())
    r = scan_url(SITE, transport=web, probe_supabase_tables=True)
    readable = sorted(f.title for f in r.findings if f.rule_id == "SS-SUPABASE-TABLE-READABLE")
    assert readable == ["Anyone can read the orders table", "Anyone can read the profiles table"]
    f = next(f for f in r.findings if "profiles" in f.title)
    assert f.severity == "high"
    assert "email, full_name, id" in f.evidence and "a@b.c" not in f.evidence  # column names only, never values
    # anon key sent as apikey + bearer
    sb_calls = [(u, h) for _, u, h in web.calls if "supabase.co" in u]
    assert all(h["apikey"] == SECRETS["ANON_JWT"] and h["Authorization"] == f"Bearer {SECRETS['ANON_JWT']}" for _, h in sb_calls)
    assert not any("avatars" in u for u, _ in sb_calls)  # storage bucket names are not tables
    assert not any("rpc" in u for u, _ in sb_calls)


def test_probe_falls_back_to_table_names_from_code():
    web = site(**supabase_routes(listing=ok('{"message":"forbidden"}', status=401)))
    r = scan_url(SITE, transport=web, probe_supabase_tables=True)
    assert sorted(f.title for f in r.findings if f.rule_id == "SS-SUPABASE-TABLE-READABLE") == [
        "Anyone can read the orders table", "Anyone can read the profiles table"]
    assert any("HTTP 401" in n for n in r.notes)


def test_probe_helper_edge_cases():
    web = FakeWeb({SB + "/rest/v1/": ok("not json")})
    findings, notes = probe_supabase(web, SB, "sb_publishable_abc", [])
    assert findings == [] and any("not valid JSON" in n for n in notes)
    assert "Authorization" not in web.calls[0][2]  # new-style publishable keys only go in apikey
    findings, notes = probe_supabase(FakeWeb({SB + "/rest/v1/": TransportError("down")}), SB, "k", [])
    assert findings == [] and "down" in notes[0]
    web = FakeWeb({SB + "/rest/v1/t?select=*&limit=1": ok("{bad")})
    assert probe_supabase(web, SB, "k", ["t"])[0] == []
    web = FakeWeb({SB + "/rest/v1/t?select=*&limit=1": TransportError("x")})
    assert probe_supabase(web, SB, "k", ["t"])[0] == []


def test_probe_picks_key_matching_project_ref():
    other = make_jwt("anon", ref="zzzzzzzzzzzzzzzzzzzz", seed=99)
    bundle = f'a="{other}";b="https://zzzzzzzzzzzzzzzzzzzz.supabase.co";c="{SB}";d="{SECRETS["ANON_JWT"]}"'
    web = site(**{SITE + "/assets/index-abc.js": ok(bundle)})
    scan_url(SITE, transport=web, probe_supabase_tables=True)
    sb_calls = [(u, h) for _, u, h in web.calls if "supabase.co" in u]
    assert sb_calls and all(h["apikey"] == other for u, h in sb_calls if "zzzz" in u)


# ------------------------------------------------------------------ errors / options
@pytest.mark.parametrize("bad", ["ftp://x.com", "example.com", "", "https://"])
def test_bad_urls(bad):
    with pytest.raises(ScanError):
        scan_url(bad, transport=FakeWeb())


def test_homepage_errors():
    with pytest.raises(ScanError, match="HTTP 404"):
        scan_url(SITE, transport=FakeWeb())
    with pytest.raises(ScanError, match="nope"):
        scan_url(SITE, transport=FakeWeb({SITE: TransportError("nope")}))


def test_ignore_rules_in_url_mode():
    r = scan_url(SITE, transport=site(), ignore_rules=["SS-HEADER-CSP", "ss-header-frame"])
    assert "SS-HEADER-CSP" not in ids(r) and "SS-HEADER-FRAME" not in ids(r)


# ------------------------------------------------------------------ real local HTTP server
class _Handler(BaseHTTPRequestHandler):
    files: dict = {}
    seen_agents: list = []

    def do_GET(self):  # noqa: N802
        self.seen_agents.append(self.headers.get("User-Agent"))
        path = self.path.split("?")[0]
        if path in self.files:
            ctype, body = self.files[path]
        elif path.startswith("/assets/"):
            self.send_response(404)
            self.end_headers()
            return
        else:  # SPA fallback, like Vercel/Netlify rewrites
            ctype, body = self.files["/"]
        data = body.encode()
        self.send_response(200)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def log_message(self, *args):
        pass


@pytest.fixture
def local_server():
    _Handler.files = {
        "/": ("text/html", '<html><script src="/assets/app.js"></script></html>'),
        "/assets/app.js": ("application/javascript", f'var k="{SECRETS["STRIPE_LIVE"]}";'),
        "/.env.local": ("text/plain", "SECRET_TOKEN=abcdef123456\n"),
    }
    _Handler.seen_agents = []
    server = ThreadingHTTPServer(("127.0.0.1", 0), _Handler)
    thread = threading.Thread(target=server.serve_forever, kwargs={"poll_interval": 0.01}, daemon=True)
    thread.start()
    try:
        yield f"http://127.0.0.1:{server.server_address[1]}"
    finally:
        server.shutdown()
        server.server_close()
        thread.join()


def test_real_http_server_end_to_end(local_server):
    r = scan_url(local_server, transport=make_urllib_transport(timeout=5))
    got = {(f.rule_id, f.location) for f in r.findings}
    assert ("SS-SECRET-STRIPE-LIVE", local_server + "/assets/app.js:1") in got
    assert ("SS-EXPOSED-FILE", local_server + "/.env.local") in got
    # /.env and /.git/config hit the SPA fallback and must not be reported
    assert not any(loc.endswith(("/.env", "/.git/config")) for _, loc in got)
    assert ("SS-HEADER-HSTS", local_server) not in got  # http, not https
    assert set(_Handler.seen_agents) == {"shipsafe/0.1"}


def test_urllib_transport_404_and_unreachable(local_server):
    t = make_urllib_transport(timeout=5)
    resp = t("GET", local_server + "/assets/missing.js", {})
    assert resp.status == 404
    assert t("GET", local_server + "/", {}).header("Content-Type") == "text/html"
    with pytest.raises(TransportError):
        t("GET", "http://127.0.0.1:1/", {})
