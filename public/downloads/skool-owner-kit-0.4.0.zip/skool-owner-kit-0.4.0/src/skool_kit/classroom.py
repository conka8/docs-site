"""`skool-kit classroom-to-skill`: turn exported/copied classroom lessons into a Claude / OpenClaw tutor skill.

Input folder layout (numeric prefixes set the order):

    lessons/
      01-getting-started/          <- module
        01-welcome.md              <- lesson (.md, .markdown, .txt, .html, .htm)
        02 - Your first automation.html
      02-finding-clients/
        ...
      bonus.txt                    <- top-level files go into a "General" module

Output: <out>/<name>/SKILL.md and <out>/<name>/references/<module>/<lesson>.md
"""
from __future__ import annotations

import re
import shutil
import unicodedata
from dataclasses import dataclass, field
from html.parser import HTMLParser
from pathlib import Path

LESSON_EXTS = (".md", ".markdown", ".txt", ".html", ".htm")
NAME_RE = re.compile(r"^[a-z0-9]+(?:-[a-z0-9]+)*$")
_PREFIX = re.compile(r"^\s*(\d+(?:\.\d+)*)[\s._\-)]*")


class SkillError(ValueError):
    pass


def slugify(text: str, fallback: str = "item", max_len: int = 60) -> str:
    t = unicodedata.normalize("NFKD", text).encode("ascii", "ignore").decode("ascii").lower()
    t = re.sub(r"[^a-z0-9]+", "-", t).strip("-")
    t = t[:max_len].rstrip("-")
    return t or fallback


def order_key(name: str) -> tuple:
    stem = Path(name).stem if Path(name).suffix.lower() in LESSON_EXTS else name
    m = _PREFIX.match(stem)
    if m:
        nums = tuple(int(x) for x in m.group(1).split("."))
        return (0, nums, stem[m.end():].lower())
    return (1, (), stem.lower())


def clean_title(name: str) -> str:
    stem = Path(name).stem if Path(name).suffix.lower() in LESSON_EXTS else name
    stem = _PREFIX.sub("", stem)
    stem = re.sub(r"^(module|lesson|part|chapter)\s*\d+\s*[-:._)]*\s*", "", stem, flags=re.I) or stem
    title = re.sub(r"[_\-]+", " ", stem).strip()
    title = " ".join(title.split())
    if title and title == title.lower():
        title = title[0].upper() + title[1:]
    return title or "Untitled"


class _HTMLText(HTMLParser):
    BLOCK = {"p", "div", "section", "article", "br", "tr", "table", "ul", "ol", "blockquote", "pre", "hr",
             "header", "footer", "main", "figure", "figcaption"}
    SKIP = {"script", "style", "noscript", "template", "svg", "head"}

    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.out: list[str] = []
        self.skip = 0
        self.title = ""
        self.h1 = ""
        self._in_title = False
        self._in_h1 = False
        self._href: list[str | None] = []

    def handle_starttag(self, tag, attrs):
        if tag in self.SKIP:
            self.skip += 1
        if tag == "title":
            self._in_title = True
        if self.skip:
            return
        if tag in self.BLOCK:
            self.out.append("\n\n" if tag != "br" else "\n")
        elif re.fullmatch(r"h[1-6]", tag):
            self.out.append("\n\n" + "#" * int(tag[1]) + " ")
            self._in_h1 = tag == "h1"
        elif tag == "li":
            self.out.append("\n- ")
        elif tag in ("td", "th"):
            self.out.append(" | ")
        elif tag == "a":
            self._href.append(dict(attrs).get("href"))
        elif tag == "img":
            alt = dict(attrs).get("alt")
            if alt:
                self.out.append(f"[image: {alt}]")

    def handle_endtag(self, tag):
        if tag in self.SKIP:
            self.skip = max(0, self.skip - 1)
        if tag == "title":
            self._in_title = False
        if self.skip:
            return
        if re.fullmatch(r"h[1-6]", tag):
            self.out.append("\n\n")
            self._in_h1 = False
        elif tag in self.BLOCK:
            self.out.append("\n")
        elif tag == "a" and self._href:
            href = self._href.pop()
            if href and href.startswith(("http://", "https://")):
                self.out.append(f" ({href})")

    def handle_data(self, data):
        if self._in_title:
            self.title += data
            return
        if self.skip:
            return
        if self._in_h1:
            self.h1 += data
        self.out.append(data)

    def text(self) -> str:
        raw = "".join(self.out)
        lines = [" ".join(line.split()) for line in raw.splitlines()]
        text = "\n".join(lines)
        return re.sub(r"\n{3,}", "\n\n", text).strip()


def html_to_text(source: str) -> tuple[str, str]:
    """Strip tags; return (text, title found in <h1> or <title>)."""
    p = _HTMLText()
    p.feed(source)
    p.close()
    return p.text(), (p.h1.strip() or p.title.strip())


@dataclass
class Lesson:
    path: Path
    title: str
    slug: str
    text: str
    parts: list[str] = field(default_factory=list)
    files: list[str] = field(default_factory=list)


@dataclass
class Module:
    title: str
    slug: str
    lessons: list[Lesson] = field(default_factory=list)


def read_lesson(path: Path) -> tuple[str, str, list[str]]:
    """Return (text, title_from_content, warnings)."""
    warnings = []
    raw = path.read_bytes()
    try:
        content = raw.decode("utf-8-sig")
    except UnicodeDecodeError:
        content = raw.decode("cp1252", errors="replace")
        warnings.append(f"{path.name}: not UTF-8, read as Windows-1252")
    title = ""
    if path.suffix.lower() in (".html", ".htm"):
        content, title = html_to_text(content)
    else:
        content = content.replace("\r\n", "\n").strip()
        m = re.match(r"^#\s+(.+)$", content, flags=re.M)
        if m and content.startswith("#"):
            title = m.group(1).strip()
        elif path.suffix.lower() == ".txt":
            first, _, rest = content.partition("\n")
            if first.strip() and len(first) <= 100 and rest.startswith("\n"):
                title = first.strip()  # a short first line followed by a blank line is the title
    return content, title, warnings


def split_text(text: str, max_chars: int) -> list[str]:
    """Split on paragraph boundaries into chunks of at most max_chars (hard-split huge paragraphs)."""
    if len(text) <= max_chars:
        return [text]
    paras = re.split(r"\n\s*\n", text)
    chunks, cur = [], ""
    for para in paras:
        while len(para) > max_chars:
            cut = para.rfind(" ", 0, max_chars)
            cut = cut if cut > max_chars // 2 else max_chars
            if cur:
                chunks.append(cur)
                cur = ""
            chunks.append(para[:cut].strip())
            para = para[cut:].strip()
        candidate = f"{cur}\n\n{para}" if cur else para
        if len(candidate) > max_chars and cur:
            chunks.append(cur)
            cur = para
        else:
            cur = candidate
    if cur.strip():
        chunks.append(cur)
    return [c for c in chunks if c.strip()]


def _unique(slug: str, used: set[str]) -> str:
    base, n = slug, 2
    while slug in used:
        slug = f"{base}-{n}"
        n += 1
    used.add(slug)
    return slug


def discover(lessons_dir: str | Path, max_chars: int = 12000) -> tuple[list[Module], list[str]]:
    root = Path(lessons_dir)
    if not root.is_dir():
        raise SkillError(f"lessons folder not found: {root}")
    warnings: list[str] = []
    modules: list[Module] = []
    used_mod: set[str] = set()

    def visible(p) -> bool:
        return not str(getattr(p, "name", p)).startswith((".", "_", "~"))

    entries = sorted([p for p in root.iterdir() if visible(p)], key=lambda p: order_key(p.name))
    top_files = [p for p in entries if p.is_file()]
    folders = [p for p in entries if p.is_dir()]
    groups: list[tuple[str, list[Path]]] = []
    if top_files:
        groups.append(("General", top_files))
    for folder in folders:
        files = sorted([f for f in folder.rglob("*") if f.is_file() and all(visible(x) for x in f.relative_to(folder).parts)],
                       key=lambda f: tuple(order_key(x) for x in f.relative_to(folder).parts))
        groups.append((clean_title(folder.name), files))
    for mod_title, files in groups:
        module = Module(mod_title, _unique(slugify(mod_title, "module"), used_mod))
        used_les: set[str] = set()
        for f in files:
            if f.suffix.lower() not in LESSON_EXTS:
                warnings.append(f"skipped {f.relative_to(root)}: not a lesson file ({', '.join(LESSON_EXTS)})")
                continue
            text, content_title, w = read_lesson(f)
            warnings += w
            if not text.strip():
                warnings.append(f"empty lesson skipped: {f.relative_to(root)}")
                continue
            title = content_title or clean_title(f.name)
            lesson = Lesson(f, title, _unique(slugify(title, "lesson"), used_les), text)
            lesson.parts = split_text(text, max_chars)
            module.lessons.append(lesson)
        if module.lessons:
            modules.append(module)
        else:
            used_mod.discard(module.slug)
            warnings.append(f"module '{mod_title}' has no usable lessons")
    if not modules:
        raise SkillError(f"no lessons found in {root} (looked for {', '.join(LESSON_EXTS)})")
    return modules, warnings


def validate_name(name: str) -> str:
    if not NAME_RE.match(name or "") or len(name) > 64:
        raise SkillError(f"skill name {name!r} must be lowercase letters, digits and hyphens, max 64 characters "
                         f"(e.g. {slugify(name or 'my-community-tutor', 'my-community-tutor')[:64]!r})")
    return name


def build_description(community: str, modules: list[Module], n_lessons: int) -> str:
    topics = ", ".join(m.title for m in modules)
    base = (f"Tutor for the {community} classroom. Answers members' questions using {n_lessons} lessons from "
            f"{len(modules)} modules")
    tail = (f". Use when a member asks how to do something taught in {community}, wants a lesson explained or "
            f"summarised, or asks which lesson covers a topic.")
    desc = f"{base} ({topics}){tail}"
    if len(desc) > 1024:
        room = 1024 - len(base) - len(tail) - 6
        desc = f"{base} ({topics[:max(0, room)].rsplit(',', 1)[0]}, ...){tail}"
    return desc[:1024]


def _md_cell(text: str) -> str:
    return str(text).replace("|", "\\|").replace("\n", " ")


def build_skill(lessons_dir: str | Path, name: str, out_dir: str | Path, community: str = "",
                classroom_url: str = "", max_chars: int = 12000, force: bool = False, support: str = "",
                support_channel: str = "") -> dict:
    import yaml
    validate_name(name)
    if max_chars < 500:
        raise SkillError("--max-chars must be at least 500")
    modules, warnings = discover(lessons_dir, max_chars)
    community = community or name.replace("-", " ").title()
    target = Path(out_dir) / name
    if target.exists() and any(target.iterdir()):
        if not force:
            raise SkillError(f"{target} already exists and is not empty; use --force to replace it")
        shutil.rmtree(target)
    refs = target / "references"
    refs.mkdir(parents=True, exist_ok=True)
    rows = []
    n_lessons = 0
    n = 0
    for module in modules:
        (refs / module.slug).mkdir(exist_ok=True)
        for lesson in module.lessons:
            n += 1
            n_lessons += 1
            total = len(lesson.parts)
            for i, part in enumerate(lesson.parts, 1):
                fname = f"{lesson.slug}.md" if total == 1 else f"{lesson.slug}-part-{i}.md"
                rel = f"references/{module.slug}/{fname}"
                heading = lesson.title if total == 1 else f"{lesson.title} (part {i} of {total})"
                header = [f"# {heading}", "", f"Module: {module.title}  ",
                          f"Source file: {lesson.path.relative_to(Path(lessons_dir)).as_posix()}  "]
                if classroom_url:
                    header.append(f"Classroom: {classroom_url}  ")
                body = part
                if total == 1 or i == 1:
                    body = re.sub(r"^#\s+.+\n+", "", body, count=1) if body.startswith("# ") else body
                (target / rel).write_text("\n".join(header) + "\n\n" + body.strip() + "\n", encoding="utf-8")
                lesson.files.append(rel)
            files = ", ".join(f"[{Path(f).name}]({f})" for f in lesson.files)
            rows.append(f"| {n} | {_md_cell(module.title)} | {_md_cell(lesson.title)} | {files} |")
    description = build_description(community, modules, n_lessons)
    front = yaml.safe_dump({"name": name, "description": description}, sort_keys=False, allow_unicode=True,
                           width=100000).strip()
    channel = (support_channel or support).rstrip(". ")
    ask_line = (f"give them a short message to post in {channel}: their question, what they're working on, "
                f"and which lesson they checked" if channel else "suggest asking in the community")
    owner_line = (f"tell them: {support.rstrip('. ')}" if support else "tell them to contact the community owner")
    link_line = (f"Link members back to the classroom so they can watch the full lesson: {classroom_url}"
                 if classroom_url else
                 "Tell members to open the lesson in the community's Classroom tab to watch the full video.")
    body = f"""---
{front}
---

# {community} tutor

You help members of {community} with questions about the course material. The lessons are in the
`references/` folder next to this file; the index below lists every lesson in classroom order.

## How to answer

1. Find the lessons that match the question in the index below and read those reference files before answering.
   Long lessons are split into parts: read every part of a lesson you rely on.
2. Answer in plain, friendly English, step by step. Members are often non-technical: explain jargon.
3. Base the answer on the lessons. Cite them by title, like: *(Lesson: "{modules[0].lessons[0].title}", module "{modules[0].title}")*.
4. {link_line}
5. If the lessons do not cover the question, say so clearly ("This isn't covered in the classroom yet").
   You may add general guidance, but label it as your own suggestion, and {ask_line}.
6. Never invent lesson names, results, prices, offers or promises that are not in the lessons.
7. If a question is about a member's account, billing or access, {owner_line}.

## Lesson index

| # | Module | Lesson | File(s) |
|---|---|---|---|
""" + "\n".join(rows) + "\n"
    (target / "SKILL.md").write_text(body, encoding="utf-8")
    return {
        "skill_dir": str(target), "name": name, "description": description, "modules": len(modules),
        "lessons": n_lessons, "files": sum(len(lesson.files) for m in modules for lesson in m.lessons),
        "split_lessons": [lesson.title for m in modules for lesson in m.lessons if len(lesson.parts) > 1],
        "warnings": warnings,
    }
