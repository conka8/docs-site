"""`skool-kit pack-build`: turn an admin's pack spec and classroom into a ready-to-distribute member pack.

The spec (pack.yaml) names the member outcome the pack is for, and the "playbooks": tasks a member completes
with Claude using the community's own method, step by step, each step tied to a lesson. The build writes:

    member-pack/
      skills/<prefix>-tutor/          lesson-grounded Q&A with citations and a "not covered" route
      skills/<prefix>-<playbook>/     one task skill per playbook, with only the lessons it needs
      evals/cases.yaml                acceptance checks for `skillkit eval`
      MEMBER-START.md                 the member's first-days guide (install, tasks, how to report the outcome)
      ADMIN-REVIEW.md                 what the admin must check before sharing, and a manual acceptance procedure
      pilot/                          pilot plan and empty logs for `skool-kit pilot`

Rebuilding is safe: files the admin edited since the last build are kept, and the new version is written next to
them as <file>.new. Nothing is sent anywhere; no AI call is made.
"""
from __future__ import annotations

import hashlib
import json
import re
import tempfile
from dataclasses import dataclass, field
from pathlib import Path

import yaml

from .classroom import Lesson, SkillError, build_skill, discover, slugify, validate_name

MANIFEST = ".skool-kit-pack.json"
CHECK_TYPES = ("contains", "not_contains", "regex", "max_chars", "json_valid", "json_has_keys")


@dataclass
class PackResult:
    out: Path
    skills: list[str]
    written: list[str] = field(default_factory=list)
    unchanged: list[str] = field(default_factory=list)
    kept: list[str] = field(default_factory=list)  # admin-edited files left alone; new version in <file>.new
    warnings: list[str] = field(default_factory=list)


# ---------------------------------------------------------------- spec


def _need(d: dict, key: str, where: str, kind=str):
    value = d.get(key) if isinstance(d, dict) else None
    if value is None or (kind is str and not str(value).strip()):
        raise SkillError(f"{where}: '{key}' is required")
    if kind is list and not isinstance(value, list):
        raise SkillError(f"{where}: '{key}' must be a list")
    return value


def load_spec(path: str | Path) -> tuple[dict, Path]:
    path = Path(path)
    if not path.is_file():
        raise SkillError(f"pack spec not found: {path}")
    try:
        spec = yaml.safe_load(path.read_text(encoding="utf-8"))
    except yaml.YAMLError as exc:
        raise SkillError(f"{path} is not valid YAML: {exc}") from exc
    except UnicodeDecodeError as exc:
        raise SkillError(f"{path} is not saved as UTF-8 text") from exc
    if not isinstance(spec, dict):
        raise SkillError(f"{path} must be a YAML mapping (community:, classroom:, playbooks: ...)")
    _need(spec, "community", "pack spec")
    _need(spec, "classroom", "pack spec")
    outcome = spec.get("first_outcome") or {}
    for key in ("name", "definition", "within_days", "how_to_report"):
        _need(outcome, key, "first_outcome", int if key == "within_days" else str)
    if not isinstance(outcome["within_days"], int) or outcome["within_days"] < 1:
        raise SkillError("first_outcome: 'within_days' must be a whole number of days, at least 1")
    playbooks = _need(spec, "playbooks", "pack spec", list)
    if not playbooks:
        raise SkillError("pack spec: add at least one playbook (a task members complete)")
    seen = set()
    for i, pb in enumerate(playbooks, 1):
        where = f"playbook {i}"
        for key in ("name", "title", "outcome", "when"):
            _need(pb, key, where)
        where = f"playbook '{pb['name']}'"
        if pb["name"] in seen:
            raise SkillError(f"{where}: two playbooks use this name")
        seen.add(pb["name"])
        for key in ("inputs", "steps"):
            if not _need(pb, key, where, list):
                raise SkillError(f"{where}: '{key}' is empty")
        for j, inp in enumerate(pb["inputs"], 1):
            _need(inp, "name", f"{where}, input {j}")
            _need(inp, "ask", f"{where}, input {j}")
        for j, step in enumerate(pb["steps"], 1):
            _need(step, "do", f"{where}, step {j}")
            _need(step, "lesson", f"{where}, step {j}")
        for j, rule in enumerate(pb.get("rules") or [], 1):
            if isinstance(rule, dict):
                _need(rule, "rule", f"{where}, rule {j}")
            elif not isinstance(rule, str):
                raise SkillError(f"{where}, rule {j}: write a sentence, or 'rule:' and 'lesson:'")
        extra = pb.get("extra_cases") or []
        if not isinstance(extra, list):
            raise SkillError(f"{where}: 'extra_cases' must be a list")
        for j, case in enumerate(extra, 1):
            _need(case, "id", f"{where}, extra case {j}")
            _need(case, "input", f"{where}, extra case {j}")
            _need(case, "pass_if", f"{where}, extra case {j}")
        for check in [c for case in extra for c in case.get("checks") or []] + list(pb.get("checks") or []):
            kinds = [k for k in check if k != "explain"] if isinstance(check, dict) else []
            if len(kinds) != 1 or kinds[0] not in CHECK_TYPES:
                raise SkillError(f"{where}: each check needs exactly one of {', '.join(CHECK_TYPES)} (got {check!r})")
            if kinds[0] == "regex":
                try:
                    re.compile(check["regex"])
                except re.error as exc:
                    raise SkillError(f"{where}: check regex {check['regex']!r} is invalid: {exc}") from exc
    return spec, path.parent


def _key(title: str) -> str:
    return re.sub(r"[^a-z0-9]+", " ", title.casefold()).strip()


def lesson_index(modules) -> dict[str, tuple]:
    """Lesson title (normalised) -> (module, lesson). Also 'module/lesson-slug' paths."""
    index = {}
    for m in modules:
        for lesson in m.lessons:
            index.setdefault(_key(lesson.title), (m, lesson))
            index.setdefault(f"{m.slug}/{lesson.slug}", (m, lesson))
    return index


def find_lesson(index: dict, ref: str, where: str) -> tuple:
    hit = index.get(_key(str(ref))) or index.get(str(ref))
    if hit is None:
        titles = sorted({lesson.title for _, lesson in index.values()})
        raise SkillError(f"{where}: no lesson called {ref!r}. Lessons found: " + "; ".join(titles))
    return hit


# ---------------------------------------------------------------- rendering helpers


def _yaml_front(name: str, description: str) -> str:
    return yaml.safe_dump({"name": name, "description": description}, sort_keys=False, allow_unicode=True,
                          width=100000).strip()


def _cell(text) -> str:
    return str(text).replace("|", "\\|").replace("\n", " ").strip()


def _lesson_files(module, lesson: Lesson) -> list[tuple[str, str]]:
    """(relative path, content) for a lesson's reference file(s), split like the tutor's."""
    total = len(lesson.parts)
    out = []
    for i, part in enumerate(lesson.parts, 1):
        fname = f"{lesson.slug}.md" if total == 1 else f"{lesson.slug}-part-{i}.md"
        heading = lesson.title if total == 1 else f"{lesson.title} (part {i} of {total})"
        body = part
        if (total == 1 or i == 1) and body.startswith("# "):
            body = re.sub(r"^#\s+.+\n+", "", body, count=1)
        out.append((f"references/{module.slug}/{fname}",
                    f"# {heading}\n\nModule: {module.title}\n\n{body.strip()}\n"))
    return out


def describe_check(check: dict) -> str:
    if check.get("explain"):
        return str(check["explain"])
    kind = next(k for k in check if k != "explain")
    value = check[kind]
    if kind == "contains":
        items = value if isinstance(value, list) else [value]
        return "It contains " + ", ".join(f'"{v}"' for v in items) + "."
    if kind == "not_contains":
        items = value if isinstance(value, list) else [value]
        return "It does not contain " + ", ".join(f'"{v}"' for v in items) + "."
    if kind == "regex":
        return f"It matches the pattern `{value}`."
    if kind == "max_chars":
        return f"It is at most {value} characters long."
    if kind == "json_valid":
        return "It is valid JSON."
    return "It is JSON with the keys " + ", ".join(f'"{v}"' for v in value) + "."


def _description(community: str, pb: dict, lessons: list[str]) -> str:
    outcome = pb["outcome"] if pb["outcome"][1:2].isupper() else pb["outcome"][0].lower() + pb["outcome"][1:]
    desc = (f"{pb['title']} for {community} members: {outcome}. Follows the {community} lessons "
            + ", ".join(f'"{t}"' for t in lessons) + f". Use when {pb['when']}.")
    return desc if len(desc) <= 1024 else desc[:1020].rsplit(" ", 1)[0] + " ..."


STANDARD_SECTIONS = ["Check", "Gaps and assumptions", "Next step"]


def _rule_text(rule, refs: dict) -> str:
    if isinstance(rule, dict):
        lesson = refs[str(rule["lesson"])][1].title if rule.get("lesson") else ""
        return f"{rule['rule']}" + (f" *(Lesson: \"{lesson}\")*" if lesson else "")
    return str(rule)


def render_playbook(spec: dict, pb: dict, name: str, refs: dict[str, tuple], has_example: bool) -> str:
    community = spec["community"]
    support = spec.get("support") or "ask in the community"
    channel = (spec.get("support_channel") or support).rstrip(". ")
    outcome = spec["first_outcome"]
    lessons = list(dict.fromkeys(refs[str(s["lesson"])][1].title for s in pb["steps"]))
    minutes = f" It usually takes about {pb['minutes']} minutes." if pb.get("minutes") else ""
    required = [i for i in pb["inputs"] if i.get("required", True)]
    optional = [i for i in pb["inputs"] if not i.get("required", True)]
    deliverable = pb.get("deliverable") or {}
    sections = list(deliverable.get("sections") or [])
    next_action = pb.get("next_action") or f"{outcome['how_to_report']}"
    out = ["---", _yaml_front(name, _description(community, pb, lessons)), "---", "",
           f"# {pb['title']}", "",
           f"You help a member of {community} finish real work: **{pb['outcome']}**. You do the work with them, using "
           f"the {community} method in the lessons below, and end with a deliverable they can edit and use.{minutes}", "",
           "## 1. Get the minimum information", "",
           "Use what the member already gave you. Ask only for required inputs that are missing, all in one short "
           "message, then wait for the answer. Don't ask for anything else.", "",
           "| Input | Required | Ask | Example |", "|---|---|---|---|"]
    for i in pb["inputs"]:
        req = "yes" if i.get("required", True) else f"no (if missing: {i.get('default', 'say what you assumed')})"
        out.append(f"| {_cell(i['name'])} | {_cell(req)} | {_cell(i['ask'])} | {_cell(i.get('example', ''))} |")
    if not required:
        out.append("")
    if optional:
        out += ["", "For optional inputs, use the default shown and list it under Gaps and assumptions."]
    out += ["", "## 2. Do the work", "",
            f"Read the lesson file for each step before you do it, and apply its method, numbers and wording rules "
            "rather than general advice. Cite the lesson by title where you use it, like *(Lesson: \"" + lessons[0] + "\")*.",
            ""]
    for n, step in enumerate(pb["steps"], 1):
        module, lesson = refs[str(step["lesson"])]
        files = ", ".join(f"[{Path(p).name}]({p})" for p, _ in _lesson_files(module, lesson))
        out.append(f"{n}. {str(step['do']).strip()}")
        out.append(f"   - Lesson: \"{lesson.title}\" ({files})")
    out += ["", "## 3. Rules", ""]
    out += [f"- {_rule_text(r, refs)}" for r in pb.get("rules") or []]
    out += ["- If the member's input conflicts with a rule or a lesson (for example a lower price, a promise, a niche "
            "that fails a filter), don't silently follow it: say which rule or lesson it conflicts with, give the "
            "version that follows the lesson, and note the conflict under Gaps and assumptions.",
            "- Never invent lessons, prices, results, statistics or promises. Every money amount, number, percentage "
            "or claim about how clients or their customers behave must come from the lessons or the member's input. "
            "If you add one anyway (even a common-sense one), list it under Gaps and assumptions as \"verify before "
            "use\", or leave it out. The same goes for numbers the member gives that the lessons don't support.",
            f"- If the member asks something the lessons don't cover, say \"This isn't covered in the classroom yet\", "
            f"label any suggestion as your own, and write a question for a coach (section 5)."]
    out += ["", "## 4. Deliverable", "",
            "Produce one Markdown document the member can copy and edit, with these `##` headings in this order:", ""]
    out += [f"- {s}" for s in sections]
    out += ["- Check: each item in the checklist below, marked pass or fail, with a one-line reason",
            "- Gaps and assumptions: inputs that were missing and what you assumed, conflicts with the lessons, and any "
            "claim the member must verify before using it. Write \"None\" if there are none",
            f"- Next step: one concrete action for today. Default: {next_action}"]
    if deliverable.get("filename"):
        out += ["", f"If you can create files, also save it as `{deliverable['filename']}`."]
    checks = pb.get("checks") or []
    out += ["", "Checklist (fix anything that fails before you show the deliverable; if you can't fix it, mark it "
            "fail and say why):", ""]
    out += [f"- {describe_check(c)}" for c in checks]
    out += ["- Every recommendation follows the lessons above and cites them; nothing is invented.",
            "- Every money amount, number or claim about customer behaviour comes from the lessons or the member, "
            "or is listed under Gaps and assumptions as \"verify before use\"."]
    out += ["", "## 5. If something is unresolved", "",
            f"If the lessons don't cover something the member needs, or a gap blocks the deliverable, end with a "
            f"**Question for a coach**: a short message the member can post in {channel}. Include what they're "
            "working on, the lesson they used, what they've already decided, and the exact question.", "",
            "## When the member is done", "",
            f"This task is part of the member's **{outcome['name']}** ({outcome['definition']}, within "
            f"{outcome['within_days']} days of joining). When they have it, tell them: {outcome['how_to_report']}"]
    if has_example:
        out += ["", "## Example", "",
                "[examples/example-input.md](examples/example-input.md) and "
                "[examples/example-output.md](examples/example-output.md) show one completed run. Follow the lessons, "
                "not the example's specifics."]
    return "\n".join(out).rstrip() + "\n"


def _skill_entries(spec: dict, names: dict[str, str]) -> list[str]:
    rows = [f"| **{names['tutor']}** | Ask anything about the lessons. It answers from the classroom and says which "
            f"lesson to watch. | Any time |"]
    for pb in spec["playbooks"]:
        rows.append(f"| **{names[pb['name']]}** | {_cell(pb['title'])}: {_cell(pb['outcome'])} | "
                    f"{pb.get('minutes', '?')} min |")
    return rows


def render_member_start(spec: dict, names: dict[str, str]) -> str:
    community = spec["community"]
    outcome = spec["first_outcome"]
    support = spec.get("support") or "ask in the community"
    first_pb = names[spec["playbooks"][0]["name"]]
    out = [f"# {community}: your AI toolkit", "",
           f"These Claude skills are built from the {community} classroom. They help you reach your "
           f"**{outcome['name']}**: {outcome['definition']}, within {outcome['within_days']} days of joining.", "",
           "| Skill | What it does | Time |", "|---|---|---|"] + _skill_entries(spec, names)
    out += ["", "## 1. Install (once, about 5 minutes)", "",
            "**Claude app (claude.ai or desktop):**", "",
            "1. Settings > Capabilities: turn on **Code execution and file creation**.",
            "2. Customize > Skills > **+** > **Create skill** > **Upload a skill**. Upload each `.zip` you received.",
            "", "**Claude Code:** copy each skill folder into `~/.claude/skills/` "
            "(Windows: `%USERPROFILE%\\.claude\\skills\\`), or run the two `/plugin` lines your admin shared.", "",
            "Check it worked: start a new chat and ask *\"Use the " + names["tutor"] + " skill: how do I get started?\"*",
            "", "## 2. Your first tasks", ""]
    for n, pb in enumerate(spec["playbooks"], 1):
        example = (pb.get("inputs") or [{}])[0].get("example", "")
        out.append(f"{n}. **{pb['title']}**: ask *\"Use the {names[pb['name']]} skill\"*. Have ready: "
                   + ", ".join(i["ask"].rstrip("?").lower() for i in pb["inputs"]) + "."
                   + (f" (Example: {example})" if example else ""))
    out += ["", f"## 3. Report your {outcome['name']}", "", outcome["how_to_report"], "",
            "## Good to know", "",
            "- The skills follow the classroom. If something isn't covered they say so: then " + support,
            "- They run in your own Claude account. Nothing is sent to the community; Claude's own data terms apply.",
            "- Check anything you send to a client. The skills help you draft; you are responsible for what you send.",
            f"- Start with **{first_pb}** if you're not sure where to begin."]
    return "\n".join(out).rstrip() + "\n"


def render_admin_review(spec: dict, names: dict[str, str], refs: dict, warnings: list[str]) -> str:
    community = spec["community"]
    out = [f"# Before you share the {community} member pack", "",
           "Generated by `skool-kit pack-build`. Work through this list; it takes 30 to 60 minutes the first time.", "",
           "## 1. Read each skill", ""]
    out.append(f"- [ ] **{names['tutor']}**: the lesson index lists every lesson members should be able to ask about.")
    for pb in spec["playbooks"]:
        used = list(dict.fromkeys(refs[str(s['lesson'])][1].title for s in pb["steps"]))
        out.append(f"- [ ] **{names[pb['name']]}**: each step points at the right lesson ({'; '.join(used)}), "
                   "the rules match how you teach it, and nothing promises results you can't stand behind.")
    out += ["", "## 2. Run the automatic checks", "", "```bash",
            "skillkit lint skills",
            "skillkit eval skills --cases evals/cases.yaml --provider fake        # shows the checks on the examples",
            "skillkit eval skills --cases evals/cases.yaml --provider anthropic   # real answers, needs ANTHROPIC_API_KEY",
            "```", "",
            "`--provider fake` only replays the example answers in `evals/cases.yaml`: it proves the checks work, not "
            "that the skills do. The real run sends each skill's instructions and one test message to the model; it "
            "doesn't read reference files or run tools, so also do step 3.", "",
            "## 3. Manual acceptance (the real test)", "",
            "For each skill: install it in the Claude surface your members use, start a new chat, paste the test "
            "input below, and judge the result. Record each run in `pilot/acceptance.csv`.", "",
            "| Skill | Test input | Pass if |", "|---|---|---|"]
    for q in (spec.get("tutor") or {}).get("sample_questions") or []:
        out.append(f"| {names['tutor']} | {_cell(q['question'])} | Answers from \"{_cell(q['lesson'])}\" and cites it |")
    for q in (spec.get("tutor") or {}).get("not_covered") or []:
        out.append(f"| {names['tutor']} | {_cell(q['question'])} | Says it isn't covered and points to support |")
    for pb in spec["playbooks"]:
        test = (pb.get("example") or {}).get("input") or "Your own realistic example"
        checks = " ".join(describe_check(c) for c in pb.get("checks") or []) or "A member could use it as is"
        out.append(f"| {names[pb['name']]} | {_cell(test)} | {_cell(checks)} A member could use it with light edits. |")
        for extra in pb.get("extra_cases") or []:
            out.append(f"| {names[pb['name']]} | {_cell(extra['input'])} | {_cell(extra['pass_if'])} |")
    out += ["", "## 4. Package and share", "", "```bash",
            f"skillkit pack skills -o dist --name {spec.get('skill_prefix') or slugify(community)}-skills "
            f"--version 1.0.0 --author \"{community}\" --format claude-app", "```", "",
            "Send members the zips and `MEMBER-START.md`. Then start the pilot (`pilot/README.md`).", "",
            "## 5. When you change a lesson", "",
            "Run `skool-kit pack-build` again. Files you edited are kept and the new version is written next to them "
            "as `<file>.new`; compare and merge, then pack with a higher `--version`."]
    if warnings:
        out += ["", "## Build warnings", ""] + [f"- {w}" for w in warnings]
    return "\n".join(out).rstrip() + "\n"


def build_cases(spec: dict, names: dict[str, str], base: Path) -> str:
    cases = []
    tutor = spec.get("tutor") or {}
    for i, q in enumerate(tutor.get("sample_questions") or [], 1):
        case = {"skill": names["tutor"], "id": f"tutor-question-{i}", "input": q["question"],
                "assert": [{"contains": q["lesson"]}]}
        if q.get("example_answer"):
            case["fake_response"] = q["example_answer"]
        cases.append(case)
    for i, q in enumerate(tutor.get("not_covered") or [], 1):
        case = {"skill": names["tutor"], "id": f"tutor-not-covered-{i}", "input": q["question"],
                "assert": [{"regex": r"(?i)(isn't|is not|not) covered"}]}
        if q.get("example_answer"):
            case["fake_response"] = q["example_answer"]
        cases.append(case)
    for pb in spec["playbooks"]:
        ex = pb.get("example") or {}
        if not ex.get("input"):
            continue
        case = {"skill": names[pb["name"]], "id": f"{pb['name']}-example", "input": ex["input"],
                "assert": [{k: v for k, v in c.items() if k != "explain"} for c in pb.get("checks") or []]}
        if ex.get("output_file"):
            case["fake_response"] = (base / ex["output_file"]).read_text(encoding="utf-8")
        cases.append(case)
    for pb in spec["playbooks"]:
        for extra in pb.get("extra_cases") or []:
            case = {"skill": names[pb["name"]], "id": f"{pb['name']}-{extra['id']}", "input": extra["input"],
                    "assert": [{k: v for k, v in c.items() if k != "explain"} for c in extra.get("checks") or []]}
            if extra.get("output_file"):
                case["fake_response"] = (base / extra["output_file"]).read_text(encoding="utf-8")
            cases.append(case)
    head = (f"# Acceptance checks for the {spec['community']} member pack (generated by skool-kit pack-build).\n"
            "# Real run, a few API calls per case:  skillkit eval skills --cases evals/cases.yaml --provider anthropic\n"
            "# Demo run (replays the hand-written example answers below; proves the checks, not the skills):\n"
            "#   skillkit eval skills --cases evals/cases.yaml --provider fake\n")
    return head + yaml.safe_dump({"provider": "fake", "cases": cases}, sort_keys=False, allow_unicode=True, width=110)


def pilot_files(spec: dict) -> dict[str, str]:
    outcome = spec["first_outcome"]
    plan = f"""# Pilot plan for the {spec['community']} member pack. Fill in the dates and numbers before you start.
# Read pilot/README.md first. `skool-kit pilot pilot/pilot.yaml` turns the three logs into a report.
pilot: {spec['community']} member pack pilot
outcome: {outcome['name']}              # {outcome['definition']}
outcome_event: first_outcome            # the event name you log in events.csv
within_days: {outcome['within_days']}            # members count for the outcome only once this window has closed
renewal_after_days: 30                  # first renewal date; members not yet due are left out, not counted as lost
as_of: 2027-01-31                       # the date your logs are complete up to; update it every time you report
pilot_cohort:     {{joined_from: 2026-12-01, joined_to: 2026-12-31}}   # new paid members who get the pack
baseline_cohort:  {{joined_from: 2026-10-01, joined_to: 2026-10-31}}   # earlier members who didn't
membership_price: 0          # what a member pays per month
platform_fee_pct: 0          # your platform's transaction fee, in percent
# Decide these BEFORE the pilot starts.
thresholds:
  min_cohort: 20             # fewer members than this whose window has closed: not enough data to decide
  min_adoption_pct: 40       # share of pilot members who install the pack
  continue_if_lift_pts: 10   # outcome rate at least this many points above baseline: continue
  stop_if_lift_pts: 0        # outcome rate no better than baseline: stop or change
  min_acceptance_pct: 100    # acceptance runs that must pass (acceptance.csv)
  max_correction_pct: 10     # tutor answers you had to correct, as a share of tutor answers you reviewed
  # max_cash_costs: 0        # optional budget limits; going over blocks a "continue"
  # max_effort_hours: 0
"""
    readme = f"""# Pilot: does the member pack help new members reach their {outcome['name']}?

Run it for at least one full cohort (members who join in one month) and {outcome['within_days']} days after the
last of them joins. Everything stays in these files on your computer.

## What to log

**events.csv**, one row per event, for members of both cohorts. Use any member ID you like (an email, or a
code if you'd rather not keep emails here). Events:

| event | Log it when |
|---|---|
| joined | A paid member joins (every member needs this row) |
| installed | A pilot member tells you, or you see, that they installed the skills |
| used | A member reports using a skill |
| task_completed | A member shows a finished deliverable (put the task name, e.g. offer-builder, in `note`) |
| first_outcome | The member reports their {outcome['name']}: {outcome['definition']} |
| renewed | The member's first renewal payment went through |
| cancelled | The member cancelled before or at the first renewal |
| refunded | The member got a refund |
| excluded | Leave this member out (for example a refund during a trial, a test account); say why in `note` |

For the baseline cohort, fill in `joined`, `first_outcome`, `renewed`, `cancelled` from your records
(for example #firstwin posts and your platform's payment history).

**questions.csv**: member questions you looked at during the pilot. `handled_by` is `tutor` (a member said the
tutor answered it, or you checked a tutor answer) or `staff`. `result` is `resolved`, `corrected` (the tutor was
wrong or incomplete and someone fixed it) or `escalated`. `staff_minutes` is the time staff spent on it.

**acceptance.csv**: one row per acceptance run before launch (`passed` is yes or no). The report won't suggest
continuing until these are recorded and pass.

**costs.csv**: every cost of running the pilot. `kind` is `cash` (money spent: implementation fee, API, software)
or `time` (minutes of your or your team's time).

## Read the result

```bash
skool-kit pilot pilot/pilot.yaml --format md -o pilot-report.md
```

The report judges three things separately: **product quality** (acceptance runs, corrected answers), **member
outcomes** (adoption, completed tasks, the first outcome within its window, pilot vs baseline) and **economics**
(cash and time spent, the observed first-renewal difference). Members whose window or renewal date hasn't arrived
by `as_of` are left out, not counted as failures. A good outcome result is held back if quality fails or the
economics are negative or over budget.

It compares cohorts; it does not prove cause: the pilot month can differ in season, marketing or price.
Small cohorts give wide ranges; the report says when there isn't enough data to decide.
"""
    return {
        "pilot/pilot.yaml": plan,
        "pilot/README.md": readme,
        "pilot/events.csv": "member,event,date,note\n",
        "pilot/questions.csv": "date,topic,handled_by,result,staff_minutes,note\n",
        "pilot/costs.csv": "date,item,kind,amount,minutes,note\n",
        "pilot/acceptance.csv": "date,skill,test,passed,reviewer,note\n",
    }


# ---------------------------------------------------------------- build


def plan_pack(spec_path: str | Path, max_chars: int = 12000) -> tuple[dict[str, str], list[str], list[str]]:
    """Return ({relative path: content}, skill names, warnings) without writing anything."""
    spec, base = load_spec(spec_path)
    community = spec["community"]
    prefix = spec.get("skill_prefix") or slugify(community)
    names = {"tutor": validate_name(f"{prefix}-tutor")}
    for pb in spec["playbooks"]:
        names[pb["name"]] = validate_name(f"{prefix}-{slugify(str(pb['name']))}")
    if len(set(names.values())) != len(names):
        raise SkillError("two skills would get the same name; rename a playbook")
    classroom = base / spec["classroom"]
    modules, warnings = discover(classroom, max_chars)
    index = lesson_index(modules)
    refs: dict[str, tuple] = {}
    for pb in spec["playbooks"]:
        for n, step in enumerate(pb["steps"], 1):
            refs[str(step["lesson"])] = find_lesson(index, step["lesson"], f"playbook '{pb['name']}', step {n}")
        for n, rule in enumerate(pb.get("rules") or [], 1):
            if isinstance(rule, dict) and rule.get("lesson"):
                refs[str(rule["lesson"])] = find_lesson(index, rule["lesson"], f"playbook '{pb['name']}', rule {n}")
    for q in (spec.get("tutor") or {}).get("sample_questions") or []:
        _need(q, "question", "tutor sample question")
        find_lesson(index, _need(q, "lesson", "tutor sample question"), f"tutor question {q['question']!r}")
    for q in (spec.get("tutor") or {}).get("not_covered") or []:
        _need(q, "question", "tutor not_covered question")

    files: dict[str, str] = {}
    with tempfile.TemporaryDirectory() as tmp:
        build_skill(classroom, names["tutor"], tmp, community, spec.get("classroom_url") or "", max_chars,
                    support=spec.get("support") or "", support_channel=spec.get("support_channel") or "")
        root = Path(tmp) / names["tutor"]
        for p in sorted(root.rglob("*")):
            if p.is_file():
                files[f"skills/{names['tutor']}/{p.relative_to(root).as_posix()}"] = p.read_text(encoding="utf-8")
    for pb in spec["playbooks"]:
        name = names[pb["name"]]
        ex = pb.get("example") or {}
        has_example = bool(ex.get("input") and ex.get("output_file"))
        files[f"skills/{name}/SKILL.md"] = render_playbook(spec, pb, name, refs, has_example)
        for step in pb["steps"]:
            module, lesson = refs[str(step["lesson"])]
            for rel, content in _lesson_files(module, lesson):
                files[f"skills/{name}/{rel}"] = content
        if has_example:
            out_file = base / ex["output_file"]
            if not out_file.is_file():
                raise SkillError(f"playbook '{pb['name']}': example output file not found: {out_file}")
            files[f"skills/{name}/examples/example-input.md"] = str(ex["input"]).strip() + "\n"
            files[f"skills/{name}/examples/example-output.md"] = out_file.read_text(encoding="utf-8")
        elif not pb.get("checks"):
            warnings.append(f"playbook '{pb['name']}' has no example and no checks: add both so you can test it")
    files["evals/cases.yaml"] = build_cases(spec, names, base)
    files["MEMBER-START.md"] = render_member_start(spec, names)
    files["ADMIN-REVIEW.md"] = render_admin_review(spec, names, refs, warnings)
    files.update(pilot_files(spec))
    return files, list(names.values()), warnings


def _hash(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def write_pack(files: dict[str, str], out: str | Path, force: bool = False) -> PackResult:
    out = Path(out)
    manifest_path = out / MANIFEST
    previous = {}
    if manifest_path.is_file():
        try:
            previous = json.loads(manifest_path.read_text(encoding="utf-8")).get("files", {})
        except (ValueError, AttributeError):
            previous = {}
    elif out.exists() and any(out.iterdir()) and not force:
        raise SkillError(f"{out} already exists and wasn't made by pack-build; choose another folder or use --force")
    result = PackResult(out, [])
    recorded = {}
    for rel, content in sorted(files.items()):
        target = out / rel
        new_hash = _hash(content)
        if target.is_file():
            current = target.read_text(encoding="utf-8", errors="replace")
            if current == content:
                result.unchanged.append(rel)
                recorded[rel] = new_hash
                continue
            edited = previous.get(rel) != _hash(current)
            if edited and not force:
                # The admin changed this file since the last build: keep it, offer the new version beside it.
                target.with_name(target.name + ".new").write_text(content, encoding="utf-8")
                result.kept.append(rel)
                recorded[rel] = previous.get(rel, "")
                continue
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(content, encoding="utf-8")
        result.written.append(rel)
        recorded[rel] = new_hash
    for rel in sorted(set(previous) - set(files)):
        if (out / rel).exists():
            result.warnings.append(f"{rel} is no longer generated; delete it if you don't need it")
    manifest_path.parent.mkdir(parents=True, exist_ok=True)
    manifest_path.write_text(json.dumps({"tool": "skool-kit pack-build", "files": recorded}, indent=2) + "\n",
                             encoding="utf-8")
    return result


def build_pack(spec_path: str | Path, out: str | Path, force: bool = False, max_chars: int = 12000) -> PackResult:
    files, names, warnings = plan_pack(spec_path, max_chars)
    result = write_pack(files, out, force)
    result.skills = names
    result.warnings = warnings + result.warnings
    return result


def list_lessons(spec_path: str | Path) -> list[str]:
    spec, base = load_spec(spec_path)
    modules, _ = discover(base / spec["classroom"])
    return [f"{m.title} / {lesson.title}" for m in modules for lesson in m.lessons]
