import csv
import io
import json
import runpy
import sys

import pytest
import yaml

from skool_kit.cli import main


def run(argv, env=None):
    out, err = io.StringIO(), io.StringIO()
    code = main(argv, env=env if env is not None else {}, out=out, err=err)
    return code, out.getvalue(), err.getvalue()


def test_help_and_version(capsys):
    code, out, _ = run([])
    assert code == 2 and "classroom-to-skill" in out
    assert run(["--version"])[0] == 0
    assert "skool-kit 0.4.0" in capsys.readouterr().out
    assert run(["nope"])[0] == 2


def test_inspect(fix):
    code, out, err = run(["inspect", str(fix / "members_semicolon_bom.csv")])
    assert code == 0 and "Delimiter: semicolon" in out and "email         <- E-mail Address" in out
    code, out, err = run(["inspect", str(fix / "members_bad.csv")])
    assert code == 0 and "skipped row 5: no name and no email" in err and "Columns used" in out
    code, out, err = run(["inspect", str(fix / "members_no_identity.csv")])
    assert code == 2 and "Could not find a name or email column" in err
    code, out, err = run(["inspect", str(fix / "members_no_identity.csv"), "--map", "Foo=email"])
    assert code == 0 and "Columns ignored: Bar" in out
    assert run(["inspect", str(fix / "missing.csv")])[0] == 2
    assert run(["inspect", str(fix / "members_bad.csv"), "--map", "nonsense"])[0] == 2


def test_onboard_formats(fix, tmp_path):
    code, out, err = run(["onboard", str(fix / "members_standard.csv"), "--since", "2026-10-15",
                          "--community-name", "AI Builders"])
    assert code == 0 and out.startswith("# New member onboarding messages") and "3 member(s)." in out
    assert "Hey Ana, welcome to AI Builders!" in out and "Dan Moore" not in out
    assert "3 onboarding message(s) for members who joined since 2026-10-15." in err
    p = tmp_path / "m.csv"
    code, out, err = run(["onboard", str(fix / "members_standard.csv"), "-o", str(p)])
    assert code == 0 and "Wrote" in out and "5 onboarding message(s)." in out
    rows = list(csv.DictReader(p.open()))
    assert len(rows) == 5 and rows[3]["segment"] == "Business owner"
    j = tmp_path / "m.jsonl"
    assert run(["onboard", str(fix / "members_standard.csv"), "-o", str(j)])[0] == 0
    assert json.loads(j.read_text().splitlines()[0])["goal"] == "first-client"
    code, out, _ = run(["onboard", str(fix / "members_standard.csv"), "--format", "jsonl"])
    assert len(out.splitlines()) == 5


def test_onboard_since_skips_rows_without_dates(fix):
    code, out, err = run(["onboard", str(fix / "members_bad.csv"), "--since", "Oct 1, 2026"])
    assert code == 0 and "skipped row 3: join date missing or unreadable" in err
    assert run(["onboard", str(fix / "members_bad.csv"), "--since", "whenever"])[0] == 2


def test_onboard_custom_rules_and_bad_rules(fix, tmp_path):
    r = tmp_path / "r.yaml"
    assert run(["rules", "-o", str(r)])[0] == 0
    rules = yaml.safe_load(r.read_text())
    rules["welcome"] = "Yo {first_name} -> {lesson_1}"
    r.write_text(yaml.safe_dump(rules))
    code, out, _ = run(["onboard", str(fix / "members_standard.csv"), "--rules", str(r)])
    assert code == 0 and "Yo Ana -> Start Here: How This Community Works" in out
    r.write_text("default_segment: ghost\n")
    code, _, err = run(["onboard", str(fix / "members_standard.csv"), "--rules", str(r)])
    assert code == 2 and "default_segment" in err
    code, out, _ = run(["rules"])
    assert code == 0 and "agency-owner" in out


def test_onboard_llm_falls_back_without_key(fix):
    code, out, err = run(["onboard", str(fix / "members_standard.csv"), "--llm", "anthropic"], env={})
    assert code == 0 and "Hey Ana" in out
    assert "LLM failed for 5 message(s)" in err and "ANTHROPIC_API_KEY is not set" in err


def test_onboard_llm_with_fake_transport(fix, monkeypatch):
    import skool_kit.llm as llm_mod
    calls = []

    def fake_post(url, headers, body, timeout):
        calls.append(url)
        lessons = json.loads(body)["messages"][0]["content"]
        return 200, json.dumps({"content": [{"type": "text", "text": "Personal note.\n" + lessons}]}).encode()

    monkeypatch.setattr(llm_mod, "urllib_post", fake_post)
    code, out, err = run(["onboard", str(fix / "members_standard.csv"), "--llm", "anthropic", "--model", "m-x"],
                         env={"ANTHROPIC_API_KEY": "k"})
    assert code == 0 and "Source: llm:anthropic" in out and len(calls) == 5


def test_health_outputs(fix, tmp_path):
    dash = tmp_path / "d.html"
    risk = tmp_path / "r.csv"
    code, out, err = run(["health", str(fix / "members_standard.csv"), "--activity", str(fix / "activity.csv"),
                          "--as-of", "2026-10-28", "-o", str(dash), "--at-risk", str(risk),
                          "--community-name", "AI Builders", "--brand-color", "#0f766e"])
    assert code == 0
    assert "5 members, 100.0% active in 30 days, 2 at risk (1 paying)." in out
    assert "Read 6 activity row(s)." in out
    page = dash.read_text()
    assert page.startswith("<!doctype html>") and "AI Builders community health" in page and "<script" not in page
    assert next(csv.DictReader(risk.open()))["name"] == "Dan Moore"
    j = tmp_path / "r.json"
    assert run(["health", str(fix / "members_standard.csv"), "--as-of", "2026-10-28", "-o", str(j)])[0] == 0
    assert json.loads(j.read_text())["kpis"]["total_members"] == 5
    c = tmp_path / "only.csv"
    assert run(["health", str(fix / "members_standard.csv"), "-o", str(c), "--threshold", "0",
                "--at-risk", str(tmp_path / "x.json")])[0] == 0
    assert len(list(csv.DictReader(c.open()))) == 5
    assert run(["health", str(fix / "members_standard.csv"), "--as-of", "someday"])[0] == 2


def test_health_activity_without_dates(fix, tmp_path):
    act = tmp_path / "a.csv"
    act.write_text("Email,Posts\nana@example.com,3\n")
    code, out, err = run(["health", str(fix / "members_standard.csv"), "--activity", str(act),
                          "-o", str(tmp_path / "d.html"), "--as-of", "2026-10-28"])
    assert code == 0 and "no date column" in err


def test_health_default_as_of_today(fix, tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    code, out, _ = run(["health", str(fix / "members_standard.csv")])
    assert code == 0 and (tmp_path / "dashboard.html").exists()


def test_classroom_to_skill(tmp_path):
    src = tmp_path / "lessons" / "01-start"
    src.mkdir(parents=True)
    (src / "01-hello.md").write_text("# Hello\n\nWorld")
    (src / "02-empty.md").write_text("")
    code, out, err = run(["classroom-to-skill", str(tmp_path / "lessons"), "--name", "my-community-tutor",
                          "-o", str(tmp_path / "out"), "--community-name", "My Community"])
    assert code == 0 and "1 lessons in 1 modules" in out and "empty lesson skipped" in err
    assert (tmp_path / "out" / "my-community-tutor" / "SKILL.md").exists()
    code, _, err = run(["classroom-to-skill", str(tmp_path / "lessons"), "--name", "my-community-tutor",
                        "-o", str(tmp_path / "out")])
    assert code == 2 and "--force" in err
    assert run(["classroom-to-skill", str(tmp_path / "lessons"), "--name", "Bad Name", "-o", str(tmp_path)])[0] == 2
    assert run(["classroom-to-skill", str(tmp_path / "lessons")])[0] == 2  # --name required


def test_webhook_command(monkeypatch, tmp_path):
    code, _, err = run(["webhook"], env={})
    assert code == 2 and "secret is required" in err
    import skool_kit.webhook as wh
    seen = {}

    class FakeServer:
        server_address = ("127.0.0.1", 9999)

        def serve_forever(self):
            raise KeyboardInterrupt

        def server_close(self):
            seen["closed"] = True

    def fake_make_server(config, host, port):
        seen.update(config=config, host=host, port=port)
        return FakeServer()

    monkeypatch.setattr(wh, "make_server", fake_make_server)
    code, out, _ = run(["webhook", "--port", "9999", "--outbox", str(tmp_path / "o.jsonl"), "--forward-url",
                        "https://hooks.zapier.com/x", "--map", "Email Address=email", "--community-name", "Club"],
                       env={"SKOOL_KIT_SECRET": "env-secret"})
    assert code == 0 and "Listening on http://127.0.0.1:9999/" in out and seen["closed"]
    cfg = seen["config"]
    assert cfg.secret == "env-secret" and cfg.forward_url == "https://hooks.zapier.com/x"
    assert cfg.field_map == {"email address": "email"} and cfg.rules["community_name"] == "Club"


def test_python_dash_m(monkeypatch, capsys):
    monkeypatch.setattr(sys, "argv", ["skool_kit", "--version"])
    with pytest.raises(SystemExit) as info:
        runpy.run_module("skool_kit", run_name="__main__")
    assert info.value.code == 0
