import shutil
from pathlib import Path

import pytest
import yaml

from skool_kit.classroom import SkillError
from skool_kit.cli import main
from skool_kit.memberpack import MANIFEST, build_pack, describe_check, list_lessons, plan_pack

LAB = Path(__file__).parent.parent / "examples" / "agency-lab"


@pytest.fixture
def lab(tmp_path):
    """A copy of the demo lab, so tests can edit the spec and lessons."""
    dest = tmp_path / "lab"
    shutil.copytree(LAB, dest, ignore=shutil.ignore_patterns("member-pack", "pilot-sample"))
    return dest


def edit_spec(lab, change):
    spec = yaml.safe_load((lab / "pack.yaml").read_text(encoding="utf-8"))
    change(spec)
    (lab / "pack.yaml").write_text(yaml.safe_dump(spec, sort_keys=False), encoding="utf-8")


def test_plan_contains_every_part_of_the_pack():
    files, names, warnings = plan_pack(LAB / "pack.yaml")
    assert names == ["northwind-tutor", "northwind-offer-builder", "northwind-outreach-sprint"]
    for rel in ["skills/northwind-tutor/SKILL.md", "skills/northwind-offer-builder/SKILL.md",
                "skills/northwind-outreach-sprint/SKILL.md", "evals/cases.yaml", "MEMBER-START.md",
                "ADMIN-REVIEW.md", "pilot/pilot.yaml", "pilot/events.csv", "pilot/questions.csv", "pilot/costs.csv",
                "pilot/acceptance.csv", "pilot/README.md"]:
        assert rel in files, rel
    assert warnings == []


def test_playbook_skill_cites_lessons_and_ships_only_the_lessons_it_needs():
    files, _, _ = plan_pack(LAB / "pack.yaml")
    md = files["skills/northwind-offer-builder/SKILL.md"]
    assert md.startswith("---\nname: northwind-offer-builder\n")
    assert 'Lesson: "Pick a niche with the 3-filter test" ([pick-a-niche-with-the-3-filter-test.md]' in md
    assert "| niches | yes | Which 1 to 3 niches are you considering? | dental clinics, roofers |" in md
    assert "ask only for required inputs that are missing, all in one short message" in md
    assert "- Pilot and proof" in md and 'Never below 300 a month. Write the price on the page. *(Lesson: "Pricing your first offer")*' in md
    assert "don't silently follow it: say which rule or lesson it conflicts with" in md
    assert '"verify before use"' in md
    assert "- Check: each item in the checklist below, marked pass or fail" in md
    assert "- Gaps and assumptions:" in md and "- Next step: one concrete action for today." in md
    assert "**Question for a coach**: a short message the member can post in the Help channel (tag a coach if nobody answers within a day)." in md
    assert 'It contains "## Niche check", "## Headline", "## Price"' in md and "It makes no guarantee of results." in md
    assert "If you can create files, also save it as `offer.md`." in md
    assert 'Post in Wins with "#firstwin"' in md
    refs = sorted(p for p in files if p.startswith("skills/northwind-offer-builder/references/"))
    assert [Path(p).name for p in refs] == ["pick-a-niche-with-the-3-filter-test.md", "pricing-your-first-offer.md",
                                            "the-one-outcome-offer.md"]
    assert "description: Build your one-page offer with the Northwind Agency Lab method. Use when the member" in md


def test_tutor_routes_uncovered_questions_to_the_support_channel():
    files, _, _ = plan_pack(LAB / "pack.yaml")
    tutor = files["skills/northwind-tutor/SKILL.md"]
    assert "give them a short message to post in the Help channel (tag a coach if nobody answers within a day): their question" in tutor
    assert "tell them: Ask in the Help channel" in tutor


def test_acceptance_cases_match_the_spec():
    files, _, _ = plan_pack(LAB / "pack.yaml")
    data = yaml.safe_load(files["evals/cases.yaml"])
    ids = [c["id"] for c in data["cases"]]
    assert ids == ["tutor-question-1", "tutor-question-2", "tutor-not-covered-1", "offer-builder-example",
                   "outreach-sprint-example", "offer-builder-conflicting-input"]
    offer = data["cases"][3]
    assert offer["skill"] == "northwind-offer-builder"
    assert {"not_contains": ["we guarantee", "guaranteed results"]} in offer["assert"]
    assert offer["fake_response"].startswith("> Actual output: Claude Code run")
    conflict = data["cases"][5]
    assert {"regex": "(?i)what can you (set up|deliver)"} in conflict["assert"]
    assert data["cases"][2]["assert"] == [{"regex": r"(?i)(isn't|is not|not) covered"}]
    assert "proves the checks, not the skills" in files["evals/cases.yaml"]


def test_member_start_and_admin_review():
    files, _, _ = plan_pack(LAB / "pack.yaml")
    start = files["MEMBER-START.md"]
    assert start.startswith("# Northwind Agency Lab: your AI toolkit")
    assert "| **northwind-offer-builder** | Build your one-page offer" in start
    assert "Upload a skill" in start and "## 4. Report your First win" in start
    review = files["ADMIN-REVIEW.md"]
    assert "| northwind-tutor | Do I need to register as a limited company" in review and "points to support" in review
    assert "| northwind-offer-builder | Build my offer for restaurants in Manchester." in review
    assert "skool-kit pack-share . -o ../share --version 1.0.0" in review and "<file>.new" in review
    assert "| `../share/northwind-member-kit-1.0.0.zip` | Every member." in review


def test_build_writes_files_and_rebuild_keeps_admin_edits(lab):
    out = lab / "member-pack"
    first = build_pack(lab / "pack.yaml", out)
    assert len(first.written) > 20 and (out / MANIFEST).is_file()
    again = build_pack(lab / "pack.yaml", out)
    assert again.written == [] and again.kept == []
    skill = out / "skills/northwind-offer-builder/SKILL.md"
    skill.write_text(skill.read_text() + "\n- My own rule.\n", encoding="utf-8")
    lesson = lab / "classroom/02-your-offer/03-pricing-your-first-offer.md"
    lesson.write_text(lesson.read_text() + "\nNew pricing note.\n", encoding="utf-8")
    third = build_pack(lab / "pack.yaml", out)
    assert "skills/northwind-offer-builder/SKILL.md" not in third.written
    assert "skills/northwind-offer-builder/references/your-offer/pricing-your-first-offer.md" in third.written
    assert "My own rule." in skill.read_text()
    edited_again = build_pack(lab / "pack.yaml", out)
    assert edited_again.written == []  # still edited: still kept, never silently overwritten
    edit_spec(lab, lambda s: s["playbooks"][0]["rules"].append("Another rule."))
    fourth = build_pack(lab / "pack.yaml", out)
    assert fourth.kept == ["skills/northwind-offer-builder/SKILL.md"]
    assert "Another rule." in (skill.parent / "SKILL.md.new").read_text() and "My own rule." in skill.read_text()
    forced = build_pack(lab / "pack.yaml", out, force=True)
    assert "skills/northwind-offer-builder/SKILL.md" in forced.written and "My own rule." not in skill.read_text()


def test_build_refuses_a_folder_it_did_not_make(lab):
    (lab / "member-pack").mkdir()
    (lab / "member-pack" / "notes.txt").write_text("mine")
    with pytest.raises(SkillError, match="wasn't made by pack-build"):
        build_pack(lab / "pack.yaml", lab / "member-pack")


def test_files_no_longer_generated_are_reported_not_deleted(lab):
    out = lab / "member-pack"
    build_pack(lab / "pack.yaml", out)
    edit_spec(lab, lambda s: s["playbooks"].pop())
    res = build_pack(lab / "pack.yaml", out)
    assert (out / "skills/northwind-outreach-sprint/SKILL.md").exists()
    assert any("northwind-outreach-sprint/SKILL.md is no longer generated" in w for w in res.warnings)


@pytest.mark.parametrize("change, message", [
    (lambda s: s["playbooks"][0]["steps"][0].update(lesson="No such lesson"), "no lesson called 'No such lesson'"),
    (lambda s: s.pop("first_outcome"), "first_outcome: 'name' is required"),
    (lambda s: s["first_outcome"].update(within_days=0), "within_days"),
    (lambda s: s.update(playbooks=[]), "add at least one playbook"),
    (lambda s: s["playbooks"][0].update(checks=[{"contains": "x", "regex": "y"}]), "exactly one of"),
    (lambda s: s["playbooks"][0].update(checks=[{"regex": "("}]), "is invalid"),
    (lambda s: s["playbooks"][1].update(name="offer-builder"), "two playbooks use this name"),
    (lambda s: s["playbooks"][0]["example"].update(output_file="missing.md"), "example output file not found"),
    (lambda s: s.update(skill_prefix="Bad Prefix"), "must be lowercase"),
    (lambda s: s["tutor"]["sample_questions"][0].update(lesson="Nope"), "no lesson called 'Nope'"),
    (lambda s: s["playbooks"][0].update(inputs=[{"name": "x"}]), "'ask' is required"),
    (lambda s: s["playbooks"][0]["rules"].append({"lesson": "Pricing your first offer"}), "'rule' is required"),
    (lambda s: s["playbooks"][0]["rules"].append({"rule": "x", "lesson": "Nope"}), "no lesson called 'Nope'"),
    (lambda s: s["playbooks"][0]["rules"].append(5), "write a sentence"),
    (lambda s: s["playbooks"][0].update(extra_cases=[{"id": "x", "input": "y"}]), "'pass_if' is required"),
    (lambda s: s["playbooks"][0].update(extra_cases="nope"), "must be a list"),
])
def test_spec_errors_are_explained(lab, change, message):
    edit_spec(lab, change)
    with pytest.raises(SkillError, match=message):
        plan_pack(lab / "pack.yaml")


def test_playbook_without_example_or_checks_warns(lab):
    def strip(s):
        s["playbooks"][0].pop("example")
        s["playbooks"][0].pop("checks")
    edit_spec(lab, strip)
    files, _, warnings = plan_pack(lab / "pack.yaml")
    assert any("no example and no checks" in w for w in warnings)
    assert "skills/northwind-offer-builder/examples/example-output.md" not in files


def test_lesson_reference_by_module_path(lab):
    edit_spec(lab, lambda s: s["playbooks"][0]["steps"][0].update(lesson="your-offer/pick-a-niche-with-the-3-filter-test"))
    files, _, _ = plan_pack(lab / "pack.yaml")
    assert 'Lesson: "Pick a niche with the 3-filter test"' in files["skills/northwind-offer-builder/SKILL.md"]


def test_describe_check():
    assert describe_check({"max_chars": 10}) == "It is at most 10 characters long."
    assert describe_check({"regex": "a", "explain": "Shows the score."}) == "Shows the score."
    assert describe_check({"json_has_keys": ["a"]}) == 'It is JSON with the keys "a".'


def test_list_lessons():
    assert "Outreach / The 3-line Loom script" in list_lessons(LAB / "pack.yaml")


def test_cli(lab, capsys):
    assert main(["pack-build", str(lab / "pack.yaml"), "-o", str(lab / "out")]) == 0
    out = capsys.readouterr().out
    assert "Built" in out and "3 skills (northwind-tutor" in out and "ADMIN-REVIEW.md" in out
    skill = lab / "out/skills/northwind-tutor/SKILL.md"
    skill.write_text("edited", encoding="utf-8")
    edit_spec(lab, lambda s: s.update(support="Email help@example.com"))
    assert main(["pack-build", str(lab / "pack.yaml"), "-o", str(lab / "out")]) == 0
    assert "Kept your edits in 1 file(s)" in capsys.readouterr().out
    assert main(["pack-build", str(lab / "pack.yaml"), "--list-lessons"]) == 0
    assert "Your offer / Pricing your first offer" in capsys.readouterr().out
    assert main(["pack-build", str(lab / "missing.yaml")]) == 2
    assert "pack spec not found" in capsys.readouterr().err


def test_committed_demo_output_is_current(tmp_path):
    """examples/agency-lab/member-pack is what the README shows; rebuild it if this fails."""
    files, _, _ = plan_pack(LAB / "pack.yaml")
    for rel, content in files.items():
        assert (LAB / "member-pack" / rel).read_text(encoding="utf-8") == content, rel


def test_optional_inputs_get_defaults(lab):
    edit_spec(lab, lambda s: s["playbooks"][0]["inputs"].append(
        {"name": "currency", "ask": "Which currency?", "required": False, "default": "your local currency"}))
    md = plan_pack(lab / "pack.yaml")[0]["skills/northwind-offer-builder/SKILL.md"]
    assert "| currency | no (if missing: your local currency) | Which currency?" in md
    assert "For optional inputs, use the default shown and list it under Gaps and assumptions." in md


def test_pilot_checklist_uses_the_specs_windows_and_keeps_verdicts_separate():
    files, _, _ = plan_pack(LAB / "pack.yaml")
    text = files["pilot/CHECKLIST.md"]
    assert "It counts only within 14 days of joining." in text
    assert "Members not yet due are left out, never counted as lost." in text
    assert "judged separately" in text and "agreed in writing before the first pilot member joins" in text
    for step in ("Fit and scope", "Content intake", "Pack construction", "Acceptance", "Installation", "Member onboarding",
                 "Adoption", "Completed tasks", "Answer corrections", "Staff effort and cash costs", "Renewal follow-up",
                 "Final customer report"):
        assert f"**{step}**" in text, step
    assert files["pilot/acceptance.csv"].startswith("date,skill,test,surface,passed")


def test_admin_review_lists_rules_that_are_not_word_for_word(lab):
    def edit(s):
        s["playbooks"][0]["rules"] = [
            {"rule": "Never go below 300 a month. Below that, support eats your time.", "lesson": "Pricing your first offer"},
            {"rule": "Never go below 200 a month.", "lesson": "Pricing your first offer"},
            "Be friendly.",
        ]
        for pb in s["playbooks"][1:]:
            pb["rules"] = []
    edit_spec(lab, edit)
    assert main(["pack-build", str(lab / "pack.yaml"), "-o", str(lab / "out")]) == 0
    review = (lab / "out" / "ADMIN-REVIEW.md").read_text()
    section = review.split("### Rules to confirm first", 1)[1].split("## 2.", 1)[0]
    assert "2 of 3 rules are paraphrased or added" in section
    assert '"Never go below 200 a month." is not word for word in "Pricing your first offer"' in section
    assert '"Be friendly." names no lesson' in section
    assert "support eats your time" not in section
