# journey-select-v1

> Actual model execution, unedited. Claude Code subagent, model alias "sonnet", 2026-10-29 18:03 UTC, about 8 s.
> Journey step (see ../README.md).


---
1: northwind-offer-builder
2: northwind-outreach-sprint
3: northwind-offer-builder
4: northwind-outreach-sprint
5: none
6: none
7: northwind-tutor
8: northwind-tutor
