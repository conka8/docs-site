# journey-update-offer

> Actual model execution, unedited. Claude Code subagent, model alias "sonnet", 2026-10-29 18:03 UTC, about 52 s.
> Journey step (see ../README.md).


---
## Niche check

Scored with *(Lesson: "Pick a niche with the 3-filter test")*, 1 point per filter.

| Filter | Estate agents, Cardiff |
|---|---|
| 1. Money leak | 1. An unanswered or slow-answered viewing enquiry is a lost lead. The lesson doesn't name estate agents, so this is provisional (see Gaps). |
| 2. Already pays for software | 1. Provisional, see Gaps. |
| 3. Reachable this week | 1. Provisional, see Gaps. |
| **Score** | **3/3** |

Chosen niche: estate agents in Cardiff. Commit for 30 days and don't switch.

## Headline

We answer every website viewing enquiry within 60 seconds and book the viewing for estate agents in Cardiff, without hiring extra admin staff. *(Lesson: "The one-outcome offer")*

Headline rules check: one niche, one countable outcome (enquiries answered within 60 seconds), no tool names, no promise about their sales.

## Who it's for

Independent estate and lettings agents in Cardiff whose team is out at viewings or on the phone, and who already use a website and diary or CRM.

## The problem

Enquiries arrive while the team is out. Replies come late, and the enquirer may contact another agent. See Gaps: the quote is a placeholder.

> "We're out at a viewing and the enquiries pile up. By the time we reply, they've called someone else."

## How it works

1. A visitor asks about a property or a viewing on your website.
2. They get an instant answer to the common questions, using the listing details you provide.
3. They pick a free slot and the viewing goes in your diary.

## What's included

- Setup of the website assistant on your site
- It runs every month
- A monthly check-in to review the numbers and adjust the answers

## Price

**Founding client offer: 750 setup + 450 a month.** *(Lesson: "Pricing your first offer")*

Why this point: the founding range is 500-1,000 setup and 350-500 a month. The lesson says to use the higher end when one recovered lead is worth a lot. I don't have a figure for what a lead is worth to an agent, so I placed it in the upper-middle until you confirm. Founding clients get this price in exchange for a testimonial and the 30-day pilot. Never go below 350 a month.

## Pilot and proof

30-day pilot with one metric agreed up front. Suggested metric: the share of website viewing enquiries answered within 60 seconds. This is speed and coverage, which you control, not their sales. No results are guaranteed.

## What I need from you

- Access to your website and your viewings diary
- Your listing details and viewing rules
- One contact person
- 30 minutes for setup

## Check

- Required headings present: pass.
- Check, Gaps and assumptions, Next step present: pass.
- Chosen niche shows 3/3: pass, but provisional (see Gaps).
- No guarantee of results: pass.
- At most 6000 characters: pass.
- Recommendations follow and cite the lessons: pass.
- Money and behaviour claims sourced or listed in Gaps: pass. Prices come from the ladder. The 60-second figure comes from the lesson's example headline.

## Gaps and assumptions

- Verify before use: filter 1. The lesson doesn't list estate agents. Confirm on your first calls that a lost viewing enquiry costs them real money.
- Verify before use: filter 2. The lesson doesn't state that Cardiff estate agents pay for a CRM or diary software. Check this.
- Verify before use: filter 3. Check you can find 50 Cardiff estate agents in under an hour (Google Maps, a directory). If not, the niche fails.
- Verify before use: the problem quote and the idea that enquirers contact another agent are my wording, not from the lessons. Replace the quote with what agents say.
- Assumed currency: pounds (£), since you're in Cardiff.
- Assumed: the assistant can read the agent's diary to book viewings. Confirm their diary or CRM allows this.
- Left out "AI chatbot" and any tool names from the page, because the lessons say clients buy outcomes.
- The price point (750 + 450) is my choice within the ladder, not a lesson figure.

## Next step

Post the offer in Wins today with "#firstwin", then start the outreach-sprint skill.

## Question for a coach

I'm building a one-page offer for estate agents in Cardiff (website assistant that answers viewing questions and books viewings), using "Pick a niche with the 3-filter test" and "The one-outcome offer". I scored them 3/3 provisionally and priced at 750 + 450. Do estate agents count as passing filter 1 (money leak), and is that price point right?
