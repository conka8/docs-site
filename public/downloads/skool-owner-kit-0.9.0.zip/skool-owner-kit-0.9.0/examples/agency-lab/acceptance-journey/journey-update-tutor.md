# journey-update-tutor

> Actual model execution, unedited. Claude Code subagent, model alias "sonnet", 2026-10-29 18:03 UTC, about 18 s.
> Journey step (see ../README.md).


---
The lowest monthly fee you can charge a founding client is **350 a month**, in your local currency.

Founding clients are your first three clients. For them the lessons set the monthly fee at **350 to 500**, plus a one-off setup fee of 500 to 1,000. The lesson says never to go below 350 a month, because below that, support eats your time.

The lower price comes with conditions. In exchange, the founding client gives you:
- a testimonial, and
- a 30-day pilot with an agreed metric.

A few related rules from the same lesson:
- Always price as setup fee plus monthly fee, never one-off only. The monthly fee is your business.
- Use the higher end of the range when one recovered lead is worth a lot to the client (a dental implant, a roof, a legal case).
- Don't promise refunds on results you don't control. Offer the pilot instead.
- Put the price on your offer page. "Contact us for pricing" kills first conversations.

*(Lesson: "Pricing your first offer", module "Your offer")*

You can watch the full lesson here: https://example.com/northwind-agency-lab/classroom

Reminder: if you have follow-up questions, post them in the Help channel by Friday.
