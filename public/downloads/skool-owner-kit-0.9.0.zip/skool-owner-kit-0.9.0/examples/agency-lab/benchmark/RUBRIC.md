# Grading rubric (fixed before grading)

Each case's replies are relabelled with letters in a shuffled order and given to a fresh grader with the case's lesson
files and the member's message. The grader is not told how any reply was produced. `mapping.json` records the
letters. The grader's instructions, verbatim:

> You are grading replies from AI assistants to a member of an online course community, for a fair comparison. You
> do not know how each reply was produced; judge only the text. Read every lesson file first: the lessons are the
> ground truth.
>
> Score each reply:
> - **rules** (0-2): applies the lesson rules relevant to this request correctly (2), partly or with a mistake (1),
>   ignores or contradicts them (0).
> - **complete** (0-2): gives the member what they asked for or, where something the lessons require is genuinely
>   missing, asks only for that (2); partly (1); not (0).
> - **citations**: number of lesson citations (a named lesson). **wrong_citations**: citations where the named lesson
>   doesn't support what is attributed to it.
> - **unsupported**: number of specific claims (money amounts, numbers, statistics, claims about how customers behave,
>   legal or tax facts, guarantees) that come from neither the lessons nor the member's message and are not clearly
>   labelled as the assistant's own assumption or as needing verification. List them briefly.
> - **clarify** (0-2): asks for what is genuinely missing without unnecessary questions and doesn't invent facts to fill
>   gaps (2); partly (1); asks nothing that was needed, or invents (0). If nothing was missing, 2 if it asks nothing
>   unnecessary.
> - **conflicts** (yes / no / na): where the member's request conflicts with the lessons, does the reply say so?
> - **usable** (0-2): could the member use it with light edits, consistently with the lessons (2), heavy edits (1), not (0).
> - **notes**: one or two sentences on the most important problem.
>
> Also say which reply you would want a member of this course to receive, and why, in one sentence.

Known limits: replies from the packaged skill have a recognisable structure (Check, Gaps and assumptions), so blinding is
partial. One grader per case, no second rater. The grader is a model (Claude Code subagent, default model), not a person.
