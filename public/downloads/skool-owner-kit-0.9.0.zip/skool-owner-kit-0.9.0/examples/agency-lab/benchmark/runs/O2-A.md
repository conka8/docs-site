# O2-A

> Actual model execution, unedited. Claude Code subagent, model alias "sonnet", 2026-10-29 18:02 UTC, about 17 s.
> Condition: General assistant, normal request (no lessons, no skill).


---
I can build this, but I need to know what you actually do for the restaurants, and I'd change the guarantee first.

**1. What's the service?**
The offer depends on this, and I don't want to invent it. For example:
- Google Business Profile and local SEO
- Instagram/TikTok content
- A booking widget or website
- Email/SMS to past customers
- Paid ads
- Review generation

Tell me what you deliver each month and roughly how many hours it takes you.

**2. Why I'd change the "guaranteed 20% more bookings"**
- **You can't measure it.** Many Manchester restaurants don't track bookings. Walk-ins, phone calls, OpenTable, Resy and Google Reserve all report separately. Without a baseline, any dispute is your word against theirs.
- **You don't control the outcome.** Weather, a bad review, a chef leaving, a Man City home game or a road closure can all move bookings by 20%. A guarantee you can't control means you eat the refund when things go wrong.
- **It can backfire.** A fixed 20% in month one means you refund if you hit 19%. A restaurant that's already full has nothing to grow.
- **Month one is too early.** Most channels (SEO, social, reviews) take 6 to 8 weeks to show results.
- **Check the claim.** In the UK, a guarantee in your marketing needs to be one you can substantiate under ASA/CMA rules. A vague "guaranteed results" claim can cause trouble.

**3. Stronger options that still make it an easy yes**
- **Risk-reversal guarantee:** "If we haven't delivered [X measurable outputs] in 30 days, you don't pay." Outputs are things you control, such as the profile fully optimised, 8 posts published, a review campaign live and a booking link on every channel.
- **Conditional results guarantee:** "We set a baseline together in week 1. If bookings from [tracked source] haven't risen 20% by day 60, month 2 is free." This needs a tracking link or code, a signed baseline and a fair measurement window.
- **Pay-for-performance top-up:** £150 base plus a small fee for each tracked booking above baseline. It's more work, but it's credible.

**4. On the £150 price**
- £150 is easy to say yes to, but it may not cover your time. At your £30/hr, it's 5 hours of work. If onboarding, reporting and chasing replies take longer, you lose money, and a guarantee makes that worse.
- Cheap prices sometimes signal low quality to restaurant owners.
- Consider £150 as a **pilot price** for month 1 and 2 (limited to the first 5 restaurants), moving to £250-£350 after. The scarcity also helps you close.

**5. Draft structure once you confirm the service**
- Headline built around one outcome and one proof point
- What they get, listed monthly
- The guarantee (one of the options above)
- Price, with the pilot framing
- A 7-day onboarding timeline
- Simple terms: 30-day rolling, tracked source, baseline sign-off
- A short outreach message for Manchester venues (Northern Quarter, Spinningfields, Didsbury and Chorlton are good starting areas)

**Questions to answer so I can write it:**
1. What exactly do you deliver?
2. Do you have any past results or case studies, even from a friend's venue?
3. What kinds of restaurants are you targeting (independents, small chains, takeaway-heavy)?
4. Do you want the offer as a one-page PDF, a message to send, or a landing page?
5. Which guarantee option do you prefer?
