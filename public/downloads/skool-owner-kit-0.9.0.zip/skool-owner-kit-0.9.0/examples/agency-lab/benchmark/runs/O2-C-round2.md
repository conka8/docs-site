# O2-C-round2

> Actual model execution, unedited. Claude Code subagent, model alias "sonnet", 2026-10-29 18:10 UTC, about 11 s.
> Condition: Packaged member skill (installed copy of the shipped pack).
> Pack after fixes 1-2 (draft with [brackets] when filters are unknown; tag a coach only after a day), made after the blind grading; not graded blind.

---
Before I build it, I need one thing from you.

**What can you set up for a restaurant client today?** For example, an online booking flow, a missed-call text-back, a chatbot that answers booking questions, or automated reminders. Name the tools you'd use if you know them.

Two things you've asked for conflict with the Northwind method, so I'll build the offer differently:
- **Price:** founding clients pay a setup fee plus a monthly fee, and the monthly fee never goes below £300. £150 a month is under that floor.
- **Guarantee:** the method doesn't allow promising a result like "20% more bookings". I'll offer a 30-day pilot with one agreed metric instead.

I'll note both under "Gaps and assumptions" in the offer.
