# O2-C-round3

> Actual model execution, unedited. Claude Code subagent, model alias "sonnet", 2026-10-29 18:10 UTC, about 25 s.
> Condition: Packaged member skill (installed copy of the shipped pack).
> Pack after fixes 1-3 (read the lessons before asking), made after the blind grading; not graded blind.

---
Before I build anything, three things in your brief conflict with the Northwind lessons.

**1. Restaurants fail the money-leak filter.** *(Lesson: "Pick a niche with the 3-filter test")* The lesson says most restaurants don't pass. Margins are thin, and a missed call is a lost $20 order, not a $2,000 job. Only a niche that scores 3/3 can go into an offer, so I can't write one for restaurants. The lesson's examples that pass are dental clinics, roofers, med spas, HVAC and law firms. Manchester should be easy to search for any of these, which helps with the "reachable this week" filter. If you know someone or speak the language of one of these niches, pick that one.

**2. £150 a month is below the floor.** *(Lesson: "Pricing your first offer")* The rule is never below 300 a month, because below that support eats your time. Founding clients (clients 1-3) pay 500-1,000 setup plus 300-500 a month. Founding clients get that lower price in exchange for a testimonial and a 30-day pilot with an agreed metric. Setup fee plus monthly fee is always required, and the price goes on the page.

**3. A guaranteed 20% more bookings isn't allowed.** *(Lesson: "The one-outcome offer")* You don't control how many bookings a client gets, so the offer can't guarantee that. The lesson says to promise what you control, such as speed, volume or coverage. It also says to offer a 30-day pilot with one success metric you agree with the client up front. The 20% figure isn't in the lessons, so it can't be used as a claim either.

To go ahead I need two answers:

- **What can you set up for a client today?** For example, a missed-call text-back, a chatbot or a booking flow. Tell me which tool or automation you'd use.
- **Which 1-3 niches do you want to consider in Manchester?** Pick from the ones above or name your own. I'll score each against the three filters, then write the full one-page offer with the compliant price and a 30-day pilot.
