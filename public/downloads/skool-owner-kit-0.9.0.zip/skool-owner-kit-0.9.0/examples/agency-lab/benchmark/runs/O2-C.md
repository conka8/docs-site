# O2-C

> Actual model execution, unedited. Claude Code subagent, model alias "sonnet", 2026-10-29 18:02 UTC, about 19 s.
> Condition: Packaged member skill (installed copy of the shipped pack).


---
Before I build the offer, I need one thing from you.

**What can you set up for a client today?** For example: a booking flow, a missed-call text-back, or a chatbot, and the tools you'd use. (Your answer decides what "How it works" and "What's included" say.)

I have your niche (restaurants) and your area (Manchester). I'll check restaurants against the three-filter test when I build the offer.

Two things in your message won't go into the offer as written, so you aren't surprised later:

- **Price:** Founding-client pricing in the Northwind method is a setup fee plus a monthly fee, and the monthly fee never goes below £300. £150 a month is under that floor. I'll set the price from the ladder and explain where I put it in the range.
- **Guarantee:** I can't write a guarantee of 20% more bookings, because results like that aren't fully in your control. The method uses a 30-day pilot with one agreed metric instead. I'll build that pilot around bookings, so the client still has a clear way to see whether it's working.

Both will be listed under "Gaps and assumptions" in the finished offer.
