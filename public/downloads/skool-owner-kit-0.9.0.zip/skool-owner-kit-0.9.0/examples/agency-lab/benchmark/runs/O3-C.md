# O3-C

> Actual model execution, unedited. Claude Code subagent, model alias "sonnet", 2026-10-29 18:02 UTC, about 47 s.
> Condition: Packaged member skill (installed copy of the shipped pack).


---
## Niche check

Scored with *(Lesson: "Pick a niche with the 3-filter test")*, 1 point per filter.

| Filter | Physio clinics, Bristol | Car garages, Bristol |
|---|---|---|
| 1. Money leak | 1. An unanswered enquiry or no-show loses a booking. Provisional, see Gaps. | 1. An unanswered enquiry loses a booking. Provisional, see Gaps. |
| 2. Already pays for software | 1. Provisional, see Gaps. | 1. Provisional, see Gaps. |
| 3. Reachable this week | 1. Provisional, see Gaps. | 1. Provisional, see Gaps. |
| **Score** | **3/3** | **3/3** |

Both score 3/3 on my provisional reading. The lesson's tie-break is to pick the one where you already know someone or speak their language. I don't know that, so I picked physio clinics because a booking assistant fits appointment-based work. If you know people in garages, tell me and I'll switch. Commit to one niche for 30 days.

## Headline

We reply to every website enquiry within 60 seconds and book it straight into your calendar for physio clinics in Bristol, without hiring a receptionist. *(Lesson: "The one-outcome offer")*

Headline rules check: one niche, countable outcome (replies and bookings), no tool names, no promise about their revenue.

## Who it's for

Independent physio clinics in Bristol that take bookings through their website and already use a booking system or calendar.

## The problem

Enquiries arrive while the team is with patients, and a slow reply can mean a lost booking. Placeholder quote, replace it with what Bristol clinics actually say:

> "We're in sessions all day. Website enquiries wait until we get a gap."

## How it works

1. A visitor asks about an appointment on your website.
2. The booking assistant replies within 60 seconds and offers free slots.
3. The booking goes straight into your calendar and your team sees it.

## What's included

- Setup of the website booking assistant, connected to your calendar
- The assistant running every month
- A monthly check-in to review the numbers and adjust the wording

## Price

**Founding client offer: £750 setup + £400 a month.** *(Lesson: "Pricing your first offer")*

Why this point: the founding range is 500-1,000 setup and 300-500 a month. The lesson says to go to the higher end when one recovered lead is worth a lot, but it gives no value for a physio booking, so I chose the middle. You can move toward £500 setup if needed, but never below £300 a month. Founding clients get this price in exchange for a testimonial and the 30-day pilot.

## Pilot and proof

30-day pilot with one metric agreed up front. Suggested metric: the share of website enquiries answered within 60 seconds. This is a speed and coverage metric you control. No promise about bookings or revenue.

## What I need from you

- Calendar and website access (logins)
- One contact person at the clinic
- 30 minutes for setup

## Check

- Required headings present: pass.
- Check, Gaps and assumptions, Next step present: pass.
- Chosen niche shows 3/3: pass, provisionally. See Gaps.
- No guarantee of results: pass.
- At most 6000 characters: pass.
- Follows and cites the lessons, nothing invented: pass. The 60-second figure is adapted from the lesson's example headline.
- Money and behaviour claims sourced or in Gaps: pass. The prices come from the ladder, and the midpoint is my judgement, listed in Gaps.

## Gaps and assumptions

- Verify before use: filter 1. The lessons name dental, roofers, med spas, HVAC and law firms. They don't name physio or garages. Confirm a missed enquiry costs a clinic real money.
- Verify before use: filter 2. Confirm Bristol physio clinics pay for a booking system or calendar.
- Verify before use: filter 3. Check you can find 50 Bristol physio clinics in under an hour. If not, the niche fails.
- Verify before use: the problem quote, "slow reply can mean a lost booking" and "without hiring a receptionist" are my wording, not from the lessons.
- Verify before use: the 60-second reply time, and that your assistant can book into each clinic's calendar.
- Assumed: £ currency, since you're in Bristol. The midpoint price (£750 + £400) is my judgement.
- I left "Voiceflow" and "chatbot" off the page because clients buy outcomes. You can deliver this today.

## Next step

Post the offer in Wins today with "#firstwin", then start the outreach-sprint skill.

## Question for a coach

I'm building a one-page offer for physio clinics in Bristol: a website booking assistant that books into their calendar. I used "Pick a niche with the 3-filter test", "The one-outcome offer" and "Pricing your first offer". I've chosen physio over garages and priced at £750 setup + £400 a month. The lessons don't cover whether physio clinics pass filter 1. Does a missed enquiry or no-show count as a money leak, and is the mid-range price sensible without a known value per lead?
