# R2-C

> Actual model execution, unedited. Claude Code subagent, model alias "sonnet", 2026-10-29 18:02 UTC, about 38 s.
> Condition: Packaged member skill (installed copy of the shipped pack).


---
## Messages

**Clifton Physio**

Day 0
> Clifton Physio's website only has a contact form and no online booking.
> A patient who wants an appointment has to fill in the form and wait, and may book somewhere else instead.
> I recorded a 60-second video showing how I'd fix it: [Loom link]. Worth a look?

Day 3 (Follow-up 1, new angle)
> Clifton Physio: one more thing I noticed: [NEW OBSERVATION: a different detail from their website, reviews or Google profile].
> Same cost applies: a patient who can't book easily may book somewhere else.
> Here's the 60-second video again: [Loom link]. Worth a look?

Day 7 (Follow-up 2, polite close)
> Clifton Physio: I haven't heard back, so I don't want to keep filling your inbox.
> Should I close your file?

**Redland Sports Injury Clinic**

Day 0
> Redland Sports Injury Clinic has two Google reviews saying nobody called them back.
> Each unreturned call is a patient who books somewhere else.
> I recorded a 60-second video showing how I'd fix it: [Loom link]. Worth a look?

Day 3 (Follow-up 1, new angle)
> Redland Sports Injury Clinic: one more thing I noticed: [NEW OBSERVATION: a different detail from their website, reviews or Google profile].
> Same cost applies: an unreturned call is a patient who books somewhere else.
> Here's the 60-second video again: [Loom link]. Worth a look?

Day 7 (Follow-up 2, polite close)
> Redland Sports Injury Clinic: I haven't heard back, so I don't want to keep filling your inbox.
> Should I close your file?

Send exactly these two follow-ups per business, then stop. Never send a third. *(Lesson: "The follow-up cadence")*

Each Day 0 message is three lines and under 90 words. It starts with the business and ends with the ask. It has no prices, attachments or links except the Loom placeholder. *(Lesson: "The 3-line Loom script")*

## Skipped

- **Bristol Back Care:** you couldn't find anything specific yet, so there is no real observation. A generic message burns your list. Check their website, Google reviews or opening hours for one specific thing, then add them back. *(Lesson: "The 3-line Loom script")*

## Tracking sheet

```csv
Business,Contact,Observation,Day 0 sent,Day 3 sent,Day 7 sent,Reply,Call booked
Clifton Physio,,Website only has a contact form; no online booking,,,,,
Redland Sports Injury Clinic,,Two Google reviews say nobody called them back,,,,,
```

Count a message as "sent" only once the Day 0 message has gone out. *(Lesson: "The follow-up cadence")*

## Check

- Contains "## Messages", "## Tracking sheet", "Day 0", "Day 3" and "Day 7": pass. All are present.
- Contains the exact tracking column header: pass. The CSV uses the lesson's columns.
- Contains "## Check", "## Gaps and assumptions" and "## Next step": pass.
- At most 12000 characters: pass.
- Every recommendation follows and cites the lessons, and nothing is invented: pass, except that Follow-up 1 needs your own new observation (see Gaps).
- Every number or customer-behaviour claim comes from the lessons or you, or is listed for verification: pass. "Each unreturned call is a patient who books somewhere else" adapts the lesson's wording. The Clifton cost line is my own wording and is listed under Gaps.

## Gaps and assumptions

- **Contact names are missing.** The Contact column is blank. Find a name for each clinic, or leave it blank and address the message to the practice.
- **Follow-up 1 needs a new angle.** The lesson asks for a different observation or a short result from another niche. You gave one observation per business, and I have no results from another niche. I left a `[NEW OBSERVATION]` placeholder instead of inventing one. Find a second real detail for each clinic before Day 3.
- **Verify before use:** the Clifton cost line ("has to fill in the form and wait, and may book somewhere else instead") is my own wording of how patients behave. The lessons don't cover it, so check it fits what you know or reword it. Also recheck that Clifton's site still has only a contact form, and that the two Redland reviews are still visible and say nobody called back.
- **Offer claims not used in the messages:** the "24/7" and "without extra front-desk staff" claims are yours and stay out of the messages. Keep them for the Loom video, and make sure you can back them up.
- **Loom videos:** record one 60-second video per business and replace each `[Loom link]` before sending.
- **Assumption:** I read "contact form, no online booking" as patients having no way to book instantly on the website.
- No conflicts with the lessons.

## Next step

Send today's Day 0 messages to Clifton Physio and Redland Sports Injury Clinic, mark them in the tracking sheet, and set a reminder for Day 3. Today, also research Bristol Back Care for one specific observation, and find a second real observation for each of the first two clinics.
