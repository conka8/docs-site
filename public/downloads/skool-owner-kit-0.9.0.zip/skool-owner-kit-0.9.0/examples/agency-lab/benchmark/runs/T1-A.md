# T1-A

> Actual model execution, unedited. Claude Code subagent, model alias "sonnet", 2026-10-29 18:02 UTC, about 14 s.
> Condition: General assistant, normal request (no lessons, no skill).


---
For a first client, I'd charge a low setup fee plus a modest monthly fee. Don't work for free.

**Suggested first-client price**
- Setup: $300-500 one-time. It covers number setup, the text flow, and A2P/10DLC registration.
- Monthly: $197-297. Make it month-to-month with no long contract.
- Optional: offer the first 1-2 months at a discount in return for a written testimonial, a case study with numbers, and permission to use their name.

**Typical market rates once you have proof**
- Setup: $500-1,500
- Monthly: $297-497. Clinics with several locations or added features (review requests, appointment reminders, a booking link) pay more.

**Why not price by hours**
- The tool costs you roughly $30-100/month (Twilio, GoHighLevel or similar), and the build takes a few hours.
- A new dental patient is typically worth $1,000-3,000 or more over their lifetime. If the text-back recovers even one or two missed calls a month, it pays for itself.
- Price against that recovered revenue, not your build time.

**Before you quote, find out**
1. How many calls they miss each week. Ask the front desk, or check the phone system's call log.
2. What a new patient is worth to them.
3. Whether the clinic is a solo practice or part of a group. A solo owner can say yes right away.

**Things to handle**
- Register for A2P 10DLC, or the texts will get blocked.
- Keep patient details (PHI) out of the automated texts. Use a platform that will sign a BAA, and tell the clinic what you're doing about HIPAA.
- Write down what's included: the number of texts, support hours, and who owns the account if you part ways.

**How to pitch it**
Say: "I'll set this up for $X. If it doesn't recover at least one patient in the first 30 days, I'll refund the setup fee." A guarantee like that lets you charge more.

If you tell me their size, location, and rough missed-call volume, I can give you a specific number and a one-paragraph pitch.
