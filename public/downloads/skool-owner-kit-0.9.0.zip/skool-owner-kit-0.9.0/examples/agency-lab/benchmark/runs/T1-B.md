# T1-B

> Actual model execution, unedited. Claude Code subagent, model alias "sonnet", 2026-10-29 18:02 UTC, about 32 s.
> Condition: Same assistant, given the same lesson files and clear instructions.


---
**Short answer:** charge a setup fee of 1,000 and a monthly fee of 500, in your local currency. Those are the top of the founding-client range. Before you quote it, I need one thing from you (see "What I need from you" below).

**Where the numbers come from**
- **Setup plus monthly (lesson 02-03, "Pricing your first offer"):** price every offer as a setup fee plus a monthly fee, never one-off.
- **Founding-client range (02-03):** clients 1 to 3 pay a setup of 500 to 1,000 and a monthly fee of 300 to 500.
- **Top of the range (02-03):** use the higher end when one recovered lead is worth a lot to the client. The lesson names a dental implant as an example. A dental clinic fits that.
- **Dental clinics fit the niche (02-01, "3-filter test"):** the lesson names them as passing the "money leak" filter.
- **Floor (02-03):** never go below 300 a month.
- **Founding-client terms (02-03):** the lower price is in exchange for a testimonial and a 30-day pilot with an agreed metric. Offer that pilot instead of promising refunds on results you don't control.
- **Pilot metric (02-02, "The one-outcome offer"):** agree one metric up front. Replying to every missed call within 60 seconds is the example the lessons use.

**How to present it**
- **Offer page (02-03, 02-02):** put the price on your one-page offer, in section 6. "Contact us for pricing" is called out as killing first conversations.
- **First message (03-01, "3-line Loom script"):** don't put the price in it. That lesson says no prices in the first message.
- **Discovery call (03-03, "The discovery call"):** ask what one new client is worth to them, then propose the 30-day pilot. Don't send a proposal unless they ask for one.
- **Offer page wording (02-02):** don't name n8n or any other tool on the page.

**What I need from you**
1. **Currency.** The lessons say amounts are "in your local currency" but give no conversion. You're in Tokyo, so which currency is the clinic billed in? If it's yen, 500 and 300 would be far too low, and the lessons don't say what the equivalent should be. Tell me the currency and I'll help you set a number that keeps the same relationship to the 300 floor.
2. **Where the clinic is.** The lessons assume one niche in one city or region (02-01). Is the clinic in Japan or in the US?
3. **Whether it's your first client.** I'm assuming it is, which is why I'm using the founding-client tier. Say so if it isn't.

**Not in the lessons (my additions)**
- **1,000 and 500 as my pick:** the lessons give a range, not a single number. I chose the top end from the implant rule. You could reasonably go lower if the clinic is very small, but nothing in the lessons says so.
- **Costs and legal:** the lessons don't cover your SMS and phone costs, taxes, contracts, or rules on texting patients (consent, privacy). Check those yourself before you sign.

**Nothing you asked goes against the lessons.**
