# T1-C

> Actual model execution, unedited. Claude Code subagent, model alias "sonnet", 2026-10-29 18:02 UTC, about 13 s.
> Condition: Packaged member skill (installed copy of the shipped pack).


---
Short answer: for your first client, charge a setup fee of 500 to 1,000 plus a monthly fee of 300 to 500. Use your own local currency (the lessons don't name one). Because a dental clinic can earn a lot from one recovered lead, such as an implant, aim for the higher end of both ranges.

*(Lesson: "Pricing your first offer", module "Your offer")*

Here is how it works.

1. **Charge two parts.** A setup fee is paid once. A monthly fee is paid every month. The lesson says never charge only a one-off fee, because the monthly fee is your real business.
2. **You count as a "founding client" deal.** Clients 1 to 3 get the lower price. In return, ask them for two things: a testimonial, and a 30-day pilot with a success metric you both agree on up front. The metric could be something like "every missed call gets a text within 60 seconds".
3. **Don't go below 300 a month.** Under that, support work eats your time.
4. **Don't promise refunds or revenue results.** You don't control how many callers book. Offer the pilot instead, and promise things you do control, such as speed and coverage. *(Lesson: "The one-outcome offer", module "Your offer")*
5. **Put the price on your offer page.** "Contact us for pricing" kills first conversations. The one-page offer has a Price section, and it sits next to the Pilot and proof section. *(Lesson: "The one-outcome offer", module "Your offer")*
6. **Test the build first.** Before you show the clinic anything, import the missed-call text-back template into n8n and test it with your own phone. *(Lesson: "Build: missed-call text-back", module "Build")*

After client 3, the ladder moves up. Clients 4 to 10 pay 1,000 to 2,500 setup and 500 to 900 a month.

You can watch the full lessons here: https://example.com/northwind-agency-lab/classroom
