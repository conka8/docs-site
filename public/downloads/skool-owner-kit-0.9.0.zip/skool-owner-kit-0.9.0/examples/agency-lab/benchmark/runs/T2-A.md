# T2-A

> Actual model execution, unedited. Claude Code subagent, model alias "sonnet", 2026-10-29 18:02 UTC, about 10 s.
> Condition: General assistant, normal request (no lessons, no skill).


---
No, you don't have to register a limited company before signing your first client. In Ireland you can trade as a sole trader, and many freelancers start that way. Whether a company is worth it depends on your situation.

**Sole trader (the default if you do nothing else)**
- You register with Revenue (via ROS or form TR1) as self-employed. You should do this when you start trading, so do it before or soon after your first paid job.
- You file an annual Form 11 return and pay income tax, USC and PRSI on your profits through self-assessment. Preliminary tax is due in the year you earn.
- You can trade under your own name with no registration. If you use a different business name, you must register it with the CRO (Registration of Business Names).
- Your liability is unlimited. Your personal assets are at risk if something goes wrong.
- You need to register for VAT only if your turnover passes the threshold. The current thresholds are about €42,500 for services and about €85,000 for goods, but check Revenue's current figures. You can also register voluntarily.

**Limited company**
- It limits your liability, and some clients, especially larger ones, prefer or require it.
- It can be more tax-efficient at higher profit levels. Corporation tax is 12.5% on trading income, but getting money out as salary or dividends is taxed again.
- It costs more to run. You have CRO registration and annual returns, usually an accountant for statutory accounts, payroll set-up if you pay yourself a salary, and more admin overall.
- Some founders switch to a company later, once income is steady and there is a real tax or liability reason.

**Other points to check before signing**
- Contract and liability. Consider professional indemnity insurance, and limit your liability in the contract.
- Employment status. If you work mainly for one client, under their control and on their schedule, Revenue may treat you as an employee. Check this against the Code of Practice on Employment and Self-Employment Status.
- Client type. If you're working for a non-Irish client, VAT and invoicing rules can differ, especially for EU clients.
- Registering for Revenue and VAT is separate from forming a company, so you can sort those out regardless of structure.

**Bottom line:** Start as a sole trader if you want to move fast. Revisit a company once your profits are meaningfully above what a salary would cost you, or if the work carries real liability risk. A short chat with an Irish accountant, often free or cheap for a first meeting, is worth it before you decide. Rules and thresholds change, so check Revenue.ie and the CRO for the current figures.

If you tell me what kind of work you do, who the client is (Irish, EU or elsewhere), and roughly what you expect to earn, I can be more specific.
