# T2-B

> Actual model execution, unedited. Claude Code subagent, model alias "sonnet", 2026-10-29 18:02 UTC, about 34 s.
> Condition: Same assistant, given the same lesson files and clear instructions.


---
**Short answer:** none of your 8 lessons cover company registration, legal structure, tax, contracts or insurance, so I can't say what the course's rule is. Everything below the next section is my own general knowledge, not course material. Please check it with an Irish accountant or Revenue before you act on it.

**What the lessons do say (relevant context only)**
- "Your first 14 days" sets your First win as two things: post your one-page offer in Wins, and send 20 outreach messages. Neither needs a legal entity. It also says you don't need a website, logo or finished automation to start.
- "Pricing your first offer" covers setup fee plus monthly fee, and says amounts are in your local currency. It says nothing about invoicing, VAT or entity type.
- "The discovery call" ends with proposing the 30-day pilot from your offer page. It doesn't mention contracts or paperwork. For the "Pilot and proof" section of the one-page offer ("The one-outcome offer"), it only says to agree one success metric up front.

**What I'm adding (not in the lessons)**
- In Ireland you don't have to form a limited company to take a client. You can trade as a sole trader. You must register with Revenue for income tax when you start earning, using the sole trader registration (Form TR1). I'm confident about this part.
- If you trade under a name that isn't your own legal name, you may also need to register that business name with the Companies Registration Office (CRO).
- A limited company is optional. It gives you limited liability and can suit you tax-wise once profits are higher. It also brings extra cost and admin: CRO filings, annual returns, accounts and corporation tax. Whether it's worth it depends on your income and your situation, so an accountant should confirm.
- VAT registration is only compulsory above a turnover threshold (roughly €40,000 to €42,500 a year for services). I'm not certain of the current figure, so check it on revenue.ie.
- Your service sends texts to callers' phones, so data protection (GDPR) and e-privacy rules matter. That's another thing none of the lessons cover. A short written agreement and liability or professional indemnity insurance are also worth asking an adviser about.

**What I'd need from you to be more specific**
1. Do you have a day job or an employment contract that restricts side work?
2. Roughly how much do you expect to earn from the first 3 clients? The lessons' founding-client range is 300 to 500 a month plus a 500 to 1,000 setup fee.
3. Will your clients be in Ireland, the UK or elsewhere?
4. Do you already have a sole trader registration or an accountant?

**Does your question go against the lessons?** No. It's simply outside them. If the community has a legal or finance channel, or a coach you can tag, the "Where to get help" section of "Your first 14 days" says to ask in Help and tag a coach if nobody answers within a day. They may have a course-specific answer.
