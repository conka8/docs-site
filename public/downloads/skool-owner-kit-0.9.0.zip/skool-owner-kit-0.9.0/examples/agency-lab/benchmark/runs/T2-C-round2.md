# T2-C-round2

> Actual model execution, unedited. Claude Code subagent, model alias "sonnet", 2026-10-29 18:10 UTC, about 23 s.
> Condition: Packaged member skill (installed copy of the shipped pack).
> Pack after fixes 1-2 (draft with [brackets] when filters are unknown; tag a coach only after a day), made after the blind grading; not graded blind.

---
This isn't covered in the classroom yet. I checked the lessons and none of them say anything about business structure, registering a company, tax or contracts. The closest ones are "Your first 14 days" and "Pricing your first offer", and they only cover getting your offer posted, sending outreach and setting prices. They don't say whether you need to be registered before you sign a client.

*(Lessons checked: "Your first 14 days", module "Start here"; "Pricing your first offer", module "Your offer")*

What the course does say is that your first goal is to post your one-page offer and send 20 outreach messages, and that you don't need a website, logo or finished automation to start. Watch the full lessons here: https://example.com/northwind-agency-lab/classroom

**My own suggestion, not from the lessons:** in Ireland you don't have to form a limited company before taking your first client. Many people start as a sole trader, which means registering with Revenue (the Irish tax authority) for self-employment. A limited company gives you limited liability and can suit you later, but it adds costs and paperwork. The right choice depends on your tax situation, your liability risk and whether you have other income. Before you sign anyone, check with an Irish accountant or Revenue, or Local Enterprise Office if you want free guidance, and confirm the current rules yourself.

If you'd like a coach or another member to weigh in, post this in the Help channel and tag a coach if nobody answers within a day:

> Hi all, I'm based in Ireland and about to sign my first client. Do I need to register a limited company first, or can I start as a sole trader? I'm working on my first offer and checked "Your first 14 days" and "Pricing your first offer", but neither covers business setup. Has anyone here in Ireland done this?
