# T2-C

> Actual model execution, unedited. Claude Code subagent, model alias "sonnet", 2026-10-29 18:02 UTC, about 27 s.
> Condition: Packaged member skill (installed copy of the shipped pack).


---
This isn't covered in the classroom yet. None of the 8 lessons deal with company registration, tax or legal setup. The closest are "Your first 14 days" and "Pricing your first offer". Neither says you need a company before your first client, and the First win plan (post your offer, send 20 messages) doesn't depend on it.

**My own suggestion, not from the lessons**

- In Ireland you generally don't have to form a limited company to take a first client. Many people start as a sole trader and incorporate later.
- A sole trader normally registers with Revenue for income tax, through myAccount or ROS. This is usually done when you start trading, so check the timing with Revenue or an accountant.
- If you trade under a name other than your own, you may also need to register that business name with the Companies Registration Office (CRO).
- The trade-offs are limited liability and credibility on one side, and setup and ongoing admin costs on the other. A limited company also has annual filing obligations. An accountant can tell you which suits your income and risk.
- VAT registration depends on your turnover thresholds, so ask about that as well.

I'm not a tax or legal adviser, so please confirm this with an Irish accountant or the Revenue and CRO websites before you sign anyone.

You can still work on your offer while you sort this out. See *(Lesson: "Pricing your first offer", module "Your offer")* and *(Lesson: "Your first 14 days", module "Start here")*. You can watch the full lessons here: https://example.com/northwind-agency-lab/classroom

**Message to post in the Help channel (tag a coach)**

> Hi @coach, I'm based in Ireland and about to sign my first client. Do I need to register as a limited company first, or can I start as a sole trader? I'm working on my one-page offer and pricing. I checked "Your first 14 days" and "Pricing your first offer", but neither covers company or tax setup. Has anyone in Ireland done this, or can you point me to a resource?
