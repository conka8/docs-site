# T3-A

> Actual model execution, unedited. Claude Code subagent, model alias "sonnet", 2026-10-29 18:02 UTC, about 13 s.
> Condition: General assistant, normal request (no lessons, no skill).


---
Chase 2 to 3 times after the original message, then stop. A Loom open isn't interest. It often means they clicked, got busy, and forgot.

Timing, counting from when you sent the Loom:
1. Follow-up 1: 2 to 3 business days later. Keep it short and put one easy question in it, like "Worth a quick call this week, or is this not a priority?"
2. Follow-up 2: 4 to 5 days after that. Add something new, like a relevant result, a small tweak to the offer, or a different angle. Don't just write "bumping this."
3. Follow-up 3 (the last one): about a week later. Make it a polite close-out: "I'll assume the timing's off and won't keep pinging. If it comes up later, I'm happy to help."

That's about 3 weeks in total. After that, leave it alone for 2 to 3 months, then reach out again with something new.

Tips:
- Don't say "I saw you opened my video." It feels like surveillance and puts people off.
- Make each message different and keep it to 2 or 3 lines. If you can, switch channel for one of them, for example email, then LinkedIn or X.
- Send on Tuesday to Thursday mornings in their time zone.
- A reply of "not now" or "no" counts as an answer. Stop chasing and thank them.

Because you're in Tokyo and they're probably in the US, send things so they land in their morning. That means evening or night for you.
