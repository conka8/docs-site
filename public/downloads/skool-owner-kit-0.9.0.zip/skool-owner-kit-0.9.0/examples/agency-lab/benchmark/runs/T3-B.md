# T3-B

> Actual model execution, unedited. Claude Code subagent, model alias "sonnet", 2026-10-29 18:02 UTC, about 37 s.
> Condition: Same assistant, given the same lesson files and clear instructions.


---
**Short answer:** chase them twice, never three times. Both follow-ups count from the day you sent the first Loom message (Day 0).

**The schedule (from "The follow-up cadence", 03-outreach)**

| Day | What to send |
|---|---|
| 0 | Your original 3-line Loom message |
| 3 | Follow-up 1: one new angle, either a different observation or a short result from another niche. Keep the same ask. |
| 7 | Follow-up 2: a polite close, such as "Should I close your file?". The lesson says this one gets the most replies. |

After Day 7, stop. The lesson says "Never send a third follow-up."

**Format of the follow-ups (from "The 3-line Loom script", 03-outreach)**
These rules are written for the first message. They don't say whether they apply to follow-ups, so treat the points below as my reading rather than the lesson's wording.
- Don't start with "I" or your company name. Start with them.
- Include no prices, no attachments, and no links except the Loom.
- If you can't find a new real observation for Follow-up 1, the cadence also allows a short result from another niche.

**Tracking (from "The follow-up cadence")**
Log the Day 3 and Day 7 dates in your sheet. The columns are Business, Contact, Observation, Day 0 sent, Day 3 sent, Day 7 sent, Reply, Call booked.

**Does the "opened" status change anything?**
The lessons don't say. They give one cadence and don't treat opened-but-silent leads differently. So don't add an extra chase, and don't mention that you saw they opened it. That tactic isn't in the lessons.

**Not covered by the lessons**
- The time of day to send.
- Which channel to use for the follow-ups.
- What to do with a lead after you've closed their file.

Nothing you asked goes against the lessons.

**Questions for you**
1. What day did you send the original message? That tells me whether you're due for Follow-up 1 (Day 3), Follow-up 2 (Day 7), or are already finished.
2. Have you already sent any follow-ups to this person? If you've sent two, you're done with them.
3. If you're due for Follow-up 1, do you have a new observation or a short result from another niche? If you paste your original message and what you know about their business, I can draft the follow-up in the lesson's format.
