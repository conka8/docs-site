# T3-C

> Actual model execution, unedited. Claude Code subagent, model alias "sonnet", 2026-10-29 18:02 UTC, about 24 s.
> Condition: Packaged member skill (installed copy of the shipped pack).


---
Send exactly two follow-ups, then stop. Never send a third.

- **Day 0:** your Loom message goes out.
- **Day 3:** Follow-up 1. Give them one new angle, either a different observation about their business or a short result from another niche. Keep the same ask as your first message.
- **Day 7:** Follow-up 2. Make it a polite close, such as "Should I close your file?" The course says this message gets the most replies.

After Day 7, leave that prospect alone. The day counts run from the day your first message went out, not from the day they opened the Loom.

Tip: keep one sheet with the columns Business, Contact, Observation, Day 0 sent, Day 3 sent, Day 7 sent, Reply and Call booked. That way you always know which follow-up is due.

*(Lesson: "The follow-up cadence", module "Outreach"; the Loom message itself is in "The 3-line Loom script", module "Outreach")*

You can watch the full lessons here: https://example.com/northwind-agency-lab/classroom
