# Pick a niche with the 3-filter test

Don't pick a niche because it sounds exciting. Pick one that passes all three filters:

1. **Money leak:** the business loses real money when a lead goes unanswered (a missed call, a slow reply,
   a no-show). Dental clinics, roofers, med spas, HVAC and law firms pass. Most restaurants don't: margins are thin
   and a missed call is a lost $20 order, not a $2,000 job.
2. **Already pays for software:** they already pay for a booking system, a CRM or a phone system. Businesses that
   pay for software understand paying monthly for a result.
3. **Reachable this week:** you can find 50 of them in one city or region in under an hour (Google Maps,
   a directory, your own network).

Score each niche you're considering: 1 point per filter. Only pick a niche that scores 3/3.
If two niches score 3/3, pick the one where you already know someone or speak their language.

## Common mistakes

- "Small businesses" is not a niche. "Dental clinics in Leeds" is.
- Enterprise companies fail filter 3: you can't reach 50 decision makers this week.
- Switching niche every week. Commit for 30 days.
