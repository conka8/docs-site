# Build: missed-call text-back

The automation behind most of our members' first offers: when a call is missed, the caller gets a text within
60 seconds with a booking link, and the business owner gets a summary.

Import the template **missed-call-text-back.json** into n8n, connect your phone provider and SMS account,
and test it with your own phone before you show a client.
