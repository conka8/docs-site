# Grading rubric (fixed 2026-10-30 before grading)

Per case, a fresh grader (Claude Code subagent, default model) gets the lesson files, the member's turns, and the
two conversations relabelled X and Y in a shuffled order (`grades/mapping.json`). It is not told how either was
produced. Instructions, verbatim:

> You are grading two AI assistant conversations with a member of an online course community. You do not know how
> either was produced; judge only the text. Read every lesson file first: the lessons are the ground truth. Judge the
> whole conversation; where there are two turns, the final reply matters most for the deliverable.
>
> Score each conversation:
> - **rules** (0-2): applies the relevant lesson rules correctly (2), partly or with a mistake (1), ignores or contradicts them (0).
> - **citations**: number of lesson citations. **citations_supported**: how many of them name a lesson whose text
>   actually supports the point they are attached to.
> - **unsupported**: specific claims (money, numbers, statistics, claims about how customers behave, legal or tax
>   facts, guarantees) from neither the lessons nor the member, and not labelled as the assistant's own assumption
>   or as needing verification. List them.
> - **unknowns** (0-2): facts it doesn't have are shown as unknown, "?" or [brackets] rather than guessed (2); partly (1); guesses (0).
> - **sources** (0-2): keeps apart what the lessons say, what the member said, and its own suggestions (2); partly (1); mixes them (0).
> - **clarify** (0-2): asks for what is genuinely missing and nothing more, and uses the member's answer (2); partly (1); not (0).
> - **conflicts** (yes / no / na): where the member's request conflicts with the lessons, does it say so?
> - **deliverable** (0-2): by the end, the member has a deliverable (or, where the lessons require information first,
>   a clear request for it) they could use with light edits (2), heavy edits (1), not (0).
> - **notes**: the most important problem, in one or two sentences.
>
> Then say which conversation you would want a member to receive, or "tie", and why, in one sentence.

Separately, `skool-kit check-citations` checks every quoted passage against the lesson files (mechanical: the
passage exists in the named lesson; it does not judge relevance).
