# H1-K

> Actual model execution, unedited. Claude Code subagent, model `claude-sonnet-5-5` (alias "sonnet"), started 2026-10-30 00:55 UTC.
> Condition: Skill kit: the 3 installed skills (member kit 1.0.1); the model chose the skill from names and descriptions.

## Turn 1

**Member:** a guy in another group said you should always send 4 follow-ups, so I'm planning day 2, 4, 6 and 10. that ok?

*Skill it said it used: `northwind-outreach-sprint`. About 13 s. Commands it ran: `cd member-home/.claude/skills/; ls -R .; cat northwind-outreach-sprint/SKILL.md`; `cd member-home/.claude/skills/northwind-outreach-sprint/references/outreach; cat the-follow-up-cadence.md`*

**Reply:**

Not quite. The Northwind lesson on the follow-up cadence says to send exactly two follow-ups, not four.

- **Day 0:** your first 3-line Loom message.
- **Day 3:** Follow-up 1. Give one new angle, either a different observation or a short result from another niche, and repeat the same ask.
- **Day 7:** Follow-up 2. Send a polite close, like "Should I close your file?". The lesson says this one gets the most replies.

Then stop. The lesson says: "Then stop. Never send a third follow-up." It also says: "Most replies come from follow-ups. Send exactly two." (Lesson: "The follow-up cadence")

Your plan of day 2, 4, 6 and 10 conflicts with the lesson in two ways. It sends four follow-ups where the lesson says two. It also doesn't include the polite close on day 7, which is the message that gets the most replies. I'd switch to day 3 and day 7. The advice from the guy in the other group isn't from the lessons, and the classroom doesn't say why more would work better.

If you share your offer headline and up to 10 businesses, each with one specific thing you noticed on their site or in their reviews, I'll write the Day 0 messages, both follow-ups, and the tracking sheet for you.
