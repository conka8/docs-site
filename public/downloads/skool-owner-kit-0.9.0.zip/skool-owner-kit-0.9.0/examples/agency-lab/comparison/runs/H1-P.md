# H1-P

> Actual model execution, unedited. Claude Code subagent, model `claude-sonnet-5-5` (alias "sonnet"), started 2026-10-30 00:55 UTC.
> Condition: Claude Project: project instructions + the project's files (project kit 1.0.1).

## Turn 1

**Member:** a guy in another group said you should always send 4 follow-ups, so I'm planning day 2, 4, 6 and 10. that ok?

*Guide it said it used: `task-northwind-tutor.md`. About 16 s. Commands it ran: `ls share/northwind-claude-project-1.0.1/knowledge`; `cd share/northwind-claude-project-1.0.1/knowledge; cat task-northwind-tutor.md the-follow-up-cadence.md`; `cd share/northwind-claude-project-1.0.1/knowledge; cat task-northwind-outreach-sprint.md`*

**Reply:**

Not quite. The lessons say to send two follow-ups, not four, and on different days than the ones you picked.

- **How many:** *(Lesson: "The follow-up cadence": "Send exactly two.")*
- **When to stop:** *(Lesson: "The follow-up cadence": "Then stop. Never send a third follow-up.")*
- **Why follow up at all:** *(Lesson: "The follow-up cadence": "Most replies come from follow-ups.")*

Your plan has four follow-ups, so it breaks the "never send a third" rule. The lesson's schedule looks like this:

| Day | Message |
|---|---|
| 0 | The 3-line Loom message |
| 3 | Follow-up 1: one new angle (a different observation or a short result from another niche), same ask |
| 7 | Follow-up 2: a polite close ("Should I close your file?"). This one gets the most replies |

The lesson says Follow-up 2, the polite close, "gets the most replies".

The lessons don't say anything about why the other group sends four, or about days 2, 4, 6 and 10. I can't say whether four works for them. For your own outreach, follow the lesson: Day 0, Day 3, Day 7, then stop.

If you want to put this in your tracking sheet, the lesson's columns are: Business, Contact, Observation, Day 0 sent, Day 3 sent, Day 7 sent, Reply, Call booked.

You can watch the full lesson here: https://example.com/northwind-agency-lab/classroom

If you'd like me to write your Day 0 message and both follow-ups, send me your offer headline. Also send up to 10 businesses, each with one specific thing you noticed about them.
