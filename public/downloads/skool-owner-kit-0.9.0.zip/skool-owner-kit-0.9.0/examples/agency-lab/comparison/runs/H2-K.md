# H2-K

> Actual model execution, unedited. Claude Code subagent, model `claude-sonnet-5-5` (alias "sonnet"), started 2026-10-30 00:55 UTC.
> Condition: Skill kit: the 3 installed skills (member kit 1.0.1); the model chose the skill from names and descriptions.

## Turn 1

**Member:** can you help me make my offer? I do AI receptionist stuff

*Skill it said it used: `northwind-offer-builder`. About 14 s. Commands it ran: `member-home/.claude/skills/northwind-offer-builder/SKILL.md`; `cd member-home/.claude/skills/northwind-offer-builder/references/your-offer/ && cat pick-a-niche-with-the-3-filter-test.md the-one-outcome-o`*

**Reply:**

Happy to. An AI receptionist is a good fit for this method, because a missed call or slow reply is exactly where the lessons say money leaks. I need three things from you before I write the page. "AI receptionist" is too broad as an offer, because the method sells one outcome to one niche.

1. **Which 1 to 3 niches are you considering?** For example dental clinics, roofers or med spas. The lessons name dental clinics, roofers, med spas, HVAC and law firms as passing the money-leak filter. They say most restaurants don't, because "a missed call is a lost $20 order, not a $2,000 job". If a restaurant is on your list, tell me and I'll flag it.
2. **Which city or region will you sell in?** Your niche has to be reachable this week, meaning you can find 50 of them there in under an hour.
3. **What can you set up for a client today?** For example answering calls, texting back missed calls, booking appointments, or answering the website chat. Say what you've actually built or can deliver, not what you could build someday.

Once I have those, I'll:
- score each niche on the 3-filter test, and only pick one that scores 3/3;
- write the headline and the one-page offer, under 400 words;
- set your founding-client price: a setup fee plus a monthly fee, shown on the page;
- build in a 30-day pilot with one success metric you agree with the client up front.

I can't promise a client revenue or results you don't control. The offer will promise things you do control, such as speed of reply and coverage.

## Turn 2

**Member:** roofers and HVAC in Phoenix. I know a couple of roofers through my dad

*Skill it said it used: `northwind-offer-builder`. About 6 s. Commands it ran: none*

**Reply:**

Roofers and HVAC in Phoenix both look like good candidates. The lessons list roofers and HVAC as passing the money-leak filter. They also say that if two niches score 3/3, you should pick the one where you already know someone, and you know roofers through your dad. So roofers is my likely pick, but I'll score both properly once I have the last piece.

One thing I still need: **what can you set up for a client today?** For example answering calls, texting back missed calls, booking appointments, or answering the website chat. Name what you've actually built or can deliver now.

After that I'll write the full offer. Two of the three filters need your confirmation, so I'll mark the niche check "pending" until you give it. The lessons don't show these either way, and you haven't told me yet:
- whether roofers in Phoenix already pay for software such as a CRM, booking or phone system;
- whether you can find 50 of them in Phoenix in under an hour.

## Turn 3

**Member:** it answers calls after hours and texts back missed calls, built on Retell and n8n. it can book into Google Calendar

*Skill it said it used: `northwind-offer-builder`. About 26 s. Commands it ran: none*

**Reply:**

## Niche check
Status: **pending** (needs 2 confirmations from you).

| Niche | Money leak | Already pays for software | Reachable this week | Score |
|---|---|---|---|---|
| Roofers, Phoenix | 1 | ? | ? | 1/3 confirmed |
| HVAC, Phoenix | 1 | ? | ? | 1/3 confirmed |

- Money leak: *(Lesson: "Pick a niche with the 3-filter test": "Dental clinics, roofers, med spas, HVAC and law firms pass.")*
- Chosen niche: roofers. *(Lesson: "Pick a niche with the 3-filter test": "If two niches score 3/3, pick the one where you already know someone or speak their language.")* You said you know a couple of roofers through your dad.
- The lessons don't tell me whether Phoenix roofers pay for software, and you haven't said. I also can't tell whether you can find 50 of them in under an hour. Please confirm both before you post.

## Headline
**We reply to every missed and after-hours call within [60 seconds] for roofers in Phoenix, without hiring a receptionist.**

*(Lesson: "The one-outcome offer": "We [measurable outcome] for [niche] in [timeframe], without [the pain they hate].")*
It has no tool names. *(Lesson: "The one-outcome offer": "No tool names (no 'n8n', 'GPT', 'Claude'). Clients buy outcomes.")* It promises speed and coverage, which you control. *(Lesson: "The one-outcome offer": "Promise the thing you control (speed, volume, coverage), not their sales.")*

## Who it's for
Phoenix roofing companies [size: ? e.g. owner-run crews of 3 to 15 people, confirm] that miss calls while they're on a roof or after hours.

## The problem
Calls that come in after hours or while the crew is on a job go unanswered, and the caller rings the next roofer. [Add what a lost job costs them, in their words, after you talk to your dad's contacts.]

## How it works
1. A call comes in after hours, or you miss it.
2. The caller gets an immediate answer or text, and we collect their name, address and what they need.
3. If they want an inspection, we book it straight into your calendar and you get a summary.

## What's included
- Setup of the after-hours call answering, missed-call text-back and calendar booking.
- A monthly check-in to review the calls and adjust.

## Price
**$1,000 setup + $500 a month** (founding client price).

- Why this point: this is the top of the founding range. *(Lesson: "Pricing your first offer": "Use the higher end when one recovered lead is worth a lot to the client (a dental implant, a roof, a legal case).")*
- It is a founding-client price, so it comes with a testimonial and the pilot. *(Lesson: "Pricing your first offer": "Founding clients get the lower price in exchange for a testimonial and a 30-day pilot with an agreed metric.")*
- The price goes on the page. *(Lesson: "Pricing your first offer": "Write the price on the offer page.")*

## Pilot and proof
A 30-day pilot with one success metric we agree up front. My suggestion, not from the lessons: after-hours and missed calls answered within [60 seconds]. No guaranteed revenue or results.

## What I need from you
Phone system access, one contact person, and 30 minutes for setup.

## Check
- Required headings present: pass.
- Check, Gaps and assumptions, and Next step present: pass.
- Niche check: pending, because the 2 "?" filters are listed for you to confirm. I did not mark it as a pass.
- No guarantee of results: pass.
- Under 6,000 characters: pass.
- Recommendations cite the lessons: pass.
- Every number comes from the lessons or from you: pass. The unverified items are under Gaps and assumptions.

## Gaps and assumptions
- **Filters 2 and 3 are unconfirmed.** Confirm that roofers in Phoenix already pay for software, and that you can find 50 of them in under an hour.
- **Verify before use:** "60 seconds" is the lesson's example. Confirm your setup really replies that fast.
- **Currency assumed:** I assumed USD because you're selling in Phoenix.
- **Business size and cost of a lost job** are unknown. They are in [brackets].
- I left out the tool names and the calendar product name, because the lessons say clients buy outcomes.
- **Conflicts with the lessons:** none.

## Next step
Confirm the two filters above, then post the offer in Wins today with "#firstwin", then start the outreach-sprint skill.
