# H2-P

> Actual model execution, unedited. Claude Code subagent, model `claude-sonnet-5-5` (alias "sonnet"), started 2026-10-30 00:55 UTC.
> Condition: Claude Project: project instructions + the project's files (project kit 1.0.1).

## Turn 1

**Member:** can you help me make my offer? I do AI receptionist stuff

*Guide it said it used: `task-northwind-offer-builder.md`. About 13 s. Commands it ran: `ls share/northwind-claude-project-1.0.1/knowledge; cat share/northwind-claude-project-1.0.1/knowledge/task-northwind-offer-builder.md`; `cd share/northwind-claude-project-1.0.1/knowledge; cat pick-a-niche-with-the-3-filter-test.md the-one-outcome-offer.md pricing-your-first-of`*

**Reply:**

Your offer is a one-page document: niche check, headline, price and a 30-day pilot, ready to post in Wins. I can't write it yet because I need three things from you:

1. Which 1 to 3 niches are you considering? For example, dental clinics or roofers.
2. Which city or region will you sell in?
3. What exactly can you set up for a client today? Does your AI receptionist answer calls, text back missed calls or book appointments? What does it run on, and does it connect to a booking system?

One note first. "AI receptionist" describes a tool, and the offer has to sell an outcome. The lesson says: *(Lesson: "The one-outcome offer": "Sell one outcome to one niche. Not a tool, not 'AI automation'.")* So we'll turn it into something clients can count, such as missed calls answered or bookings made.

Once I have your answers, I'll score your niches and write the offer.

## Turn 2

**Member:** roofers and HVAC in Phoenix. I know a couple of roofers through my dad

*Guide it said it used: `task-northwind-offer-builder.md`. About 7 s. Commands it ran: none*

**Reply:**

Thanks. Roofers and HVAC are both on the lesson's list for the first filter. *(Lesson: "Pick a niche with the 3-filter test": "Dental clinics, roofers, med spas, HVAC and law firms pass.")* I'll score the other two filters in the draft. Your contact through your dad helps with the tie-break: *(Lesson: "Pick a niche with the 3-filter test": "If two niches score 3/3, pick the one where you already know someone or speak their language.")*

I still need one thing before I can write it. You didn't say what your AI receptionist actually does for a client today. Which of these is it?

- Answers inbound calls live
- Texts back missed calls
- Books appointments
- Something else

Also tell me what it runs on and whether it connects to a booking system or CRM. The offer can only promise what you can set up.

## Turn 3

**Member:** it answers calls after hours and texts back missed calls, built on Retell and n8n. it can book into Google Calendar

*Guide it said it used: `task-northwind-offer-builder.md`. About 26 s. Commands it ran: `cd share/northwind-claude-project-1.0.1/knowledge; cat build-missed-call-text-back.md northwind-offer-builder-example-output.md`*

**Reply:**

## Niche check

Scored with *(Lesson: "Pick a niche with the 3-filter test": "Score each niche you're considering: 1 point per filter. Only pick a niche that scores 3/3.")*

| Filter | Roofers, Phoenix | HVAC, Phoenix |
|---|---|---|
| 1. Money leak | 1. The lesson names roofers as a pass. | 1. The lesson names HVAC as a pass. |
| 2. Already pays for software | ? Not stated in the lessons or by you. | ? Same. |
| 3. Reachable this week | ? You know a couple of roofers, but the test needs 50 findable in under an hour. | ? Same. |
| **Score** | **1/3 confirmed, 2 pending** | **1/3 confirmed, 2 pending** |

Neither niche is confirmed yet. I wrote the draft for roofers because the lesson says: *(Lesson: "Pick a niche with the 3-filter test": "If two niches score 3/3, pick the one where you already know someone or speak their language.")* The niche check stays **pending** until you confirm filters 2 and 3 (see Gaps). Commit to one niche for 30 days.

## Headline

We reply to every missed or after-hours call within 60 seconds for roofers in Phoenix, without hiring a receptionist. *(Lesson: "The one-outcome offer": "We [measurable outcome] for [niche] in [timeframe], without [the pain they hate].")*

It has one niche and one countable outcome. It names no tools and promises nothing about their revenue.

## Who it's for

Roofing companies in Phoenix that miss calls when crews are on a roof or the office is closed, and that already use a phone or booking system. [Confirm the size of business you're targeting.]

## The problem

When a call goes unanswered after hours or while the team is busy, the caller may ring the next roofer. [Replace this with what Phoenix roofers actually say to you.]

## How it works

1. Someone calls and nobody can pick up, or it's after hours.
2. The call is answered or the caller gets a text within 60 seconds, and a booking is offered.
3. You get a summary and the appointment lands in your calendar.

## What's included

- Setup on your business number
- After-hours call answering and missed-call text-back, running every month
- A monthly check-in

## Price

**Founding client offer: $1,000 setup + $500 a month.** *(Lesson: "Pricing your first offer": "Use the higher end when one recovered lead is worth a lot to the client (a dental implant, a roof, a legal case).")*

I chose the top of the range because a roof is the lesson's own example of a high-value lead. The founding-client range is 500 to 1,000 setup and 300 to 500 a month. Founding clients get this price in exchange for a testimonial and the pilot below. *(Lesson: "Pricing your first offer": "Never go below 300 a month.")*

## Pilot and proof

A 30-day pilot with one metric agreed up front. My suggestion, not from the lessons: the share of missed and after-hours calls that get a reply within 60 seconds. This is speed and coverage, which you control. Nothing here promises revenue.

## What I need from you

- Access to your phone system or number settings
- One contact person
- 30 minutes for setup

## Check

- Required headings present: pass
- Check, Gaps and assumptions, and Next step present: pass
- Niche check: pending, with the "?" filters listed
- No guarantee of results: pass
- At most 6000 characters: pass
- Cites the lessons, nothing invented: pass
- Money and behaviour claims sourced or listed under Gaps: pass

## Gaps and assumptions

- **Verify before use, filter 2:** Confirm that Phoenix roofers already pay for a phone, CRM or booking system. The lessons don't say so.
- **Verify before use, filter 3:** Check that you can find 50 roofers in Phoenix in under an hour (Google Maps, a directory). If not, roofers fail and we switch to HVAC.
- **Verify before use:** The idea that callers ring the next roofer is my wording, not from the lessons.
- **Assumed currency:** US dollars, since you're in Phoenix. The lessons say "local currency".
- **Tool names:** I left out Retell, n8n and Google Calendar, because the headline rule is "No tool names". You can still deliver everything described.
- **60-second reply:** The figure comes from the lesson's example headline. Confirm that your setup meets it for both text-back and after-hours calls.

## Next step

Confirm filters 2 and 3 for roofers. Then post the offer in Wins today with "#firstwin", and start the outreach-sprint skill.

## Question for a coach

If you want a coach to check the "pending" filters, post this in the Help channel:

"I'm working on my one-page offer, using 'Pick a niche with the 3-filter test'. I've picked roofers in Phoenix, with HVAC as the backup. I'm unsure about filters 2 and 3: do roofers there already pay for software, and is a couple of contacts enough to count as reachable? How would you verify both before I post?"
