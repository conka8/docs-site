# H3-K

> Actual model execution, unedited. Claude Code subagent, model `claude-sonnet-5-5` (alias "sonnet"), started 2026-10-30 00:55 UTC.
> Condition: Skill kit: the 3 installed skills (member kit 1.0.1); the model chose the skill from names and descriptions.

## Turn 1

**Member:** do I need a contract with my first client or is the pilot thing enough? what should be in it

*Skill it said it used: `northwind-tutor`. About 23 s. Commands it ran: `member-home/.claude/skills/northwind-tutor/SKILL.md`; `cd member-home/.claude/skills/northwind-tutor/references && ls -R && grep -ril -E "contract|pilot|agreement" .`; `cd member-home/.claude/skills/northwind-tutor/references && cat your-offer/pricing-your-first-offer.md your-offer/the-one-outcome-offer.md o`*

**Reply:**

**Short answer:** The pilot isn't a contract. It's the trial period and the success metric. The lessons never say whether you need a written agreement, so below I separate what they say from my own suggestions.

**What the lessons say about the pilot**
- The pilot is a 30-day trial with one success metric you agree up front. *(Lesson: "The one-outcome offer": "**Pilot and proof**: a 30-day pilot with one success metric you agree up front")*
- Founding clients get the lower price in return for a testimonial and the pilot. *(Lesson: "Pricing your first offer": "Founding clients get the lower price in exchange for a testimonial and a 30-day pilot with an agreed metric.")*
- On refunds, the lessons say: *(Lesson: "Pricing your first offer": "No refunds promised on results you don't control. Offer the pilot instead.")*
- The offer page also lists what you need from the client. *(Lesson: "The one-outcome offer": "**What I need from you**: logins, a contact person, 30 minutes for setup")*

**This isn't covered in the classroom yet.** That includes whether you need a contract and what goes in it.

**My suggestion, not from the lessons:** Yes, put it in writing, even if it's one or two pages. You'll have logins to their systems, you'll message their customers, and you'll take a monthly fee. A verbal "let's try it" leaves too much open. A simple agreement should cover:
1. **Scope:** the one outcome you're delivering and what's not included.
2. **Pilot:** 30 days, with the agreed metric written down and how you'll measure it.
3. **Price and payment:** setup fee, monthly fee, when invoices are due, and what happens after the pilot (continue, or stop).
4. **Access and data:** which logins you need, who their contact person is, and that you'll only use their data to do the work.
5. **No result guarantees:** you commit to the things you control (speed, coverage), not their revenue.
6. **Testimonial:** if they get the founding-client price for one, write it in.
7. **Ending it:** how either side can stop, and the notice period.
8. **Liability:** a cap on it. If you message their customers, check the local rules on texting and consent.

Have a lawyer or a template service check it. The right terms depend on your country and theirs, and I don't know where you or your client are. If you tell me, I can tailor the list.

**Post this in the Help channel** (tag a coach if nobody answers within a day):
> Question: Do I need a written contract with my first client on top of the 30-day pilot, and what should it include? I'm working on my first founding client and checked "Pricing your first offer" and "The one-outcome offer", which cover the pilot but not contracts.

Full lessons: https://example.com/northwind-agency-lab/classroom
