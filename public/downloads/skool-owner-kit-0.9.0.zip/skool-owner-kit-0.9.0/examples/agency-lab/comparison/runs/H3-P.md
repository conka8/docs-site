# H3-P

> Actual model execution, unedited. Claude Code subagent, model `claude-sonnet-5-5` (alias "sonnet"), started 2026-10-30 00:55 UTC.
> Condition: Claude Project: project instructions + the project's files (project kit 1.0.1).

## Turn 1

**Member:** do I need a contract with my first client or is the pilot thing enough? what should be in it

*Guide it said it used: `task-northwind-tutor.md`. About 24 s. Commands it ran: `ls -R share/northwind-claude-project-1.0.1/knowledge`; `cd share/northwind-claude-project-1.0.1/knowledge; cat task-northwind-tutor.md; grep -il -E "contract|agreement|pilot|terms" *.md`; `cd share/northwind-claude-project-1.0.1/knowledge; cat pricing-your-first-offer.md the-discovery-call.md the-one-outcome-offer.md; grep -n -`*

**Reply:**

**Short answer:** the lessons don't say whether you need a contract. This isn't covered in the classroom yet. They do cover the pilot, but only as an offer, not as a legal agreement.

**What the lessons say about the pilot**
- The pilot is part of your offer page: *(Lesson: "The one-outcome offer": "**Pilot and proof**: a 30-day pilot with one success metric you agree up front")*
- Founding clients get it in exchange for proof: *(Lesson: "Pricing your first offer": "Founding clients get the lower price in exchange for a testimonial and a 30-day pilot with an agreed metric.")*
- You don't promise results you can't control: *(Lesson: "Pricing your first offer": "No refunds promised on results you don't control. Offer the pilot instead.")*
- You propose the pilot on the discovery call: *(Lesson: "The discovery call": "Then propose the 30-day pilot from your offer page. Don't send a proposal unless they ask for one.")*

So the pilot defines what you'll do, the metric and the price. The lessons never say it replaces a written agreement, and they don't say you need one.

**My suggestion, not from the lessons:** put the pilot in writing, even if it's a short one-page agreement or a confirmation email the client replies "agreed" to. A verbal pilot is where disputes start, such as "I thought that was included" or "I never agreed to pay after 30 days". I'm not a lawyer. Rules differ by country, and you'll be giving the tool access to a client's phone numbers and customer messages. For anything beyond a simple pilot, have a lawyer or a template service check it.

**What I'd put in it (my suggestion, not from the lessons)**
1. Who the two parties are, and the start and end dates of the 30-day pilot.
2. What you'll do. Copy this from your one-page offer: the one outcome and what's included.
3. The success metric you agreed up front, and how you'll both measure it.
4. The price: setup fee, monthly fee, and when invoices are due. Use the numbers from your offer page.
5. What happens on day 30: it either converts to the monthly plan or ends, and how either side can cancel.
6. What you need from them: logins, a contact person, setup time. Say that delays on their side don't extend your commitment.
7. No guaranteed results. State that you control speed, volume and coverage, not their sales.
8. Data and access. Say which accounts you can touch, that you'll only use them for this work, and that they can revoke access and you'll hand it back when you finish.
9. The testimonial, if they're a founding client at the lower price: what you're allowed to use and in what form.
10. Who owns what you built, and a liability limit. These are the parts to have a lawyer review.

**To get a coach's view on the contract side**, paste this in the Help channel. Tag a coach if nobody answers within a day.

> I'm about to start my first founding-client 30-day pilot. I checked "Pricing your first offer", "The one-outcome offer" and "The discovery call". They cover the pilot and its agreed metric but don't say whether I need a written contract or what it should include. Is there a Northwind template or recommended approach?

You can watch the full lessons here: https://example.com/northwind-agency-lab/classroom

If you tell me your country and the niche, I can draft a plain-English pilot summary from your offer page for you to review.
