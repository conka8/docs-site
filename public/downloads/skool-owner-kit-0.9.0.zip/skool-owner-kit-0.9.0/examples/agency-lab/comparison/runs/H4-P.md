# H4-P

> Actual model execution, unedited. Claude Code subagent, model `claude-sonnet-5-5` (alias "sonnet"), started 2026-10-30 00:55 UTC.
> Condition: Claude Project: project instructions + the project's files (project kit 1.0.1).

## Turn 1

**Member:** Offer: "We reply to every missed call within 60 seconds for roofers in Phoenix, without hiring a receptionist." Prospects: 1) Desert Peak Roofing - 2 Google reviews say nobody called back about a quote. 2) Sunbelt Roof Co - probably misses calls, they're a small team. 3) Canyon Roofing - their site says "call for a free estimate" and the phone went to voicemail when I tried at 2pm Tuesday. Put my price (500 setup + 300/mo) in the first message so they know it's cheap.

*Guide it said it used: `task-northwind-outreach-sprint.md`. About 31 s. Commands it ran: `cd share/northwind-claude-project-1.0.1/knowledge && ls && cat task-northwind-outreach-sprint.md`; `cd share/northwind-claude-project-1.0.1/knowledge && cat the-3-line-loom-script.md the-follow-up-cadence.md pricing-your-first-offer.md`*

**Reply:**

## Messages

**1. Desert Peak Roofing** (contact: ?)

**Day 0**
> Two of your Google reviews say nobody called back about a quote.
> Each of those is a homeowner who took their roof quote to someone else.
> I recorded a 60-second video showing how I'd fix it: [Loom link]. Worth a look?

(About 40 words.)

**Day 3 (Follow-up 1, new angle)**
> Quick follow-up for Desert Peak Roofing: [second observation, e.g. from your website or opening hours: ?].
> That's another way a quote request can go quiet before anyone answers.
> The 60-second video is here: [Loom link]. Worth a look?

**Day 7 (Follow-up 2, polite close)**
> Should I close your file?

**2. Canyon Roofing** (contact: ?)

**Day 0**
> Your website says 'call for a free estimate', and when I called at 2pm on Tuesday it went to voicemail.
> A homeowner ready to book an estimate will likely try the next roofer on the list.
> I recorded a 60-second video showing how I'd fix it: [Loom link]. Worth a look?

(About 55 words.)

**Day 3 (Follow-up 1, new angle)**
> 'Call for a free estimate' makes the phone your front door, so every unanswered call is a closed door.
> The 60-second video shows how I'd keep it open: [Loom link]. Worth a look?

**Day 7 (Follow-up 2, polite close)**
> Should I close your file?

*Before you send:* the follow-ups must be new angles, not repeats of Day 0. Send exactly these two, then stop.

## Skipped

- **Sunbelt Roof Co:** "probably misses calls, they're a small team" is a guess, not something you saw on their site or reviews. *(Lesson: "The 3-line Loom script": "If you can't find a real observation, skip that business.")* Check their reviews, site and opening hours. If you find a real observation, send me the details and I'll write their three messages.

## Tracking sheet

```csv
Business,Contact,Observation,Day 0 sent,Day 3 sent,Day 7 sent,Reply,Call booked
Desert Peak Roofing,?,2 Google reviews say nobody called back about a quote,,,,,
Canyon Roofing,?,Site says 'call for a free estimate'; phone went to voicemail at 2pm Tuesday,,,,,
```

Count outreach as "sent" only when the Day 0 message goes out. *(Lesson: "The follow-up cadence": "Count your outreach as 'sent' only when the Day 0 message went out.")*

## Check

- Contains "## Messages", "## Tracking sheet", "Day 0", "Day 3", "Day 7": pass.
- Tracking sheet has the lesson's columns: pass.
- Contains "## Check", "## Gaps and assumptions", "## Next step": pass.
- At most 12000 characters: pass.
- Recommendations follow the lessons and cite them: pass, except Desert Peak's Day 3, which has an open placeholder.
- Every number or behaviour claim comes from the lessons or from you, or is listed under Gaps and assumptions as "verify before use": pass.

## Gaps and assumptions

- **Conflict: price in the first message.** You asked me to put 500 setup + 300/mo in the first message. I left it out because the lessons rule it out. *(Lesson: "The 3-line Loom script": "No attachments, no prices, no links except the Loom.")* Your price itself is fine for a founding client. *(Lesson: "Pricing your first offer": "Clients 1-3 ('founding clients') | 500 to 1,000 | 300 to 500".)* Bring it up later, on the call and on your offer page. I can't find a lesson that tells you what to say when a prospect asks the price before a call, so ask a coach if that matters to you.
- **Contacts:** I don't have names for either business, so the Contact column is "?".
- **Cost lines (verify before use):** they claim that homeowners go to another roofer. The first is adapted from the lesson's own example ("Each missed call is a patient who books somewhere else."). The second, for Canyon, is my suggestion, not from the lessons. Neither is backed by data you gave me, so keep them soft.
- **Canyon Day 3 (my suggestion, not from the lessons):** it re-uses the website line as its new angle. If you find a different observation, use that instead.
- **Desert Peak Day 3:** you gave me only one observation, so the second one is a placeholder you need to fill. Don't send that message with the bracket still in it.
- **Loom link:** you need to record a 60-second Loom per business. Both messages assume one.
- **Canyon voicemail:** it's a single call on one day, which is a real observation. Say it plainly and don't claim they "always" miss calls.

## Next step

Record the two Loom videos and paste the links into the Day 0 messages. Send them today, mark "Day 0 sent" in the sheet, and set a reminder for Day 3. Spend 10 minutes finding a real observation for Sunbelt Roof Co.
