# T1-K

> Actual model execution, unedited. Claude Code subagent, model `claude-sonnet-5-5` (alias "sonnet"), started 2026-10-30 00:55 UTC.
> Condition: Skill kit: the 3 installed skills (member kit 1.0.1); the model chose the skill from names and descriptions.

## Turn 1

**Member:** What should I charge my first client? I'm setting up a missed-call text-back for a dental clinic.

*Skill it said it used: `northwind-offer-builder`. About 18 s. Commands it ran: `member-home/.claude/skills/northwind-offer-builder/SKILL.md`; `member-home/.claude/skills/northwind-offer-builder/references/your-offer/pricing-your-first-offer.md`; `member-home/.claude/skills/northwind-offer-builder/references/your-offer/pick-a-niche-with-the-3-filter-test.md`*

**Reply:**

For a first client, charge a setup fee plus a monthly fee. Don't charge a one-off price only.

**Founding client (clients 1-3): 500 to 1,000 setup and 300 to 500 a month.** The amounts are in your local currency. *(Lesson: "Pricing your first offer": "Price every offer as **setup fee + monthly fee**.")*

**Where to land in that range:** the lesson points you to the higher end for dental. *(Lesson: "Pricing your first offer": "Use the higher end when one recovered lead is worth a lot to the client (a dental implant, a roof, a legal case).")* One missed call from a patient who wants an implant can be worth a lot, so I'd start near 1,000 setup and 400 to 500 a month. That exact point is my suggestion, not from the lessons.

**Rules that apply:**
- Never go below 300 a month. *(Lesson: "Pricing your first offer": "Never go below 300 a month.")*
- The lower founding price comes with conditions. *(Lesson: "Pricing your first offer": "Founding clients get the lower price in exchange for a testimonial and a 30-day pilot with an agreed metric.")*
- Don't promise refunds or guaranteed results. Offer the pilot instead. *(Lesson: "Pricing your first offer": "No refunds promised on results you don't control. Offer the pilot instead.")*
- Put the price on the offer page. *(Lesson: "Pricing your first offer": "Write the price on the offer page.")*

**Niche check:** dental clinics pass the money-leak filter. *(Lesson: "Pick a niche with the 3-filter test": "Dental clinics, roofers, med spas, HVAC and law firms pass.")* I can't score the other two filters yet. They are "already pays for software" and "reachable this week", meaning you can find 50 clinics in one place in under an hour. Both are still "?".

To turn this into your full one-page offer (headline, sections, pilot), I need one thing from you:
- Which city or region will you sell in?

I'll also need you to confirm that the clinics there already pay for a booking system or phone system, and that you can find 50 of them in under an hour.
