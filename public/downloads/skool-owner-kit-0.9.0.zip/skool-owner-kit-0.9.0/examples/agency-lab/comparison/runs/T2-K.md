# T2-K

> Actual model execution, unedited. Claude Code subagent, model `claude-sonnet-5-5` (alias "sonnet"), started 2026-10-30 00:55 UTC.
> Condition: Skill kit: the 3 installed skills (member kit 1.0.1); the model chose the skill from names and descriptions.

## Turn 1

**Member:** Do I need to register as a limited company before I sign my first client? I'm based in Ireland.

*Skill it said it used: `northwind-tutor`. About 17 s. Commands it ran: `member-home/.claude/skills/northwind-tutor/SKILL.md`; `cd member-home/.claude/skills/northwind-tutor/references && grep -rniE "compan|regist|tax|legal|incorporat|LLC|invoice|contract|business" . `*

**Reply:**

Not covered by the lessons.

This isn't covered in the classroom yet. I checked the lessons, including "Your first 14 days" and "Pricing your first offer", and none of them mention company registration, tax or legal setup. What follows is general guidance and my own suggestion, not from the lessons, and it isn't legal or tax advice.

**What's generally true in Ireland (my suggestion, please verify):**
- You usually don't need a limited company before your first client. You can start as a **sole trader**, which means trading in your own name. You register with Revenue (the Irish tax authority) for self-employment, normally through myAccount/ROS, and you declare your income through your annual Form 11 return.
- You normally need to register as soon as you start trading, not once you've earned a certain amount. It's worth sorting that out around the time you sign your first client.
- A limited company is a separate legal entity. It gives you limited liability, but it also means incorporation costs, annual filings with the CRO (Companies Registration Office) and accounts. Many people begin as sole traders and incorporate later, once income or risk justifies it.
- VAT registration has its own thresholds. Check them on revenue.ie.
- A short call with an Irish accountant, or the free guidance from Revenue and your local Enterprise Office, will tell you what fits your situation. I don't know your income, other employment or plans, so I can't say which setup is best for you.

**Message to post in the Help channel** (tag a coach if nobody answers within a day):

> Question: Do I need to register as a limited company before signing my first client? I'm based in Ireland. I'm working on [your niche/offer] and about to start outreach. I checked "Your first 14 days" and "Pricing your first offer" and couldn't find anything on business registration. Has anyone here set up from Ireland, or is there guidance in the classroom?

You can keep going with the course in the meantime: https://example.com/northwind-agency-lab/classroom
