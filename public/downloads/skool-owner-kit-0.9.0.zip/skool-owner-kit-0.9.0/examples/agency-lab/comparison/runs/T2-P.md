# T2-P

> Actual model execution, unedited. Claude Code subagent, model `claude-sonnet-5-5` (alias "sonnet"), started 2026-10-30 00:55 UTC.
> Condition: Claude Project: project instructions + the project's files (project kit 1.0.1).

## Turn 1

**Member:** Do I need to register as a limited company before I sign my first client? I'm based in Ireland.

*Guide it said it used: `task-northwind-tutor.md`. About 12 s. Commands it ran: `cd share/northwind-claude-project-1.0.1/knowledge && ls && cat task-northwind-tutor.md`; `cd share/northwind-claude-project-1.0.1/knowledge && grep -inE "compan|legal|regist|tax|incorporat|LLC|contract|invoice|insurance|sole|VAT|I`*

**Reply:**

This isn't covered in the classroom yet. None of the Northwind lessons say anything about company registration, legal structure or tax, and they say nothing specific to Ireland. I can't tell you from the course whether you need a limited company before your first client.

What the lessons do say is that the early focus is on getting an offer and conversations going. *(Lesson: "Your first 14 days": "You don't need a website, a logo or a finished automation to start. You need an offer and conversations.")* That sentence is about what you need to start, and it doesn't mention legal set-up. Your first 14 days (offer posted, 20 messages sent, first calls) don't depend on this decision, so you can keep going on those while you sort it out.

Here is some general guidance, which is my suggestion, not from the lessons:
- I don't know your situation, including your current employment, your expected income and what your first client will require, and the answer depends on those.
- In Ireland, people often start as a sole trader and register with Revenue. A limited company is another route. Which one suits you depends on your circumstances.
- Check this with an accountant or with official sources such as Revenue and Enterprise Ireland / your Local Enterprise Office before you invoice anyone. I can't give you legal or tax advice.

You can post this in the Help channel (tag a coach if nobody answers within a day):

> Question: Do I need to register a limited company before signing my first client? I'm based in Ireland. I'm working on my offer and outreach (Your first 14 days). I checked the lessons, including "Your first 14 days", and found nothing on business registration or tax.

You can watch the full lessons here: https://example.com/northwind-agency-lab/classroom
