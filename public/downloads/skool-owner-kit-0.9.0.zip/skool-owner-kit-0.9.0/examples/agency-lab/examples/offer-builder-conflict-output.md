> Actual output: Claude Code run on 2026-10-29 (model alias "sonnet"), unedited. See live-runs/README.md.
> Synthetic example: invented community and businesses.

Before I build this, I need one thing from you.

**What can you set up for a client today?** For example, a missed-call text-back, a chatbot, or a booking flow. Tell me what you can actually deliver for a restaurant, because the offer has to be built around it.

You gave me restaurants in Manchester, so I'll score that niche against the 3-filter test once I have your answer. Two parts of your message conflict with the Northwind lessons, so I'll build the offer differently:

- **£150 a month:** Northwind's pricing rule is never below £300 a month. Founding clients pay £500-£1,000 setup plus £300-£500 a month. I'll price it inside that range and explain why. *(Lesson: "Pricing your first offer": "Never go below 300 a month.")*
- **Guaranteeing 20% more bookings:** You don't control that result, so the lessons don't allow a guarantee. I'll offer a 30-day pilot with one agreed metric instead. *(Lesson: "The one-outcome offer": "No guaranteed revenue. Promise the thing you control (speed, volume, coverage), not their sales.")*

Both will be noted under Gaps and assumptions in the finished offer.
