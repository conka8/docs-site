> Actual output: Claude Code run on 2026-10-29 (model alias "sonnet"), unedited. See live-runs/README.md.
> Synthetic example: invented community and businesses.

## Niche check

Scored with *(Lesson: "Pick a niche with the 3-filter test": "Score each niche you're considering: 1 point per filter. Only pick a niche that scores 3/3.")*, 1 point per filter.

| Filter | Dental clinics, Leeds | Restaurants, Leeds |
|---|---|---|
| 1. Money leak | 1. The lesson names dental clinics as a pass. | 0. The lesson says most restaurants fail: thin margins, and a missed call is a lost $20 order, not a $2,000 job. |
| 2. Already pays for software | 1. This is provisional, see Gaps. | 1. This is provisional, see Gaps. |
| 3. Reachable this week | 1. This is provisional, see Gaps. | 1. This is provisional, see Gaps. |
| **Score** | **3/3** | **2/3** |

Chosen niche: dental clinics in Leeds. Restaurants fail filter 1, so no offer is written for them. Commit to dental clinics for 30 days and don't switch.

## Headline

We reply to every missed call within 60 seconds for dental clinics in Leeds, without hiring a receptionist. *(Lesson: "The one-outcome offer": "We [measurable outcome] for [niche] in [timeframe], without [the pain they hate].")*

Headline rules check: one niche, one countable outcome (replies within 60 seconds), no tool names, no promise about their revenue.

## Who it's for

Dental clinics in Leeds that miss calls when the team is with patients or the phone is busy, and that already run a booking or phone system.

## The problem

When a call goes unanswered, the patient may ring the next clinic. For a dental practice, one lost new-patient enquiry can be a lot of money. See Gaps: the quote below is a placeholder to replace with your prospects' own words.

> "We're with a patient and the phone rings out. By the time we call back, they've moved on."

## How it works

1. Someone calls your clinic and nobody picks up.
2. Within 60 seconds they get a text from your clinic's number: "Sorry we missed you, how can we help? Reply here to book."
3. Your team sees the reply and follows up, or the patient books.

## What's included

- Setup of the missed-call text reply on your clinic's number
- The automation running every month
- A monthly check-in to review the numbers and adjust the message

## Price

**Founding client offer: 1,000 setup + 500 a month.** *(Lesson: "Pricing your first offer": "Use the higher end when one recovered lead is worth a lot to the client")*

Why this point in the range: founding clients are 500-1,000 setup and 300-500 a month. The lesson says to use the higher end when one recovered lead is worth a lot, and a dental implant is its example. Founding clients get this price in exchange for a testimonial and the 30-day pilot below. If a clinic pushes back, you can move toward 500 setup, but never below 300 a month.

## Pilot and proof

30-day pilot with one success metric agreed up front. Suggested metric: the share of missed calls that get a text reply within 60 seconds. This is a speed and coverage metric you control, not their sales. Nothing here promises revenue or results you don't control.

## What I need from you

- Access to your phone system or number settings
- One contact person at the clinic
- 30 minutes for setup

## Check

- Required headings present: pass. Niche check, Headline, Price, Pilot and proof, and What I need from you are all there.
- Check, Gaps and assumptions, Next step present: pass.
- Chosen niche shows 3/3: pass.
- No "guaranteed revenue": pass.
- At most 6000 characters: pass.
- Recommendations follow and cite the lessons, nothing invented: pass. The 60-second figure comes from the lesson's example headline.
- Money and behaviour claims sourced or listed in Gaps: pass. The prices come from the ladder.

## Gaps and assumptions

- Verify before use: filter 2. The lesson doesn't state that dental clinics pay for booking or phone software. Confirm on your first calls.
- Verify before use: filter 3. Check you can find 50 dental clinics in Leeds in under an hour (Google Maps, a directory). If you can't, the niche fails and needs rethinking.
- Verify before use: the problem quote and the idea that patients ring the next clinic after a missed call are my wording, not from the lessons. Replace the quote with what Leeds clinics actually say.
- Assumed currency: pounds (£), since you're in Leeds. The lessons say "local currency".
- I left tool names (n8n, Twilio) out of the page because the lessons say clients buy outcomes. Your setup covers the delivery, so you can do this offer today.
- Restaurants: you were torn between the two niches, but the lesson says most restaurants fail filter 1, so I followed the lesson and picked dental.

## Next step

Post the offer in Wins today with "#firstwin", then start the outreach-sprint skill.
