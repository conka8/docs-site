> Actual output: Claude Code run on 2026-10-29 (model alias "sonnet"), unedited. See live-runs/README.md.
> Synthetic example: invented community and businesses.

## Messages

**Smile Studio Leeds**

Day 0
> Smile Studio Leeds: three of your last ten Google reviews mention calls going to voicemail.
> Each missed call is a patient who books somewhere else.
> I recorded a 60-second video showing how I'd fix it: [Loom link]. Worth a look?

Day 3 (Follow-up 1, new angle)
> Smile Studio Leeds: one more thing I noticed: [NEW OBSERVATION: a different detail from their website, Google profile or opening hours].
> Same cost applies: a call that goes unanswered is a patient who books somewhere else.
> Here's the 60-second video again: [Loom link]. Worth a look?

Day 7 (Follow-up 2, polite close)
> Smile Studio Leeds: I haven't heard back, so I don't want to keep filling your inbox.
> Should I close your file?

**Kirkstall Dental**

Day 0
> Kirkstall Dental's website says the phone line closes at 4pm on weekdays, so anyone calling after that gets no answer.
> Each of those calls is a patient who books somewhere else.
> I recorded a 60-second video showing how I'd fix it: [Loom link]. Worth a look?

Day 3 (Follow-up 1, new angle)
> Kirkstall Dental: one more thing I noticed: [NEW OBSERVATION: a different detail from their website, reviews or Google profile].
> Same cost applies: an unanswered call is a patient who books somewhere else.
> Here's the 60-second video again: [Loom link]. Worth a look?

Day 7 (Follow-up 2, polite close)
> Kirkstall Dental: I haven't heard back, so I don't want to keep filling your inbox.
> Should I close your file?

Send exactly these two follow-ups per business, then stop. Never send a third. *(Lesson: "The follow-up cadence": "Then stop. Never send a third follow-up.")*

Each Day 0 message is three lines and under 90 words. It starts with the business and ends with the ask. It has no prices, attachments or links except the Loom placeholder. *(Lesson: "The 3-line Loom script": "No attachments, no prices, no links except the Loom.")*

## Skipped

- **Bright Dental Care:** you haven't looked at them yet, so there is no real observation. A generic message burns your list. Check their website, Google reviews or opening hours for one specific thing, then add them back. *(Lesson: "The 3-line Loom script": "If you can't find a real observation, skip that business. Generic messages burn your list.")*

## Tracking sheet

```csv
Business,Contact,Observation,Day 0 sent,Day 3 sent,Day 7 sent,Reply,Call booked
Smile Studio Leeds,,3 of last 10 Google reviews mention calls going to voicemail,,,,,
Kirkstall Dental,,Website says phone line closes at 4pm on weekdays,,,,,
```

Count a message as "sent" only once the Day 0 message has gone out. *(Lesson: "The follow-up cadence": "Count your outreach as 'sent' only when the Day 0 message went out.")*

## Check

- Contains "## Messages", "## Tracking sheet", "Day 0", "Day 3" and "Day 7": pass. All are present.
- Contains the exact tracking column header: pass. The CSV uses the lesson's columns.
- Contains "## Check", "## Gaps and assumptions" and "## Next step": pass.
- At most 12000 characters: pass.
- Every recommendation follows and cites the lessons, and nothing is invented: pass, except that Follow-up 1 needs your own new observation (see Gaps).
- Every number or customer-behaviour claim comes from the lessons or you, or is listed for verification: pass. "Each missed call is a patient who books somewhere else" comes from the lesson. The "3 of 10" and "4pm" figures come from you.

## Gaps and assumptions

- **Contact names are missing.** The Contact column is blank. Find a name for each clinic, or leave it blank and address the message to the practice.
- **Follow-up 1 needs a new angle.** The lesson asks for a different observation or a short result from another niche. You gave one observation per business, and I have no results from another niche. I left a `[NEW OBSERVATION]` placeholder instead of inventing one. Find a second real detail for each clinic before Day 3.
- **Verify before use:** recheck that 3 of Smile Studio's last 10 reviews still mention voicemail, since the "last 10" window shifts as new reviews arrive. Also confirm Kirkstall's 4pm weekday closing is still on their website.
- **Loom videos:** record one 60-second video per business and replace each `[Loom link]` before sending.
- **Assumption:** I read "phone line closes at 4pm" as nobody answering calls after 4pm on weekdays.
- No conflicts with the lessons.

## Next step

Send today's Day 0 messages to Smile Studio Leeds and Kirkstall Dental, mark them in the tracking sheet, and set a reminder for Day 3. Today, also research Bright Dental Care and find a second observation for each of the first two clinics.
