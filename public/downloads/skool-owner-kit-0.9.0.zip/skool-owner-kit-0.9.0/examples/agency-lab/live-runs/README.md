# Skill execution record: Northwind member pack

**What this is:** the generated skills run by Claude on test inputs, outputs saved unedited. The community, lessons,
businesses and inputs are synthetic. This is evidence about the skills' behaviour, not about members, outcomes or money.

| Level | Status for this pack |
|---|---|
| Packaging and lint | Passes: `skillkit lint --strict`, upload zips built |
| API instruction evaluation (`skillkit eval --provider anthropic`) | Not run: no API key in this environment, and no spending was allowed |
| **Skill execution in Claude** | **Done in Claude Code, 8 runs below.** Not done in the Claude app (claude.ai or desktop) |
| Real member outcomes | None: no real community has used it |
| Financial outcomes | None |

## How the runs were done

- **Platform:** Claude Code (Claude Agent SDK). Each run was a fresh subagent with no other context. It was told the
  skill folder's path, to read `SKILL.md` and follow it, reading the reference files it points to, and to reply to
  the member's message in one turn. It had no access to the expected results.
- **Model:** the `sonnet` model alias in Claude Code. The run did not report an exact model version.
- **Date:** 2026-10-29.
- **Pack:** built by `skool-kit pack-build` from `../pack.yaml` with the example outputs removed, so the runs couldn't
  copy them.
- **Not tested:** Claude choosing the skill by itself from its description (each run was told which skill to use),
  the Claude app's upload and code-execution environment, and multi-turn conversations.

## Round 1

| # | Case | Skill | Member input | Time | Result | Corrections needed |
|---|---|---|---|---|---|---|
| 1 | Question answered from a lesson | tutor | "What should I charge my first client? I'm setting up a missed-call text-back for a dental clinic." | 11 s | **Pass.** Correct ladder (500-1,000 setup, 300-500 a month, never below 300), cites "Pricing your first offer" | None |
| 2 | Question the lessons don't cover | tutor | "Do I need to register as a limited company before I sign my first client? I'm based in Ireland." | 15 s | **Pass.** Says it isn't covered, labels its general guidance as its own, gives a paste-ready coach question | None. Admins who don't want any general guidance on legal topics should add that rule |
| 3 | Offer task | offer-builder | Dental clinics vs restaurants in Leeds; can build missed-call text-back with n8n + Twilio | 32 s | **Pass with a defect.** Scores dental 3/3, restaurants 2/3; all sections; price inside the ladder (900 / 450); 253-word page | 1: "one lost new-patient enquiry can be worth hundreds or thousands of pounds" is an unsupported money claim, not flagged |
| 4 | Outreach task | outreach-sprint | Offer headline + 3 prospects, one with no observation | 36 s | **Pass with a defect.** 3-line Day 0 messages (39 and 41 words), skips the business without an observation, two follow-ups each, tracking CSV | 1: Day 3 follow-ups state customer behaviour as fact ("don't usually try again the next day") |
| 5 | Incomplete and conflicting input | offer-builder | "Restaurants in Manchester… £150 a month… guarantee them 20% more bookings" (no deliverable given) | 11 s | **Pass.** Asks only for the missing input; names both conflicts with the lesson they break | None |

**Fix after round 1:** every task skill now says that money amounts, numbers and claims about customer behaviour must
come from the lessons or the member, or be listed under "Gaps and assumptions" as "verify before use"; the checklist
checks it. (`memberpack.py`, rule and checklist line.)

## Round 2 (after the fix; same inputs)

| # | Case | Time | Result | Corrections needed |
|---|---|---|---|---|
| 3 | Offer task | 27 s | **Pass.** The claim about patients ringing the next clinic and the sample quote are now flagged "verify before use"; filters 2 and 3 marked provisional; price 1,000 / 500 inside the ladder; 382-word page (limit 400) | None |
| 6 | Question answered from a lesson ("How do I choose a niche?", tutor) | 9 s | **Pass.** All three filters, scoring rule, tie-break and common mistakes as in the lesson; cites "Pick a niche with the 3-filter test" | None |
| 4 | Outreach task | 37 s | **Pass.** No invented behaviour claims; Day 3 uses a `[NEW OBSERVATION]` placeholder instead of making one up, and lists it as a gap; Day 0 messages 40 and 46 words | None. Trade-off: the member must find a second observation before Day 3 |

Outputs: `round-1/` and `round-2/`, unedited. Round 2's offer and outreach outputs, and round 1's tutor answers, are
the example outputs in `../examples/` and in `evals/cases.yaml`.

## Changes after the runs

- The escalation sentence was reworded to name a place to post (`support_channel: the Help channel (tag a coach)`)
  instead of quoting the support instruction. The instruction itself is unchanged.
- Run 5 (conflicting input) was added to the pack's acceptance cases as `offer-builder-conflicting-input`.

## Later evidence

- `../acceptance-journey/`: the member journey from the released download, installed copies, simulated skill
  selection, and an update that reaches members.
- `../benchmark/`: the same model as a general assistant, with the lessons, and as the skill, graded blind. It found
  further defects, fixed in pack builds after these runs.

## Still to do before a real member sees a pack

Run the acceptance cases in the **Claude app** on the plan members use: build the kit with
`skool-kit pack-share member-pack -o share --version 1.0.0`, follow its `START-HERE.md`, and record each run in
`pilot/acceptance.csv`. The steps are in `../acceptance-journey/README.md`. This needs a Claude account; it was not
available here.
