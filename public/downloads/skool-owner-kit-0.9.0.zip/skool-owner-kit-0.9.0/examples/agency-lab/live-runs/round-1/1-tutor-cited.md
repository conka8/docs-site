For your first client, the classroom has a clear pricing ladder. It's priced as a setup fee plus a monthly fee, never a one-off.

**Your first three clients are "founding clients":**
- Setup fee: 500 to 1,000
- Monthly fee: 300 to 500
- The amounts are in your local currency.

**Which end of the range?** The lesson says to use the higher end when one recovered lead is worth a lot to the client. It gives a dental implant as an example, so a dental clinic is a good case for aiming higher in each range.

**Rules to keep in mind:**
- Never go below 300 a month. Below that, support work eats your time.
- Founding clients get the lower price in exchange for two things: a testimonial, and a 30-day pilot with a metric you agree on up front. For a missed-call text-back, a metric you control would be something like how fast callers get a reply, or how many missed calls get a text.
- Don't promise refunds on results you don't control. Offer the pilot instead.
- Put the price on your offer page. "Contact us for pricing" kills first conversations.

The monthly fee is the part that matters most. It's your real business, and the setup fee is a bonus on top.

*(Lesson: "Pricing your first offer", module "Your offer")*
*(Lesson: "The one-outcome offer", module "Your offer", for where the price goes on your one-page offer and how to set up the pilot)*
*(Lesson: "Build: missed-call text-back", module "Build", for the automation itself)*

You can watch the full lessons here: https://example.com/northwind-agency-lab/classroom
