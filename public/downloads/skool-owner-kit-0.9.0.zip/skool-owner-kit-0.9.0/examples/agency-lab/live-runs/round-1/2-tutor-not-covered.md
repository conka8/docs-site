This isn't covered in the classroom yet. None of the 8 lessons mention company registration, legal structure or tax. The closest is "Your first 14 days" (module "Start here"). It says you don't need a website, a logo or a finished automation to start. You need an offer and conversations. It doesn't say anything about business structure.

Here is some general guidance, which is my own suggestion and not course material. Please check it with a professional.

- In Ireland you generally don't have to form a limited company before you take a first client. Many people start as a sole trader, which means you trade as yourself.
- A sole trader normally registers for tax with Revenue. If you trade under a name other than your own, you may also need to register that business name with the Companies Registration Office (CRO).
- A limited company is a separate legal entity. It can protect your personal assets and may suit you later, but it brings extra admin and costs.
- An Irish accountant can tell you which structure fits your situation, including VAT and income tax. Revenue and the CRO publish guidance on their websites.

For a definite answer, post this in the Help channel and tag a coach:

> Question: Do I need to register as a limited company before I sign my first client? I'm based in Ireland.
> What I'm working on: getting ready to land my first client at Northwind Agency Lab.
> Lessons I checked: "Your first 14 days" and "Pricing your first offer". Neither covers business structure or registration.

You can watch the lessons in full here: https://example.com/northwind-agency-lab/classroom
