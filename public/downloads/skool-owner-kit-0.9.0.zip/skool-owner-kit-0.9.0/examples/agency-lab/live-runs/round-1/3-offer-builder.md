## Niche check

Each niche gets 1 point per filter *(Lesson: "Pick a niche with the 3-filter test")*.

| Filter | Dental clinics, Leeds | Restaurants, Leeds |
|---|---|---|
| Money leak | 1. A missed call can be a high-value treatment. | 0. A missed call is a lost low-value order and margins are thin. |
| Already pays for software | 1. They typically already pay for booking or practice software (assumed, see Gaps). | 1. Typically pay for booking or till software (assumed). |
| Reachable this week | 1. 50 clinics in Leeds can be found on Google Maps in under an hour. | 1. Easy to find on Google Maps. |
| **Score** | **3/3** | **2/3** |

**Chosen niche: dental clinics in Leeds.** Restaurants fail the money-leak filter, so I haven't written an offer for them. Commit to dental for 30 days.

## Headline

**We reply to every missed call within 60 seconds for dental clinics in Leeds, without hiring a receptionist.**

It names one niche and one countable outcome. It has no tool names and no promise about their sales *(Lesson: "The one-outcome offer")*.

## Who it's for

Independent dental clinics in Leeds with 1 to 5 dentists. They use a booking or practice system but have no one covering the phone at lunch, in the evening or when the front desk is busy.

## The problem

"We're with a patient and the phone rings out." Every missed call is a patient who rings the next clinic. One lost new-patient enquiry can be worth hundreds or thousands of pounds.

## How it works

1. A call to your clinic goes unanswered.
2. Within 60 seconds, the caller gets a friendly text: "Sorry we missed you. How can we help? Reply here and we'll get back to you."
3. Their reply goes to your team, so you can book them in.

## What's included

- Setup of the missed-call text-back, with the wording written for your clinic.
- The automation running every day.
- A monthly check-in on the numbers.

## Price

Founding-client price:
- **Setup: £900 one-off**
- **Monthly: £450 a month**

In exchange, I ask for a testimonial and the 30-day pilot below.

## Pilot and proof

A 30-day pilot with one metric we agree up front: the share of missed calls that get a text within 60 seconds. We review the results together at day 30.

## What I need from you

- Access to your phone system or call forwarding.
- One contact person at the clinic.
- 30 minutes for setup.

## Check

- Required headings (Niche check, Headline, Price, Pilot and proof, What I need from you): pass. All are present.
- Check, Gaps and assumptions, Next step headings: pass. All are present.
- Niche check shows the chosen niche at 3/3: pass. Dental scores 3/3.
- No promise of revenue: pass. The page promises speed only.
- At most 6,000 characters: pass.
- Follows the lessons and cites them, nothing invented: pass. Price and pilot come from the pricing ladder, and the offer is 8 sections under 400 words.

## Gaps and assumptions

- Price: I used the higher end of the founding-client range (£900 setup, £450 a month), because one recovered dental lead can be worth a lot *(Lesson: "Pricing your first offer")*. Lower it if you prefer, but never below £300 a month. I assumed GBP, since you're in Leeds.
- Filter 2: I assumed Leeds dental clinics already pay for booking or practice software. Confirm this on your first few calls.
- Tools: n8n and Twilio stay off the page, since clients buy outcomes. Check that your setup can really send the text within 60 seconds before you use that figure.
- Restaurants: they fail filter 1, so the lessons say not to pick them. This isn't a conflict with your input, just the result of the test.

## Next step

Post the offer in Wins today with "#firstwin", then start the outreach-sprint skill.
