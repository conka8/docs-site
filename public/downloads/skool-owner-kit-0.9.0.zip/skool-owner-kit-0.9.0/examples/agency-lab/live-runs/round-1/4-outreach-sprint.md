## Messages

**Smile Studio Leeds**

**Day 0** *(Lesson: "The 3-line Loom script")*

> Three of your last ten Google reviews mention calls going to voicemail.
> Each missed call is a patient who books with another clinic instead.
> I recorded a 60-second video showing how I'd fix it. Worth a look? [Loom link]

**Day 3, Follow-up 1** *(Lesson: "The follow-up cadence": one new angle, same ask)*

> Most clinics in Leeds can't justify a full-time receptionist just to catch every call, which is why I built this around replying within 60 seconds instead. The 60-second video shows how it would work for Smile Studio. Worth a look? [Loom link]

**Day 7, Follow-up 2** *(Lesson: "The follow-up cadence": polite close)*

> Should I close your file? If missed calls aren't a priority right now, no problem at all. The video is here if you change your mind. [Loom link]

---

**Kirkstall Dental**

**Day 0** *(Lesson: "The 3-line Loom script")*

> Your website says the phone line closes at 4pm on weekdays.
> Anyone who rings after work is likely to book with a clinic that picks up.
> I recorded a 60-second video showing how I'd fix it. Worth a look? [Loom link]

**Day 3, Follow-up 1** *(Lesson: "The follow-up cadence": one new angle, same ask)*

> Patients who can't get through at 4pm don't usually try again the next day, they book elsewhere. The 60-second video shows how Kirkstall could reply to those calls within a minute, without hiring anyone. Worth a look? [Loom link]

**Day 7, Follow-up 2** *(Lesson: "The follow-up cadence": polite close)*

> Should I close your file? If after-hours calls aren't a priority right now, no problem at all. The video is here if you change your mind. [Loom link]

## Skipped

- **Bright Dental Care**: you haven't looked at them yet, so there is no real observation. A generic message would burn your list. Spend 5 minutes on their website and Google reviews, find one specific thing, and send it to me to add. *(Lesson: "The 3-line Loom script")*

## Tracking sheet

```csv
Business,Contact,Observation,Day 0 sent,Day 3 sent,Day 7 sent,Reply,Call booked
Smile Studio Leeds,,"3 of last 10 Google reviews mention calls going to voicemail",,,,,
Kirkstall Dental,,"Website says phone line closes at 4pm on weekdays",,,,,
```

Count a message as "sent" only once the Day 0 message has gone out. *(Lesson: "The follow-up cadence")*

## Check

- Contains "## Messages", "## Tracking sheet", "Day 0", "Day 3", "Day 7": pass. All are present.
- Contains the exact tracking sheet header: pass. The CSV uses the lesson's columns.
- Contains "## Check", "## Gaps and assumptions", "## Next step": pass.
- At most 12000 characters: pass.
- Every recommendation follows the lessons and cites them, nothing invented: pass. Each Day 0 message has three lines, is under 90 words, starts with the prospect, and has no prices or links except the Loom placeholder. There are exactly two follow-ups per business. The follow-up angles are my own wording, flagged under Gaps and assumptions.

## Gaps and assumptions

- **Contact names are missing.** I left the Contact column blank. Add a first name and greeting if you have one, but keep the message to three lines.
- **Loom link:** I used the placeholder `[Loom link]`. Record one 60-second video per business before sending, because the Day 0 ask promises one.
- **Follow-up 1 angle (my own suggestion):** the lesson asks for a different observation or a short result from another niche. You gave me only one observation per business and no results from other niches, and I won't invent any. So I used a different angle on the same problem (no extra hire for Smile Studio, patients not retrying for Kirkstall). If you find a second real observation, such as another review or their opening hours on Google, swap it in.
- **Verify before sending:**
  - Re-check that "3 of their last 10 Google reviews" is still accurate for Smile Studio, because the count shifts as new reviews come in.
  - Re-check that Kirkstall's 4pm weekday cutoff is still on their website.
  - The Kirkstall cost line ("after work") is my inference from the 4pm closing time, so confirm it fits their patients.
  - Your offer headline promises a reply "within 60 seconds". Make sure you can deliver that before you say it in the video.
- **Conflicts with the lessons:** None.

## Next step

Send today's Day 0 messages to Smile Studio Leeds and Kirkstall Dental, mark them in the tracking sheet, and set a reminder for Day 3. Then look at Bright Dental Care and send me one real observation so I can write theirs.

---

**Question for a coach** (paste into Ask in the Help channel and tag a coach):

> I'm working on my first outreach messages using "The 3-line Loom script" and "The follow-up cadence". My offer is: "We reply to every missed call within 60 seconds for dental clinics in Leeds, without hiring a receptionist." I have 2 prospects with real observations and 1 I've skipped for now. I only have one observation per prospect, and I have no results from other niches yet. For Follow-up 1, is it OK to take a new angle on the same observation, or should I find a second observation before sending Day 3?
