Great question. Northwind Agency Lab teaches a simple scoring test for this, the 3-filter test. Don't pick a niche because it sounds exciting. Pick one that passes all three filters.

**The 3 filters**

1. **Money leak.** The business loses real money when a lead goes unanswered, for example after a missed call, a slow reply or a no-show.
   - Dental clinics, roofers, med spas, HVAC and law firms pass.
   - Most restaurants don't. Their margins are thin, and a missed call costs them a $20 order, not a $2,000 job.
2. **Already pays for software.** They already pay for a booking system, a CRM or a phone system. A business that pays for software understands paying monthly for a result.
3. **Reachable this week.** You can find 50 of them in one city or region in under an hour. Google Maps, a directory or your own network all work.

**How to use it**
- List the niches you're considering.
- Give each niche 1 point for every filter it passes.
- Only pick a niche that scores 3/3.
- If two niches both score 3/3, pick the one where you already know someone or speak their language.

**Common mistakes to avoid**
- "Small businesses" is not a niche. "Dental clinics in Leeds" is.
- Enterprise companies fail filter 3, because you can't reach 50 decision makers in a week.
- Switching niche every week. Commit to your pick for 30 days.

*(Lesson: "Pick a niche with the 3-filter test", module "Your offer")*

You can watch the full lesson in the classroom: https://example.com/northwind-agency-lab/classroom

Once you've picked a niche, the next lesson in the same module is "The one-outcome offer". It covers what to sell to that niche.
