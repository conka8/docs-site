# Northwind Agency Lab: your AI toolkit

3 Claude skills built from the Northwind Agency Lab classroom. They draft your first work with you, following the lessons, toward your **First win**: One-page offer posted in Wins and 20 outreach messages sent, within 14 days of joining. You review and edit everything they draft.

| Skill | What it helps you make | Time |
|---|---|---|
| **northwind-tutor** | Ask anything about the lessons. It answers from the classroom and says which lesson to watch. | Any time |
| **northwind-offer-builder** | Build your one-page offer: A one-page offer for one niche, priced, ready to post in Wins | 30 min |
| **northwind-outreach-sprint** | Write your first outreach messages: Personalised first messages and both follow-ups for up to 10 businesses, plus a tracking sheet | 45 min |

## What you need

- A Claude account: claude.ai, the Claude desktop app, or Claude Code.
- The 3 files from your admin, one per skill: `northwind-tutor.zip`, `northwind-offer-builder.zip`, `northwind-outreach-sprint.zip`.

## 1. Install (once, about 5 minutes)

**Claude app (claude.ai or desktop):**

1. Settings > Capabilities: turn on **Code execution and file creation** (in some layouts: **Create and edit files**).
2. Customize > Skills > **+** > **Create skill** > **Upload a skill**. Choose `northwind-tutor.zip`.
3. Make sure the skill's switch is on.
4. Repeat steps 2 and 3 for `northwind-offer-builder.zip` and `northwind-outreach-sprint.zip`.

On a Team or Enterprise plan your admin may have added the skills for everyone: look in Customize > Skills first.

**Claude Code:** put each zip in one folder, open a terminal there, and run:

```bash
mkdir -p ~/.claude/skills
unzip -o northwind-tutor.zip -d ~/.claude/skills/
unzip -o northwind-offer-builder.zip -d ~/.claude/skills/
unzip -o northwind-outreach-sprint.zip -d ~/.claude/skills/
```

Windows (PowerShell):

```powershell
Expand-Archive -Force northwind-tutor.zip "$env:USERPROFILE\.claude\skills"
Expand-Archive -Force northwind-offer-builder.zip "$env:USERPROFILE\.claude\skills"
Expand-Archive -Force northwind-outreach-sprint.zip "$env:USERPROFILE\.claude\skills"
```

You should now have `~/.claude/skills/northwind-tutor/SKILL.md`. Start a new Claude Code session; `/skills` lists them.

## 2. Check it works (1 minute)

Start a new chat and ask: *"How do I choose a niche?"*

The answer should name a lesson, like *(Lesson: "Pick a niche with the 3-filter test")*. If it doesn't, ask again starting with "Use the northwind-tutor skill:". If Claude says it has no such skill, go back to step 1.

## 3. Your first tasks

### 1. Build your one-page offer (30 min)

Paste this into a new chat, replacing the parts in [brackets]:

> Use the northwind-offer-builder skill. Which 1 to 3 niches are you considering? [dental clinics, roofers] Which city or region will you sell in? [Leeds] What can you set up for a client today (an automation, a chatbot, a booking flow)? [missed-call text-back with n8n and SMS]

What you get: a draft you can copy and edit, with the sections Niche check, Headline, Who it's for, The problem, How it works, What's included, Price, Pilot and proof, What I need from you, then a **Check** of the draft against the lessons, **Gaps and assumptions**, and a **Next step**.

Before you use it: read Gaps and assumptions first, and check or remove anything marked "verify before use". The check is Claude reviewing its own draft against the lessons; it can miss things.

### 2. Write your first outreach messages (45 min)

Paste this into a new chat, replacing the parts in [brackets]:

> Use the northwind-outreach-sprint skill. What's your offer headline? (Paste it from your one-page offer.) [We reply to every missed call within 60 seconds for dental clinics in Leeds, without hiring a receptionist.] List up to 10 businesses, each with one specific thing you noticed (from their website or reviews). [Smile Studio Leeds: 3 recent reviews mention calls going to voicemail]

What you get: a draft you can copy and edit, with the sections Messages, Skipped, Tracking sheet, then a **Check** of the draft against the lessons, **Gaps and assumptions**, and a **Next step**.

Before you use it: read Gaps and assumptions first, and check or remove anything marked "verify before use". The check is Claude reviewing its own draft against the lessons; it can miss things.

## 4. Report your First win

Post in Wins with "#firstwin" and a link to your offer.

## When the lessons don't cover something

The skill says it isn't covered and drafts a short question for you. Copy it and post it in the Help channel (tag a coach if nobody answers within a day); the skill can't post it for you.

## Updates

When your admin shares a new version: in the Claude app, delete the old skill (Customize > Skills) and upload the new zip. In Claude Code, run the same unzip commands again.

## Good to know

- The skills run in your own Claude account. Nothing is sent to the community; Claude's own data terms apply.
- Check anything before you send it to a client. You are responsible for what you send.
- Not sure where to begin? Start with task 1.
