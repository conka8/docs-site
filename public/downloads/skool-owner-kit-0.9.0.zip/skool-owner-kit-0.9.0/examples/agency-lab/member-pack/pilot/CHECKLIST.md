# Pilot operating checklist: Northwind Agency Lab

One page to run the pilot from. Windows and thresholds come from `pilot.yaml`; set them there once. Product quality,
member outcomes and economics are judged separately: a good number in one never makes up for a failure in another.

## Before launch

- [ ] **Fit and scope**: the fit questions answered; one first outcome (First win: One-page offer posted in Wins and 20 outreach messages sent); the
      supported tasks listed; the lessons the pack may use chosen.
- [ ] **Content intake**: those lessons as you have them (exports, transcripts or notes); two or three examples of good
      member work.
- [ ] **Format**: a Claude Project (default when members use Claude on their own plans) or skills (Claude Code users,
      or a Team or Enterprise organisation), chosen and written down with the reason.
- [ ] **Approval**: `skool-kit pack-build`, then the owner signs APPROVAL.md: the tasks, every rule listed to confirm
      (each shown beside its closest lesson sentence) and the acceptance cases.
- [ ] **Baseline**: an earlier month of new paid members with no launch, sale or price change, logged in `events.csv`
      the same way the pilot will be (joined, First win, first renewal or cancellation).
- [ ] **Thresholds** in `pilot.yaml`, agreed in writing before the first pilot member joins.
- [ ] **Acceptance**: every case in `evals/acceptance.yaml` run in the Claude app in the chosen format, in new chats,
      with its later turns; each final reply saved and checked with `skool-kit check-answer reply.md --pack .
      --case <id>`, and its review questions answered by a person. One row each in `acceptance.csv` (surface and plan
      in `surface`). Fix and re-run failures before launch.
- [ ] **Installation**: `skool-kit pack-share --format project` (or `skills`); set the kit up yourself by following its
      START-HERE.md exactly, and note any step that didn't match.

## During the pilot month

- [ ] **Member onboarding**: every new paid member gets the kit and START-HERE.md on the day they join.
- [ ] **Joins**: on the last day of the month, `skool-kit pilot-import` with a member export; add anyone who already
      left from your payment history.
- [ ] Optional: `installed` and `task_completed` (task in `note`), only when you can see them without asking.
- [ ] **First win**: log `first_outcome` on the day it's reported. It counts only within 14 days of joining.
- [ ] **Answer corrections**: in `questions.csv`, every answer someone had to correct (`corrected`), with staff
      minutes. Reviewing other answers is optional.
- [ ] **Staff effort and cash costs**: every hour and every payment in `costs.csv`, including your own time, with the
      activity as `item`.

- [ ] **Halfway**: run `skool-kit pilot pilot/pilot.yaml` to check the logs are complete; fix gaps now, not later.

## After the pilot month

- [ ] **Outcome window**: 14 days after the last pilot member joined, set `as_of` and run the report.
- [ ] **Renewal follow-up**: after each member's first renewal date (`renewal_after_days` after joining), log
      `renewed` or `cancelled`. Members not yet due are left out, never counted as lost.
- [ ] **Final customer report**: `skool-kit pilot pilot/pilot.yaml --format md -o pilot-report.md`, read with the
      three verdicts side by side, then decide: continue, extend, change or stop.

## What the report can't tell you

- Two cohorts of a few dozen members can only show large differences; the report gives 95% ranges and says when there
  isn't enough data.
- It compares months, so season, marketing and who joined also change the result. It can't prove cause.
- Self-reported outcomes undercount; log both cohorts the same way.
- Time freed is capacity, not cash, unless you cut paid hours.
