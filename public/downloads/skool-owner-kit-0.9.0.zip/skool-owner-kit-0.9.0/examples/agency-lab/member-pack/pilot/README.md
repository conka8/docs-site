# Pilot: does the member pack help new members reach their First win?

Run it for at least one full cohort (members who join in one month) and 14 days after the
last of them joins. Everything stays in these files on your computer.

## What to log: the essentials

Five things, and nothing collected from members' chats:

1. **Who joined** (both cohorts): `skool-kit pilot-import pilot/pilot.yaml members.csv` with your community's member
   export. It adds a `joined` row per member, logged by a code instead of an email. An export lists current members
   only, so take it on the last day of the cohort month, and add anyone who has already left from your payment history.
2. **First outcomes**: `first_outcome` on the day a member reports it.
3. **Corrected answers**: one row in `questions.csv` whenever someone has to correct the kit.
4. **Renewals**: `renewed` or `cancelled` from your payment history, only once each member's renewal date has passed.
5. **Effort and cash**: time rows by activity and every payment, in `costs.csv` (whoever delivers the pilot keeps it).

Everything else below is optional: log it only when you can see it without asking every member.

**events.csv**, one row per event. Use the code `pilot-import` gave the member (`skool-kit pilot-import
pilot/pilot.yaml --code <email>` prints it), or any ID you like. Events:

| event | Log it when |
|---|---|
| joined | A paid member joins (every member needs this row) |
| installed | A pilot member tells you, or you see, that they installed the skills |
| used | A member reports using a skill |
| task_completed | A member shows a finished deliverable (put the task name, e.g. offer-builder, in `note`) |
| first_outcome | The member reports their First win: One-page offer posted in Wins and 20 outreach messages sent |
| renewed | The member's first renewal payment went through |
| cancelled | The member cancelled before or at the first renewal |
| refunded | The member got a refund |
| excluded | Leave this member out (for example a refund during a trial, a test account); say why in `note` |

For the baseline cohort, fill in `joined`, `first_outcome`, `renewed`, `cancelled` from your records
(for example #firstwin posts and your platform's payment history).

**questions.csv**: member questions you looked at during the pilot. `handled_by` is `tutor` (a member said the
tutor answered it, or you checked a tutor answer) or `staff`. `result` is `resolved`, `corrected` (the tutor was
wrong or incomplete and someone fixed it) or `escalated`. `staff_minutes` is the time staff spent on it.

**acceptance.csv**: one row per acceptance run before launch (`passed` is yes or no; `surface` is where it ran, for
example "Claude app, Pro"). The report won't suggest
continuing until these are recorded and pass.

**costs.csv**: every cost of running the pilot. `kind` is `cash` (money spent: implementation fee, API, software)
or `time` (minutes of your or your team's time). For time, name `item` after the activity (intake, spec, review,
acceptance, onboarding, logging, corrections, maintenance) and put who did it in `note` (owner, staff or us): the first
pilots replace the published effort estimates with these minutes.

## Read the result

```bash
skool-kit pilot pilot/pilot.yaml --format md -o pilot-report.md
```

The report judges three things separately: **product quality** (acceptance runs, corrected answers), **member
outcomes** (adoption, completed tasks, the first outcome within its window, pilot vs baseline) and **economics**
(cash and time spent, the observed first-renewal difference). Members whose window or renewal date hasn't arrived
by `as_of` are left out, not counted as failures. A good outcome result is held back if quality fails or the
economics are negative or over budget.

It compares cohorts; it does not prove cause: the pilot month can differ in season, marketing or price.
Small cohorts give wide ranges; the report says when there isn't enough data to decide.
