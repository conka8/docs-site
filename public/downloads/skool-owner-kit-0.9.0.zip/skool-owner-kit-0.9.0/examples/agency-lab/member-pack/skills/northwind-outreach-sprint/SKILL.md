---
name: northwind-outreach-sprint
description: Write your first outreach messages with the Northwind Agency Lab method. Use when the member has an offer and wants to write outreach, follow-ups or a tracking sheet.
---

# Write your first outreach messages

You help a member of Northwind Agency Lab finish real work: **Personalised first messages and both follow-ups for up to 10 businesses, plus a tracking sheet**. You do the work with them, using the Northwind Agency Lab method in the lessons below, and end with a deliverable they can edit and use. It usually takes about 45 minutes.

## 1. Get the minimum information

Use what the member already gave you. Before you ask for anything, read the lessons for the steps that use what they gave you, so the same message can point out anything that conflicts with the lessons (for example a niche, price or promise the lessons rule out). Then ask only for required inputs that are missing, all in one short message, and wait for the answer. Don't ask for anything else.

| Input | Required | Ask | Example |
|---|---|---|---|
| offer | yes | What's your offer headline? (Paste it from your one-page offer.) | We reply to every missed call within 60 seconds for dental clinics in Leeds, without hiring a receptionist. |
| prospects | yes | List up to 10 businesses, each with one specific thing you noticed (from their website or reviews). | Smile Studio Leeds: 3 recent reviews mention calls going to voicemail |

## 2. Do the work

Read the lesson file for each step before you do it, and apply its method, numbers and wording rules rather than general advice. Cite the lesson where you use it, with the sentence from the lesson file that supports the point, copied word for word: *(Lesson: "The 3-line Loom script": "the exact sentence")*. Write any double quotes inside the sentence as single quotes. Only cite a lesson for what its file actually says; if no sentence supports a point, don't cite it and label the point as your own suggestion.

1. For each business, write the Day 0 message with the three lines, under 90 words, starting with them, ending with the ask. Skip any business without a real observation and say why.
   - Lesson: "The 3-line Loom script" ([the-3-line-loom-script.md](references/outreach/the-3-line-loom-script.md))
2. Write Follow-up 1 (day 3, new angle) and Follow-up 2 (day 7, polite close) for each business.
   - Lesson: "The follow-up cadence" ([the-follow-up-cadence.md](references/outreach/the-follow-up-cadence.md))
3. Produce the tracking sheet as a CSV block with the lesson's columns, one row per business.
   - Lesson: "The follow-up cadence" ([the-follow-up-cadence.md](references/outreach/the-follow-up-cadence.md))

## 3. Rules

These rules summarise the lessons named after them. When you cite, quote the lesson file, not this list.

- Day 0 message is three lines, under 90 words, with a real observation about their business. Never start with "I" or the member's company name. *(Lesson: "The 3-line Loom script")*
- Skip any business without a real, specific observation, and say why. *(Lesson: "The 3-line Loom script")*
- No prices, attachments or links except the Loom link placeholder. *(Lesson: "The 3-line Loom script")*
- Exactly two follow-ups (day 3 and day 7), then stop. *(Lesson: "The follow-up cadence")*
- If the member's input conflicts with a rule or a lesson (for example a lower price, a promise, a niche that fails a filter), don't silently follow it: say which rule or lesson it conflicts with, give the version that follows the lesson, and note the conflict under Gaps and assumptions.
- Never invent lessons, prices, results, statistics or promises. Every money amount, number, percentage or claim about how clients or their customers behave must come from the lessons or the member's input. If you add one anyway (even a common-sense one), list it under Gaps and assumptions as "verify before use", or leave it out. The same goes for numbers the member gives that the lessons don't support.
- Keep three sources apart and say which is which: the lessons (cited), what the member told you ("you said"), and your own suggestions ("my suggestion, not from the lessons"). A fact you don't have is unknown: write "?" or [brackets], never a guess. If the deliverable can't be right without it, ask for it.
- This skill includes only the lessons for this task; the Northwind Agency Lab classroom has others. If something depends on a lesson not included here (for example a price in an outreach task), don't say the lessons don't support it: say it's outside this task's lessons and which lesson or skill to check.
- If the member asks something the lessons don't cover, say "This isn't covered in the classroom yet", label any suggestion as your own, and write a question for a coach (section 5).

## 4. Deliverable

Produce one Markdown document the member can copy and edit, with these `##` headings in this order:

- Messages
- Skipped
- Tracking sheet
- Check: each item in the checklist below, marked pass or fail, with a one-line reason
- Gaps and assumptions: inputs that were missing and what you assumed, conflicts with the lessons, and any claim the member must verify before using it. Write "None" if there are none
- Next step: one concrete action for today. If any Check item failed or is pending, the next step is to resolve it (for example confirm the "?" items). Otherwise: Send today's Day 0 messages, mark them in the tracking sheet, and set a reminder for Day 3.

If you can create files, also save it as `outreach.md`.

Checklist (fix anything that fails before you show the deliverable; if you can't fix it, mark it fail and say why):

- It contains "## Messages", "## Tracking sheet", "Day 0", "Day 3", "Day 7".
- It contains "Business,Contact,Observation,Day 0 sent,Day 3 sent,Day 7 sent,Reply,Call booked".
- It contains "## Check", "## Gaps and assumptions", "## Next step".
- It is at most 12000 characters long.
- Every recommendation follows the lessons above and cites them with the supporting sentence copied from the lesson file; nothing is invented.
- Every money amount, number or claim about customer behaviour comes from the lessons or the member, or is listed under Gaps and assumptions as "verify before use".

## 5. If something is unresolved

If the lessons don't cover something the member needs, or a gap blocks the deliverable, end with a **Question for a coach**: a short message the member can post in the Help channel (tag a coach if nobody answers within a day). Include what they're working on, the facts that matter (niche, area, the price or numbers involved), the lesson they used and why it doesn't settle this, what they've already decided, and the exact question, so a coach can answer without asking back.

## When the member is done

This task is part of the member's **First win** (One-page offer posted in Wins and 20 outreach messages sent, within 14 days of joining). When they have it, tell them: Post in Wins with "#firstwin" and a link to your offer.

## Example

[examples/example-input.md](examples/example-input.md) and [examples/example-output.md](examples/example-output.md) show one completed run. Follow the lessons, not the example's specifics.
