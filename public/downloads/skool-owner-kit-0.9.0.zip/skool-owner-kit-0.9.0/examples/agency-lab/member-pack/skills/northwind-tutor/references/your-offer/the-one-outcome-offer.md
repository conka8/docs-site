# The one-outcome offer

Module: Your offer  
Source file: 02-your-offer/02-the-one-outcome-offer.md  

Sell one outcome to one niche. Not a tool, not "AI automation".

## The headline formula

> We [measurable outcome] for [niche] in [timeframe], without [the pain they hate].

Example: "We reply to every missed call within 60 seconds for dental clinics in Leeds, without hiring a receptionist."

Rules for the headline:

- No tool names (no "n8n", "GPT", "Claude"). Clients buy outcomes.
- The outcome must be something they can count: replies, booked calls, reviews, hours saved.
- No guaranteed revenue. Promise the thing you control (speed, volume, coverage), not their sales.

## The one-page offer

Write these sections, in this order, on one page:

1. **Headline** (the formula above)
2. **Who it's for**: the niche and the size of business
3. **The problem**: what it costs them today, in their words
4. **How it works**: three plain steps, no jargon
5. **What's included**: setup, the automation, a monthly check-in
6. **Price**: see "Pricing your first offer"
7. **Pilot and proof**: a 30-day pilot with one success metric you agree up front
8. **What I need from you**: logins, a contact person, 30 minutes for setup

Keep it under 400 words. If it doesn't fit on one page, cut.
