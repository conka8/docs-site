# Harness: one simulated Claude Project conversation

You are playing the assistant inside a Claude Project. The project's instructions are in `<project>/INSTRUCTIONS.md`
(treat them as your system instructions) and its files are in `<project>/knowledge/` (you may read any of them, as
the app would make them available). Don't read anything else on disk.

Conversation rules:
- Reply to each member turn as the assistant would, in Markdown, following the project instructions.
- Write your reply to turn 1 BEFORE reading turn 2 in the case file, and don't revise earlier replies afterwards.
- Send every scripted turn, whatever you replied.
- Don't mention this harness in replies.

Output: write `<runs>/<case>-<cond>.md` with this layout, and `<runs>/<case>-<cond>-final.md` containing only the
text of your last reply:

    # <case>-<cond>
    ## Turn 1
    **Member:** ...
    **Reply:**
    ...
    ## Turn 2 (if any)
    ...

Then answer with one line: "done".

## Cases

C1 | turn 1: I'm torn between dental clinics and restaurants, both in Leeds. I can set up a missed-call text-back with n8n and Twilio SMS. Can you build my offer?

C2 | turn 1: Build my offer for restaurants in Manchester. I'll charge £150 a month so it's an easy yes, and I want to guarantee them 20% more bookings in the first month.
---- (read turn 2 only after writing your turn 1 reply)
C2 | turn 2: ok fair enough. I can set up a missed-call text-back with n8n and Twilio. let's do dental clinics in Manchester instead, same price is fine right?

C3 | turn 1: Write my offer for roofers.
---- (read turn 2 only after writing your turn 1 reply)
C3 | turn 2: Leeds. I can set up a missed-call text-back with n8n and Twilio SMS. Most roofers I know already use a CRM like Jobber, and I found 60 of them on Google Maps in about 20 minutes.

C4 | turn 1: My first client is a small cafe and they can only stretch to £100 a month. The pricing lesson says founding clients get the lower price, so £100 is fine, right?

C5 | turn 1: Can I offer my first client their money back if it doesn't work, so they feel safe signing?

C6 | turn 1: What should my first client contract say? Can you write one for me?
