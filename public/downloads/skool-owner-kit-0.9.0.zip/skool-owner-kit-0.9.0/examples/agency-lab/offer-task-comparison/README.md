# The offer task: our kit vs a well-instructed Claude Project with the same lessons

**Question:** for the one task we sell hardest (build a priced one-page offer), does our prepared kit do better than
the simple alternative an owner could set up alone: the same 8 lessons in a Claude Project with a short, competent
instruction?

**Answer from these 6 cases:** on the hard judgement calls, no difference. Both refused to read "founding clients get
the lower price" as permission to go under 300 a month, both kept "on results you don't control", and both named the
member's conflicting price and guarantee. The difference is in what the member ends up with:

- **Deliverable:** our kit produced the full one-page offer, with its Check, Gaps and assumptions, and Next step
  sections, in all 3 runs that called for one. The DIY Project produced 1 differently structured draft. In C1 it asked
  the member to check two filters before drafting anything, and in C3 it gave the draft no check or gaps.
- **Traceable citations:** 40 of 40 in our kit's final replies name the lesson and quote a passage found in it. In the
  DIY Project, 21 of 36 do. The rest quote a sentence without naming its lesson, or name a lesson without a
  checkable quote.
- **Not covered (C6):** both said contracts aren't covered. Ours drafted a question a coach could answer. The DIY
  Project told the member to ask in the Help channel but didn't write the question.

This doesn't show a smarter model. It shows the value of the preparation: a fixed deliverable, a citation format a
checker can trace, and the escalation step. A better DIY instruction could close some of the gap. We wrote this one
(`diy-project/INSTRUCTIONS.md`, 7 bullets) to be competent rather than weak.

**Not an app result.** Both conditions ran as Claude Code subagents (`claude-sonnet-5-5`) with the project's
instructions as their brief and its files readable, on 2026-10-30. That simulates Project-like context; it is not a
Claude Project in the app. One run per case and condition, so the sample is small and noisy. One subagent reported
it saw its scripted turn 2 before writing turn 1. Three made stray shell calls (an `echo` or a listing), and one
wrote its output files with a shell command instead of the Write tool. None of these changed the replies' inputs.

## Conditions

| | Kit (P) | DIY Project (D) |
|---|---|---|
| Instructions | `INSTRUCTIONS.md` from `northwind-claude-project-1.1.0.zip` (sha256 `1b52bd19…`), built by `pack-share --format project` from the current `member-pack/` | `diy-project/INSTRUCTIONS.md` |
| Files | The 15 kit files: 8 lessons, 3 task guides, 4 worked examples | The 8 lesson files, as exported |

## Cases (`HARNESS.md`) and results

The deterministic checks come from `skool-kit check-answer` with the matching acceptance case (`checks/`). The
semantic review is by the developer who built the kit: it is neither independent nor the owner's acceptance.

| Case | Acceptance type | Kit | DIY Project | Semantic review (developer) |
|---|---|---|---|---|
| C1 | Full task, inputs given | pass | fail: no deliverable structure; 7 of 10 citations not traceable | Kit: a complete draft, niche marked pending on the 2 unknown filters. DIY: asks the member to check the filters first, no draft yet. Both follow the 3-filter rule |
| C2 turn 1 | Member input contradicts lessons | pass | pass | Both name restaurants failing filter 1, £150 under the 300 floor, and the guarantee; both ask what the member can deliver |
| C2 turn 2 | Same, after a niche change | pass | fail: £750 setup not labelled as a choice from the ladder | Both still refuse £150 for dental clinics. DIY's draft has no Check or Gaps section |
| C3 turn 1 | Essential facts missing | pass | pass | Both ask for the area and what the member can deliver; neither invents them |
| C3 turn 2 | Full task after the facts | pass | fail: no deliverable structure; "95%" metric and £750 unlabelled; 3 of 5 citations not traceable | Both usable; the kit's states which facts are the member's and which are assumptions |
| C4 | True quote, wrong conclusion | pass | pass | Both reject £100, explain "lower price" as the founding row, and raise the money-leak question for a cafe |
| C5 | Dropped qualification | pass | pass | Both keep "on results you don't control" and offer the pilot. DIY adds a copy-and-edit pilot paragraph |
| C6 | Topic absent | pass | fail: no drafted coach question; 5 citations without a checkable quote | Both say contracts aren't covered and label the rest as their own suggestion |

## What this means for the offer

Members can't get better judgement from us than from their own well-instructed Project. What we can sell is a
deliverable they can use straight away, citations an owner can check mechanically, a route to a coach, and the
acceptance testing that found these differences. All of these come from preparation and testing, so that is how the
offer should be described.
