# Answer check: offer-builder-example

Deterministic checks: reliable for what they test, and nothing more. A reply can pass them all and still be wrong. Accepting it is a person's decision.

## Citations

| Lesson named | Quote | 1. Exists | 2. Right lesson | 3. Qualification | 4. Supports the claim? |
|---|---|---|---|---|---|
| Pick a niche with the 3-filter test | Pick one that passes all three filters | yes | yes | kept | person: does it support "## Step 1: the 3-filter test"? |
| - | Dental clinics, roofers, med spas, HVAC and law firms pass. | yes | no lesson named | - | person: does it support "Money leak \| Pass."? |
| - | Most restaurants don't: margins are thin and a missed call is a lost $20 order, not a $2,000 job. | yes | no lesson named | - | person: does it support "() \| Fail."? |
| - | you can find 50 of them in one city or region in under an hour. | yes | no lesson named | - | person: does it support "Filter 3:** can you find 50 dental clinics in Leeds in under an hour (Google Maps, a directory, your own network)?"? |
| - | If two niches score 3/3, pick the one where you already know someone or speak their language. | yes | no lesson named | - | person: does it support "It only matters if a second niche also hits 3/3."? |
| Build: missed-call text-back | - | no passage | - | - | person: does it support "n8n and Twilio stay off the page.** Your delivery method is a good fit: the lesson's build is a text to the caller within 60 seconds of a missed call, with a bo"? |
| The one-outcome offer | No tool names (no \ | no | - | - | person: does it support "But"? |
| Pricing your first offer | Use the higher end when one recovered lead is worth a lot to the client (a dental implant, a roof, a legal case). | yes | yes | kept | person: does it support "Price.** If this is one of your first three clients, the lesson's founding-client range is a setup fee of 500 to 1,000 and a monthly fee of 300 to 500, in pound"? |
| - | No guaranteed revenue. Promise the thing you control (speed, volume, coverage), not their sales. | yes | no lesson named | - | person: does it support "No promised results.** The pilot will be 30 days with one success metric agreed up front."? |
| Pick a niche with the 3-filter test | Switching niche every week. Commit for 30 days. | yes | yes | kept | person: does it support "One more rule:"? |

## Numbers

Unsourced (not in the lessons, the member's input or Gaps and assumptions): none

Declared as assumptions: none

## Promises

None found (checks guarantee, refund and earnings wording).

## Case checks

- [ ] contains: ['## Niche check', '## Headline', '## Price', '## Pilot and proof', '## What I need from you']
- [ ] contains: ['## Check', '## Gaps and assumptions', '## Next step']
- [x] The niche check shows the chosen niche scoring 3/3, or marks the check pending and lists the "?" filters the member must confirm.
- [x] It makes no guarantee of results.
- [x] max_chars: 6000

## For a person to decide

- [ ] Does each citation above support the sentence it's attached to, or is a true quote used for a different conclusion?
- [ ] Did the reply keep the lessons' limits and resolve any conflict between lessons?

**Deterministic result: fail**
- quote with no lesson named: "Dental clinics, roofers, med spas, HVAC and law firms pass."
- quote with no lesson named: "Most restaurants don't: margins are thin and a missed call is a lost $20 order, not a $2,000 job."
- quote with no lesson named: "you can find 50 of them in one city or region in under an hour."
- quote with no lesson named: "If two niches score 3/3, pick the one where you already know someone or speak their language."
- citation without a quote: Build: missed-call text-back
- quote not found: The one-outcome offer: "No tool names (no \"
- quote with no lesson named: "No guaranteed revenue. Promise the thing you control (speed, volume, coverage), not their sales."
- case check failed: contains: ['## Niche check', '## Headline', '## Price', '## Pilot and proof', '## What I need from you']
- case check failed: contains: ['## Check', '## Gaps and assumptions', '## Next step']
