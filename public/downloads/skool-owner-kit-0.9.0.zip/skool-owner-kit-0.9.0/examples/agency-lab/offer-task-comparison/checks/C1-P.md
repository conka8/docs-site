# Answer check: offer-builder-example

Deterministic checks: reliable for what they test, and nothing more. A reply can pass them all and still be wrong. Accepting it is a person's decision.

## Citations

| Lesson named | Quote | 1. Exists | 2. Right lesson | 3. Qualification | 4. Supports the claim? |
|---|---|---|---|---|---|
| Pick a niche with the 3-filter test | Score each niche you're considering: 1 point per filter. Only pick a niche that scores 3/3. | yes | yes | kept | person: does it support "Scored with"? |
| Pick a niche with the 3-filter test | Dental clinics, roofers, med spas, HVAC and law firms pass. | yes | yes | kept | person: does it support "Money leak \| 1."? |
| Pick a niche with the 3-filter test | Most restaurants don't: margins are thin and a missed call is a lost $20 order, not a $2,000 job. | yes | yes | kept | person: does it support "()* \| 0."? |
| The one-outcome offer | We [measurable outcome] for [niche] in [timeframe], without [the pain they hate]. | yes | yes | kept | person: does it support "This follows"? |
| Build: missed-call text-back | when a call is missed, the caller gets a text within 60 seconds with a booking link, and the business owner gets a summary. | yes | yes | kept | person: does it support "This matches"? |
| Pricing your first offer | Clients 1-3 ('founding clients') | yes | yes | kept | person: does it support "The ladder row for clients 1-3 is 500 to 1,000 setup and 300 to 500 monthly"? |
| Pricing your first offer | Use the higher end when one recovered lead is worth a lot to the client | yes | yes | kept | person: does it support "I chose the top of the range because of"? |
| Pricing your first offer | Never go below 300 a month. | yes | yes | kept | person: does it support "If a clinic pushes back, you can move down toward 500 setup, but never below 300 a month"? |
| The one-outcome offer | a 30-day pilot with one success metric you agree up front | yes | yes | kept | person: does it support "A 30-day pilot with one success metric agreed up front"? |

## Numbers

Unsourced (not in the lessons, the member's input or Gaps and assumptions): none

Declared as assumptions: none

## Promises

None found (checks guarantee, refund and earnings wording).

## Case checks

- [x] contains: ['## Niche check', '## Headline', '## Price', '## Pilot and proof', '## What I need from you']
- [x] contains: ['## Check', '## Gaps and assumptions', '## Next step']
- [x] The niche check shows the chosen niche scoring 3/3, or marks the check pending and lists the "?" filters the member must confirm.
- [x] It makes no guarantee of results.
- [x] max_chars: 6000

## For a person to decide

- [ ] Does each citation above support the sentence it's attached to, or is a true quote used for a different conclusion?
- [ ] Did the reply keep the lessons' limits and resolve any conflict between lessons?

**Deterministic result: pass**
