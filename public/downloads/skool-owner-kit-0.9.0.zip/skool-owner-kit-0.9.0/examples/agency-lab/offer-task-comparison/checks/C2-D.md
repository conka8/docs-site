# Answer check: C2-D-final.md

Deterministic checks: reliable for what they test, and nothing more. A reply can pass them all and still be wrong. Accepting it is a person's decision.

## Citations

| Lesson named | Quote | 1. Exists | 2. Right lesson | 3. Qualification | 4. Supports the claim? |
|---|---|---|---|---|---|
| Pricing your first offer | Never go below 300 a month. Below that, support eats your time. | yes | yes | kept | person: does it support "Dental clinics in Manchester are a much better fit, but the same price isn't fine."? |
| Pricing your first offer | Use the higher end when one recovered lead is worth a lot to the client (a dental implant, a roof, a legal case). | yes | yes | kept | person: does it support "The lesson's founding-client range (clients 1-3) is 500 to 1,000 setup and 300 to 500 monthly."? |
| Pick a niche with the 3-filter test | Dental clinics, roofers, med spas, HVAC and law firms pass. | yes | yes | kept | person: does it support "Niche score (3-filter test)"? |
| Pick a niche with the 3-filter test | you can find 50 of them in one city or region in under an hour. | yes | yes | kept | person: does it support "Reachable this week: you need to confirm this one."? |
| Pick a niche with the 3-filter test | Switching niche every week. Commit for 30 days. | yes | yes | kept | person: does it support "Also, commit to the niche."? |
| The one-outcome offer | No tool names (no | yes | yes | kept | person: does it support "30 minutes for setup"? |
| Build: missed-call text-back | test it with your own phone before you show a client. | yes | yes | kept | person: does it support ""? |

## Numbers

Unsourced (not in the lessons, the member's input or Gaps and assumptions): £150, £750

Declared as assumptions: none

## Promises

None found (checks guarantee, refund and earnings wording).

## For a person to decide

- [ ] Does each citation above support the sentence it's attached to, or is a true quote used for a different conclusion?
- [ ] Did the reply keep the lessons' limits and resolve any conflict between lessons?

**Deterministic result: fail**
- unsourced number: £150
- unsourced number: £750
