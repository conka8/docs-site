# Answer check: C2-P-final.md

Deterministic checks: reliable for what they test, and nothing more. A reply can pass them all and still be wrong. Accepting it is a person's decision.

## Citations

| Lesson named | Quote | 1. Exists | 2. Right lesson | 3. Qualification | 4. Supports the claim? |
|---|---|---|---|---|---|
| Pricing your first offer | Never go below 300 a month. | yes | yes | kept | person: does it support "£150 a month is still below the lessons' floor."? |
| Pick a niche with the 3-filter test | Score each niche you're considering: 1 point per filter. Only pick a niche that scores 3/3. | yes | yes | kept | person: does it support "Scored with"? |
| Pick a niche with the 3-filter test | Dental clinics, roofers, med spas, HVAC and law firms pass. | yes | yes | kept | person: does it support "The lesson names dental clinics as a pass."? |
| The one-outcome offer | We [measurable outcome] for [niche] in [timeframe], without [the pain they hate]. | yes | yes | kept | person: does it support "We reply to every missed call within 60 seconds for dental clinics in Manchester, without hiring a receptionist."? |
| Pricing your first offer | Never go below 300 a month. | yes | yes | kept | person: does it support "Ladder: founding clients are 500 to 1,000 setup and 300 to 500 a month"? |
| Pricing your first offer | Use the higher end when one recovered lead is worth a lot to the client (a dental implant, a roof, a legal case). | yes | yes | kept | person: does it support "Why the top of the range:"? |
| The one-outcome offer | a 30-day pilot with one success metric you agree up front | yes | yes | kept | person: does it support "30-day pilot with one success metric agreed up front"? |

## Numbers

Unsourced (not in the lessons, the member's input or Gaps and assumptions): none

Declared as assumptions: £150

## Promises

None found (checks guarantee, refund and earnings wording).

## For a person to decide

- [ ] Does each citation above support the sentence it's attached to, or is a true quote used for a different conclusion?
- [ ] Did the reply keep the lessons' limits and resolve any conflict between lessons?

**Deterministic result: pass**
