# Answer check: offer-builder-conflicting-input

Deterministic checks: reliable for what they test, and nothing more. A reply can pass them all and still be wrong. Accepting it is a person's decision.

## Citations

| Lesson named | Quote | 1. Exists | 2. Right lesson | 3. Qualification | 4. Supports the claim? |
|---|---|---|---|---|---|
| Pick a niche with the 3-filter test | Most restaurants don't: margins are thin and a missed call is a lost $20 order, not a $2,000 job. | yes | yes | kept | person: does it support "Restaurants fail the niche test"? |
| Pick a niche with the 3-filter test | Only pick a niche that scores 3/3. | yes | yes | kept | person: does it support "()"? |
| Pricing your first offer | Never go below 300 a month. Below that, support eats your time. | yes | yes | kept | person: does it support "£150 a month is below the floor"? |
| The one-outcome offer | No guaranteed revenue. Promise the thing you control (speed, volume, coverage), not their sales. | yes | yes | kept | person: does it support "You can't guarantee 20% more bookings"? |
| Pricing your first offer | No refunds promised on results you don't control. Offer the pilot instead. | yes | yes | kept | person: does it support "()"? |

## Numbers

Unsourced (not in the lessons, the member's input or Gaps and assumptions): none

Declared as assumptions: none

## Promises

None found (checks guarantee, refund and earnings wording).

## Case checks

- [x] Cites both lessons, the 300 minimum and the pilot alternative.
- [x] Asks for the missing input.

## For a person to decide

- [ ] In the second reply, is £150 still refused (below the 300 floor), rather than accepted because the niche changed?
- [ ] Does each citation above support the sentence it's attached to, or is a true quote used for a different conclusion?
- [ ] Did the reply keep the lessons' limits and resolve any conflict between lessons?

**Deterministic result: pass**
