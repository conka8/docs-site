# Answer check: offer-builder-example

Deterministic checks: reliable for what they test, and nothing more. A reply can pass them all and still be wrong. Accepting it is a person's decision.

## Citations

| Lesson named | Quote | 1. Exists | 2. Right lesson | 3. Qualification | 4. Supports the claim? |
|---|---|---|---|---|---|
| Pick a niche with the 3-filter test | Dental clinics, roofers, med spas, HVAC and law firms pass. | yes | yes | kept | person: does it support "Money leak:** pass."? |
| - | Businesses that pay for software understand paying monthly for a result. | yes | no lesson named | - | person: does it support "You say most use a CRM like Jobber."? |
| - | you can find 50 of them in one city or region in under an hour. | yes | no lesson named | - | person: does it support "You found 60 on Google Maps in about 20 minutes."? |
| The one-outcome offer | No tool names (no | yes | yes | kept | person: does it support "Also, the headline can't name tools."? |
| - | Switching niche every week. Commit for 30 days. | yes | no lesson named | - | person: does it support "Commit to roofers for 30 days."? |

## Numbers

Unsourced (not in the lessons, the member's input or Gaps and assumptions): 750, £750, 95%

Declared as assumptions: none

## Promises

None found (checks guarantee, refund and earnings wording).

## Case checks

- [ ] contains: ['## Niche check', '## Headline', '## Price', '## Pilot and proof', '## What I need from you']
- [ ] contains: ['## Check', '## Gaps and assumptions', '## Next step']
- [x] The niche check shows the chosen niche scoring 3/3, or marks the check pending and lists the "?" filters the member must confirm.
- [x] It makes no guarantee of results.
- [x] max_chars: 6000

## For a person to decide

- [ ] Does each citation above support the sentence it's attached to, or is a true quote used for a different conclusion?
- [ ] Did the reply keep the lessons' limits and resolve any conflict between lessons?

**Deterministic result: fail**
- quote with no lesson named: "Businesses that pay for software understand paying monthly for a result."
- quote with no lesson named: "you can find 50 of them in one city or region in under an hour."
- quote with no lesson named: "Switching niche every week. Commit for 30 days."
- unsourced number: 750
- unsourced number: £750
- unsourced number: 95%
- case check failed: contains: ['## Niche check', '## Headline', '## Price', '## Pilot and proof', '## What I need from you']
- case check failed: contains: ['## Check', '## Gaps and assumptions', '## Next step']
