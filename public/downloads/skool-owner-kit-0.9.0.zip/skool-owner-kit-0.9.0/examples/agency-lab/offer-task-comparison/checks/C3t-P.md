# Answer check: offer-builder-missing-facts

Deterministic checks: reliable for what they test, and nothing more. A reply can pass them all and still be wrong. Accepting it is a person's decision.

## Citations

| Lesson named | Quote | 1. Exists | 2. Right lesson | 3. Qualification | 4. Supports the claim? |
|---|---|---|---|---|---|
| Pick a niche with the 3-filter test | Dental clinics, roofers, med spas, HVAC and law firms pass. | yes | yes | kept | person: does it support "Good news first: the lessons name roofers as a niche that passes the money-leak filter"? |

## Numbers

Unsourced (not in the lessons, the member's input or Gaps and assumptions): none

Declared as assumptions: none

## Promises

None found (checks guarantee, refund and earnings wording).

## Case checks

- [x] Asks where they will sell.
- [x] Asks what they can deliver.
- [x] Doesn't draft the offer before it has the facts.

## For a person to decide

- [ ] Does it avoid assuming a city, a service or a price for the member?
- [ ] Does each citation above support the sentence it's attached to, or is a true quote used for a different conclusion?
- [ ] Did the reply keep the lessons' limits and resolve any conflict between lessons?

**Deterministic result: pass**
