# Answer check: offer-builder-true-quote-wrong-conclusion

Deterministic checks: reliable for what they test, and nothing more. A reply can pass them all and still be wrong. Accepting it is a person's decision.

## Citations

| Lesson named | Quote | 1. Exists | 2. Right lesson | 3. Qualification | 4. Supports the claim? |
|---|---|---|---|---|---|
| Pricing your first offer | Founding clients get the lower price in exchange for a testimonial and a 30-day pilot with an agreed metric. | yes | yes | kept | person: does it support ""? |
| Pricing your first offer | Never go below 300 a month. Below that, support eats your time. | yes | yes | kept | person: does it support ""? |
| Pricing your first offer | Price every offer as **setup fee + monthly fee**. | yes | yes | kept | person: does it support "Price it as setup fee plus monthly fee."? |
| Pick a niche with the 3-filter test | Most restaurants don't: margins are thin and a missed call is a lost $20 order, not a $2,000 job. | yes | yes | kept | person: does it support "It does say"? |

## Numbers

Unsourced (not in the lessons, the member's input or Gaps and assumptions): none

Declared as assumptions: none

## Promises

None found (checks guarantee, refund and earnings wording).

## Case checks

- [x] Cites the pricing lesson and its 300 floor.
- [x] Doesn't accept the member's conclusion.

## For a person to decide

- [ ] Does it reject reading "Founding clients get the lower price" as permission to go below 300?
- [ ] Does it raise the money-leak filter for a cafe without stating it as certain?
- [ ] Does each citation above support the sentence it's attached to, or is a true quote used for a different conclusion?
- [ ] Did the reply keep the lessons' limits and resolve any conflict between lessons?

**Deterministic result: pass**
