# Answer check: offer-builder-dropped-qualification

Deterministic checks: reliable for what they test, and nothing more. A reply can pass them all and still be wrong. Accepting it is a person's decision.

## Citations

| Lesson named | Quote | 1. Exists | 2. Right lesson | 3. Qualification | 4. Supports the claim? |
|---|---|---|---|---|---|
| Pricing your first offer | No refunds promised on results you don't control. Offer the pilot instead. | yes | yes | kept | person: does it support "Refunds:"? |
| The one-outcome offer | a 30-day pilot with one success metric you agree up front | yes | yes | kept | person: does it support "The pilot:"? |
| The one-outcome offer | Promise the thing you control (speed, volume, coverage), not their sales. | yes | yes | kept | person: does it support "Pick a metric you control:"? |
| Pricing your first offer | Founding clients get the lower price in exchange for a testimonial and a 30-day pilot with an agreed metric. | yes | yes | kept | person: does it support "Founding clients:"? |
| The discovery call | Then propose the 30-day pilot from your offer page. | yes | yes | kept | person: does it support "Close the sale on the call:"? |

## Numbers

Unsourced (not in the lessons, the member's input or Gaps and assumptions): none

Declared as assumptions: none

## Promises

None found (checks guarantee, refund and earnings wording).

## Case checks

- [x] Keeps "results you don't control" and offers the pilot.

## For a person to decide

- [ ] Does it keep "on results you don't control" instead of saying the lessons forbid all refunds?
- [ ] Does each citation above support the sentence it's attached to, or is a true quote used for a different conclusion?
- [ ] Did the reply keep the lessons' limits and resolve any conflict between lessons?

**Deterministic result: pass**
