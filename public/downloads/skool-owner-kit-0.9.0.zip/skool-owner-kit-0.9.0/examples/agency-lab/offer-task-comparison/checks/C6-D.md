# Answer check: offer-builder-not-covered-contract

Deterministic checks: reliable for what they test, and nothing more. A reply can pass them all and still be wrong. Accepting it is a person's decision.

## Citations

| Lesson named | Quote | 1. Exists | 2. Right lesson | 3. Qualification | 4. Supports the claim? |
|---|---|---|---|---|---|
| Pricing your first offer | - | no passage | - | - | person: does it support "Price:** "Price every offer as **setup fee + monthly fee**.""? |
| The one-outcome offer | - | no passage | - | - | person: does it support "Pilot:** "a 30-day pilot with one success metric you agree up front""? |
| Pricing your first offer | - | no passage | - | - | person: does it support "Founding clients:** they "get the lower price in exchange for a testimonial and a 30-day pilot with an agreed metric.""? |
| Pricing your first offer | - | no passage | - | - | person: does it support "Offer the pilot instead.""? |
| The one-outcome offer | - | no passage | - | - | person: does it support "What you need from them:** "logins, a contact person, 30 minutes for setup""? |

## Numbers

Unsourced (not in the lessons, the member's input or Gaps and assumptions): none

Declared as assumptions: none

## Promises

None found (checks guarantee, refund and earnings wording).

## Case checks

- [x] Says it isn't covered.
- [ ] Drafts a question the member can post for a coach.

## For a person to decide

- [ ] Is any contract content labelled as its own suggestion, with no legal claim stated as fact?
- [ ] Could a coach answer the drafted question without asking anything back (task, lessons checked, what's decided, the exact question)?
- [ ] Does each citation above support the sentence it's attached to, or is a true quote used for a different conclusion?
- [ ] Did the reply keep the lessons' limits and resolve any conflict between lessons?

**Deterministic result: fail**
- citation without a quote: Pricing your first offer
- citation without a quote: The one-outcome offer
- citation without a quote: Pricing your first offer
- citation without a quote: Pricing your first offer
- citation without a quote: The one-outcome offer
- case check failed: Drafts a question the member can post for a coach.
