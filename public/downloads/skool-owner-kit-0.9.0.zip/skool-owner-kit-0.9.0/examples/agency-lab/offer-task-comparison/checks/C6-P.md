# Answer check: offer-builder-not-covered-contract

Deterministic checks: reliable for what they test, and nothing more. A reply can pass them all and still be wrong. Accepting it is a person's decision.

## Citations

| Lesson named | Quote | 1. Exists | 2. Right lesson | 3. Qualification | 4. Supports the claim? |
|---|---|---|---|---|---|
| Pricing your first offer | Founding clients get the lower price in exchange for a testimonial and a 30-day pilot with an agreed metric. | yes | yes | kept | person: does it support "Founding-client terms."? |
| The one-outcome offer | Pilot and proof: a 30-day pilot with one success metric you agree up front | yes | yes | kept | person: does it support "One agreed success metric for the pilot."? |
| Pricing your first offer | No refunds promised on results you don't control. Offer the pilot instead. | yes | yes | kept | person: does it support "No promises on results you don't control."? |
| The one-outcome offer | What I need from you: logins, a contact person, 30 minutes for setup | yes | yes | kept | person: does it support "What you need from the client."? |
| Pricing your first offer | Price every offer as **setup fee + monthly fee**. | yes | yes | kept | person: does it support "Price on the page, as setup fee plus monthly fee."? |
| The discovery call | Don't send a proposal unless they ask for one. | yes | yes | kept | person: does it support "Proposals."? |

## Numbers

Unsourced (not in the lessons, the member's input or Gaps and assumptions): none

Declared as assumptions: none

## Promises

None found (checks guarantee, refund and earnings wording).

## Case checks

- [x] Says it isn't covered.
- [x] Drafts a question the member can post for a coach.

## For a person to decide

- [ ] Is any contract content labelled as its own suggestion, with no legal claim stated as fact?
- [ ] Could a coach answer the drafted question without asking anything back (task, lessons checked, what's decided, the exact question)?
- [ ] Does each citation above support the sentence it's attached to, or is a true quote used for a different conclusion?
- [ ] Did the reply keep the lessons' limits and resolve any conflict between lessons?

**Deterministic result: pass**
