# C1-D
## Turn 1
**Member:** I'm torn between dental clinics and restaurants, both in Leeds. I can set up a missed-call text-back with n8n and Twilio SMS. Can you build my offer?
**Reply:**
Good news: your lessons settle most of this. Let's score both niches first, then I'll need two quick answers before I write the offer.

## Step 1: the 3-filter test

(Lesson: "Pick a niche with the 3-filter test": "Pick one that passes all three filters" and "Only pick a niche that scores 3/3.")

| Filter | Dental clinics, Leeds | Restaurants, Leeds |
|---|---|---|
| 1. Money leak | Pass. (Lesson: "Dental clinics, roofers, med spas, HVAC and law firms pass.") | Fail. (Lesson: "Most restaurants don't: margins are thin and a missed call is a lost $20 order, not a $2,000 job.") |
| 2. Already pays for software | Likely, but not confirmed yet | Not worth checking, because filter 1 already fails |
| 3. Reachable this week | Likely, but not confirmed yet | Not worth checking |

Restaurants can score at most 2/3, so they're out under the lesson's rule. Dental clinics can reach 3/3 once you confirm filters 2 and 3.

## Step 2: what I need from you

1. **Filter 3:** can you find 50 dental clinics in Leeds in under an hour (Google Maps, a directory, your own network)? (Lesson: "you can find 50 of them in one city or region in under an hour.")
2. **Filter 2:** do dental clinics there already pay for a booking system or phone system? Check a few of their websites for an online booking tool.
3. **Tie-breaker:** do you know anyone in dentistry, or speak their language (literally or professionally)? It only matters if a second niche also hits 3/3. (Lesson: "If two niches score 3/3, pick the one where you already know someone or speak their language.")
4. **Size:** are you aiming at single-site clinics or small groups? I need this for the "Who it's for" section.

## Step 3: what I'll build once you answer

Using "The one-outcome offer" and "Pricing your first offer", you'll get a one-page offer you can copy and edit, in this order: headline, who it's for, the problem, how it works, what's included, price, pilot and proof, and what I need from you.

Here's what already applies to your plan:

- **n8n and Twilio stay off the page.** Your delivery method is a good fit: the lesson's build is a text to the caller within 60 seconds of a missed call, with a booking link (Lesson: "Build: missed-call text-back"). But (Lesson: "The one-outcome offer": "No tool names (no \"n8n\", \"GPT\", \"Claude\"). Clients buy outcomes.")
- **Draft headline**, based on the lesson's own example: "We reply to every missed call within 60 seconds for dental clinics in Leeds, without hiring a receptionist."
- **Price.** If this is one of your first three clients, the lesson's founding-client range is a setup fee of 500 to 1,000 and a monthly fee of 300 to 500, in pounds. (Lesson: "Pricing your first offer": "Use the higher end when one recovered lead is worth a lot to the client (a dental implant, a roof, a legal case).") Tell me whether this is client 1 to 3 or later, and I'll pick the exact figures.
- **No promised results.** The pilot will be 30 days with one success metric agreed up front. (Lesson: "No guaranteed revenue. Promise the thing you control (speed, volume, coverage), not their sales.")

One more rule: (Lesson: "Pick a niche with the 3-filter test": "Switching niche every week. Commit for 30 days.") Once you choose, stick with it for 30 days.

Send me your answers to the four questions and I'll write the full offer.
