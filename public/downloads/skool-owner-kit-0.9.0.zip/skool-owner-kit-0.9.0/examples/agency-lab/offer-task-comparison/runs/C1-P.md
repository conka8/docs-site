# C1-P
## Turn 1
**Member:** I'm torn between dental clinics and restaurants, both in Leeds. I can set up a missed-call text-back with n8n and Twilio SMS. Can you build my offer?
**Reply:**
Restaurants are one of the two niches you're torn between, so I'll say this first. The lessons say most of them fail filter 1, so I haven't written an offer for them. Dental clinics are the likely pick, and the draft below is for them. It is marked pending until you confirm two filters.

## Niche check

Scored with *(Lesson: "Pick a niche with the 3-filter test": "Score each niche you're considering: 1 point per filter. Only pick a niche that scores 3/3.")*

| Filter | Dental clinics, Leeds | Restaurants, Leeds |
|---|---|---|
| 1. Money leak | 1. *(Lesson: "Pick a niche with the 3-filter test": "Dental clinics, roofers, med spas, HVAC and law firms pass.")* | 0. *(Lesson: "Pick a niche with the 3-filter test": "Most restaurants don't: margins are thin and a missed call is a lost $20 order, not a $2,000 job.")* |
| 2. Already pays for software | ? Not stated in the lessons or by you | ? |
| 3. Reachable this week | ? Not yet checked | ? |
| **Score** | **1 + 2 unconfirmed** | **0 + 2 unconfirmed** |

Status: **pending**. Dental clinics are the only candidate that can reach 3/3, so restaurants are out. Please confirm filters 2 and 3 before you post (see Next step). Commit to the niche for 30 days once it passes.

## Headline

We reply to every missed call within 60 seconds for dental clinics in Leeds, without hiring a receptionist.

This follows *(Lesson: "The one-outcome offer": "We [measurable outcome] for [niche] in [timeframe], without [the pain they hate].")* It has one niche and one countable outcome, with no tool names and no promise about their revenue.

## Who it's for

Dental clinics in Leeds that miss calls when the team is with patients, and that already use a booking or phone system. [Confirm the size of clinic you're targeting.]

## The problem

When the team is with a patient, the phone rings out. [Replace with a quote from a real Leeds clinic in their own words.]

## How it works

1. Someone calls your clinic and nobody picks up.
2. Within 60 seconds they get a text with a booking link.
3. You get a summary of the missed call, so your team can follow up.

This matches *(Lesson: "Build: missed-call text-back": "when a call is missed, the caller gets a text within 60 seconds with a booking link, and the business owner gets a summary.")*

## What's included

- Setup of the missed-call text-back on your clinic's number
- The automation running every month
- A monthly check-in

## Price

**Founding client offer: [£]1,000 setup + [£]500 a month.**

Where it comes from:
- The ladder row for clients 1-3 is 500 to 1,000 setup and 300 to 500 monthly *(Lesson: "Pricing your first offer": "Clients 1-3 ('founding clients')")*.
- I chose the top of the range because of *(Lesson: "Pricing your first offer": "Use the higher end when one recovered lead is worth a lot to the client")*. Its examples include a dental implant, which is why I picked this point. It is my reading of that sentence.
- Founding clients get the lower price in exchange for a testimonial and the 30-day pilot below. If a clinic pushes back, you can move down toward 500 setup, but never below 300 a month *(Lesson: "Pricing your first offer": "Never go below 300 a month.")*.

## Pilot and proof

A 30-day pilot with one success metric agreed up front *(Lesson: "The one-outcome offer": "a 30-day pilot with one success metric you agree up front")*. My suggestion, not from the lessons: the share of missed calls that get a text within 60 seconds. It measures speed and coverage, which you control, not their sales. Nothing here guarantees revenue or results.

## What I need from you

- Access to your phone system or number settings
- One contact person at the clinic
- 30 minutes for setup

## Check

- Required headings present: pass.
- Check, Gaps and assumptions, Next step present: pass.
- Niche check shows 3/3 or pending with "?" listed: pass (pending; filters 2 and 3 are listed).
- No guarantee of results: pass.
- At most 6000 characters: pass.
- Follows and cites the lessons, nothing invented: pass.
- Money and behaviour claims sourced: pass. The prices come from the ladder.

## Gaps and assumptions

- Verify before use: filter 2. Nothing in the lessons or your input says dental clinics in Leeds pay for a booking or phone system.
- Verify before use: filter 3. Check you can find 50 dental clinics in Leeds in under an hour (Google Maps, a directory). If you can't, the niche fails.
- Verify before use: the problem line is a placeholder. Replace it with what clinics actually say.
- Assumed currency: pounds, since you're in Leeds. The lessons say local currency, so I put it in [brackets].
- You said you can set up a missed-call text-back with n8n and Twilio SMS. I left tool names off the page because the lessons say clients buy outcomes. The 60-second figure comes from the lessons' example headline, not from your results.
- Conflict with the lessons: restaurants fail filter 1, so I followed the lesson and picked dental clinics.

## Next step

Confirm filters 2 and 3 today: find 50 dental clinics in Leeds on Google Maps in under an hour, and check on your first calls whether they pay for a booking or phone system. Then change the niche check to 3/3.

**Question for a coach:** none needed unless filter 2 or 3 fails. If it does, post in Help with your niche, Leeds, the lesson "Pick a niche with the 3-filter test" and which filter failed.
