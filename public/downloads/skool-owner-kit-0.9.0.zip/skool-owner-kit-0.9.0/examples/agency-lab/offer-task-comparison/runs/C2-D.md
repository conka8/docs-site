# C2-D
## Turn 1
**Member:** Build my offer for restaurants in Manchester. I'll charge £150 a month so it's an easy yes, and I want to guarantee them 20% more bookings in the first month.
**Reply:**
I can't build this one as planned, because three parts conflict with the lessons. Here is each one, with the lesson's version.

**1. Restaurants fail the niche test**
(Lesson: "Pick a niche with the 3-filter test": "Most restaurants don't: margins are thin and a missed call is a lost $20 order, not a $2,000 job.")
(Lesson: "Pick a niche with the 3-filter test": "Only pick a niche that scores 3/3.")

Restaurants in Manchester are reachable (filter 3), but they are weak on the money leak (filter 1). The lesson lists the niches that pass: "Dental clinics, roofers, med spas, HVAC and law firms pass."

**2. £150 a month is below the floor**
(Lesson: "Pricing your first offer": "Never go below 300 a month. Below that, support eats your time.")

The founding-client range is 500 to 1,000 setup and 300 to 500 monthly. Price is always setup fee plus monthly fee. A low price doesn't make it an easy yes. It only leaves you without enough income to support the client.

**3. You can't guarantee 20% more bookings**
(Lesson: "The one-outcome offer": "No guaranteed revenue. Promise the thing you control (speed, volume, coverage), not their sales.")
(Lesson: "Pricing your first offer": "No refunds promised on results you don't control. Offer the pilot instead.")

I also can't promise results, and I have no figure to back a 20% claim. The lesson's version is to promise something you control, such as replying to every missed call within 60 seconds. Then run a 30-day pilot with one success metric you agree up front.

**Before I write your offer, I need from you:**
1. Which niches are you considering besides restaurants? Pick two or three, ideally ones you know someone in or understand well.
2. Which city or area do you want to target? Manchester?
3. What can you deliver today? (The lessons cover a missed-call text-back build; tell me if that's what you'll offer.)

Once you answer, I'll score each niche out of 3 and write the one-page offer, under 400 words, with the price on the page, for you to copy and edit.

## Turn 2
**Member:** ok fair enough. I can set up a missed-call text-back with n8n and Twilio. let's do dental clinics in Manchester instead, same price is fine right?
**Reply:**
Dental clinics in Manchester are a much better fit, but the same price isn't fine.

(Lesson: "Pricing your first offer": "Never go below 300 a month. Below that, support eats your time.")

£150 a month is half the minimum. The lesson's founding-client range (clients 1-3) is 500 to 1,000 setup and 300 to 500 monthly. (Lesson: "Pricing your first offer": "Use the higher end when one recovered lead is worth a lot to the client (a dental implant, a roof, a legal case).") A dental lead can be worth a lot, so the upper half of the range is reasonable. Picking exact numbers within the range is my own suggestion: **£750 setup + £400 a month**. Change them if you like, but stay inside the ranges.

**Niche score (3-filter test)**
(Lesson: "Pick a niche with the 3-filter test": "Dental clinics, roofers, med spas, HVAC and law firms pass.")
- Money leak: 1/1. Dental clinics are on the lesson's passing list.
- Already pays for software: 1/1. The lesson counts dental as passing, and most clinics have a booking or phone system. Check this on your first calls.
- Reachable this week: you need to confirm this one. (Lesson: "Pick a niche with the 3-filter test": "you can find 50 of them in one city or region in under an hour.") Try Google Maps for "dental clinic Manchester" and see if you reach 50. If you can, it's 3/3.

Also, commit to the niche. (Lesson: "Pick a niche with the 3-filter test": "Switching niche every week. Commit for 30 days.")

**Your one-page offer (copy and edit)**

# We reply to every missed call within 60 seconds for dental clinics in Manchester, without hiring a receptionist

**Who it's for**
Independent dental clinics in Manchester with a busy front desk and a booking system already in place.

**The problem**
When the phone rings out during a treatment or a lunch break, the caller often rings the next clinic. [Edit this into your prospect's own words after your first conversations.]

**How it works**
1. A call to your clinic goes unanswered.
2. Within 60 seconds the caller gets a text with a link to book.
3. You get a short summary of who called and whether they booked.

**What's included**
- Setup and testing on your number
- The automatic text-back, running every day
- A monthly check-in to review the numbers

**Price**
£750 one-off setup + £400 a month.

**Pilot and proof**
A 30-day pilot with one success metric we agree up front, for example: "every missed call receives a text within 60 seconds." That is something I control. I don't promise bookings or revenue.

**What I need from you**
- Access to your phone and booking system
- One contact person
- 30 minutes for setup

(Lesson: "The one-outcome offer": "No tool names (no "n8n", "GPT", "Claude"). Clients buy outcomes." I've kept n8n and Twilio off the page.)

**Next steps**
- (Lesson: "Build: missed-call text-back": "test it with your own phone before you show a client.") Import the template and test it first.
- Since you're a founding client seller, the lesson says: "Founding clients get the lower price in exchange for a testimonial and a 30-day pilot with an agreed metric." Add the testimonial ask when you pitch client 1.
- If you want help with the pitch or the discovery call, ask me and I'll use those lessons.
