# C2-P
## Turn 1
**Member:** Build my offer for restaurants in Manchester. I'll charge £150 a month so it's an easy yes, and I want to guarantee them 20% more bookings in the first month.
**Reply:**
I can't build this as asked. Three things conflict with the lessons:

1. **Restaurants fail the niche test.** *(Lesson: "Pick a niche with the 3-filter test": "Most restaurants don't: margins are thin and a missed call is a lost $20 order, not a $2,000 job.")* The lesson says to only pick a niche that scores 3/3, so I won't write an offer for restaurants. The lesson names dental clinics, roofers, med spas, HVAC and law firms as passing.
2. **£150 a month is too low.** *(Lesson: "Pricing your first offer": "Never go below 300 a month.")* Founding clients are 500 to 1,000 setup and 300 to 500 a month, plus a setup fee.
3. **A 20% bookings guarantee isn't allowed.** *(Lesson: "The one-outcome offer": "No guaranteed revenue. Promise the thing you control (speed, volume, coverage), not their sales.")* Also *(Lesson: "Pricing your first offer": "No refunds promised on results you don't control. Offer the pilot instead.")* The lessons' alternative is a 30-day pilot with one metric you agree up front.

To go ahead, I only need one thing: **What can you set up for a client today (an automation, a chatbot, a booking flow)?**

## Turn 2
**Member:** ok fair enough. I can set up a missed-call text-back with n8n and Twilio. let's do dental clinics in Manchester instead, same price is fine right?
**Reply:**
No, the same price isn't fine. £150 a month is still below the lessons' floor. *(Lesson: "Pricing your first offer": "Never go below 300 a month.")* I've used £1,000 setup + £500 a month, explained under Price. Dental clinics pass filter 1, but I can't confirm filters 2 and 3 yet, so the niche check is pending and the draft has [brackets].

## Niche check

Scored with *(Lesson: "Pick a niche with the 3-filter test": "Score each niche you're considering: 1 point per filter. Only pick a niche that scores 3/3.")*

| Filter | Dental clinics, Manchester |
|---|---|
| 1. Money leak | 1. The lesson names dental clinics as a pass. *(Lesson: "Pick a niche with the 3-filter test": "Dental clinics, roofers, med spas, HVAC and law firms pass.")* |
| 2. Already pays for software | ? Not stated in the lessons or by you |
| 3. Reachable this week | ? Not checked yet |
| **Score** | **1/3 confirmed, 2 pending** |

Status: pending. Confirm filters 2 and 3 before you post (see Gaps). Restaurants are dropped: they fail filter 1.

## Headline

We reply to every missed call within 60 seconds for dental clinics in Manchester, without hiring a receptionist. *(Lesson: "The one-outcome offer": "We [measurable outcome] for [niche] in [timeframe], without [the pain they hate].")*

## Who it's for

Dental clinics in Manchester [confirm size, e.g. number of dentists] that miss calls when the team is with patients, and already pay for a booking or phone system [confirm].

## The problem

When nobody picks up, the caller may ring another clinic. [Replace with a quote from a Manchester clinic in their own words.]

## How it works

1. Someone calls your clinic and nobody picks up.
2. Within 60 seconds they get a text from your number with a booking link.
3. You get a summary and your team follows up.

## What's included

- Setup of the missed-call text reply on your number
- The automation running every month
- A monthly check-in to review the numbers

## Price

**Founding client offer: £1,000 setup + £500 a month.**

- Ladder: founding clients are 500 to 1,000 setup and 300 to 500 a month *(Lesson: "Pricing your first offer": "Never go below 300 a month.")*
- Why the top of the range: *(Lesson: "Pricing your first offer": "Use the higher end when one recovered lead is worth a lot to the client (a dental implant, a roof, a legal case).")*
- Currency: pounds, since you said £. This is my suggestion; you can move toward £500 setup, never below £300 a month.

## Pilot and proof

30-day pilot with one success metric agreed up front *(Lesson: "The one-outcome offer": "a 30-day pilot with one success metric you agree up front")*. Suggested metric (my suggestion): the share of missed calls that get a text within 60 seconds. It measures speed and coverage, which you control. No promise about bookings or revenue.

## What I need from you

- Access to your phone system or number settings
- One contact person
- 30 minutes for setup

## Check

- Required headings: pass.
- Check, Gaps and assumptions, Next step: pass.
- Niche 3/3 or pending with "?" listed: pass (pending; filters 2 and 3).
- No guarantee of results: pass.
- Under 6000 characters: pass.
- Follows and cites lessons: pass. The 60 seconds comes from the lesson's example headline.
- Numbers sourced or listed in Gaps: pass.

## Gaps and assumptions

- Same price: no. Your £150 is below the lessons' floor, so I used £1,000 + £500 instead.
- Verify before use, filter 2: the lessons don't say dental clinics pay for booking or phone software. Confirm it.
- Verify before use, filter 3: check you can find 50 Manchester dental clinics in under an hour.
- Verify before use: the problem line (callers ring another clinic) is my wording, not from the lessons.
- Assumed currency: £.
- Tool names (n8n, Twilio) are left off the page because clients buy outcomes. Your setup is what makes the offer deliverable.
- The 20% booking guarantee is dropped (see my earlier message).

## Next step

Confirm filters 2 and 3 for Manchester dental clinics today (find 50 on Google Maps; check they use booking or phone software). Then post the offer in Wins and start the outreach-sprint skill.
