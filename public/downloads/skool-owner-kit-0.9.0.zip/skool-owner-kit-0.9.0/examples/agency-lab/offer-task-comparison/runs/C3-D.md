# C3-D
## Turn 1
**Member:** Write my offer for roofers.
**Reply:**
Happy to. Roofers are a good candidate, and I need two things from you before I write the offer.

(Lesson: "Pick a niche with the 3-filter test": "Money leak: the business loses real money when a lead goes unanswered (a missed call, a slow reply, a no-show). Dental clinics, roofers, med spas, HVAC and law firms pass.")

So roofers pass filter 1. Filters 2 and 3 depend on your area, and the offer headline needs it too (the lesson's example is "dental clinics in Leeds", not just "dental clinics"):

1. **Which city or region will you sell in?** (Filter 3: "you can find 50 of them in one city or region in under an hour.")
2. **What can you deliver?** Which automation can you build and test today? For example, can you set up the missed-call text-back from our build lesson, and with which phone and SMS tools?

Also helpful, but optional:
- Do the roofers you'd target already pay for software such as a CRM, booking or phone system? (Filter 2.)
- Do you already know any roofers, or speak their language?

Send me those answers and I'll write a one-page offer you can copy and edit, using the one-outcome offer and pricing lessons.

## Turn 2
**Member:** Leeds. I can set up a missed-call text-back with n8n and Twilio SMS. Most roofers I know already use a CRM like Jobber, and I found 60 of them on Google Maps in about 20 minutes.
**Reply:**
Thanks, that's what I needed. Roofers in Leeds score 3/3 on the 3-filter test:

1. **Money leak:** pass. (Lesson: "Pick a niche with the 3-filter test": "Dental clinics, roofers, med spas, HVAC and law firms pass.")
2. **Already pays for software:** pass. You say most use a CRM like Jobber. (Lesson: "Businesses that pay for software understand paying monthly for a result.")
3. **Reachable this week:** pass. You found 60 on Google Maps in about 20 minutes. (Lesson: "you can find 50 of them in one city or region in under an hour.")

Pricing note: the lessons give a range, not one number. Founding clients (1-3) pay 500 to 1,000 setup and 300 to 500 monthly. Two rules pull in different directions. "Use the higher end when one recovered lead is worth a lot to the client (a dental implant, a roof, a legal case)", and "Founding clients get the lower price in exchange for a testimonial and a 30-day pilot with an agreed metric." The figures below (750 setup, 400 monthly) are my own suggestion, a middle point inside the range. Change them within the range if you prefer. Never go below 300 a month.

Also, the headline can't name tools. (Lesson: "The one-outcome offer": "No tool names (no "n8n", "GPT", "Claude"). Clients buy outcomes.") I've left n8n and Twilio out of the offer.

---

## One-page offer (copy and edit)

**We text back every missed call within 60 seconds for roofers in Leeds, without hiring a receptionist.**

**Who it's for**
Leeds roofing companies with 2 to 15 staff who miss calls while crews are on site. *(Edit to match who you target.)*

**The problem**
"I'm up on a roof, I can't answer, and by the time I call back they've rung someone else." Every unanswered call is a possible roof job going to a competitor.

**How it works**
1. A call to your business number goes unanswered.
2. Within 60 seconds the caller gets a text with a link to book a callback or survey.
3. You get a short summary of who called and when.

**What's included**
- Setup and testing on your number
- The missed-call text-back automation
- A monthly check-in

**Price**
£750 setup + £400 per month. *(Founding-client price, in exchange for a testimonial and the pilot below.)*

**Pilot and proof**
30-day pilot. We agree one success metric up front, for example: "95% of missed calls get a text within 60 seconds." I can't promise how many jobs you win. I control speed and coverage, so that's what we measure.

**What I need from you**
- Access to your phone number or phone system settings
- One contact person
- 30 minutes for setup

---

**Next steps (my suggestions, not from the lessons):**
- Check that the missed-call text-back will work with how these roofers take calls (mobile, landline, or a phone system). The lesson says to "test it with your own phone before you show a client."
- The lessons don't say whether the automation connects to Jobber or other CRMs. If you want that as part of the offer, ask in the Help channel and tag a coach if nobody answers within a day.
- Commit to roofers for 30 days. (Lesson: "Switching niche every week. Commit for 30 days.")
