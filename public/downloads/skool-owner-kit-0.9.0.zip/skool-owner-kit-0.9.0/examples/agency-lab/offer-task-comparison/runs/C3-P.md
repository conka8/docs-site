# C3-P
## Turn 1
**Member:** Write my offer for roofers.
**Reply:**
Good news first: the lessons name roofers as a niche that passes the money-leak filter *(Lesson: "Pick a niche with the 3-filter test": "Dental clinics, roofers, med spas, HVAC and law firms pass.")*. I need two things before I can write the offer:

1. Which city or region will you sell in?
2. What can you set up for a client today (an automation, a chatbot, a booking flow)?

## Turn 2
**Member:** Leeds. I can set up a missed-call text-back with n8n and Twilio SMS. Most roofers I know already use a CRM like Jobber, and I found 60 of them on Google Maps in about 20 minutes.
**Reply:**
## Niche check

Scored with *(Lesson: "Pick a niche with the 3-filter test": "Score each niche you're considering: 1 point per filter.")*

| Filter | Roofers, Leeds |
|---|---|
| 1. Money leak | 1. *(Lesson: "Pick a niche with the 3-filter test": "Dental clinics, roofers, med spas, HVAC and law firms pass.")* |
| 2. Already pays for software | 1. You said most roofers you know already use a CRM like Jobber. |
| 3. Reachable this week | 1. You said you found 60 on Google Maps in about 20 minutes. The lesson asks for 50 in under an hour. |
| **Score** | **3/3** |

Roofers score 3/3, so the offer below is for them. *(Lesson: "Pick a niche with the 3-filter test": "Only pick a niche that scores 3/3.")*

## Headline

We reply to every missed call within 60 seconds for roofers in Leeds, without you stopping work on a roof to answer the phone. *(Lesson: "The one-outcome offer": "We [measurable outcome] for [niche] in [timeframe], without [the pain they hate].")*

Headline rules: one niche, one countable outcome, no tool names, no promise about their revenue. The 60 seconds comes from the lessons' example; the "without..." wording is my suggestion, not from the lessons.

## Who it's for

Roofing businesses in Leeds that already use a CRM such as Jobber and miss calls while the team is on site.

## The problem

When the crew is on a roof, calls go unanswered and the caller may ring another roofer. That is my suggestion, not from the lessons. Replace it with how Leeds roofers describe it in their own words.

## How it works

1. Someone calls your business and nobody picks up.
2. Within 60 seconds they get a text with a booking link.
3. You get a summary of the missed call.

## What's included

- Setup on your business number
- The text-back running every month
- A monthly check-in

## Price

**Founding client offer: [£]1,000 setup + [£]500 a month.**

Where it comes from: the ladder row for clients 1-3 is 500 to 1,000 setup and 300 to 500 a month. *(Lesson: "Pricing your first offer": "Use the higher end when one recovered lead is worth a lot to the client (a dental implant, a roof, a legal case).")* A roof is the lesson's own example, so I chose the top of the range. Founding clients get this price in exchange for a testimonial and the pilot below. *(Lesson: "Pricing your first offer": "Founding clients get the lower price in exchange for a testimonial and a 30-day pilot with an agreed metric.")* You can go down toward 500 setup if needed, but not below 300 a month. *(Lesson: "Pricing your first offer": "Never go below 300 a month.")* I don't know your currency for sure, so confirm it.

## Pilot and proof

*(Lesson: "The one-outcome offer": "Pilot and proof: a 30-day pilot with one success metric you agree up front")*

Suggested metric (my suggestion): the share of missed calls that get a text within 60 seconds. It is speed and coverage, which you control. No results or revenue are promised. *(Lesson: "The one-outcome offer": "No guaranteed revenue. Promise the thing you control (speed, volume, coverage), not their sales.")*

## What I need from you

- Access to your phone system or number settings
- One contact person
- 30 minutes for setup

## Check

- Required headings present: pass.
- Check, Gaps and assumptions, Next step present: pass.
- Chosen niche shows 3/3: pass.
- No guarantee of results: pass.
- At most 6000 characters: pass.
- Recommendations follow and cite the lessons, nothing invented: pass.
- Money and behaviour claims sourced or listed in Gaps: pass.

## Gaps and assumptions

- Verify before use: filters 2 and 3 rest on what you told me. Check that the roofers you called "already using a CRM" really pay for it, and that the 60 you found are real roofers in Leeds.
- Verify before use: the idea that callers ring another roofer after a missed call is my wording, not from the lessons.
- Assumed currency: pounds, since you're in Leeds. I left it as [£]; confirm.
- Your Jobber point supports filter 2. I left the tools (n8n, Twilio) out of the page because clients buy outcomes.

## Next step

Post the offer in Wins today, then start the outreach-sprint skill. Add "#firstwin" once you have also sent 20 outreach messages.
