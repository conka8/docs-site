# C4-D
## Turn 1
**Member:** My first client is a small cafe and they can only stretch to £100 a month. The pricing lesson says founding clients get the lower price, so £100 is fine, right?
**Reply:**
Not quite. £100 a month conflicts with the pricing lesson, so here is the lesson's version.

**What the lesson says**

- The founding-client range is a monthly fee of 300 to 500, plus a setup fee of 500 to 1,000. (Lesson: "Pricing your first offer": "Clients 1-3 ("founding clients") | 500 to 1,000 | 300 to 500")
- "The lower price" means the low end of that range, which is 300. It doesn't mean going below the range. (Lesson: "Pricing your first offer": "Never go below 300 a month. Below that, support eats your time.")
- The price also isn't a straight discount. (Lesson: "Pricing your first offer": "Founding clients get the lower price in exchange for a testimonial and a 30-day pilot with an agreed metric.")
- Price every offer as setup fee plus monthly fee. (Lesson: "Pricing your first offer": "Price every offer as **setup fee + monthly fee**. Never only one-off: the monthly fee is your business.")

**What this means for your cafe**

- The lowest founding-client offer you can make is a 500 setup fee and 300 a month, with a testimonial and a 30-day pilot with an agreed metric.
- Amounts are in your local currency, so use £ figures. The lesson also says the higher end of a range fits clients where one recovered lead is worth a lot. A cafe may sit at the low end, but I can't judge that from the lessons.
- Put the price on the offer page. (Lesson: "Pricing your first offer": "Write the price on the offer page. "Contact us for pricing" kills first conversations.")

**If the cafe really can't afford 300 a month**

The lessons don't say how to handle a client who is below the price floor. My own suggestion, not from the lessons: treat this as a sign the cafe may not be the right first client. Check it against the 3-filter test in "Pick a niche with the 3-filter test". You could also ask in the Help channel and tag a coach if nobody answers within a day.

**To build the offer, I need to know:**

1. What can you deliver for the cafe? Is it the missed-call text-back, or something else?
2. Which city or area are the cafe and you in?
3. What metric could you agree on for the 30-day pilot?

Once I have those, I'll write a one-page offer you can copy and edit.
