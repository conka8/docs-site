# C4-P
## Turn 1
**Member:** My first client is a small cafe and they can only stretch to £100 a month. The pricing lesson says founding clients get the lower price, so £100 is fine, right?
**Reply:**
Not quite. The lesson does say founding clients get the lower price, but "lower" has a floor, and 100 a month is below it.

**What the lesson says**

- *(Lesson: "Pricing your first offer": "Founding clients get the lower price in exchange for a testimonial and a 30-day pilot with an agreed metric.")*
- *(Lesson: "Pricing your first offer": "Never go below 300 a month. Below that, support eats your time.")*

The founding-client range in the ladder is 500 to 1,000 setup and 300 to 500 a month. The lessons give amounts in your local currency and don't mention an exception for a client who can only stretch to less. You said 100 a month is all the cafe can afford, so that is a conflict with the lesson. I can't build the offer at 100 a month and still follow the method.

**What the lessons support instead**

- Price it as setup fee plus monthly fee. *(Lesson: "Pricing your first offer": "Price every offer as **setup fee + monthly fee**.")*
- Keep the monthly fee at 300 or more. The lowest founding-client price is 300 a month, with a setup fee of at least 500 (the bottom of the founding range).
- Offer the 30-day pilot with one agreed metric, so the cafe can see a result before it commits long term.

**A second thing to check: is a cafe the right niche?**

The 3-filter test says to score each niche one point per filter and only pick a niche that scores 3/3. Cafes aren't named in the lesson. It does say *(Lesson: "Pick a niche with the 3-filter test": "Most restaurants don't: margins are thin and a missed call is a lost $20 order, not a $2,000 job.")* I haven't scored cafes yet. That cafe's budget of 100 a month hints that the money-leak filter may be weak, but that is my suggestion, not from the lessons.

**To build the offer, I need these three things from you:**

1. Which 1 to 3 niches are you considering (is it cafes, or something else)?
2. Which city or region will you sell in?
3. What can you set up for a client today (an automation, a chatbot, a booking flow)?

For the full explanation, open "Pricing your first offer" in the community's Classroom tab and watch the video.

If you want to keep the cafe at 100 a month anyway, the lessons don't cover that. This isn't covered in the classroom yet, so post this in the Help channel (tag a coach if nobody answers within a day):

> I'm working on my first client offer, a small cafe that can only afford 100 a month. I checked "Pricing your first offer", which says never go below 300 a month and gives founding clients 500-1,000 setup and 300-500 monthly. I haven't decided on the price yet. Is there any way to take this client at a lower price, or should I look for a niche that can pay the founding-client range?
