# C5-D
## Turn 1
**Member:** Can I offer my first client their money back if it doesn't work, so they feel safe signing?
**Reply:**
I'd steer you away from a money-back guarantee. The lessons give you a different way to make a first client feel safe.

**What the lesson says**

(Lesson: "Pricing your first offer": "No refunds promised on results you don't control. Offer the pilot instead.")

Whether "it works" depends on things like the client's staff, their calls and their market. Those are mostly outside your control, so this rule applies.

**What to offer instead: the 30-day pilot**

(Lesson: "The one-outcome offer": "Pilot and proof: a 30-day pilot with one success metric you agree up front")

The pilot removes most of the risk for the client:
- It runs for 30 days, so they aren't committing to a long contract on day one.
- You agree one success metric with them before you start, so "does it work?" has a clear answer.
- Founding clients get the lower price in exchange for it. (Lesson: "Pricing your first offer": "Founding clients get the lower price in exchange for a testimonial and a 30-day pilot with an agreed metric.")

**Promise what you control**

(Lesson: "The one-outcome offer": "No guaranteed revenue. Promise the thing you control (speed, volume, coverage), not their sales.")

Make the pilot metric something you control, such as "every missed call gets a text within 60 seconds". Don't use something like bookings or revenue.

**Copy-and-edit text for section 7 of your offer page**

> **Pilot and proof**
> We run a 30-day pilot. Before we start, we agree one success metric together: [e.g. every missed call gets a text reply within 60 seconds]. At the end of the 30 days we review the numbers together and you decide whether to continue.

**What the lessons don't cover**

The lessons don't say whether you can refund or credit something you control, for example if you fail to deliver the setup you agreed. They also don't cover contract wording for this. Ask in the Help channel and tag a coach if nobody answers within a day.

Tell me your niche, your area and the metric you'd like to use, and I can build the full one-page offer around the pilot.
