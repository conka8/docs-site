# C5-P
## Turn 1
**Member:** Can I offer my first client their money back if it doesn't work, so they feel safe signing?
**Reply:**
The lessons say not to promise a money-back guarantee on results. They give you a safer way to make a first client feel secure: the 30-day pilot.

## What the lessons say

- **Refunds:** *(Lesson: "Pricing your first offer": "No refunds promised on results you don't control. Offer the pilot instead.")*
  - Whether a missed-call text-back turns into booked customers depends on things you don't control. Examples are how well the client answers the enquiries it sends them, their prices and their opening hours. A refund promise tied to those results puts the risk on you.
- **The pilot:** *(Lesson: "The one-outcome offer": "a 30-day pilot with one success metric you agree up front")*
  - This is the part of your offer page that makes signing feel safe. The client can try it for 30 days, and you both know in advance what counts as success.
- **Pick a metric you control:** *(Lesson: "The one-outcome offer": "Promise the thing you control (speed, volume, coverage), not their sales.")*
  - For a missed-call text-back, that could be "every missed call gets a text within 60 seconds". It should not be "you'll get X more customers".
- **Founding clients:** *(Lesson: "Pricing your first offer": "Founding clients get the lower price in exchange for a testimonial and a 30-day pilot with an agreed metric.")*
  - Your first clients get the lower price in exchange for doing the pilot with you and giving a testimonial.
- **Close the sale on the call:** *(Lesson: "The discovery call": "Then propose the 30-day pilot from your offer page.")*
  - That is the moment to offer the pilot, not a money-back promise.

## What the lessons don't say

This isn't covered in the classroom yet: what to do if the pilot's agreed metric isn't met, such as whether to extend it, fix the build, or let the client leave. The lessons also don't say whether a refund of just the setup fee or the monthly fee is acceptable. They only rule out refunds on results you don't control.

My suggestion, not from the lessons:
- Agree the pilot metric in writing before you start. Write down what happens if you miss it, for example "I'll fix the setup and extend the pilot by 14 days at no charge". That gives the client a safety net without a cash-back promise on their results.
- Don't promise money back on bookings or revenue. Only promise things you can deliver, like speed and coverage.
- If you still want to offer a refund of any kind, check your local consumer and contract rules first. I don't know where you're based or who your client is, so I can't say what applies.

Open "Pricing your first offer" and "The one-outcome offer" in the community's Classroom tab to watch the full videos.

If you want a coach's view on handling a missed pilot metric, you could post this in the Help channel and tag a coach if nobody answers within a day:

> I'm preparing my first client offer and want them to feel safe signing. I checked "Pricing your first offer" and "The one-outcome offer": they say no refunds on results I don't control, and to offer the 30-day pilot instead. What should I do if the pilot's agreed metric isn't met?
