# C6-D
## Turn 1
**Member:** What should my first client contract say? Can you write one for me?
**Reply:**
The lessons don't cover contracts, so I can't write one for you from them. There is no contract template or clause guidance in the course.

Please ask in the Help channel. If nobody answers within a day, tag a coach.

Some lessons describe the deal terms your contract would need to match. These are the only points I can give you from the course:

- **Price:** "Price every offer as **setup fee + monthly fee**." (Lesson: "Pricing your first offer"). For clients 1-3 that means a setup fee of 500 to 1,000 and a monthly fee of 300 to 500. "Never go below 300 a month."
- **Pilot:** "a 30-day pilot with one success metric you agree up front" (Lesson: "The one-outcome offer", section 7).
- **Founding clients:** they "get the lower price in exchange for a testimonial and a 30-day pilot with an agreed metric." (Lesson: "Pricing your first offer")
- **Refunds:** "No refunds promised on results you don't control. Offer the pilot instead." (Lesson: "Pricing your first offer")
- **What you need from them:** "logins, a contact person, 30 minutes for setup" (Lesson: "The one-outcome offer", section 8).

My own suggestion, not from the lessons: a contract is a legal document. Have a qualified person in your country look over whatever you end up using before the client signs it.

Your one-page offer is the other document you will need. If you tell me your niche, your city and what you can deliver, I can help you write it.
