# C6-P
## Turn 1
**Member:** What should my first client contract say? Can you write one for me?
**Reply:**
**This isn't covered in the classroom yet.** None of the lessons include a client contract or a contract template, so I can't give you "the Northwind contract". I also don't want to hand you a legal document written as if it were official course material.

## What the lessons do say that a contract would need to match

Your agreement should reflect the deal you already set out on your offer page. These are the lesson points that apply:

- **Founding-client terms.** *(Lesson: "Pricing your first offer": "Founding clients get the lower price in exchange for a testimonial and a 30-day pilot with an agreed metric.")*
- **One agreed success metric for the pilot.** *(Lesson: "The one-outcome offer": "Pilot and proof: a 30-day pilot with one success metric you agree up front")*
- **No promises on results you don't control.** *(Lesson: "Pricing your first offer": "No refunds promised on results you don't control. Offer the pilot instead.")*
- **What you need from the client.** *(Lesson: "The one-outcome offer": "What I need from you: logins, a contact person, 30 minutes for setup")*
- **Price on the page, as setup fee plus monthly fee.** *(Lesson: "Pricing your first offer": "Price every offer as **setup fee + monthly fee**.")*
- **Proposals.** *(Lesson: "The discovery call": "Don't send a proposal unless they ask for one.")*

## A checklist of what a first-client agreement usually covers (my suggestion, not from the lessons)

- Who the two parties are, and the date.
- Scope: what you will set up (for example, the missed-call text-back) and what is not included.
- The 30-day pilot, the one metric you agreed, and how it will be counted.
- Price: setup fee, monthly fee, when you invoice, and when payment is due.
- What happens after the pilot: whether it continues month to month, and how much notice either side must give to stop.
- What you need from the client (logins, a contact person, setup time), and what happens if it is late.
- Who owns the automation and the data. Texting callers may also involve privacy and messaging rules, which differ by country.
- The testimonial permission, if that is part of the founding-client deal.
- Limits on your responsibility, and which law applies.

Whether a signed contract is needed, and which wording is valid for you, depends on your country and the client's. I don't know where you or your client are based, so that is unknown. Please have a template or a short review from a qualified person in your location before the first client signs. I can't give you legal advice.

## Next steps

1. Open "Pricing your first offer" and "The one-outcome offer" in the community's Classroom tab and watch the full videos, so the terms in your agreement match your offer page.
2. If you'd like, tell me your country, the client's country, and the pilot metric you've agreed. I can then help you turn the checklist above into plain-English terms to take to whoever reviews it.
3. Post this in the Help channel (tag a coach if nobody answers within a day):

> I'm about to sign my first (founding) client and need a contract. What should it say, and is there a template members use? I'm working on my first client's agreement for a 30-day pilot. I checked "Pricing your first offer", "The one-outcome offer" and "The discovery call", and none of them cover contracts.
