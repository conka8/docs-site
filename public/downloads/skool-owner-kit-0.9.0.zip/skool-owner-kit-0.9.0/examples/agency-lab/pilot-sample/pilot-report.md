# Northwind member pack pilot (synthetic): pilot report

Data as of 2027-01-15.

**Suggestion: CONTINUE**

- Member outcomes: continue. Quality: pass. Economics: positive.

## 1. Product quality

**Quality: pass**

- 5 of 5 acceptance runs passed.
- 10% of reviewed tutor answers needed correcting (limit 10%).

- Acceptance runs passed: 5/5 = 100% (95% range 57-100%)
- Tutor answers reviewed: 42 (resolved 34, corrected 4, escalated 4)

## 2. Member outcomes

**Outcomes: continue**

- The outcome rate is 16.3 points above baseline (target 10).
- The 95% ranges still overlap: run another cohort before treating this as settled.

Primary outcome: **First win** within 14 days of joining. Only members whose 14-day window has closed are counted.

| Cohort | Members | Window closed | Reached the outcome |
|---|---|---|---|
| Pilot (got the pack) | 40 | 40 | 16/40 = 40% (95% range 26-55%) |
| Baseline (earlier members) | 38 | 38 | 9/38 = 24% (95% range 13-39%) |

Difference: +16.3 percentage points. Pilot members still inside their window: 0.

- Installed: 29/40 = 72% (95% range 57-84%)
- Used a skill or completed a task: 23/40 = 58% (95% range 42-71%)
- Completed tasks: offer-builder 23, outreach-sprint 15

## 3. Economics

**Economics: positive**

- Observed first-renewal difference 253 minus cash costs 6 = 247 (observed, not proven to be caused by the pack; time not included).

- First renewal, pilot: 29/40 = 72% (95% range 57-84%) (0 pilot member(s) not due yet)
- First renewal, baseline: 25/38 = 66% (95% range 50-79%)
- Refunds in the pilot cohort: 1
- Observed revenue difference at first renewal: 253 (renewal-rate difference × pilot members with a renewal result × price, after fees)
- Cash spent on the pilot: 6
- Time spent: 12.5 hours (not included in cash)
- Staff-handled questions: 18, 11 minutes each; capacity freed (estimate): 6.3 hours (capacity, not cash)

## Read this before you decide

- This compares two cohorts; it does not prove the member pack caused any difference. Season, marketing, price changes and who joined can all differ between months.
- Events are only as complete as your logging. Self-reported outcomes undercount members who don't post.
- Staff time freed is capacity, not cash, unless you actually reduced paid hours.
