# Grades: Set X (out/S<n>-diy.md) and Set Y (tool/S<n>-review.md)

Ground truth is all 17 defects in GROUND-TRUTH.md: 6 critical, 10 major, 1 minor. That includes the two S7 defects added after the reviews ran.
Verdicts:
- **found**: the draft names the defect as a problem to fix.
- **routed**: the draft leaves the defect open and asks the coach that exact question.
- **missed**: neither.

False flags are problems the draft asserts that are not ground-truth defects. They are split into two kinds:
- **clear**: no lesson supports the point.
- **arguable**: the text does differ from the literal wording of a lesson, but ground truth does not list it.

They only count when the draft asserts them, in its problems list, checklist or reply. Conditional cautions such as "if it's invented, label it" are not counted.

## Set X (DIY)

| Sub | Defect | Sev | Verdict | Where |
|---|---|---|---|---|
| S1 | (none) | | | |
| S2 | monthly-floor £200 | critical | found | Problem 1 |
| S2 | setup-range £400 | major | found | Problem 1 |
| S3 | no-guarantee (20 bookings or money back) | critical | found | Problem 1 |
| S3 | pilot-metric: no agreed metric | major | found | Problem 1 fix and reply item 1: replace with a 30-day pilot with one agreed metric |
| S3 | one-niche: "more booked patients" is a revenue result | critical (J) | found | Problem 2: "a sales promise, and 'More' can't be counted" |
| S4 | headline-no-tools (n8n, GPT) | major | found | Problem 2 |
| S4 | one-niche: "small businesses" | critical (J) | found | Problem 1 |
| S4 | problem-in-their-words: "Missed calls cost money" | major (J) | found | Problem 4 |
| S5 | sections: 3 missing | major | found | Problem 2 |
| S5 | price-structure: no setup fee | critical | found | Problem 1 |
| S5 | pilot-metric: no pilot | major | found | Problem 2, Pilot and proof bullet |
| S6 | unsupported claims £2,400 / 62% | critical | found | Problem 1 |
| S6 | problem-in-their-words: generic third sentence | major (J) | found | Problem 2 |
| S7 | length over 400 | minor | found | Problem 3 |
| S7 | monthly-range: $750 above founding 300-500 | major | found | Problem 1 |
| S7 | headline call-back vs steps text plus next-morning call | major (J) | found | Problem 2 |
| S8 | sections: one paragraph | major | found | Problem 2 |

### False flags, Set X

Clear (18):
1. S1: testimonial missing from the founding deal. The pricing lesson describes the exchange but doesn't require the page to state it, and ground truth says S1 is clean.
2. S1: "Every missed new-patient call is a course of treatment…" is called an unsourced claim. It has no figure, and it is the cost in the client's terms that the lesson asks for. S1 is clean.
3. S2: "To make it an easy yes" is said to frame the price as a discount and should be deleted. No lesson covers this.
4. S2: pilot metric wording ("Problem 4", which the draft itself calls "countable and fine"). It meets the lesson.
5. S2: How it works step 1 "reads like a log line". It is not jargon, so no rule applies.
6. S3: step 3 "We book them in" promises something the member may not control. The no-guarantee rule is about results, not about how the steps describe the process.
7. S3: price doesn't say it is founding, and needs a testimonial. No lesson requires a label.
8. S4: pilot metric should be a share. The lesson asks for one agreed metric, and S4 has one.
9. S5: the problem quote should add a cost line. The quote already states the cost ("a $5,000 install gone").
10. S5: "every enquiry" versus calls plus web forms. The draft hedges it as "probably fine".
11. S5: the $5,000 figure must be sourced (reply item 3). It sits inside a client quote, and ground truth lists S6's figures as the claims defect, not this.
12. S6: asks for a 3-filter score for physio clinics. No lesson requires the offer to show the score.
13. S6: step 3 "Replies to your inbox" is too vague. It is plain and has no jargon.
14. S6: testimonial condition and client number. The page doesn't have to state either.
15. S7: "Who it's for" and "The problem" overlap. No rule covers this.
16. S7: testimonial not mentioned (inside Problem 1). The page doesn't have to state it.
17. S8: price "needs to be framed": move up the band, state founding and testimonial. Ground truth says the price follows the lessons.
18. S8: pilot metric is "only partly there" because of "like". Ground truth says the pilot and metric follow the lessons.

Arguable (13). Each is a literal gap against the lesson's section list or formula, and none is in ground truth:
1. S2: headline has no "We" and no timeframe (formula).
2. S2: "What I need from you" lacks the 30 minutes.
3. S3: "What's included" lacks a monthly check-in.
4. S3: "Who it's for" has no business size.
5. S3: "The problem" gives no cost and is not in their words.
6. S3: "What I need from you" says "logins" vaguely and has no contact person.
7. S4: How it works uses n8n and GPT (jargon).
8. S4: "What's included" lacks a monthly check-in.
9. S4: "What I need from you" says "API access" and has no 30 minutes.
10. S5: "Who it's for" has no size ("own service vans").
11. S6: "Who it's for" has no size.
12. S8: the opening sentence fails the headline formula ("stop losing patients" can't be counted).
13. S8: "What I need from you" lacks the 30 minutes.

S8 Problem 3 (missing problem cost, steps and included items) is not counted. It follows directly from the sections defect.

### Lesson misstatements, Set X
- S5 (Problem 1 and reply): "never monthly only". The lesson says "Never only one-off". Setup plus monthly is required, but the "never" in the lesson is about one-off pricing.
- S6 (Problem 2): calls the generic sentence "exactly the 'small businesses' vagueness the lessons warn about". The lesson's warning is about choosing a niche, not about the wording of the problem section. This is a stretch.
- S4 (Problem 1): "the member can't find 50 of them in an hour" applies filter 3 to "small businesses". The lesson only says "'Small businesses' is not a niche"; it doesn't say they fail filter 3, and small businesses are easy to list. This is a dubious application, not a direct misquote.

## Set Y (tool)

| Sub | Defect | Sev | Verdict | Where |
|---|---|---|---|---|
| S1 | (none) | | | |
| S2 | monthly-floor £200 | critical | found | monthly-floor missing |
| S2 | setup-range £400 | major | found | setup-range missing |
| S3 | no-guarantee | critical | found | no-guarantee missing |
| S3 | pilot-metric | major | found | pilot-metric missing ("Doesn't mention: metric") |
| S3 | one-niche: revenue outcome | critical (J) | routed | you judge: "…and one countable outcome?" |
| S4 | headline-no-tools | major | found | "Found: n8n, gpt" |
| S4 | one-niche: "small businesses" | critical (J) | routed | you judge: "not 'small businesses'" |
| S4 | problem-in-their-words | major (J) | routed | you judge row |
| S5 | sections: 3 missing | major | found | sections missing |
| S5 | price-structure: no setup fee | critical | found | price-structure missing |
| S5 | pilot-metric: no pilot | major | found | pilot-metric missing |
| S6 | unsupported claims £2,400 / 62% | critical | found | Claims section and checklist |
| S6 | problem-in-their-words: generic third sentence | major (J) | routed | you judge row |
| S7 | length over 400 | minor | found | length missing (420 words) |
| S7 | monthly-range: $750 above founding range | major | missed | Only monthly-floor was checked and marked met (750). The reply lists "monthly fee at least 300" as following the method. |
| S7 | headline call-back vs steps | major (J) | missed | No row asks about it. The you-judge rows cover niche/outcome and the problem only. |
| S8 | sections: one paragraph | major | found | sections missing (all 8) |

### False flags, Set Y
None.

These are non-assertions, not counted:
- S5: setup-range "uncertain: check (couldn't read a setup amount)" repeats the price-structure finding.
- S8: headline-no-tools "uncertain: check (no Headline section found)" is noise on a headline that doesn't exist.
- S1 to S8: the same two you-judge rows appear on every submission, including the clean S1. They ask questions and assert nothing.

### Lesson misstatements, Set Y
None found. All lesson quotes in the criteria rows match the lessons.

These are draft defects but not misstatements:
- S6: the reply cuts the quoted claim off mid-word ("…62% of calle").
- S7: the setup-range row is labelled "Founding-client", but the rubric doesn't check the matching founding monthly range, which is why S7 was missed.

## Totals

| Set | Found (crit / other) | Routed (crit / other) | Missed (crit / other) | False flags |
|---|---|---|---|---|
| X (DIY) | 17 (6 / 11) | 0 (0 / 0) | 0 (0 / 0) | 31 (18 clear, 13 arguable); 3 lesson misstatements (1 direct, 2 stretches) |
| Y (tool) | 11 (4 / 7) | 4 (2 / 2) | 2 (0 / 2) | 0; 0 lesson misstatements |

On S1, the clean offer, X raised 2 false problems and Y raised none.
