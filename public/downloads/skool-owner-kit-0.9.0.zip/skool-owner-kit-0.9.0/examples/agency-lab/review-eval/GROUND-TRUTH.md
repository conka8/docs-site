# Ground truth for the synthetic submissions (written before any review was run)

SYNTHETIC: the eight submissions in `submissions/` were written by hand to resemble members' posted offers, each with
known defects planted against the Northwind lessons. No real member wrote them.

"Critical" follows the rubric (`pack.yaml` → offer-builder → rubric): a member who sent it as it stands would break a
core rule of the method.

| Id | Planted defects (rubric id, severity) | Also true, not a defect |
|---|---|---|
| S1 | none | A clean offer; any finding is a false flag |
| S2 | monthly-floor: £200 a month (critical); setup-range: £400 (major) | Roofers pass the money-leak filter |
| S3 | no-guarantee: "We guarantee 20 new bookings ... or your money back" (critical); pilot-metric: no agreed metric (major); one-niche: outcome "more booked patients" is a revenue result, not one they control (critical, judgement) | |
| S4 | headline-no-tools: n8n, GPT (major); one-niche: "small businesses" (critical, judgement); problem-in-their-words: "Missed calls cost money" (major, judgement) | |
| S5 | sections: no What's included, Pilot and proof, What I need from you (major); price-structure: no setup fee (critical); pilot-metric: no pilot (major) | |
| S6 | unsupported claims: "£2,400 a month", "62% of callers" (critical: invented figures in a client document); problem-in-their-words: generic third sentence (major, judgement) | |
| S7 | length: over 400 words (minor) | Bold-line headings instead of Markdown; "$750/mo after a $950 setup fee" is within the ladder |
| S8 | sections: written as one paragraph, no sections (major) | Price (300 a month, 600 setup), niche, pilot and metric all follow the lessons |

Total planted: 15 (6 critical, 8 major, 1 minor). 4 of them need judgement by their nature (one-niche in S3 and S4,
problem-in-their-words in S4 and S6).

## Added after the reviews ran (2026-10-30), and how they were found

The DIY Project reviewer (S5-S8 run) pointed out two real problems in S7 that this table missed:

| Id | Defect | Severity | Why it was missed |
|---|---|---|---|
| S7 | monthly-range: $750 a month is above the founding-client range of 300-500 ("Clients 1-3 ('founding clients') \| 500 to 1,000 \| 300 to 500") while the page calls it founding pricing | major | The table above wrongly said the price was "within the ladder"; the rubric only checked the 300 floor |
| S7 | Headline promises a call-back within 2 minutes; the steps send a text and the firm calls back next morning | major (judgement) | Not planted; a real inconsistency in the hand-written text |

With these, 17 defects: 6 critical, 10 major, 1 minor; 5 need judgement. The rubric's monthly check was widened to
the founding range afterwards (see README), and that change is reported separately from the original run.
