# Member-work review: the tool against a well-instructed Claude Project

**SYNTHETIC.** Eight member offers written by hand with known defects (`submissions/`, `GROUND-TRUTH.md`, written
before any review ran). No real member, coach or review time is involved. Model execution time is not human time
saved; no human minutes were measured.

**Question:** for a coach reviewing members' one-page offers, how does a first pass from `skool-kit review` compare
with the realistic alternative: the same lessons in a Claude Project with a clear review instruction?

| | `skool-kit review` (first run, `tool-first-run/`) | Claude Project, same lessons (`diy-project/`) |
|---|---|---|
| How it ran | Deterministic, no model, about 0.1 s per submission | Simulated: Claude Code subagents (`claude-sonnet-5-5`) given the project's instructions and lesson files; not the Claude app |
| Defects found (of 17: 6 critical) | 11 (4 critical) | 17 (6 critical) |
| Handed to the coach as an explicit question | 4 (2 critical): the judgement items | 0 |
| Missed | 2, both in S7: a monthly fee above the founding range, and a headline that promises what the steps don't do | 0 |
| False flags (problems that aren't in the lessons) | 0 | 31 (18 clear, 13 arguable), including 2 on the clean offer S1 |
| Misstatements of a lesson | 0 | 3 (e.g. "never monthly only"; the lesson says "never only one-off") |
| Words for the coach to read per submission | about 650 (first run); 420-690 after compacting the met criteria | about 700 |

Grading: one model grader, not blind to which set was which (`claude-opus-5-5`, `GRADES.md`), spot-checked by the developer. Model
grading is fallible; the counts are a rough guide, not a measurement.

## What it means

- **The Project finds more, and says more that's wrong.** It caught every defect, including the ones that need
  judgement. But almost two thirds of its findings weren't defects, so a coach has to check every point before
  sending. That checking is the work we're trying to reduce.
- **The tool is narrow and reliable.** It found every mechanical defect in the rubric and raised no false flags. It
  handed judgement items to the coach explicitly rather than guessing. It missed what the rubric didn't cover: the
  monthly ceiling (since added: `monthly-founding-range` now flags S7, reported separately from this run) and the
  headline-vs-steps inconsistency.
- **Neither replaces the coach.** The useful combination, untested here, is the tool's first pass plus the coach's
  judgement, or the tool plus a Project the coach asks about judgement items only.
- **Coach time hasn't been measured.** Neither review is shorter to read, and the research we found suggests AI drafts
  make feedback more frequent rather than faster (arXiv 2606.03095). The first pilot measures minutes against the
  coach's own baseline (REVIEW-PILOT.md), and "no saving" is a realistic result.

If a pilot shows coaches working as fast from a well-instructed Project, with no more corrections, the simpler
alternative wins: recommend it and drop the paid review setup.
