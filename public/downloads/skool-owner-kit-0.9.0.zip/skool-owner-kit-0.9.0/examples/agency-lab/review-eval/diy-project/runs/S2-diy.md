## Review: roofers in Bristol offer

**Verdict:** The niche and structure are good, but the price breaks the pricing rules and the headline doesn't use the formula.

### Problems (most serious first)

1. **The price is below the allowed range.** "Pricing your first offer" says never go below 300 a month, and the founding-client ladder (clients 1-3) is 500-1,000 setup and 300-500 monthly. This offer has £400 setup and £200 a month. The monthly fee is under the 300 floor, and the setup is under 500. The wording "To make it an easy yes" also frames the price as a discount.
   *Fix:* use at least £500 setup and £300 a month. A recovered roofing lead is worth a lot (a whole roof), so the lesson says to use the higher end, e.g. £750-1,000 setup and £400-500 a month. Delete "To make it an easy yes". If this is a founding client, say so and mention the testimonial.
2. **The headline doesn't follow the formula.** The formula is "We [measurable outcome] for [niche] in [timeframe], without [the pain they hate]". "Every missed call answered by text for roofers in Bristol, without extra staff" has no "We" and no timeframe.
   *Fix:* "We reply to every missed call within 60 seconds for roofers in Bristol, without extra staff." The 60 seconds also matches the pilot metric.
3. **"What I need from you" is missing the 30 minutes for setup.** The lesson lists logins, a contact person, and 30 minutes for setup.
   *Fix:* "Your phone provider login, a contact person, and 30 minutes for setup."
4. **Minor: the pilot metric wording.** "Replies sent within a minute" is countable and fine, but it is clearer as "share of missed calls that get a text within 60 seconds", so both sides can measure it.
5. **Minor: "How it works" step 1 reads like a log line.** "Missed call detected" could be plainer, e.g. "When you miss a call, we notice."

### Claims and figures that need a source
- The quote "By the time we call back they've hired someone else" should come from a real roofer. If it doesn't, label it as typical.
- There are no other figures. When the member prices higher, they shouldn't add claims about job values without a source.

### What already follows the method
- The niche is specific, and roofers pass the 3-filter test (the lesson names them as a pass).
- No tool names, and no revenue promise.
- All sections are present and in order. It's short, under 400 words.
- The pilot is 30 days with one agreed metric the member controls.
- "What's included" has setup, the automation, and a monthly check-in. The price is on the page.

### Draft reply for the member (please check and edit)

> Good start. Roofers in Bristol is a sharp niche, the sections are in order, and your pilot metric is something you control.
>
> Three fixes:
> 1. **Price.** £200 a month is below our 300 floor, and £400 setup is under the founding-client range of 500-1,000. Roofing jobs are high value, so aim for the higher end, e.g. £750 setup and £400 a month. Please drop "To make it an easy yes". If this is a founding client, add that it's in exchange for a testimonial.
> 2. **Headline.** Use the formula: "We reply to every missed call within 60 seconds for roofers in Bristol, without extra staff."
> 3. **What I need from you.** Add "30 minutes for setup".
>
> Send me the updated version and we'll take another look.
