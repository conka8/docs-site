## Review: med spas in Austin offer

**Verdict:** The niche and the price are fine, but the guarantee is the biggest problem and the rest is too vague. It needs a rewrite before it goes out.

### Problems (most serious first)

1. **The pilot guarantees results and promises a refund.** "We guarantee 20 new bookings in your first 30 days, or your money back" breaks two rules. "Pricing your first offer" says no refunds on results you don't control, and "The one-outcome offer" says to promise what you control (speed, volume, coverage), not their sales. Bookings depend on the med spa's prices, staff and reputation. The member could also lose money on it.
   *Fix:* replace it with a 30-day pilot with one agreed metric the member controls, e.g. "the share of missed calls that get a text within 60 seconds". No refund promise.
2. **The headline doesn't follow the formula.** "More booked patients for med spas in Austin, without missing a call" has no "We", no measurable outcome and no timeframe. "More booked patients" is a sales promise, and "More" can't be counted.
   *Fix:* "We reply to every missed call within 60 seconds for med spas in Austin, without hiring front-desk staff."
3. **"How it works" step 3 promises something the member may not control.** "We book them in" implies the member handles the bookings.
   *Fix:* describe what actually happens, e.g. "The text offers a booking link or a call back."
4. **"What's included" is vague.** "Setup, the system, support" should be setup, the automation, and a monthly check-in.
5. **"Who it's for" and "The problem" are too thin.** "Med spas in Austin" has no business size. "They lose bookings when nobody answers the phone" doesn't say what it costs them or use their words.
   *Fix:* add the size (e.g. 1-3 treatment rooms) and one real quote from an owner.
6. **"What I need from you" is vague.** "Logins" doesn't say which. It also doesn't mention a contact person.
   *Fix:* "Access to your phone system, one contact person, and 30 minutes for setup."
7. **The price doesn't say it is a founding-client price.** $900 setup and $450 a month is inside the founding-client range (500-1,000 setup, 300-500 monthly). It would be below the range for clients 4-10 (1,000-2,500 setup, 500-900 monthly). If this isn't client 1-3, raise it. If it is, say so and mention the testimonial.

### Claims and figures that need a source
- "20 new bookings in 30 days" has no basis. There's no data on how many missed calls a med spa has, so the member can't know whether 20 is reachable. Remove it.
- "They lose bookings when nobody answers the phone" is plausible but uncited. A real figure from a med spa would help.

### What already follows the method
- The niche passes the 3-filter test (the lesson names med spas as a pass). It's specific, with a city.
- No tool names.
- All 8 sections are present and in order. It's under 400 words.
- The price is on the page and above the 300 floor.
- The pilot is 30 days (the length is right, only the content is wrong).

### Draft reply for the member (please check and edit)

> Thanks for posting. Med spas in Austin is a good niche and your price ($900 setup, $450 a month) fits our founding-client range. But I'd rewrite a few things before you send it out.
>
> 1. **Remove the guarantee.** We don't promise bookings or refunds on results you can't control. Instead use a 30-day pilot with one agreed metric you do control, such as "the share of missed calls that get a text within 60 seconds".
> 2. **Headline.** Use the formula: "We reply to every missed call within 60 seconds for med spas in Austin, without hiring front-desk staff."
> 3. **How it works.** Replace "We book them in" with what you actually do, e.g. "The text offers a booking link or a call back."
> 4. **Fill in the thin sections.** Add a business size under "Who it's for", a real quote and what a missed call costs them under "The problem", "setup, the automation, a monthly check-in" under "What's included", and the specific logins plus a contact person under "What I need from you".
> 5. **Founding price.** If this is one of your first three clients, say so and ask for a testimonial in return.
>
> Send me the new version and we'll check it again.
