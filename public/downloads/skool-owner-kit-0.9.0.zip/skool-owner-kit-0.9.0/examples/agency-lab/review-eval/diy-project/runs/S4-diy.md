## Review: "n8n + GPT missed-call bot" offer

**Verdict:** This offer sells a tool to a vague audience, which is what the lessons say not to do. It needs a niche first, then a rewrite. The price and the pilot metric are fine.

### Problems (most serious first)

1. **There is no niche.** "Small businesses that get phone calls" fails the 3-filter test. The lesson says "'Small businesses' is not a niche. 'Dental clinics in Leeds' is." Not every business with a phone loses real money on a missed call, and the member can't find 50 of them in an hour.
   *Fix:* run the 3-filter test on two or three candidates (money leak, already pays for software, reachable this week) and only pick one that scores 3/3. Prefer one where the member knows someone. Then commit to it for 30 days.
2. **The headline sells a tool, not an outcome.** "n8n + GPT missed-call bot for small businesses" breaks the headline rules: no tool names, a countable outcome, and the formula "We [outcome] for [niche] in [timeframe], without [the pain]". It has none of them.
   *Fix:* e.g. "We reply to every missed call within 60 seconds for [niche] in [city], without hiring a receptionist."
3. **"How it works" uses tool names and jargon.** "n8n workflow" and "GPT writes a reply" should be three plain steps a client understands, e.g. "1. You miss a call. 2. The caller gets a text within 60 seconds. 3. Replies land in one inbox for your team."
4. **"The problem" has no cost and isn't in the client's words.** "Missed calls cost money" is generic.
   *Fix:* once the niche is chosen, add a real quote from an owner and what one missed call costs them.
5. **"What's included" is missing the monthly check-in.** The lesson lists setup, the automation, and a monthly check-in. Without it the monthly fee has nothing behind it.
6. **"What I need from you" is jargon and incomplete.** "API access" means nothing to most owners, and there's no 30 minutes for setup.
   *Fix:* "Access to your phone system, one contact person, and 30 minutes for setup."
7. **Minor: the pilot metric wording.** "Texts sent within 2 minutes" is countable and the member controls it, which is correct. But it should be a share ("share of missed calls texted within 2 minutes") so success can be measured. Make it match the headline's timeframe.

### Claims and figures that need a source
- "Missed calls cost money" is vague, so there's nothing to source yet. Once the niche is chosen, any figure for what a missed call costs needs a real source.
- The "2 minutes" is a promise about the member's own system, so they should test it first.

### What already follows the method
- The price is 600 setup and 350 a month. That is inside the founding-client range (500-1,000 setup, 300-500 monthly) and above the 300 floor. It's on the page. If this is client 1-3, add a line about a testimonial in exchange.
- The pilot is 30 days with one agreed, countable metric the member controls, with no result guarantee and no refund.
- All 8 sections are present and in the right order, and it's well under 400 words.
- It makes no revenue promise.

### Draft reply for the member (please check and edit)

> Thanks for sharing. Your price (600 setup, 350 a month) and your pilot (30 days, one agreed metric) are both right for a founding client. The main work is on who you're selling to and what you're selling.
>
> 1. **Pick a niche.** "Small businesses" isn't one. Score two or three candidates with the 3-filter test and choose one that gets 3/3, ideally one where you already know someone. Then name it with a city, like "dental clinics in Leeds".
> 2. **Rewrite the headline** with the formula and no tool names: "We reply to every missed call within 60 seconds for [niche] in [city], without hiring a receptionist."
> 3. **Take n8n and GPT out of "How it works".** Use three plain steps a client would understand.
> 4. **Fill the thin parts.** Add a real quote and cost under "The problem", a monthly check-in under "What's included", and "access to your phone system, a contact person, 30 minutes for setup" under "What I need from you".
>
> Send me the new version and we'll look again.
