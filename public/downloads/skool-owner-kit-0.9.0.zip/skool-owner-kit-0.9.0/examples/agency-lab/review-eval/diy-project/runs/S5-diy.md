## Review: HVAC Phoenix offer

### Problems (most serious first)

1. **Price has no setup fee.** It says "$500 a month, cancel any time." *Pricing your first offer* says every offer is setup fee + monthly fee, never monthly only. Fix: add a setup fee. The ladder is 500 to 1,000 setup for clients 1-3, and 1,000 to 2,500 setup for clients 4-10. HVAC is a high-value-lead niche (the member quotes a $5,000 install), so the higher end of whichever band applies is justified. The $500 monthly fits both bands: it is the top of the founding range (300-500) and the bottom of the clients 4-10 range (500-900). The member should say which client number this is. If it is a founding client, add the testimonial + 30-day pilot trade.

2. **Three of the eight required sections are missing.** The lesson requires "What's included", "Pilot and proof" and "What I need from you", in order. Fix:
   - What's included: setup, the text automation, a monthly check-in.
   - Pilot and proof: a 30-day pilot with one success metric agreed up front. The headline promises a 5-minute response, so something like "share of missed calls and web forms that get a text within 5 minutes" is the natural metric.
   - What I need from you: phone system and web form access, a contact person (the dispatcher?), 30 minutes for setup.

3. **"Who it's for" gives the niche but not the size of business.** The lesson asks for niche and size. "With their own service vans" hints at it, but a number is better (for example "2 to 10 vans").

4. **"The problem" is one quote.** It should say what the problem costs today, in the client's words. The quote is good, but it needs a line on what it adds up to (for example how many calls go unanswered in a summer week). Only add that if the member can back it up.

5. **Minor: the headline says "every enquiry", and How it works only covers missed calls and web forms.** That is probably fine, but check that "enquiry" means exactly those two channels, so the pilot metric can be measured.

### Claims needing a source
- "Every missed one is a $5,000 install gone." It is presented as a client quote. The member should confirm it comes from a real HVAC owner or from their own research, or soften it ("a missed call can be a multi-thousand-dollar install").
- "More calls than we can pick up" in summer: same question, is this a real quote?

### What already follows the method
- The headline follows the formula: measurable outcome (5 minutes), niche + place, "without" clause, no tool names, no revenue guarantee.
- Phoenix HVAC is a strong niche: money leak (a missed call is an install), reachable this week, and HVAC firms already pay for dispatch/phone software. It would likely pass the 3-filter test, though the member should confirm filter 2 (software) and filter 3 (50 in Phoenix).
- How it works is three plain steps, no jargon.
- The $500 monthly is inside our ladder and above the 300 floor.
- Very short, so there is plenty of room under the 400-word limit.

### Draft reply for the member (please check and edit)

Hi, good start. Your headline and niche are exactly what we teach, and the HVAC missed-call problem in a Phoenix summer is a strong one. Three things to fix before this is ready:

1. Price: add a setup fee. Our rule is setup + monthly, never monthly only. Tell us if this is client 1-3 or 4-10 and pick the setup from that band (500-1,000 or 1,000-2,500). Your $500/month is fine.
2. Add the three missing sections, in this order: What's included, Pilot and proof (30 days, one agreed metric, for example the share of missed calls and web forms that get a text within 5 minutes), and What I need from you.
3. In "Who it's for", add the business size (for example number of vans), and make sure the $5,000 install figure in the problem comes from a real conversation or a source you can point to.

Send it back once updated and we'll take another look.
