## Review: physio clinics Manchester offer

### Problems (most serious first)

1. **Unsourced figures in "The problem".** "Clinics lose about £2,400 a month to missed calls" and "studies show 62% of callers won't call back" are specific claims with no source. If the member can't name the study and show how £2,400 was calculated, they should not go on the page. Fix: use a figure from a real conversation with a clinic, or a simple calculation the client can check ("if you miss 10 calls a month and each new patient is worth £X..."), or say it plainly without numbers.

2. **The problem section is not in the client's words.** The lesson asks for what it costs them today, in their words. "Small businesses struggle with customer communication in general" is generic filler and is exactly the "small businesses" vagueness the lessons warn about. Cut it and replace it with a quote or a concrete scene (patient rings during a treatment, gets voicemail, books elsewhere).

3. **Niche not shown to pass the 3-filter test.** Physio clinics are not among the examples in the lesson. They may pass, but the member should check: (1) does a missed call lose real money, meaning what a new patient is worth over a course of treatment? (2) do clinics already pay for a booking system or phone system? (3) can the member list 50 in Manchester in under an hour? The coach should ask for the 3/3 score.

4. **"Who it's for" lacks the size of business.** Lesson asks for niche and size (for example 1 to 5 practitioners).

5. **Step 3 is vague.** "Replies to your inbox" doesn't say who sees what or when. One plain sentence is enough (for example, "any reply lands in your clinic's email and your front desk answers it").

6. **Minor: no testimonial condition.** £600 setup and £350 a month are within the founding-client ranges (500-1,000 and 300-500), so the price is fine. But founding prices are given in exchange for a testimonial and the 30-day pilot. If this is client 1-3, say so on the page. If it is client 4+, the setup is below the 1,000 minimum for that band. The coach should ask which.

### Claims needing a source
- £2,400 a month lost to missed calls.
- "Studies show 62%": which study?

### What already follows the method
- Headline matches the formula: measurable outcome (60 seconds), niche and place, "without a receptionist", no tool names, no revenue promise.
- All eight sections are present and in the right order.
- Price shows setup + monthly and respects the ladder and the 300 floor.
- Pilot: 30 days, one metric agreed up front, and the metric (reply time to missed calls) matches the headline promise and is something the member controls.
- "What I need from you" is exactly the lesson's list.
- Short, well under 400 words.

### Draft reply for the member (please check and edit)

Hi, this is close. Structure, headline, pilot and price all follow the method, and your pilot metric (reply time) is a good one because it's something you control. Fix these before it goes out:

1. Source or remove the £2,400 and the 62% figures. Anything we can't trace to a study or a real clinic conversation shouldn't be on the page. A quote from a clinic owner is stronger.
2. Replace "Small businesses struggle with customer communication in general" with the actual pain in a clinic owner's words.
3. Add the size of clinic in "Who it's for", and make step 3 specific about who sees the reply.
4. Please send us your 3-filter score for physio clinics in Manchester (money leak, already pays for software, 50 reachable this week). And tell us whether this is client 1-3, as the price suggests, so we can confirm the founding terms (testimonial + pilot).
