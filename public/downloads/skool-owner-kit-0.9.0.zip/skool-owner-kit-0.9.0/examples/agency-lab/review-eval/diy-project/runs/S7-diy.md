## Review: Denver law firms offer

### Problems (most serious first)

1. **Monthly price is above the founding range, but the offer calls itself founding pricing.** "$750/mo after a $950 setup fee. Founding client pricing, for the first three firms only." The ladder for clients 1-3 is 500-1,000 setup and 300-500 monthly. $950 setup is fine, but $750 a month is 250 over the founding maximum. Fix, either way:
   - Keep the "founding" label and drop the monthly to 500 (using the higher end is justified for a legal case, but the top of the band is 500).
   - Or drop the "founding" label and price as clients 4-10 (500-900 monthly), where the setup must then be at least 1,000.
   Also, founding prices are given in exchange for a testimonial and the 30-day pilot. The page mentions the pilot but not the testimonial.

2. **The headline promises more than the mechanism delivers.** The headline says "We call back every missed enquiry within 2 minutes", but How it works says the caller gets a text within 2 minutes and the firm's intake person calls back the next morning. The pilot metric also measures texts, not call-backs. Fix: "We text back every missed call within 2 minutes for law firms in Denver, without a night receptionist". This keeps the promise to something the member controls and matches the pilot metric.

3. **Over the 400-word limit.** The page is roughly 410 to 430 words depending on how headings are counted. The lesson says under 400, cut if needed. Easy cuts: "Who it's for" is one very long sentence that restates the problem (for example "Small personal-injury and family law firms in Denver, two to eight lawyers, with a case management system and phone system in place"), and the second half of "The problem" (the partners paragraph) can be trimmed to one sentence.

4. **Minor: "Who it's for" and "The problem" overlap.** The "who" section explains the problem (partners answering their own phones, calls going unanswered). Keep who it's for to the niche and size and let the problem section carry the pain.

### Claims needing a source
- "A single missed case can be worth more than a year of this service." Plausible, but the member should be able to say where it comes from (typical case values, or a firm they spoke with).
- "Partners tell me they know it happens": fine if these are the member's own real conversations, which the coach may want to confirm.
- "Someone calls at 7pm after an accident... signed with another firm": presented as a quote, so it should come from a real conversation.

### What already follows the method
- Niche is strong and clearly passes the 3-filter test: law firms are a named money-leak niche, the offer says they already pay for case management and phone systems, and Denver firms of 2-8 lawyers are listable in an hour.
- All eight sections, in the right order, with the right content in each. Three plain steps, no tool names, and the "What's included" list includes the monthly check-in.
- Price is shown as setup + monthly and above the 300 floor, and the $950 setup fits the founding band.
- Pilot: 30 days, one metric agreed up front, measured from a source the client can check (the phone system call log), with a clear decision at the end and no refund promised.
- "What I need from you" matches the lesson (access, a contact person, 30 minutes).
- No revenue guarantee.

### Draft reply for the member (please check and edit)

Hi, this is a strong offer. The niche, sections, pilot and the way you measure it from the call log are all what we teach. Three fixes:

1. Price: you've called it founding pricing, but $750/month is above our founding range (300-500). Either drop the monthly to 500, or take the founding label off and price as client 4+ (500-900 monthly with a setup of 1,000 or more). If it stays founding, add that it comes with a testimonial and the pilot.
2. Headline: it says you call back within 2 minutes, but your steps send a text within 2 minutes and the firm calls back in the morning. Change it to "We text back every missed call within 2 minutes..." so it matches your steps and your pilot metric.
3. Length: it's slightly over our 400-word limit. Shorten "Who it's for" to the niche and size, and trim the second half of the problem section.

Also be ready to say where "a single missed case is worth more than a year of this service" comes from.
