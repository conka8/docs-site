# What `skool-kit check-answer` can and can't verify

The replies in this folder are **constructed by hand**, each with one known defect, to test the checker. They are not
model outputs.

```bash
skool-kit check-answer verification/dropped-qualification.md --pack member-pack --case offer-builder-dropped-qualification
```

For every citation it answers four questions separately. Only the first three are decided by the machine:

| | Question | How |
|---|---|---|
| 1 | Does the quote exist? | Exact match against the lesson files (ignoring case, spacing, emphasis, quote marks) |
| 2 | Is it in the lesson the reply names? | Same match, against the named lesson only; if it's elsewhere, says where |
| 3 | Was a qualification dropped? | The quote is part of a longer lesson sentence whose missing part limits it (unless, only, on results, in exchange, ...) |
| 4 | Does it support the claim? | **Not decided.** Listed with the reply sentence it's attached to, for a person |

It also flags unsourced numbers (not in the lessons, the member's input, or the reply's Gaps and assumptions), promise
wording that isn't negated, and the acceptance case's own checks. Then it lists the case's review questions.

## Results on the constructed replies

| Reply | Planted defect | Checker | Caught by the machine? |
|---|---|---|---|
| `good-pricing.md` | none | pass | n/a |
| `wrong-lesson.md` | real quote, wrong lesson named | exists: yes; right lesson: no, found in "Pricing your first offer" | yes |
| `dropped-qualification.md` | "No refunds promised" without "on results you don't control" | qualification: cut, and the case's own check fails | yes |
| `unsourced-numbers.md` | £2,400 lost a month, 40% more bookings, £750 setup, "expect to sign 3 clients" | 3 unsourced numbers, 1 possible promise; £1,500 declared as an assumption is accepted | yes, except "£400 a month" (passes because a lesson says "400 words") |
| `promise.md` | "We guarantee 20 new patients ... or your money back" | 1 possible promise; the negated sentence after it is not flagged | yes |
| `true-quote-wrong-conclusion.md` | full, correct quote of "Founding clients get the lower price ..." used to justify £100 a month | **pass** on every deterministic check, including the case's own | **no**: only the review question ("does it reject reading ... as permission to go below 300?") catches it |

The last row is the point: a reply can quote correctly and still be wrong. Acceptance therefore needs a person to
answer the review questions; the deterministic checks only remove the mechanical errors first.

## On recorded model outputs

| Output | Result |
|---|---|
| The three example outputs (`../examples/`) with their cases | pass |
| The 16 conversations in `../comparison/runs/` (whole transcripts, no case) | 11 pass. The 5 flagged: 4 citations (in two conversations) naming a lesson with no checkable quote; numbers computed from the member's facts (£250, £600) and not listed as assumptions, plus "6000" repeated from the task's limits outside a Check section; and, in 2 conversations, promise wording inside the member's own message, which a transcript includes and a saved reply wouldn't (a false positive) |

Not a measure of answer quality: it shows which kinds of problems the checker reports on real outputs.

## Limits

- Numbers are compared by value, not meaning, and counts under 100 aren't checked.
- Promise detection is word-based: it can miss a promise phrased differently, and flag a sentence a person would
  read as fine.
- Qualification detection only looks inside the quoted sentence; a limit stated in the next sentence isn't seen.
- No model grades anything here. A model grader could help sort cases, but its judgement is fallible and isn't
  independent verification; acceptance decisions stay with a person.
