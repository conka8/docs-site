No, don't offer your money back. The lessons rule out refunds *(Lesson: "Pricing your first offer": "No refunds promised")*.
