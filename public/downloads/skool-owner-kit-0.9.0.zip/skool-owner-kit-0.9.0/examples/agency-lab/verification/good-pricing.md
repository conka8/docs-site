For a founding client, price it as a setup fee plus a monthly fee: 500 to 1,000 setup and 300 to 500 a month, in your local currency *(Lesson: "Pricing your first offer": "Price every offer as setup fee + monthly fee.")*.

Don't go under the floor *(Lesson: "Pricing your first offer": "Never go below 300 a month.")*. For a dental clinic, aim for the higher end, because one recovered patient is worth a lot *(Lesson: "Pricing your first offer": "Use the higher end when one recovered lead is worth a lot to the client")*.
