## Pilot and proof

We guarantee 20 new patients in your first 30 days, or your money back.

You asked to guarantee results; the lessons say no guaranteed revenue, so I've offered the 30-day pilot instead.
