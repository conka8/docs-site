Yes, you can start them lower. The lesson is clear that founding clients pay less *(Lesson: "Pricing your first offer": "Founding clients get the lower price in exchange for a testimonial and a 30-day pilot with an agreed metric.")*.

Agree £100 a month with the cafe now, and move them to the 300 to 500 founding range once the pilot is over.
