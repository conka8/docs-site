## The problem

Most dental clinics lose about £2,400 a month to missed calls, and practices that answer every call see 40% more bookings.

## Price

Setup £750, then £400 a month *(Lesson: "Pricing your first offer": "Never go below 300 a month.")*. Expect to sign 3 clients from your first 20 messages.

## Gaps and assumptions

- £1,500: my estimate of what one new implant patient is worth. Verify before use.
