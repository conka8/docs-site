Keep your monthly fee at 300 or more *(Lesson: "The one-outcome offer": "Never go below 300 a month.")*.
