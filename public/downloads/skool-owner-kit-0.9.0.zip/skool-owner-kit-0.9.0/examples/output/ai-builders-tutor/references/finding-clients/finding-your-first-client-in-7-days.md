# Finding Your First Client in 7 Days

Module: Finding clients  
Source file: 02-finding-clients/2 - Finding your first client in 7 days.md  
Classroom: https://www.skool.com/your-community/classroom  

Day 1: list 50 local businesses in your niche.
Day 2: record a 60-second Loom for the top 10.
Day 3-5: send the Looms, follow up once.
Day 6-7: book calls and use the discovery-call script.
