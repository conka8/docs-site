# The AI Agency Offer That Sells

Module: Finding clients  
Source file: 02-finding-clients/1 - The offer that sells.html  
Classroom: https://www.skool.com/your-community/classroom  

Sell an outcome, not a tool. Example: "We answer every missed call in 60 seconds".

- Pick one niche (dentists, roofers, med spas).
- Pick one painful problem.
- Price it monthly.

Template: offer template (https://example.com/offer-template)
