# AI basics in 20 minutes

Module: Start here  
Source file: 01-start-here/02-ai-basics-in-20-minutes.txt  
Classroom: https://www.skool.com/your-community/classroom  

AI basics in 20 minutes

A large language model predicts text. You give it instructions (a prompt) and context.
Good prompts say who the AI is, what the task is, what good output looks like, and give one example.

Exercise: write a prompt that turns a messy customer email into a polite reply.
