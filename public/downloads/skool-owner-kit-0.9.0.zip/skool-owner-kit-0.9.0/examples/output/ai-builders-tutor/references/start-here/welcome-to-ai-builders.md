# Welcome to AI Builders

Module: Start here  
Source file: 01-start-here/01-welcome.md  
Classroom: https://www.skool.com/your-community/classroom  

This community helps you make money with AI, even if you are not technical.

## How the classroom works

Work through the modules in order. Each lesson has a short video and a checklist.
Post your progress in the Wins channel every Friday.

## Your first week

1. Watch the AI basics lesson.
2. Introduce yourself in the community.
3. Join the Tuesday live call.
