# New member onboarding messages

10 member(s).

## Ben Moore

- Email: ben.1@example.com
- Segment: Beginner (matched: non-technical, curious)
- Goal: get comfortable using AI
- Source: template

```text
Hey Ben, welcome to AI Builders! Since you want to get comfortable using AI, here's your first week:
1. Start Here: How This Community Works
2. AI Basics in 20 Minutes
3. Your First Automation (Step by Step)
Your first action: Post a quick intro in the community: who you are and the one thing you want AI to do for you.
Reply here if you get stuck. Happy to help!
```

## Ivy Kim

- Email: ivy.8@example.com
- Segment: Developer (matched: engineer, software engineer)
- Goal: build and launch your first app
- Source: template

```text
Hey Ivy, welcome to AI Builders! Since you want to build and launch your first app, here's your first week:
1. Start Here: How This Community Works
2. Build an App with Claude Code
3. Deploying Your App Safely
Your first action: Share what you're building (a link or a screenshot) in the community.
Reply here if you get stuck. Happy to help!
```

## Jay Carter

- Email: jay.9@example.com
- Segment: Agency owner (matched: agency, marketing agency)
- Goal: automate your business
- Source: template

```text
Hey Jay, welcome to AI Builders! Since you want to automate your business, here's your first week:
1. Start Here: How This Community Works
2. The AI Agency Offer That Sells
3. Finding Your First Client in 7 Days
Your first action: Write down 10 local businesses you could help and share your niche in the wins channel.
Reply here if you get stuck. Happy to help!
```

## Quinn Okafor

- Email: quinn.16@example.com
- Segment: Business owner (matched: my business, clinic)
- Goal: automate your business
- Source: template

```text
Hey Quinn, welcome to AI Builders! Since you want to automate your business, here's your first week:
1. Start Here: How This Community Works
2. Automate Your Business: First 3 Workflows
3. AI Customer Support in an Afternoon
Your first action: List the 3 tasks that eat most of your week and post them; we'll suggest which to automate first.
Reply here if you get stuck. Happy to help!
```

## Sara Stone

- Email: sara.18@example.com
- Segment: Agency owner (matched: clients, freelance)
- Goal: land your first client
- Source: template

```text
Hey Sara, welcome to AI Builders! Since you want to land your first client, here's your first week:
1. Start Here: How This Community Works
2. The AI Agency Offer That Sells
3. Finding Your First Client in 7 Days
Your first action: Write down 10 local businesses you could help and share your niche in the wins channel.
Reply here if you get stuck. Happy to help!
```

## Wes Brandt

- Email: wes.22@example.com
- Segment: Agency owner (matched: agency, marketing agency)
- Goal: automate your business
- Source: template

```text
Hey Wes, welcome to AI Builders! Since you want to automate your business, here's your first week:
1. Start Here: How This Community Works
2. The AI Agency Offer That Sells
3. Finding Your First Client in 7 Days
Your first action: Write down 10 local businesses you could help and share your niche in the wins channel.
Reply here if you get stuck. Happy to help!
```

## Bo Stone

- Email: bo.27@example.com
- Segment: Beginner (matched: non-technical, curious)
- Goal: get comfortable using AI
- Source: template

```text
Hey Bo, welcome to AI Builders! Since you want to get comfortable using AI, here's your first week:
1. Start Here: How This Community Works
2. AI Basics in 20 Minutes
3. Your First Automation (Step by Step)
Your first action: Post a quick intro in the community: who you are and the one thing you want AI to do for you.
Reply here if you get stuck. Happy to help!
```

## Dev Okafor

- Email: dev.29@example.com
- Segment: Developer (matched: engineer, software engineer)
- Goal: build and launch your first app
- Source: template

```text
Hey Dev, welcome to AI Builders! Since you want to build and launch your first app, here's your first week:
1. Start Here: How This Community Works
2. Build an App with Claude Code
3. Deploying Your App Safely
Your first action: Share what you're building (a link or a screenshot) in the community.
Reply here if you get stuck. Happy to help!
```

## Ella Carter

- Email: ella.30@example.com
- Segment: Developer (matched: engineer, software engineer)
- Goal: build and launch your first app
- Source: template

```text
Hey Ella, welcome to AI Builders! Since you want to build and launch your first app, here's your first week:
1. Start Here: How This Community Works
2. Build an App with Claude Code
3. Deploying Your App Safely
Your first action: Share what you're building (a link or a screenshot) in the community.
Reply here if you get stuck. Happy to help!
```

## Gus Kim

- Email: gus.32@example.com
- Segment: Business owner (matched: real estate)
- Goal: automate your business
- Source: template

```text
Hey Gus, welcome to AI Builders! Since you want to automate your business, here's your first week:
1. Start Here: How This Community Works
2. Automate Your Business: First 3 Workflows
3. AI Customer Support in an Afternoon
Your first action: List the 3 tasks that eat most of your week and post them; we'll suggest which to automate first.
Reply here if you get stuck. Happy to help!
```
