---
name: skool-onboarding
description: Writes personalised first-week welcome messages for new Skool community members from the owner's own member export (CSV) or Zapier webhook, using the skool-kit CLI. Segments members by their join-question answers (beginner, agency owner, developer, business owner, job seeker), picks 3 classroom lessons and a first action. Use when a Skool owner asks to welcome, onboard or DM new members, or to set up automatic welcome messages.
---

# Skool new-member onboarding

Use the `skool-kit` command line tool (package `skool-owner-kit`). It only uses the owner's own data:
a member CSV export or Zapier "new member" events. Never scrape Skool or ask for the owner's Skool login.

## One-off: welcome everyone who joined recently

1. Ask the owner for their member export CSV (the member export from their Skool admin settings, or a Google Sheet
   filled by Zapier).
2. Check how the file is read, and fix column names if needed:
   `skool-kit inspect members.csv`
   If the join answers or emails were not detected, add `--map "Exact Column Name=answers"` (fields: name, first_name,
   last_name, email, joined, answers, level, points, last_active, posts, comments, price, plan, invited_by, ltv).
   For day/month/year dates add `--dayfirst`.
3. Make the lesson names match the owner's classroom:
   `skool-kit rules -o rules.yaml`, then edit the lesson names, first actions and the welcome text in `rules.yaml`
   (ask the owner for their real lesson titles; do not invent them).
4. Generate the messages:
   `skool-kit onboard members.csv --since 2026-10-01 --rules rules.yaml --community-name "Their Community" -o messages.csv`
   Use `-o messages.md` for an easy-to-read review copy.
5. Show the owner 2-3 messages and the segment counts. They paste them into Skool DMs (or a Zapier/email step).
   Optional: `--llm anthropic` (needs `ANTHROPIC_API_KEY`) rewrites each message to sound more personal;
   if the LLM fails, the template message is used and the reason is printed.

## Automatic: Zapier webhook

1. Start the receiver on a machine with a public HTTPS URL (or a tunnel). Have the owner set the secret
   in their own terminal (`export SKOOL_KIT_SECRET="LONG-RANDOM-SECRET"`); never put it in chat. Then:
   `skool-kit webhook --host 0.0.0.0 --port 8787 --rules rules.yaml --forward-url "https://hooks.zapier.com/hooks/catch/..."`
2. In Zapier (Skool's Zapier app needs the Skool Pro plan): trigger = Skool **"Answered Membership Questions"**
   (or **"New Paid Member"** for paid groups; there is no trigger for every free member) -> action
   "Webhooks by Zapier: POST" to `https://their-host:8787/`, header `X-Skool-Kit-Secret` = the secret,
   payload type JSON, include name, email and answer fields.
3. Each new member gets a message in `outbox.jsonl`, and it is forwarded to the second Zap (send email/DM).
   Wrong secret = 401, bad JSON = 400. If the field names differ, add `--map "Zapier Field Name=email"`.

## Rules of thumb

- Keep messages short and human; lesson names must match the classroom exactly.
- Members' answers are personal data: don't paste them anywhere except the owner's own tools.
