"""Check that a reply's lesson citations point at passages the lessons actually contain.

The pack's skills cite like *(Lesson: "Pricing your first offer": "Never go below 300 a month.")*: the lesson title,
then the supporting sentence copied from the lesson file. This module finds those citations in a reply and checks
each one against the reference files shipped in the skills: the title must be a real lesson and the passage must
appear in it (ignoring case, spacing, Markdown emphasis and the kind of quote marks). It doesn't judge whether the
passage supports the point being made; that still needs a reader.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path

QUOTES = str.maketrans({c: "'" for c in "\"“”‘’`"})
CITATION = re.compile(r"Lesson:\s*\"([^\"\n]+)\"(?:,\s*module\s*\"[^\"\n]*\")?(?:\s*[:—-]\s*\"([^\"\n]+)\")?")
HEADING = re.compile(r"^#\s+(.+?)(?:\s+\(part \d+ of \d+\))?\s*$")


@dataclass
class Citation:
    lesson: str
    passage: str
    status: str  # ok | unknown lesson | no passage | passage not found


def normalise(text: str) -> str:
    text = text.replace("“", '"').replace("”", '"').translate(QUOTES)
    text = re.sub(r"[*_]+", "", text)
    text = text.replace("—", "-").replace("–", "-")
    return re.sub(r"\s+", " ", text).strip().lower()


def load_lessons(paths: list[Path]) -> dict[str, str]:
    """Lesson title -> normalised text, from every references/ file under the given skill or pack folders."""
    lessons: dict[str, dict[str, str]] = {}
    for root in paths:
        for f in sorted(Path(root).rglob("*.md")):
            if "references" not in f.parts:
                continue
            text = f.read_text(encoding="utf-8")
            m = HEADING.match(text.partition("\n")[0])
            if m:
                lessons.setdefault(normalise(m.group(1)), {})[f.name] = normalise(text)
    # The same lesson ships in several skills; keep one copy of each part, in part order.
    return {title: " ".join(parts[k] for k in sorted(parts)) for title, parts in lessons.items()}


def _found(passage: str, text: str) -> bool:
    pos = 0
    for frag in (p.strip(" .,;:'") for p in re.split(r"\.\.\.|…", passage)):
        if not frag:
            continue
        pos = text.find(frag, pos)
        if pos < 0:
            return False
        pos += len(frag)
    return True


def check_citations(reply: str, lessons: dict[str, str]) -> list[Citation]:
    text = reply.replace("“", '"').replace("”", '"')
    out = []
    for m in CITATION.finditer(text):
        title, passage = m.group(1).strip(), (m.group(2) or "").strip()
        body = lessons.get(normalise(title))
        if body is None:
            status = "unknown lesson"
        elif not passage:
            status = "no passage"
        else:
            status = "ok" if _found(normalise(passage), body) else "passage not found"
        out.append(Citation(title, passage, status))
    return out
