"""Self-contained HTML dashboard (inline CSS + inline SVG charts, no JavaScript, prints to PDF)."""
from __future__ import annotations

import html
import re

from .health import KPIs, MemberHealth

_HEX = re.compile(r"^#(?:[0-9a-fA-F]{3}|[0-9a-fA-F]{6})$")


def esc(v) -> str:
    return html.escape("" if v is None else str(v), quote=True)


def column_chart(items: list[tuple[str, float]], value_fmt=lambda v: f"{v:g}", title: str = "",
                 width: int = 640, height: int = 200, max_value: float | None = None) -> str:
    """Single-series column chart: bars <= 24px, 4px rounded tops, value on the cap, one baseline."""
    if not items:
        return '<p class="muted">No data yet.</p>'
    top_pad, bottom_pad, side = 22, 34, 8
    plot_h = height - top_pad - bottom_pad
    n = len(items)
    band = (width - 2 * side) / n
    bar_w = min(24.0, band * 0.6)
    vmax = max_value if max_value else max((v for _, v in items), default=0) or 1
    parts = [f'<svg viewBox="0 0 {width} {height}" width="{width}" style="max-width:100%;height:auto" role="img" '
             f'aria-label="{esc(title)}" '
             f'xmlns="http://www.w3.org/2000/svg" class="chart">']
    base_y = top_pad + plot_h
    for i, (label, value) in enumerate(items):
        v = max(0.0, float(value or 0))
        h = 0 if vmax <= 0 else plot_h * min(v, vmax) / vmax
        cx = side + band * i + band / 2
        x = cx - bar_w / 2
        y = base_y - h
        r = min(4.0, h, bar_w / 2)
        if h > 0:
            path = (f"M{x:.1f},{base_y:.1f} V{y + r:.1f} Q{x:.1f},{y:.1f} {x + r:.1f},{y:.1f} "
                    f"H{x + bar_w - r:.1f} Q{x + bar_w:.1f},{y:.1f} {x + bar_w:.1f},{y + r:.1f} V{base_y:.1f} Z")
            bar = f'<path d="{path}" class="bar"/>'
        else:
            bar = ""
        # hit target bigger than the mark, carries the tooltip
        parts.append(f'<g><title>{esc(label)}: {esc(value_fmt(value))}</title>'
                     f'<rect x="{side + band * i:.1f}" y="{top_pad}" width="{band:.1f}" height="{plot_h}" fill="transparent"/>'
                     f'{bar}<text x="{cx:.1f}" y="{y - 6:.1f}" class="val" text-anchor="middle">{esc(value_fmt(value))}</text>'
                     f'<text x="{cx:.1f}" y="{base_y + 16:.1f}" class="lbl" text-anchor="middle">{esc(label)}</text></g>')
    parts.append(f'<line x1="{side}" y1="{base_y}" x2="{width - side}" y2="{base_y}" class="axis"/></svg>')
    return "".join(parts)


def _fmt_pct(v) -> str:
    return "n/a" if v is None else f"{v:.0f}%"


def render_dashboard(kpis: KPIs, healths: list[MemberHealth], risky: list[MemberHealth], community_name: str = "",
                     brand_color: str = "", currency: str = "$", max_rows: int = 50) -> str:
    accent = brand_color if _HEX.match(brand_color or "") else "#2a78d6"
    title = f"{community_name} community health" if community_name else "Community health"
    tiles = [
        ("Members", f"{kpis.total_members:,}", f"{kpis.paid_members:,} paying"),
        ("Active last 7 days", _fmt_pct(kpis.active_7d_pct), f"{kpis.active_7d:,} members"),
        ("Active last 30 days", _fmt_pct(kpis.active_30d_pct), f"{kpis.active_30d:,} members"),
        ("New per week", f"{kpis.avg_joins_per_week:g}", f"average, last {len(kpis.joins_per_week)} weeks"),
        ("At-risk paying members", f"{kpis.at_risk_paying:,}",
         f"{currency}{kpis.revenue_at_risk:,.0f} per billing period" if kpis.revenue_at_risk else f"{kpis.at_risk:,} at risk in total"),
    ]
    tile_html = "".join(f'<div class="tile"><div class="tl">{esc(a)}</div><div class="tv">{esc(b)}</div>'
                        f'<div class="ts">{esc(c)}</div></div>' for a, b, c in tiles)
    joins_chart = column_chart([(j["week_start"][5:], j["count"]) for j in kpis.joins_per_week],
                               lambda v: f"{v:g}", "New members per week")
    cohort_chart = column_chart([(c["month"], c["retention_pct"] or 0) for c in kpis.cohorts],
                                lambda v: f"{v:.0f}%", "Share of each join-month cohort active in the last 30 days",
                                width=960, max_value=100)
    bands = kpis.risk_bands
    band_chart = column_chart([("High risk", bands["high"]), ("Medium", bands["medium"]), ("Low", bands["low"])],
                              lambda v: f"{v:g}", "Members by inactivity risk", width=300)
    contrib_rows = "".join(
        f"<tr><td>{esc(c['name'])}</td><td class=num>{esc(c['contributions'])}</td>"
        f"<td class=num>{esc(c['points'] if c['points'] is not None else '-')}</td>"
        f"<td class=num>{esc(c['level'] if c['level'] is not None else '-')}</td></tr>"
        for c in kpis.top_contributors) or '<tr><td colspan="4" class="muted">No posts or comments in the export.</td></tr>'
    risk_rows = "".join(
        f"<tr><td><strong>{esc(h.member.name or h.member.email)}</strong><div class=muted>{esc(h.member.email)}</div></td>"
        f'<td class=num><span class="badge {esc(h.band)}">{h.risk}</span></td>'
        f"<td>{'Paid' if h.member.is_paid else ('Free' if h.member.is_paid is False else '?')}</td>"
        f"<td>{esc('; '.join(r.text for r in h.reasons if r.points > 0))}</td>"
        f"<td class=msg>{esc(h.suggestion)}</td></tr>"
        for h in risky[:max_rows]) or '<tr><td colspan="5" class="muted">Nobody is at risk right now.</td></tr>'
    more = (f'<p class="muted">Showing {max_rows} of {len(risky)}. The full list is in the CSV/JSON export.</p>'
            if len(risky) > max_rows else "")
    cohort_table = "".join(f"<tr><td>{esc(c['month'])}</td><td class=num>{c['members']}</td>"
                           f"<td class=num>{c['active_30d']}</td><td class=num>{_fmt_pct(c['retention_pct'])}</td></tr>"
                           for c in kpis.cohorts)
    return f"""<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>{esc(title)}</title>
<style>
:root{{--surface:#fcfcfb;--card:#ffffff;--text:#0b0b0b;--text2:#52514e;--line:#e3e2de;--series:{accent};
--high:#c62828;--medium:#b26a00;--low:#1a7f37}}
@media (prefers-color-scheme: dark){{:root:not([data-theme="light"]){{--surface:#1a1a19;--card:#232321;--text:#f0efec;
--text2:#c3c2b7;--line:#3a3936;--high:#ef6b6b;--medium:#e3a33b;--low:#4cc06a}}}}
:root[data-theme="dark"]{{--surface:#1a1a19;--card:#232321;--text:#f0efec;--text2:#c3c2b7;--line:#3a3936;--high:#ef6b6b;--medium:#e3a33b;--low:#4cc06a}}
*{{box-sizing:border-box}}
body{{margin:0;background:var(--surface);color:var(--text);font:15px/1.45 -apple-system,Segoe UI,Roboto,Helvetica,Arial,sans-serif;padding:24px 16px}}
.wrap{{max-width:1040px;margin:0 auto}}
h1{{font-size:24px;margin:0 0 4px}} h2{{font-size:17px;margin:0 0 10px}}
.muted{{color:var(--text2);font-size:13px}}
.tiles{{display:grid;grid-template-columns:repeat(auto-fit,minmax(170px,1fr));gap:12px;margin:20px 0}}
.tile,.card{{background:var(--card);border:1px solid var(--line);border-radius:10px;padding:14px}}
.tl{{font-size:13px;color:var(--text2)}} .tv{{font-size:28px;font-weight:700}} .ts{{font-size:12px;color:var(--text2)}}
.grid{{display:grid;grid-template-columns:2fr 1fr;gap:12px;margin-bottom:12px}}
@media (max-width:760px){{.grid{{grid-template-columns:1fr}}}}
.card{{margin-bottom:12px;overflow-x:auto}}
.chart .bar{{fill:var(--series)}} .chart .val{{font-size:11px;fill:var(--text)}} .chart .lbl{{font-size:10px;fill:var(--text2)}}
.chart .axis{{stroke:var(--line);stroke-width:1}}
table{{width:100%;border-collapse:collapse;font-size:14px}}
th,td{{text-align:left;padding:7px 8px;border-bottom:1px solid var(--line);vertical-align:top}}
th{{font-size:12px;color:var(--text2);font-weight:600}}
td.num,th.num{{text-align:right}} td.msg{{font-size:13px;max-width:360px}}
.badge{{display:inline-block;min-width:34px;text-align:center;border-radius:999px;padding:1px 8px;font-weight:700;color:#fff}}
.badge.high{{background:var(--high)}} .badge.medium{{background:var(--medium)}} .badge.low{{background:var(--low)}}
@media print{{body{{background:#fff;padding:0}} .card,.tile{{break-inside:avoid}}}}
</style></head><body><div class="wrap">
<h1>{esc(title)}</h1>
<div class="muted">As of {esc(kpis.as_of)}. Built from your own Skool exports with skool-owner-kit. Risk scores are a simple, transparent heuristic from activity data (<a href="#how">how they work</a>); check a member before you message them.</div>
<div class="tiles">{tile_html}</div>
<div class="grid">
<div class="card"><h2>New members per week</h2>{joins_chart}</div>
<div class="card"><h2>Inactivity risk</h2>{band_chart}
<div class="muted">High = score 60+, medium = 35-59. A score from activity signals, not a prediction of who will cancel.</div></div>
</div>
<div class="card"><h2>Cohort activity</h2>
<div class="muted">Of the current members who joined in each month, the share active in the last 30 days. The export only lists current members, so people who left are not counted: this is not a cancellation or retention rate.</div>
{cohort_chart}
<table><thead><tr><th>Joined</th><th class=num>Members</th><th class=num>Active (30d)</th><th class=num>Active %</th></tr></thead>
<tbody>{cohort_table}</tbody></table></div>
<div class="card"><h2>At-risk members ({len(risky)})</h2>
<table><thead><tr><th>Member</th><th class=num>Risk</th><th>Plan</th><th>Why</th><th>Suggested message</th></tr></thead>
<tbody>{risk_rows}</tbody></table>{more}</div>
<div class="card"><h2>Top contributors</h2>
<table><thead><tr><th>Member</th><th class=num>Posts + comments</th><th class=num>Points</th><th class=num>Level</th></tr></thead>
<tbody>{contrib_rows}</tbody></table></div>
<div class="card" id="how"><h2>How to read this</h2><ul class="muted">
<li>Risk score (0-100) adds points for days since last active, never posting, posting less, no new posts between exports and a stuck level, and takes off a few for long-time members. 60+ is high, 35-59 medium.</li>
<li>Paying vs free doesn't change the score. Paying members are listed first.</li>
<li>Trends need several weekly exports stacked into an activity file. With one export, the score uses last-active date, posts, level and tenure only.</li>
<li>Skool's export columns are not publicly documented. Run <code>skool-kit inspect</code> to see which columns were used.</li>
</ul></div>
</div></body></html>
"""
