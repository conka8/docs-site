"""Tolerant date parsing for CSV exports and webhook payloads.

Accepts ISO dates/times (with or without Z/offset), US m/d/Y (with or without time, AM/PM),
"Oct 3, 2026", "October 3, 2026 2:15 PM", "3 Oct 2026", and relative values like "3d ago",
"2 weeks ago", "today", "yesterday". Returns a naive datetime in UTC, or None.
"""
from __future__ import annotations

import re
from datetime import date, datetime, timedelta, timezone

_FORMATS_US = (
    "%m/%d/%Y", "%m/%d/%y", "%m/%d/%Y %H:%M", "%m/%d/%Y %H:%M:%S", "%m/%d/%Y %I:%M %p", "%m/%d/%Y %I:%M:%S %p",
    "%m/%d/%y %H:%M", "%m/%d/%y %I:%M %p", "%m-%d-%Y", "%m-%d-%Y %H:%M",
)
_FORMATS_DAYFIRST = (
    "%d/%m/%Y", "%d/%m/%y", "%d/%m/%Y %H:%M", "%d/%m/%Y %H:%M:%S", "%d/%m/%Y %I:%M %p", "%d.%m.%Y",
    "%d.%m.%Y %H:%M", "%d-%m-%Y",
)
_FORMATS_OTHER = (
    "%Y/%m/%d", "%Y/%m/%d %H:%M", "%Y/%m/%d %H:%M:%S",
    "%b %d, %Y", "%B %d, %Y", "%b %d %Y", "%B %d %Y",
    "%b %d, %Y %I:%M %p", "%B %d, %Y %I:%M %p", "%b %d, %Y %H:%M", "%b %d, %Y, %I:%M %p", "%B %d, %Y, %I:%M %p",
    "%a, %b %d, %Y", "%A, %B %d, %Y", "%a %b %d %Y", "%a %b %d %Y %H:%M:%S",
    "%d %b %Y", "%d %B %Y", "%d %b %Y %H:%M", "%d %B %Y %H:%M", "%Y%m%d",
)
_REL = re.compile(r"^(\d+)\s*(m|min|mins|minute|minutes|h|hr|hrs|hour|hours|d|day|days|w|wk|wks|week|weeks|"
                  r"mo|month|months|y|yr|yrs|year|years)\s*(ago)?$")
_UNIT_DAYS = {"m": 0, "min": 0, "mins": 0, "minute": 0, "minutes": 0, "h": 0, "hr": 0, "hrs": 0, "hour": 0,
              "hours": 0, "d": 1, "day": 1, "days": 1, "w": 7, "wk": 7, "wks": 7, "week": 7, "weeks": 7,
              "mo": 30, "month": 30, "months": 30, "y": 365, "yr": 365, "yrs": 365, "year": 365, "years": 365}


def _clean(text: str) -> str:
    t = " ".join(text.replace(" ", " ").split())
    t = re.sub(r"(\d)(st|nd|rd|th)\b", r"\1", t, flags=re.I)  # 3rd -> 3
    t = re.sub(r"\b([A-Za-z]{3,9})\.", r"\1", t)  # "Oct." -> "Oct"
    t = re.sub(r"\s+at\s+", " ", t, flags=re.I)  # "Oct 3, 2026 at 2:15 PM"
    t = re.sub(r"\s*(UTC|GMT)$", "", t, flags=re.I)
    t = re.sub(r"(?i)(\d)\s*([ap])\.?m\.?(?![a-z])", lambda m: f"{m.group(1)} {m.group(2).upper()}M", t)
    return t


def _now(today: datetime | date | None) -> datetime:
    if today is None:
        return datetime.now(timezone.utc).replace(tzinfo=None)
    if isinstance(today, datetime):
        return today.replace(tzinfo=None) if today.tzinfo is None else today.astimezone(timezone.utc).replace(tzinfo=None)
    return datetime(today.year, today.month, today.day)


def parse_date(value, dayfirst: bool = False, today: datetime | date | None = None) -> datetime | None:
    if value is None:
        return None
    if isinstance(value, datetime):
        return value.astimezone(timezone.utc).replace(tzinfo=None) if value.tzinfo else value
    if isinstance(value, date):
        return datetime(value.year, value.month, value.day)
    text = str(value).strip()
    if not text or text.lower() in ("-", "n/a", "na", "none", "null", "never"):
        return None
    low = text.lower()
    if low in ("today", "now", "just now", "online now"):
        return _now(today)
    if low == "yesterday":
        return _now(today) - timedelta(days=1)
    rel = _REL.match(low.replace("active ", "").strip())
    if rel:
        n, unit = int(rel.group(1)), rel.group(2)
        days = _UNIT_DAYS[unit]
        if days == 0:
            hours = n if unit.startswith("h") else n / 60
            return _now(today) - timedelta(hours=hours)
        return _now(today) - timedelta(days=n * days)
    # epoch seconds / milliseconds
    if re.fullmatch(r"\d{10}(\d{3})?", text):
        num = int(text)
        if num > 1e11:
            num //= 1000
        return datetime.fromtimestamp(num, tz=timezone.utc).replace(tzinfo=None)
    iso = text[:-1] + "+00:00" if text[-1:] in "Zz" else text
    try:
        dt = datetime.fromisoformat(iso)
        return dt.astimezone(timezone.utc).replace(tzinfo=None) if dt.tzinfo else dt
    except ValueError:
        pass
    t = _clean(text)
    first, second = (_FORMATS_DAYFIRST, _FORMATS_US) if dayfirst else (_FORMATS_US, _FORMATS_DAYFIRST)
    for fmt in first + _FORMATS_OTHER + second:  # second: e.g. 25/12/2026 when not dayfirst
        try:
            return datetime.strptime(t, fmt)
        except ValueError:
            continue
    return None
