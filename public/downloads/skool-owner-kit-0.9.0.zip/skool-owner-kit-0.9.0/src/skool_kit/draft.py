"""`skool-kit pack-draft`: a first pack.yaml from the lessons, for the owner to correct and approve.

It reads the classroom folder the same way pack-build does and writes a spec with:
- one draft task per module, its steps taken from the module's lessons in classroom order;
- rules copied word for word from the lessons (bullet points under a "Rules" or "Common mistakes" heading, and
  bullets that start with Never / Always / Only / No / Don't), each tied to its lesson;
- every decision only the owner can make marked `TODO (owner)`: the first outcome, what members must say first,
  the deliverable, where questions go.

Nothing here is invented: what the lessons don't say is left as a TODO. pack-share refuses to share a pack that
still contains one, so a draft can be built and previewed but not sent to members by mistake.
"""
from __future__ import annotations

import re
from pathlib import Path

import yaml

from .classroom import discover, slugify

TODO = "TODO (owner)"
RULE_HEADING = re.compile(r"^#{2,4}\s*(rules?|common mistakes|don'?ts?|mistakes)\b", re.I)
RULE_BULLET = re.compile(r"^\s*[-*]\s+(\*\*)?(never|always|only|no|don'?t|do not)\b", re.I)
BULLET = re.compile(r"^\s*[-*]\s+(.+)$")


def lesson_rules(text: str) -> list[str]:
    """Bullet points the lesson states as rules, word for word (Markdown emphasis removed)."""
    rules, under_heading, mistakes = [], False, False
    for line in text.splitlines():
        if line.startswith("#"):
            under_heading = bool(RULE_HEADING.match(line))
            mistakes = under_heading and "mistake" in line.lower()
            continue
        m = BULLET.match(line)
        if m and (under_heading or RULE_BULLET.match(line)):
            rule = re.sub(r"\*\*|__", "", m.group(1)).strip()
            if mistakes:
                rule = f"Avoid this common mistake from the lesson: {rule}"
            if rule not in rules:
                rules.append(rule)
    return rules


def draft_spec(classroom: str | Path, community: str, classroom_ref: str = "") -> tuple[str, dict]:
    """The draft's YAML text and a summary. `classroom_ref` is the classroom path as pack.yaml should name it."""
    modules, warnings = discover(classroom)
    if not modules:
        raise ValueError(f"no lessons found in {classroom}")
    rel = classroom_ref or str(classroom)
    playbooks, n_rules = [], 0
    for module in modules:
        steps, rules = [], []
        for lesson in module.lessons:
            steps.append({"do": f"{TODO}: what the member does with this lesson's method", "lesson": lesson.title})
            for rule in lesson_rules("\n".join(lesson.parts)):
                rules.append({"rule": rule, "lesson": lesson.title})
        n_rules += len(rules)
        playbooks.append({
            "name": slugify(module.title),
            "title": f"{TODO}: the task members finish with \"{module.title}\"",
            "outcome": f"{TODO}: the deliverable a member ends up with",
            "when": f"{TODO}: when a member wants to ...",
            "inputs": [{"name": "situation", "ask": f"{TODO}: what must the member tell you first?"}],
            "steps": steps,
            "rules": rules,
        })
    spec = {
        "community": community,
        "classroom": rel,
        "support": f"{TODO}: where members ask when the lessons don't cover something",
        "first_outcome": {
            "name": f"{TODO}: the first outcome's name",
            "definition": f"{TODO}: what a member has done, in countable terms",
            "within_days": 14,
            "how_to_report": f"{TODO}: how members report it (for example a post with a tag)",
        },
        "playbooks": playbooks,
    }
    header = (f"# DRAFT member pack spec for \"{community}\", made by `skool-kit pack-draft` from {rel}.\n"
              f"# Rules are copied from the lessons word for word. Everything marked {TODO} is a decision only the\n"
              "# owner can make; keep, merge or delete the draft tasks (one per module). pack-share refuses a pack\n"
              f"# that still contains {TODO}.\n#\n# Preview: skool-kit pack-build pack.yaml -o member-pack\n\n")
    text = header + yaml.safe_dump(spec, sort_keys=False, allow_unicode=True, width=110)
    return text, {"modules": len(modules), "lessons": sum(len(m.lessons) for m in modules), "rules": n_rules,
                  "todos": text.count(TODO) - 2, "warnings": warnings}
