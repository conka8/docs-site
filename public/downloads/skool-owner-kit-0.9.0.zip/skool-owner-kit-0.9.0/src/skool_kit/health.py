"""`skool-kit health`: churn-risk score per member and community KPIs from member/activity exports.

Risk score (0-100, higher = more likely to leave), sum of:
  inactivity     last active 4-7 days: +10, 8-14: +25, 15-30: +40, 31+: +55, unknown: +20
  never posted   0 posts+comments and member 14+ days: +15 (newer than 14 days: +5)
  trend          needs 2+ activity snapshots: stopped posting +20, posting less than half as often +12,
                 no new posts since the last snapshot +8
  level          stuck on the same level for 28+ days (snapshots) or still level 1 after 30 days: +10
  tenure         member for 180+ days: -5 (long-time members leave less often)
Paid vs free does not change the score; it sets the order of the at-risk list and the
"at-risk paying members" KPI.
"""
from __future__ import annotations

import csv
import io
import json
from collections import defaultdict
from dataclasses import dataclass, field
from datetime import datetime, timedelta

from .members import Member

HIGH, MEDIUM = 60, 35
SUGGESTIONS = {
    "inactive": "Hey {first_name}, haven't seen you around for a bit. Anything blocking you? Reply with your #1 goal "
                "right now and I'll point you to the exact lesson for it.",
    "never_posted": "Hey {first_name}! Would love to hear from you: drop a quick intro post (what you're working on "
                    "and one goal) and I'll reply personally.",
    "new_quiet": "Hey {first_name}, welcome again! The fastest way to get value here is the Start Here lesson and a "
                 "quick intro post. Want me to point you to the right first lesson?",
    "stopped": "Hey {first_name}, your posts were helping other members. What changed? If you're stuck on something, "
               "post it and tag me.",
    "slowing": "Hey {first_name}, quick check-in: how is your project going? Share where you're at and I'll suggest "
               "the next step.",
    "level": "Hey {first_name}, you're close to the next level. Comment on a few posts this week to unlock it and the "
             "lessons that come with it.",
    "ok": "Hey {first_name}, thanks for being part of the community! Anything you'd like more of?",
}


@dataclass
class Reason:
    kind: str
    points: int
    text: str


@dataclass
class MemberHealth:
    member: Member
    risk: int
    band: str
    reasons: list[Reason]
    engagement: int
    days_inactive: int | None
    tenure_days: int | None
    contributions: int | None
    suggestion: str = ""
    snapshots: int = 0

    @property
    def paid(self) -> bool:
        return bool(self.member.is_paid)

    def to_dict(self) -> dict:
        m = self.member
        return {
            "name": m.name, "email": m.email, "risk_score": self.risk, "band": self.band,
            "engagement_score": self.engagement, "paid": m.is_paid, "price": m.price, "plan": m.plan,
            "days_inactive": self.days_inactive, "tenure_days": self.tenure_days, "posts": m.posts,
            "comments": m.comments, "level": m.level, "points": m.points,
            "reasons": [r.text for r in self.reasons if r.points > 0],
            "suggested_message": self.suggestion,
        }


def band_for(risk: int) -> str:
    return "high" if risk >= HIGH else ("medium" if risk >= MEDIUM else "low")


def _days(as_of: datetime, dt: datetime | None) -> int | None:
    if dt is None:
        return None
    return max(0, (as_of - dt).days)


def score_member(m: Member, as_of: datetime, snapshots: list[Member] | None = None) -> MemberHealth:
    snaps = sorted([s for s in (snapshots or []) if s.snapshot_date], key=lambda s: s.snapshot_date)
    reasons: list[Reason] = []
    last_active = m.last_active
    if last_active is None and snaps:
        last_active = next((s.last_active for s in reversed(snaps) if s.last_active), None)
    if last_active is not None and m.joined is not None and last_active < m.joined:
        last_active = m.joined  # exports can't have activity before joining; trust the join date
    inactive = _days(as_of, last_active)
    tenure = _days(as_of, m.joined)
    contrib = m.contributions
    if contrib is None and snaps:
        contrib = snaps[-1].contributions

    if inactive is None:
        reasons.append(Reason("inactive", 20, "no last-active date in the export"))
    elif inactive > 30:
        reasons.append(Reason("inactive", 55, f"last active {inactive} days ago"))
    elif inactive > 14:
        reasons.append(Reason("inactive", 40, f"last active {inactive} days ago"))
    elif inactive > 7:
        reasons.append(Reason("inactive", 25, f"last active {inactive} days ago"))
    elif inactive > 3:
        reasons.append(Reason("inactive", 10, f"last active {inactive} days ago"))

    if contrib == 0:
        if tenure is not None and tenure < 14:
            reasons.append(Reason("new_quiet", 5, f"joined {tenure} days ago and hasn't posted yet"))
        else:
            reasons.append(Reason("never_posted", 15, "has never posted or commented"))

    series = [(s.snapshot_date, s.contributions) for s in snaps if s.contributions is not None]
    if len(series) >= 2:
        incs = [b[1] - a[1] for a, b in zip(series, series[1:])]
        last = incs[-1]
        if len(incs) >= 2:
            prev_avg = sum(incs[:-1]) / len(incs[:-1])
            if prev_avg > 0 and last <= 0:
                reasons.append(Reason("stopped", 20, f"stopped posting (was about {prev_avg:.0f} posts+comments "
                                                     f"per snapshot, none since {series[-2][0]:%b %d})"))
            elif prev_avg > 0 and last < 0.5 * prev_avg:
                reasons.append(Reason("slowing", 12, f"posting less ({prev_avg:.0f} -> {last} per snapshot)"))
        elif last <= 0 and (series[-1][1] or 0) > 0:
            reasons.append(Reason("stopped", 8, f"no new posts or comments since {series[-2][0]:%b %d}"))

    levels = [(s.snapshot_date, s.level) for s in snaps if s.level is not None]
    if len(levels) >= 2 and levels[0][1] == levels[-1][1] and (levels[-1][0] - levels[0][0]).days >= 28:
        span = (levels[-1][0] - levels[0][0]).days
        reasons.append(Reason("level", 10, f"stuck at level {levels[-1][1]} for {span} days"))
    elif len(levels) < 2 and m.level is not None and m.level <= 1 and tenure is not None and tenure >= 30:
        reasons.append(Reason("level", 10, f"still level {m.level} after {tenure} days"))

    if tenure is not None and tenure >= 180:
        reasons.append(Reason("tenure", -5, f"member for {tenure // 30} months (lowers risk)"))

    risk = max(0, min(100, sum(r.points for r in reasons)))
    # engagement: recency (0-50) + contribution rate (0-30) + level (0-20)
    if inactive is None:
        recency = 10
    else:
        recency = 50 if inactive <= 3 else 40 if inactive <= 7 else 25 if inactive <= 14 else 10 if inactive <= 30 else 0
    weeks = max(1.0, (tenure or 7) / 7)
    rate = (contrib or 0) / weeks
    engagement = recency + min(30, round(rate * 10)) + (min(20, (m.level - 1) * 4) if m.level else 0)
    top = max((r for r in reasons if r.points > 0), key=lambda r: r.points, default=None)
    template = SUGGESTIONS[top.kind] if top else SUGGESTIONS["ok"]
    suggestion = template.replace("{first_name}", m.first_name)
    return MemberHealth(m, risk, band_for(risk), reasons, max(0, min(100, engagement)), inactive, tenure, contrib,
                        suggestion, len(snaps))


def group_snapshots(activity: list[Member]) -> dict[str, list[Member]]:
    by: dict[str, list[Member]] = defaultdict(list)
    for a in activity:
        if a.email:
            by["e:" + a.email.casefold()].append(a)
        if a.name:
            by["n:" + a.name.casefold()].append(a)
    return by


def score_all(members: list[Member], as_of: datetime, activity: list[Member] | None = None) -> list[MemberHealth]:
    snaps = group_snapshots(activity or [])
    out = []
    for m in members:
        s = snaps.get("e:" + m.email.casefold()) if m.email else None
        if not s and m.name:
            s = snaps.get("n:" + m.name.casefold())
        out.append(score_member(m, as_of, s))
    return out


def at_risk(healths: list[MemberHealth], threshold: int = MEDIUM) -> list[MemberHealth]:
    """Members at or above threshold: highest risk first, paying members first on ties, then by price/LTV."""
    rows = [h for h in healths if h.risk >= threshold]
    return sorted(rows, key=lambda h: (-h.risk, not h.paid, -(h.member.price or 0), -(h.member.ltv or 0),
                                       h.member.name.lower()))


def _week_start(d: datetime) -> datetime:
    d = datetime(d.year, d.month, d.day)
    return d - timedelta(days=d.weekday())


def pct(n: int, d: int) -> float | None:
    return None if not d else round(100.0 * n / d, 1)


@dataclass
class KPIs:
    as_of: str
    total_members: int
    paid_members: int
    active_7d: int
    active_30d: int
    active_7d_pct: float | None
    active_30d_pct: float | None
    joins_per_week: list[dict]
    avg_joins_per_week: float
    at_risk: int
    at_risk_paying: int
    revenue_at_risk: float
    risk_bands: dict
    top_contributors: list[dict]
    cohorts: list[dict] = field(default_factory=list)

    def to_dict(self) -> dict:
        return dict(self.__dict__)


def compute_kpis(healths: list[MemberHealth], as_of: datetime, threshold: int = MEDIUM, weeks: int = 8,
                 months: int = 12) -> KPIs:
    total = len(healths)
    a7 = sum(1 for h in healths if h.days_inactive is not None and h.days_inactive <= 7)
    a30 = sum(1 for h in healths if h.days_inactive is not None and h.days_inactive <= 30)
    this_week = _week_start(as_of)
    starts = [this_week - timedelta(weeks=i) for i in range(weeks - 1, -1, -1)]
    counts = {s: 0 for s in starts}
    for h in healths:
        if h.member.joined:
            ws = _week_start(h.member.joined)
            if ws in counts:
                counts[ws] += 1
    joins = [{"week_start": s.strftime("%Y-%m-%d"), "count": counts[s]} for s in starts]
    risky = [h for h in healths if h.risk >= threshold]
    paying_risky = [h for h in risky if h.member.is_paid]
    bands = {"high": 0, "medium": 0, "low": 0}
    for h in healths:
        bands[h.band] += 1
    top = sorted((h for h in healths if (h.contributions or 0) > 0),
                 key=lambda h: (-(h.contributions or 0), -(h.member.points or 0), h.member.name.lower()))[:5]
    cohorts: dict[str, list[MemberHealth]] = defaultdict(list)
    for h in healths:
        if h.member.joined:
            cohorts[h.member.joined.strftime("%Y-%m")].append(h)
    cohort_rows = []
    for month in sorted(cohorts)[-months:]:
        group = cohorts[month]
        active = sum(1 for h in group if h.days_inactive is not None and h.days_inactive <= 30)
        cohort_rows.append({"month": month, "members": len(group), "active_30d": active,
                            "retention_pct": pct(active, len(group))})
    return KPIs(
        as_of=as_of.strftime("%Y-%m-%d"), total_members=total,
        paid_members=sum(1 for h in healths if h.member.is_paid),
        active_7d=a7, active_30d=a30, active_7d_pct=pct(a7, total), active_30d_pct=pct(a30, total),
        joins_per_week=joins, avg_joins_per_week=round(sum(j["count"] for j in joins) / weeks, 1) if weeks else 0.0,
        at_risk=len(risky), at_risk_paying=len(paying_risky),
        revenue_at_risk=round(sum(h.member.price or 0 for h in paying_risky), 2), risk_bands=bands,
        top_contributors=[{"name": h.member.name or h.member.email, "contributions": h.contributions,
                           "points": h.member.points, "level": h.member.level} for h in top],
        cohorts=cohort_rows,
    )


AT_RISK_COLUMNS = ("name", "email", "risk_score", "band", "paid", "price", "days_inactive", "tenure_days", "posts",
                   "comments", "level", "reasons", "suggested_message")


def at_risk_csv(rows: list[MemberHealth]) -> str:
    buf = io.StringIO()
    w = csv.writer(buf)
    w.writerow(AT_RISK_COLUMNS)
    for h in rows:
        d = h.to_dict()
        d["reasons"] = "; ".join(d["reasons"])
        d["paid"] = {True: "yes", False: "no", None: "unknown"}[d["paid"]]
        w.writerow(["" if d[c] is None else d[c] for c in AT_RISK_COLUMNS])
    return buf.getvalue()


def health_json(kpis: KPIs, rows: list[MemberHealth]) -> str:
    return json.dumps({"kpis": kpis.to_dict(), "at_risk": [h.to_dict() for h in rows]}, indent=2, ensure_ascii=False)
