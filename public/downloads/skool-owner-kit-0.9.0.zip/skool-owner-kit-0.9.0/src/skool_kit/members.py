"""Read Skool member exports (CSV) and webhook payloads with flexible column mapping.

Skool's export columns are not documented and differ between exports and tools (Zapier, Sheets),
so headers are matched against many common variants, case-insensitively. Anything can be
overridden with `--map "Column Name=field"`.
"""
from __future__ import annotations

import csv
import io
import re
from dataclasses import dataclass, field
from datetime import date, datetime
from pathlib import Path
from typing import Any

from .dates import parse_date

FIELDS = ("name", "first_name", "last_name", "email", "joined", "answers", "level", "points", "last_active",
          "posts", "comments", "price", "plan", "invited_by", "ltv", "snapshot_date")

ALIASES: dict[str, tuple[str, ...]] = {
    "name": ("name", "full name", "fullname", "member name", "member", "display name", "user name", "username",
             "member full name"),
    "first_name": ("first name", "firstname", "first", "given name", "fname"),
    "last_name": ("last name", "lastname", "last", "surname", "family name", "lname"),
    "email": ("email", "email address", "e mail", "e mail address", "mail", "member email", "user email"),
    "joined": ("joined", "join date", "joined date", "date joined", "joined at", "joined on", "approved at",
               "approved", "approved date", "approved on", "member since", "created at", "signup date",
               "sign up date", "start date"),
    "answers": ("answers", "answer", "membership questions", "membership question answers", "membership answers",
                "join questions", "join answers", "application answers", "survey answers", "survey", "questions",
                "onboarding answers"),
    "level": ("level", "member level", "skool level", "lvl"),
    "points": ("points", "total points", "score", "member points"),
    "last_active": ("last active", "last seen", "last activity", "last active at", "last online", "last login",
                    "last active date", "last seen at", "last visit"),
    "posts": ("posts", "post count", "number of posts", "posts count", "total posts", "num posts"),
    "comments": ("comments", "comment count", "number of comments", "comments count", "total comments",
                 "num comments"),
    "price": ("price", "plan price", "amount", "mrr", "subscription price", "monthly price", "billing amount"),
    "plan": ("plan", "tier", "membership", "membership type", "membership tier", "subscription", "billing",
             "recurring interval", "billing interval", "plan name", "membership plan"),
    "invited_by": ("invited by", "inviter", "referred by", "referrer", "affiliate", "invited", "referral"),
    "ltv": ("ltv", "lifetime value", "total paid", "revenue", "total revenue", "lifetime revenue"),
    "snapshot_date": ("date", "snapshot date", "snapshot", "export date", "exported at", "as of", "week",
                      "report date"),
}
_ALIAS_LOOKUP = {alias: f for f, names in ALIASES.items() for alias in names}
_ANSWER_RE = re.compile(r"^(?:membership |join |application |onboarding )?(?:question|answer|q|a)s? ?\d+(?: answer)?$")
NUMERIC = ("level", "points", "posts", "comments", "price", "ltv")
DATES = ("joined", "last_active", "snapshot_date")


def normalize_header(h: str) -> str:
    h = (h or "").replace("﻿", "").strip().lower()
    h = h.replace("#", " number ").replace("&", " and ")
    h = re.sub(r"[^a-z0-9?]+", " ", h)
    return " ".join(h.split())


class MappingError(ValueError):
    pass


@dataclass
class Member:
    row: int = 0
    name: str = ""
    email: str = ""
    joined: datetime | None = None
    answers: list[str] = field(default_factory=list)
    level: int | None = None
    points: int | None = None
    last_active: datetime | None = None
    posts: int | None = None
    comments: int | None = None
    price: float | None = None
    plan: str = ""
    invited_by: str = ""
    ltv: float | None = None
    snapshot_date: datetime | None = None
    first_name_raw: str = ""
    extra: dict = field(default_factory=dict)

    @property
    def first_name(self) -> str:
        if self.first_name_raw.strip():
            return self.first_name_raw.strip()
        if self.name.strip():
            return self.name.split()[0]
        if self.email:
            local = self.email.split("@")[0]
            local = re.split(r"[._\-+0-9]", local)[0]
            if local:
                return local.capitalize()
        return "there"

    @property
    def key(self) -> str:
        return (self.email or self.name).strip().casefold()

    @property
    def contributions(self) -> int | None:
        if self.posts is None and self.comments is None:
            return None
        return (self.posts or 0) + (self.comments or 0)

    @property
    def is_paid(self) -> bool | None:
        if self.price is not None:
            return self.price > 0
        plan = self.plan.strip().lower()
        if plan:
            words = set(re.split(r"[^a-z0-9$]+", plan))
            return not (words & {"free", "none", "trial", "0", "$0"})
        return None

    def to_dict(self) -> dict:
        def d(v):
            return v.isoformat(sep=" ") if isinstance(v, datetime) else v
        return {
            "name": self.name, "first_name": self.first_name, "email": self.email, "joined": d(self.joined),
            "answers": list(self.answers), "level": self.level, "points": self.points,
            "last_active": d(self.last_active), "posts": self.posts, "comments": self.comments, "price": self.price,
            "plan": self.plan, "invited_by": self.invited_by, "ltv": self.ltv, "paid": self.is_paid,
        }


@dataclass
class SkippedRow:
    row: int
    reason: str


@dataclass
class ImportResult:
    members: list[Member]
    skipped: list[SkippedRow]
    warnings: list[str]
    mapping: dict[str, list[str]]
    unmapped: list[str]
    delimiter: str = ","
    total_rows: int = 0


def parse_overrides(pairs: list[str] | None) -> dict[str, str]:
    """["Column Name=field", ...] -> {normalized column: field}."""
    out: dict[str, str] = {}
    for pair in pairs or []:
        if "=" not in pair:
            raise MappingError(f"--map needs COLUMN=FIELD, got {pair!r}")
        col, fld = pair.rsplit("=", 1)
        fld = fld.strip().lower().replace(" ", "_").replace("-", "_")
        if fld not in FIELDS and fld != "ignore":
            raise MappingError(f"--map: unknown field {fld!r}. Fields: {', '.join(FIELDS)}, ignore")
        out[normalize_header(col)] = fld
    return out


def detect_mapping(headers: list[str], overrides: dict[str, str] | None = None,
                   leaf_fallback: bool = False) -> tuple[dict[str, list[str]], list[str]]:
    """Map fields to columns. With leaf_fallback, "data.member.email" may also match on "email"."""
    overrides = overrides or {}
    mapping: dict[str, list[str]] = {}
    unmapped: list[str] = []
    norm_headers = {normalize_header(h) for h in headers}
    for col in overrides:
        if col not in norm_headers:
            raise MappingError(f"--map: column {col!r} is not in the data. Columns: {', '.join(headers)}")
    for h in headers:
        n = normalize_header(h)
        if not n:
            continue
        candidates = [n]
        if leaf_fallback and "." in h:
            candidates.append(normalize_header(h.rsplit(".", 1)[-1]))
        fld = overrides.get(n)
        for c in candidates:
            if fld is None:
                fld = _ALIAS_LOOKUP.get(c)
        for c in candidates:
            if fld is None and (_ANSWER_RE.match(c) or c.endswith("?")):
                fld = "answers"
        if fld is None or fld == "ignore":
            if fld is None:
                unmapped.append(h)
            continue
        if fld != "answers" and fld in mapping:
            unmapped.append(h)  # first matching column wins
            continue
        mapping.setdefault(fld, []).append(h)
    return mapping, unmapped


def _number(text: str) -> float | None:
    t = str(text).strip()
    if not t or t.lower() in ("-", "n/a", "none", "free"):
        return None if t.lower() != "free" else 0.0
    m = re.search(r"-?\d[\d,]*(?:\.\d+)?", t.replace(" ", ""))
    if not m:
        raise ValueError(t)
    return float(m.group(0).replace(",", ""))


def sniff_delimiter(sample: str) -> str:
    first_line = sample.splitlines()[0] if sample else ""
    try:
        d = csv.Sniffer().sniff(sample, delimiters=",;\t|").delimiter
        if d in first_line:
            return d
    except csv.Error:
        pass
    counts = {d: first_line.count(d) for d in (",", ";", "\t", "|")}
    best = max(counts, key=counts.get)
    return best if counts[best] else ","


def read_table(path: str | Path) -> tuple[list[str], list[list[str]], str, list[str]]:
    """Return headers, rows, delimiter, warnings. Handles BOM, ; and tab delimiters, Windows encodings."""
    raw = Path(path).read_bytes()
    warnings = []
    try:
        text = raw.decode("utf-8-sig")
    except UnicodeDecodeError:
        text = raw.decode("cp1252", errors="replace")
        warnings.append("file is not UTF-8; read it as Windows-1252 (check names with accents)")
    return (*_parse_text(text), warnings)


def _parse_text(text: str) -> tuple[list[str], list[list[str]], str]:
    if not text.strip():
        return [], [], ","
    delim = sniff_delimiter(text[:8192])
    rows = list(csv.reader(io.StringIO(text), delimiter=delim))
    while rows and not any(c.strip() for c in rows[0]):
        rows.pop(0)
    if not rows:
        return [], [], delim
    return [h.strip() for h in rows[0]], rows[1:], delim


def build_member(values: dict[str, Any], mapping: dict[str, list[str]], row: int, dayfirst: bool = False,
                 today: datetime | date | None = None, warnings: list[str] | None = None) -> Member:
    warnings = warnings if warnings is not None else []
    m = Member(row=row)

    def get(fld: str) -> str:
        cols = mapping.get(fld) or []
        return str(values.get(cols[0]) or "").strip() if cols else ""

    first, last = get("first_name"), get("last_name")
    m.name = get("name") or " ".join(p for p in (first, last) if p)
    m.first_name_raw = first
    m.email = get("email").lower()
    for fld in DATES:
        raw = get(fld)
        if raw:
            dt = parse_date(raw, dayfirst=dayfirst, today=today)
            if dt is None:
                warnings.append(f"row {row}: could not read {fld.replace('_', ' ')} date {raw!r}")
            setattr(m, fld, dt)
    for fld in NUMERIC:
        raw = get(fld)
        if raw:
            try:
                num = _number(raw)
            except ValueError:
                warnings.append(f"row {row}: {fld} {raw!r} is not a number")
                continue
            if num is not None and fld in ("level", "points", "posts", "comments"):
                num = int(num)
            setattr(m, fld, num)
    m.plan = get("plan")
    m.invited_by = get("invited_by")
    answers = []
    for col in mapping.get("answers") or []:
        v = values.get(col)
        if isinstance(v, list):
            answers += [str(x).strip() for x in v if str(x).strip()]
        elif v is not None and str(v).strip():
            answers.append(str(v).strip())
    m.answers = answers
    mapped = {c for cols in mapping.values() for c in cols}
    m.extra = {k: v for k, v in values.items() if k not in mapped and v not in (None, "")}
    return m


def import_members(path: str | Path, overrides: list[str] | dict | None = None, dayfirst: bool = False,
                   today: datetime | date | None = None, allow_duplicates: bool = False) -> ImportResult:
    p = Path(path)
    if not p.exists():
        raise FileNotFoundError(f"File not found: {p}")
    headers, rows, delim, warnings = read_table(p)
    return import_rows(headers, rows, overrides, dayfirst, today, allow_duplicates, delim, warnings)


def import_rows(headers: list[str], rows: list[list[str]], overrides=None, dayfirst: bool = False,
                today=None, allow_duplicates: bool = False, delim: str = ",", warnings: list[str] | None = None) -> ImportResult:
    warnings = list(warnings or [])
    if not headers:
        raise MappingError("The file is empty: no header row found.")
    ov = overrides if isinstance(overrides, dict) else parse_overrides(overrides)
    mapping, unmapped = detect_mapping(headers, ov)
    if not any(f in mapping for f in ("email", "name", "first_name", "last_name")):
        raise MappingError("Could not find a name or email column. Columns found: " + ", ".join(headers)
                           + '. Tell me which one it is, e.g. --map "Member=name".')
    members: list[Member] = []
    skipped: list[SkippedRow] = []
    seen: set[str] = set()
    for i, row in enumerate(rows, start=2):  # row 1 is the header
        if not any(c.strip() for c in row):
            continue
        if len(row) > len(headers) and any(c.strip() for c in row[len(headers):]):
            warnings.append(f"row {i}: has more cells than the header; extra cells ignored")
        values = {h: (row[j] if j < len(row) else "") for j, h in enumerate(headers)}
        m = build_member(values, mapping, i, dayfirst, today, warnings)
        if not m.name and not m.email:
            skipped.append(SkippedRow(i, "no name and no email"))
            continue
        if m.email and "@" not in m.email:
            warnings.append(f"row {i}: email {m.email!r} looks wrong")
        if not allow_duplicates:
            if m.key in seen:
                skipped.append(SkippedRow(i, f"duplicate of an earlier row ({m.email or m.name})"))
                continue
            seen.add(m.key)
        members.append(m)
    return ImportResult(members, skipped, warnings, mapping, unmapped, delim, sum(1 for r in rows if any(c.strip() for c in r)))


def flatten(record: Any, prefix: str = "") -> dict[str, Any]:
    """Flatten nested JSON objects: {"member": {"email": x}} -> {"member.email": x} (lists kept as lists)."""
    out: dict[str, Any] = {}
    if isinstance(record, dict):
        for k, v in record.items():
            key = f"{prefix}.{k}" if prefix else str(k)
            if isinstance(v, dict):
                out.update(flatten(v, key))
            else:
                out[key] = v
    return out


def member_from_record(record: dict, overrides: list[str] | dict | None = None, dayfirst: bool = False,
                       today=None) -> tuple[Member, list[str]]:
    """Build a Member from a webhook JSON object (Zapier field names vary, so the same alias rules apply)."""
    flat = flatten(record)
    ov = overrides if isinstance(overrides, dict) else parse_overrides(overrides)
    headers = list(flat)
    present = {normalize_header(h) for h in headers}
    mapping, _ = detect_mapping(headers, {k: v for k, v in ov.items() if k in present}, leaf_fallback=True)
    warnings: list[str] = []
    values = {h: (v if isinstance(v, list) else ("" if v is None else str(v))) for h, v in flat.items()}
    return build_member(values, mapping, 0, dayfirst, today, warnings), warnings
