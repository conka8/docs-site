"""`skool-kit onboard`: a personalised first-week message for every new member."""
from __future__ import annotations

import csv
import io
import json
from dataclasses import dataclass
from datetime import datetime

from .llm import LLMClient, personalize
from .members import Member
from .rules import render_template, segment_member, template_context


@dataclass
class OnboardingMessage:
    member: Member
    segment: str
    segment_label: str
    goal: str
    goal_label: str
    lessons: list[str]
    first_action: str
    message: str
    source: str = "template"
    llm_error: str = ""
    matched: dict | None = None

    def to_dict(self) -> dict:
        return {
            "name": self.member.name, "first_name": self.member.first_name, "email": self.member.email,
            "joined": self.member.joined.isoformat(sep=" ") if self.member.joined else None,
            "segment": self.segment, "segment_label": self.segment_label, "goal": self.goal,
            "goal_label": self.goal_label, "lessons": self.lessons, "first_action": self.first_action,
            "message": self.message, "source": self.source, "llm_error": self.llm_error,
            "matched_keywords": self.matched or {},
        }


def build_message(member: Member, rules: dict, llm: LLMClient | None = None) -> OnboardingMessage:
    seg = segment_member(member.answers, rules)
    ctx = template_context(member.first_name, member.name, seg, rules)
    draft = render_template(seg.welcome, ctx).strip()
    text, source, err = personalize(llm, draft, member.answers, seg.segment_label, seg.goal_label,
                                    required=[x for x in seg.lessons[:3] if x])
    return OnboardingMessage(member, seg.segment, seg.segment_label, seg.goal, seg.goal_label, seg.lessons[:3],
                             seg.first_action, text, source, err, seg.matched)


def select_new(members: list[Member], since: datetime | None) -> tuple[list[Member], list[tuple[int, str]]]:
    if since is None:
        return list(members), []
    keep, skipped = [], []
    for m in members:
        if m.joined is None:
            skipped.append((m.row, "join date missing or unreadable, can't tell if they are new"))
        elif m.joined >= since:
            keep.append(m)
    return keep, skipped


CSV_COLUMNS = ("name", "first_name", "email", "joined", "segment", "goal", "lesson_1", "lesson_2", "lesson_3",
               "first_action", "message", "source")


def render_csv(messages: list[OnboardingMessage]) -> str:
    buf = io.StringIO()
    w = csv.writer(buf)
    w.writerow(CSV_COLUMNS)
    for msg in messages:
        d = msg.to_dict()
        lessons = (msg.lessons + ["", "", ""])[:3]
        w.writerow([d["name"], d["first_name"], d["email"], d["joined"] or "", msg.segment_label, msg.goal_label,
                    *lessons, msg.first_action, msg.message, msg.source])
    return buf.getvalue()


def render_markdown(messages: list[OnboardingMessage], title: str = "New member onboarding messages") -> str:
    lines = [f"# {title}", "", f"{len(messages)} member(s).", ""]
    for msg in messages:
        who = msg.member.name or msg.member.email
        lines += [f"## {who}", "",
                  f"- Email: {msg.member.email or '-'}",
                  f"- Segment: {msg.segment_label}" + (f" (matched: {', '.join(msg.matched['segment'])})"
                                                        if msg.matched and msg.matched.get("segment") else ""),
                  f"- Goal: {msg.goal_label}",
                  f"- Source: {msg.source}" + (f" (LLM failed: {msg.llm_error})" if msg.llm_error else ""),
                  "", "```text", msg.message, "```", ""]
    return "\n".join(lines)


def render_jsonl(messages: list[OnboardingMessage]) -> str:
    return "".join(json.dumps(m.to_dict(), ensure_ascii=False) + "\n" for m in messages)
