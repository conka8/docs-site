"""The same reviewed pack as one Claude Project instead of separate skills.

    <prefix>-claude-project-<version>/
      START-HERE.md        how a member sets the project up and their first messages
      INSTRUCTIONS.md      paste into the project's instructions
      knowledge/           upload every file: the lessons, one task guide per skill, the worked examples

Built from the skills in the pack folder, so the admin's reviewed wording is what the project follows. Nothing is
rewritten except links: a task guide is the skill's SKILL.md body with its links pointed at the knowledge files.
"""
from __future__ import annotations

import re
import shutil
from pathlib import Path

from .share import _front

LINK = re.compile(r"\]\(((?:references|examples)/[^)]+)\)")


def _knowledge_name(skill: str, rel: str) -> str:
    rel_path = Path(rel)
    if rel_path.parts[0] == "examples":
        return f"{skill}-{rel_path.name}"
    return rel_path.name


def _body(path: Path) -> str:
    """A lesson file without the header lines that differ between the tutor's copy and a task skill's."""
    lines = path.read_text(encoding="utf-8").splitlines()
    return "\n".join(x for x in lines if not re.match(r"(Module|Source file|Classroom):", x)).strip()


def _guide(skill_dir: Path) -> str:
    body = (skill_dir / "SKILL.md").read_text(encoding="utf-8").split("---", 2)[2].lstrip()
    body = LINK.sub(lambda m: f"]({_knowledge_name(skill_dir.name, m.group(1))})", body)
    body = body.replace("The lessons are in the\n`references/` folder next to this file",
                        "The lessons are in this\nproject's files")
    return body


def build_project(folders: list[Path], start: str, out: Path) -> list[str]:
    """Write the project folder from the pack's skill folders; returns the knowledge file names."""
    if out.exists():
        shutil.rmtree(out)
    knowledge = out / "knowledge"
    knowledge.mkdir(parents=True)
    tasks = []
    # The tutor's copies of the lessons carry the classroom link, so take those first.
    for f in sorted(folders, key=lambda f: not f.name.endswith("-tutor")):
        meta = _front(f / "SKILL.md")
        guide = f"task-{f.name}.md"
        (knowledge / guide).write_text(_guide(f), encoding="utf-8")
        tasks.append((guide, str(meta.get("description", "")).strip()))
        for sub in ("references", "examples"):
            for src in sorted((f / sub).rglob("*.md")) if (f / sub).is_dir() else []:
                target = knowledge / _knowledge_name(f.name, src.relative_to(f).as_posix())
                if target.exists():
                    if _body(target) != _body(src):
                        raise ValueError(f"two different lesson files are both called {target.name}")
                    continue
                shutil.copyfile(src, target)
    community = start.splitlines()[0].lstrip("# ").split(":")[0] if start.strip() else "this community"
    lines = [f"You help members of {community} do their work with the {community} method. This project's files hold "
             "the lessons and one task guide per task. Before every reply, pick the guide that fits the member's "
             "message and follow it exactly: its steps, rules, deliverable and citation format.", ""]
    lines += [f"- {guide}: {desc}" for guide, desc in tasks]
    lines += ["", "If no guide fits and the message isn't about the member's course work, answer normally. Never "
              "invent lesson names, prices, results or promises; say what the lessons don't cover."]
    (out / "INSTRUCTIONS.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    (out / "START-HERE.md").write_text(_project_start(community, sorted(p.name for p in knowledge.iterdir()), start),
                                       encoding="utf-8")
    return sorted(p.name for p in knowledge.iterdir())


def _project_start(community: str, files: list[str], skills_start: str) -> str:
    tasks = skills_start.split("## 3. Your first tasks", 1)[-1].split("\n## ", 1)[0].strip()
    tasks = re.sub(r"Use the [\w-]+ skill\. ", "", tasks)
    return "\n".join([
        f"# {community}: your Claude Project", "",
        "One Claude Project holds the lessons and the task guides. Every chat you start inside it follows them. "
        "Projects work on every Claude plan (Free accounts can have up to five).", "",
        "## 1. Set it up (once, about 5 minutes)", "",
        "1. In Claude, open **Projects** and create a project. Name it after the community.",
        "2. Open the project's **instructions**, and paste in everything from `INSTRUCTIONS.md`.",
        f"3. Add the {len(files)} files in the `knowledge` folder to the project's files (you can select them all "
        "at once).", "",
        "## 2. Check it works (1 minute)", "",
        "Start a new chat **inside the project** and ask a question the lessons answer. The reply should quote a "
        "lesson like *(Lesson: \"...\": \"...\")*. If it doesn't, check that step 2 and step 3 are done.", "",
        "## 3. Your first tasks", "",
        "Start each task in a new chat inside the project.", "",
        tasks, "",
        "## Updates", "",
        "When your admin shares a new version, replace the project's instructions and files with the new ones. "
        "Your old chats stay.", "",
        "## Good to know", "",
        "- Chats outside the project don't know the lessons.",
        "- Check anything before you send it to a client. You are responsible for what you send.", ""])
