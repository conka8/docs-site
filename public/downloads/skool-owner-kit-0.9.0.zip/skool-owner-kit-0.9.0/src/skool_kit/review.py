"""`skool-kit review`: a first-pass review of a member's submission against the owner's rubric, for a coach to approve.

The rubric lives in pack.yaml, per task. Each criterion names its lesson and quotes the sentence it rests on
(`pack-build` refuses a quote that isn't in the lesson), and is either:

- checked here, deterministically: sections present, word count, forbidden words in a section, prices against the
  lesson's numbers, promise wording, words a section must contain; or
- left to the coach (`judge`): the question the coach answers, shown with the lesson sentence.

Output, for the coach: each criterion as met / missing / uncertain / for you to judge, with the evidence found and the
lesson sentence; claims in the submission that need a source; a checklist the member can work through; and a reply
draft marked DRAFT that nothing sends. The coach approves, edits or rewrites it and records the minutes, so review time
can be compared with manual review (`skool-kit review-report`). No model is called; nothing leaves the computer.
"""
from __future__ import annotations

import csv
import hashlib
import re
from dataclasses import dataclass, field
from datetime import date
from pathlib import Path

from .verify import NEGATION, PROMISE

CHECKS = ("sections", "max_words", "not_in_section", "price", "no_promises", "section_contains")
SEVERITIES = ("critical", "major", "minor")
LOG_HEADER = ["date", "submission", "task", "method", "met", "missing", "uncertain", "judge", "decision",
              "coach_minutes", "critical_missed", "note"]
MONEY = r"[£$€]?\s?(\d{1,3}(?:,\d{3})+|\d+)(?:\.\d+)?\s?(k\b)?"
MONTHLY = re.compile(rf"{MONEY}\s*(?:/\s*(?:mo|month)\b|(?:a|per|each)\s+month|monthly|pcm)", re.I)
MONTHLY_BEFORE = re.compile(rf"monthly(?: fee)?\s*(?:of|:|-)?\s*{MONEY}", re.I)
SETUP = re.compile(rf"{MONEY}\s*(?:one[- ]off\s+)?(?:to\s+)?(?:setup|set-up|set up)", re.I)
SETUP_BEFORE = re.compile(rf"(?:setup|set-up|set up)(?: fee)?\s*(?:of|:|-)?\s*{MONEY}", re.I)
CLAIM = re.compile(r"(\d+(?:\.\d+)?\s?%|\b\d+x\b|[£$€]\s?\d[\d,]*(?:k\b)?\s+(?:a|per)\s+(?:month|year|week)\s+"
                   r"(?:lost|in lost|more|extra)|\b(?:most|studies|research|on average)\b[^.]*\b(?:lose|show|find)\b)",
                   re.I)


@dataclass
class CriterionResult:
    id: str
    criterion: str
    severity: str
    status: str      # met | missing | uncertain | judge
    evidence: str
    lesson: str
    quote: str
    fix: str
    question: str = ""


@dataclass
class Review:
    task: str
    label: str
    submission_id: str
    results: list[CriterionResult] = field(default_factory=list)
    claims: list[str] = field(default_factory=list)
    words: int = 0

    def count(self, status: str) -> int:
        return sum(1 for r in self.results if r.status == status)


def _sections(text: str) -> dict[str, str]:
    """Heading (lowercase) -> body. Accepts Markdown headings and bold-line headings ("**Price**")."""
    out, current = {}, None
    lines = text.splitlines()
    first = next((i for i, ln in enumerate(lines) if ln.strip()), None)
    if first is not None:
        m = re.match(r"^\s*(?:#\s+(.+?)|\*\*(.+?)\*\*)\s*$", lines[first])
        if m:  # an offer's title line is its headline
            out["headline"] = (m.group(1) or m.group(2)).strip() + "\n"
            lines = lines[first + 1:]
    for line in lines:
        m = re.match(r"^\s*(?:#{1,4}\s+|\*\*)(.+?)(?:\*\*)?\s*:?\s*$", line)
        if m and len(m.group(1)) < 60:
            current = re.sub(r"[*_#:]", "", m.group(1)).strip().lower()
            out.setdefault(current, "")
            continue
        if current is not None:
            out[current] += line + "\n"
    return out


def _find(sections: dict[str, str], name: str) -> str | None:
    key = name.lower()
    for k, body in sections.items():
        if k == key or k.startswith(key) or key in k:
            return body
    return None


def _amount(m: re.Match) -> float:
    n = float(m.group(1).replace(",", ""))
    return n * 1000 if m.group(2) else n


def _prices(body: str) -> tuple[list[float], list[float]]:
    monthly = [_amount(m) for m in MONTHLY.finditer(body)] + [_amount(m) for m in MONTHLY_BEFORE.finditer(body)]
    setup = [_amount(m) for m in SETUP.finditer(body)] + [_amount(m) for m in SETUP_BEFORE.finditer(body)]
    return monthly, setup


def _check(kind: str, arg, text: str, sections: dict[str, str], scoped: bool = False) -> tuple[str, str]:
    """(status, evidence) for one deterministic check."""
    if kind == "sections":
        missing = [s for s in arg if _find(sections, s) is None]
        present = [s for s in arg if _find(sections, s) is not None]
        order = [k for k in sections if any(k.startswith(s.lower()) or s.lower() in k for s in present)]
        if missing:
            return "missing", "Missing: " + ", ".join(missing)
        expected = [s.lower() for s in arg]
        seen = [next(s for s in expected if k.startswith(s) or s in k) for k in order]
        if seen != sorted(seen, key=expected.index):
            return "missing", "All present, but not in the lesson's order"
        return "met", f"All {len(arg)} present, in order"
    if kind == "max_words":
        n = len(re.findall(r"\b\w[\w'-]*\b", text))
        return ("met" if n <= int(arg) else "missing"), f"{n} words" + (" (the rubric's sections only)" if scoped else "")
    if kind == "not_in_section":
        body = _find(sections, arg["section"])
        if body is None:
            first = next((ln for ln in text.splitlines() if ln.strip()), "")
            body = first if first.lstrip().startswith("#") else None
        if body is None:
            return "uncertain", f"No {arg['section']} section found"
        hits = [w for w in arg["words"] if re.search(rf"(?<![\w-]){re.escape(w)}(?![\w-])", body, re.I)]
        return ("missing", "Found: " + ", ".join(hits)) if hits else ("met", "None found")
    if kind == "price":
        body, where = _find(sections, arg.get("section", "Price")), ""
        if body is None:  # judge the price wherever it is; the missing section is the sections criterion's job
            body, where = text, f" (no {arg.get('section', 'Price')} section; read from the whole text)"
        monthly, setup = _prices(body)
        problems, notes = [], []
        if arg.get("monthly") and not monthly:
            problems.append("no monthly fee found")
        if arg.get("setup") and not setup:
            problems.append("no setup fee found")
        if "monthly_min" in arg:
            if not monthly:
                return "uncertain", "Couldn't read a monthly amount; check by eye"
            low = min(monthly)
            notes.append(f"monthly {low:,.0f}")
            if low < arg["monthly_min"]:
                problems.append(f"monthly {low:,.0f} is below {arg['monthly_min']:,}")
        if "monthly_max" in arg:
            if not monthly:
                return "uncertain", "Couldn't read a monthly amount; check by eye"
            high = max(monthly)
            notes.append(f"monthly {high:,.0f}")
            if high > arg["monthly_max"]:
                problems.append(f"monthly {high:,.0f} is above {arg['monthly_max']:,}")
        if "setup_min" in arg or "setup_max" in arg:
            if not setup:
                return "uncertain", "Couldn't read a setup amount; check by eye"
            s = min(setup)
            notes.append(f"setup {s:,.0f}")
            if s < arg.get("setup_min", s) or s > arg.get("setup_max", s):
                problems.append(f"setup {s:,.0f} is outside {arg.get('setup_min', 0):,}-{arg.get('setup_max', 0):,}")
        if problems:
            return "missing", "; ".join(problems) + where
        return "met", (", ".join(notes) or "setup and monthly fee both shown") + where
    if kind == "no_promises":
        found = [s.strip() for s in re.split(r"(?<=[.!?])\s+|\n+", text)
                 if PROMISE.search(s) and not NEGATION.search(s)]
        return ("missing", "; ".join(f"\"{f[:120]}\"" for f in found)) if found else ("met", "None found")
    if kind == "section_contains":
        body, where = _find(sections, arg["section"]), ""
        if body is None:
            body, where = text, f" (no {arg['section']} section; read from the whole text)"
        absent = [w for w in arg["all"] if w.lower() not in body.lower()]
        if absent:
            return "missing", "Doesn't mention: " + ", ".join(absent) + where
        return "met", "Mentions " + ", ".join(arg["all"]) + where
    raise ValueError(f"unknown check {kind!r}")


def review_submission(text: str, task: str, rubric: list[dict], label: str = "") -> Review:
    sections = _sections(text)
    rev = Review(task, label or "submission", hashlib.sha256(text.encode("utf-8")).hexdigest()[:10],
                 words=len(re.findall(r"\b\w[\w'-]*\b", text)))
    if not text.strip():
        raise ValueError("the submission is empty")
    # The deliverable itself: the sections the rubric expects, without anything else the member pasted around it.
    expected = next((c["check"]["sections"] for c in rubric if (c.get("check") or {}).get("sections")), [])
    page_text = "\n".join(_find(sections, x) or "" for x in expected) if expected else ""
    page_text = page_text if page_text.strip() else ""
    for c in rubric:
        base = dict(id=c["id"], criterion=c["criterion"], severity=c.get("severity", "major"),
                    lesson=c.get("lesson", ""), quote=c.get("quote", ""), fix=c.get("fix", ""))
        if c.get("check"):
            kind, arg = next(iter(c["check"].items()))
            scoped = kind == "max_words" and bool(page_text)
            status, evidence = _check(kind, arg, page_text or text, sections, scoped)
            rev.results.append(CriterionResult(status=status, evidence=evidence, **base))
        else:
            rev.results.append(CriterionResult(status="judge", evidence="", question=c.get("judge", ""), **base))
    for s in re.split(r"(?<=[.!?])\s+|\n+", text):
        if CLAIM.search(s):
            rev.claims.append(re.sub(r"\s+", " ", s).strip(" *_#>-"))
    return rev


STATUS = {"met": "met", "missing": "**missing**", "uncertain": "uncertain: check", "judge": "**you judge**"}


def render(rev: Review, member: str = "") -> str:
    order = {"missing": 0, "uncertain": 1, "judge": 2, "met": 3}
    rows = sorted(rev.results, key=lambda r: (order[r.status], SEVERITIES.index(r.severity)))
    cell = lambda s: str(s).replace("|", "\\|").replace("\n", " ")
    out = [f"# Review draft: {rev.task}{f' for {member}' if member else ''}", "",
           "**DRAFT, not sent.** Generated by `skool-kit review` from the community's rubric. Check the items marked "
           "for you, edit the reply, and record your decision and minutes at the end.", "",
           f"Submission `{rev.submission_id}`, {rev.words} words. {rev.count('met')} met, {rev.count('missing')} "
           f"missing, {rev.count('uncertain')} uncertain, {rev.count('judge')} for you to judge.", "",
           "## Criteria", "",
           "| | Criterion | Severity | Status | Found | Lesson |", "|---|---|---|---|---|---|"]
    for r in [r for r in rows if r.status != "met"]:
        found = r.question if r.status == "judge" else r.evidence
        out.append(f"| {r.id} | {cell(r.criterion)} | {r.severity} | {STATUS[r.status]} | {cell(found)} | "
                   f"\"{cell(r.lesson)}\": \"{cell(r.quote)}\" |")
    met = [r for r in rows if r.status == "met"]
    if met:
        out += ["", "Met: " + "; ".join(f"{r.criterion.lower()} ({r.evidence})" for r in met) + "."]
    out += ["", "## Claims that need a source", ""]
    out += [f"- {c}" for c in rev.claims] or ["None found (percentages, multiples, money-lost figures, \"most ...\")."]
    todo = [r for r in rows if r.status in ("missing", "uncertain")]
    out += ["", "## Checklist for the member", ""]
    out += [f"- [ ] {r.fix} *(Lesson: \"{r.lesson}\": \"{r.quote}\")*" for r in todo if r.status == "missing"]
    out += [f"- [ ] Check: {r.criterion.lower()} ({r.evidence})" for r in todo if r.status == "uncertain"]
    out += [f"- [ ] Add a source for, or remove: \"{c[:100]}\"" for c in rev.claims]
    if not (todo or rev.claims):
        out.append("- Nothing found by the automatic checks.")
    critical = [r for r in rows if r.status == "missing" and r.severity == "critical"]
    out += ["", "## Reply draft (edit before sending)", "",
            f"Hi{' ' + member if member else ''}, thanks for posting your {rev.label}.", ""]
    if critical:
        out.append("Before you send it to anyone, fix these first:")
        out += [f"- {r.fix}" for r in critical]
        out.append("")
    rest = [r for r in todo if r not in critical and r.status == "missing"]
    if rest:
        out.append("Then:" if critical else "To bring it in line with the method:")
        out += [f"- {r.fix}" for r in rest]
        out.append("")
    if rev.claims:
        out.append("A number or claim that needs a source, or should come out: " + "; ".join(
            f"\"{c[:80]}\"" for c in rev.claims[:3]) + ".")
        out.append("")
    good = [r.criterion.lower() for r in rows if r.status == "met"]
    if good:
        out += [f"What already follows the method: {', '.join(good[:4])}.", ""]
    out += [f"[Coach: your view on: {r.question}]" for r in rows if r.status == "judge"]
    out += ["", "## Your decision (fill in, then log it)", "",
            "- [ ] Sent as drafted (light wording only)  - [ ] Edited (changed a finding)  - [ ] Rewritten",
            "- Minutes you spent on this review, including reading the submission: ____",
            "- Anything important the draft missed (count critical misses): ____", "",
            f"`skool-kit review-log reviews.csv --submission {rev.submission_id} --decision sent|edited|rewritten "
            "--minutes N [--critical-missed N]`", ""]
    return "\n".join(out)


def append_log(path: str | Path, rev: Review, method: str = "tool") -> None:
    path = Path(path)
    new = not path.is_file() or not path.read_text(encoding="utf-8").strip()
    with path.open("a", encoding="utf-8", newline="") as f:
        w = csv.writer(f)
        if new:
            w.writerow(LOG_HEADER)
        w.writerow([date.today().isoformat(), rev.submission_id, rev.task, method, rev.count("met"),
                    rev.count("missing"), rev.count("uncertain"), rev.count("judge"), "", "", "", ""])


def record_decision(path: str | Path, submission: str, decision: str, minutes: float, critical_missed: int = 0,
                    method: str | None = None, task: str = "") -> str:
    """Fill the coach's decision into the log row for this submission (or add a manual-review row). Returns the
    action taken."""
    path = Path(path)
    if decision not in ("sent", "edited", "rewritten", "manual"):
        raise ValueError("--decision must be sent, edited, rewritten or manual")
    rows = list(csv.DictReader(path.open(encoding="utf-8"))) if path.is_file() else []
    hit = next((r for r in reversed(rows) if r["submission"] == submission and not r["decision"]), None)
    if hit is None:
        if decision != "manual" and method != "manual":
            raise ValueError(f"no open review for submission {submission} in {path}")
        rows.append({k: "" for k in LOG_HEADER} | {"date": date.today().isoformat(), "submission": submission,
                                                    "task": task, "method": "manual"})
        hit = rows[-1]
        action = "added a manual-review row"
    else:
        action = "updated the review row"
    hit.update(decision=decision, coach_minutes=f"{minutes:g}", critical_missed=str(critical_missed))
    with path.open("w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, LOG_HEADER)
        w.writeheader()
        w.writerows(rows)
    return action


def _median(xs: list[float]) -> float | None:
    xs = sorted(xs)
    if not xs:
        return None
    mid = len(xs) // 2
    return xs[mid] if len(xs) % 2 else (xs[mid - 1] + xs[mid]) / 2


def report(path: str | Path) -> str:
    rows = [r for r in csv.DictReader(Path(path).open(encoding="utf-8")) if r.get("decision")]
    manual = [float(r["coach_minutes"]) for r in rows if r["method"] == "manual" and r["coach_minutes"]]
    tool = [r for r in rows if r["method"] == "tool" and r["coach_minutes"]]
    tool_min = [float(r["coach_minutes"]) for r in tool]
    out = ["# Review log summary", "",
           f"Reviews logged: {len(manual)} manual, {len(tool)} with the review draft.", ""]
    mm, tm = _median(manual), _median(tool_min)
    fmt = lambda x: "-" if x is None else f"{x:g}"
    out.append(f"- Median coach minutes per review: manual {fmt(mm)}, with draft {fmt(tm)}")
    if tool:
        sent = sum(1 for r in tool if r["decision"] == "sent")
        edited = sum(1 for r in tool if r["decision"] == "edited")
        missed = sum(int(r["critical_missed"] or 0) for r in tool)
        out.append(f"- Drafts sent with light wording only: {sent} of {len(tool)}; edited {edited}; rewritten "
                   f"{len(tool) - sent - edited}")
        out.append(f"- Critical problems the draft missed (found by the coach): {missed}")
    if mm and tm is not None and len(manual) >= 5 and len(tool) >= 5:
        out.append(f"- Change in median minutes: {100 * (tm - mm) / mm:+.0f}%")
    else:
        out.append("- Not enough reviews to compare yet (at least 5 of each).")
    out += ["", "Coach-reported minutes on different submissions: an observation, not a controlled measurement. "
            "Submissions vary; compare like with like, and count critical misses before minutes."]
    return "\n".join(out) + "\n"
