"""Keyword rules that turn join-question answers into a segment, a goal and a first-week path.

The default ruleset targets AI / automation communities. Dump it with `skool-kit rules -o rules.yaml`,
edit lesson names and wording, and pass `--rules rules.yaml`.
"""
from __future__ import annotations

import copy
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

DEFAULT_RULES: dict[str, Any] = {
    "community_name": "the community",
    "segments": [
        {"id": "agency-owner", "label": "Agency owner",
         "keywords": ["agency", "my agency", "my clients", "clients", "smma", "retainer", "white label",
                      "lead gen", "marketing agency", "freelancer", "freelance", "consultant", "consulting"]},
        {"id": "developer", "label": "Developer",
         "keywords": ["developer", "engineer", "software engineer", "programmer", "python", "javascript",
                      "typescript", "coding", "i code", "full stack", "backend", "frontend", "github", "cs degree"]},
        {"id": "business-owner", "label": "Business owner",
         "keywords": ["my business", "business owner", "my company", "own a business", "my store", "my shop",
                      "ecommerce", "e-commerce", "clinic", "practice", "restaurant", "real estate", "my team",
                      "employees", "founder", "ceo", "small business", "brick and mortar"]},
        {"id": "job-seeker", "label": "Job seeker",
         "keywords": ["job", "get hired", "hired", "career", "laid off", "unemployed", "resume", "interview",
                      "new role", "career change", "switch careers", "looking for work", "graduate"]},
        {"id": "beginner", "label": "Beginner",
         "keywords": ["beginner", "new to", "no experience", "never used", "just starting", "just started",
                      "newbie", "not technical", "non-technical", "non technical", "no idea", "don't know",
                      "dont know", "curious", "complete beginner", "zero"]},
    ],
    "default_segment": "beginner",
    "goals": [
        {"id": "first-client", "label": "land your first client",
         "keywords": ["first client", "get clients", "land clients", "find clients", "sign clients", "more clients",
                      "first customer", "close deals", "sell ai", "outreach", "cold email", "make money"]},
        {"id": "build-app", "label": "build and launch your first app",
         "keywords": ["build an app", "build app", "build apps", "saas", "mvp", "my app", "an app", "web app",
                      "launch", "side project", "vibe coding", "vibe code"]},
        {"id": "automate-business", "label": "automate your business",
         "keywords": ["automate my business", "automate", "automation", "automations", "save time", "workflow",
                      "workflows", "n8n", "zapier", "make.com", "repetitive", "manual work", "manual tasks"]},
        {"id": "get-hired", "label": "get hired in an AI role",
         "keywords": ["get hired", "job", "career", "new role", "portfolio", "interview", "promotion"]},
        {"id": "learn-ai", "label": "get comfortable using AI",
         "keywords": ["learn ai", "learn", "understand", "chatgpt", "claude", "ai tools", "prompting", "prompts"]},
    ],
    "default_goal": "learn-ai",
    "lesson_links": {},
    "paths": {
        "beginner": {
            "default_goal": "learn-ai",
            "lessons": ["Start Here: How This Community Works", "AI Basics in 20 Minutes",
                        "Your First Automation (Step by Step)"],
            "first_action": "Post a quick intro in the community: who you are and the one thing you want AI to do for you.",
        },
        "agency-owner": {
            "default_goal": "first-client",
            "lessons": ["Start Here: How This Community Works", "The AI Agency Offer That Sells",
                        "Finding Your First Client in 7 Days"],
            "first_action": "Write down 10 local businesses you could help and share your niche in the wins channel.",
        },
        "developer": {
            "default_goal": "build-app",
            "lessons": ["Start Here: How This Community Works", "Build an App with Claude Code",
                        "Deploying Your App Safely"],
            "first_action": "Share what you're building (a link or a screenshot) in the community.",
        },
        "business-owner": {
            "default_goal": "automate-business",
            "lessons": ["Start Here: How This Community Works", "Automate Your Business: First 3 Workflows",
                        "AI Customer Support in an Afternoon"],
            "first_action": "List the 3 tasks that eat most of your week and post them; we'll suggest which to automate first.",
        },
        "job-seeker": {
            "default_goal": "get-hired",
            "lessons": ["Start Here: How This Community Works", "Portfolio Projects That Get You Hired",
                        "AI Skills Employers Ask For"],
            "first_action": "Pick one portfolio project from the lesson and post your plan for it.",
        },
    },
    "welcome": (
        "Hey {first_name}, welcome to {community_name}! Since you want to {goal}, here's your first week:\n"
        "1. {lesson_1}\n2. {lesson_2}\n3. {lesson_3}\n"
        "Your first action: {first_action}\n"
        "Reply here if you get stuck. Happy to help!"
    ),
}


class RulesError(ValueError):
    pass


@dataclass
class Segmentation:
    segment: str
    segment_label: str
    goal: str
    goal_label: str
    lessons: list[str]
    first_action: str
    matched: dict[str, list[str]] = field(default_factory=dict)
    welcome: str = ""


def default_rules() -> dict:
    return copy.deepcopy(DEFAULT_RULES)


def validate_rules(rules: dict) -> dict:
    if not isinstance(rules, dict):
        raise RulesError("rules file must be a YAML mapping")
    for key in ("segments", "goals"):
        items = rules.get(key)
        if not isinstance(items, list) or not items:
            raise RulesError(f"rules: '{key}' must be a non-empty list")
        for i, it in enumerate(items, 1):
            if not isinstance(it, dict) or not it.get("id"):
                raise RulesError(f"rules: {key} item {i} needs an id")
            kws = it.get("keywords") or []
            if not isinstance(kws, list):
                raise RulesError(f"rules: keywords of {key} '{it['id']}' must be a list")
            it["keywords"] = [str(k) for k in kws]
            it.setdefault("label", str(it["id"]).replace("-", " "))
    seg_ids = {s["id"] for s in rules["segments"]}
    goal_ids = {g["id"] for g in rules["goals"]}
    if rules.get("default_segment") not in seg_ids:
        raise RulesError(f"rules: default_segment must be one of {sorted(seg_ids)}")
    if rules.get("default_goal") not in goal_ids:
        raise RulesError(f"rules: default_goal must be one of {sorted(goal_ids)}")
    paths = rules.get("paths")
    if paths is None:
        paths = rules["paths"] = {}
    if not isinstance(paths, dict):
        raise RulesError("rules: 'paths' must be a mapping of segment id -> path")
    for sid, path in paths.items():
        if sid not in seg_ids:
            raise RulesError(f"rules: path '{sid}' does not match any segment id")
        if not isinstance(path, dict):
            raise RulesError(f"rules: path '{sid}' must be a mapping")
        if path.get("default_goal") and path["default_goal"] not in goal_ids:
            raise RulesError(f"rules: path '{sid}' default_goal must be one of {sorted(goal_ids)}")
        lessons = path.get("lessons") or []
        if not isinstance(lessons, list):
            raise RulesError(f"rules: lessons of path '{sid}' must be a list")
        path["lessons"] = [str(x) for x in lessons]
    if not isinstance(rules.get("welcome", ""), str):
        raise RulesError("rules: 'welcome' must be text")
    return rules


def load_rules(path: str | Path | None = None) -> dict:
    if path is None:
        return default_rules()
    p = Path(path)
    if not p.exists():
        raise RulesError(f"rules file not found: {p}")
    import yaml
    try:
        data = yaml.safe_load(p.read_text(encoding="utf-8"))
    except yaml.YAMLError as exc:
        raise RulesError(f"{p} is not valid YAML: {exc}") from exc
    if not isinstance(data, dict):
        raise RulesError("rules file must be a YAML mapping")
    merged = default_rules()
    merged.update(data)  # top-level keys in the file replace the defaults
    return validate_rules(merged)


def dump_rules(rules: dict | None = None) -> str:
    import yaml
    header = ("# skool-kit onboarding rules. Edit keywords, lesson names and wording to match your classroom.\n"
              "# Placeholders: {first_name} {name} {goal} {segment} {lesson_1} {lesson_2} {lesson_3}\n"
              "#               {lesson_1_link} {first_action} {community_name}\n")
    return header + yaml.safe_dump(rules or default_rules(), sort_keys=False, allow_unicode=True, width=100)


def _kw_regex(kw: str) -> re.Pattern:
    return re.compile(r"(?<![\w])" + re.escape(kw.lower()) + r"(?![\w])")


def score(text: str, keywords: list[str]) -> tuple[int, list[str]]:
    """Weighted keyword hits: multi-word phrases count more (they are more specific)."""
    total, hits = 0, []
    low = " ".join(text.lower().replace("’", "'").split())
    for kw in keywords:
        if kw and _kw_regex(kw).search(low):
            total += len(kw.split())
            hits.append(kw)
    return total, hits


def _best(items: list[dict], text: str) -> tuple[dict | None, list[str]]:
    best, best_score, best_hits = None, 0, []
    for it in items:  # ties keep the earlier item: order in the rules file is the priority
        s, hits = score(text, it.get("keywords") or [])
        if s > best_score:
            best, best_score, best_hits = it, s, hits
    return best, best_hits


def segment_member(answers: list[str] | str, rules: dict | None = None) -> Segmentation:
    rules = rules or DEFAULT_RULES
    text = answers if isinstance(answers, str) else " \n ".join(answers or [])
    seg, seg_hits = _best(rules["segments"], text)
    if seg is None:
        seg = next(s for s in rules["segments"] if s["id"] == rules["default_segment"])
    path = (rules.get("paths") or {}).get(seg["id"]) or {}
    goal, goal_hits = _best(rules["goals"], text)
    if goal is None:
        gid = path.get("default_goal") or rules["default_goal"]
        goal = next(g for g in rules["goals"] if g["id"] == gid)
    return Segmentation(
        segment=seg["id"], segment_label=seg.get("label", seg["id"]),
        goal=goal["id"], goal_label=goal.get("label", goal["id"]),
        lessons=list(path.get("lessons") or []),
        first_action=str(path.get("first_action") or "Introduce yourself in the community."),
        matched={"segment": seg_hits, "goal": goal_hits},
        welcome=str(path.get("welcome") or rules.get("welcome") or DEFAULT_RULES["welcome"]),
    )


_PLACEHOLDER = re.compile(r"\{([a-z_0-9]+)\}")


def render_template(template: str, context: dict) -> str:
    """Replace {placeholders}; unknown ones are left as typed, stray braces are harmless."""
    return _PLACEHOLDER.sub(lambda m: str(context[m.group(1)]) if m.group(1) in context else m.group(0), template)


def template_context(first_name: str, name: str, seg: Segmentation, rules: dict) -> dict:
    lessons = (seg.lessons + ["", "", ""])[:3]
    links = rules.get("lesson_links") or {}
    ctx = {
        "first_name": first_name or "there", "name": name or first_name or "there",
        "goal": seg.goal_label, "segment": seg.segment_label, "first_action": seg.first_action,
        "community_name": rules.get("community_name") or "the community",
    }
    for i, lesson in enumerate(lessons, 1):
        ctx[f"lesson_{i}"] = lesson
        ctx[f"lesson_{i}_link"] = links.get(lesson, "")
    return ctx
