"""`skool-kit pack-share`: turn a reviewed member pack into what members actually receive.

    share/
      <prefix>-member-kit-<version>/      the files to give every member
        START-HERE.md                      the pack's MEMBER-START.md
        <skill>.zip                        one upload zip per skill, skill folder at the zip root
      <prefix>-member-kit-<version>.zip   the same folder as one download
      <prefix>-claude-project-<version>/  the same pack as one Claude Project (see project.py), and its .zip
      LAUNCH-POST.md                       a draft announcement for the admin to edit (LAUNCH-POST-project.md too
                                           with --format both)

`--format project` or `--format skills` writes only that format; the default writes both.

It zips the skills exactly as they are in the pack folder, so the admin's own edits are what members get.
It refuses to share a pack with unmerged `.new` files or skills the Claude app would reject.
"""
from __future__ import annotations

import os
import re
import shutil
import zipfile
from dataclasses import dataclass, field
from pathlib import Path

import yaml

from .classroom import DESCRIPTION_MAX, SkillError

VERSION_PATTERN = re.compile(r"^\d+(\.\d+){0,2}$")
SKIP = {".DS_Store", "__pycache__", ".git"}
FIXED_TIME = (2026, 1, 1, 0, 0, 0)  # same bytes for the same files, so a rebuild is easy to compare


@dataclass
class ShareResult:
    folder: Path | None
    kit_zip: Path | None
    launch_post: Path
    skills: list[str] = field(default_factory=list)
    project_zip: Path | None = None


def _front(skill_md: Path) -> dict:
    text = skill_md.read_text(encoding="utf-8")
    if not text.startswith("---"):
        raise SkillError(f"{skill_md} has no frontmatter")
    try:
        meta = yaml.safe_load(text.split("---", 2)[1]) or {}
    except yaml.YAMLError as exc:
        raise SkillError(f"{skill_md}: frontmatter is not valid YAML ({exc})") from None
    return meta if isinstance(meta, dict) else {}


def check_pack(pack: Path) -> list[Path]:
    """The skill folders to share, after the checks a member's upload would otherwise fail on."""
    skills_dir = pack / "skills"
    if not skills_dir.is_dir():
        raise SkillError(f"{skills_dir} not found: point pack-share at a folder made by pack-build")
    pending = sorted(p.relative_to(pack).as_posix() for p in pack.rglob("*.new"))
    if pending:
        raise SkillError("merge or delete these updates first (pack-build wrote them next to files you edited): "
                         + ", ".join(pending))
    folders = sorted(p for p in skills_dir.iterdir() if p.is_dir() and not p.name.startswith("."))
    if not folders:
        raise SkillError(f"no skills in {skills_dir}")
    problems = []
    for f in folders:
        md = f / "SKILL.md"
        if not md.is_file():
            problems.append(f"{f.name}: no SKILL.md")
            continue
        meta = _front(md)
        if meta.get("name") != f.name:
            problems.append(f"{f.name}: the name in SKILL.md ({meta.get('name')!r}) must match the folder name")
        desc = meta.get("description")
        if not isinstance(desc, str) or not desc.strip():
            problems.append(f"{f.name}: no description")
        elif len(desc) > DESCRIPTION_MAX:
            problems.append(f"{f.name}: description is {len(desc)} characters; the Claude app accepts "
                            f"{DESCRIPTION_MAX}")
        if "TODO (owner)" in md.read_text(encoding="utf-8"):
            problems.append(f"{f.name}: still contains TODO (owner) from pack-draft; fill it in and rebuild")
    if problems:
        raise SkillError("can't share this pack:\n  " + "\n  ".join(problems))
    if not (pack / "MEMBER-START.md").is_file():
        raise SkillError(f"{pack / 'MEMBER-START.md'} not found")
    return folders


def _zip(target: Path, base: Path, paths: list[Path]) -> None:
    with zipfile.ZipFile(target, "w", zipfile.ZIP_DEFLATED) as zf:
        for p in paths:
            for f in sorted([p] if p.is_file() else p.rglob("*")):
                if f.is_dir() or SKIP & set(f.relative_to(base).parts):
                    continue
                info = zipfile.ZipInfo(f.relative_to(base).as_posix(), FIXED_TIME)
                info.compress_type = zipfile.ZIP_DEFLATED
                info.external_attr = 0o644 << 16
                zf.writestr(info, f.read_bytes())


def _kit_name(folders: list[Path]) -> str:
    prefix = os.path.commonprefix([f.name for f in folders]).rstrip("-")
    if "-" in prefix and len(folders) > 1 and not all(f.name.startswith(prefix + "-") for f in folders):
        prefix = prefix.rsplit("-", 1)[0]
    return (prefix or "community") + "-member-kit"


FORMATS = ("both", "project", "skills")


def launch_post(title: str, kit: str, skills: list[str], project: bool = False) -> str:
    if project:
        what = (f"We've put our classroom into one Claude Project: the lessons plus a guide for each first-week task. "
                "Every chat inside it drafts your first work with you, following our lessons, and tells you what's "
                "missing or needs checking before you use it.")
        how = (f"Download `{kit}.zip` (attached), open START-HERE.md and follow the 5-minute setup: create a project, "
               "paste the instructions, add the files. Then start with task 1 in that guide.")
        check = "Before posting: attach the project zip, and check the task names, the time estimates and where members should post questions."
        listing = []
    else:
        what = (f"We've turned our classroom into {len(skills)} Claude skills. They draft your first work with you, "
                "following our lessons, and tell you what's missing or needs checking before you use it.")
        how = (f"Download `{kit}.zip` (attached), open START-HERE.md and follow the 5-minute install. Then start with "
               "task 1 in that guide.")
        check = ("Before posting: attach the kit zip (or the files inside its folder), and check the skill names, the "
                 "time estimates and where members should post questions.")
        listing = ["- " + "\n- ".join(f"`{s}`" for s in skills), ""]
    return "\n".join([
        "# Launch post (draft: edit before posting)", "",
        f"**New: {title} AI toolkit for your first weeks**", "",
        what, "", *listing, how, "",
        "It drafts; you check. Anything it can't answer from the lessons comes back as a question for you to post here.",
        "", "---", "", check, ""])


def share_pack(pack: str | Path, out: str | Path, version: str, title: str = "", fmt: str = "both") -> ShareResult:
    """Build what members receive. fmt: "project" (one Claude Project), "skills" (upload zips) or "both"."""
    pack, out = Path(pack), Path(out)
    if fmt not in FORMATS:
        raise SkillError(f"--format must be one of {', '.join(FORMATS)}")
    if not VERSION_PATTERN.match(version):
        raise SkillError(f"--version must look like 1.0.0, got {version!r}")
    folders = check_pack(pack)
    if out.resolve() == pack.resolve() or pack.resolve() in out.resolve().parents:
        raise SkillError("write the share folder outside the pack folder (for example -o ../share)")
    kit = f"{_kit_name(folders)}-{version}"
    start = (pack / "MEMBER-START.md").read_text(encoding="utf-8")
    heading = (start.splitlines()[0].lstrip("# ").split(":")[0] if start.strip() else "") or "Our"
    title = title or heading
    names = [f.name for f in folders]
    folder = kit_zip = post = project_zip = None
    if fmt in ("both", "skills"):
        folder = out / kit
        if folder.exists():
            shutil.rmtree(folder)
        folder.mkdir(parents=True)
        (folder / "START-HERE.md").write_text(start, encoding="utf-8")
        for f in folders:
            _zip(folder / f"{f.name}.zip", f.parent, [f])
        kit_zip = out / f"{kit}.zip"
        _zip(kit_zip, out, [folder])
        post = out / "LAUNCH-POST.md"
        post.write_text(launch_post(title, kit, names), encoding="utf-8")
    if fmt in ("both", "project"):
        from .project import build_project
        project = out / kit.replace("-member-kit-", "-claude-project-")
        build_project(folders, start, project)
        project_zip = out / f"{project.name}.zip"
        _zip(project_zip, out, [project])
        project_post = out / ("LAUNCH-POST.md" if fmt == "project" else "LAUNCH-POST-project.md")
        project_post.write_text(launch_post(title, project.name, names, project=True), encoding="utf-8")
        post = post or project_post
    return ShareResult(folder, kit_zip, post, names, project_zip)
