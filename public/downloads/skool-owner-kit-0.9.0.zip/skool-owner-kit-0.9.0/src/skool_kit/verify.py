"""`skool-kit check-answer`: what can be checked about a reply without trusting a model, kept apart from what can't.

Four questions about every citation, answered separately:

1. Quote exists: the quoted sentence is in the lessons at all.
2. Right lesson: it is in the lesson the reply names (not only in another one).
3. Qualification kept: the quote isn't cut from a longer lesson sentence whose missing part limits it ("unless ...",
   "on results you don't control", "only ...").
4. Supports the claim: NOT decided here. Whether a true quote supports the point it's attached to (or is used for
   the wrong conclusion) needs a reader. The report lists every citation with the reply sentence it backs, for a
   person to judge.

And three checks on the whole reply:

- Numbers: every price, percentage or other number of 100 or more is in the lessons, in the member's input, or
  inside the reply's "Gaps and assumptions" section. Anything else is reported as unsourced. It compares values, not
  meanings: "£400 a month" passes if a lesson says "400 words", and small counts ("3 clients") aren't checked.
- Promises: a sentence that mentions a guarantee, a refund promise or earnings without a negation is reported.
- Case checks: the acceptance case's own contains / regex / not_contains / max_chars checks.

Deterministic results are reliable for what they test and nothing more: a reply can pass all of them and still be
wrong. The acceptance decision stays with a person.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field

from .citations import CITATION, check_citations, normalise

QUALIFIER = re.compile(r"\b(unless|except|only|if|when|but|until|without|below|above|at least|at most|up to|"
                       r"in exchange|on results|instead|not|never|no)\b")
PROMISE = re.compile(r"(?i)\b(guarantee[sd]?|(full|your) refund|refund (guarantee|if)|you('| wi)ll (earn|make)|earn \$?\d|risk[- ]free|"
                     r"double your|money[- ]back|expect to (sign|earn|make|land|close|get) \d+)\b")
NEGATION = re.compile(r"(?i)\b(no|not|never|nothing|neither|away from|don'?t|doesn'?t|can'?t|without|instead|avoid|conflicts?|"
                      r"isn'?t|won'?t|rather than|ruled? out|removed?|dropped|left out|you asked|you said|you wanted)\b")
NUMBER = re.compile(r"(?<![\w.])([£$€¥]\s?\d(?:[\d,]*\d)?(?:\.\d+)?|\d(?:[\d,]*\d)?(?:\.\d+)?\s?%|\d{1,3}(?:,\d{3})+|\d{3,})"
                    r"(?![\w])")
SENTENCE = re.compile(r"(?<=[.!?])\s+|\n+")
# Lesson text is stored normalised (one line), so list items, headings and table cells also end a sentence.
BODY_SENTENCE = re.compile(r"(?<=[.!?])\s+|(?<=[.!?]')\s+|\s(?=[-*]\s)|#+\s|\|\s*|\s(?=\d+\.\s)|\n+")


@dataclass
class CitationCheck:
    lesson: str
    passage: str
    exists: str          # yes | no | no passage
    right_lesson: str    # yes | no (found in "X") | unknown lesson | -
    qualification: str   # kept | cut: "..." | -
    claim: str           # the reply sentence the citation backs, for a person to judge support


@dataclass
class AnswerReport:
    citations: list[CitationCheck] = field(default_factory=list)
    unsourced_numbers: list[str] = field(default_factory=list)
    assumed_numbers: list[str] = field(default_factory=list)
    promises: list[str] = field(default_factory=list)
    case_results: list[tuple[str, bool]] = field(default_factory=list)
    review: list[str] = field(default_factory=list)

    @property
    def failures(self) -> list[str]:
        out = []
        for c in self.citations:
            if c.exists != "yes":
                out.append(f"quote not found: {c.lesson}: \"{c.passage}\"" if c.exists == "no"
                           else f"citation without a quote: {c.lesson}")
            elif c.right_lesson == "no lesson named":
                out.append(f"quote with no lesson named: \"{c.passage}\"")
            elif c.right_lesson == "unknown lesson":
                out.append(f"no lesson is called \"{c.lesson}\" (the quote itself is in the lessons)")
            elif c.right_lesson != "yes":
                out.append(f"wrong lesson named: \"{c.passage}\" is not in \"{c.lesson}\" "
                           f"({c.right_lesson.removeprefix('no (').rstrip(')')})")
            if c.qualification.startswith("cut"):
                out.append(f"qualification dropped from \"{c.lesson}\": {c.qualification[5:]}")
        out += [f"unsourced number: {n}" for n in self.unsourced_numbers]
        out += [f"possible promise: {p}" for p in self.promises]
        out += [f"case check failed: {name}" for name, ok in self.case_results if not ok]
        return out


def _sentences(text: str) -> list[str]:
    return [s for s in SENTENCE.split(text) if s.strip()]


def _qualification(passage: str, body: str) -> str:
    """'kept', or 'cut: <the dropped part>' when the quote is part of a lesson sentence that limits it."""
    p = normalise(passage).strip(" .,;:'")
    for sentence in (x for x in BODY_SENTENCE.split(body) if x and x.strip()):
        s = sentence.strip()
        if p and p in s:
            rest = s.replace(p, " ", 1).strip(" .,;:'-")
            if rest and QUALIFIER.search(rest):
                return f"cut: \"{rest}\""
            return "kept"
    return "kept"  # a quote spanning sentences, or joined with "...": nothing reliable to say


def _claim(reply: str, start: int) -> str:
    """The reply sentence just before a citation: what the citation is offered as support for."""
    before = CITATION.sub("", reply[:start]).rstrip(" *(_\n")
    parts = _sentences(before)
    return re.sub(r"\s+", " ", parts[-1]).strip(" *_-") if parts else ""


def _digits(token: str) -> str:
    return re.sub(r"[^\d.]", "", token).rstrip(".")


def _section(reply: str, heading: str) -> str:
    m = re.search(rf"(?ims)^#+\s*{heading}\s*$(.*?)(?=^#+\s|\Z)", reply)
    return m.group(1) if m else ""


def _run_check(check: dict, reply: str) -> tuple[str, bool]:
    kind, value = next((k, v) for k, v in check.items() if k != "explain")
    label = check.get("explain") or f"{kind}: {value}"
    values = value if isinstance(value, list) else [value]
    if kind == "contains":
        return label, all(str(v) in reply for v in values)
    if kind == "not_contains":
        return label, not any(str(v).lower() in reply.lower() for v in values)
    if kind == "regex":
        return label, bool(re.search(str(value), reply))
    if kind == "max_chars":
        return label, len(reply) <= int(value)
    return label, False


def check_answer(reply: str, lessons: dict[str, str], member_input: str = "", case: dict | None = None
                 ) -> AnswerReport:
    report = AnswerReport()
    text = reply.replace("“", '"').replace("”", '"')
    matches = list(CITATION.finditer(text))
    for m, cite in zip(matches, check_citations(reply, lessons)):
        claim = _claim(text, m.start())
        if cite.status == "unknown lesson":
            if not cite.passage and any(normalise(cite.lesson).strip(" .") in body for body in lessons.values()):
                # *(Lesson: "a sentence")*: a real quote with no lesson named, so it can't be traced.
                report.citations.append(CitationCheck("-", cite.lesson, "yes", "no lesson named", "-", claim))
                continue
            elsewhere = [t for t, body in lessons.items() if cite.passage and normalise(cite.passage) in body]
            report.citations.append(CitationCheck(cite.lesson, cite.passage, "yes" if elsewhere else "no",
                                                  "unknown lesson", "-", claim))
            continue
        if cite.status == "no passage":
            report.citations.append(CitationCheck(cite.lesson, "", "no passage", "-", "-", claim))
            continue
        body = lessons[normalise(cite.lesson)]
        if cite.status == "ok":
            report.citations.append(CitationCheck(cite.lesson, cite.passage, "yes", "yes",
                                                  _qualification(cite.passage, body), claim))
            continue
        p = normalise(cite.passage)
        other = next((t for t, b in lessons.items() if p.strip(" .,;:'") in b), None)
        report.citations.append(CitationCheck(
            cite.lesson, cite.passage, "yes" if other else "no",
            f"no (found in \"{other}\")" if other else "-",
            _qualification(cite.passage, lessons[other]) if other else "-", claim))

    # Numbers: from the lessons, from the member, or declared under Gaps and assumptions.
    known = {_digits(t) for t in NUMBER.findall(" ".join(lessons.values()) + " " + member_input)}
    known |= {_digits(t) for t in re.findall(r"\d[\d,]*", " ".join(lessons.values()) + " " + member_input)}
    gaps = _section(text, r"gaps and assumptions")
    declared = {_digits(t) for t in NUMBER.findall(gaps)}
    quoted = " ".join(m.group(0) for m in matches)
    # Dates, and the deliverable's own Check section (it repeats the task's limits), aren't claims.
    own_check = _section(text, r"check")
    body = text.replace(own_check, " ") if own_check.strip() else text
    body = re.sub(r"\b\d{4}-\d{2}-\d{2}\b", " ", body)
    for token in dict.fromkeys(t.strip() for t in NUMBER.findall(body)):
        d = _digits(token)
        if not d or d in known or token in quoted:
            continue
        (report.assumed_numbers if d in declared else report.unsourced_numbers).append(token)

    for sentence in _sentences(CITATION.sub("", text)):
        if PROMISE.search(sentence) and not NEGATION.search(sentence):
            report.promises.append(re.sub(r"\s+", " ", sentence).strip(" *_-#>"))

    for check in (case or {}).get("checks") or []:
        report.case_results.append(_run_check(check, reply))
    report.review = [str(q) for q in (case or {}).get("review") or []]
    return report


def render(report: AnswerReport, title: str = "Answer check") -> str:
    out = [f"# {title}", "",
           "Deterministic checks: reliable for what they test, and nothing more. A reply can pass them all and still "
           "be wrong. Accepting it is a person's decision.", "",
           "## Citations", ""]
    if report.citations:
        out += ["| Lesson named | Quote | 1. Exists | 2. Right lesson | 3. Qualification | 4. Supports the claim? |",
                "|---|---|---|---|---|---|"]
        for c in report.citations:
            cell = lambda s: s.replace("|", "\\|")
            out.append(f"| {cell(c.lesson)} | {cell(c.passage) or '-'} | {c.exists} | {cell(c.right_lesson)} | "
                       f"{cell(c.qualification)} | person: does it support \"{cell(c.claim[:160])}\"? |")
    else:
        out.append("None found. Every lesson-based point should cite its lesson.")
    out += ["", "## Numbers", ""]
    out.append("Unsourced (not in the lessons, the member's input or Gaps and assumptions): "
               + (", ".join(report.unsourced_numbers) or "none"))
    out.append("")
    out.append("Declared as assumptions: " + (", ".join(report.assumed_numbers) or "none"))
    out += ["", "## Promises", ""]
    out += [f"- {p}" for p in report.promises] or ["None found (checks guarantee, refund and earnings wording)."]
    if report.case_results:
        out += ["", "## Case checks", ""]
        out += [f"- [{'x' if ok else ' '}] {name}" for name, ok in report.case_results]
    out += ["", "## For a person to decide", ""]
    review = report.review + ["Does each citation above support the sentence it's attached to, or is a true quote "
                              "used for a different conclusion?",
                              "Did the reply keep the lessons' limits and resolve any conflict between lessons?"]
    out += [f"- [ ] {q}" for q in review]
    out += ["", f"**Deterministic result: {'pass' if not report.failures else 'fail'}**"]
    out += [f"- {f}" for f in report.failures]
    return "\n".join(out).rstrip() + "\n"
