"""`skool-kit webhook`: receive Zapier "new member" POSTs, write the welcome message, optionally forward it.

    POST /            JSON body (or form-encoded) with the member's fields
                      secret in header X-Skool-Kit-Secret (configurable) or ?secret=...
    GET  /health      liveness check

Responses: 200 {"ok": true, "message": ...}, 400 bad JSON, 401 bad secret, 413 too large.
"""
from __future__ import annotations

import hmac
import json
import threading
import urllib.parse
from dataclasses import dataclass, field
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Callable

from .llm import LLMClient, LLMError, urllib_post
from .members import member_from_record
from .onboard import build_message
from .rules import default_rules

DEFAULT_SECRET_HEADER = "X-Skool-Kit-Secret"
MAX_BODY = 1_000_000
REQUEST_TIMEOUT = 30  # seconds


@dataclass
class WebhookConfig:
    secret: str
    outbox: Path | None = Path("outbox.jsonl")
    forward_url: str = ""
    secret_header: str = DEFAULT_SECRET_HEADER
    secret_param: str = "secret"
    field_map: dict | list | None = None
    rules: dict = field(default_factory=default_rules)
    llm: LLMClient | None = None
    forward_transport: Callable = urllib_post
    forward_timeout: float = 15.0
    paths: tuple[str, ...] = ("/", "/new-member", "/webhook")
    log: Callable[[str], None] | None = None
    _lock: threading.Lock = field(default_factory=threading.Lock, repr=False)


def check_secret(config: WebhookConfig, headers, query: dict) -> bool:
    if not config.secret:
        return False
    given = headers.get(config.secret_header) or ""
    if not given:
        values = query.get(config.secret_param) or [""]
        given = values[0]
    return hmac.compare_digest(given.encode("utf-8"), config.secret.encode("utf-8"))


def process_event(payload: dict, config: WebhookConfig) -> dict:
    member, warnings = member_from_record(payload, config.field_map)
    if not member.name and not member.email:
        raise ValueError("no name or email found in the payload; set field names with --map")
    msg = build_message(member, config.rules, config.llm)
    record = {
        "received_at": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
        **msg.to_dict(),
        "warnings": warnings,
        "forwarded": False,
    }
    if config.forward_url:
        try:
            status, body = config.forward_transport(
                config.forward_url, {"Content-Type": "application/json"},
                json.dumps(record).encode("utf-8"), config.forward_timeout)
            record["forwarded"] = 200 <= status < 300
            if not record["forwarded"]:
                record["forward_error"] = f"HTTP {status}"
        except (LLMError, OSError) as exc:
            record["forward_error"] = str(exc)
    if config.outbox:
        with config._lock:
            config.outbox.parent.mkdir(parents=True, exist_ok=True)
            with config.outbox.open("a", encoding="utf-8") as fh:
                fh.write(json.dumps(record, ensure_ascii=False) + "\n")
    return record


def make_handler(config: WebhookConfig):
    class Handler(BaseHTTPRequestHandler):
        server_version = "skool-kit-webhook/0.1"
        timeout = REQUEST_TIMEOUT  # drop clients that open a connection and never finish sending

        def _send(self, status: int, data: dict):
            body = json.dumps(data).encode("utf-8")
            self.send_response(status)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def log_message(self, fmt, *args):  # quiet by default; route to config.log if given
            if config.log:
                line = fmt % args
                if config.secret:
                    line = line.replace(urllib.parse.quote(config.secret, safe=""), "***").replace(config.secret, "***")
                config.log("%s - %s" % (self.address_string(), line))

        def do_GET(self):  # noqa: N802
            if urllib.parse.urlsplit(self.path).path == "/health":
                self._send(200, {"ok": True})
            else:
                self._send(404, {"ok": False, "error": "not found"})

        def do_POST(self):  # noqa: N802
            parts = urllib.parse.urlsplit(self.path)
            if parts.path not in config.paths:
                self._send(404, {"ok": False, "error": "not found"})
                return
            query = urllib.parse.parse_qs(parts.query)
            if not check_secret(config, self.headers, query):
                self._send(401, {"ok": False, "error": "bad or missing secret"})
                return
            try:
                length = int(self.headers.get("Content-Length") or 0)
            except ValueError:
                length = -1
            if length < 0 or length > MAX_BODY:
                self._send(413, {"ok": False, "error": "body too large"})
                return
            raw = self.rfile.read(length) if length else b""
            ctype = (self.headers.get("Content-Type") or "").split(";")[0].strip().lower()
            try:
                if ctype == "application/x-www-form-urlencoded":
                    payload = {k: v[0] if len(v) == 1 else v
                               for k, v in urllib.parse.parse_qs(raw.decode("utf-8")).items()}
                else:
                    payload = json.loads(raw.decode("utf-8"))
            except (ValueError, UnicodeDecodeError):
                self._send(400, {"ok": False, "error": "body is not valid JSON"})
                return
            if not isinstance(payload, dict):
                self._send(400, {"ok": False, "error": "expected a JSON object with the member's fields"})
                return
            try:
                record = process_event(payload, config)
            except ValueError as exc:
                self._send(400, {"ok": False, "error": str(exc)})
                return
            except OSError as exc:
                self._send(500, {"ok": False, "error": f"could not write outbox: {exc}"})
                return
            if config.log:
                config.log(f"new member {record.get('email') or record.get('name')}: {record['segment']} / "
                           f"{record['goal']} (forwarded: {record['forwarded']})")
            self._send(200, {"ok": True, **record})

    return Handler


def make_server(config: WebhookConfig, host: str = "127.0.0.1", port: int = 8787) -> ThreadingHTTPServer:
    if not config.secret:
        raise ValueError("a shared secret is required (--secret or SKOOL_KIT_SECRET)")
    server = ThreadingHTTPServer((host, port), make_handler(config))
    server.daemon_threads = True
    return server
