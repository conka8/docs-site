from datetime import datetime
from pathlib import Path

import pytest

FIX = Path(__file__).parent / "fixtures"
AS_OF = datetime(2026, 10, 28)


@pytest.fixture
def fix():
    return FIX


@pytest.fixture
def as_of():
    return AS_OF
