from pathlib import Path

from skool_kit.citations import check_citations, load_lessons
from skool_kit.cli import main

PACK = Path(__file__).resolve().parents[1] / "examples/agency-lab/member-pack"


def statuses(reply):
    return [c.status for c in check_citations(reply, load_lessons([PACK]))]


def test_quoted_passage_is_found_despite_quotes_case_and_emphasis():
    reply = ('Price it. *(Lesson: "Pricing your first offer": "write the price on the offer page. '
             '‘Contact us for pricing’ kills **first** conversations.")*')
    assert statuses(reply) == ["ok"]


def test_passage_from_another_lesson_is_caught():
    # The defect from the benchmark: a real sentence credited to the wrong lesson.
    reply = '*(Lesson: "The one-outcome offer": "Contact us for pricing kills first conversations.")*'
    assert statuses(reply) == ["passage not found"]


def test_title_only_and_invented_lessons_are_reported():
    reply = '*(Lesson: "Pricing your first offer")* and *(Lesson: "The Northwind method": "Charge more.")*'
    assert statuses(reply) == ["no passage", "unknown lesson"]


def test_ellipsis_joins_fragments_in_order():
    ok = '*(Lesson: "The follow-up cadence": "Most replies come from follow-ups... Send exactly two.")*'
    backwards = '*(Lesson: "The follow-up cadence": "Send exactly two... Most replies come from follow-ups")*'
    assert statuses(ok + backwards) == ["ok", "passage not found"]


def test_cli_exit_code(tmp_path, capsys):
    good, bad = tmp_path / "good.md", tmp_path / "bad.md"
    good.write_text('*(Lesson: "Pricing your first offer": "Never go below 300 a month.")*', encoding="utf-8")
    bad.write_text('*(Lesson: "Pricing your first offer": "Never go below 200 a month.")*', encoding="utf-8")
    assert main(["check-citations", str(good), "--skills", str(PACK)]) == 0
    assert "1 of 1 citations verified" in capsys.readouterr().out
    assert main(["check-citations", str(good), str(bad), "--skills", str(PACK)]) == 1
    assert 'passage not found: "Pricing your first offer"' in capsys.readouterr().out
    assert main(["check-citations", str(good), "--skills", str(tmp_path)]) == 2


def test_shipped_examples_cite_real_passages():
    for f in PACK.glob("skills/*/examples/example-output.md"):
        found = check_citations(f.read_text(encoding="utf-8"), load_lessons([PACK]))
        assert found and all(c.status == "ok" for c in found), (f, [(c.lesson, c.status) for c in found])
