from pathlib import Path

import pytest
import yaml

from skool_kit.cli import main
from skool_kit.draft import TODO, lesson_rules

LAB = Path(__file__).parent.parent / "examples" / "agency-lab"


def test_rules_are_copied_word_for_word_with_mistakes_labelled():
    text = (LAB / "classroom/02-your-offer/01-pick-a-niche-with-the-3-filter-test.md").read_text()
    rules = lesson_rules(text)
    assert "Avoid this common mistake from the lesson: Switching niche every week. Commit for 30 days." in rules
    loom = lesson_rules((LAB / "classroom/03-outreach/01-the-3-line-loom-script.md").read_text())
    assert "Never start with \"I\" or your company name. Start with them." in loom
    assert all(not r.startswith("**") for r in loom)


def test_draft_builds_for_preview_but_cannot_be_shared(tmp_path, capsys):
    spec = tmp_path / "pack.yaml"
    assert main(["pack-draft", str(LAB / "classroom"), "--community-name", "Northwind", "-o", str(spec)]) == 0
    out = capsys.readouterr().out
    assert "4 draft task(s) from 8 lessons" in out and "TODO (owner)" in out
    data = yaml.safe_load(spec.read_text())
    lessons = {r["lesson"] for pb in data["playbooks"] for r in pb["rules"]}
    assert "Pricing your first offer" in lessons
    assert all(TODO in pb["title"] for pb in data["playbooks"])
    # Every rule is in its lesson's text, so nothing in the draft is invented.
    texts = {p.read_text() for p in (LAB / "classroom").rglob("*.md")}
    for pb in data["playbooks"]:
        for r in pb["rules"]:
            body = r["rule"].split(": ", 1)[1] if r["rule"].startswith("Avoid this") else r["rule"]
            assert any(body.replace('"', "") in t.replace("**", "").replace('"', "") for t in texts), body
    assert main(["pack-build", str(spec), "-o", str(tmp_path / "pack")]) == 0
    capsys.readouterr()
    assert main(["pack-share", str(tmp_path / "pack"), "-o", str(tmp_path / "share"), "--version", "1.0.0"]) == 2
    assert "still contains TODO (owner)" in capsys.readouterr().err
    assert main(["pack-draft", str(LAB / "classroom"), "--community-name", "Northwind", "-o", str(spec)]) == 2
    assert "already exists" in capsys.readouterr().err
