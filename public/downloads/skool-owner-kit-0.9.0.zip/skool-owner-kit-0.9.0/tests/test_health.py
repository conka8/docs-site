import csv
import io
import json
from datetime import datetime, timedelta

import pytest

from skool_kit import health
from skool_kit.dashboard import column_chart, render_dashboard
from skool_kit.health import at_risk, band_for, compute_kpis, score_all, score_member
from skool_kit.members import Member, import_members

AS_OF = datetime(2026, 10, 28)


def days_ago(n):
    return AS_OF - timedelta(days=n)


def snap(n_days_ago, posts, comments=0, level=None, email="x@x.com"):
    return Member(email=email, snapshot_date=days_ago(n_days_ago), posts=posts, comments=comments, level=level)


def kinds(h):
    return {r.kind: r.points for r in h.reasons}


@pytest.mark.parametrize("inactive,points", [(0, 0), (3, 0), (4, 10), (7, 10), (8, 25), (14, 25), (15, 40),
                                             (30, 40), (31, 55), (200, 55)])
def test_inactivity_points(inactive, points):
    m = Member(name="A", joined=days_ago(250), last_active=days_ago(inactive), posts=5)
    h = score_member(m, AS_OF)
    assert h.days_inactive == inactive
    assert kinds(h).get("inactive", 0) == points
    assert h.risk == max(0, points - 5)  # 250-day member: tenure bonus


def test_unknown_last_active_and_never_posted():
    h = score_member(Member(name="A", joined=days_ago(40), posts=0, comments=0), AS_OF)
    assert kinds(h) == {"inactive": 20, "never_posted": 15}
    assert h.risk == 35 and h.band == "medium"
    assert "drop a quick intro post" not in h.suggestion  # inactivity (20) outranks never-posted (15)
    assert h.suggestion.startswith("Hey A, haven't seen you")


def test_new_quiet_member():
    h = score_member(Member(name="Bo", joined=days_ago(5), last_active=days_ago(1), posts=0), AS_OF)
    assert kinds(h) == {"new_quiet": 5} and h.risk == 5 and h.band == "low"
    assert h.suggestion.startswith("Hey Bo, welcome again")


def test_unknown_contributions_not_penalised():
    h = score_member(Member(name="A", joined=days_ago(40), last_active=days_ago(1)), AS_OF)
    assert h.risk == 0 and h.contributions is None
    assert h.suggestion.startswith("Hey A, thanks for being part")


def test_trend_stopped_and_slowing():
    m = Member(email="x@x.com", name="X", joined=days_ago(90), last_active=days_ago(1))
    stopped = score_member(m, AS_OF, [snap(21, 10), snap(14, 20), snap(7, 30), snap(0, 30)])
    assert kinds(stopped)["stopped"] == 20 and "none since" in stopped.reasons[0].text
    slowing = score_member(m, AS_OF, [snap(21, 10), snap(14, 20), snap(7, 30), snap(0, 33)])
    assert kinds(slowing) == {"slowing": 12}
    steady = score_member(m, AS_OF, [snap(14, 10), snap(7, 20), snap(0, 30)])
    assert kinds(steady) == {}
    # snapshots are sorted by date, whatever the file order
    shuffled = score_member(m, AS_OF, [snap(0, 30), snap(21, 10), snap(7, 30), snap(14, 20)])
    assert kinds(shuffled)["stopped"] == 20


def test_trend_two_snapshots_and_contrib_from_snapshot():
    m = Member(email="x@x.com", joined=days_ago(60), last_active=days_ago(2))
    h = score_member(m, AS_OF, [snap(7, 4, 4), snap(0, 4, 4)])
    assert kinds(h) == {"stopped": 8}
    assert h.contributions == 8  # member row has no counts: latest snapshot used
    zero = score_member(m, AS_OF, [snap(7, 0), snap(0, 0)])
    assert "stopped" not in kinds(zero) and kinds(zero)["never_posted"] == 15


def test_level_stagnation():
    m = Member(email="x@x.com", joined=days_ago(60), last_active=days_ago(1), posts=10)
    stuck = score_member(m, AS_OF, [snap(30, 5, level=2), snap(0, 10, level=2)])
    assert kinds(stuck)["level"] == 10 and "stuck at level 2 for 30 days" in stuck.reasons[-1].text
    short = score_member(m, AS_OF, [snap(10, 5, level=2), snap(0, 10, level=2)])
    assert "level" not in kinds(short)
    up = score_member(m, AS_OF, [snap(30, 5, level=1), snap(0, 10, level=2)])
    assert "level" not in kinds(up)
    no_snaps = score_member(Member(name="L", joined=days_ago(45), last_active=days_ago(1), posts=1, level=1), AS_OF)
    assert kinds(no_snaps) == {"level": 10}
    young = score_member(Member(name="L", joined=days_ago(10), last_active=days_ago(1), posts=1, level=1), AS_OF)
    assert "level" not in kinds(young)


def test_tenure_bonus_and_clamping():
    loyal = score_member(Member(name="A", joined=days_ago(400), last_active=days_ago(0), posts=3), AS_OF)
    assert kinds(loyal) == {"tenure": -5} and loyal.risk == 0
    assert "lowers risk" in loyal.reasons[0].text
    assert loyal.to_dict()["reasons"] == []  # only risk-raising reasons are listed
    worst = score_member(Member(email="x@x.com", joined=days_ago(60), last_active=days_ago(90), level=1, posts=0),
                         AS_OF, [snap(60, 0, level=1), snap(30, 0, level=1), snap(0, 0, level=1)])
    assert worst.risk == 80 and worst.band == "high"


def test_last_active_before_join_is_clamped():
    h = score_member(Member(name="A", joined=days_ago(5), last_active=days_ago(50), posts=1), AS_OF)
    assert h.days_inactive == 5


def test_last_active_from_snapshot():
    s = snap(0, 3)
    s.last_active = days_ago(9)
    h = score_member(Member(email="x@x.com", joined=days_ago(60), posts=3), AS_OF, [s])
    assert h.days_inactive == 9


def test_engagement_score_bounds():
    hot = score_member(Member(name="A", joined=days_ago(70), last_active=days_ago(0), posts=500, level=9), AS_OF)
    assert hot.engagement == 100
    cold = score_member(Member(name="B", joined=days_ago(70), last_active=days_ago(60), posts=0), AS_OF)
    assert cold.engagement == 0


def test_band_for():
    assert [band_for(x) for x in (0, 34, 35, 59, 60, 100)] == ["low", "low", "medium", "medium", "high", "high"]


@pytest.fixture
def scored(fix):
    members = import_members(fix / "members_standard.csv").members
    activity = import_members(fix / "activity.csv", allow_duplicates=True).members
    return score_all(members, AS_OF, activity)


def test_fixture_scores_and_ordering(scored):
    by = {h.member.name: h for h in scored}
    assert by["Ana Lopez"].risk == 0 and by["Ben Carter"].risk == 0
    assert by["Cara Diaz"].risk == 55
    assert by["Dan Moore"].risk == 65 and set(kinds(by["Dan Moore"])) == {"inactive", "stopped", "level", "tenure"}
    assert by["Eve Stone"].risk == 5
    assert by["Dan Moore"].snapshots == 4 and by["Ana Lopez"].snapshots == 2
    risky = at_risk(scored)
    assert [h.member.name for h in risky] == ["Dan Moore", "Cara Diaz"]
    assert [h.member.name for h in at_risk(scored, threshold=60)] == ["Dan Moore"]


def test_at_risk_paid_first_on_ties():
    a = score_member(Member(name="Free", joined=days_ago(60), last_active=days_ago(40), posts=1, price=0), AS_OF)
    b = score_member(Member(name="Paid", joined=days_ago(60), last_active=days_ago(40), posts=1, price=49), AS_OF)
    c = score_member(Member(name="Paid more", joined=days_ago(60), last_active=days_ago(40), posts=1, price=99), AS_OF)
    assert [h.member.name for h in at_risk([a, b, c])] == ["Paid more", "Paid", "Free"]


def test_snapshots_matched_by_name_when_no_email():
    m = Member(name="Sam Lee", joined=days_ago(60), last_active=days_ago(1))
    act = [Member(name="sam lee", snapshot_date=days_ago(7), posts=5), Member(name="Sam Lee", snapshot_date=days_ago(0), posts=5)]
    assert score_all([m], AS_OF, act)[0].snapshots == 2


def test_kpis(scored):
    k = compute_kpis(scored, AS_OF)
    assert (k.total_members, k.paid_members) == (5, 3)
    assert (k.active_7d, k.active_7d_pct, k.active_30d, k.active_30d_pct) == (3, 60.0, 5, 100.0)
    assert (k.at_risk, k.at_risk_paying, k.revenue_at_risk) == (2, 1, 99)
    assert k.risk_bands == {"high": 1, "medium": 1, "low": 3}
    weeks = {w["week_start"]: w["count"] for w in k.joins_per_week}
    assert len(weeks) == 8 and weeks["2026-10-19"] == 3 and weeks["2026-09-28"] == 1 and weeks["2026-10-26"] == 0
    assert k.avg_joins_per_week == 0.5
    assert k.cohorts == [{"month": "2026-04", "members": 1, "active_30d": 1, "retention_pct": 100.0},
                         {"month": "2026-10", "members": 4, "active_30d": 4, "retention_pct": 100.0}]
    assert [c["name"] for c in k.top_contributors] == ["Dan Moore", "Ana Lopez", "Ben Carter"]
    assert k.to_dict()["as_of"] == "2026-10-28"


def test_kpis_empty():
    k = compute_kpis([], AS_OF)
    assert k.total_members == 0 and k.active_7d_pct is None and k.active_30d_pct is None
    assert k.avg_joins_per_week == 0 and k.cohorts == [] and k.top_contributors == []
    page = render_dashboard(k, [], [])
    assert "n/a" in page and "Nobody is at risk right now." in page and "No posts or comments" in page
    assert "No data yet." in page  # empty cohort chart


def test_at_risk_csv_and_json(scored):
    risky = at_risk(scored)
    rows = list(csv.DictReader(io.StringIO(health.at_risk_csv(risky))))
    assert rows[0]["name"] == "Dan Moore" and rows[0]["paid"] == "yes" and rows[0]["risk_score"] == "65"
    assert "stopped posting" in rows[0]["reasons"] and rows[0]["suggested_message"].startswith("Hey Dan")
    assert rows[1]["paid"] == "no"
    data = json.loads(health.health_json(compute_kpis(scored, AS_OF), risky))
    assert data["kpis"]["at_risk"] == 2 and data["at_risk"][1]["name"] == "Cara Diaz"


def test_dashboard_escaping_and_content(scored):
    scored[3].member.name = "<script>alert('x')</script>"
    risky = at_risk(scored)
    page = render_dashboard(compute_kpis(scored, AS_OF), scored, risky, community_name="A & B <Club>",
                            brand_color="#ff0066")
    assert "<script>alert" not in page and "&lt;script&gt;" in page
    assert "A &amp; B &lt;Club&gt; community health" in page
    assert "--series:#ff0066" in page
    assert page.count("<svg") == 3 and "<title>2026-10: 100%</title>" in page
    assert "$99 per billing period" in page
    bad_color = render_dashboard(compute_kpis(scored, AS_OF), scored, risky, brand_color="red;}body{x")
    assert "red;}" not in bad_color and "--series:#2a78d6" in bad_color


def test_dashboard_truncates_long_lists(scored):
    risky = at_risk(scored, threshold=0)
    page = render_dashboard(compute_kpis(scored, AS_OF), scored, risky, max_rows=2)
    assert "Showing 2 of 5" in page


def test_column_chart():
    svg = column_chart([("a", 0), ("b", 10)], title="t<")
    assert 'aria-label="t&lt;"' in svg and svg.count('class="bar"') == 1  # zero bar draws no mark
    assert "<title>b: 10</title>" in svg
    assert column_chart([]) == '<p class="muted">No data yet.</p>'
    allzero = column_chart([("a", 0)])
    assert 'class="bar"' not in allzero


def test_dashboard_does_not_present_activity_as_retention_or_churn(scored):
    page = render_dashboard(compute_kpis(scored, AS_OF), scored, at_risk(scored))
    visible = page.split("</style>", 1)[1]
    assert "Retention" not in visible and "Churn" not in visible and "churn" not in visible
    assert "<h2>Cohort activity</h2>" in visible and "this is not a cancellation or retention rate" in visible
    assert "<h2>Inactivity risk</h2>" in visible and "not a prediction of who will cancel" in visible
    assert 'id="how"' in visible and "How to read this" in visible
