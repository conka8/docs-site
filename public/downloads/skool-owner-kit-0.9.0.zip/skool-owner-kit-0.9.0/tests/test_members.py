from datetime import date, datetime

import pytest

from skool_kit.dates import parse_date
from skool_kit.members import (MappingError, Member, detect_mapping, flatten, import_members, import_rows,
                               member_from_record, normalize_header, parse_overrides, read_table, sniff_delimiter)

TODAY = date(2026, 10, 28)


@pytest.mark.parametrize("text,expected", [
    ("2026-10-03", datetime(2026, 10, 3)),
    ("2026-10-03T14:22:11Z", datetime(2026, 10, 3, 14, 22, 11)),
    ("2026-10-03T09:22:11-05:00", datetime(2026, 10, 3, 14, 22, 11)),
    ("2026-10-03 14:22", datetime(2026, 10, 3, 14, 22)),
    ("10/3/2026", datetime(2026, 10, 3)),
    ("10/03/26", datetime(2026, 10, 3)),
    ("10/03/2026 2:15 PM", datetime(2026, 10, 3, 14, 15)),
    ("10/3/2026 9:05am", datetime(2026, 10, 3, 9, 5)),
    ("Oct 3, 2026", datetime(2026, 10, 3)),
    ("October 3rd, 2026 at 2:15pm", datetime(2026, 10, 3, 14, 15)),
    ("Oct. 3, 2026, 2:15 p.m.", datetime(2026, 10, 3, 14, 15)),
    ("Sat, Oct 3, 2026", datetime(2026, 10, 3)),
    ("3 Oct 2026", datetime(2026, 10, 3)),
    ("2026/10/03", datetime(2026, 10, 3)),
    ("25/12/2026", datetime(2026, 12, 25)),  # impossible as US -> day-first fallback
    ("1790936000", datetime(2026, 10, 2, 10, 13, 20)),
    ("1790936000000", datetime(2026, 10, 2, 10, 13, 20)),
    ("3d ago", datetime(2026, 10, 25)),
    ("Active 2 weeks ago", datetime(2026, 10, 14)),
    ("yesterday", datetime(2026, 10, 27)),
    ("today", datetime(2026, 10, 28)),
    ("5 hours ago", datetime(2026, 10, 27, 19)),
])
def test_parse_date(text, expected):
    assert parse_date(text, today=TODAY) == expected


@pytest.mark.parametrize("text", ["", None, "-", "n/a", "never", "sometime", "13/25/2026", "2026-13-01"])
def test_parse_date_rejects(text):
    assert parse_date(text, today=TODAY) is None


def test_parse_date_dayfirst_and_objects():
    assert parse_date("03/10/2026", dayfirst=True) == datetime(2026, 10, 3)
    assert parse_date("03/10/2026") == datetime(2026, 3, 10)
    assert parse_date(date(2026, 1, 2)) == datetime(2026, 1, 2)
    assert parse_date(datetime(2026, 1, 2, 3)) == datetime(2026, 1, 2, 3)
    from datetime import timezone, timedelta
    aware = datetime(2026, 1, 2, 3, tzinfo=timezone(timedelta(hours=-5)))
    assert parse_date(aware) == datetime(2026, 1, 2, 8)
    assert parse_date("yesterday", today=datetime(2026, 1, 2, 12, tzinfo=timezone.utc)) == datetime(2026, 1, 1, 12)
    assert parse_date("today") is not None  # uses now()


def test_normalize_header():
    assert normalize_header("﻿  E-Mail Address ") == "e mail address"
    assert normalize_header("# Posts") == "number posts"
    assert normalize_header("What's your goal?") == "what s your goal?"


def test_standard_export(fix):
    res = import_members(fix / "members_standard.csv")
    assert res.delimiter == ","
    assert res.mapping["answers"] == ["Question 1", "Question 2", "Question 3"]
    assert not res.skipped and not res.warnings and not res.unmapped
    ana, ben, cara, dan, eve = res.members
    assert ana.name == "Ana Lopez" and ana.first_name == "Ana" and ana.email == "ana@example.com"
    assert ana.joined == datetime(2026, 10, 20) and ana.level == 2 and ana.points == 40
    assert ana.posts == 3 and ana.comments == 10 and ana.contributions == 13
    assert ana.price == 49 and ana.ltv == 98 and ana.is_paid is True and ana.invited_by == "Sam Owner"
    assert ben.email == "ben@example.com"  # lower-cased
    assert ben.last_active == datetime(2026, 10, 26, 21, 15)
    assert cara.joined == datetime(2026, 10, 3) and cara.is_paid is False
    assert dan.joined == datetime(2026, 4, 1, 10)
    assert eve.price == 0 and eve.is_paid is False and eve.ltv is None
    assert len(ana.answers) == 3
    d = ana.to_dict()
    assert d["joined"] == "2026-10-20 00:00:00" and d["paid"] is True


def test_semicolon_bom_first_last(fix):
    res = import_members(fix / "members_semicolon_bom.csv", today=TODAY)
    assert res.delimiter == ";"
    assert "first_name" in res.mapping and res.mapping["email"] == ["E-mail Address"]
    zoe, yan = res.members
    assert zoe.name == "Zoe Kim" and zoe.first_name == "Zoe"
    assert zoe.joined == datetime(2026, 10, 3) and zoe.last_active == datetime(2026, 10, 3, 14, 15)
    assert zoe.is_paid is True and yan.is_paid is False
    assert yan.joined == datetime(2026, 10, 10, 9)
    assert yan.last_active == datetime(2026, 10, 25)
    assert zoe.answers == ["I have an agency and need more clients"]


def test_bad_rows(fix):
    res = import_members(fix / "members_bad.csv")
    assert [m.name for m in res.members] == ["Good Person", "Bad Date", "Only Name"]
    assert [(s.row, s.reason) for s in res.skipped] == [
        (5, "no name and no email"), (6, "duplicate of an earlier row (good@example.com)")]
    joined = "\n".join(res.warnings)
    assert "row 3: could not read joined date 'sometime last year'" in joined
    assert "row 3: level 'two' is not a number" in joined
    assert "row 7: could not read joined date '13/25/2026'" in joined
    bad = res.members[1]
    assert bad.joined is None and bad.level is None and bad.last_active is None
    assert res.total_rows == 5  # blank row not counted


def test_allow_duplicates(fix):
    res = import_members(fix / "members_bad.csv", allow_duplicates=True)
    assert len(res.members) == 4


def test_missing_identity_column(fix):
    with pytest.raises(MappingError, match="Could not find a name or email column"):
        import_members(fix / "members_no_identity.csv")
    res = import_members(fix / "members_no_identity.csv", ["Foo=name", "bar=ignore"])
    assert res.members[0].name == "1" and res.unmapped == []


def test_overrides():
    assert parse_overrides(["Why join?=answers", "X = Last-Active"]) == {"why join?": "answers", "x": "last_active"}
    with pytest.raises(MappingError, match="COLUMN=FIELD"):
        parse_overrides(["nope"])
    with pytest.raises(MappingError, match="unknown field"):
        parse_overrides(["a=shoe_size"])
    with pytest.raises(MappingError, match="not in the data"):
        detect_mapping(["Email"], {"missing": "name"})
    mapping, unmapped = detect_mapping(["Email", "Mail", "What brought you here?", "Q2", "Favourite colour"])
    assert mapping == {"email": ["Email"], "answers": ["What brought you here?", "Q2"]}
    assert unmapped == ["Mail", "Favourite colour"]  # second email column ignored


def test_header_variants():
    headers = ["Member Name", "Email Address", "Approved At", "Membership Questions", "Lvl", "Total Points",
               "Last Seen", "Post Count", "Number of Comments", "Plan Price", "Tier", "Referred By",
               "Lifetime Value"]
    mapping, unmapped = detect_mapping(headers)
    assert set(mapping) == {"name", "email", "joined", "answers", "level", "points", "last_active", "posts",
                            "comments", "price", "plan", "invited_by", "ltv"}
    assert unmapped == []


def test_sniff_delimiter():
    assert sniff_delimiter("a;b;c\n1;2;3\n") == ";"
    assert sniff_delimiter("a\tb\n1\t2\n") == "\t"
    assert sniff_delimiter("name,email\n\"Lopez, Ana\",a@x.com\n") == ","
    assert sniff_delimiter("single\nvalue\n") == ","
    assert sniff_delimiter("") == ","


def test_read_table_cp1252_and_empty(tmp_path):
    p = tmp_path / "w.csv"
    p.write_bytes("Name,Email\nJos\xe9,j@x.com\n".encode("cp1252"))
    headers, rows, delim, warnings = read_table(p)
    assert rows[0][0] == "José" and "Windows-1252" in warnings[0]
    e = tmp_path / "e.csv"
    e.write_text("\n\n")
    with pytest.raises(MappingError, match="empty"):
        import_members(e)
    with pytest.raises(FileNotFoundError):
        import_members(tmp_path / "missing.csv")


def test_extra_cells_and_bad_email():
    res = import_rows(["Name", "Email"], [["A", "not-an-email", "extra"]])
    assert any("more cells" in w for w in res.warnings)
    assert any("looks wrong" in w for w in res.warnings)
    assert res.members[0].extra == {}


def test_first_name_fallbacks():
    assert Member(email="jane.doe@x.com").first_name == "Jane"
    assert Member().first_name == "there"
    assert Member(name="  ").first_name == "there"
    assert Member(email="123@x.com").first_name == "there"
    assert Member(name="Ana Lopez", first_name_raw="Ani").first_name == "Ani"


def test_is_paid_variants():
    assert Member(plan="Pro 2024").is_paid is True
    assert Member(plan="Free trial").is_paid is False
    assert Member(plan="$0").is_paid is False
    assert Member().is_paid is None
    assert Member(price=0, plan="VIP").is_paid is False


def test_flatten_and_record():
    assert flatten({"a": {"b": {"c": 1}}, "d": [1]}) == {"a.b.c": 1, "d": [1]}
    m, warnings = member_from_record({
        "data": {"member": {"email": "Zed@X.com", "first_name": "Zed", "last_name": "Ali"},
                 "answers": ["I run an agency", " "]},
        "Question 1": "need clients", "joined_at": "Oct 1, 2026", "level": "x"})
    assert m.email == "zed@x.com" and m.name == "Zed Ali" and m.first_name == "Zed"
    assert m.answers == ["I run an agency", "need clients"]
    assert m.joined == datetime(2026, 10, 1)
    assert any("level" in w for w in warnings)
    m2, _ = member_from_record({"Who are you": "dev", "mail": "a@b.c"}, ["Who are you=answers"])
    assert m2.answers == ["dev"] and m2.email == "a@b.c"
