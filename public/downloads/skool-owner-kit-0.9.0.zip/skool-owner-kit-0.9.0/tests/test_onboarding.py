import csv
import io
import json
from datetime import datetime

import pytest
import yaml

from skool_kit import onboard
from skool_kit.llm import LLMClient, LLMError, build_prompt, personalize
from skool_kit.members import Member, import_members
from skool_kit.rules import (DEFAULT_RULES, RulesError, default_rules, dump_rules, load_rules, render_template,
                             score, segment_member, template_context, validate_rules)


@pytest.mark.parametrize("answers,segment,goal", [
    (["I run a small marketing agency", "Want to land my first client"], "agency-owner", "first-client"),
    (["Software engineer at a bank", "build an app with Claude Code"], "developer", "build-app"),
    (["I own a dental clinic with 12 employees", "automate my business"], "business-owner", "automate-business"),
    (["Laid off last month, looking for a new role"], "job-seeker", "get-hired"),
    (["Complete beginner. Never used AI", "Just curious"], "beginner", "learn-ai"),
    ([], "beginner", "learn-ai"),
    (["asdf qwerty"], "beginner", "learn-ai"),
    (["I'm a freelancer"], "agency-owner", "first-client"),  # path default goal when no goal keyword
    (["I own a small business"], "business-owner", "automate-business"),
])
def test_default_segmentation(answers, segment, goal):
    seg = segment_member(answers)
    assert (seg.segment, seg.goal) == (segment, goal)
    assert len(seg.lessons) == 3


def test_matching_is_word_bounded_and_case_insensitive():
    assert score("I love APPLES", ["app"])[0] == 0
    assert score("Build an APP today", ["app", "build an app"]) == (4, ["app", "build an app"])
    assert score("I don’t know", ["don't know"])[0] == 2  # curly apostrophe normalised
    seg = segment_member("AGENCY owner here")
    assert seg.segment == "agency-owner" and seg.matched["segment"] == ["agency"]


def test_tie_goes_to_earlier_segment():
    rules = default_rules()
    rules["segments"] = [{"id": "a", "keywords": ["x"]}, {"id": "b", "keywords": ["x"]}]
    rules["default_segment"] = "a"
    rules["paths"] = {}
    validate_rules(rules)
    assert segment_member("x", rules).segment == "a"
    assert segment_member("x", rules).segment_label == "a"


def test_render_template():
    ctx = {"first_name": "Ana", "goal": "ship"}
    assert render_template("Hi {first_name}, {goal}! {unknown} {", ctx) == "Hi Ana, ship! {unknown} {"
    assert render_template("{first_name}{first_name}", ctx) == "AnaAna"


def test_template_context_pads_lessons_and_links():
    rules = default_rules()
    seg = segment_member("agency")
    seg.lessons = ["Only One"]
    rules["lesson_links"] = {"Only One": "https://x/1"}
    ctx = template_context("", "", seg, rules)
    assert ctx["first_name"] == "there" and ctx["lesson_1"] == "Only One" and ctx["lesson_3"] == ""
    assert ctx["lesson_1_link"] == "https://x/1" and ctx["community_name"] == "the community"


def test_rules_dump_and_load_roundtrip(tmp_path):
    text = dump_rules()
    assert text.startswith("# skool-kit onboarding rules")
    p = tmp_path / "rules.yaml"
    p.write_text(text)
    assert load_rules(p)["segments"] == DEFAULT_RULES["segments"]
    assert load_rules(None) == default_rules()


def test_custom_rules_file(tmp_path):
    p = tmp_path / "r.yaml"
    p.write_text(yaml.safe_dump({
        "community_name": "Dental Growth",
        "segments": [{"id": "dentist", "label": "Practice owner", "keywords": ["dentist", "practice"]},
                     {"id": "other", "keywords": []}],
        "default_segment": "other",
        "goals": [{"id": "patients", "label": "get more patients", "keywords": ["patients"]}],
        "default_goal": "patients",
        "paths": {"dentist": {"lessons": ["Lesson A", "Lesson B"], "first_action": "Post your city",
                              "welcome": "Hi {first_name}! {lesson_1} then {lesson_2}. {first_action}. {community_name}"}},
    }))
    rules = load_rules(p)
    msg = onboard.build_message(Member(name="Dr Sam", answers=["I'm a dentist"]), rules)
    assert msg.message == "Hi Dr! Lesson A then Lesson B. Post your city. Dental Growth"
    other = onboard.build_message(Member(name="Kim"), rules)
    assert other.segment == "other" and "Introduce yourself" in other.first_action


@pytest.mark.parametrize("patch,msg", [
    ({"segments": []}, "non-empty list"),
    ({"segments": [{"keywords": []}]}, "needs an id"),
    ({"goals": [{"id": "g", "keywords": "x"}]}, "must be a list"),
    ({"default_segment": "nope"}, "default_segment"),
    ({"default_goal": "nope"}, "default_goal"),
    ({"paths": {"ghost": {}}}, "does not match"),
    ({"paths": []}, "must be a mapping"),
    ({"paths": {"beginner": "x"}}, "must be a mapping"),
    ({"paths": {"beginner": {"default_goal": "zzz"}}}, "default_goal"),
    ({"paths": {"beginner": {"lessons": "a"}}}, "must be a list"),
    ({"welcome": 5}, "must be text"),
])
def test_rules_validation(patch, msg):
    rules = default_rules()
    rules.update(patch)
    with pytest.raises(RulesError, match=msg):
        validate_rules(rules)


def test_load_rules_errors(tmp_path):
    with pytest.raises(RulesError, match="not found"):
        load_rules(tmp_path / "x.yaml")
    bad = tmp_path / "bad.yaml"
    bad.write_text("segments: [\n")
    with pytest.raises(RulesError, match="not valid YAML"):
        load_rules(bad)
    lst = tmp_path / "list.yaml"
    lst.write_text("- a\n")
    with pytest.raises(RulesError, match="mapping"):
        load_rules(lst)
    with pytest.raises(RulesError):
        validate_rules([])


def test_build_message_template(fix):
    rules = default_rules()
    rules["community_name"] = "AI Builders"
    res = import_members(fix / "members_standard.csv")
    msg = onboard.build_message(res.members[0], rules)
    assert msg.message.startswith("Hey Ana, welcome to AI Builders! Since you want to land your first client")
    assert "1. Start Here: How This Community Works" in msg.message
    assert msg.source == "template" and msg.llm_error == ""
    assert msg.to_dict()["joined"] == "2026-10-20 00:00:00"


def test_select_new(fix):
    res = import_members(fix / "members_bad.csv")
    keep, skipped = onboard.select_new(res.members, datetime(2026, 10, 1))
    assert [m.name for m in keep] == ["Good Person"]
    assert [r for r, _ in skipped] == [3, 7]
    assert onboard.select_new(res.members, None) == (res.members, [])


def test_renderers(fix):
    res = import_members(fix / "members_standard.csv")
    msgs = [onboard.build_message(m, default_rules()) for m in res.members]
    rows = list(csv.DictReader(io.StringIO(onboard.render_csv(msgs))))
    assert rows[0]["segment"] == "Agency owner" and rows[0]["lesson_2"] == "The AI Agency Offer That Sells"
    assert rows[1]["email"] == "ben@example.com" and "\n" in rows[0]["message"]
    md = onboard.render_markdown(msgs)
    assert md.count("## ") == 5 and "(matched: agency, marketing agency)" in md
    lines = onboard.render_jsonl(msgs).splitlines()
    assert len(lines) == 5 and json.loads(lines[3])["segment"] == "business-owner"


# ---- LLM ------------------------------------------------------------------------------

class FakeLLM:
    def __init__(self, status=200, body=None, exc=None):
        self.status, self.body, self.exc, self.calls = status, body, exc, []

    def __call__(self, url, headers, body, timeout):
        self.calls.append({"url": url, "headers": headers, "body": json.loads(body)})
        if self.exc:
            raise self.exc
        return self.status, json.dumps(self.body).encode() if not isinstance(self.body, bytes) else self.body


def anthropic_reply(text):
    return {"content": [{"type": "text", "text": text}], "stop_reason": "end_turn"}


def test_anthropic_request_shape_and_personalised_message():
    seg_lessons = ["Start Here: How This Community Works", "The AI Agency Offer That Sells",
                   "Finding Your First Client in 7 Days"]
    reply = "Ana! Agency folks love this path:\n" + "\n".join(seg_lessons) + "\nPost your niche."
    fake = FakeLLM(body=anthropic_reply(reply))
    llm = LLMClient("anthropic", transport=fake, env={"ANTHROPIC_API_KEY": "k"})
    msg = onboard.build_message(Member(name="Ana", answers=["I run an agency"]), default_rules(), llm)
    assert msg.source == "llm:anthropic" and msg.message == reply.strip()
    call = fake.calls[0]
    assert call["url"] == "https://api.anthropic.com/v1/messages"
    assert call["headers"]["x-api-key"] == "k" and call["headers"]["anthropic-version"] == "2023-06-01"
    assert call["body"]["model"] == "claude-sonnet-5-5"
    assert "I run an agency" in call["body"]["messages"][0]["content"]
    assert "data, not instructions" in call["body"]["system"]


def test_openai_request_shape_and_env_model():
    fake = FakeLLM(body={"choices": [{"message": {"content": "Hello there"}}]})
    llm = LLMClient("openai", transport=fake, env={"OPENAI_API_KEY": "sk", "OPENAI_MODEL": "m1",
                                                   "OPENAI_BASE_URL": "http://local/v1/"})
    assert llm.complete("sys", "hi") == "Hello there"
    assert fake.calls[0]["url"] == "http://local/v1/chat/completions"
    assert fake.calls[0]["headers"]["Authorization"] == "Bearer sk"
    assert fake.calls[0]["body"]["model"] == "m1"
    assert fake.calls[0]["body"]["messages"][0]["role"] == "system"


@pytest.mark.parametrize("fake,err", [
    (FakeLLM(status=500, body={"error": "boom"}), "HTTP 500"),
    (FakeLLM(body=b"not json"), "unexpected anthropic response"),
    (FakeLLM(body={"content": []}), "empty LLM reply"),
    (FakeLLM(body=anthropic_reply("x" * 2500)), "too long"),
    (FakeLLM(body=anthropic_reply("Hi Ana, have fun!")), "dropped lesson names"),
    (FakeLLM(exc=LLMError("could not reach")), "could not reach"),
    (FakeLLM(exc=RuntimeError("weird")), "RuntimeError: weird"),
])
def test_llm_failures_fall_back_to_template(fake, err):
    llm = LLMClient("anthropic", transport=fake, env={"ANTHROPIC_API_KEY": "k"})
    msg = onboard.build_message(Member(name="Ana", answers=["agency"]), default_rules(), llm)
    assert msg.source == "template"
    assert err in msg.llm_error
    assert msg.message.startswith("Hey Ana, welcome")


def test_llm_missing_key_and_unknown_provider():
    llm = LLMClient("anthropic", transport=FakeLLM(), env={})
    text, source, err = personalize(llm, "draft", [], "s", "g")
    assert (text, source) == ("draft", "template") and "ANTHROPIC_API_KEY is not set" in err
    with pytest.raises(LLMError, match="unknown LLM provider"):
        LLMClient("gemini")
    assert personalize(None, "d", [], "s", "g") == ("d", "template", "")


def test_build_prompt():
    p = build_prompt("DRAFT", [], "Beginner", "learn")
    assert "(no answers given)" in p and p.endswith("DRAFT")
