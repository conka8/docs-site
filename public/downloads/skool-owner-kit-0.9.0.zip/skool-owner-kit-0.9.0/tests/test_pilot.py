import json
import shutil
from datetime import date
from pathlib import Path

import pytest

from skool_kit.cli import main
from skool_kit.pilot import PilotError, Rate, analyse, load_plan, render, run

SAMPLE = Path(__file__).parent.parent / "examples" / "agency-lab" / "pilot-sample"

PLAN = """pilot: Test pilot
outcome: First win
within_days: 14
renewal_after_days: 30
as_of: 2027-01-31
pilot_cohort: {joined_from: 2026-11-01, joined_to: 2026-11-30}
baseline_cohort: {joined_from: 2026-09-01, joined_to: 2026-09-30}
membership_price: 100
platform_fee_pct: 10
thresholds: {min_cohort: 2, min_adoption_pct: 40, continue_if_lift_pts: 10, stop_if_lift_pts: 0,
             max_correction_pct: 10, min_acceptance_pct: 100}
"""
ACCEPT_OK = "2026-10-29,tutor,q1,yes,admin,\n2026-10-29,offer,o1,yes,admin,\n"


def write(tmp_path, events, questions="", costs="", plan=PLAN, acceptance=ACCEPT_OK):
    (tmp_path / "pilot.yaml").write_text(plan, encoding="utf-8")
    (tmp_path / "events.csv").write_text("member,event,date,note\n" + events, encoding="utf-8")
    (tmp_path / "questions.csv").write_text("date,topic,handled_by,result,staff_minutes,note\n" + questions,
                                            encoding="utf-8")
    (tmp_path / "costs.csv").write_text("date,item,kind,amount,minutes,note\n" + costs, encoding="utf-8")
    if acceptance is not None:
        (tmp_path / "acceptance.csv").write_text("date,skill,test,passed,reviewer,note\n" + acceptance,
                                                 encoding="utf-8")
    return tmp_path / "pilot.yaml"


def events(rows):
    return "".join(f"{r[0]},{r[1]},{r[2]},{r[3] if len(r) > 3 else ''}\n" for r in rows)


BASIC = events([
    ("p1", "joined", "2026-11-01"), ("p1", "installed", "2026-11-02"), ("p1", "first_outcome", "2026-11-10"),
    ("p1", "task_completed", "2026-11-03", "offer"), ("p1", "task_completed", "2026-11-06", "outreach"),
    ("p1", "renewed", "2026-12-01"),
    ("p2", "joined", "2026-11-05"), ("p2", "installed", "2026-11-05"), ("p2", "first_outcome", "2026-11-30"),
    ("p2", "task_completed", "2026-11-07", "offer"), ("p2", "cancelled", "2026-11-28"),
    ("b1", "joined", "2026-09-01"), ("b1", "first_outcome", "2026-09-30"), ("b1", "renewed", "2026-10-01"),
    ("b2", "joined", "2026-09-10"), ("b2", "cancelled", "2026-10-01"),
])


def test_cohorts_outcome_window_and_lift(tmp_path):
    r = run(write(tmp_path, BASIC))
    assert (r.pilot_members, r.baseline_members) == (2, 2)
    # p2 reached the outcome after 25 days and b1 after 29: outside the 14-day window
    assert (r.outcome_pilot.hits, r.outcome_pilot.total, r.outcome_baseline.hits) == (1, 2, 0)
    assert r.lift_pts == pytest.approx(50.0)
    assert r.outcomes.status == "continue" and r.quality.status == "pass"
    assert any("ranges still overlap" in x for x in r.outcomes.reasons)
    assert r.tasks == {"offer": 2, "outreach": 1}
    assert r.used.hits == 2


def test_members_whose_window_is_still_open_are_not_failures(tmp_path):
    plan = PLAN.replace("as_of: 2027-01-31", "as_of: 2026-11-12")
    r = run(write(tmp_path, BASIC, plan=plan))
    # p1 joined Nov 1 (window closed Nov 15 > Nov 12): pending; p2 joined Nov 5: pending.
    assert r.outcome_pilot.total == 0 and r.outcome_pending == 2
    assert r.decision == "not enough data"


def test_renewals_count_only_after_the_renewal_date(tmp_path):
    plan = PLAN.replace("as_of: 2027-01-31", "as_of: 2026-12-02")
    r = run(write(tmp_path, BASIC, plan=plan))
    # p1 due Dec 1 (counted), p2 due Dec 5 (not due yet) even though p2 already cancelled
    assert (r.renewal_pilot.hits, r.renewal_pilot.total, r.renewal_not_due) == (1, 1, 1)


def test_unlogged_renewals_are_left_out_and_reported(tmp_path):
    rows = BASIC + events([("p3", "joined", "2026-11-10")])
    r = run(write(tmp_path, rows))
    assert r.renewal_unlogged == 1
    assert any("no 'renewed' or 'cancelled' row" in w for w in r.warnings)


def test_excluded_members_leave_the_cohort(tmp_path):
    rows = BASIC + events([("p2", "excluded", "2026-11-06", "refunded in trial")])
    assert run(write(tmp_path, rows)).pilot_members == 1


def test_renewal_and_observed_revenue_difference(tmp_path):
    r = run(write(tmp_path, BASIC))
    assert (r.renewal_pilot.hits, r.renewal_pilot.total) == (1, 2)
    assert (r.renewal_baseline.hits, r.renewal_baseline.total) == (1, 2)
    assert r.observed_revenue_difference == pytest.approx(0.0)
    assert r.economics.status == "positive"  # 0 difference, 0 cost


def test_support_metrics_keep_capacity_separate_from_cash(tmp_path):
    q = ("2026-11-02,niche,tutor,resolved,0,\n2026-11-03,niche,tutor,resolved,0,\n"
         "2026-11-04,price,tutor,corrected,5,\n2026-11-05,tax,tutor,escalated,5,\n"
         "2026-11-06,setup,staff,resolved,10,\n2026-11-07,setup,staff,resolved,20,\n")
    c = "2026-11-01,setup,time,,120,\n2026-11-01,api,cash,12.5,,\n2026-11-02,fee,cash,\"1,000\",,\n"
    r = run(write(tmp_path, BASIC, q, c))
    assert (r.tutor_answers, r.tutor_resolved, r.tutor_corrected, r.tutor_escalated) == (4, 2, 1, 1)
    assert r.correction_pct == 25.0 and r.staff_minutes_per_question == 15.0
    assert r.capacity_hours_freed_estimate == pytest.approx(0.5)
    assert r.cash_costs == 1012.5 and r.time_cost_hours == 2.0
    assert r.quality.status == "fail" and any("needed correcting" in x for x in r.quality.reasons)
    assert r.decision == "fix quality first"  # a good outcome lift can't hide bad answers


def test_failed_acceptance_blocks_continue(tmp_path):
    r = run(write(tmp_path, BASIC, acceptance="2026-10-29,offer,o1,no,admin,missing price\n"))
    assert r.quality.status == "fail" and r.decision == "fix quality first"


def test_missing_acceptance_downgrades_continue(tmp_path):
    r = run(write(tmp_path, BASIC, acceptance=None))
    assert r.quality.status == "not checked" and r.outcomes.status == "continue" and r.decision == "extend"


def test_negative_economics_block_continue(tmp_path):
    r = run(write(tmp_path, BASIC, costs="2026-11-01,implementation,cash,5000,,\n"))
    assert r.economics.status == "negative" and r.decision == "change"
    assert r.observed_net_cash == pytest.approx(-5000)


def test_over_budget_blocks_continue(tmp_path):
    plan = PLAN.replace("min_acceptance_pct: 100}", "min_acceptance_pct: 100, max_effort_hours: 5}")
    r = run(write(tmp_path, BASIC, costs="2026-11-01,logging,time,,600,\n", plan=plan))
    assert r.economics.status == "over budget" and r.decision == "change"


def test_economics_unknown_before_renewals(tmp_path):
    plan = PLAN.replace("as_of: 2027-01-31", "as_of: 2026-11-25")
    r = run(write(tmp_path, BASIC, plan=plan))
    assert r.economics.status == "not yet known" and r.observed_revenue_difference is None


def test_not_enough_data(tmp_path):
    r = run(write(tmp_path, BASIC, plan=PLAN.replace("min_cohort: 2", "min_cohort: 20")))
    assert r.decision == "not enough data" and "at least 20 members" in r.outcomes.reasons[0]


def test_low_adoption_means_change(tmp_path):
    rows = BASIC.replace("p1,installed,2026-11-02,\n", "").replace("p2,installed,2026-11-05,\n", "")
    r = run(write(tmp_path, rows))
    assert r.outcomes.status == "change" and "installed the pack" in r.outcomes.reasons[0]


def test_no_lift_means_stop_or_change(tmp_path):
    rows = BASIC.replace("p1,first_outcome,2026-11-10,\n", "")
    assert run(write(tmp_path, rows)).decision == "stop or change"


def test_between_thresholds_means_extend(tmp_path):
    plan = PLAN.replace("continue_if_lift_pts: 10", "continue_if_lift_pts: 60")
    assert run(write(tmp_path, BASIC, plan=plan)).decision == "extend"


def test_as_of_defaults_to_latest_event(tmp_path):
    r = run(write(tmp_path, BASIC, plan=PLAN.replace("as_of: 2027-01-31\n", "")))
    assert r.as_of == "2026-12-01" and any("No as_of date" in w for w in r.warnings)


def test_log_problems_are_warnings(tmp_path):
    rows = BASIC + "x9,first_outcome,2026-11-02,\n,joined,2026-11-02,\np1,danced,2026-11-02,\n"
    r = run(write(tmp_path, rows))
    assert any("no 'joined' row" in w for w in r.warnings)
    assert any("needs a member and an event" in w for w in r.warnings)
    assert any("unknown event 'danced'" in w for w in r.warnings)


def test_bad_inputs(tmp_path):
    with pytest.raises(PilotError, match="must look like 2026-12-01"):
        run(write(tmp_path, "p1,joined,11/01/2026,\n"))
    with pytest.raises(PilotError, match="pilot plan not found"):
        load_plan(tmp_path / "nope.yaml")
    with pytest.raises(PilotError, match="'within_days' is required"):
        run(write(tmp_path, BASIC, plan="pilot_cohort: {joined_from: 2026-01-01, joined_to: 2026-01-02}\n"
                                        "baseline_cohort: {joined_from: 2026-01-01, joined_to: 2026-01-02}\n"))
    with pytest.raises(PilotError, match="joined_to is before joined_from"):
        run(write(tmp_path, BASIC, plan=PLAN.replace("joined_to: 2026-11-30", "joined_to: 2026-10-01")))
    path = write(tmp_path, BASIC)
    (tmp_path / "costs.csv").write_text("date,item\n", encoding="utf-8")
    with pytest.raises(PilotError, match="missing column"):
        run(path)
    (tmp_path / "costs.csv").write_bytes("date,item,kind,amount,minutes\n1,caf\xe9,cash,1,\n".encode("cp1252"))
    with pytest.raises(PilotError, match="UTF-8"):
        run(path)
    (tmp_path / "costs.csv").write_text("date,item,kind,amount,minutes\n1,x,cash,lots,\n", encoding="utf-8")
    with pytest.raises(PilotError, match="not a number"):
        run(path)
    (tmp_path / "costs.csv").write_text("date,item,kind,amount,minutes\n1,x,cash,-5,\n", encoding="utf-8")
    with pytest.raises(PilotError, match="can't be negative"):
        run(path)


def test_rate_interval():
    assert Rate(0, 0).pct is None and Rate(0, 0).interval() is None
    lo, hi = Rate(16, 40).interval()
    assert round(lo) == 26 and round(hi) == 55


def test_render_formats_report_three_areas_and_caveats(tmp_path):
    r = run(write(tmp_path, BASIC))
    md = render(r, "md")
    assert md.startswith("# Test pilot: pilot report") and "Data as of 2027-01-31." in md
    for heading in ("## 1. Product quality", "## 2. Member outcomes", "## 3. Economics"):
        assert heading in md
    assert "does not prove the member pack caused" in md and "capacity, not cash" in md
    assert "Completed tasks: offer 2, outreach 1" in md
    assert "**" not in render(r, "text")
    data = json.loads(render(r, "json"))
    assert data["outcome_pilot"]["pct"] == 50.0 and data["quality"]["status"] == "pass" and data["caveats"]


def test_sample_pilot_and_cli(tmp_path, capsys):
    shutil.copytree(SAMPLE, tmp_path / "s")
    assert main(["pilot", str(tmp_path / "s" / "pilot.yaml")]) == 0
    out = capsys.readouterr().out
    assert "Suggestion: CONTINUE" in out and "16/40 = 40%" in out and "9/38 = 24%" in out
    assert main(["pilot", str(tmp_path / "s" / "pilot.yaml"), "--format", "md", "-o", str(tmp_path / "r.md")]) == 0
    assert (tmp_path / "r.md").read_text() == (SAMPLE / "pilot-report.md").read_text()
    assert main(["pilot", str(tmp_path / "missing.yaml")]) == 2
    assert "pilot plan not found" in capsys.readouterr().err


def test_analyse_with_no_rows():
    d = date(2026, 1, 1)
    r = analyse({"within_days": 14, "pilot_cohort": (d, d), "baseline_cohort": (d, d), "as_of": d}, [], [], [])
    assert r.decision == "not enough data" and r.lift_pts is None and r.correction_pct is None
    assert "no data" in render(r, "md")


def test_pilot_import_adds_joined_rows_for_both_cohorts_without_contact_details(tmp_path):
    from skool_kit.cli import main
    from skool_kit.pilot import member_code
    plan = tmp_path / "pilot.yaml"
    plan.write_text("within_days: 14\nas_of: 2027-01-31\n"
                    "pilot_cohort: {joined_from: 2026-12-01, joined_to: 2026-12-31}\n"
                    "baseline_cohort: {joined_from: 2026-10-01, joined_to: 2026-10-31}\n")
    (tmp_path / "events.csv").write_text("member,event,date,note\n")
    export = tmp_path / "members.csv"
    export.write_text("Name,Email,Joined\nAna,ana@example.com,2026-12-03\nBo,bo@example.com,2026-10-20\n"
                      "Cy,cy@example.com,2026-11-15\n")
    assert main(["pilot-import", str(plan), str(export)]) == 0
    text = (tmp_path / "events.csv").read_text()
    assert "example.com" not in text and "Ana" not in text
    assert f"{member_code('ana@example.com')},joined,2026-12-03,\"pilot cohort" in text
    assert "baseline cohort" in text and text.count("joined") == 2   # November is in neither cohort
    assert main(["pilot-import", str(plan), str(export)]) == 0
    assert (tmp_path / "events.csv").read_text() == text            # running again adds nothing
