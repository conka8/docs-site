import csv
from pathlib import Path

import pytest
import yaml

from skool_kit.cli import main
from skool_kit.review import record_decision, report, review_submission

LAB = Path(__file__).resolve().parents[1] / "examples/agency-lab"
PACK = LAB / "member-pack"
SUBS = LAB / "review-eval/submissions"
TASK = yaml.safe_load((PACK / "review/rubric.yaml").read_text())["tasks"]["offer-builder"]


def flagged(name):
    rev = review_submission((SUBS / f"{name}.md").read_text(), "offer-builder", TASK["rubric"], TASK["label"])
    return {r.id: r for r in rev.results if r.status in ("missing", "uncertain")}, rev


@pytest.mark.parametrize("name,expected", [
    ("S1", set()),
    ("S2", {"monthly-floor", "setup-range"}),
    ("S3", {"no-guarantee", "pilot-metric"}),
    ("S4", {"headline-no-tools"}),
    ("S7", {"length", "monthly-founding-range"}),   # the range check was added after the first run found it
])
def test_planted_mechanical_defects_are_found_and_nothing_else(name, expected):
    found, _ = flagged(name)
    assert set(found) == expected


def test_missing_sections_dont_cause_false_price_flags():
    found, _ = flagged("S8")   # one paragraph, but the price and pilot follow the lessons
    assert found["sections"].status == "missing"
    assert "monthly-floor" not in found and "pilot-metric" not in found and "price-structure" not in found
    assert found["headline-no-tools"].status == "uncertain"


def test_invented_figures_are_listed_as_claims_and_judgement_goes_to_the_coach():
    _, rev = flagged("S6")
    assert any("£2,400" in c and "62%" in c for c in rev.claims)
    judged = {r.id for r in rev.results if r.status == "judge"}
    assert judged == {"one-niche", "problem-in-their-words"}


def test_review_draft_is_marked_unsent_and_quotes_lessons(tmp_path, capsys):
    log = tmp_path / "reviews.csv"
    out = tmp_path / "review.md"
    assert main(["review", str(SUBS / "S2.md"), "--pack", str(PACK), "--member", "Sam", "--log", str(log),
                 "-o", str(out)]) == 0
    text = out.read_text()
    assert text.startswith("# Review draft: offer-builder for Sam")
    assert "**DRAFT, not sent.**" in text
    assert "Hi Sam, thanks for posting your one-page offer." in text
    assert 'Raise the monthly fee to at least 300 (founding clients 300-500). *(Lesson: "Pricing your first offer": "Never go below 300 a month.")*' in text
    assert "[Coach: your view on:" in text
    row = list(csv.DictReader(log.open()))[0]
    assert row["method"] == "tool" and row["missing"] == "2" and row["decision"] == ""


def test_decisions_and_manual_reviews_feed_the_report(tmp_path):
    log = tmp_path / "reviews.csv"
    for i in range(5):
        record_decision(log, f"manual-{i}", "manual", 20 + i, method="manual", task="offer-builder")
    for i, name in enumerate(["S1", "S2", "S3", "S4", "S5"]):
        assert main(["review", str(SUBS / f"{name}.md"), "--pack", str(PACK), "--log", str(log), "-o",
                     str(tmp_path / f"{name}.md")]) == 0
        sub = list(csv.DictReader(log.open()))[-1]["submission"]
        assert main(["review-log", str(log), "--submission", sub, "--decision", "sent" if i < 3 else "edited",
                     "--minutes", "10", "--critical-missed", "1" if i == 4 else "0"]) == 0
    text = report(log)
    assert "Median coach minutes per review: manual 22, with draft 10" in text
    assert "Drafts sent with light wording only: 3 of 5; edited 2; rewritten 0" in text
    assert "Critical problems the draft missed (found by the coach): 1" in text
    assert "Change in median minutes: -55%" in text
    assert "not a controlled measurement" in text


def test_rubric_quotes_must_be_in_the_lesson(tmp_path):
    spec = yaml.safe_load((LAB / "pack.yaml").read_text())
    spec["classroom"] = str(LAB / "classroom")
    spec["playbooks"][0]["rubric"][0]["quote"] = "Sell two outcomes to every niche."
    for pb in spec["playbooks"]:
        if pb.get("example", {}).get("output_file"):
            pb["example"]["output_file"] = str(LAB / pb["example"]["output_file"])
        for c in pb.get("extra_cases") or []:
            if c.get("output_file"):
                c["output_file"] = str(LAB / c["output_file"])
    (tmp_path / "pack.yaml").write_text(yaml.safe_dump(spec))
    assert main(["pack-build", str(tmp_path / "pack.yaml"), "-o", str(tmp_path / "out")]) != 0
