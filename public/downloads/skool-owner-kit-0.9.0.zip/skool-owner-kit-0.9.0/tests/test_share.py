import shutil
import zipfile
from pathlib import Path

import pytest
import yaml

from skool_kit.classroom import SkillError
from skool_kit.cli import main
from skool_kit.share import share_pack

LAB = Path(__file__).parent.parent / "examples" / "agency-lab"
SKILLS = ["northwind-offer-builder", "northwind-outreach-sprint", "northwind-tutor"]


@pytest.fixture
def pack(tmp_path):
    dest = tmp_path / "member-pack"
    shutil.copytree(LAB / "member-pack", dest)
    return dest


def test_share_writes_one_kit_with_an_upload_zip_per_skill(pack, tmp_path, capsys):
    assert main(["pack-share", str(pack), "-o", str(tmp_path / "share"), "--version", "1.0.0"]) == 0
    out = capsys.readouterr().out
    assert "Send every member:" in out and "northwind-member-kit-1.0.0.zip" in out and "Keep to yourself" in out
    folder = tmp_path / "share" / "northwind-member-kit-1.0.0"
    assert sorted(p.name for p in folder.iterdir()) == ["START-HERE.md"] + [f"{s}.zip" for s in SKILLS]
    assert (folder / "START-HERE.md").read_text() == (pack / "MEMBER-START.md").read_text()
    for s in SKILLS:
        with zipfile.ZipFile(folder / f"{s}.zip") as zf:
            names = zf.namelist()
            # The Claude app wants the skill folder at the zip root, named like the skill.
            assert f"{s}/SKILL.md" in names and all(n.startswith(s + "/") for n in names)
            front = yaml.safe_load(zf.read(f"{s}/SKILL.md").decode().split("---")[1])
            assert front["name"] == s and len(front["description"]) <= 200
    with zipfile.ZipFile(tmp_path / "share" / "northwind-member-kit-1.0.0.zip") as zf:
        assert "northwind-member-kit-1.0.0/START-HERE.md" in zf.namelist()
    post = (tmp_path / "share" / "LAUNCH-POST.md").read_text()
    assert "northwind-member-kit-1.0.0.zip" in post and "draft" in post.lower()


def test_start_guide_matches_the_kit(pack):
    start = (pack / "MEMBER-START.md").read_text()
    for s in SKILLS:
        assert f"`{s}.zip`" in start and f"unzip -o {s}.zip -d ~/.claude/skills/" in start
    assert "Use the northwind-offer-builder skill. Which 1 to 3 niches" in start
    assert "verify before use" in start and "the skill can't post it for you" in start
    assert "/plugin" not in start


def test_share_ships_the_admins_edits_and_is_repeatable(pack, tmp_path):
    md = pack / "skills" / "northwind-tutor" / "SKILL.md"
    md.write_text(md.read_text() + "\nEdited by the admin.\n")
    share_pack(pack, tmp_path / "a", "1.0.1")
    share_pack(pack, tmp_path / "b", "1.0.1")
    a = (tmp_path / "a" / "northwind-member-kit-1.0.1" / "northwind-tutor.zip").read_bytes()
    assert a == (tmp_path / "b" / "northwind-member-kit-1.0.1" / "northwind-tutor.zip").read_bytes()
    with zipfile.ZipFile(tmp_path / "a" / "northwind-member-kit-1.0.1" / "northwind-tutor.zip") as zf:
        assert "Edited by the admin." in zf.read("northwind-tutor/SKILL.md").decode()


def test_share_refuses_unmerged_updates_and_bad_skills(pack, tmp_path):
    (pack / "skills" / "northwind-tutor" / "SKILL.md.new").write_text("x")
    with pytest.raises(SkillError, match="merge or delete"):
        share_pack(pack, tmp_path / "s", "1.0.0")
    (pack / "skills" / "northwind-tutor" / "SKILL.md.new").unlink()
    md = pack / "skills" / "northwind-tutor" / "SKILL.md"
    text = md.read_text()
    _, front, body = text.split("---", 2)
    meta = yaml.safe_load(front)
    meta["description"] = "Use when testing. " + "x" * 200
    md.write_text("---\n" + yaml.safe_dump(meta) + "---" + body)
    with pytest.raises(SkillError, match="Claude app accepts 200"):
        share_pack(pack, tmp_path / "s", "1.0.0")
    md.write_text(text.replace("name: northwind-tutor", "name: other-name", 1))
    with pytest.raises(SkillError, match="must match the folder name"):
        share_pack(pack, tmp_path / "s", "1.0.0")


def test_share_input_errors(pack, tmp_path, capsys):
    with pytest.raises(SkillError, match="1.0.0"):
        share_pack(pack, tmp_path / "s", "v1")
    with pytest.raises(SkillError, match="outside the pack"):
        share_pack(pack, pack / "share", "1.0.0")
    assert main(["pack-share", str(tmp_path / "nope"), "--version", "1.0.0"]) == 2
    assert "made by pack-build" in capsys.readouterr().err


def test_share_also_writes_the_same_pack_as_one_claude_project(pack, tmp_path, capsys):
    assert main(["pack-share", str(pack), "-o", str(tmp_path / "share"), "--version", "1.0.0"]) == 0
    assert "northwind-claude-project-1.0.0.zip" in capsys.readouterr().out
    project = tmp_path / "share" / "northwind-claude-project-1.0.0"
    knowledge = sorted(p.name for p in (project / "knowledge").iterdir())
    lessons = {p.name for p in pack.glob("skills/northwind-tutor/references/*/*.md")}
    assert lessons <= set(knowledge) and len(lessons) == 8
    assert [k for k in knowledge if k.startswith("task-")] == [f"task-{s}.md" for s in sorted(SKILLS)]
    instructions = (project / "INSTRUCTIONS.md").read_text()
    assert all(f"task-{s}.md" in instructions for s in SKILLS)
    guide = (project / "knowledge" / "task-northwind-offer-builder.md").read_text()
    # The guide is the reviewed SKILL.md body, with links pointing at the flat knowledge files.
    assert not guide.startswith("---") and "](references/" not in guide and "](examples/" not in guide
    assert "](pricing-your-first-offer.md)" in guide and "](northwind-offer-builder-example-output.md)" in guide
    assert "references/" not in (project / "knowledge" / "task-northwind-tutor.md").read_text()
    start = (project / "START-HERE.md").read_text()
    assert "INSTRUCTIONS.md" in start and "Use the northwind" not in start
    with zipfile.ZipFile(tmp_path / "share" / "northwind-claude-project-1.0.0.zip") as zf:
        assert "northwind-claude-project-1.0.0/knowledge/task-northwind-tutor.md" in zf.namelist()


def test_project_refuses_two_different_lessons_with_one_file_name(pack, tmp_path):
    clash = pack / "skills/northwind-outreach-sprint/references/outreach/the-follow-up-cadence.md"
    clash.write_text(clash.read_text() + "\nSend a third follow-up.\n")
    with pytest.raises(ValueError, match="the-follow-up-cadence.md"):
        share_pack(pack, tmp_path / "share", "1.0.0")


def test_one_format_only_with_a_matching_launch_post(pack, tmp_path, capsys):
    assert main(["pack-share", str(pack), "-o", str(tmp_path / "p"), "--version", "1.0.0", "--format", "project"]) == 0
    out = capsys.readouterr().out
    assert "Send every member:" in out and "northwind-claude-project-1.0.0.zip" in out
    assert sorted(x.name for x in (tmp_path / "p").iterdir()) == [
        "LAUNCH-POST.md", "northwind-claude-project-1.0.0", "northwind-claude-project-1.0.0.zip"]
    post = (tmp_path / "p" / "LAUNCH-POST.md").read_text()
    assert "Claude Project" in post and "paste the instructions" in post and "skills" not in post.lower()
    assert main(["pack-share", str(pack), "-o", str(tmp_path / "s"), "--version", "1.0.0", "--format", "skills"]) == 0
    assert not any("claude-project" in x.name for x in (tmp_path / "s").iterdir())
    assert main(["pack-share", str(pack), "-o", str(tmp_path / "b"), "--version", "1.0.0"]) == 0
    assert (tmp_path / "b" / "LAUNCH-POST-project.md").exists() and (tmp_path / "b" / "LAUNCH-POST.md").exists()
