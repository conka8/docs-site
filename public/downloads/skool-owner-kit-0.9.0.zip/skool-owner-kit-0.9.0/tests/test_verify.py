from pathlib import Path

import yaml

from skool_kit.citations import load_lessons
from skool_kit.cli import main
from skool_kit.verify import check_answer, render

LAB = Path(__file__).resolve().parents[1] / "examples/agency-lab"
PACK = LAB / "member-pack"
FIXTURES = LAB / "verification"
LESSONS = load_lessons([PACK])
CASES = {c["id"]: c for c in yaml.safe_load((PACK / "evals/acceptance.yaml").read_text())["cases"]}


def check(name, case=None):
    case = CASES[case] if case else None
    member = "\n".join([case["input"], *case.get("turns", [])]) if case else ""
    return check_answer((FIXTURES / f"{name}.md").read_text(), LESSONS, member, case)


def test_a_correct_answer_passes_every_deterministic_check():
    r = check("good-pricing")
    assert r.failures == []
    assert [c.exists for c in r.citations] == ["yes"] * 3
    assert all(c.qualification == "kept" for c in r.citations)


def test_a_real_quote_under_the_wrong_lesson_is_caught_separately_from_existence():
    (c,) = check("wrong-lesson").citations
    assert c.exists == "yes"
    assert "pricing your first offer" in c.right_lesson
    assert any("wrong lesson" in f for f in check("wrong-lesson").failures)


def test_a_quote_cut_before_its_qualification_is_caught():
    r = check("dropped-qualification", "offer-builder-dropped-qualification")
    (c,) = r.citations
    assert c.exists == "yes" and c.right_lesson == "yes"
    assert c.qualification == 'cut: "on results you don\'t control"'


def test_a_true_quote_used_for_the_wrong_conclusion_passes_the_machine_and_goes_to_a_person():
    # The limit of deterministic checking: everything checkable is fine, the conclusion is wrong.
    r = check("true-quote-wrong-conclusion", "offer-builder-true-quote-wrong-conclusion")
    assert r.failures == []
    assert any("permission to go below 300" in q for q in r.review)
    assert "person: does it support" in render(r)


def test_numbers_need_a_source_or_a_declared_assumption():
    r = check("unsourced-numbers")
    assert r.unsourced_numbers == ["£2,400", "40%", "£750"]
    assert r.assumed_numbers == ["£1,500"]
    assert any("Expect to sign 3 clients" in p for p in r.promises)


def test_numbers_the_member_gave_are_sourced():
    r = check_answer("You said £150 a month.", LESSONS, "I'll charge £150 a month")
    assert r.unsourced_numbers == []


def test_promises_are_flagged_unless_negated():
    r = check("promise")
    assert len(r.promises) == 1 and r.promises[0].startswith("We guarantee 20 new patients")


def test_every_acceptance_type_is_in_the_example_pack():
    for case in ("offer-builder-conflicting-input", "offer-builder-missing-facts",
                 "offer-builder-true-quote-wrong-conclusion", "offer-builder-dropped-qualification",
                 "offer-builder-not-covered-contract", "outreach-sprint-conflicting-lessons", "tutor-not-covered-1"):
        assert CASES[case]["pass_if"]
    assert CASES["offer-builder-conflicting-input"]["turns"]


def test_the_recorded_example_outputs_pass(tmp_path):
    for out, case in [("offer-builder-output", "offer-builder-example"),
                      ("offer-builder-conflict-output", "offer-builder-conflicting-input"),
                      ("outreach-sprint-output", "outreach-sprint-example")]:
        reply = (LAB / "examples" / f"{out}.md").read_text()
        case_ = CASES[case]
        assert check_answer(reply, LESSONS, "\n".join([case_["input"], *case_.get("turns", [])]), case_).failures == []


def test_cli_check_answer(tmp_path, capsys):
    report = tmp_path / "r.md"
    code = main(["check-answer", str(FIXTURES / "dropped-qualification.md"), "--pack", str(PACK),
                 "--case", "offer-builder-dropped-qualification", "-o", str(report)])
    assert code == 1
    text = report.read_text()
    assert "3. Qualification" in text and "For a person to decide" in text
    assert main(["check-answer", str(FIXTURES / "good-pricing.md"), "--pack", str(PACK)]) == 0
    assert main(["check-answer", str(FIXTURES / "good-pricing.md"), "--pack", str(PACK), "--case", "nope"]) != 0
