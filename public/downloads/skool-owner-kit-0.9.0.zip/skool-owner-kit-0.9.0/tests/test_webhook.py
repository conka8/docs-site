import json
import threading
import urllib.error
import urllib.request
from http.server import BaseHTTPRequestHandler, HTTPServer

import pytest

from skool_kit.members import parse_overrides
from skool_kit.webhook import WebhookConfig, check_secret, make_server, process_event

SECRET = "s3cret-value"


def post(url, data=None, headers=None, raw=None):
    body = raw if raw is not None else json.dumps(data).encode()
    req = urllib.request.Request(url, data=body, method="POST",
                                 headers={"Content-Type": "application/json", **(headers or {})})
    try:
        with urllib.request.urlopen(req, timeout=5) as r:
            return r.status, json.loads(r.read())
    except urllib.error.HTTPError as e:
        return e.code, json.loads(e.read() or b"{}")


@pytest.fixture
def serve():
    servers = []

    def start(config):
        server = make_server(config, "127.0.0.1", 0)
        t = threading.Thread(target=server.serve_forever, kwargs={"poll_interval": 0.02}, daemon=True)
        t.start()
        servers.append(server)
        return f"http://127.0.0.1:{server.server_address[1]}"

    yield start
    for s in servers:
        s.shutdown()
        s.server_close()


class Catcher(BaseHTTPRequestHandler):
    received = []
    status = 200

    def do_POST(self):  # noqa: N802
        n = int(self.headers.get("Content-Length") or 0)
        Catcher.received.append(json.loads(self.rfile.read(n)))
        self.send_response(Catcher.status)
        self.send_header("Content-Length", "2")
        self.end_headers()
        self.wfile.write(b"{}")

    def log_message(self, *a):
        pass


@pytest.fixture
def catcher():
    Catcher.received = []
    Catcher.status = 200
    server = HTTPServer(("127.0.0.1", 0), Catcher)
    t = threading.Thread(target=server.serve_forever, kwargs={"poll_interval": 0.02}, daemon=True)
    t.start()
    yield f"http://127.0.0.1:{server.server_address[1]}/hooks/catch"
    server.shutdown()
    server.server_close()


ZAP = {"first_name": "Ana", "last_name": "Lopez", "email": "ana@example.com",
       "answer_1": "I run a marketing agency", "answer_2": "first client please"}


def test_good_secret_header_writes_outbox(serve, tmp_path):
    outbox = tmp_path / "out" / "outbox.jsonl"
    logs = []
    base = serve(WebhookConfig(secret=SECRET, outbox=outbox, log=logs.append))
    status, data = post(base + "/", ZAP, {"X-Skool-Kit-Secret": SECRET})
    assert status == 200 and data["ok"] is True
    assert data["segment"] == "agency-owner" and data["goal"] == "first-client"
    assert data["message"].startswith("Hey Ana, welcome")
    assert data["forwarded"] is False
    lines = outbox.read_text().splitlines()
    assert len(lines) == 1 and json.loads(lines[0])["email"] == "ana@example.com"
    assert any("new member ana@example.com" in line for line in logs)
    # second event appends
    post(base + "/new-member", {"email": "b@x.com"}, {"X-Skool-Kit-Secret": SECRET})
    assert len(outbox.read_text().splitlines()) == 2


def test_secret_in_query_param_is_not_logged(serve, tmp_path):
    logs = []
    base = serve(WebhookConfig(secret=SECRET, outbox=tmp_path / "o.jsonl", log=logs.append))
    status, data = post(base + f"/?secret={SECRET}", ZAP)
    assert status == 200 and data["first_name"] == "Ana"
    assert any("?secret=***" in line for line in logs)
    assert not any(SECRET in line for line in logs)


@pytest.mark.parametrize("headers,query", [({}, ""), ({"X-Skool-Kit-Secret": "wrong"}, ""), ({}, "?secret=nope")])
def test_bad_secret_401(serve, tmp_path, headers, query):
    outbox = tmp_path / "o.jsonl"
    base = serve(WebhookConfig(secret=SECRET, outbox=outbox))
    status, data = post(base + "/" + query, ZAP, headers)
    assert status == 401 and data == {"ok": False, "error": "bad or missing secret"}
    assert not outbox.exists()


def test_bad_json_and_bad_payloads(serve, tmp_path):
    base = serve(WebhookConfig(secret=SECRET, outbox=tmp_path / "o.jsonl"))
    h = {"X-Skool-Kit-Secret": SECRET}
    assert post(base + "/", raw=b"{not json", headers=h) == (400, {"ok": False, "error": "body is not valid JSON"})
    assert post(base + "/", raw=b"\xff\xfe", headers=h)[0] == 400
    status, data = post(base + "/", [1, 2], h)
    assert status == 400 and "JSON object" in data["error"]
    status, data = post(base + "/", {"favourite_colour": "blue"}, h)
    assert status == 400 and "no name or email" in data["error"]
    assert post(base + "/elsewhere", ZAP, h)[0] == 404


def test_form_encoded_and_health(serve, tmp_path):
    base = serve(WebhookConfig(secret=SECRET, outbox=None))
    body = b"name=Raj+Patel&email=raj%40x.com&question_1=I+want+to+get+hired"
    status, data = post(base + "/", raw=body, headers={"X-Skool-Kit-Secret": SECRET,
                                                        "Content-Type": "application/x-www-form-urlencoded"})
    assert status == 200 and data["segment"] == "job-seeker"
    with urllib.request.urlopen(base + "/health", timeout=5) as r:
        assert json.loads(r.read()) == {"ok": True}
    with pytest.raises(urllib.error.HTTPError) as info:
        urllib.request.urlopen(base + "/other", timeout=5)
    assert info.value.code == 404


def test_custom_header_and_field_map(serve, tmp_path):
    cfg = WebhookConfig(secret=SECRET, outbox=tmp_path / "o.jsonl", secret_header="X-Zap-Key",
                        field_map=parse_overrides(["What do you do=answers", "Member Email=email"]))
    base = serve(cfg)
    status, data = post(base + "/", {"Member Email": "q@x.com", "What do you do": "python developer"},
                        {"X-Zap-Key": SECRET})
    assert status == 200 and data["email"] == "q@x.com" and data["segment"] == "developer"


def test_forwarding_to_second_local_server(serve, tmp_path, catcher):
    base = serve(WebhookConfig(secret=SECRET, outbox=tmp_path / "o.jsonl", forward_url=catcher))
    status, data = post(base + "/", ZAP, {"X-Skool-Kit-Secret": SECRET})
    assert status == 200 and data["forwarded"] is True
    assert Catcher.received[0]["email"] == "ana@example.com"
    assert Catcher.received[0]["message"] == data["message"]
    saved = json.loads((tmp_path / "o.jsonl").read_text())
    assert saved["forwarded"] is True


def test_forwarding_failure_still_200(serve, tmp_path, catcher):
    Catcher.status = 500
    base = serve(WebhookConfig(secret=SECRET, outbox=tmp_path / "o.jsonl", forward_url=catcher))
    status, data = post(base + "/", ZAP, {"X-Skool-Kit-Secret": SECRET})
    assert status == 200 and data["forwarded"] is False and data["forward_error"] == "HTTP 500"


def test_forwarding_unreachable(tmp_path):
    srv = HTTPServer(("127.0.0.1", 0), Catcher)
    port = srv.server_address[1]
    srv.server_close()
    cfg = WebhookConfig(secret=SECRET, outbox=None, forward_url=f"http://127.0.0.1:{port}/x", forward_timeout=2)
    rec = process_event(ZAP, cfg)
    assert rec["forwarded"] is False and "could not reach" in rec["forward_error"]


def test_process_event_with_fake_forward_transport(tmp_path):
    sent = []
    cfg = WebhookConfig(secret=SECRET, outbox=tmp_path / "o.jsonl", forward_url="https://hooks.zapier.com/x",
                        forward_transport=lambda url, h, body, t: (sent.append((url, json.loads(body))) or (200, b"")))
    rec = process_event({"name": "Kim", "answers": "I own a restaurant"}, cfg)
    assert rec["forwarded"] and sent[0][0] == "https://hooks.zapier.com/x"
    assert rec["segment"] == "business-owner"


def test_outbox_write_error_returns_500(serve, tmp_path):
    blocker = tmp_path / "file"
    blocker.write_text("x")
    base = serve(WebhookConfig(secret=SECRET, outbox=blocker / "o.jsonl"))
    status, data = post(base + "/", ZAP, {"X-Skool-Kit-Secret": SECRET})
    assert status == 500 and "outbox" in data["error"]


def test_body_too_large(serve, tmp_path):
    base = serve(WebhookConfig(secret=SECRET, outbox=None))
    req = urllib.request.Request(base + "/", data=b"{}", method="POST",
                                 headers={"X-Skool-Kit-Secret": SECRET, "Content-Length": "5000000"})
    # we only send 2 bytes but claim 5 MB: the server must refuse without reading
    try:
        urllib.request.urlopen(req, timeout=5)
        code = 200
    except urllib.error.HTTPError as e:
        code = e.code
    except urllib.error.URLError:
        code = 413  # some platforms reset the connection after the early reply
    assert code == 413


def test_check_secret_and_server_requires_secret():
    assert check_secret(WebhookConfig(secret=""), {}, {}) is False
    assert check_secret(WebhookConfig(secret="a"), {"X-Skool-Kit-Secret": "a"}, {}) is True
    with pytest.raises(ValueError, match="secret is required"):
        make_server(WebhookConfig(secret=""), "127.0.0.1", 0)


def test_handler_drops_stalled_clients():
    from skool_kit.webhook import REQUEST_TIMEOUT, make_handler
    assert make_handler(WebhookConfig(secret="s")).timeout == REQUEST_TIMEOUT > 0
