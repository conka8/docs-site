# vertical-packs (`vpacks`)

Small, concrete "agent packs" for niche business communities. Each pack is a calculator or checker
you can run from the command line, plus a Claude skill (`skills/*/SKILL.md`) that tells Claude how to
run it and how to explain the results in plain English. Free, open source (MIT), no API keys, works offline.

| Pack | Who it's for | Commands |
| --- | --- | --- |
| `str` | Airbnb / short-term rental hosts | `listing`, `revenue`, `message` |
| `pm` | Landlords, property managers | `triage` (one request or a CSV queue) |
| `rei` | Real estate investors | `rental`, `flip`, `brrrr` |
| `freight` | Freight brokers, small carriers | `load`, `carrier` |
| `kdp` | Self-published authors | `check` |

Every command takes `--format text|json|md` (text for the terminal, `md` to paste into Skool/Notion/Docs,
`json` for automations). Bad input gets a clear message and exit code 2.

## Install

Needs Python 3.10+. No other dependencies.

```bash
git clone <this repo> && cd vertical-packs
pip install .            # gives you the `vpacks` command
# or, without installing:
PYTHONPATH=src python -m vpacks --help
```

### Use it with Claude

Copy a folder from `skills/` (e.g. `skills/vpacks-rei`) into your Claude skills folder
(`~/.claude/skills/` for Claude Code, or upload it as a skill in Claude). Then just ask:
"Analyze this rental: 200k, 20% down, 6%, rent 2,000..." and Claude runs the tool for you.

## Quickstart (one command per pack)

All example inputs are in `examples/`.

```bash
# Short-term rental
vpacks str listing examples/str/listing.json
vpacks str revenue --input examples/str/revenue.json --format md
vpacks str revenue --adr 185 --occupancy-pct 62 --cleaning-fee 95 --cleaning-cost 75 --monthly-costs "mortgage=1650,utilities=280"
vpacks str message --type checkin --data examples/str/guest.json      # also: checkout, review-request, issue

# Property maintenance
vpacks pm triage --text "No leak, but I smell gas near the stove" --emergency-phone "555-0100"
vpacks pm triage examples/pm/request.txt --outdoor-temp-f 18
vpacks pm triage --csv examples/pm/requests.csv --format md

# Real estate investors
vpacks rei rental --input examples/rei/rental.json
vpacks rei rental --purchase-price 300000 --down-payment-pct 0 --interest-rate-pct 7 --monthly-rent 2500
vpacks rei flip --input examples/rei/flip.json
vpacks rei brrrr --input examples/rei/brrrr.json

# Freight
vpacks freight load --input examples/freight/load.json
vpacks freight carrier examples/freight/carrier.json --as-of 2026-10-28

# Authors
vpacks kdp check examples/kdp/book.json
vpacks kdp check examples/kdp/book-clean.json --strict    # exit code 1 if there are errors
```

Numeric commands take inputs from `--input file.json`, from flags (`--purchase-price 200000`), or both
(flags win). Percentages are whole numbers: `7` means 7%. Run any command with `--help` to see every
field and its default.

## Example output

```text
$ vpacks rei rental --input examples/rei/rental.json
Rental property analysis
========================

Financing
---------
Loan amount          $160,000.00
Down payment         $40,000.00
Monthly P&I          $959.28
Total cash invested  $45,000.00
...
Returns & ratios
----------------
NOI (annual)        $14,400.00
Cash flow (annual)  $2,888.63
Cap rate            7.20%
Cash-on-cash        6.42%
DSCR                1.25
GRM                 8.33
1% rule             1.00% -> pass
50% rule cash flow  $40.72 -> pass
```

```text
$ vpacks pm triage --text "No leak, but I smell gas near the stove" --emergency-phone 555-0100
EMERGENCY maintenance request
=============================

Summary
-------
Category            plumbing (also: appliance)
Urgency             EMERGENCY
Emergency type      gas smell
Call 911 first      YES
...
Tell the tenant now
-------------------
- Leave the home now. Don't flip light switches, light flames or use your phone inside. From outside, call 911 and the gas company's emergency line.
- Once you are safe, call our emergency maintenance line: 555-0100.
```

```text
$ vpacks freight load --input examples/freight/load.json
Load check: GO
...
Deadhead-adjusted RPM  $2.27
Fuel                   $676.92 (169.2 gal)
Profit                 $1,113.08
Broker margin          $400.00 (13.79%)
```

## What each pack does

**str listing** scores a listing out of 100: title (Airbnb's 50-character limit), description length and
topics (beds, location, arrival/parking), photo count, key amenities for the market type (beach, mountain,
lake, urban, rural, desert, general), response rate, rating and review count. Returns prioritized fixes.

**str revenue** builds a 12-month P&L from nightly rate, occupancy, average stay, cleaning fee/cost,
platform and management fees, owner-blocked nights, seasonality and fixed monthly costs. Gives annual net,
average monthly net and break-even occupancy.

**str message** writes check-in, checkout, review-request and issue messages. Missing details become
`[placeholders]` and are listed so the host fills them in.

**pm triage** is keyword-based triage; it always escalates when unsure. It sorts a request into plumbing,
electrical, HVAC, appliance, pest, lockout, structural or other; sets urgency (emergency / urgent / routine);
flags emergencies (gas smell, flooding or anything that burst, no water, no heat in freezing weather,
sparks/fire/smoke/burning smell, carbon monoxide alarm or CO with symptoms, security breach, collapse) with
safety instructions and a "call 911" flag; lists vendor types, questions to ask, and a response target.
Any mention of carbon monoxide or a CO alarm, a smoke alarm, gas with a smell, a major leak, exposed wires
or a shock is at least URGENT and marked "needs a human to review now", even when the tenant says it isn't
happening ("I don't smell gas anymore"). Plain negations like "no leak" are ignored. Handles requests with
several problems. `--csv` triages a whole queue, most urgent first.

**rei rental** mortgage payment (standard amortization), NOI, cap rate, cash-on-cash, DSCR, GRM, 1% rule,
50% rule, cash flow, with vacancy/capex/repairs/management percentages.
**rei flip** max allowable offer (70% rule), holding, financing (points + interest-only), selling costs,
profit, ROI and simple annualized ROI.
**rei brrrr** refinance at LTV, cash out, cash left in the deal, infinite-return flag, post-refi cash flow.

**freight load** RPM, deadhead-adjusted RPM, fuel cost from mpg and price, driver pay (per mile and/or %),
total cost, profit, broker margin (if you enter the shipper rate) and a GO / NO-GO against your minimum RPM.
**freight carrier** vetting checklist and 0-100 risk score from what you collected: authority status and age,
insurance vs. minimums, safety rating, out-of-service rates vs. national averages, and double-brokering red
flags (email domain mismatch, free email, phone not matching FMCSA, recent phone change, payee mismatch).

**kdp check** title + subtitle length, 7 keyword slots and 50-character limit, risky keyword terms (other
authors, brands, "bestseller", "free", "Kindle Unlimited"), duplicate keywords and keywords repeating title
words, description length and allowed HTML tags, category count, and series consistency.

## Limits (please read)

- **Verify every platform limit against current guidelines.** Limits live in one constants dict per pack:
  `STR_LIMITS` (Airbnb title 50 chars, default 3% host fee), `KDP_LIMITS` (200 / 7 x 50 / 4000 / 3 categories,
  allowed HTML tags), `CARRIER_RULES` (insurance minimums, FMCSA national OOS averages), `SLA` (maintenance
  response targets). Platforms change these; the values are what was published at time of writing.
- No external lookups: `freight carrier` doesn't query FMCSA/SAFER; you type in what the record shows.
- Listing scores and maintenance triage are rule-based heuristics, not machine learning. Triage matches
  keywords and can miss unusual wording, so anything it can't classify is marked "needs human review", and
  any danger word escalates to at least URGENT. Always read the tenant's own words. It is not a substitute
  for calling 911 or for your local landlord-tenant law.
- Financial results are screening estimates, not financial, tax or legal advice. Lenders may limit
  cash-out refinances; occupancy taxes are assumed to be passed through to guests.
- Division by zero (no loan, $0 price, 0 miles, 0 months) returns `n/a` / `null` with a note explaining why.

## Development

```bash
cd vertical-packs && ../.venv/bin/python -m pytest -q
```

Layout: `src/vpacks/` (`common.py` validation + output, one module per pack, `cli.py`), `tests/`,
`skills/`, `examples/`.

## License

MIT, see `LICENSE`.
