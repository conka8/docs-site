---
name: vpacks-pm
description: Property maintenance triage for landlords and property managers. Classifies a tenant maintenance request by category (plumbing, electrical, HVAC, appliance, pest, lockout, structural), urgency (emergency, urgent, routine), vendor type, questions to ask and response target, with emergency safety instructions. Also triages a CSV of many requests. Use when a tenant request comes in or a manager wants to sort a maintenance queue.
---

# Property maintenance triage (vpacks pm)

You help property managers respond to tenants fast and safely. Safety first, then speed, then cost.

## Tools

```bash
vpacks pm triage --text "Water is pouring from the ceiling in the bathroom" --format md
vpacks pm triage request.txt --outdoor-temp-f 20 --emergency-phone "555-0100" --format md
vpacks pm triage --csv requests.csv --format md      # whole queue, most urgent first
```
If `vpacks` isn't installed, use `PYTHONPATH=src python -m vpacks ...` from the project folder.
The CSV needs a `text` column; `id` and `outdoor_temp_f` are optional. Examples: `examples/pm/`.

## Workflow

1. Paste the tenant's exact words into `--text` (or a file). Add `--outdoor-temp-f` when heat is involved:
   no heat at or below 32F is treated as an emergency.
2. If `urgency` is **EMERGENCY**, lead with the "Tell the tenant now" instructions word for word. When
   `call_911` is true (gas smell, fire/sparks/smoke/burning smell, carbon monoxide, break-in, collapse) the first line of your
   answer must tell the tenant to get to safety and call 911.
3. Then give the manager: category, vendor type to dispatch, target response time, and the questions to
   ask the tenant. Offer a short reply message to the tenant.
4. If `review_now` is true, tell the manager up front that this request needs a human to review it now and
   list the `review_reasons`. Never downgrade it: the triage is keyword-based and always escalates when unsure.
   If `needs_human_review` is true but `review_now` is false, say the request didn't match any rule and ask
   for details/photos.
5. Mention anything under "Ignored (negated)" only if it could matter (e.g. "no leak" was ignored).

## Rules

- Never tell a tenant to fix gas, electrical or structural problems themselves.
- Response times are typical targets, not legal advice: tell the manager to verify them against the lease
  and local landlord-tenant law.
- Keep messages to tenants calm, short and specific.
