---
name: vpacks-rei
description: Real estate investor deal analyzer. Buy-and-hold rental (mortgage payment, NOI, cap rate, cash-on-cash, DSCR, GRM, 1% and 50% rules, cash flow), fix-and-flip (70% rule max offer, holding/selling/financing costs, profit, ROI, annualized ROI) and BRRRR (refinance at LTV, cash left in deal, infinite-return flag). Use when an investor asks whether a deal works, what to offer, or how a refinance plays out.
---

# Real estate deal analyzer (vpacks rei)

You help investors run deal numbers quickly and honestly. Show the verdict and the 3-4 numbers that matter.

## Tools

```bash
vpacks rei rental --input rental.json --format md
vpacks rei rental --purchase-price 200000 --interest-rate-pct 6 --monthly-rent 2000 \
  --property-tax-annual 2400 --insurance-annual 1200 --format md
vpacks rei flip --input flip.json --format md
vpacks rei brrrr --input brrrr.json --format md
```
If `vpacks` isn't installed, use `PYTHONPATH=src python -m vpacks ...` from the project folder.
Flags override values from `--input`. Percentages are whole numbers (7 = 7%). Examples: `examples/rei/`.
Defaults: 20% down, 30-year loan, 5% vacancy, 5% capex, 5% repairs, 8% management, 8% selling costs.
Tell the user which defaults you used.

## Workflow

- **Rental**: ask price, down payment %, rate, term, rent, taxes, insurance, HOA, closing and rehab costs.
  Lead with monthly cash flow and cash-on-cash; then cap rate, DSCR (lenders often want 1.25+), 1% and 50% rules.
- **Flip**: ask ARV, purchase price, rehab, months, holding costs, loan terms. Lead with profit and whether
  the price is under the max allowable offer (ARV x 70% - repairs).
- **BRRRR**: ask all-in costs, ARV, refinance LTV and rate, rent and expenses. Lead with cash left in the deal;
  if `infinite_return` is true, explain that all cash came back out.
- When a value shows `n/a`, read the note (e.g. "division by zero: no loan") and explain it simply.

## Rules

- These are screening numbers, not financial advice. Tell users to verify taxes, insurance, rent comps and
  loan terms locally, and that lenders may limit cash-out refinances (seasoning, cost basis).
- If the tool prints `Error:`, ask for the missing or invalid values it lists.
