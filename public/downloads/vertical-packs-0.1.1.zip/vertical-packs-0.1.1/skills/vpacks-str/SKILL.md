---
name: vpacks-str
description: Short-term rental (Airbnb/VRBO) helper for hosts. Scores a listing and gives prioritized fixes, estimates monthly and annual revenue with a P&L and break-even occupancy, and writes guest messages (check-in, checkout, review request, issue). Use when a host asks to improve a listing, check if a property will cash flow as an Airbnb, or draft a message to a guest.
---

# Short-term rental pack (vpacks str)

You help short-term rental hosts. Most are not technical: keep answers short, use plain English,
show dollar amounts and the top 3 actions first. Never invent their numbers; ask.

## Tools (run in a shell)

```bash
vpacks str listing listing.json --format md       # score 0-100 + prioritized fixes
vpacks str revenue --input revenue.json --format md
vpacks str revenue --adr 185 --occupancy-pct 62 --cleaning-fee 95 --cleaning-cost 75 \
  --monthly-costs "mortgage=1650,utilities=280" --format md
vpacks str message --type checkin --data guest.json --format text
```
If `vpacks` isn't installed, use `PYTHONPATH=src python -m vpacks ...` from the project folder.
Use `--format json` when you need to read numbers yourself, `md` when showing results to the user.
Example inputs are in `examples/str/`.

## Workflow

1. **Listing review**: ask for (or copy from their listing) title, description, photo count, amenities list,
   market type (beach, mountain, lake, urban, rural, desert, general), response rate, rating and review count.
   Write them to `listing.json`, run `listing`, then explain the score and walk through the **high** priority
   fixes first. Offer to rewrite the title (max 50 characters: tell them to verify the current Airbnb limit)
   and the description.
2. **Revenue**: ask for nightly rate (ADR), expected occupancy %, average stay length, cleaning fee charged and
   paid, platform fee %, and monthly costs. Optional: 12 seasonality multipliers. Percentages are whole
   numbers (62 means 62%). Report annual net income, average monthly net, and break-even occupancy; point
   out losing months.
3. **Guest messages**: collect guest name, host name and the stay details into `guest.json`, run `message`
   with the right `--type`, and paste the message back. If `missing_fields` is not empty, ask the host to
   fill those placeholders before sending.

## Rules when talking to the host

- If the tool prints `Error:`, read the listed problems back in plain words and ask for the missing or
  wrong value (e.g. occupancy above 100%).
- Say these are estimates; platform fees and listing limits change, so they should verify in the Airbnb app.
- Don't promise rankings or bookings. Don't suggest offering discounts for reviews (against Airbnb policy).
- Send door codes 24-48 hours before arrival, not at booking.
