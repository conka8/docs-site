"""vpacks: small, concrete agent packs (calculators + Claude skills) for niche communities."""

__version__ = "0.1.1"
