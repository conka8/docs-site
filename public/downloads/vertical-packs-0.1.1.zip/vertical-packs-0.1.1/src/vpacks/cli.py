"""Command line: vpacks <pack> <command> [options]."""
from __future__ import annotations

import argparse
import sys
from datetime import date
from typing import Sequence

from . import __version__, freight, kdp, pm, rei, str_pack
from .common import FORMATS, Field, ValidationError, emit, load_json_file, read_text_file


def _fmt(p: argparse.ArgumentParser) -> None:
    p.add_argument("--format", choices=FORMATS, default="text", help="output format (default: text)")


def _add_fields(p: argparse.ArgumentParser, fields: Sequence[Field]) -> None:
    p.add_argument("--input", "-i", metavar="FILE.json", help="read inputs from a JSON file; flags override it")
    for f in fields:
        hint = f.help or f.name.replace("_", " ")
        if f.default not in (None, "") and not callable(f.default):
            hint += f" (default {f.default:g})" if isinstance(f.default, float) else f" (default {f.default})"
        p.add_argument(f.flag, dest=f.name, metavar="X", default=None, help=hint.replace("%", "%%"))


def _collect(args: argparse.Namespace, fields: Sequence[Field]) -> dict:
    data = load_json_file(args.input) if args.input else {}
    if not isinstance(data, dict):
        raise ValidationError(f"{args.input} must contain a JSON object (curly braces).")
    for f in fields:
        value = getattr(args, f.name, None)
        if value is not None:
            data[f.name] = value
    return data


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="vpacks",
        description="Small calculators and checkers for niche businesses: short-term rentals (str), property "
                    "maintenance (pm), real estate investing (rei), freight brokerage (freight) and authors (kdp).",
    )
    parser.add_argument("--version", action="version", version=f"vpacks {__version__}")
    packs = parser.add_subparsers(dest="pack", metavar="PACK")
    packs.required = True

    # str
    p_str = packs.add_parser("str", help="short-term rental (Airbnb) tools")
    s = p_str.add_subparsers(dest="command", metavar="COMMAND")
    s.required = True
    c = s.add_parser("listing", help="score a listing and list fixes")
    c.add_argument("file", help="listing JSON file")
    _fmt(c)
    c = s.add_parser("revenue", help="estimate revenue, P&L and break-even occupancy")
    _add_fields(c, str_pack.REVENUE_FIELDS)
    _fmt(c)
    c = s.add_parser("message", help="write a guest message")
    c.add_argument("--type", required=True, choices=str_pack.MESSAGE_TYPES)
    c.add_argument("--data", required=True, metavar="FILE.json", help="guest/stay details JSON")
    _fmt(c)

    # pm
    p_pm = packs.add_parser("pm", help="property maintenance tools")
    s = p_pm.add_subparsers(dest="command", metavar="COMMAND")
    s.required = True
    c = s.add_parser("triage", help="classify a tenant maintenance request (or a CSV of them)")
    c.add_argument("file", nargs="?", help="text file with the tenant's request ('-' for stdin)")
    c.add_argument("--text", help="the request text, in quotes")
    c.add_argument("--csv", metavar="FILE.csv", help="batch mode: CSV with a 'text' column (optional id, outdoor_temp_f)")
    c.add_argument("--outdoor-temp-f", type=float, default=None, help="outside temperature in F (no heat at <=32F is an emergency)")
    c.add_argument("--emergency-phone", default=None, help="your 24/7 emergency line, shown to the tenant")
    _fmt(c)

    # rei
    p_rei = packs.add_parser("rei", help="real estate investor deal analyzers")
    s = p_rei.add_subparsers(dest="command", metavar="COMMAND")
    s.required = True
    for name, fields, helptext in (("rental", rei.RENTAL_FIELDS, "buy-and-hold rental analysis"),
                                   ("flip", rei.FLIP_FIELDS, "fix-and-flip analysis"),
                                   ("brrrr", rei.BRRRR_FIELDS, "buy-rehab-rent-refinance analysis")):
        c = s.add_parser(name, help=helptext)
        _add_fields(c, fields)
        _fmt(c)

    # freight
    p_fr = packs.add_parser("freight", help="freight brokerage / carrier tools")
    s = p_fr.add_subparsers(dest="command", metavar="COMMAND")
    s.required = True
    c = s.add_parser("load", help="load profitability and go/no-go")
    _add_fields(c, freight.LOAD_FIELDS)
    _fmt(c)
    c = s.add_parser("carrier", help="carrier vetting checklist and risk score")
    c.add_argument("file", help="carrier JSON file")
    c.add_argument("--as-of", default=None, metavar="YYYY-MM-DD", help="date to compute authority age (default today)")
    _fmt(c)

    # kdp
    p_kdp = packs.add_parser("kdp", help="Amazon KDP book metadata checks")
    s = p_kdp.add_subparsers(dest="command", metavar="COMMAND")
    s.required = True
    c = s.add_parser("check", help="check title, keywords, description, categories, series")
    c.add_argument("file", help="book JSON file")
    c.add_argument("--strict", action="store_true", help="exit with code 1 if there are errors")
    _fmt(c)
    return parser


def _run(args: argparse.Namespace) -> tuple[str, int]:
    fmt = args.format
    key = (args.pack, args.command)
    if key == ("str", "listing"):
        res = str_pack.score_listing(load_json_file(args.file))
        return emit(res, str_pack.listing_report(res), fmt), 0
    if key == ("str", "revenue"):
        res = str_pack.estimate_revenue(_collect(args, str_pack.REVENUE_FIELDS))
        return emit(res, str_pack.revenue_report(res), fmt), 0
    if key == ("str", "message"):
        res = str_pack.guest_message(args.type, load_json_file(args.data))
        return emit(res, str_pack.message_report(res), fmt), 0
    if key == ("pm", "triage"):
        sources = [x for x in (args.file, args.text, args.csv) if x is not None]
        if len(sources) != 1:
            raise ValidationError("Give exactly one of: a request file, --text \"...\", or --csv FILE.csv.")
        if args.csv:
            res = pm.triage_csv(read_text_file(args.csv), emergency_phone=args.emergency_phone)
            return emit(res, pm.batch_report(res), fmt), 0
        text = args.text if args.text is not None else (
            sys.stdin.read() if args.file == "-" else read_text_file(args.file))
        res = pm.triage(text, outdoor_temp_f=args.outdoor_temp_f, emergency_phone=args.emergency_phone)
        return emit(res, pm.triage_report(res), fmt), 0
    if args.pack == "rei":
        fn, rep, fields = {"rental": (rei.analyze_rental, rei.rental_report, rei.RENTAL_FIELDS),
                           "flip": (rei.analyze_flip, rei.flip_report, rei.FLIP_FIELDS),
                           "brrrr": (rei.analyze_brrrr, rei.brrrr_report, rei.BRRRR_FIELDS)}[args.command]
        res = fn(_collect(args, fields))
        return emit(res, rep(res), fmt), 0
    if key == ("freight", "load"):
        res = freight.analyze_load(_collect(args, freight.LOAD_FIELDS))
        return emit(res, freight.load_report(res), fmt), 0
    if key == ("freight", "carrier"):
        as_of = None
        if args.as_of:
            try:
                as_of = date.fromisoformat(args.as_of)
            except ValueError:
                raise ValidationError(f"--as-of must be a date like 2026-01-31 (got {args.as_of!r}).") from None
        res = freight.vet_carrier(load_json_file(args.file), as_of=as_of)
        return emit(res, freight.carrier_report(res), fmt), 0
    if key == ("kdp", "check"):
        res = kdp.check_book(load_json_file(args.file))
        return emit(res, kdp.kdp_report(res), fmt), (1 if args.strict and not res["ok"] else 0)
    raise ValidationError(f"Unknown command: {args.pack} {args.command}")  # pragma: no cover


def main(argv: Sequence[str] | None = None) -> int:
    parser = build_parser()
    try:
        args = parser.parse_args(argv)
    except SystemExit as exc:  # argparse prints its own message
        return int(exc.code or 0)
    try:
        output, code = _run(args)
    except ValidationError as exc:
        print("Error: please fix the input and try again.", file=sys.stderr)
        for problem in exc.problems:
            print(f"  - {problem}", file=sys.stderr)
        return 2
    sys.stdout.write(output)
    return code


if __name__ == "__main__":  # pragma: no cover
    sys.exit(main())
