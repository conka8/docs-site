"""Shared helpers: input validation, safe math, and text / markdown / JSON output."""
from __future__ import annotations

import difflib
import json
import math
from dataclasses import dataclass
from datetime import date
from pathlib import Path
from typing import Any, Iterable, Sequence

FORMATS = ("text", "json", "md")


class ValidationError(ValueError):
    """Bad user input. Carries a list of plain-English problems."""

    def __init__(self, problems: str | Iterable[str]):
        if isinstance(problems, str):
            problems = [problems]
        self.problems = list(problems)
        super().__init__("\n".join(self.problems))


@dataclass(frozen=True)
class Field:
    """One input value of a calculator.

    kind: float | int | pct | str | bool | date | count | floatlist | strlist | moneydict
    min/max: allowed range for numbers (pct defaults to 0..100).
    """

    name: str
    kind: str = "float"
    required: bool = False
    default: Any = None
    min: float | None = 0.0
    max: float | None = None
    help: str = ""

    @property
    def flag(self) -> str:
        return "--" + self.name.replace("_", "-")


def _n(x: float) -> str:
    return f"{x:,.10g}" if abs(x) >= 1000 else f"{x:.10g}"


def _to_number(raw: Any) -> float:
    if isinstance(raw, bool):
        raise ValueError("must be a number, not true/false")
    if isinstance(raw, (int, float)):
        value = float(raw)
    elif isinstance(raw, str):
        cleaned = raw.strip().replace(",", "").replace("$", "").rstrip("%").strip()
        try:
            value = float(cleaned)
        except ValueError:
            raise ValueError(f"must be a number (got {raw!r})") from None
    else:
        raise ValueError(f"must be a number (got {type(raw).__name__})")
    if math.isnan(value) or math.isinf(value):
        raise ValueError("must be a finite number")
    return value


def _convert(f: Field, raw: Any) -> Any:
    kind = f.kind
    if kind in ("float", "pct"):
        return _to_number(raw)
    if kind == "int":
        value = _to_number(raw)
        if value != int(value):
            raise ValueError(f"must be a whole number (got {raw!r})")
        return int(value)
    if kind == "count":
        if isinstance(raw, list):
            return len(raw)
        return _convert(Field(f.name, "int"), raw)
    if kind == "str":
        if isinstance(raw, (dict, list)):
            raise ValueError("must be text")
        return str(raw).strip()
    if kind == "bool":
        if isinstance(raw, bool):
            return raw
        text = str(raw).strip().lower()
        if text in ("true", "yes", "y", "1"):
            return True
        if text in ("false", "no", "n", "0"):
            return False
        raise ValueError(f"must be true or false (got {raw!r})")
    if kind == "date":
        try:
            return date.fromisoformat(str(raw).strip())
        except ValueError:
            raise ValueError(f"must be a date like 2026-01-31 (got {raw!r})") from None
    if kind == "floatlist":
        items = raw.split(",") if isinstance(raw, str) else raw
        if not isinstance(items, list):
            raise ValueError("must be a list of numbers")
        return [_to_number(x) for x in items]
    if kind == "strlist":
        if isinstance(raw, str):
            items = [x for x in (p.strip() for p in raw.split(",")) if x]
        elif isinstance(raw, list):
            items = [str(x).strip() for x in raw]
        else:
            raise ValueError("must be a list of text values")
        return items
    if kind == "moneydict":
        if isinstance(raw, str):
            out = {}
            for part in (p.strip() for p in raw.split(",")):
                if not part:
                    continue
                if "=" not in part:
                    raise ValueError(f"use name=amount pairs like 'mortgage=1500,utilities=250' (got {part!r})")
                key, val = part.split("=", 1)
                out[key.strip()] = _to_number(val)
            return out
        if isinstance(raw, dict):
            return {str(k): _to_number(v) for k, v in raw.items()}
        raise ValueError("must be an object of name: amount pairs")
    raise ValueError(f"unknown field kind {kind}")  # pragma: no cover - programming error


def _range_problems(f: Field, value: Any) -> list[str]:
    if f.kind not in ("float", "pct", "int", "count", "floatlist", "moneydict"):
        return []
    lo = f.min
    hi = f.max if f.max is not None else (100.0 if f.kind == "pct" else None)
    if isinstance(value, list):
        values = value
    elif isinstance(value, dict):
        values = list(value.values())
    else:
        values = [value]
    problems = []
    for v in values:
        if lo is not None and v < lo:
            if lo == 0:
                problems.append(f"'{f.name}' can't be negative (got {_n(v)}).")
            else:
                problems.append(f"'{f.name}' must be at least {_n(lo)} (got {_n(v)}).")
            break
        if hi is not None and v > hi:
            hint = " Enter percentages as whole numbers, e.g. 65 for 65%." if f.kind == "pct" else ""
            problems.append(f"'{f.name}' must be at most {_n(hi)} (got {_n(v)}).{hint}")
            break
    return problems


def parse_fields(data: Any, fields: Sequence[Field], what: str = "input") -> dict:
    """Validate and convert a dict of raw values. Collects every problem before raising."""
    if not isinstance(data, dict):
        raise ValidationError(f"The {what} must be a JSON object (curly braces) with named fields.")
    problems: list[str] = []
    out: dict = {}
    names = [f.name for f in fields]
    for key in data:
        if key in names or str(key).startswith("_") or key in ("notes", "label"):
            continue
        close = difflib.get_close_matches(str(key), names, n=1)
        hint = f" Did you mean '{close[0]}'?" if close else ""
        problems.append(f"Unknown field '{key}'.{hint}")
    for f in fields:
        raw = data.get(f.name)
        if raw is None or (isinstance(raw, str) and raw.strip() == "" and f.kind != "str"):
            if f.required:
                extra = f" ({f.help})" if f.help else ""
                problems.append(f"Missing required field '{f.name}'{extra}.")
            out[f.name] = f.default() if callable(f.default) else f.default
            continue
        try:
            value = _convert(f, raw)
        except ValueError as exc:
            problems.append(f"'{f.name}' {exc}.")
            continue
        problems.extend(_range_problems(f, value))
        out[f.name] = value
    if problems:
        raise ValidationError(problems)
    return out


def safe_div(numerator: float, denominator: float, notes: list[str], message: str) -> float | None:
    """Divide, or return None and record a plain-English note when the denominator is zero."""
    if denominator == 0:
        notes.append(message)
        return None
    return numerator / denominator


def r2(x: float | None, digits: int = 2) -> float | None:
    if x is None:
        return None
    value = round(x, digits)
    return 0.0 if value == 0 else value


def money(x: float | None) -> str:
    if x is None:
        return "n/a"
    value = round(x, 2)
    text = f"${abs(value):,.2f}"
    return "-" + text if value < 0 else text


def pct(x: float | None, digits: int = 2) -> str:
    return "n/a" if x is None else f"{x:.{digits}f}%"


def num(x: float | None, digits: int = 2) -> str:
    return "n/a" if x is None else f"{x:,.{digits}f}"


def yes_no(flag: bool | None) -> str:
    return "n/a" if flag is None else ("yes" if flag else "no")


def load_json_file(path: str | Path) -> Any:
    p = Path(path)
    try:
        text = p.read_text(encoding="utf-8")
    except FileNotFoundError:
        raise ValidationError(f"File not found: {path}") from None
    except OSError as exc:
        raise ValidationError(f"Can't read {path}: {exc.strerror}") from None
    try:
        return json.loads(text)
    except json.JSONDecodeError as exc:
        raise ValidationError(
            f"{path} is not valid JSON (line {exc.lineno}, column {exc.colno}: {exc.msg})."
        ) from None


def read_text_file(path: str | Path) -> str:
    try:
        return Path(path).read_text(encoding="utf-8")
    except FileNotFoundError:
        raise ValidationError(f"File not found: {path}") from None
    except OSError as exc:
        raise ValidationError(f"Can't read {path}: {exc.strerror}") from None


class Report:
    """A small document model rendered to plain text or Markdown."""

    def __init__(self, title: str, subtitle: str | None = None):
        self.title = title
        self.subtitle = subtitle
        self.blocks: list[tuple] = []

    def kv(self, heading: str, rows: Iterable[tuple[Any, Any]]) -> "Report":
        self.blocks.append(("kv", heading, [(str(a), str(b)) for a, b in rows]))
        return self

    def table(self, heading: str, headers: Sequence[str], rows: Iterable[Sequence[Any]]) -> "Report":
        self.blocks.append(("table", heading, list(headers), [[str(c) for c in r] for r in rows]))
        return self

    def bullets(self, heading: str, items: Iterable[Any]) -> "Report":
        self.blocks.append(("bullets", heading, [str(i) for i in items]))
        return self

    def pre(self, heading: str, text: str) -> "Report":
        self.blocks.append(("pre", heading, text))
        return self

    # -- renderers -------------------------------------------------------
    def to_text(self) -> str:
        lines = [self.title, "=" * len(self.title)]
        if self.subtitle:
            lines.append(self.subtitle)
        for block in self.blocks:
            kind, heading = block[0], block[1]
            lines += ["", heading, "-" * len(heading)]
            if kind == "kv":
                rows = block[2]
                width = max((len(a) for a, _ in rows), default=0)
                lines += [f"{a.ljust(width)}  {b}" for a, b in rows] or ["(none)"]
            elif kind == "table":
                headers, rows = block[2], block[3]
                if not rows:
                    lines.append("(none)")
                    continue
                widths = [max(len(str(x)) for x in col) for col in zip(headers, *rows)]
                lines.append("  ".join(h.ljust(w) for h, w in zip(headers, widths)).rstrip())
                lines.append("  ".join("-" * w for w in widths))
                for row in rows:
                    lines.append("  ".join(c.ljust(w) for c, w in zip(row, widths)).rstrip())
            elif kind == "bullets":
                lines += [f"- {i}" for i in block[2]] or ["(none)"]
            elif kind == "pre":
                lines.append(block[2])
        return "\n".join(lines).rstrip() + "\n"

    def to_markdown(self) -> str:
        def cell(text: str) -> str:
            return text.replace("|", "\\|").replace("\n", " ")

        lines = [f"# {self.title}"]
        if self.subtitle:
            lines += ["", self.subtitle]
        for block in self.blocks:
            kind, heading = block[0], block[1]
            lines += ["", f"## {heading}", ""]
            if kind == "kv":
                lines += ["| Item | Value |", "| --- | --- |"]
                lines += [f"| {cell(a)} | {cell(b)} |" for a, b in block[2]]
            elif kind == "table":
                headers, rows = block[2], block[3]
                if not rows:
                    lines.append("_None._")
                    continue
                lines.append("| " + " | ".join(cell(h) for h in headers) + " |")
                lines.append("| " + " | ".join("---" for _ in headers) + " |")
                lines += ["| " + " | ".join(cell(c) for c in row) + " |" for row in rows]
            elif kind == "bullets":
                lines += [f"- {i}" for i in block[2]] or ["_None._"]
            elif kind == "pre":
                lines += ["```text", block[2], "```"]
        return "\n".join(lines).rstrip() + "\n"


def _json_default(obj: Any) -> Any:
    if isinstance(obj, date):
        return obj.isoformat()
    raise TypeError(f"not JSON serializable: {type(obj).__name__}")


def emit(result: Any, report: Report, fmt: str) -> str:
    if fmt == "json":
        return json.dumps(result, indent=2, ensure_ascii=False, default=_json_default) + "\n"
    if fmt == "md":
        return report.to_markdown()
    if fmt == "text":
        return report.to_text()
    raise ValidationError(f"Unknown format '{fmt}'. Use one of: {', '.join(FORMATS)}.")
