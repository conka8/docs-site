"""Freight pack: load profitability (go/no-go) and carrier vetting for brokers.

No FMCSA API calls: the user enters what they found on the FMCSA / SAFER record and the carrier packet.
"""
from __future__ import annotations

import re
from datetime import date

from .common import Field, Report, ValidationError, money, num, parse_fields, pct, r2, safe_div

LOAD_DEFAULTS = {
    "_note": "Set your own minimum rate per mile; market rates change weekly.",
    "min_rpm": 2.00,
    "mpg": 6.5,
}

CARRIER_RULES = {
    "_note": "Common broker thresholds, not law. Verify against current FMCSA rules (49 CFR 387) and your own "
             "carrier packet requirements.",
    "federal_min_auto_liability": 750_000,  # general freight, verify
    "required_auto_liability": 1_000_000,  # what most brokers/shippers require
    "required_cargo": 100_000,
    "new_authority_high_risk_days": 90,
    "new_authority_caution_days": 180,
    "national_avg_vehicle_oos_pct": 22.26,  # FMCSA national average (verify current value)
    "national_avg_driver_oos_pct": 6.67,  # FMCSA national average (verify current value)
    "recent_phone_change_days": 90,
    "free_email_domains": ["gmail.com", "yahoo.com", "hotmail.com", "outlook.com", "aol.com", "icloud.com",
                           "protonmail.com", "proton.me", "mail.com", "gmx.com", "live.com", "msn.com"],
}

LOAD_FIELDS = [
    Field("rate", "float", required=True, help="total pay for the load in dollars (linehaul + fuel surcharge)"),
    Field("loaded_miles", "float", required=True),
    Field("deadhead_miles", "float", default=0.0, help="empty miles to the pickup"),
    Field("mpg", "float", default=LOAD_DEFAULTS["mpg"], help="truck fuel economy, miles per gallon"),
    Field("fuel_price", "float", required=True, help="diesel price per gallon"),
    Field("driver_pay_per_mile", "float", default=0.0, help="paid on all miles (loaded + deadhead)"),
    Field("driver_pay_pct", "pct", default=0.0, help="percent-of-load driver pay"),
    Field("other_costs", "float", default=0.0, help="tolls, lumper, scales, etc."),
    Field("fixed_cost_per_mile", "float", default=0.0, help="truck payment, insurance, maintenance per mile"),
    Field("shipper_rate", "float", help="what the shipper pays the broker (to see broker margin)"),
    Field("min_rpm", "float", default=LOAD_DEFAULTS["min_rpm"], help="your minimum all-miles rate per mile"),
]


def analyze_load(data: dict) -> dict:
    d = parse_fields(data, LOAD_FIELDS, "load input")
    if d["mpg"] <= 0:
        raise ValidationError("'mpg' must be greater than 0.")
    notes: list[str] = []
    total_miles = d["loaded_miles"] + d["deadhead_miles"]
    rpm = safe_div(d["rate"], d["loaded_miles"], notes, "Rate per loaded mile can't be calculated: loaded miles is 0.")
    all_rpm = safe_div(d["rate"], total_miles, notes, "Deadhead-adjusted rate per mile can't be calculated: total miles is 0.")
    gallons = total_miles / d["mpg"]
    fuel = gallons * d["fuel_price"]
    driver = d["driver_pay_per_mile"] * total_miles + d["rate"] * d["driver_pay_pct"] / 100
    fixed = d["fixed_cost_per_mile"] * total_miles
    total_cost = fuel + driver + fixed + d["other_costs"]
    profit = d["rate"] - total_cost
    profit_per_mile = safe_div(profit, total_miles, [], "")
    margin = safe_div(profit, d["rate"], notes, "Profit margin can't be calculated: the rate is $0.")
    cost_per_mile = safe_div(total_cost, total_miles, [], "")
    broker = None
    if d["shipper_rate"] is not None:
        b_margin = d["shipper_rate"] - d["rate"]
        b_pct = safe_div(b_margin, d["shipper_rate"], notes, "Broker margin % can't be calculated: shipper rate is $0.")
        broker = {"shipper_rate": r2(d["shipper_rate"]), "broker_margin": r2(b_margin),
                  "broker_margin_pct": r2(None if b_pct is None else b_pct * 100)}
    reasons = []
    if all_rpm is None:
        reasons.append("No miles entered.")
    elif all_rpm < d["min_rpm"]:
        reasons.append(f"Deadhead-adjusted RPM ${all_rpm:.2f} is below your minimum ${d['min_rpm']:.2f}.")
    if profit <= 0:
        reasons.append(f"Load doesn't make a profit ({money(profit)}).")
    decision = "GO" if not reasons else "NO-GO"
    if decision == "GO":
        reasons.append(f"Deadhead-adjusted RPM ${all_rpm:.2f} meets your ${d['min_rpm']:.2f} minimum and profit is {money(profit)}.")
    if d["deadhead_miles"] and d["loaded_miles"] and d["deadhead_miles"] / d["loaded_miles"] > 0.15:
        notes.append("Deadhead is over 15% of loaded miles; try to negotiate or find a closer load.")
    return {
        "total_miles": r2(total_miles),
        "rpm": r2(rpm),
        "deadhead_adjusted_rpm": r2(all_rpm),
        "fuel_gallons": r2(gallons),
        "fuel_cost": r2(fuel),
        "driver_pay": r2(driver),
        "fixed_costs": r2(fixed),
        "other_costs": r2(d["other_costs"]),
        "total_cost": r2(total_cost),
        "cost_per_mile": r2(cost_per_mile),
        "profit": r2(profit),
        "profit_per_mile": r2(profit_per_mile),
        "profit_margin_pct": r2(None if margin is None else margin * 100),
        "broker": broker,
        "min_rpm": d["min_rpm"],
        "decision": decision,
        "reasons": reasons,
        "notes": notes,
    }


def load_report(res: dict) -> Report:
    rep = Report(f"Load check: {res['decision']}")
    rows = [("Total miles", num(res["total_miles"], 0)), ("Rate per loaded mile", money(res["rpm"])),
            ("Deadhead-adjusted RPM", money(res["deadhead_adjusted_rpm"])), ("Your minimum RPM", money(res["min_rpm"])),
            ("Fuel", f"{money(res['fuel_cost'])} ({num(res['fuel_gallons'], 1)} gal)"),
            ("Driver pay", money(res["driver_pay"])), ("Fixed costs", money(res["fixed_costs"])),
            ("Other costs", money(res["other_costs"])), ("Total cost", money(res["total_cost"])),
            ("Cost per mile", money(res["cost_per_mile"])), ("Profit", money(res["profit"])),
            ("Profit per mile", money(res["profit_per_mile"])), ("Margin", pct(res["profit_margin_pct"]))]
    if res["broker"]:
        b = res["broker"]
        rows += [("Shipper rate", money(b["shipper_rate"])),
                 ("Broker margin", f"{money(b['broker_margin'])} ({pct(b['broker_margin_pct'])})")]
    rep.kv("Numbers", rows)
    rep.bullets("Decision", [res["decision"]] + res["reasons"])
    rep.bullets("Notes", res["notes"])
    return rep


SAFETY_RATINGS = ("satisfactory", "conditional", "unsatisfactory", "not rated")
CARRIER_FIELDS = [
    Field("legal_name", "str", required=True),
    Field("mc_number", "str"),
    Field("dot_number", "str"),
    Field("authority_status", "str", help="active / inactive / revoked"),
    Field("authority_granted_date", "date"),
    Field("authority_age_days", "int"),
    Field("as_of_date", "date"),
    Field("cargo_insurance", "float"),
    Field("auto_liability_insurance", "float"),
    Field("safety_rating", "str", help="satisfactory / conditional / unsatisfactory / not rated"),
    Field("vehicle_oos_pct", "pct"),
    Field("driver_oos_pct", "pct"),
    Field("email", "str"),
    Field("company_website", "str"),
    Field("fmcsa_email", "str", help="email on the FMCSA record"),
    Field("phone", "str"),
    Field("fmcsa_phone", "str", help="phone on the FMCSA record"),
    Field("phone_changed_days_ago", "int"),
    Field("payee_name", "str", help="name on the payment / factoring instructions"),
    Field("address_matches_fmcsa", "bool"),
]


def _domain(value: str | None) -> str | None:
    if not value:
        return None
    v = value.strip().lower()
    if "@" in v:
        v = v.rsplit("@", 1)[1]
    v = re.sub(r"^[a-z]+://", "", v).split("/")[0]
    if v.startswith("www."):
        v = v[4:]
    return v or None


def _digits(phone: str | None) -> str:
    d = re.sub(r"\D", "", phone or "")
    return d[-10:]


def _norm_name(name: str | None) -> str:
    n = re.sub(r"[^a-z0-9 ]", "", (name or "").lower())
    n = re.sub(r"\b(llc|inc|corp|co|ltd|incorporated|company|corporation)\b", "", n)
    return " ".join(n.split())


def vet_carrier(data: dict, as_of: date | None = None) -> dict:
    d = parse_fields(data, CARRIER_FIELDS, "carrier data")
    R = CARRIER_RULES
    checks: list[dict] = []

    def check(name: str, status: str, points: int, reason: str, critical: bool = False) -> None:
        checks.append({"check": name, "status": status, "risk_points": points, "reason": reason, "critical": critical})

    # Authority status
    status = (d["authority_status"] or "").lower()
    if not status:
        check("Operating authority", "unknown", 10, "Authority status not entered; confirm it's ACTIVE on the FMCSA record.")
    elif status != "active":
        check("Operating authority", "fail", 50, f"Authority status is '{status}': do not tender loads.", critical=True)
    else:
        check("Operating authority", "pass", 0, "Authority is active.")

    # Authority age
    today = as_of or d["as_of_date"] or date.today()
    age = d["authority_age_days"]
    if age is None and d["authority_granted_date"]:
        age = (today - d["authority_granted_date"]).days
        if age < 0:
            raise ValidationError("'authority_granted_date' is in the future.")
    if age is None:
        check("Authority age", "unknown", 10, "Authority age not entered.")
    elif age < R["new_authority_high_risk_days"]:
        check("Authority age", "fail", 30, f"Authority is only {age} days old: new authorities are the most common "
              "source of fraud and double brokering.")
    elif age < R["new_authority_caution_days"]:
        check("Authority age", "warn", 15, f"Authority is {age} days old (under {R['new_authority_caution_days']}).")
    else:
        check("Authority age", "pass", 0, f"Authority is {age} days old.")

    # Insurance
    auto = d["auto_liability_insurance"]
    if auto is None:
        check("Auto liability insurance", "unknown", 10, "Auto liability amount not entered; get a certificate of insurance.")
    elif auto < R["federal_min_auto_liability"]:
        check("Auto liability insurance", "fail", 40, f"{money(auto)} is below the federal minimum "
              f"{money(R['federal_min_auto_liability'])} (verify).", critical=True)
    elif auto < R["required_auto_liability"]:
        check("Auto liability insurance", "warn", 15, f"{money(auto)} is below the usual broker requirement "
              f"{money(R['required_auto_liability'])}.")
    else:
        check("Auto liability insurance", "pass", 0, f"{money(auto)} meets {money(R['required_auto_liability'])}.")
    cargo = d["cargo_insurance"]
    if cargo is None:
        check("Cargo insurance", "unknown", 10, "Cargo insurance amount not entered.")
    elif cargo < R["required_cargo"]:
        check("Cargo insurance", "fail", 15, f"{money(cargo)} is below the usual {money(R['required_cargo'])} requirement.")
    else:
        check("Cargo insurance", "pass", 0, f"{money(cargo)} meets {money(R['required_cargo'])}.")

    # Safety rating
    rating = (d["safety_rating"] or "").lower().replace("_", " ").replace("none", "not rated").strip()
    if rating and rating not in SAFETY_RATINGS:
        raise ValidationError(f"'safety_rating' must be one of: {', '.join(SAFETY_RATINGS)} (got {d['safety_rating']!r}).")
    if not rating:
        check("Safety rating", "unknown", 5, "Safety rating not entered.")
    elif rating == "unsatisfactory":
        check("Safety rating", "fail", 50, "Unsatisfactory safety rating.", critical=True)
    elif rating == "conditional":
        check("Safety rating", "warn", 20, "Conditional safety rating: review the reasons before using.")
    elif rating == "not rated":
        check("Safety rating", "warn", 5, "Not rated (common for small or new carriers).")
    else:
        check("Safety rating", "pass", 0, "Satisfactory safety rating.")

    # Out-of-service rates
    for key, label, avg in (("vehicle_oos_pct", "Vehicle out-of-service rate", R["national_avg_vehicle_oos_pct"]),
                            ("driver_oos_pct", "Driver out-of-service rate", R["national_avg_driver_oos_pct"])):
        v = d[key]
        if v is None:
            check(label, "unknown", 0, "Not entered.")
        elif v > 2 * avg:
            check(label, "fail", 20, f"{v:g}% is more than double the national average {avg:g}%.")
        elif v > avg:
            check(label, "warn", 10, f"{v:g}% is above the national average {avg:g}%.")
        else:
            check(label, "pass", 0, f"{v:g}% is at or below the national average {avg:g}%.")

    # Double-brokering / identity red flags
    email_dom = _domain(d["email"])
    site_dom = _domain(d["company_website"])
    fmcsa_dom = _domain(d["fmcsa_email"])
    if not email_dom:
        check("Email domain", "unknown", 5, "No contact email entered.")
    elif fmcsa_dom and email_dom != fmcsa_dom:
        check("Email domain", "fail", 25, f"Email domain '{email_dom}' doesn't match the FMCSA record '{fmcsa_dom}': "
              "possible impersonation. Contact the carrier using the FMCSA-listed details.")
    elif site_dom and email_dom not in R["free_email_domains"] and email_dom != site_dom:
        check("Email domain", "fail", 25, f"Email domain '{email_dom}' doesn't match the company website '{site_dom}'.")
    elif email_dom in R["free_email_domains"]:
        check("Email domain", "warn", 10, f"Free email address ({email_dom}); confirm identity by calling the FMCSA-listed phone.")
    else:
        check("Email domain", "pass", 0, f"Email domain '{email_dom}' is consistent.")

    if d["phone"] and d["fmcsa_phone"]:
        if _digits(d["phone"]) != _digits(d["fmcsa_phone"]):
            check("Phone number", "fail", 20, "Phone doesn't match the FMCSA record: call the FMCSA-listed number to confirm.")
        else:
            check("Phone number", "pass", 0, "Phone matches the FMCSA record.")
    else:
        check("Phone number", "unknown", 5, "Enter both the contact phone and the FMCSA-listed phone to compare.")
    changed = d["phone_changed_days_ago"]
    if changed is not None and changed < R["recent_phone_change_days"]:
        check("Recent contact change", "fail", 20, f"Phone/contact changed {changed} days ago: common sign of a hijacked authority.")
    elif changed is not None:
        check("Recent contact change", "pass", 0, f"No contact change in the last {R['recent_phone_change_days']} days.")

    if d["payee_name"]:
        if _norm_name(d["payee_name"]) != _norm_name(d["legal_name"]):
            check("Payee name", "warn", 20, f"Payment goes to '{d['payee_name']}', not '{d['legal_name']}'. "
                  "Confirm the factoring company / notice of assignment directly.")
        else:
            check("Payee name", "pass", 0, "Payee matches the legal name.")
    if d["address_matches_fmcsa"] is False:
        check("Address", "warn", 10, "Address doesn't match the FMCSA record.")
    elif d["address_matches_fmcsa"] is True:
        check("Address", "pass", 0, "Address matches the FMCSA record.")

    score = min(100, sum(c["risk_points"] for c in checks))
    critical = [c for c in checks if c["critical"]]
    if critical:
        level, recommendation = "high", "DO NOT USE: fails a hard requirement."
    elif score >= 50:
        level, recommendation = "high", "High risk: don't tender without manager approval and extra verification."
    elif score >= 20:
        level, recommendation = "medium", "Medium risk: resolve the warnings before tendering."
    else:
        level, recommendation = "low", "Low risk: OK to proceed with your normal process."
    red_flags = [c["reason"] for c in checks if c["status"] == "fail"]
    return {
        "legal_name": d["legal_name"],
        "mc_number": d["mc_number"],
        "dot_number": d["dot_number"],
        "authority_age_days": age,
        "risk_score": score,
        "risk_level": level,
        "recommendation": recommendation,
        "red_flags": red_flags,
        "checklist": checks,
        "note": "Data is entered by you; this tool doesn't query FMCSA. " + R["_note"],
    }


def carrier_report(res: dict) -> Report:
    ids = " / ".join(x for x in (f"MC {res['mc_number']}" if res["mc_number"] else "",
                                 f"DOT {res['dot_number']}" if res["dot_number"] else "") if x)
    rep = Report(f"Carrier vetting: {res['legal_name']}", ids or None)
    rep.kv("Result", [("Risk score", f"{res['risk_score']} / 100"), ("Risk level", res["risk_level"].upper()),
                      ("Recommendation", res["recommendation"])])
    rep.table("Checklist", ["Check", "Status", "Risk", "Reason"],
              [[c["check"], c["status"].upper(), c["risk_points"], c["reason"]] for c in res["checklist"]])
    rep.bullets("Red flags", res["red_flags"])
    rep.bullets("Note", [res["note"]])
    return rep
