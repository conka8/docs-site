"""Authors pack: Amazon KDP metadata checks (title, keywords, description HTML, categories, series)."""
from __future__ import annotations

import re

from .common import Field, Report, parse_fields

KDP_LIMITS = {
    "_note": "Verify against current KDP guidelines (KDP Help: metadata guidelines); Amazon changes these limits.",
    "title_subtitle_max_chars": 200,
    "keyword_slots": 7,
    "keyword_max_chars": 50,
    "description_max_chars": 4000,
    "max_categories": 3,
    "allowed_html_tags": ["b", "strong", "i", "em", "u", "br", "p", "h4", "h5", "h6", "ul", "ol", "li"],
}
VOID_TAGS = {"br"}

RISKY_AUTHOR_NAMES = [
    "stephen king", "james patterson", "colleen hoover", "j.k. rowling", "jk rowling", "nora roberts",
    "john grisham", "danielle steel", "brandon sanderson", "sarah j. maas", "sarah j maas", "rick riordan",
    "lee child", "freida mcfadden", "rebecca yarros", "emily henry", "dan brown", "agatha christie",
]
RISKY_BRANDS = [
    "amazon", "kindle", "audible", "netflix", "disney", "marvel", "harry potter", "star wars", "lego",
    "barbie", "pokemon", "minecraft", "game of thrones", "twilight",
]
PROMO_TERMS = [
    "bestseller", "best seller", "best-seller", "bestselling", "best selling", "best-selling", "free",
    "kindle unlimited", "ku", "#1", "number one", "new release", "on sale", "discount", "cheap",
]
STOPWORDS = {
    "a", "an", "the", "and", "or", "of", "to", "in", "on", "for", "with", "at", "by", "from", "is", "your",
    "my", "how", "book", "books", "guide", "novel", "vol", "volume",
}

BOOK_FIELDS = [
    Field("title", "str", required=True),
    Field("subtitle", "str", default=""),
    Field("author", "str", default=""),
    Field("keywords", "strlist", default=list),
    Field("description", "str", default=""),
    Field("categories", "strlist", default=list),
    Field("series_name", "str", default=""),
    Field("series_number", "int", min=None),
    Field("extra_banned_terms", "strlist", default=list, help="other authors or brands you want flagged"),
]


def _term_pattern(term: str) -> str:
    if term == "free":
        # Allow descriptors like "gluten-free" / "sugar-free"; flag standalone "free".
        return r"(?<![\w-])free(?![\w-])"
    if term.startswith("#"):
        return re.escape(term) + r"(?!\d)"
    return r"(?<![\w])" + re.escape(term) + r"(?![\w])"


def find_risky_terms(text: str, extra: list[str] | None = None) -> list[tuple[str, str]]:
    """Return (term, kind) pairs found in text. kind: author | brand | promo | custom."""
    low = text.lower()
    found: list[tuple[str, str]] = []
    groups = [("author", RISKY_AUTHOR_NAMES), ("brand", RISKY_BRANDS), ("promo", PROMO_TERMS),
              ("custom", [e.lower() for e in (extra or []) if e.strip()])]
    for kind, terms in groups:
        for term in terms:
            if re.search(_term_pattern(term), low) and not any(term in f for f, _ in found):
                found.append((term, kind))
    return found


def _words(text: str) -> list[str]:
    return [w for w in re.findall(r"[a-z0-9']+", text.lower()) if w not in STOPWORDS and len(w) > 1]


def check_html(description: str) -> tuple[list[str], list[str]]:
    """Return (disallowed tags, unclosed/mismatched tags)."""
    allowed = set(KDP_LIMITS["allowed_html_tags"])
    disallowed: list[str] = []
    problems: list[str] = []
    stack: list[str] = []
    for m in re.finditer(r"<\s*(/)?\s*([a-zA-Z][a-zA-Z0-9]*)[^>]*?(/)?\s*>", description):
        closing, tag, selfclose = m.group(1), m.group(2).lower(), m.group(3)
        if tag not in allowed:
            if tag not in disallowed:
                disallowed.append(tag)
            continue
        if tag in VOID_TAGS or selfclose:
            continue
        if not closing:
            stack.append(tag)
        elif stack and stack[-1] == tag:
            stack.pop()
        elif tag in stack:
            while stack and stack[-1] != tag:
                problems.append(f"<{stack.pop()}> is not closed")
            stack.pop()
        else:
            problems.append(f"</{tag}> has no opening tag")
    problems += [f"<{t}> is not closed" for t in reversed(stack)]
    return disallowed, problems


def check_book(data: dict) -> dict:
    d = parse_fields(data, BOOK_FIELDS, "book metadata")
    L = KDP_LIMITS
    issues: list[dict] = []

    def add(severity: str, field: str, message: str) -> None:
        issues.append({"severity": severity, "field": field, "message": message})

    title, subtitle = d["title"], d["subtitle"]
    if not title:
        add("error", "title", "Title is empty.")
    combined = len(title) + len(subtitle)
    if combined > L["title_subtitle_max_chars"]:
        add("error", "title", f"Title + subtitle is {combined} characters; the limit is {L['title_subtitle_max_chars']}.")
    for field, text in (("title", title), ("subtitle", subtitle)):
        for term, kind in find_risky_terms(text, d["extra_banned_terms"]):
            if kind == "promo":
                add("error", field, f"'{term}' is promotional language KDP doesn't allow in titles/subtitles.")
            elif kind in ("author", "custom"):
                add("warning", field, f"Mentions '{term}': don't reference other authors in your title.")

    # Keywords
    kws = d["keywords"]
    if len(kws) > L["keyword_slots"]:
        add("error", "keywords", f"{len(kws)} keywords entered; KDP has {L['keyword_slots']} keyword slots.")
    used = [k for k in kws if k]
    if len(used) < L["keyword_slots"]:
        add("info", "keywords", f"Using {len(used)} of {L['keyword_slots']} keyword slots; fill them all.")
    title_words = set(_words(title + " " + subtitle))
    seen: dict[str, int] = {}
    own_author = d["author"].lower().strip()
    for i, kw in enumerate(kws, start=1):
        field = f"keywords[{i}]"
        if not kw:
            continue
        if len(kw) > L["keyword_max_chars"]:
            add("error", field, f"Keyword {i} is {len(kw)} characters; the limit is {L['keyword_max_chars']}.")
        for term, kind in find_risky_terms(kw, d["extra_banned_terms"]):
            label = {"author": "another author's name", "brand": "a brand / trademark", "promo": "promotional language",
                     "custom": "a term on your banned list"}[kind]
            add("error", field, f"Keyword {i} contains '{term}' ({label}); KDP can suppress or block this.")
        if own_author and own_author in kw.lower():
            add("info", field, f"Keyword {i} contains your own name; Amazon already indexes the author field.")
        key = " ".join(kw.lower().split())
        if key in seen:
            add("warning", field, f"Keyword {i} duplicates keyword {seen[key]}.")
        else:
            seen[key] = i
        overlap = sorted(set(_words(kw)) & title_words)
        if overlap:
            add("warning", field, f"Keyword {i} repeats title words ({', '.join(overlap)}); the title is already "
                "indexed, so use the space for new phrases.")

    # Description
    desc = d["description"]
    if not desc.strip():
        add("error", "description", "Description is empty.")
    elif len(desc) > L["description_max_chars"]:
        add("error", "description", f"Description is {len(desc)} characters (including HTML); the limit is "
            f"{L['description_max_chars']}.")
    disallowed, html_problems = check_html(desc)
    if disallowed:
        add("error", "description", "HTML tags not supported by KDP: " + ", ".join(f"<{t}>" for t in disallowed)
            + ". Allowed: " + ", ".join(L["allowed_html_tags"]) + ".")
    for p in html_problems:
        add("warning", "description", f"HTML: {p}.")
    for term, kind in find_risky_terms(re.sub(r"<[^>]+>", " ", desc), d["extra_banned_terms"]):
        if kind == "promo" and term in ("free", "#1", "bestseller", "best seller", "best-seller", "bestselling", "best selling",
                                          "best-selling"):
            add("warning", "description", f"Description says '{term}'; avoid time-sensitive or unverifiable claims.")

    # Categories
    cats = [c for c in d["categories"] if c]
    if not cats:
        add("warning", "categories", "No categories chosen.")
    elif len(cats) > L["max_categories"]:
        add("error", "categories", f"{len(cats)} categories; KDP lets you pick up to {L['max_categories']}.")
    if len({c.lower() for c in cats}) < len(cats):
        add("warning", "categories", "The same category is listed twice.")

    # Series
    name, number = d["series_name"], d["series_number"]
    if number is not None and number < 1:
        add("error", "series_number", f"Series number must be 1 or higher (got {number}).")
    if name and number is None:
        add("error", "series_number", f"Series '{name}' has no book number.")
    if number is not None and not name:
        add("error", "series_name", "Series number is set but series name is empty.")
    m = re.search(r"\b(?:book|volume|vol\.?|part|#)\s*(\d+)\b", (title + " " + subtitle).lower())
    if m:
        title_no = int(m.group(1))
        if number is not None and title_no != number:
            add("error", "series_number", f"Title says number {title_no} but series number is {number}.")
        elif number is None and not name:
            add("warning", "series_name", f"Title mentions number {title_no}; add series info so the books link together.")
    if name and name.lower() in title.lower() and len(name) > 3:
        add("info", "title", "Series name is repeated in the title; KDP shows the series separately.")

    order = {"error": 0, "warning": 1, "info": 2}
    issues.sort(key=lambda i: order[i["severity"]])
    errors = sum(i["severity"] == "error" for i in issues)
    warnings = sum(i["severity"] == "warning" for i in issues)
    return {
        "title": title,
        "ok": errors == 0,
        "errors": errors,
        "warnings": warnings,
        "issues": issues,
        "stats": {"title_subtitle_chars": combined, "keywords_used": len(used),
                  "description_chars": len(desc), "categories": len(cats)},
        "limits": {k: v for k, v in KDP_LIMITS.items() if not k.startswith("_")},
        "limits_note": KDP_LIMITS["_note"],
    }


def kdp_report(res: dict) -> Report:
    L = res["limits"]
    s = res["stats"]
    verdict = "Ready to publish" if res["ok"] else "Fix errors before publishing"
    rep = Report(f"KDP metadata check: {res['title']}", f"{verdict} ({res['errors']} errors, {res['warnings']} warnings)")
    rep.kv("Stats", [
        ("Title + subtitle", f"{s['title_subtitle_chars']} / {L['title_subtitle_max_chars']} chars"),
        ("Keyword slots used", f"{s['keywords_used']} / {L['keyword_slots']}"),
        ("Description", f"{s['description_chars']} / {L['description_max_chars']} chars"),
        ("Categories", f"{s['categories']} / {L['max_categories']}"),
    ])
    rep.table("Issues", ["Severity", "Field", "Message"],
              [[i["severity"].upper(), i["field"], i["message"]] for i in res["issues"]])
    rep.bullets("Note", [res["limits_note"]])
    return rep
