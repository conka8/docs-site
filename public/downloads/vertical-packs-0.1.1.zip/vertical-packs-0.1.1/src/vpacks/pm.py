"""Property maintenance pack: triage tenant maintenance requests.

Keyword/regex rules with negation handling ("no leak" doesn't trigger a leak), multi-issue
requests, emergency instructions and a CSV batch mode. Keyword-based triage that always escalates when
unsure: danger words (CO, gas, smoke, burst, exposed wires...) are at least urgent and flagged for a human. Rules are deliberately transparent so a
property manager can read and adjust them.
"""
from __future__ import annotations

import csv
import io
import re
from dataclasses import dataclass

from .common import Report, ValidationError

CATEGORIES = ("plumbing", "electrical", "hvac", "appliance", "pest", "lockout", "structural", "other")
URGENCY_RANK = {"routine": 0, "urgent": 1, "emergency": 2}

SLA = {
    "_note": "Typical targets, not legal advice. Check your lease and local landlord-tenant law for required timelines.",
    "emergency": "Respond within 1 hour, make safe the same day (24/7).",
    "urgent": "Respond the same day, repair within 24-48 hours.",
    "routine": "Acknowledge within 1 business day, schedule within 5-7 business days.",
}

VENDORS = {
    "plumbing": "Licensed plumber",
    "electrical": "Licensed electrician",
    "hvac": "HVAC technician",
    "appliance": "Appliance repair technician",
    "pest": "Licensed pest control company",
    "lockout": "Locksmith",
    "structural": "General contractor (structural engineer for foundation or collapse issues)",
    "other": "Handyman, or property manager review",
}

EMERGENCY_VENDORS = {
    "gas smell": "Gas utility emergency line first, then a licensed plumber / gas fitter",
    "fire or sparks": "Fire department (911) if there is fire or smoke, then a licensed electrician",
    "carbon monoxide": "Fire department (911), then an HVAC technician",
    "flooding": "Licensed plumber (emergency call-out) and a water damage mitigation company",
    "no water": "Licensed plumber (after checking for a city water outage)",
    "no heat in freezing weather": "HVAC technician (emergency call-out)",
    "security breach": "Locksmith / board-up service (police report if there was a break-in)",
    "structural collapse": "Structural engineer / general contractor (emergency)",
}

EMERGENCY_INSTRUCTIONS = {
    "gas smell": "Leave the home now. Don't flip light switches, light flames or use your phone inside. "
                 "From outside, call 911 and the gas company's emergency line.",
    "fire or sparks": "If there is fire or smoke, get everyone out and call 911. If it's only sparking and safe "
                      "to do so, switch off that circuit at the breaker panel and don't use the outlet.",
    "carbon monoxide": "Get everyone (and pets) out into fresh air now and call 911. Don't go back in until "
                       "the fire department says it's safe.",
    "flooding": "If safe, shut off the main water valve or the valve behind the fixture. Stay out of standing "
                "water near outlets or appliances. Move valuables off the floor.",
    "no water": "Check whether neighbors also have no water (it may be a city outage). Don't open the water "
                "heater. We'll send a plumber.",
    "no heat in freezing weather": "Keep warm safely: never use the oven or a grill for heat. Open cabinet doors "
                                   "under sinks and let faucets drip slightly so pipes don't freeze.",
    "security breach": "If anyone might still be inside or you feel unsafe, leave and call 911. Don't touch "
                       "anything that was damaged until police have seen it.",
    "structural collapse": "Keep everyone away from the affected area. If anyone is hurt or the building feels "
                           "unsafe, get out and call 911.",
}

CATEGORY_TIPS = {
    "plumbing": "Turn off the valve behind the toilet or under the sink if water is leaking, and put a bucket or towels down.",
    "electrical": "Don't use the affected outlet or switch. Check if a breaker has tripped.",
    "hvac": "Check the thermostat setting and batteries, and that the filter isn't clogged.",
    "appliance": "Unplug the appliance if it's sparking, smoking or leaking. Move food to a cooler if the fridge is warm.",
    "pest": "Store food in sealed containers and take a photo of the pest if you can.",
    "lockout": "Stay somewhere safe and keep your phone charged. Have your ID ready for the locksmith.",
    "structural": "Keep people and pets away from the damaged area and take photos.",
    "other": "Send a photo or video so we can send the right person.",
}

QUESTIONS = {
    "plumbing": ["Where exactly is the problem (which room and fixture)?",
                 "Is water actively leaking or overflowing right now?",
                 "Have you been able to turn off the water valve to that fixture or the main?"],
    "electrical": ["Which outlets, switches or lights are affected?",
                   "Do you see sparks, smoke or scorch marks, or smell burning?",
                   "Have you checked the breaker panel? Is the whole unit out or just part of it?"],
    "hvac": ["What does the thermostat show (setting and current temperature)?",
             "Is the system running at all (fan, noise) or completely off?",
             "When did it stop working?"],
    "appliance": ["Which appliance, and what brand/model (sticker inside the door)?",
                  "What exactly is it doing or not doing? Any error code?",
                  "Is it leaking water or gas?"],
    "pest": ["What kind of pest is it (photo if possible)?",
             "Which rooms, and since when?",
             "Are neighbors seeing them too?"],
    "lockout": ["Can you confirm your full name and unit number?",
                "Where are you now, and are you safe?",
                "Is anyone (child, pet) inside, or anything on the stove?"],
    "structural": ["Where is it, and how big is it (photo with an object for scale)?",
                   "Is it getting worse, moving, or letting water in?",
                   "Is anyone at risk of getting hurt?"],
    "other": ["Can you describe the problem in a bit more detail?"],
}
GENERAL_QUESTIONS = ["Can you send a photo or short video?",
                     "Is it OK for maintenance to enter if you're not home? Any pets?",
                     "What times work best for a visit?"]


@dataclass(frozen=True)
class Rule:
    id: str
    category: str
    urgency: str
    pattern: str
    negatable: bool = True
    emergency: str | None = None


# Order matters: earlier rules "consume" the words they match, so a later, more generic rule
# doesn't fire on the same words (e.g. "gas leak" is a gas emergency, not a plumbing leak).
RULES: list[Rule] = [
    # --- emergencies -----------------------------------------------------------------------
    Rule("gas_smell", "plumbing", "emergency",
         r"\b(smell(s|ing|ed)? (of |like )?(natural )?gas|gas (smell|odou?r|leak)|rotten eggs?)\b",
         emergency="gas smell"),
    Rule("carbon_monoxide", "hvac", "emergency",
         r"\b(carbon monoxide|co) (alarm|detector)s? (is |are |keeps |just )?(going off|went off|goes off|sounding|"
         r"alarming|ringing|blaring)\b"
         r"|\bcarbon monoxide (leak|poisoning)\b",
         emergency="carbon monoxide"),
    Rule("fire_sparks", "electrical", "emergency",
         r"\b(sparks?|sparking|on fire|fire(?! (alarm|detector|escape|extinguisher|exit|door|hydrant)s?\b)|flames?|"
         r"smoke(?! (alarm|detector)s?\b)|smoky|smoking|(burning|burnt|burned) (smell|odou?r)|"
         r"smell(s|ing|ed)? (of |like )?(something )?(burning|burnt|burned)|something('s| is)? burning|"
         r"melted|scorch(ed|ing)?)\b",
         emergency="fire or sparks"),
    Rule("flooding", "plumbing", "emergency",
         r"\b(flood(s|ing|ed)?|water everywhere|burst(ing)?|ruptured|pipes? (broke|exploded)|"
         r"sewage (backup|backing up|coming up)|water (is )?pouring|gushing)\b",
         emergency="flooding"),
    Rule("no_water", "plumbing", "emergency",
         r"\bno (running )?water\b(?!\s+(leak|leaking|leaks|damage|stains?|spots?|on|under|heater))"
         r"|\b(do not|don'?t|dont) have (any )?(running )?water\b"
         r"|\bwater (is |has been |got |was )?(shut|turned|cut) off\b",
         negatable=False, emergency="no water"),
    Rule("security", "lockout", "emergency",
         r"\b(break[- ]?in|broke in|broken into|burglar(y|ized)?|intruder|"
         r"(front|back|entry|entrance|main|apartment|unit|patio|sliding|outside) door\b[^.,;]{0,20}"
         r"\b(won'?t|doesn'?t|does not|will not|can'?t|cannot) (lock|close|latch|shut)|"
         r"(door|deadbolt|lock)s? (won'?t|doesn'?t|does not|will not|can'?t|cannot) lock|can'?t lock|cannot lock|"
         r"(front|back|entry|entrance|main|apartment|unit|patio|sliding|outside) door (is |was )?"
         r"(broken|smashed|kicked in)|(lock|deadbolt) (is |was )?(broken|smashed)|"
         r"(window|glass) (is |was )?(smashed|shattered)|smashed window|kicked in)\b",
         negatable=False, emergency="security breach"),
    Rule("collapse", "structural", "emergency",
         r"\b(ceiling|roof|floor|wall|stairs?|balcony|deck)\b[^.,;]{0,20}\b(collapsed|caved in|caving in|"
         r"falling (down|in)|fell in|gave way)\b",
         negatable=False, emergency="structural collapse"),
    # --- urgent (may escalate) ---------------------------------------------------------------
    Rule("no_heat", "hvac", "urgent",
         r"\bno (heat|heating)\b"
         r"|\b(heat|heating|heater|furnace|boiler)\b[^.,;]{0,25}\b(not working|isn'?t working|stopped working|broke|"
         r"broken|is out|went out|died|won'?t (turn|come) on|not turning on|not coming on)\b"
         r"|\b(do not|don'?t|dont) have (any )?heat\b",
         negatable=False),
    Rule("no_ac", "hvac", "urgent",
         r"\b(ac|a/c|air conditioning|air conditioner|central air)\b[^.,;]{0,25}\b(not working|isn'?t working|"
         r"stopped working|broke|broken|blowing (warm|hot) air|won'?t (turn|come) on|not cooling|isn'?t cooling)\b"
         r"|\bno (ac|a/c|air conditioning|cooling)\b",
         negatable=False),
    Rule("no_power", "electrical", "urgent",
         r"\bno (power|electricity)\b|\b(power|electricity) (is |went |has been |was )?(out|off)\b|\bpower outage\b",
         negatable=False),
    Rule("no_hot_water", "plumbing", "urgent",
         r"\bno hot water\b|\bhot water\b[^.,;]{0,20}\b(not working|isn'?t working|is out|gone)\b"
         r"|\bwater heater\b[^.,;]{0,25}\b(not working|broken|leaking|is out|died)\b",
         negatable=False),
    Rule("fridge_out", "appliance", "urgent",
         r"\b(fridge|refrigerator|freezer)\b[^.,;]{0,25}\b(not (cooling|cold|working)|isn'?t (cooling|cold|working)|"
         r"stopped (cooling|working)|warm|died|broken)\b",
         negatable=False),
    Rule("lockout", "lockout", "urgent",
         r"\b(locked out|lock(ed)? (myself|ourselves) out|lost (my |the |our )?keys?|can'?t get in(to)?|"
         r"key (broke|is stuck|won'?t turn)|lockout)\b",
         negatable=False),
    Rule("frozen_pipes", "plumbing", "urgent", r"\b(frozen pipes?|pipes? (are |is )?frozen)\b", negatable=False),
    Rule("roof_leak", "structural", "urgent",
         r"\broof\b[^.,;]{0,20}\bleak(s|ing|ed|y)?\b|\bleak(s|ing|y)?\b[^.,;]{0,20}\broof\b"),
    Rule("leak", "plumbing", "urgent",
         r"\b(leak(s|ing|ed|y)?|dripping from (the )?ceiling|water (stains?|damage)|water coming (in|through|from)|"
         r"overflow(s|ing|ed)?)\b"),
    Rule("bed_bugs", "pest", "urgent", r"\bbed ?bugs?\b"),
    # --- routine: object / symptom words -------------------------------------------------------
    Rule("plumbing_general", "plumbing", "routine",
         r"\b(toilets?|sinks?|faucets?|drains?|pipes?|shower|tub|bathtub|clog(s|ged)?|backed up|"
         r"dripp?(ing|y)?|plumbing|water pressure)\b"),
    Rule("electrical_general", "electrical", "routine",
         r"\b(outlets?|breakers?|circuits?|light switch(es)?|switch(es)?|wiring|lights?|light fixtures?|"
         r"flicker(s|ing)?)\b"),
    Rule("hvac_general", "hvac", "routine",
         r"\b(thermostat|vents?|furnace|heater|heat|heating|hvac|ac unit|air conditioner|air conditioning|a/c|ac|"
         r"air filter)\b"),
    Rule("appliance_general", "appliance", "routine",
         r"\b(fridge|refrigerator|freezer|stove|oven|range|cooktop|dishwasher|washer|washing machine|dryer|"
         r"microwave|garbage disposal|disposal|ice maker)\b"),
    Rule("pest_general", "pest", "routine",
         r"\b(roach(es)?|cockroach(es)?|mice|mouse|rats?|rodents?|ants|termites?|wasps?|bees|hornets?|"
         r"spiders?|fleas|pests?|droppings|bugs|infestation|raccoons?|squirrels?)\b"),
    Rule("structural_general", "structural", "routine",
         r"\b(roof|ceiling|foundation|cracks?|cracked|drywall|hole in (the )?(wall|ceiling|floor)|windows?|"
         r"mou?ld|rot(ted|ting)?|sagging|stairs|railing|siding)\b"),
]


@dataclass(frozen=True)
class SafetyCheck:
    """A fail-safe check on the whole request: any mention makes it at least urgent and flags it for a human now.

    ``escalate_if`` (searched anywhere in the request) turns it into an emergency of type ``emergency``.
    Checks with ``urgency="emergency"`` drop to urgent (still flagged) when the tenant negates them.
    """
    id: str
    category: str
    pattern: str
    reason: str
    instruction: str
    urgency: str = "urgent"
    emergency: str | None = None
    escalate_if: str | None = None


ALARM_SOUNDING = r"\b(going off|went off|goes off|sounding|alarming|ringing|blaring|won'?t stop)\b"
CO_SYMPTOMS = (r"\b(headaches?|dizzy|dizziness|light-?headed|nause(a|ous)|vomit(ing)?|throwing up|sick|ill|"
               r"faint(ed|ing)?|passed out|pass out|drowsy|confused|short(ness)? of breath|can'?t breathe|"
               r"trouble breathing)\b")
GAS_WORD = r"\b(gas|propane|gassy)\b"
SMELL_WORD = r"\b(smell\w*|odou?r\w*|whiff|stinks?|stinking|hiss\w*)\b"

# Word-boundary matching throughout: "co" never matches "cook", "company" or "coworker".
SAFETY_CHECKS: list[SafetyCheck] = [
    SafetyCheck(
        "carbon_monoxide_mention", "hvac",
        r"\b(carbon monoxide|co (alarm|detector|monitor|sensor)s?|co (leak|levels?|poisoning|reading))\b",
        "Mentions carbon monoxide or a CO alarm.",
        "If the CO alarm is sounding, or anyone has a headache, feels dizzy, sick or very sleepy, get everyone "
        "(and pets) outside into fresh air now and call 911. If it only chirps once in a while, the battery may "
        "be low: don't remove it, we'll check it today.",
        emergency="carbon monoxide", escalate_if=ALARM_SOUNDING + "|" + CO_SYMPTOMS,
    ),
    SafetyCheck(
        "smoke_alarm_mention", "electrical", r"\b(smoke|fire) (alarm|detector)s?\b",
        "Mentions a smoke or fire alarm.",
        "If the alarm is sounding or you see or smell smoke, get everyone out and call 911. If it only chirps, "
        "the battery may be low: don't remove it, we'll check it today.",
        emergency="fire or sparks", escalate_if=ALARM_SOUNDING,
    ),
    SafetyCheck(
        "gas_mention", "plumbing",
        GAS_WORD + r"[^.!?\n]{0,40}" + SMELL_WORD + "|" + SMELL_WORD + r"[^.!?\n]{0,40}" + GAS_WORD,
        "Mentions gas together with a smell, leak or hissing.",
        "If you smell gas at any point, leave the home now and call 911 and the gas company from outside. "
        "Don't flip switches or light flames.",
        urgency="emergency", emergency="gas smell",
    ),
    SafetyCheck(
        "major_leak", "plumbing",
        r"\b(major|massive|huge|big|bad|serious|heavy) (water )?leak\w*|\bleaking (a lot|badly|everywhere|fast)\b",
        "Mentions a major water leak.",
        "If safe, shut off the main water valve or the valve behind the fixture, and stay away from water near "
        "outlets or appliances.",
    ),
    SafetyCheck(
        "exposed_wires", "electrical",
        r"\b(exposed|bare|live|frayed|hanging|loose|dangling) (electrical )?wir(es?|ing)\b"
        r"|\bwir(es?|ing) (is |are )?(exposed|hanging|sticking out|bare)\b"
        r"|\b(electric shock|shocked me|got (a )?shock|electrocuted)\b",
        "Mentions exposed wires or an electric shock.",
        "Keep everyone away and don't touch the wires or the outlet. If it's safe, switch off that circuit at "
        "the breaker panel.",
    ),
]
REVIEW_NOW = "needs a human to review now"


NEGATION = re.compile(
    r"\b(no|not|never|without|none|nothing|isn'?t|wasn'?t|aren'?t|weren'?t|don'?t|doesn'?t|didn'?t|"
    r"haven'?t|hasn'?t|no longer)\b"
)
CLAUSE_SPLIT = re.compile(r"[.;!?\n]+|,|\b(?:but|however|although|though|and|also|plus)\b")
FREEZING = re.compile(r"\b(freezing|below freezing|below zero|sub-?zero|snow(ing|storm)?|icy|frozen)\b")
TEMP = re.compile(r"(-?\d{1,3})\s*(?:°|degrees?|deg)\s*f?\b")


def _normalize(text: str) -> str:
    return text.replace("’", "'").replace("‘", "'").lower()


def _is_freezing(text: str, outdoor_temp_f: float | None) -> bool:
    if outdoor_temp_f is not None and outdoor_temp_f <= 32:
        return True
    if FREEZING.search(text):
        return True
    return any(int(m.group(1)) <= 32 for m in TEMP.finditer(text))


def triage(text: str, outdoor_temp_f: float | None = None, emergency_phone: str | None = None) -> dict:
    """Classify one maintenance request."""
    if not isinstance(text, str) or not text.strip():
        raise ValidationError("The maintenance request is empty. Paste what the tenant wrote.")
    norm = _normalize(text)
    freezing = _is_freezing(norm, outdoor_temp_f)
    matches: list[dict] = []
    ignored: list[dict] = []
    review: list[str] = []  # reasons a human must look at this now
    offset = 0
    clauses = []
    for part in CLAUSE_SPLIT.split(norm):
        if part is None:
            continue
        start = norm.find(part, offset)
        offset = start + len(part)
        clauses.append((start, part))
    for c_start, clause in clauses:
        consumed: list[tuple[int, int]] = []
        found: list[tuple[Rule, re.Match]] = []
        for rule in RULES:
            for m in re.finditer(rule.pattern, clause):
                if any(m.start() < e and s < m.end() for s, e in consumed):
                    continue
                consumed.append((m.start(), m.end()))
                found.append((rule, m))
        # Negation cues that are not part of a matched problem phrase ("no heat" is a problem, not a negation).
        protected = [(m.start(), m.end()) for r, m in found if not r.negatable]
        cue_ends = [n.end() for n in NEGATION.finditer(clause)
                    if not any(s <= n.start() < e for s, e in protected)]
        for rule, m in found:
            negated = rule.negatable and any(end <= m.start() for end in cue_ends)
            item = {"rule": rule.id, "category": rule.category, "text": m.group(0).strip(),
                    "position": c_start + m.start(), "end": c_start + m.end()}
            if negated:
                ignored.append({**item, "reason": "negated (e.g. 'no leak')"})
                if rule.emergency:  # fail safe: a negated danger word still gets a human to check
                    review.append(f"Mentions {rule.emergency}, but the tenant may have said it isn't happening: "
                                  "confirm with them.")
                    matches.append({**item, "rule": "safety_" + rule.id, "urgency": "urgent", "emergency": None,
                                    "safety": True})
                continue
            urgency, emergency = rule.urgency, rule.emergency
            if rule.id == "no_heat" and freezing:
                urgency, emergency = "emergency", "no heat in freezing weather"
            matches.append({**item, "urgency": urgency, "emergency": emergency})

    safety_tips: list[str] = []
    for check in SAFETY_CHECKS:
        for m in re.finditer(check.pattern, norm):
            c_start, clause = next((c for c in reversed(clauses) if c[0] <= m.start()), clauses[0])
            negated = any(c_start + n.end() <= m.start() for n in NEGATION.finditer(clause))
            urgency, emergency = check.urgency, (check.emergency if check.urgency == "emergency" else None)
            if check.escalate_if and re.search(check.escalate_if, norm):
                urgency, emergency = "emergency", check.emergency
            elif negated and urgency == "emergency":
                urgency, emergency = "urgent", None
            if check.reason not in review:
                review.append(check.reason)
            if urgency != "emergency" and check.instruction not in safety_tips:
                safety_tips.append(check.instruction)
            overlapping = [x for x in matches if x["position"] < m.end() and m.start() < x["end"]]
            if any(URGENCY_RANK[x["urgency"]] >= URGENCY_RANK[urgency]
                   and (x["emergency"] == emergency or emergency is None) for x in overlapping):
                continue  # a rule already covers these words at least as urgently
            matches.append({"rule": "safety_" + check.id, "category": check.category, "text": m.group(0).strip(),
                            "position": m.start(), "end": m.end(), "urgency": urgency, "emergency": emergency,
                            "safety": True})

    matches.sort(key=lambda x: x["position"])
    if matches:
        ordered = sorted(matches, key=lambda x: (-URGENCY_RANK[x["urgency"]], x["position"]))
        categories: list[str] = []
        for m in ordered:
            if m["category"] not in categories:
                categories.append(m["category"])
        urgency = ordered[0]["urgency"]
    else:
        categories, urgency = ["other"], "routine"
    emergencies: list[str] = []
    for m in sorted(matches, key=lambda x: x["position"]):
        if m["emergency"] and m["emergency"] not in emergencies:
            emergencies.append(m["emergency"])

    phone = emergency_phone or "[your 24/7 emergency maintenance line]"
    instructions: list[str] = []
    if emergencies:
        instructions += [EMERGENCY_INSTRUCTIONS[e] for e in emergencies]
        instructions += safety_tips
        instructions.append(f"Once you are safe, call our emergency maintenance line: {phone}.")
    elif urgency == "urgent":
        instructions += safety_tips
        instructions.append("We'll respond today and aim to repair within 24-48 hours.")
    else:
        instructions.append("We'll contact you to schedule a visit.")
    # Categories handled by an emergency get emergency instructions only (no "check the valve" tips for gas).
    covered = {m["category"] for m in matches if m["emergency"]}
    safety_covered = covered | {m["category"] for m in matches if m.get("safety")}
    for cat in categories:
        tip = CATEGORY_TIPS[cat]
        if cat not in safety_covered and tip not in instructions:
            instructions.append(tip)
    for e in emergencies:
        reason = f"Emergency: {e}."
        if reason not in review:
            review.insert(0, reason)

    vendors = [EMERGENCY_VENDORS[e] for e in emergencies]
    vendors += [VENDORS[c] for c in categories if c not in covered]
    questions: list[str] = ["Is everyone out of danger right now?"] if review else []
    for cat in categories:
        if cat not in covered:
            questions += QUESTIONS[cat]
    if "hvac" in categories and "no_heat" in {m["rule"] for m in matches} and outdoor_temp_f is None and not freezing:
        questions.append("What's the temperature outside and inside right now? (No heat in freezing weather is an emergency.)")
    questions += [q for q in GENERAL_QUESTIONS if not (emergencies and "times work best" in q)]
    return {
        "request": text.strip(),
        "category": categories[0],
        "categories": categories,
        "urgency": urgency,
        "emergency": bool(emergencies),
        "emergency_types": emergencies,
        "call_911": any(e in emergencies for e in
                        ("gas smell", "fire or sparks", "carbon monoxide", "security breach", "structural collapse")),
        "tenant_instructions": instructions,
        "vendor_types": vendors,
        "questions_for_tenant": questions,
        "sla": SLA[urgency],
        "matched": [{k: m[k] for k in ("rule", "category", "urgency", "text")} for m in matches],
        "ignored_negated": [{k: m[k] for k in ("rule", "text", "reason")} for m in ignored],
        "needs_human_review": not matches or bool(review),
        "review_now": bool(review),
        "review_reasons": review,
        "sla_note": SLA["_note"],
    }


def triage_report(res: dict) -> Report:
    title = "EMERGENCY maintenance request" if res["emergency"] else "Maintenance request triage"
    rep = Report(title)
    rep.kv("Summary", [
        ("Category", res["category"] + (f" (also: {', '.join(res['categories'][1:])})" if len(res["categories"]) > 1 else "")),
        ("Urgency", res["urgency"].upper()),
        ("Emergency type", ", ".join(res["emergency_types"]) or "none"),
        ("Call 911 first", "YES" if res["call_911"] else "no"),
        ("Target response", res["sla"]),
        ("Needs human review", f"YES, {REVIEW_NOW}" if res["review_now"]
         else ("yes" if res["needs_human_review"] else "no")),
    ])
    if res["review_now"]:
        rep.bullets("Why a human must review this now", res["review_reasons"])
    rep.bullets("Tell the tenant now", res["tenant_instructions"])
    rep.bullets("Send this vendor type", res["vendor_types"])
    rep.bullets("Ask the tenant", res["questions_for_tenant"])
    rep.table("Why (matched words)", ["Rule", "Category", "Urgency", "Words"],
              [[m["rule"], m["category"], m["urgency"], m["text"]] for m in res["matched"]])
    if res["ignored_negated"]:
        rep.table("Ignored (negated)", ["Rule", "Words"], [[m["rule"], m["text"]] for m in res["ignored_negated"]])
    rep.bullets("Note", [res["sla_note"]])
    return rep


TEXT_COLUMNS = ("text", "request", "description", "message")


def triage_csv(csv_text: str, emergency_phone: str | None = None) -> dict:
    """Triage every row of a CSV. Needs a 'text' column; optional 'id' and 'outdoor_temp_f'."""
    reader = csv.DictReader(io.StringIO(csv_text))
    if not reader.fieldnames:
        raise ValidationError("The CSV file is empty. It needs a header row with a 'text' column.")
    fields = {f.strip().lower(): f for f in reader.fieldnames if f}
    text_col = next((fields[c] for c in TEXT_COLUMNS if c in fields), None)
    if text_col is None:
        raise ValidationError(f"The CSV needs a column named 'text' (found: {', '.join(reader.fieldnames)}).")
    id_col = fields.get("id")
    temp_col = fields.get("outdoor_temp_f")
    results, problems = [], []
    for n, row in enumerate(reader, start=1):
        text = (row.get(text_col) or "").strip()
        row_id = (row.get(id_col) or "").strip() if id_col else str(n)
        if not text:
            problems.append(f"Row {n} (id {row_id or n}): empty request text, skipped.")
            continue
        temp = None
        if temp_col and (row.get(temp_col) or "").strip():
            try:
                temp = float(row[temp_col])
            except ValueError:
                problems.append(f"Row {n}: outdoor_temp_f {row[temp_col]!r} is not a number, ignored.")
        res = triage(text, outdoor_temp_f=temp, emergency_phone=emergency_phone)
        res["id"] = row_id or str(n)
        results.append(res)
    results.sort(key=lambda r: -URGENCY_RANK[r["urgency"]])  # stable: keeps file order within a level
    counts = {u: sum(r["urgency"] == u for r in results) for u in ("emergency", "urgent", "routine")}
    return {"count": len(results), "counts": counts, "results": results, "problems": problems}


def batch_report(res: dict) -> Report:
    c = res["counts"]
    rep = Report("Maintenance queue", f"{res['count']} requests: {c['emergency']} emergency, "
                 f"{c['urgent']} urgent, {c['routine']} routine")
    rep.table("Queue (most urgent first)", ["ID", "Urgency", "Category", "Vendor", "Request"], [
        [r["id"], r["urgency"].upper() + (" (review now)" if r["review_now"] else ""), "/".join(r["categories"]),
         r["vendor_types"][0],
         r["request"][:60] + ("..." if len(r["request"]) > 60 else "")] for r in res["results"]])
    if res["problems"]:
        rep.bullets("Problems", res["problems"])
    return rep
