"""Real estate investor pack: buy-and-hold rental, fix-and-flip, and BRRRR deal analyzers."""
from __future__ import annotations

from .common import Field, Report, money, num, parse_fields, pct, r2, safe_div, yes_no

RULES_OF_THUMB = {
    "_note": "Rules of thumb for quick screening only. Verify taxes, insurance, rents and loan terms locally.",
    "one_percent_rule": 1.0,  # monthly rent >= 1% of price (+ rehab)
    "fifty_percent_rule": 50.0,  # operating expenses ~= 50% of rent (excluding mortgage)
    "flip_mao_pct": 70.0,  # max allowable offer = ARV x 70% - repairs
    "min_dscr": 1.25,  # common DSCR lender minimum (verify with lender)
}


def mortgage_payment(principal: float, annual_rate_pct: float, years: float) -> float:
    """Monthly principal & interest payment (standard amortization formula).

    P = L * r / (1 - (1 + r) ** -n), r = annual rate / 12, n = years * 12. Zero rate -> L / n.
    """
    if principal <= 0:
        return 0.0
    n = round(years * 12)
    if n <= 0:
        raise ValueError("loan term must be at least 1 month")
    r = annual_rate_pct / 100 / 12
    if r == 0:
        return principal / n
    return principal * r / (1 - (1 + r) ** -n)


# Operating inputs shared by rental and BRRRR.
OPERATING_FIELDS = [
    Field("monthly_rent", "float", required=True, help="total monthly rent"),
    Field("other_monthly_income", "float", default=0.0, help="laundry, parking, pet fees"),
    Field("vacancy_pct", "pct", default=5.0, help="percent of rent lost to vacancy"),
    Field("capex_pct", "pct", default=5.0, help="capital expenditure reserve, percent of rent"),
    Field("repairs_pct", "pct", default=5.0, help="repairs & maintenance, percent of rent"),
    Field("management_pct", "pct", default=8.0, help="property management, percent of rent"),
    Field("property_tax_annual", "float", default=0.0),
    Field("insurance_annual", "float", default=0.0),
    Field("hoa_monthly", "float", default=0.0),
    Field("utilities_monthly", "float", default=0.0, help="utilities the owner pays"),
    Field("other_monthly_expenses", "float", default=0.0),
]


def _operating(d: dict) -> dict:
    """Monthly operating numbers. Percentages apply to gross scheduled income (rent + other income)."""
    gross = d["monthly_rent"] + d["other_monthly_income"]
    vacancy = gross * d["vacancy_pct"] / 100
    egi = gross - vacancy
    expenses = {
        "property_tax": d["property_tax_annual"] / 12,
        "insurance": d["insurance_annual"] / 12,
        "hoa": d["hoa_monthly"],
        "utilities": d["utilities_monthly"],
        "capex_reserve": gross * d["capex_pct"] / 100,
        "repairs": gross * d["repairs_pct"] / 100,
        "management": gross * d["management_pct"] / 100,
        "other": d["other_monthly_expenses"],
    }
    opex = sum(expenses.values())
    return {"gross": gross, "vacancy": vacancy, "egi": egi, "expenses": expenses, "opex": opex, "noi": egi - opex}


RENTAL_FIELDS = [
    Field("purchase_price", "float", required=True),
    Field("down_payment_pct", "pct", default=20.0, help="down payment percent"),
    Field("interest_rate_pct", "pct", required=True, help="annual interest rate percent, e.g. 7"),
    Field("loan_term_years", "float", default=30.0, min=1, max=50),
    Field("closing_costs", "float", default=0.0),
    Field("rehab_costs", "float", default=0.0),
] + OPERATING_FIELDS


def analyze_rental(data: dict) -> dict:
    d = parse_fields(data, RENTAL_FIELDS, "rental input")
    notes: list[str] = []
    price = d["purchase_price"]
    down = price * d["down_payment_pct"] / 100
    loan = price - down
    payment = mortgage_payment(loan, d["interest_rate_pct"], d["loan_term_years"])
    op = _operating(d)
    noi_annual = op["noi"] * 12
    debt_annual = payment * 12
    cash_flow = op["noi"] - payment
    cash_invested = down + d["closing_costs"] + d["rehab_costs"]
    cap = safe_div(noi_annual, price, notes, "Cap rate can't be calculated: purchase price is $0 (division by zero).")
    coc = safe_div(cash_flow * 12, cash_invested, notes,
                   "Cash-on-cash return can't be calculated: total cash invested is $0 (division by zero).")
    dscr = safe_div(noi_annual, debt_annual, notes, "DSCR isn't applicable: there is no loan payment (division by zero).")
    grm = safe_div(price, d["monthly_rent"] * 12, notes, "GRM can't be calculated: rent is $0 (division by zero).")
    basis = price + d["rehab_costs"]
    rent_ratio = safe_div(d["monthly_rent"], basis, notes,
                          "1% rule can't be checked: price plus rehab is $0 (division by zero).")
    fifty_cf = d["monthly_rent"] * (1 - RULES_OF_THUMB["fifty_percent_rule"] / 100) - payment
    if dscr is not None and dscr < RULES_OF_THUMB["min_dscr"]:
        notes.append(f"DSCR {dscr:.2f} is below {RULES_OF_THUMB['min_dscr']}, a common lender minimum (verify with lender).")
    if cash_flow < 0:
        notes.append("This deal loses money every month at these numbers.")
    notes.append(RULES_OF_THUMB["_note"])
    return {
        "loan_amount": r2(loan),
        "down_payment": r2(down),
        "monthly_mortgage_payment": r2(payment),
        "gross_monthly_income": r2(op["gross"]),
        "vacancy_loss_monthly": r2(op["vacancy"]),
        "effective_gross_income_monthly": r2(op["egi"]),
        "operating_expenses_monthly": r2(op["opex"]),
        "expense_breakdown_monthly": {k: r2(v) for k, v in op["expenses"].items()},
        "noi_monthly": r2(op["noi"]),
        "noi_annual": r2(noi_annual),
        "annual_debt_service": r2(debt_annual),
        "cash_flow_monthly": r2(cash_flow),
        "cash_flow_annual": r2(cash_flow * 12),
        "total_cash_invested": r2(cash_invested),
        "cap_rate_pct": r2(None if cap is None else cap * 100),
        "cash_on_cash_pct": r2(None if coc is None else coc * 100),
        "dscr": r2(dscr),
        "grm": r2(grm),
        "one_percent_rule": {"rent_to_price_pct": r2(None if rent_ratio is None else rent_ratio * 100),
                             "passes": None if rent_ratio is None else rent_ratio * 100 >= RULES_OF_THUMB["one_percent_rule"]},
        "fifty_percent_rule": {"estimated_cash_flow_monthly": r2(fifty_cf), "passes": fifty_cf > 0},
        "notes": notes,
    }


def rental_report(res: dict) -> Report:
    rep = Report("Rental property analysis")
    rep.kv("Financing", [("Loan amount", money(res["loan_amount"])), ("Down payment", money(res["down_payment"])),
                         ("Monthly P&I", money(res["monthly_mortgage_payment"])),
                         ("Total cash invested", money(res["total_cash_invested"]))])
    rep.kv("Monthly", [("Gross income", money(res["gross_monthly_income"])),
                       ("Vacancy", money(-res["vacancy_loss_monthly"])),
                       ("Operating expenses", money(-res["operating_expenses_monthly"])),
                       ("NOI", money(res["noi_monthly"])),
                       ("Mortgage", money(-res["monthly_mortgage_payment"])),
                       ("Cash flow", money(res["cash_flow_monthly"]))])
    one, fifty = res["one_percent_rule"], res["fifty_percent_rule"]
    rep.kv("Returns & ratios", [
        ("NOI (annual)", money(res["noi_annual"])), ("Cash flow (annual)", money(res["cash_flow_annual"])),
        ("Cap rate", pct(res["cap_rate_pct"])), ("Cash-on-cash", pct(res["cash_on_cash_pct"])),
        ("DSCR", num(res["dscr"])), ("GRM", num(res["grm"])),
        ("1% rule", f"{pct(one['rent_to_price_pct'])} -> {'pass' if one['passes'] else 'fail' if one['passes'] is not None else 'n/a'}"),
        ("50% rule cash flow", f"{money(fifty['estimated_cash_flow_monthly'])} -> {'pass' if fifty['passes'] else 'fail'}"),
    ])
    rep.bullets("Notes", res["notes"])
    return rep


FLIP_FIELDS = [
    Field("arv", "float", required=True, help="after-repair value"),
    Field("purchase_price", "float", required=True),
    Field("rehab_costs", "float", default=0.0),
    Field("buy_closing_costs", "float", default=0.0),
    Field("holding_months", "float", default=6.0, help="months from purchase to sale"),
    Field("holding_costs_monthly", "float", default=0.0, help="taxes, insurance, utilities per month"),
    Field("loan_amount", "float", default=0.0, help="hard-money / private loan amount"),
    Field("loan_rate_pct", "pct", default=0.0, help="annual interest (interest-only)"),
    Field("loan_points_pct", "pct", default=0.0, help="lender points, percent of loan"),
    Field("selling_costs_pct", "pct", default=8.0, help="agent commissions + closing, percent of ARV"),
    Field("mao_rule_pct", "pct", default=RULES_OF_THUMB["flip_mao_pct"], help="max allowable offer rule percent"),
]


def analyze_flip(data: dict) -> dict:
    d = parse_fields(data, FLIP_FIELDS, "flip input")
    notes: list[str] = []
    arv, months = d["arv"], d["holding_months"]
    mao = arv * d["mao_rule_pct"] / 100 - d["rehab_costs"]
    holding = d["holding_costs_monthly"] * months
    points = d["loan_amount"] * d["loan_points_pct"] / 100
    interest = d["loan_amount"] * d["loan_rate_pct"] / 100 / 12 * months
    financing = points + interest
    selling = arv * d["selling_costs_pct"] / 100
    total_cost = d["purchase_price"] + d["buy_closing_costs"] + d["rehab_costs"] + holding + financing + selling
    profit = arv - total_cost
    cash_invested = d["purchase_price"] + d["buy_closing_costs"] + d["rehab_costs"] + holding + financing - d["loan_amount"]
    roi = None
    if cash_invested <= 0:
        notes.append("ROI can't be calculated: the loan covers all costs, so your cash invested is $0 or less.")
    else:
        roi = profit / cash_invested * 100
    annualized = None
    if roi is not None:
        if months <= 0:
            notes.append("Annualized ROI can't be calculated: holding period is 0 months (division by zero).")
        else:
            annualized = roi * 12 / months
    meets = d["purchase_price"] <= mao
    if not meets:
        notes.append(f"Purchase price is {money(d['purchase_price'] - mao)} above the {d['mao_rule_pct']:g}% rule offer.")
    if profit < 0:
        notes.append("This flip loses money at these numbers.")
    notes.append("Annualized ROI is simple (ROI x 12 / months), not compounded.")
    return {
        "arv": r2(arv),
        "max_allowable_offer": r2(mao),
        "meets_mao_rule": meets,
        "holding_costs": r2(holding),
        "financing_costs": r2(financing),
        "selling_costs": r2(selling),
        "total_project_cost": r2(total_cost),
        "profit": r2(profit),
        "cash_invested": r2(cash_invested),
        "roi_pct": r2(roi),
        "annualized_roi_pct": r2(annualized),
        "notes": notes,
    }


def flip_report(res: dict) -> Report:
    rep = Report("Fix-and-flip analysis")
    rep.kv("Deal", [("ARV", money(res["arv"])), ("Max allowable offer", money(res["max_allowable_offer"])),
                    ("Meets offer rule", yes_no(res["meets_mao_rule"])),
                    ("Holding costs", money(res["holding_costs"])), ("Financing costs", money(res["financing_costs"])),
                    ("Selling costs", money(res["selling_costs"])), ("Total project cost", money(res["total_project_cost"])),
                    ("Profit", money(res["profit"])), ("Cash invested", money(res["cash_invested"])),
                    ("ROI", pct(res["roi_pct"])), ("Annualized ROI", pct(res["annualized_roi_pct"]))])
    rep.bullets("Notes", res["notes"])
    return rep


BRRRR_FIELDS = [
    Field("purchase_price", "float", required=True),
    Field("rehab_costs", "float", default=0.0),
    Field("buy_closing_costs", "float", default=0.0),
    Field("holding_costs", "float", default=0.0, help="total holding costs until refinance"),
    Field("initial_loan_amount", "float", default=0.0, help="purchase/rehab loan paid off at refinance"),
    Field("arv", "float", required=True, help="after-repair value (appraisal)"),
    Field("refi_ltv_pct", "pct", default=75.0, help="refinance loan-to-value percent"),
    Field("refi_closing_costs", "float", default=0.0),
    Field("refi_rate_pct", "pct", required=True, help="refinance interest rate percent"),
    Field("refi_term_years", "float", default=30.0, min=1, max=50),
] + OPERATING_FIELDS


def analyze_brrrr(data: dict) -> dict:
    d = parse_fields(data, BRRRR_FIELDS, "BRRRR input")
    notes: list[str] = []
    all_in = d["purchase_price"] + d["rehab_costs"] + d["buy_closing_costs"] + d["holding_costs"]
    initial_cash = all_in - d["initial_loan_amount"]
    refi_loan = d["arv"] * d["refi_ltv_pct"] / 100
    cash_out = refi_loan - d["refi_closing_costs"] - d["initial_loan_amount"]
    cash_left = initial_cash - cash_out
    payment = mortgage_payment(refi_loan, d["refi_rate_pct"], d["refi_term_years"])
    op = _operating(d)
    cash_flow = op["noi"] - payment
    infinite = cash_left <= 0
    coc = None
    if infinite:
        notes.append("Infinite return: the refinance pulled out all of your cash, so cash-on-cash can't be calculated "
                     "(nothing left in the deal to divide by).")
    else:
        coc = cash_flow * 12 / cash_left * 100
    if cash_out < 0:
        notes.append(f"The refinance doesn't cover the original loan: you'd bring {money(-cash_out)} to closing.")
    dscr = safe_div(op["noi"] * 12, payment * 12, notes, "DSCR isn't applicable: there is no loan payment (division by zero).")
    if cash_flow < 0:
        notes.append("Negative cash flow after the refinance at these numbers.")
    notes.append("Lenders may limit cash-out by seasoning period or cost basis; verify refinance terms with your lender.")
    return {
        "all_in_cost": r2(all_in),
        "initial_cash_invested": r2(initial_cash),
        "refi_loan_amount": r2(refi_loan),
        "cash_out_at_refi": r2(cash_out),
        "cash_left_in_deal": r2(cash_left),
        "infinite_return": infinite,
        "equity_after_refi": r2(d["arv"] - refi_loan),
        "monthly_mortgage_payment": r2(payment),
        "noi_monthly": r2(op["noi"]),
        "cash_flow_monthly": r2(cash_flow),
        "cash_flow_annual": r2(cash_flow * 12),
        "cash_on_cash_pct": r2(coc),
        "dscr": r2(dscr),
        "notes": notes,
    }


def brrrr_report(res: dict) -> Report:
    rep = Report("BRRRR analysis")
    rep.kv("Refinance", [("All-in cost", money(res["all_in_cost"])),
                         ("Initial cash invested", money(res["initial_cash_invested"])),
                         ("Refinance loan", money(res["refi_loan_amount"])),
                         ("Cash out at refinance", money(res["cash_out_at_refi"])),
                         ("Cash left in deal", money(res["cash_left_in_deal"])),
                         ("Infinite return", yes_no(res["infinite_return"])),
                         ("Equity after refinance", money(res["equity_after_refi"]))])
    rep.kv("After refinance (monthly)", [("Mortgage P&I", money(res["monthly_mortgage_payment"])),
                                         ("NOI", money(res["noi_monthly"])),
                                         ("Cash flow", money(res["cash_flow_monthly"])),
                                         ("Cash flow (annual)", money(res["cash_flow_annual"])),
                                         ("Cash-on-cash", pct(res["cash_on_cash_pct"])),
                                         ("DSCR", num(res["dscr"]))])
    rep.bullets("Notes", res["notes"])
    return rep
