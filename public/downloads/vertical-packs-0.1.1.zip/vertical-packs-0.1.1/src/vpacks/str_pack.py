"""Short-term rental (Airbnb / VRBO) pack: listing score, revenue & P&L, guest messages."""
from __future__ import annotations

import re

from .common import Field, Report, ValidationError, money, num, parse_fields, pct, r2, safe_div

# Platform rules change. Every number here is a heuristic or a published limit at time of writing.
STR_LIMITS = {
    "_note": "Verify current limits in Airbnb's listing editor and help center; platforms change them.",
    "title_max_chars": 50,  # Airbnb listing title limit (verify current limit)
    "title_min_good_chars": 20,
    "description_min_chars": 150,
    "description_good_chars": 400,
    "photos_good": 20,
    "photos_ok": 10,
    "photos_min": 5,
    "response_rate_good_pct": 90,
    "response_rate_ok_pct": 75,
    "rating_good": 4.8,
    "rating_ok": 4.5,
    "reviews_established": 10,
    "reviews_new_listing": 5,
    "default_platform_fee_pct": 3.0,  # Airbnb split-fee host fee (verify; host-only fee is ~15%)
}

CORE_AMENITIES = [
    "wifi", "kitchen", "washer", "dryer", "air conditioning", "heating", "free parking",
    "smoke alarm", "carbon monoxide alarm", "self check-in", "coffee maker", "dedicated workspace",
]
SAFETY_AMENITIES = {"smoke alarm", "carbon monoxide alarm"}
MARKET_AMENITIES = {
    "general": [],
    "beach": ["beach access", "beach gear", "outdoor shower", "patio or balcony", "pool"],
    "mountain": ["fireplace", "hot tub", "ski storage", "grill", "patio or balcony"],
    "lake": ["waterfront", "kayak", "fire pit", "grill", "dock"],
    "urban": ["elevator", "gym", "ev charger"],
    "rural": ["fire pit", "grill", "outdoor dining area", "board games"],
    "desert": ["pool", "hot tub", "outdoor dining area", "fire pit"],
}
AMENITY_ALIASES = {
    "wifi": ["wifi", "wi-fi", "wireless internet", "internet"],
    "air conditioning": ["air conditioning", "ac", "a/c", "central air"],
    "heating": ["heating", "heat", "central heating", "heater"],
    "free parking": ["free parking", "parking", "driveway", "garage"],
    "smoke alarm": ["smoke alarm", "smoke detector"],
    "carbon monoxide alarm": ["carbon monoxide alarm", "carbon monoxide detector", "co alarm", "co detector"],
    "self check-in": ["self check-in", "self checkin", "self check in", "keypad", "smart lock", "lockbox"],
    "washer": ["washer", "washing machine", "laundry"],
    "dryer": ["dryer", "laundry"],
    "kitchen": ["kitchen", "kitchenette"],
    "coffee maker": ["coffee maker", "coffee", "espresso machine", "keurig", "nespresso"],
    "dedicated workspace": ["dedicated workspace", "workspace", "desk", "office"],
    "hot tub": ["hot tub", "jacuzzi", "spa"],
    "patio or balcony": ["patio", "balcony", "deck", "terrace"],
    "beach gear": ["beach gear", "beach chairs", "beach umbrella", "beach towels"],
    "beach access": ["beach access", "beachfront", "private beach"],
    "fire pit": ["fire pit", "firepit"],
    "grill": ["grill", "bbq", "barbecue"],
    "kayak": ["kayak", "kayaks", "canoe", "paddle board", "paddleboard"],
    "waterfront": ["waterfront", "lakefront", "lake access"],
    "ev charger": ["ev charger", "ev charging"],
    "fireplace": ["fireplace", "wood stove"],
    "outdoor dining area": ["outdoor dining area", "outdoor dining", "picnic table"],
}
MARKET_TYPES = tuple(MARKET_AMENITIES)

DESCRIPTION_TOPICS = {
    "the space (beds, bedrooms, who it sleeps)": [r"\bbeds?\b", r"\bbedrooms?\b", r"\bsleeps\b", r"\bking\b", r"\bqueen\b"],
    "the location and what's nearby": [r"\bwalk", r"\bminutes?\b", r"\bnear", r"\bdowntown\b", r"\bclose to\b", r"\bmiles?\b", r"\bblocks?\b"],
    "arrival, access and parking": [r"check-?in", r"\bparking\b", r"\bself check", r"\baccess\b", r"\bkeypad\b", r"\bsmart lock\b"],
}

PRIORITY_RANK = {"high": 0, "medium": 1, "low": 2}

LISTING_FIELDS = [
    Field("title", "str", required=True, help="the listing title"),
    Field("description", "str", default=""),
    Field("photos", "count", default=0, help="number of photos, or a list of photo URLs"),
    Field("amenities", "strlist", default=list),
    Field("market_type", "str", default="general", help="one of " + ", ".join(MARKET_TYPES)),
    Field("response_rate_pct", "pct"),
    Field("rating", "float", min=0, max=5),
    Field("review_count", "int", default=0),
]


def _has_amenity(amenity: str, listed: list[str]) -> bool:
    aliases = AMENITY_ALIASES.get(amenity, [amenity])
    for item in listed:
        text = item.lower().strip()
        for alias in aliases:
            if re.search(r"(?<![\w-])" + re.escape(alias) + r"(?![\w-])", text):
                return True
    return False


def wanted_amenities(market_type: str) -> list[str]:
    seen: list[str] = []
    for a in CORE_AMENITIES + MARKET_AMENITIES[market_type]:
        if a not in seen:
            seen.append(a)
    return seen


def score_listing(data: dict) -> dict:
    d = parse_fields(data, LISTING_FIELDS, "listing")
    market = d["market_type"].lower()
    if market not in MARKET_AMENITIES:
        raise ValidationError(f"'market_type' must be one of: {', '.join(MARKET_TYPES)} (got {d['market_type']!r}).")
    L = STR_LIMITS
    breakdown: list[dict] = []
    fixes: list[dict] = []

    def fix(priority: str, area: str, at_stake: int, text: str) -> None:
        fixes.append({"priority": priority, "area": area, "points_at_stake": at_stake, "fix": text})

    # Title (15)
    title = d["title"]
    tlen = len(title)
    if tlen == 0:
        t_pts = 0
        fix("high", "Title", 15, "Add a title. Lead with your best feature (view, hot tub, walk to beach).")
    elif tlen > L["title_max_chars"]:
        t_pts = 0
        fix("high", "Title", 15,
            f"Shorten the title to {L['title_max_chars']} characters or fewer (now {tlen}); Airbnb cuts or rejects longer "
            "titles (verify current limit).")
    elif tlen < L["title_min_good_chars"]:
        t_pts = 8
        fix("medium", "Title", 7,
            f"Use more of the {L['title_max_chars']} characters (now {tlen}): add your top feature and location.")
    else:
        t_pts = 15
    letters = [c for c in title if c.isalpha()]
    if t_pts and len(letters) > 10 and sum(c.isupper() for c in letters) / len(letters) > 0.7:
        t_pts -= 5
        fix("low", "Title", 5, "Avoid ALL CAPS in the title; it reads as spammy.")
    breakdown.append({"area": "Title", "points": t_pts, "max": 15, "detail": f"{tlen} characters"})

    # Description (20)
    desc = d["description"]
    dlen = len(desc)
    if dlen == 0:
        base = 0
    elif dlen < L["description_min_chars"]:
        base = 5
    elif dlen < L["description_good_chars"]:
        base = 12
    else:
        base = 20
    if dlen < L["description_good_chars"]:
        fix("high" if dlen < L["description_min_chars"] else "medium", "Description", 20 - base,
            f"Write a fuller description: aim for {L['description_good_chars']}+ characters (now {dlen}).")
    missing_topics = []
    lower = desc.lower()
    for topic, patterns in DESCRIPTION_TOPICS.items():
        if not any(re.search(p, lower) for p in patterns):
            missing_topics.append(topic)
    d_pts = max(0, base - 2 * len(missing_topics)) if base else 0
    for topic in missing_topics:
        fix("low", "Description", 2, f"Describe {topic}.")
    breakdown.append({"area": "Description", "points": d_pts, "max": 20,
                      "detail": f"{dlen} characters, missing topics: {len(missing_topics)}"})

    # Photos (15)
    photos = d["photos"]
    if photos >= L["photos_good"]:
        p_pts = 15
    elif photos >= L["photos_ok"]:
        p_pts = 10
    elif photos >= L["photos_min"]:
        p_pts = 5
    else:
        p_pts = 0
    if p_pts < 15:
        fix("high" if photos < L["photos_ok"] else "medium", "Photos", 15 - p_pts,
            f"Add photos: aim for {L['photos_good']}+ (now {photos}), including every bedroom, bathroom and the view.")
    breakdown.append({"area": "Photos", "points": p_pts, "max": 15, "detail": f"{photos} photos"})

    # Amenities (25)
    wanted = wanted_amenities(market)
    present = [a for a in wanted if _has_amenity(a, d["amenities"])]
    missing = [a for a in wanted if a not in present]
    a_pts = round(25 * len(present) / len(wanted))
    missing_safety = [a for a in missing if a in SAFETY_AMENITIES]
    other_missing = [a for a in missing if a not in SAFETY_AMENITIES]
    if missing_safety:
        fix("high", "Amenities", 0,
            "Install and list: " + ", ".join(missing_safety) + " (guest safety; often legally required).")
    if other_missing:
        fix("medium", "Amenities", 25 - a_pts,
            f"Add or list amenities guests filter for in a {market} market: " + ", ".join(other_missing[:6]) + ".")
    breakdown.append({"area": "Amenities", "points": a_pts, "max": 25,
                      "detail": f"{len(present)} of {len(wanted)} key amenities"})

    # Response rate (10)
    rr = d["response_rate_pct"]
    if rr is None:
        r_pts = 5
        fix("low", "Response rate", 5, "No response rate yet: turn on app notifications and reply within an hour.")
    elif rr >= L["response_rate_good_pct"]:
        r_pts = 10
    elif rr >= L["response_rate_ok_pct"]:
        r_pts = 6
        fix("medium", "Response rate", 4, f"Raise response rate to {L['response_rate_good_pct']}%+ (now {rr:g}%): use saved replies.")
    else:
        r_pts = 2
        fix("high", "Response rate", 8, f"Response rate is {rr:g}%: reply to every inquiry, even ones you decline.")
    breakdown.append({"area": "Response rate", "points": r_pts, "max": 10,
                      "detail": "not available" if rr is None else f"{rr:g}%"})

    # Reviews (15)
    rating, count = d["rating"], d["review_count"]
    if rating is None or count == 0:
        rv_pts = 5
        fix("medium", "Reviews", 10,
            f"Get your first {L['reviews_new_listing']} reviews: price slightly below the market and ask every guest.")
    else:
        if rating >= L["rating_good"]:
            rv_pts = 10
        elif rating >= L["rating_ok"]:
            rv_pts = 6
            fix("medium", "Reviews", 4, f"Rating {rating:g}: read the 4-star reviews and fix what they mention.")
        else:
            rv_pts = 2
            fix("high", "Reviews", 8, f"Rating {rating:g} is below {L['rating_ok']}: fix cleanliness/accuracy issues first.")
        if count >= L["reviews_established"]:
            rv_pts += 5
        elif count >= L["reviews_new_listing"]:
            rv_pts += 3
            fix("low", "Reviews", 2, f"Keep asking for reviews ({count} so far); {L['reviews_established']}+ builds trust.")
        else:
            rv_pts += 1
            fix("medium", "Reviews", 4, f"Only {count} reviews: send a review request after every stay.")
    breakdown.append({"area": "Reviews", "points": rv_pts, "max": 15,
                      "detail": "no reviews yet" if rating is None or count == 0 else f"{rating:g} stars, {count} reviews"})

    score = sum(b["points"] for b in breakdown)
    if score >= 85:
        grade = "Strong"
    elif score >= 70:
        grade = "Good"
    elif score >= 50:
        grade = "Needs work"
    else:
        grade = "Weak"
    fixes.sort(key=lambda f: (PRIORITY_RANK[f["priority"]], -f["points_at_stake"]))
    return {
        "title": title,
        "market_type": market,
        "score": score,
        "max_score": 100,
        "grade": grade,
        "breakdown": breakdown,
        "fixes": fixes,
        "amenities_present": present,
        "amenities_missing": missing,
        "limits_note": STR_LIMITS["_note"],
    }


def listing_report(res: dict) -> Report:
    rep = Report("Listing score", f"{res['title']!r} ({res['market_type']} market)")
    rep.kv("Summary", [("Score", f"{res['score']} / {res['max_score']}"), ("Grade", res["grade"])])
    rep.table("Breakdown", ["Area", "Points", "Max", "Detail"],
              [[b["area"], b["points"], b["max"], b["detail"]] for b in res["breakdown"]])
    rep.table("Fixes, most important first", ["Priority", "Area", "Fix"],
              [[f["priority"], f["area"], f["fix"]] for f in res["fixes"]])
    rep.bullets("Note", [res["limits_note"]])
    return rep


# --------------------------------------------------------------------------- revenue
DAYS_IN_MONTH = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]
MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]

REVENUE_FIELDS = [
    Field("adr", "float", required=True, help="average daily (nightly) rate in dollars"),
    Field("occupancy_pct", "pct", required=True, help="expected occupancy, percent (65 = 65%)"),
    Field("avg_stay_nights", "float", default=3.0, min=0.5, help="average nights per booking"),
    Field("cleaning_fee", "float", default=0.0, help="cleaning fee charged to the guest per stay"),
    Field("cleaning_cost", "float", default=0.0, help="what you pay your cleaner per stay"),
    Field("platform_fee_pct", "pct", default=STR_LIMITS["default_platform_fee_pct"], help="host platform fee percent"),
    Field("management_pct", "pct", default=0.0, help="co-host / manager fee percent of gross"),
    Field("owner_blocked_nights_per_month", "float", default=0.0, max=31, help="nights you block for yourself each month"),
    Field("seasonality", "floatlist", help="12 monthly occupancy multipliers, Jan..Dec (1.0 = average)"),
    Field("monthly_costs", "moneydict", default=dict, help="fixed monthly costs, e.g. mortgage=1500,utilities=250"),
]


def estimate_revenue(data: dict) -> dict:
    d = parse_fields(data, REVENUE_FIELDS, "revenue input")
    season = d["seasonality"] or [1.0] * 12
    if len(season) != 12:
        raise ValidationError(f"'seasonality' needs exactly 12 numbers, one per month (got {len(season)}).")
    occ = d["occupancy_pct"] / 100
    pf, mg = d["platform_fee_pct"] / 100, d["management_pct"] / 100
    stay = d["avg_stay_nights"]
    fixed = sum(d["monthly_costs"].values())
    notes: list[str] = []
    months = []
    totals = dict.fromkeys(["available_nights", "booked_nights", "stays", "rental_income", "cleaning_income",
                            "gross_revenue", "platform_fees", "management_fees", "cleaning_costs", "fixed_costs",
                            "net_income"], 0.0)
    for i, days in enumerate(DAYS_IN_MONTH):
        available = max(0.0, days - d["owner_blocked_nights_per_month"])
        booked = min(available, available * occ * season[i])
        stays = booked / stay
        rental = booked * d["adr"]
        cleaning_income = stays * d["cleaning_fee"]
        gross = rental + cleaning_income
        platform = gross * pf
        management = gross * mg
        cleaning = stays * d["cleaning_cost"]
        net = gross - platform - management - cleaning - fixed
        row = {"month": MONTHS[i], "available_nights": available, "booked_nights": booked, "stays": stays,
               "rental_income": rental, "cleaning_income": cleaning_income, "gross_revenue": gross,
               "platform_fees": platform, "management_fees": management, "cleaning_costs": cleaning,
               "fixed_costs": fixed, "net_income": net}
        for k in totals:
            totals[k] += row[k]
        months.append({k: (r2(v) if isinstance(v, float) else v) for k, v in row.items()})
    if any(s * occ > 1 for s in season):
        notes.append("Some months were capped at 100% occupancy (seasonality x occupancy was above 100%).")

    contribution = (d["adr"] + d["cleaning_fee"] / stay) * (1 - pf - mg) - d["cleaning_cost"] / stay
    annual_fixed = fixed * 12
    if annual_fixed == 0:
        breakeven = 0.0
    elif contribution <= 0:
        breakeven = None
        notes.append("Break-even occupancy can't be calculated: each booked night loses money after fees and cleaning.")
    else:
        be_nights = annual_fixed / contribution
        share = safe_div(be_nights, totals["available_nights"], notes,
                         "Break-even occupancy can't be calculated: there are no available nights (division by zero).")
        breakeven = None if share is None else share * 100
        if breakeven is not None and breakeven > 100:
            notes.append("Break-even occupancy is above 100%: this property can't cover its fixed costs at this rate.")
    if d["platform_fee_pct"] == STR_LIMITS["default_platform_fee_pct"] and "platform_fee_pct" not in data:
        notes.append("Platform fee defaulted to 3% (Airbnb split-fee); verify your actual fee structure.")
    notes.append("Lodging/occupancy taxes are assumed to be collected from guests and passed through, so they're excluded.")
    annual = {k: r2(v) for k, v in totals.items()}
    return {
        "inputs": {k: v for k, v in d.items()},
        "monthly": months,
        "annual": annual,
        "average_monthly_net": r2(totals["net_income"] / 12),
        "effective_occupancy_pct": (r2(totals["booked_nights"] / totals["available_nights"] * 100)
                                    if totals["available_nights"] else None),
        "contribution_per_booked_night": r2(contribution),
        "breakeven_occupancy_pct": r2(breakeven),
        "notes": notes,
    }


def revenue_report(res: dict) -> Report:
    a = res["annual"]
    rep = Report("Short-term rental revenue estimate")
    rep.kv("Annual P&L", [
        ("Booked nights", num(a["booked_nights"], 1)),
        ("Rental income", money(a["rental_income"])),
        ("Cleaning fees collected", money(a["cleaning_income"])),
        ("Gross revenue", money(a["gross_revenue"])),
        ("Platform fees", money(-a["platform_fees"])),
        ("Management fees", money(-a["management_fees"])),
        ("Cleaning costs", money(-a["cleaning_costs"])),
        ("Fixed costs", money(-a["fixed_costs"])),
        ("Net income", money(a["net_income"])),
        ("Average monthly net", money(res["average_monthly_net"])),
        ("Effective occupancy", pct(res["effective_occupancy_pct"])),
        ("Break-even occupancy", pct(res["breakeven_occupancy_pct"])),
    ])
    rep.table("Monthly", ["Month", "Nights", "Gross", "Fees+cleaning", "Fixed", "Net"], [
        [m["month"], num(m["booked_nights"], 1), money(m["gross_revenue"]),
         money(m["platform_fees"] + m["management_fees"] + m["cleaning_costs"]), money(m["fixed_costs"]),
         money(m["net_income"])] for m in res["monthly"]])
    rep.bullets("Notes", res["notes"])
    return rep


# --------------------------------------------------------------------------- guest messages
MESSAGE_TYPES = ("checkin", "checkout", "review-request", "issue")
GUEST_FIELDS = [
    Field("guest_name", "str", required=True),
    Field("host_name", "str", required=True),
    Field("property_name", "str"),
    Field("address", "str"),
    Field("checkin_date", "str"),
    Field("checkin_time", "str"),
    Field("checkout_date", "str"),
    Field("checkout_time", "str"),
    Field("door_code", "str"),
    Field("wifi_name", "str"),
    Field("wifi_password", "str"),
    Field("parking", "str"),
    Field("house_rules", "strlist", default=list),
    Field("checkout_tasks", "strlist", default=list),
    Field("review_link", "str"),
    Field("issue_description", "str"),
    Field("fix_plan", "str"),
    Field("eta", "str"),
]

_SUBJECTS = {
    "checkin": "Check-in details for {property_name}",
    "checkout": "Checkout reminder for {property_name}",
    "review-request": "Thank you for staying at {property_name}",
    "issue": "About the issue at {property_name}",
}
_TIPS = {
    "checkin": ["Send this 24-48 hours before arrival, not at booking: door codes shouldn't sit in inboxes for weeks.",
                "Change the door code between guests."],
    "checkout": ["Send the evening before checkout.", "Keep checkout tasks short; long chore lists hurt reviews."],
    "review-request": ["Send within 24 hours of checkout.",
                       "Don't offer discounts or gifts for reviews; that breaks Airbnb's review policy (verify current policy)."],
    "issue": ["Reply within 15 minutes, even if the fix takes longer.",
              "Keep all communication on the platform in case you need support or a damage claim later."],
}


def guest_message(msg_type: str, data: dict) -> dict:
    if msg_type not in MESSAGE_TYPES:
        raise ValidationError(f"Message type must be one of: {', '.join(MESSAGE_TYPES)} (got {msg_type!r}).")
    d = parse_fields(data, GUEST_FIELDS, "guest data")
    if msg_type == "issue" and not d["issue_description"]:
        raise ValidationError("Missing required field 'issue_description' for an issue message (what went wrong).")
    missing: list[str] = []

    def v(key: str, label: str | None = None) -> str:
        value = d.get(key)
        if value:
            return value
        if key not in missing:
            missing.append(key)
        return f"[{label or key.replace('_', ' ')}]"

    first = d["guest_name"].split()[0]
    host = d["host_name"]
    if msg_type == "checkin":
        lines = [f"Hi {first}!", "",
                 f"We're excited to host you at {v('property_name')} on {v('checkin_date')}. "
                 "Here's everything you need for a smooth arrival:", "",
                 f"- Check-in: from {v('checkin_time')}",
                 f"- Address: {v('address')}",
                 f"- Door code: {v('door_code')}",
                 f"- Wi-Fi: {v('wifi_name')} / password: {v('wifi_password')}",
                 f"- Parking: {v('parking')}"]
        if d["house_rules"]:
            lines += ["", "A few house rules:"] + [f"- {r}" for r in d["house_rules"]]
        lines += ["", "If anything isn't right when you arrive, message me here and I'll sort it out quickly.", "",
                  "See you soon,", host]
    elif msg_type == "checkout":
        lines = [f"Hi {first},", "",
                 f"We hope you've enjoyed your stay at {v('property_name')}! A quick reminder that checkout is "
                 f"{v('checkout_date')} by {v('checkout_time')}."]
        if d["checkout_tasks"]:
            lines += ["", "Before you go, could you please:"] + [f"- {t}" for t in d["checkout_tasks"]]
        lines += ["", "No need to strip beds or do laundry beyond that. Safe travels!", "", host]
    elif msg_type == "review-request":
        lines = [f"Hi {first},", "",
                 f"Thank you for staying at {v('property_name')}. It was a pleasure hosting you!", "",
                 "If you enjoyed your stay, a short review would mean a lot to our small business."
                 + (f" You can leave one here: {d['review_link']}" if d["review_link"] else ""),
                 "", "And if anything wasn't 5-star, please tell me directly so I can fix it for the next guest.",
                 "", "Thanks again,", host]
    else:
        plan = d["fix_plan"] or "I'm arranging a fix right now"
        eta = f" I expect it to be sorted by {d['eta']}." if d["eta"] else ""
        if not d["eta"]:
            missing.append("eta")
        lines = [f"Hi {first},", "",
                 f"I'm so sorry about {d['issue_description']}, and thank you for letting me know right away.", "",
                 f"{plan}.{eta} I'll keep you updated here.", "",
                 "If it's affecting your stay in the meantime, tell me what would help most and I'll do my best.",
                 "", host]
    subject = _SUBJECTS[msg_type].format(property_name=d["property_name"] or "your stay")
    return {"type": msg_type, "subject": subject, "message": "\n".join(lines),
            "missing_fields": missing, "tips": _TIPS[msg_type]}


def message_report(res: dict) -> Report:
    rep = Report(f"Guest message: {res['type']}", f"Subject: {res['subject']}")
    rep.pre("Message (copy and paste)", res["message"])
    if res["missing_fields"]:
        rep.bullets("Fill in before sending", res["missing_fields"])
    rep.bullets("Tips", res["tips"])
    return rep
