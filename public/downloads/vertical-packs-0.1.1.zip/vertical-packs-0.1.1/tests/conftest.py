import json
from pathlib import Path

import pytest

from vpacks.cli import main

ROOT = Path(__file__).resolve().parents[1]
EXAMPLES = ROOT / "examples"


@pytest.fixture
def run(capsys):
    """Run the CLI, return (exit_code, stdout, stderr)."""

    def _run(*argv):
        code = main([str(a) for a in argv])
        out, err = capsys.readouterr()
        return code, out, err

    return _run


@pytest.fixture
def write_json(tmp_path):
    def _write(data, name="input.json"):
        p = tmp_path / name
        p.write_text(json.dumps(data), encoding="utf-8")
        return p

    return _write
