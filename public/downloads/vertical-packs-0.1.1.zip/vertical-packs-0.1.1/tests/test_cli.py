import json
import os
import subprocess
import sys
from pathlib import Path

import pytest

from conftest import EXAMPLES, ROOT

E = EXAMPLES

# Every subcommand with its example input.
COMMANDS = {
    "str listing": ["str", "listing", E / "str/listing.json"],
    "str revenue": ["str", "revenue", "--input", E / "str/revenue.json"],
    "str message checkin": ["str", "message", "--type", "checkin", "--data", E / "str/guest.json"],
    "str message checkout": ["str", "message", "--type", "checkout", "--data", E / "str/guest.json"],
    "str message review": ["str", "message", "--type", "review-request", "--data", E / "str/guest.json"],
    "str message issue": ["str", "message", "--type", "issue", "--data", E / "str/guest.json"],
    "pm triage file": ["pm", "triage", E / "pm/request.txt"],
    "pm triage text": ["pm", "triage", "--text", "No leak, but the toilet is clogged"],
    "pm triage csv": ["pm", "triage", "--csv", E / "pm/requests.csv"],
    "rei rental": ["rei", "rental", "--input", E / "rei/rental.json"],
    "rei flip": ["rei", "flip", "--input", E / "rei/flip.json"],
    "rei brrrr": ["rei", "brrrr", "--input", E / "rei/brrrr.json"],
    "freight load": ["freight", "load", "--input", E / "freight/load.json"],
    "freight carrier": ["freight", "carrier", E / "freight/carrier.json"],
    "kdp check": ["kdp", "check", E / "kdp/book.json"],
    "kdp check clean": ["kdp", "check", E / "kdp/book-clean.json"],
}


@pytest.mark.parametrize("fmt", ["text", "json", "md"])
@pytest.mark.parametrize("name", list(COMMANDS))
def test_every_subcommand_every_format(run, name, fmt):
    code, out, err = run(*COMMANDS[name], "--format", fmt)
    assert code == 0, err
    assert err == ""
    if fmt == "json":
        data = json.loads(out)
        assert isinstance(data, dict) and data
    elif fmt == "md":
        assert out.startswith("# ")
        assert "\n## " in out
    else:
        title = out.splitlines()[0]
        assert out.splitlines()[1] == "=" * len(title)


def test_every_example_file_is_used():
    used = {Path(str(a)).resolve() for argv in COMMANDS.values() for a in argv if isinstance(a, Path)}
    files = {p.resolve() for p in EXAMPLES.rglob("*") if p.is_file()}
    assert files == used


def test_rei_flags_only_and_override(run):
    code, out, _ = run("rei", "rental", "--purchase-price", "300000", "--interest-rate-pct", "7",
                       "--down-payment-pct", "0", "--monthly-rent", "2500", "--format", "json")
    assert code == 0
    assert json.loads(out)["monthly_mortgage_payment"] == 1995.91
    code, out, _ = run("rei", "rental", "--input", E / "rei/rental.json", "--interest-rate-pct", "0", "--format", "json")
    assert json.loads(out)["monthly_mortgage_payment"] == round(160000 / 360, 2)


def test_str_revenue_flags(run):
    code, out, _ = run("str", "revenue", "--adr", "200", "--occupancy-pct", "50", "--avg-stay-nights", "2",
                       "--cleaning-fee", "100", "--cleaning-cost", "80", "--platform-fee-pct", "3",
                       "--monthly-costs", "mortgage=1500,utilities=300", "--format", "json")
    assert code == 0
    res = json.loads(out)
    assert res["annual"]["net_income"] == 15356.25
    assert res["breakeven_occupancy_pct"] == 29.22
    code, out, _ = run("str", "revenue", "--adr", "100", "--occupancy-pct", "50",
                       "--seasonality", ",".join(["1"] * 12), "--format", "json")
    assert code == 0


def test_freight_flags_and_as_of(run):
    code, out, _ = run("freight", "load", "--rate", "2500", "--loaded-miles", "1000", "--deadhead-miles", "100",
                       "--fuel-price", "4", "--driver-pay-per-mile", "0.6", "--other-costs", "50", "--format", "json")
    assert code == 0 and json.loads(out)["profit"] == 1113.08
    code, out, _ = run("freight", "carrier", E / "freight/carrier.json", "--as-of", "2027-10-28", "--format", "json")
    assert json.loads(out)["authority_age_days"] == 434
    code, _, err = run("freight", "carrier", E / "freight/carrier.json", "--as-of", "tomorrow")
    assert code == 2 and "--as-of must be a date" in err


def test_pm_stdin_and_options(run, monkeypatch):
    import io
    monkeypatch.setattr("sys.stdin", io.StringIO("The furnace died"))
    code, out, _ = run("pm", "triage", "-", "--outdoor-temp-f", "10", "--emergency-phone", "555-0100", "--format", "json")
    res = json.loads(out)
    assert code == 0 and res["urgency"] == "emergency"
    assert any("555-0100" in i for i in res["tenant_instructions"])


@pytest.mark.parametrize("argv,needle", [
    (["rei", "rental", "--purchase-price", "-5", "--interest-rate-pct", "7", "--monthly-rent", "1"], "can't be negative"),
    (["rei", "rental"], "Missing required field 'purchase_price'"),
    (["str", "revenue", "--adr", "100", "--occupancy-pct", "120"], "at most 100"),
    (["str", "revenue", "--adr", "x", "--occupancy-pct", "50"], "must be a number"),
    (["str", "revenue", "--adr", "100", "--occupancy-pct", "50", "--seasonality", "1,2"], "exactly 12"),
    (["freight", "load", "--rate", "100", "--loaded-miles", "10", "--fuel-price", "4", "--mpg", "0"], "greater than 0"),
    (["pm", "triage"], "exactly one of"),
    (["pm", "triage", "--text", "a", "--csv", "x.csv"], "exactly one of"),
    (["pm", "triage", "--text", "  "], "empty"),
    (["pm", "triage", "missing.txt"], "File not found"),
    (["pm", "triage", "--csv", "missing.csv"], "File not found"),
    (["kdp", "check", "missing.json"], "File not found"),
    (["str", "listing", "missing.json"], "File not found"),
    (["rei", "flip", "--input", "missing.json"], "File not found"),
])
def test_validation_errors_exit_2(run, argv, needle):
    code, out, err = run(*argv)
    assert code == 2
    assert out == ""
    assert err.startswith("Error: please fix the input")
    assert needle in err


def test_bad_json_and_non_object(run, tmp_path, write_json):
    bad = tmp_path / "bad.json"
    bad.write_text("{oops")
    code, _, err = run("kdp", "check", bad)
    assert code == 2 and "not valid JSON" in err
    lst = write_json([1, 2])
    code, _, err = run("rei", "flip", "--input", lst)
    assert code == 2 and "JSON object" in err
    code, _, err = run("str", "listing", lst)
    assert code == 2 and "JSON object" in err


def test_unknown_field_in_input(run, write_json):
    p = write_json({"purchase_price": 1, "interest_rate_pct": 5, "monthly_rent": 1, "vacancy": 5})
    code, _, err = run("rei", "rental", "--input", p)
    assert code == 2 and "Did you mean 'vacancy_pct'" in err


def test_issue_message_without_description(run, write_json):
    p = write_json({"guest_name": "A", "host_name": "B"})
    code, _, err = run("str", "message", "--type", "issue", "--data", p)
    assert code == 2 and "issue_description" in err
    code, out, _ = run("str", "message", "--type", "checkin", "--data", p)
    assert code == 0 and "[door code]" in out


def test_kdp_strict_exit_code(run):
    assert run("kdp", "check", E / "kdp/book.json", "--strict")[0] == 1
    assert run("kdp", "check", E / "kdp/book-clean.json", "--strict")[0] == 0


def test_argparse_errors_and_help(run):
    code, _, err = run("str", "message", "--type", "hello", "--data", "x.json")
    assert code == 2 and "invalid choice" in err
    code, _, err = run("rei", "rental", "--format", "pdf")
    assert code == 2
    code, _, err = run()
    assert code == 2
    code, out, _ = run("--help")
    assert code == 0 and "vpacks" in out
    code, out, _ = run("--version")
    assert code == 0 and "0.1.1" in out


def test_python_dash_m(tmp_path):
    env = {**os.environ, "PYTHONPATH": str(ROOT / "src")}
    proc = subprocess.run([sys.executable, "-m", "vpacks", "rei", "rental", "--purchase-price", "375000",
                           "--down-payment-pct", "20", "--interest-rate-pct", "7", "--monthly-rent", "3000",
                           "--format", "json"], capture_output=True, text=True, env=env, cwd=tmp_path, timeout=60)
    assert proc.returncode == 0, proc.stderr
    assert json.loads(proc.stdout)["monthly_mortgage_payment"] == 1995.91
    proc = subprocess.run([sys.executable, "-m", "vpacks", "rei", "rental"], capture_output=True, text=True, env=env,
                          cwd=tmp_path, timeout=60)
    assert proc.returncode == 2 and "Missing required field" in proc.stderr


def test_example_outputs_content(run):
    """The shipped examples demonstrate the main features."""
    _, out, _ = run("pm", "triage", E / "pm/request.txt", "--format", "json")
    res = json.loads(out)
    assert res["urgency"] == "emergency" and "plumbing" in res["categories"]
    assert [m["rule"] for m in res["ignored_negated"]] == ["leak"]
    _, out, _ = run("pm", "triage", "--csv", E / "pm/requests.csv", "--format", "json")
    batch = json.loads(out)
    assert batch["count"] == 8
    assert batch["results"][0]["id"] == "1002"
    assert batch["counts"]["emergency"] == 3
    _, out, _ = run("kdp", "check", E / "kdp/book.json", "--format", "json")
    assert json.loads(out)["errors"] >= 5
    _, out, _ = run("kdp", "check", E / "kdp/book-clean.json", "--format", "json")
    assert json.loads(out)["ok"] is True
    _, out, _ = run("freight", "carrier", E / "freight/carrier.json", "--format", "json")
    assert json.loads(out)["risk_level"] == "high"
    _, out, _ = run("str", "listing", E / "str/listing.json", "--format", "json")
    assert json.loads(out)["fixes"][0]["area"] == "Title"


@pytest.mark.parametrize("argv", [["str", "listing"], ["str", "revenue"], ["str", "message"], ["pm", "triage"],
                                  ["rei", "rental"], ["rei", "flip"], ["rei", "brrrr"], ["freight", "load"],
                                  ["freight", "carrier"], ["kdp", "check"]])
def test_every_subcommand_help(run, argv):
    code, out, _ = run(*argv, "--help")
    assert code == 0 and "--format" in out
