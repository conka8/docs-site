import json
from datetime import date

import pytest

from vpacks.common import (Field, Report, ValidationError, emit, load_json_file, money, num, parse_fields, pct, r2,
                           read_text_file, safe_div, yes_no)


FIELDS = [
    Field("price", "float", required=True, help="the price"),
    Field("rate_pct", "pct", default=5.0),
    Field("count", "int", default=0),
    Field("photos", "count", default=0),
    Field("flag", "bool"),
    Field("when", "date"),
    Field("season", "floatlist"),
    Field("tags", "strlist", default=list),
    Field("costs", "moneydict", default=dict),
    Field("name", "str"),
]


def test_parse_defaults_and_conversion():
    d = parse_fields({"price": "$1,500", "rate_pct": "7%", "count": "3", "photos": ["a", "b"], "flag": "yes",
                      "when": "2026-01-31", "season": "1,1.5", "tags": "a, b,", "costs": "rent=100, gas=20"}, FIELDS)
    assert d["price"] == 1500.0
    assert d["rate_pct"] == 7.0
    assert d["count"] == 3
    assert d["photos"] == 2
    assert d["flag"] is True
    assert d["when"] == date(2026, 1, 31)
    assert d["season"] == [1.0, 1.5]
    assert d["tags"] == ["a", "b"]
    assert d["costs"] == {"rent": 100.0, "gas": 20.0}
    assert d["name"] is None


def test_parse_defaults_are_fresh_objects():
    a = parse_fields({"price": 1}, FIELDS)
    b = parse_fields({"price": 1}, FIELDS)
    a["tags"].append("x")
    assert b["tags"] == []
    assert a["rate_pct"] == 5.0


def test_parse_collects_all_problems():
    with pytest.raises(ValidationError) as exc:
        parse_fields({"rate_pct": 120, "count": 1.5, "flag": "maybe", "pricee": 3}, FIELDS)
    problems = exc.value.problems
    text = "\n".join(problems)
    assert "Missing required field 'price' (the price)" in text
    assert "'rate_pct' must be at most 100 (got 120)" in text
    assert "65 for 65%" in text
    assert "'count' must be a whole number" in text
    assert "'flag' must be true or false" in text
    assert "Unknown field 'pricee'. Did you mean 'price'?" in text


@pytest.mark.parametrize("raw,msg", [
    (-1, "can't be negative"), ("abc", "must be a number"), (True, "not true/false"),
    (float("nan"), "finite"), ([1], "must be a number"),
])
def test_number_errors(raw, msg):
    with pytest.raises(ValidationError, match=msg):
        parse_fields({"price": raw}, FIELDS)


def test_other_kind_errors():
    with pytest.raises(ValidationError, match="date like"):
        parse_fields({"price": 1, "when": "31/01/2026"}, FIELDS)
    with pytest.raises(ValidationError, match="name=amount"):
        parse_fields({"price": 1, "costs": "rent100"}, FIELDS)
    with pytest.raises(ValidationError, match="can't be negative"):
        parse_fields({"price": 1, "costs": {"x": -5}}, FIELDS)
    with pytest.raises(ValidationError, match="list of numbers"):
        parse_fields({"price": 1, "season": 5}, FIELDS)
    with pytest.raises(ValidationError, match="must be text"):
        parse_fields({"price": 1, "name": {"a": 1}}, FIELDS)
    with pytest.raises(ValidationError, match="JSON object"):
        parse_fields([1, 2], FIELDS)


def test_min_bound_message():
    f = [Field("x", "float", min=1)]
    with pytest.raises(ValidationError, match="at least 1"):
        parse_fields({"x": 0.5}, f)


def test_ignores_comment_keys():
    assert parse_fields({"price": 1, "_comment": "hi", "notes": "x"}, FIELDS)["price"] == 1


def test_safe_div():
    notes = []
    assert safe_div(10, 4, notes, "nope") == 2.5
    assert notes == []
    assert safe_div(10, 0, notes, "Can't divide: zero.") is None
    assert notes == ["Can't divide: zero."]


def test_formatters():
    assert money(1995.907) == "$1,995.91"
    assert money(-1234.5) == "-$1,234.50"
    assert money(-0.001) == "$0.00"
    assert money(None) == "n/a"
    assert pct(7.2) == "7.20%"
    assert pct(None) == "n/a"
    assert num(1234.567, 1) == "1,234.6"
    assert num(None) == "n/a"
    assert r2(-0.001) == 0.0
    assert r2(None) is None
    assert r2(1.23456, 3) == 1.235
    assert yes_no(True) == "yes" and yes_no(False) == "no" and yes_no(None) == "n/a"


def _report():
    rep = Report("Title", "sub")
    rep.kv("KV", [("a", 1), ("long label", "x|y")])
    rep.table("Table", ["H1", "H2"], [["1", "2"], ["333", "4"]])
    rep.table("Empty", ["H"], [])
    rep.bullets("List", ["one"])
    rep.bullets("None", [])
    rep.pre("Pre", "line1\nline2")
    return rep


def test_report_text():
    text = _report().to_text()
    assert text.startswith("Title\n=====\nsub\n")
    assert "long label  x|y" in text
    assert "H1   H2" in text and "333  4" in text
    assert "(none)" in text
    assert "- one" in text
    assert "line1\nline2" in text


def test_report_markdown():
    md = _report().to_markdown()
    assert md.startswith("# Title")
    assert "## KV" in md
    assert "| long label | x\\|y |" in md
    assert "| H1 | H2 |" in md
    assert "_None._" in md
    assert "```text\nline1\nline2\n```" in md


def test_emit_formats():
    rep = Report("T")
    assert json.loads(emit({"d": date(2026, 1, 2)}, rep, "json")) == {"d": "2026-01-02"}
    assert emit({}, rep, "text").startswith("T\n")
    assert emit({}, rep, "md").startswith("# T")
    with pytest.raises(ValidationError):
        emit({}, rep, "pdf")


def test_load_json_errors(tmp_path):
    with pytest.raises(ValidationError, match="File not found"):
        load_json_file(tmp_path / "missing.json")
    bad = tmp_path / "bad.json"
    bad.write_text("{\n  'a': 1}")
    with pytest.raises(ValidationError, match="not valid JSON \\(line 2"):
        load_json_file(bad)
    with pytest.raises(ValidationError, match="Can't read"):
        load_json_file(tmp_path)
    with pytest.raises(ValidationError, match="File not found"):
        read_text_file(tmp_path / "x.txt")
    with pytest.raises(ValidationError, match="Can't read"):
        read_text_file(tmp_path)
