from datetime import date

import pytest

from vpacks import freight as f
from vpacks.common import ValidationError

LOAD = {"rate": 2500, "loaded_miles": 1000, "deadhead_miles": 100, "mpg": 6.5, "fuel_price": 4.00,
        "driver_pay_per_mile": 0.60, "other_costs": 50, "shipper_rate": 2900, "min_rpm": 2.00}


def test_load_hand_computed():
    r = f.analyze_load(LOAD)
    assert r["total_miles"] == 1100.0
    assert r["rpm"] == 2.5
    assert r["deadhead_adjusted_rpm"] == 2.27  # 2500 / 1100
    assert r["fuel_gallons"] == 169.23  # 1100 / 6.5
    assert r["fuel_cost"] == 676.92
    assert r["driver_pay"] == 660.0
    assert r["total_cost"] == 1386.92
    assert r["profit"] == 1113.08
    assert r["profit_per_mile"] == 1.01
    assert r["cost_per_mile"] == 1.26
    assert r["profit_margin_pct"] == 44.52
    assert r["broker"] == {"shipper_rate": 2900.0, "broker_margin": 400.0, "broker_margin_pct": 13.79}
    assert r["decision"] == "GO"


def test_load_pct_driver_pay_and_fixed_costs():
    r = f.analyze_load({**LOAD, "driver_pay_per_mile": 0, "driver_pay_pct": 25, "fixed_cost_per_mile": 0.5})
    assert r["driver_pay"] == 625.0
    assert r["fixed_costs"] == 550.0


def test_load_no_go_low_rpm_and_deadhead_note():
    r = f.analyze_load({**LOAD, "rate": 2000, "deadhead_miles": 200})
    assert r["deadhead_adjusted_rpm"] == 1.67
    assert r["decision"] == "NO-GO"
    assert any("below your minimum" in x for x in r["reasons"])
    assert any("Deadhead is over 15%" in n for n in r["notes"])


def test_load_no_go_loss():
    r = f.analyze_load({**LOAD, "min_rpm": 0.1, "rate": 500})
    assert r["profit"] < 0
    assert r["decision"] == "NO-GO"
    assert any("doesn't make a profit" in x for x in r["reasons"])


def test_load_zero_miles():
    r = f.analyze_load({**LOAD, "loaded_miles": 0, "deadhead_miles": 0})
    assert r["rpm"] is None and r["deadhead_adjusted_rpm"] is None
    assert r["profit_per_mile"] is None and r["cost_per_mile"] is None
    assert r["decision"] == "NO-GO" and "No miles entered." in r["reasons"]
    assert any("loaded miles is 0" in n for n in r["notes"])
    deadhead_only = f.analyze_load({**LOAD, "loaded_miles": 0})
    assert deadhead_only["rpm"] is None
    assert deadhead_only["deadhead_adjusted_rpm"] == 25.0


def test_load_zero_rate_and_shipper():
    r = f.analyze_load({**LOAD, "rate": 0, "shipper_rate": 0})
    assert r["profit_margin_pct"] is None
    assert r["broker"]["broker_margin_pct"] is None
    assert any("rate is $0" in n for n in r["notes"])


def test_load_without_shipper_rate_has_no_broker_block():
    data = dict(LOAD)
    data.pop("shipper_rate")
    assert f.analyze_load(data)["broker"] is None


@pytest.mark.parametrize("bad,msg", [
    ({"mpg": 0}, "greater than 0"), ({"rate": -100}, "can't be negative"),
    ({"fuel_price": None}, "fuel_price"), ({"driver_pay_pct": 120}, "at most 100"),
])
def test_load_validation(bad, msg):
    with pytest.raises(ValidationError, match=msg):
        f.analyze_load({**LOAD, **bad})


def test_load_report():
    text = f.load_report(f.analyze_load(LOAD)).to_text()
    assert text.startswith("Load check: GO")
    assert "Broker margin          $400.00 (13.79%)" in text


CLEAN = {"legal_name": "Good Freight, LLC", "mc_number": "111", "dot_number": "222", "authority_status": "Active",
         "authority_age_days": 900, "cargo_insurance": 100000, "auto_liability_insurance": 1000000,
         "safety_rating": "Satisfactory", "vehicle_oos_pct": 10, "driver_oos_pct": 2,
         "email": "ops@goodfreight.com", "company_website": "https://www.goodfreight.com/about",
         "fmcsa_email": "dispatch@goodfreight.com", "phone": "+1 (555) 201-7788", "fmcsa_phone": "555-201-7788",
         "phone_changed_days_ago": 400, "payee_name": "Good Freight LLC", "address_matches_fmcsa": True}


def test_clean_carrier_low_risk():
    r = f.vet_carrier(CLEAN)
    assert r["risk_score"] == 0
    assert r["risk_level"] == "low"
    assert r["red_flags"] == []
    assert all(c["status"] == "pass" for c in r["checklist"])
    assert "doesn't query FMCSA" in r["note"]


def test_example_style_carrier_scores():
    data = {**CLEAN, "authority_age_days": None, "authority_granted_date": "2026-08-20",
            "safety_rating": "not rated", "vehicle_oos_pct": 30, "email": "dispatch.fastlane@gmail.com",
            "fmcsa_email": None, "phone": "555 410 0000", "phone_changed_days_ago": 21,
            "payee_name": "QuickPay Factoring Inc"}
    r = f.vet_carrier(data, as_of=date(2026, 10, 28))
    assert r["authority_age_days"] == 69
    pts = {c["check"]: c["risk_points"] for c in r["checklist"]}
    assert pts["Authority age"] == 30
    assert pts["Safety rating"] == 5
    assert pts["Vehicle out-of-service rate"] == 10
    assert pts["Email domain"] == 10
    assert pts["Phone number"] == 20
    assert pts["Recent contact change"] == 20
    assert pts["Payee name"] == 20
    assert r["risk_score"] == 100  # 115 capped
    assert r["risk_level"] == "high"
    assert r["recommendation"].startswith("High risk")
    assert len(r["red_flags"]) == 3


def test_as_of_from_data_and_future_date():
    r = f.vet_carrier({**CLEAN, "authority_age_days": None, "authority_granted_date": "2026-01-01",
                       "as_of_date": "2026-06-30"})
    assert r["authority_age_days"] == 180
    with pytest.raises(ValidationError, match="future"):
        f.vet_carrier({**CLEAN, "authority_age_days": None, "authority_granted_date": "2030-01-01"},
                      as_of=date(2026, 1, 1))


@pytest.mark.parametrize("over,check,status,critical", [
    ({"authority_status": "revoked"}, "Operating authority", "fail", True),
    ({"auto_liability_insurance": 500000}, "Auto liability insurance", "fail", True),
    ({"auto_liability_insurance": 750000}, "Auto liability insurance", "warn", False),
    ({"cargo_insurance": 50000}, "Cargo insurance", "fail", False),
    ({"safety_rating": "unsatisfactory"}, "Safety rating", "fail", True),
    ({"safety_rating": "conditional"}, "Safety rating", "warn", False),
    ({"authority_age_days": 120}, "Authority age", "warn", False),
    ({"authority_age_days": 30}, "Authority age", "fail", False),
    ({"driver_oos_pct": 14}, "Driver out-of-service rate", "fail", False),
    ({"email": "ops@other-freight.net", "fmcsa_email": None}, "Email domain", "fail", False),
    ({"email": "ops@other-freight.net"}, "Email domain", "fail", False),
    ({"phone_changed_days_ago": 10}, "Recent contact change", "fail", False),
    ({"address_matches_fmcsa": False}, "Address", "warn", False),
])
def test_individual_checks(over, check, status, critical):
    r = f.vet_carrier({**CLEAN, **over})
    item = next(c for c in r["checklist"] if c["check"] == check)
    assert item["status"] == status
    assert item["critical"] is critical
    if critical:
        assert r["recommendation"].startswith("DO NOT USE")


def test_fmcsa_email_mismatch_message():
    r = f.vet_carrier({**CLEAN, "email": "ops@goodfreight-dispatch.com"})
    item = next(c for c in r["checklist"] if c["check"] == "Email domain")
    assert "FMCSA record" in item["reason"]


def test_medium_risk():
    r = f.vet_carrier({**CLEAN, "authority_age_days": 120, "email": "x@gmail.com", "fmcsa_email": None,
                       "company_website": None})
    assert r["risk_score"] == 25
    assert r["risk_level"] == "medium"


def test_minimal_carrier_unknowns():
    r = f.vet_carrier({"legal_name": "Unknown Co"})
    statuses = {c["check"]: c["status"] for c in r["checklist"]}
    assert statuses["Operating authority"] == "unknown"
    assert statuses["Phone number"] == "unknown"
    assert "Payee name" not in statuses and "Address" not in statuses
    assert r["risk_score"] == 55
    assert r["risk_level"] == "high"


def test_carrier_validation():
    with pytest.raises(ValidationError, match="safety_rating"):
        f.vet_carrier({**CLEAN, "safety_rating": "great"})
    with pytest.raises(ValidationError, match="legal_name"):
        f.vet_carrier({})
    with pytest.raises(ValidationError, match="date like"):
        f.vet_carrier({**CLEAN, "authority_granted_date": "08/20/2026"})
    assert f.vet_carrier({**CLEAN, "safety_rating": "none"})["checklist"][4]["status"] == "warn"


def test_helpers():
    assert f._domain("https://www.Example.com/path") == "example.com"
    assert f._domain("Bob@Mail.Example.com") == "mail.example.com"
    assert f._domain("") is None
    assert f._digits("+1 (555) 201-7788") == "5552017788"
    assert f._norm_name("Good Freight, L.L.C.") != ""
    assert f._norm_name("Good Freight, Inc.") == f._norm_name("good freight")


def test_carrier_report():
    rep = f.carrier_report(f.vet_carrier(CLEAN))
    assert "MC 111 / DOT 222" in rep.to_text()
    assert "| Operating authority | PASS | 0 |" in rep.to_markdown()
    assert f.carrier_report(f.vet_carrier({"legal_name": "X"})).subtitle is None
