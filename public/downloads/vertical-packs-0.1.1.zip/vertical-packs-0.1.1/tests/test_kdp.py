import pytest

from vpacks import kdp
from vpacks.common import ValidationError

CLEAN = {
    "title": "Gluten-Free Baking for Beginners",
    "subtitle": "75 Easy Recipes for Bread, Cookies and Cakes",
    "author": "Sam Baker",
    "keywords": ["celiac friendly desserts", "wheat allergy cookbook", "homemade sandwich loaf",
                 "low sugar party treats", "almond flour muffins", "dairy alternatives kitchen",
                 "family weekend projects"],
    "description": "<p>Bake bread your family will love.</p><ul><li>75 recipes</li><li>Photos</li></ul><br>",
    "categories": ["Cookbooks > Gluten-Free", "Cookbooks > Baking"],
}


def check(**over):
    return kdp.check_book({**CLEAN, **over})


def messages(res, severity=None):
    return [i["message"] for i in res["issues"] if severity is None or i["severity"] == severity]


def test_clean_book_passes():
    res = check()
    assert res["ok"] is True
    assert res["errors"] == 0 and res["warnings"] == 0
    assert res["issues"] == []
    assert res["stats"]["keywords_used"] == 7
    assert "verify against current kdp guidelines" in res["limits_note"].lower()
    assert res["limits"]["keyword_slots"] == 7


def test_limits_constants():
    assert kdp.KDP_LIMITS["title_subtitle_max_chars"] == 200
    assert kdp.KDP_LIMITS["keyword_max_chars"] == 50
    assert kdp.KDP_LIMITS["description_max_chars"] == 4000
    assert "_note" in kdp.KDP_LIMITS


def test_title_subtitle_limit_boundary():
    assert check(title="T" * 100, subtitle="S" * 100)["errors"] == 0
    res = check(title="T" * 100, subtitle="S" * 101)
    assert res["errors"] == 1
    assert "201 characters" in messages(res, "error")[0]


def test_keyword_length_boundary():
    kws = list(CLEAN["keywords"])
    kws[0] = "a" * 50
    assert check(keywords=kws)["errors"] == 0
    kws[0] = "a" * 51
    res = check(keywords=kws)
    assert res["issues"][0]["field"] == "keywords[1]"
    assert "51 characters" in res["issues"][0]["message"]


def test_too_many_and_too_few_keywords():
    res = check(keywords=CLEAN["keywords"] + ["eighth phrase here"])
    assert any("8 keywords" in m for m in messages(res, "error"))
    few = check(keywords=["one keyword phrase"])
    assert few["ok"] is True
    assert "Using 1 of 7 keyword slots" in messages(few, "info")[0]


@pytest.mark.parametrize("keyword,term", [
    ("books like stephen king", "stephen king"),
    ("harry potter style magic", "harry potter"),
    ("bestseller thriller", "bestseller"),
    ("free romance ebook", "free"),
    ("kindle unlimited romance", "kindle unlimited"),
    ("romance ku reads", "ku"),
    ("#1 cozy mystery", "#1"),
    ("Best-Selling Fantasy", "best-selling"),
])
def test_risky_keywords(keyword, term):
    kws = list(CLEAN["keywords"])
    kws[2] = keyword
    res = check(keywords=kws)
    assert not res["ok"]
    assert any(f"'{term}'" in m and "Keyword 3" in m for m in messages(res, "error"))


@pytest.mark.parametrize("keyword", ["gluten-free desserts", "sugar-free snacks", "kukui nut recipes",
                                     "freedom fighters", "#10 envelope crafts"])
def test_safe_keywords_not_flagged(keyword):
    assert kdp.find_risky_terms(keyword) == []


def test_extra_banned_terms():
    kws = list(CLEAN["keywords"])
    kws[0] = "like jane rival novels"
    res = check(keywords=kws, extra_banned_terms=["Jane Rival"])
    assert any("banned list" in m for m in messages(res, "error"))


def test_title_promo_and_author_terms():
    res = check(title="Free Bestseller Bread Book")
    errs = messages(res, "error")
    assert any("'free'" in m for m in errs) and any("'bestseller'" in m for m in errs)
    res = check(subtitle="For Fans of Stephen King")
    assert any("other authors" in m for m in messages(res, "warning"))


def test_keyword_duplicates_and_title_words():
    kws = list(CLEAN["keywords"])
    kws[1] = "Celiac Friendly  Desserts"
    kws[2] = "easy bread recipes"
    res = check(keywords=kws)
    warns = messages(res, "warning")
    assert any("Keyword 2 duplicates keyword 1" in m for m in warns)
    assert any("Keyword 3 repeats title words (bread, easy, recipes)" in m for m in warns)
    assert res["ok"] is True


def test_own_author_name_info():
    kws = list(CLEAN["keywords"])
    kws[0] = "sam baker cookbooks"
    assert any("your own name" in m for m in messages(check(keywords=kws), "info"))


def test_description_length_and_html():
    assert check(description="x" * 4000)["errors"] == 0
    res = check(description="x" * 4001)
    assert any("4001 characters" in m for m in messages(res, "error"))
    res = check(description="<div>Hi</div><span>x</span><script>alert(1)</script>")
    err = messages(res, "error")[0]
    assert "<div>, <span>, <script>" in err
    res = check(description="<p>Open <b>bold</p>")
    assert any("<b> is not closed" in m for m in messages(res, "warning"))
    res = check(description="<p>Text</p></i>")
    assert any("</i> has no opening tag" in m for m in messages(res, "warning"))
    res = check(description="<p>Unclosed")
    assert any("<p> is not closed" in m for m in messages(res, "warning"))
    assert messages(check(description="Line<br/>Line<BR>"), "warning") == []
    assert any("empty" in m for m in messages(check(description=""), "error"))


def test_description_claims_warning():
    res = check(description="<p>The #1 bestselling baking guide.</p>")
    warns = messages(res, "warning")
    assert any("'#1'" in m for m in warns) and any("'bestselling'" in m for m in warns)


def test_check_html_function():
    assert kdp.check_html("<h4>Hi</h4><ol><li>a</li></ol>") == ([], [])
    assert kdp.check_html("<table><tr></tr></table>")[0] == ["table", "tr"]


def test_categories():
    assert any("No categories" in m for m in messages(check(categories=[]), "warning"))
    res = check(categories=["A", "B", "C", "D"])
    assert any("up to 3" in m for m in messages(res, "error"))
    assert check(categories=["A", "B", "C"])["errors"] == 0
    assert any("listed twice" in m for m in messages(check(categories=["A", "a"]), "warning"))


def test_series_rules():
    assert check(series_name="Easy Baking", series_number=1)["errors"] == 0
    assert any("no book number" in m for m in messages(check(series_name="Easy Baking"), "error"))
    assert any("series name is empty" in m for m in messages(check(series_number=2), "error"))
    assert any("1 or higher" in m for m in messages(check(series_name="S", series_number=0), "error"))
    res = check(title="Dragon Fire: Book 2", series_name="Dragon Fire Saga", series_number=3)
    assert any("Title says number 2 but series number is 3" in m for m in messages(res, "error"))
    assert check(title="Dragon Fire, Book 3", series_name="Ember", series_number=3)["errors"] == 0
    res = check(title="Dragon Fire Volume 4")
    assert any("add series info" in m for m in messages(res, "warning"))
    res = check(title="Ember Saga: Rising", series_name="Ember Saga", series_number=1)
    assert any("Series name is repeated" in m for m in messages(res, "info"))


def test_issue_ordering_and_counts():
    res = check(title="Free Book 2", keywords=["x" * 60, "y"], categories=[])
    sev = [i["severity"] for i in res["issues"]]
    assert sev == sorted(sev, key=lambda s: {"error": 0, "warning": 1, "info": 2}[s])
    assert res["errors"] == sev.count("error") and res["warnings"] == sev.count("warning")


def test_validation():
    with pytest.raises(ValidationError, match="title"):
        kdp.check_book({"keywords": []})
    with pytest.raises(ValidationError, match="keywords"):
        kdp.check_book({"title": "x", "keywords": 5})
    with pytest.raises(ValidationError, match="series_number"):
        kdp.check_book({"title": "x", "series_number": 1.5})
    assert any("Title is empty" in m for m in messages(kdp.check_book({"title": ""}), "error"))


def test_report():
    rep = kdp.kdp_report(check(categories=["A", "B", "C", "D"]))
    text = rep.to_text()
    assert "Fix errors before publishing (1 errors" in text
    assert "Categories          4 / 3" in text
    assert kdp.kdp_report(check()).to_text().count("Ready to publish") == 1
