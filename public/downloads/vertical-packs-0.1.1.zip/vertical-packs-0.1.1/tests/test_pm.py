import pytest

from vpacks import pm
from vpacks.common import ValidationError


def t(text, **kw):
    return pm.triage(text, **kw)


@pytest.mark.parametrize("text,category,urgency,emergency", [
    ("I smell gas in the kitchen", "plumbing", "emergency", "gas smell"),
    ("There's a gas leak near the stove", "plumbing", "emergency", "gas smell"),
    ("Smells like rotten eggs by the water heater", "plumbing", "emergency", "gas smell"),
    ("The basement is flooding", "plumbing", "emergency", "flooding"),
    ("A pipe burst under the bathroom sink", "plumbing", "emergency", "flooding"),
    ("There is no water in the whole apartment", "plumbing", "emergency", "no water"),
    ("We don't have any water since this morning", "plumbing", "emergency", "no water"),
    ("The outlet in the bedroom is sparking", "electrical", "emergency", "fire or sparks"),
    ("There's a burning smell coming from the panel", "electrical", "emergency", "fire or sparks"),
    ("The CO detector is going off", "hvac", "emergency", "carbon monoxide"),
    ("Someone broke in last night", "lockout", "emergency", "security breach"),
    ("Our front door won't lock", "lockout", "emergency", "security breach"),
    ("The bathroom ceiling collapsed", "structural", "emergency", "structural collapse"),
])
def test_emergencies(text, category, urgency, emergency):
    res = t(text)
    assert res["category"] == category
    assert res["urgency"] == urgency
    assert res["emergency"] is True
    assert emergency in res["emergency_types"]
    assert res["sla"] == pm.SLA["emergency"]
    assert res["tenant_instructions"][0] == pm.EMERGENCY_INSTRUCTIONS[emergency]


@pytest.mark.parametrize("text,category,urgency", [
    ("The kitchen sink is leaking", "plumbing", "urgent"),
    ("Toilet is overflowing", "plumbing", "urgent"),
    ("No hot water in the shower", "plumbing", "urgent"),
    ("Fridge stopped cooling and food is going bad", "appliance", "urgent"),
    ("The AC isn't cooling at all", "hvac", "urgent"),
    ("Power is out in the whole unit", "electrical", "urgent"),
    ("I'm locked out of my apartment", "lockout", "urgent"),
    ("Lost my keys", "lockout", "urgent"),
    ("I think we have bed bugs", "pest", "urgent"),
    ("The roof is leaking into the bedroom", "structural", "urgent"),
    ("Pipes are frozen in the kitchen", "plumbing", "urgent"),
    ("Kitchen faucet drips a little", "plumbing", "routine"),
    ("The bathroom drain is clogged", "plumbing", "routine"),
    ("Light switch in the hallway doesn't do anything", "electrical", "routine"),
    ("Dishwasher makes a loud noise", "appliance", "routine"),
    ("Saw some roaches under the fridge", "pest", "routine"),
    ("There's mold on the bathroom wall", "structural", "routine"),
    ("Thermostat screen is blank", "hvac", "routine"),
])
def test_non_emergencies(text, category, urgency):
    res = t(text)
    assert res["category"] == category, res["matched"]
    assert res["urgency"] == urgency
    assert res["emergency"] is False
    assert res["call_911"] is False
    assert res["vendor_types"][0] == pm.VENDORS[category]


def test_negation_no_leak():
    res = t("There is no leak under the sink.")
    assert res["category"] == "other"
    assert res["urgency"] == "routine"
    assert res["needs_human_review"] is True
    assert {m["rule"] for m in res["ignored_negated"]} >= {"leak", "plumbing_general"}
    assert res["vendor_types"] == [pm.VENDORS["other"]]


def test_negation_does_not_cross_clause():
    res = t("No leak, but the toilet is clogged")
    assert res["category"] == "plumbing"
    assert res["urgency"] == "routine"
    assert [m["rule"] for m in res["ignored_negated"]] == ["leak"]


@pytest.mark.parametrize("text", ["I don't smell gas anymore", "I don’t smell gas anymore",
                                  "There's no gas smell", "No sparks, no burning smell"])
def test_negated_emergencies_do_not_trigger(text):
    res = t(text)
    assert res["emergency"] is False
    assert res["ignored_negated"]


def test_no_water_leak_is_not_no_water():
    res = t("No water leak in the bathroom")
    assert res["emergency"] is False
    assert "leak" in [m["rule"] for m in res["ignored_negated"]]


def test_problem_phrases_with_negation_still_count():
    # "not working" / "no heat" are problems, not negations
    res = t("The sink is not draining")
    assert res["category"] == "plumbing"
    res = t("The heater is not working")
    assert res["category"] == "hvac" and res["urgency"] == "urgent"
    assert any("temperature outside" in q for q in res["questions_for_tenant"])


def test_no_heat_freezing_escalates():
    assert t("No heat", outdoor_temp_f=20)["urgency"] == "emergency"
    assert t("No heat", outdoor_temp_f=32)["emergency_types"] == ["no heat in freezing weather"]
    assert t("No heat", outdoor_temp_f=45)["urgency"] == "urgent"
    assert t("Furnace won't turn on and it's 15 degrees outside")["urgency"] == "emergency"
    assert t("Heat stopped working, it's 50 degrees outside")["urgency"] == "urgent"
    assert t("No heat and the kids are freezing")["urgency"] == "emergency"
    frozen = t("No heat", outdoor_temp_f=10)
    assert not any("temperature outside" in q for q in frozen["questions_for_tenant"])


def test_multi_issue_request():
    res = t("The dishwasher is leaking and there are roaches in the kitchen. Also the bedroom light flickers.")
    assert res["urgency"] == "urgent"
    assert res["category"] == "plumbing"
    assert set(res["categories"]) == {"plumbing", "appliance", "pest", "electrical"}
    assert len(res["vendor_types"]) == 4
    assert any("kind of pest" in q for q in res["questions_for_tenant"])


def test_multi_emergency_and_dedup():
    res = t("I smell gas and the outlet is sparking", emergency_phone="555-0100")
    assert res["emergency_types"] == ["gas smell", "fire or sparks"]
    assert res["call_911"] is True
    assert any("555-0100" in i for i in res["tenant_instructions"])
    assert res["vendor_types"][:2] == [pm.EMERGENCY_VENDORS["gas smell"], pm.EMERGENCY_VENDORS["fire or sparks"]]
    assert pm.VENDORS["plumbing"] not in res["vendor_types"]
    assert not any("times work best" in q for q in res["questions_for_tenant"])


def test_flooding_is_not_911_but_has_line():
    res = t("Water everywhere in the laundry room")
    assert res["call_911"] is False
    assert any("[your 24/7 emergency maintenance line]" in i for i in res["tenant_instructions"])


def test_false_security_triggers_avoided():
    res = t("The dishwasher door is broken")
    assert res["emergency"] is False
    assert res["category"] == "appliance"


def test_unmatched_and_empty():
    res = t("The blinds are stuck")
    assert res["category"] == "other" and res["needs_human_review"]
    assert res["tenant_instructions"][0] == "We'll contact you to schedule a visit."
    with pytest.raises(ValidationError, match="empty"):
        t("   ")


def test_triage_report_formats():
    rep = pm.triage_report(t("No leak here, but I smell gas"))
    text = rep.to_text()
    assert text.startswith("EMERGENCY maintenance request")
    assert "Call 911 first      YES" in text
    assert "Ignored (negated)" in text
    assert "## Tell the tenant now" in rep.to_markdown()
    assert pm.triage_report(t("Dripping faucet")).to_text().startswith("Maintenance request triage")


CSV = """id,unit,text,outdoor_temp_f
1,2A,Kitchen faucet drips,
2,3C,I smell gas!!,
3,1B,Furnace won't turn on,25
4,4D,"Fridge stopped cooling, food warm",
5,5A,,
6,6B,No heat,abc
"""


def test_batch_csv_sorted_and_counts():
    res = pm.triage_csv(CSV)
    assert res["count"] == 5
    assert [r["id"] for r in res["results"]] == ["2", "3", "4", "6", "1"]
    assert res["counts"] == {"emergency": 2, "urgent": 2, "routine": 1}
    assert any("Row 5" in p and "empty" in p for p in res["problems"])
    assert any("abc" in p for p in res["problems"])
    rep = pm.batch_report(res).to_text()
    assert "5 requests: 2 emergency, 2 urgent, 1 routine" in rep


def test_batch_csv_alt_column_and_default_ids():
    res = pm.triage_csv("Request\nToilet clogged\n" + "x" * 80 + " sink\n")
    assert [r["id"] for r in res["results"]] == ["1", "2"]
    assert "..." in pm.batch_report(res).to_text()


def test_batch_csv_errors():
    with pytest.raises(ValidationError, match="'text'"):
        pm.triage_csv("id,body\n1,leak\n")
    with pytest.raises(ValidationError, match="empty"):
        pm.triage_csv("")


def test_emergency_category_gets_no_routine_tips():
    res = t("I smell gas near the stove")
    assert not any("valve behind the toilet" in i for i in res["tenant_instructions"])
    assert res["questions_for_tenant"][0] == "Is everyone out of danger right now?"
    assert not any("water valve" in q for q in res["questions_for_tenant"])
    # the stove is still an appliance issue that needs its own questions
    assert any("brand/model" in q for q in res["questions_for_tenant"])


# --------------------------------------------------------------------------- fail safe on danger words
@pytest.mark.parametrize("text,emergency", [
    ("CO detector is beeping and I have a headache", "carbon monoxide"),
    ("The carbon monoxide alarm went off and my son feels dizzy", "carbon monoxide"),
    ("co alarm keeps beeping, we all feel sick", "carbon monoxide"),
    ("I smell something burning", "fire or sparks"),
    ("There's smoke in the hallway", "fire or sparks"),
    ("Burnt smell coming from the dryer", "fire or sparks"),
    ("The smoke detector is going off and won't stop", "fire or sparks"),
    ("It smells kind of like gas by the stove", "gas smell"),
    ("Propane odor near the grill", "gas smell"),
])
def test_life_safety_is_emergency_and_call_911(text, emergency):
    res = t(text)
    assert res["urgency"] == "emergency", res["matched"]
    assert emergency in res["emergency_types"]
    assert res["call_911"] is True
    assert res["review_now"] is True and res["needs_human_review"] is True
    assert pm.EMERGENCY_INSTRUCTIONS[emergency] in res["tenant_instructions"]
    text_report = pm.triage_report(res).to_text()
    assert "Call 911 first      YES" in text_report and "needs a human to review now" in text_report


@pytest.mark.parametrize("text,emergency", [
    ("water heater burst", "flooding"),
    ("The washing machine hose burst", "flooding"),
    ("No heat and it's below freezing outside", "no heat in freezing weather"),
])
def test_water_and_cold_emergencies_without_911(text, emergency):
    res = t(text)
    assert res["urgency"] == "emergency" and emergency in res["emergency_types"]
    assert res["call_911"] is False and res["review_now"] is True


@pytest.mark.parametrize("text,reason", [
    ("The CO detector keeps beeping", "carbon monoxide"),
    ("Please replace the battery in the carbon monoxide detector", "carbon monoxide"),
    ("Smoke detector chirps every minute", "smoke or fire alarm"),
    ("I don't smell gas anymore", "gas smell"),
    ("No sparks, no burning smell", "fire or sparks"),
    ("Big leak under the kitchen sink", "major water leak"),
    ("There are exposed wires hanging from the ceiling light", "exposed wires"),
    ("The outlet shocked me", "electric shock"),
])
def test_danger_words_are_at_least_urgent_and_flagged(text, reason):
    res = t(text)
    assert res["urgency"] in ("urgent", "emergency"), res["matched"]
    assert res["review_now"] is True
    assert any(reason in r for r in res["review_reasons"])
    md = pm.triage_report(res).to_markdown()
    assert "needs a human to review now" in md and "Why a human must review this now" in md


def test_co_alarm_without_symptoms_is_urgent_with_safety_advice():
    res = t("The CO detector keeps beeping")
    assert res["urgency"] == "urgent" and res["call_911"] is False
    assert any("call 911" in i for i in res["tenant_instructions"])
    assert not any("thermostat" in i for i in res["tenant_instructions"])
    assert res["questions_for_tenant"][0] == "Is everyone out of danger right now?"


@pytest.mark.parametrize("text", [
    "I cooked dinner and now the sink is clogged",
    "The company that fixed the dishwasher left a mess",
    "My coworker says the faucet drips",
    "Our co-op board says the toilet runs",
    "Gas burner on the stove won't light",
    "The fireplace screen is loose",
    "Kitchen faucet drips a little",
    "Thermostat screen is blank",
])
def test_ordinary_requests_stay_routine(text):
    res = t(text)
    assert res["urgency"] == "routine", res["matched"]
    assert res["review_now"] is False and res["review_reasons"] == []
    assert "review now" not in pm.triage_report(res).to_text()


def test_batch_marks_review_now():
    res = pm.triage_csv("id,text\n1,Faucet drips\n2,CO detector keeps beeping\n")
    assert [r["id"] for r in res["results"]] == ["2", "1"]
    out = pm.batch_report(res).to_text()
    assert "URGENT (review now)" in out and "ROUTINE (review now)" not in out
