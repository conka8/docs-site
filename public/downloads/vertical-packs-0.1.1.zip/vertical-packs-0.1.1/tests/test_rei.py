import pytest

from vpacks import rei
from vpacks.common import ValidationError


@pytest.mark.parametrize("principal,rate,years,expected", [
    (300000, 7, 30, 1995.91),
    (160000, 6, 30, 959.28),
    (200000, 4.5, 15, 1529.99),
    (250000, 6.5, 30, 1580.17),
    (120000, 0, 10, 1000.00),  # zero interest -> principal / months
    (0, 7, 30, 0.0),
])
def test_mortgage_payment(principal, rate, years, expected):
    assert round(rei.mortgage_payment(principal, rate, years), 2) == expected


def test_mortgage_bad_term():
    with pytest.raises(ValueError):
        rei.mortgage_payment(1000, 5, 0)


RENTAL = {"purchase_price": 200000, "down_payment_pct": 20, "interest_rate_pct": 6, "loan_term_years": 30,
          "closing_costs": 5000, "monthly_rent": 2000, "vacancy_pct": 5, "capex_pct": 5, "repairs_pct": 5,
          "management_pct": 10, "property_tax_annual": 2400, "insurance_annual": 1200}


def test_rental_hand_computed():
    r = rei.analyze_rental(RENTAL)
    assert r["loan_amount"] == 160000.0
    assert r["down_payment"] == 40000.0
    assert r["monthly_mortgage_payment"] == 959.28
    assert r["vacancy_loss_monthly"] == 100.0
    assert r["effective_gross_income_monthly"] == 1900.0
    # tax 200 + insurance 100 + capex 100 + repairs 100 + management 200
    assert r["operating_expenses_monthly"] == 700.0
    assert r["expense_breakdown_monthly"]["management"] == 200.0
    assert r["noi_monthly"] == 1200.0
    assert r["noi_annual"] == 14400.0
    assert r["cap_rate_pct"] == 7.2  # 14400 / 200000
    assert r["cash_flow_monthly"] == 240.72
    assert r["cash_flow_annual"] == 2888.63  # 240.7192 * 12
    assert r["total_cash_invested"] == 45000.0
    assert r["cash_on_cash_pct"] == 6.42  # 2888.63 / 45000
    assert r["dscr"] == 1.25  # 14400 / 11511.37
    assert r["grm"] == 8.33  # 200000 / 24000
    assert r["one_percent_rule"] == {"rent_to_price_pct": 1.0, "passes": True}
    assert r["fifty_percent_rule"] == {"estimated_cash_flow_monthly": 40.72, "passes": True}


def test_rental_defaults_and_rules_fail():
    r = rei.analyze_rental({"purchase_price": 300000, "interest_rate_pct": 7, "monthly_rent": 2000})
    assert r["monthly_mortgage_payment"] == round(rei.mortgage_payment(240000, 7, 30), 2)
    # defaults: 5% vacancy, 5% capex, 5% repairs, 8% management
    assert r["operating_expenses_monthly"] == 360.0
    assert r["one_percent_rule"]["passes"] is False
    assert r["fifty_percent_rule"]["passes"] is False
    assert r["cash_flow_monthly"] < 0
    assert any("loses money" in n for n in r["notes"])
    assert any("below 1.25" in n for n in r["notes"])


def test_rental_all_cash_dscr_none():
    r = rei.analyze_rental({**RENTAL, "down_payment_pct": 100})
    assert r["monthly_mortgage_payment"] == 0.0
    assert r["dscr"] is None
    assert any("DSCR isn't applicable" in n for n in r["notes"])
    assert r["cash_on_cash_pct"] == round(14400 / 205000 * 100, 2)


def test_rental_zero_interest():
    r = rei.analyze_rental({**RENTAL, "interest_rate_pct": 0})
    assert r["monthly_mortgage_payment"] == round(160000 / 360, 2)


def test_rental_division_by_zero_messages():
    r = rei.analyze_rental({"purchase_price": 0, "interest_rate_pct": 5, "monthly_rent": 0})
    assert r["cap_rate_pct"] is None
    assert r["cash_on_cash_pct"] is None
    assert r["grm"] is None
    assert r["one_percent_rule"] == {"rent_to_price_pct": None, "passes": None}
    notes = " ".join(r["notes"])
    for word in ("Cap rate", "Cash-on-cash", "GRM", "1% rule"):
        assert word in notes
    assert "division by zero" in notes


@pytest.mark.parametrize("bad,msg", [
    ({"purchase_price": -1}, "can't be negative"),
    ({"down_payment_pct": 120}, "at most 100"),
    ({"vacancy_pct": 101}, "vacancy_pct"),
    ({"loan_term_years": 0}, "at least 1"),
    ({"monthly_rent": "lots"}, "must be a number"),
])
def test_rental_validation(bad, msg):
    with pytest.raises(ValidationError, match=msg):
        rei.analyze_rental({**RENTAL, **bad})


def test_rental_missing_required():
    with pytest.raises(ValidationError) as exc:
        rei.analyze_rental({})
    assert {p.split("'")[1] for p in exc.value.problems} == {"purchase_price", "interest_rate_pct", "monthly_rent"}


FLIP = {"arv": 300000, "purchase_price": 180000, "rehab_costs": 40000, "buy_closing_costs": 3000,
        "holding_months": 6, "holding_costs_monthly": 1500, "selling_costs_pct": 8}


def test_flip_cash_hand_computed():
    f = rei.analyze_flip(FLIP)
    assert f["max_allowable_offer"] == 170000.0  # 300000 * 0.7 - 40000
    assert f["meets_mao_rule"] is False
    assert f["holding_costs"] == 9000.0
    assert f["selling_costs"] == 24000.0
    assert f["financing_costs"] == 0.0
    assert f["total_project_cost"] == 256000.0
    assert f["profit"] == 44000.0
    assert f["cash_invested"] == 232000.0
    assert f["roi_pct"] == 18.97  # 44000 / 232000
    assert f["annualized_roi_pct"] == 37.93  # x 12 / 6
    assert any("$10,000.00 above" in n for n in f["notes"])


def test_flip_with_hard_money():
    f = rei.analyze_flip({**FLIP, "loan_amount": 144000, "loan_rate_pct": 10, "loan_points_pct": 2})
    # points 2880 + interest 144000 * 10% / 12 * 6 = 7200
    assert f["financing_costs"] == 10080.0
    assert f["total_project_cost"] == 266080.0
    assert f["profit"] == 33920.0
    assert f["cash_invested"] == 98080.0
    assert f["roi_pct"] == 34.58
    assert f["annualized_roi_pct"] == 69.17


def test_flip_meets_rule_and_edge_cases():
    good = rei.analyze_flip({**FLIP, "purchase_price": 170000})
    assert good["meets_mao_rule"] is True
    zero_months = rei.analyze_flip({**FLIP, "holding_months": 0})
    assert zero_months["annualized_roi_pct"] is None
    assert any("0 months" in n for n in zero_months["notes"])
    fully_financed = rei.analyze_flip({**FLIP, "loan_amount": 500000})
    assert fully_financed["roi_pct"] is None and fully_financed["annualized_roi_pct"] is None
    assert any("ROI can't be calculated" in n for n in fully_financed["notes"])
    loser = rei.analyze_flip({**FLIP, "arv": 200000})
    assert loser["profit"] < 0 and any("loses money" in n for n in loser["notes"])
    custom = rei.analyze_flip({**FLIP, "mao_rule_pct": 75})
    assert custom["max_allowable_offer"] == 185000.0


def test_flip_validation():
    with pytest.raises(ValidationError, match="arv"):
        rei.analyze_flip({"purchase_price": 1})
    with pytest.raises(ValidationError, match="selling_costs_pct"):
        rei.analyze_flip({**FLIP, "selling_costs_pct": 200})


BRRRR = {"purchase_price": 100000, "rehab_costs": 30000, "buy_closing_costs": 3000, "holding_costs": 2000,
         "arv": 180000, "refi_ltv_pct": 75, "refi_closing_costs": 4000, "refi_rate_pct": 7, "refi_term_years": 30,
         "monthly_rent": 1600, "vacancy_pct": 5, "capex_pct": 5, "repairs_pct": 5, "management_pct": 8,
         "property_tax_annual": 1800, "insurance_annual": 1200}


def test_brrrr_hand_computed():
    b = rei.analyze_brrrr(BRRRR)
    assert b["all_in_cost"] == 135000.0
    assert b["refi_loan_amount"] == 135000.0
    assert b["cash_out_at_refi"] == 131000.0
    assert b["cash_left_in_deal"] == 4000.0
    assert b["infinite_return"] is False
    assert b["equity_after_refi"] == 45000.0
    assert b["monthly_mortgage_payment"] == 898.16  # 135000 @ 7% / 30y
    # NOI: 1600 - 80 vacancy - (150 tax + 100 ins + 80 capex + 80 repairs + 128 mgmt) = 982
    assert b["noi_monthly"] == 982.0
    assert b["cash_flow_monthly"] == 83.84
    assert b["cash_flow_annual"] == 1006.1
    assert b["cash_on_cash_pct"] == 25.15
    assert b["dscr"] == 1.09


def test_brrrr_infinite_return():
    b = rei.analyze_brrrr({**BRRRR, "arv": 200000})
    assert b["refi_loan_amount"] == 150000.0
    assert b["cash_left_in_deal"] == -11000.0
    assert b["infinite_return"] is True
    assert b["cash_on_cash_pct"] is None
    assert any("Infinite return" in n for n in b["notes"])


def test_brrrr_with_initial_loan_and_shortfall():
    b = rei.analyze_brrrr({**BRRRR, "initial_loan_amount": 100000})
    assert b["initial_cash_invested"] == 35000.0
    assert b["cash_out_at_refi"] == 31000.0
    assert b["cash_left_in_deal"] == 4000.0
    short = rei.analyze_brrrr({**BRRRR, "initial_loan_amount": 100000, "arv": 120000})
    assert short["cash_out_at_refi"] == -14000.0
    assert any("bring $14,000.00 to closing" in n for n in short["notes"])


def test_brrrr_zero_ltv_no_loan():
    b = rei.analyze_brrrr({**BRRRR, "refi_ltv_pct": 0})
    assert b["monthly_mortgage_payment"] == 0.0
    assert b["dscr"] is None
    assert b["cash_left_in_deal"] == 139000.0


def test_brrrr_validation():
    with pytest.raises(ValidationError, match="refi_rate_pct"):
        rei.analyze_brrrr({k: v for k, v in BRRRR.items() if k != "refi_rate_pct"})


def test_reports_render():
    for fn, rep, data in ((rei.analyze_rental, rei.rental_report, RENTAL), (rei.analyze_flip, rei.flip_report, FLIP),
                          (rei.analyze_brrrr, rei.brrrr_report, BRRRR)):
        res = fn(data)
        assert rep(res).to_text()
        assert rep(res).to_markdown().startswith("# ")
    text = rei.rental_report(rei.analyze_rental(RENTAL)).to_text()
    assert "Monthly P&I          $959.28" in text
    assert "1% rule             1.00% -> pass" in text
    na = rei.rental_report(rei.analyze_rental({"purchase_price": 0, "interest_rate_pct": 5, "monthly_rent": 0}))
    assert "n/a" in na.to_text()
