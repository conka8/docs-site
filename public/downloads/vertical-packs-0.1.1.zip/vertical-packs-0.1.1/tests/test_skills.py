import re

import pytest
import yaml

from conftest import ROOT

SKILLS = sorted((ROOT / "skills").glob("*/SKILL.md"))
PACKS = {"str", "pm", "rei", "freight", "kdp"}


def frontmatter(path):
    text = path.read_text(encoding="utf-8")
    assert text.startswith("---\n"), f"{path} must start with YAML frontmatter"
    end = text.index("\n---\n", 4)
    return yaml.safe_load(text[4:end]), text[end + 5:]


def test_one_skill_per_pack():
    assert {p.parent.name for p in SKILLS} == {f"vpacks-{p}" for p in PACKS}


@pytest.mark.parametrize("path", SKILLS, ids=lambda p: p.parent.name)
def test_skill_frontmatter_valid(path):
    meta, body = frontmatter(path)
    assert isinstance(meta, dict)
    name, desc = meta["name"], meta["description"]
    assert re.fullmatch(r"[a-z0-9-]{1,64}", name)
    assert name == path.parent.name
    assert isinstance(desc, str) and 50 < len(desc) <= 1024
    assert "Use when" in desc or "Use for" in desc or "Use before" in desc
    pack = name.split("-", 1)[1]
    assert f"vpacks {pack}" in body, "skill must show how to run the CLI"
    assert "--format" in body
    assert "verify" in body.lower(), "skill must tell Claude to flag limits that need verifying"


@pytest.mark.parametrize("path", SKILLS, ids=lambda p: p.parent.name)
def test_skill_commands_are_real(path, run):
    """Every `vpacks <pack> <command>` mentioned in a skill exists in the CLI."""
    _, body = frontmatter(path)
    for pack, command in set(re.findall(r"vpacks (str|pm|rei|freight|kdp) ([a-z]+)", body)):
        code, out, _ = run(pack, command, "--help")
        assert code == 0 and "--format" in out
