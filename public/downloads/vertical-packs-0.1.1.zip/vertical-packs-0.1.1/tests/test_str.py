import pytest

from vpacks import str_pack as s
from vpacks.common import ValidationError

LONG_DESC = (
    "Our bright two-bedroom cottage sleeps 4 with a king bed and a queen bed, fresh linens and blackout curtains. "
    "It's a 5-minute walk to the beach and close to downtown restaurants, coffee shops and the farmers market. "
    "Self check-in with a keypad lets you arrive any time after 4pm, and there is free parking for two cars in "
    "the driveway. The kitchen is fully stocked for cooking, the workspace has a fast connection for remote work, "
    "and the porch is perfect for morning coffee."
)


def perfect_listing(**over):
    data = {
        "title": "Sunny Cottage, Walk to Beach, King Bed",
        "description": LONG_DESC,
        "photos": 25,
        "amenities": ["WiFi", "Kitchen", "Washer", "Dryer", "Central air", "Heating", "Free parking",
                      "Smoke detector", "Carbon monoxide alarm", "Keypad", "Coffee maker", "Desk"],
        "market_type": "general",
        "response_rate_pct": 98,
        "rating": 4.92,
        "review_count": 57,
    }
    data.update(over)
    return data


def test_perfect_listing_scores_100():
    res = s.score_listing(perfect_listing())
    assert res["score"] == 100
    assert res["grade"] == "Strong"
    assert res["fixes"] == []
    assert res["amenities_missing"] == []
    assert sum(b["max"] for b in res["breakdown"]) == 100


def test_title_limit_boundary():
    assert len(LONG_DESC) >= 400
    ok = s.score_listing(perfect_listing(title="A" * 10 + "b" * 40))  # exactly 50 chars, mixed case
    assert next(b for b in ok["breakdown"] if b["area"] == "Title")["points"] == 15
    too_long = s.score_listing(perfect_listing(title="x" * 51))
    title = next(b for b in too_long["breakdown"] if b["area"] == "Title")
    assert title["points"] == 0
    fix = too_long["fixes"][0]
    assert fix["priority"] == "high" and fix["area"] == "Title"
    assert "50 characters" in fix["fix"] and "verify current limit" in fix["fix"]
    assert too_long["score"] == 85


def test_short_and_caps_and_empty_title():
    short = s.score_listing(perfect_listing(title="Nice home"))
    assert next(b for b in short["breakdown"] if b["area"] == "Title")["points"] == 8
    caps = s.score_listing(perfect_listing(title="AMAZING BEACH HOUSE WITH POOL"))
    assert next(b for b in caps["breakdown"] if b["area"] == "Title")["points"] == 10
    assert any("ALL CAPS" in f["fix"] for f in caps["fixes"])
    empty = s.score_listing(perfect_listing(title=""))
    assert next(b for b in empty["breakdown"] if b["area"] == "Title")["points"] == 0


@pytest.mark.parametrize("desc,points", [("", 0), ("x" * 100, 0), ("bedroom walk parking " * 5, 5),
                                         ("king bed, 5 minutes to downtown, free parking. " * 4, 12)])
def test_description_points(desc, points):
    res = s.score_listing(perfect_listing(description=desc))
    assert next(b for b in res["breakdown"] if b["area"] == "Description")["points"] == points


def test_description_missing_topics_lose_points():
    res = s.score_listing(perfect_listing(description="Lovely place. " * 40))
    d = next(b for b in res["breakdown"] if b["area"] == "Description")
    assert d["points"] == 20 - 3 * 2
    assert sum(f["area"] == "Description" for f in res["fixes"]) == 3


@pytest.mark.parametrize("photos,points", [(25, 15), (20, 15), (19, 10), (10, 10), (9, 5), (5, 5), (4, 0), (0, 0)])
def test_photo_points(photos, points):
    res = s.score_listing(perfect_listing(photos=photos))
    assert next(b for b in res["breakdown"] if b["area"] == "Photos")["points"] == points


def test_photos_as_list_of_urls():
    res = s.score_listing(perfect_listing(photos=["u"] * 12))
    assert next(b for b in res["breakdown"] if b["area"] == "Photos")["detail"] == "12 photos"


def test_amenities_by_market_and_safety_first():
    res = s.score_listing(perfect_listing(market_type="Beach", amenities=["wifi", "kitchen"]))
    assert res["market_type"] == "beach"
    assert "beach gear" in res["amenities_missing"]
    assert "smoke alarm" in res["amenities_missing"]
    amen = next(b for b in res["breakdown"] if b["area"] == "Amenities")
    assert amen["points"] == round(25 * 2 / len(s.wanted_amenities("beach")))
    assert res["fixes"][0]["area"] == "Amenities" and "smoke alarm" in res["fixes"][0]["fix"]


def test_amenity_alias_matching_is_word_based():
    assert s._has_amenity("air conditioning", ["A/C in every room"])
    assert s._has_amenity("hot tub", ["Private Jacuzzi"])
    assert not s._has_amenity("air conditioning", ["Spacious backyard"])  # 'ac' inside 'space' doesn't count
    assert s.wanted_amenities("urban").count("dedicated workspace") == 1


@pytest.mark.parametrize("rate,points", [(None, 5), (90, 10), (89, 6), (75, 6), (74, 2)])
def test_response_rate_points(rate, points):
    res = s.score_listing(perfect_listing(response_rate_pct=rate))
    assert next(b for b in res["breakdown"] if b["area"] == "Response rate")["points"] == points


@pytest.mark.parametrize("rating,count,points", [
    (None, 0, 5), (4.9, 0, 5), (4.8, 10, 15), (4.6, 10, 11), (4.6, 5, 9), (4.2, 2, 3),
])
def test_review_points(rating, count, points):
    res = s.score_listing(perfect_listing(rating=rating, review_count=count))
    assert next(b for b in res["breakdown"] if b["area"] == "Reviews")["points"] == points


def test_grades_and_fix_ordering():
    weak = s.score_listing({"title": "Room", "market_type": "urban"})
    assert weak["grade"] == "Weak"
    ranks = [s.PRIORITY_RANK[f["priority"]] for f in weak["fixes"]]
    assert ranks == sorted(ranks)
    mid = s.score_listing(perfect_listing(photos=0, response_rate_pct=50))
    assert mid["score"] == 77 and mid["grade"] == "Good"
    low = s.score_listing(perfect_listing(photos=0, response_rate_pct=50, title="x" * 60))
    assert low["grade"] == "Needs work"


def test_listing_validation():
    with pytest.raises(ValidationError, match="market_type"):
        s.score_listing(perfect_listing(market_type="moon"))
    with pytest.raises(ValidationError, match="Missing required field 'title'"):
        s.score_listing({"photos": 3})
    with pytest.raises(ValidationError, match="'rating' must be at most 5"):
        s.score_listing(perfect_listing(rating=6))
    with pytest.raises(ValidationError, match="response_rate_pct"):
        s.score_listing(perfect_listing(response_rate_pct=101))


def test_listing_report_renders():
    rep = s.listing_report(s.score_listing(perfect_listing(photos=3)))
    assert "Score" in rep.to_text() and "| Photos |" in rep.to_markdown()


# ---------------------------------------------------------------- revenue
BASE_REV = {"adr": 200, "occupancy_pct": 50, "avg_stay_nights": 2, "cleaning_fee": 100, "cleaning_cost": 80,
            "platform_fee_pct": 3, "monthly_costs": {"mortgage": 1500, "utilities": 300}}


def test_revenue_hand_computed():
    res = s.estimate_revenue(BASE_REV)
    jan = res["monthly"][0]
    # Jan: 31 nights * 50% = 15.5 booked, 7.75 stays
    assert jan["booked_nights"] == 15.5
    assert jan["rental_income"] == 3100.0
    assert jan["cleaning_income"] == 775.0
    assert jan["gross_revenue"] == 3875.0
    assert jan["platform_fees"] == 116.25
    assert jan["cleaning_costs"] == 620.0
    assert jan["net_income"] == 1338.75
    a = res["annual"]
    assert a["booked_nights"] == 182.5
    assert a["gross_revenue"] == 45625.0
    assert a["platform_fees"] == 1368.75
    assert a["cleaning_costs"] == 7300.0
    assert a["fixed_costs"] == 21600.0
    assert a["net_income"] == 15356.25
    assert res["average_monthly_net"] == 1279.69
    assert res["effective_occupancy_pct"] == 50.0
    # contribution per night = (200 + 100/2) * 0.97 - 80/2 = 202.5 ; 21600 / 202.5 / 365 = 29.22%
    assert res["contribution_per_booked_night"] == 202.5
    assert res["breakeven_occupancy_pct"] == 29.22


def test_revenue_management_fee_and_blocked_nights():
    res = s.estimate_revenue({**BASE_REV, "management_pct": 20, "owner_blocked_nights_per_month": 1})
    jan = res["monthly"][0]
    assert jan["available_nights"] == 30.0
    assert jan["booked_nights"] == 15.0
    assert jan["management_fees"] == round((3000 + 750) * 0.20, 2)


def test_zero_occupancy():
    res = s.estimate_revenue({**BASE_REV, "occupancy_pct": 0})
    assert res["annual"]["gross_revenue"] == 0.0
    assert res["annual"]["net_income"] == -21600.0
    assert res["breakeven_occupancy_pct"] == 29.22


def test_seasonality_and_cap():
    season = [0.5] * 6 + [2.0] * 6
    res = s.estimate_revenue({**BASE_REV, "occupancy_pct": 60, "seasonality": season})
    assert res["monthly"][0]["booked_nights"] == 9.3  # 31 * 0.6 * 0.5
    assert res["monthly"][6]["booked_nights"] == 31.0  # capped at 100%
    assert any("capped" in n for n in res["notes"])


def test_breakeven_edge_cases():
    no_fixed = s.estimate_revenue({"adr": 100, "occupancy_pct": 50})
    assert no_fixed["breakeven_occupancy_pct"] == 0.0
    assert any("Platform fee defaulted" in n for n in no_fixed["notes"])
    losing = s.estimate_revenue({"adr": 10, "occupancy_pct": 50, "avg_stay_nights": 1, "cleaning_cost": 100,
                                 "monthly_costs": {"rent": 100}})
    assert losing["breakeven_occupancy_pct"] is None
    assert any("loses money" in n for n in losing["notes"])
    blocked = s.estimate_revenue({"adr": 100, "occupancy_pct": 50, "owner_blocked_nights_per_month": 31,
                                  "monthly_costs": {"rent": 100}})
    assert blocked["breakeven_occupancy_pct"] is None
    assert blocked["effective_occupancy_pct"] is None
    assert any("division by zero" in n for n in blocked["notes"])
    unreachable = s.estimate_revenue({"adr": 10, "occupancy_pct": 50, "monthly_costs": {"rent": 5000}})
    assert unreachable["breakeven_occupancy_pct"] > 100
    assert any("above 100%" in n for n in unreachable["notes"])


@pytest.mark.parametrize("bad,msg", [
    ({"occupancy_pct": 120}, "at most 100"),
    ({"occupancy_pct": -5}, "can't be negative"),
    ({"adr": -1}, "'adr' can't be negative"),
    ({"seasonality": [1] * 11}, "exactly 12"),
    ({"avg_stay_nights": 0}, "at least 0.5"),
    ({"platform_fee_pct": 150}, "platform_fee_pct"),
])
def test_revenue_validation(bad, msg):
    with pytest.raises(ValidationError, match=msg):
        s.estimate_revenue({**BASE_REV, **bad})


def test_revenue_missing_fields():
    with pytest.raises(ValidationError) as exc:
        s.estimate_revenue({})
    assert len(exc.value.problems) == 2


def test_revenue_report():
    text = s.revenue_report(s.estimate_revenue(BASE_REV)).to_text()
    assert "Net income               $15,356.25" in text
    assert "Break-even occupancy     29.22%" in text


# ---------------------------------------------------------------- messages
GUEST = {"guest_name": "Maria Lopez", "host_name": "Adam", "property_name": "Seaside Cottage",
         "address": "12 Dune Rd", "checkin_date": "June 12", "checkin_time": "4 PM", "checkout_date": "June 15",
         "checkout_time": "10 AM", "door_code": "4821", "wifi_name": "Guest", "wifi_password": "pw",
         "parking": "Driveway", "house_rules": ["No parties"], "checkout_tasks": ["Start the dishwasher"],
         "review_link": "https://example.com/r", "issue_description": "the AC not cooling", "eta": "6 PM"}


def test_checkin_message_complete():
    res = s.guest_message("checkin", GUEST)
    assert res["subject"] == "Check-in details for Seaside Cottage"
    assert res["message"].startswith("Hi Maria!")
    assert "Door code: 4821" in res["message"] and "- No parties" in res["message"]
    assert res["message"].rstrip().endswith("Adam")
    assert res["missing_fields"] == []
    assert any("24-48 hours" in t for t in res["tips"])


def test_checkin_missing_fields_get_placeholders():
    res = s.guest_message("checkin", {"guest_name": "Bo", "host_name": "Al"})
    assert "[door code]" in res["message"]
    assert "door_code" in res["missing_fields"] and "address" in res["missing_fields"]
    assert res["subject"] == "Check-in details for your stay"
    assert "house rules" not in res["message"]


def test_checkout_review_issue_messages():
    out = s.guest_message("checkout", GUEST)
    assert "checkout is June 15 by 10 AM" in out["message"]
    assert "- Start the dishwasher" in out["message"]
    review = s.guest_message("review-request", GUEST)
    assert "https://example.com/r" in review["message"]
    assert any("Don't offer discounts" in t for t in review["tips"])
    no_link = s.guest_message("review-request", {**GUEST, "review_link": ""})
    assert "leave one here" not in no_link["message"]
    issue = s.guest_message("issue", GUEST)
    assert "so sorry about the AC not cooling" in issue["message"]
    assert "sorted by 6 PM" in issue["message"]
    assert "I'm arranging a fix right now." in issue["message"]
    no_eta = s.guest_message("issue", {**GUEST, "eta": "", "fix_plan": "A tech arrives at 3"})
    assert "A tech arrives at 3." in no_eta["message"] and "eta" in no_eta["missing_fields"]


def test_message_validation():
    with pytest.raises(ValidationError, match="issue_description"):
        s.guest_message("issue", {"guest_name": "A", "host_name": "B"})
    with pytest.raises(ValidationError, match="Message type"):
        s.guest_message("welcome", GUEST)
    with pytest.raises(ValidationError, match="guest_name"):
        s.guest_message("checkin", {"host_name": "B"})


def test_message_report_md_is_copyable():
    md = s.message_report(s.guest_message("checkin", {"guest_name": "Bo", "host_name": "Al"})).to_markdown()
    assert "```text\nHi Bo!" in md
    assert "## Fill in before sending" in md
