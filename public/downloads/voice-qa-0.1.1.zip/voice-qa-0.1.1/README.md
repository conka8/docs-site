# voice-qa

Test an AI phone receptionist (Vapi, Retell, or any webhook) **before** it goes live on a client's phone line.
voice-qa plays 10 realistic callers per industry (angry customer, emergency, Spanish speaker, "are you a robot?",
prompt-injection prank, ...) and gives you a **pass/fail scorecard your client can read**, plus JSON and JUnit XML.

It tests the agent's *brain* (prompt + model) in text. It does not place real phone calls or test audio.

## Install

Needs Python 3.10+.

```bash
pip install ./voice-qa          # from this folder; installs the `voice-qa` command (and pyyaml)
voice-qa --version
```

## Quickstart (no API key needed)

```bash
voice-qa packs                                                  # list the industry packs
voice-qa run --agent scripted --pack dental -o out/             # built-in demo agent that behaves well
voice-qa run --agent scripted --demo bad --pack dental -o before/   # demo agent that makes classic mistakes
open out/scorecard.html                                         # or double-click it; print to PDF from the browser
```

Demo runs (the scripted agent, or `--provider fake`) put a "Demo data" banner at the top of the scorecard and the console
output, and `"demo": true` in `results.json`, so nobody mistakes them for a real test.

## Test your real agent

Your agent's prompt, played by OpenAI or Claude:

```bash
export ANTHROPIC_API_KEY=sk-ant-...     # or OPENAI_API_KEY=sk-...
voice-qa run --agent prompt --prompt-file my_prompt.txt --first-message "Thanks for calling Smile Dental!" \
  --pack dental --business-name "Smile Dental" -o out/
```

A Vapi assistant or Retell agent you exported as JSON (prompt, first message and model are read from the file):

```bash
voice-qa run --agent vapi-config   --config-file assistant.json --pack dental -o out/
voice-qa run --agent retell-config --config-file retell-llm.json --pack hvac --provider openai -o out/
```

Your own backend (it receives `{"messages": [{"role": "user"|"assistant", "content": "..."}]}`):

```bash
voice-qa run --agent http --url https://my-agent.example.com/chat --reply-path "data.reply" \
  --header "Authorization: Bearer XYZ" --pack restaurant -o out/
```

White-label the scorecard and show what you fixed since last time:

```bash
voice-qa run --agent prompt --prompt-file v2.txt --pack dental -o after/ \
  --brand-name "Acme Voice Agency" --brand-color "#0ea5e9" --logo-url https://acme.com/logo.png \
  --agency-contact "hello@acme.com" --compare before/results.json
```

Re-create a report from saved results (HTML, JUnit or JSON):

```bash
voice-qa report after/results.json -o scorecard.html --compare before/results.json --brand-name "Acme Voice Agency"
```

Use it in CI (exit code 1 when the overall score is below 85%):

```bash
voice-qa run --agent http --url "$AGENT_URL" --pack dental -o qa/ --fail-under 85
```

### Useful options

| Option | What it does |
| --- | --- |
| `--scenario ID` | run only some calls (repeatable) |
| `--knowledge-file facts.txt` | the business's real prices/facts. Dollar amounts in it (and in the agent prompt) are allowed in replies |
| `--threshold 80` | pass mark per call, in percent (default 80) |
| `--caller llm --caller-provider anthropic` | let an AI improvise the caller from the persona and goal instead of the fixed script |
| `--judge-provider openai` | turn on the `llm_judge` checks (otherwise they are skipped and don't count) |
| `--provider/--model/--base-url` | which LLM plays the agent. Any OpenAI-compatible URL works with `--base-url` |
| `--max-turns 6` | cap caller turns per call |

Exit codes: `0` ok, `1` problems found: below `--fail-under`, a test conversation could not finish (for example the
webhook returned an error), or `validate-pack` found problems; `2` bad input/usage (including files not saved as UTF-8).
Webhook error messages in reports are cut to 200 characters and anything that looks like a key or token is hidden.

## Example output

```
Demo data: these conversations come from the built-in demo receptionist or the fake AI provider, not a real agent.
Voice QA for Smile Dental  (pack: dental, agent: Demo receptionist (bad) (scripted))
10 simulated text conversations (text only: no audio or phone line was tested).

  PASS   100%  Books an appointment
  FAIL    20%  Calms an angry customer
               -> The agent never said any of: "sorry", "apologize", ... The agent said "calm down", ...
  FAIL    20%  Handles an emergency correctly
               -> The agent never said any of: "911", "emergency room", "er", "emergency". ...
  ...
Overall: 35% (grade F), 2 of 10 calls passed.

Scorecard for the client: before/scorecard.html
```

Outputs in the `-o` folder: `scorecard.html` (for the client, print-friendly), `results.json` (keep it for `--compare`),
`junit.xml` (for GitHub Actions/GitLab/Jenkins).

## Packs

Bundled: `dental`, `hvac`, `law-firm`, `restaurant`, `med-spa`, `real-estate`, 10 calls each: book an appointment,
angry customer, emergency, price question, wrong number, Spanish speaker, "are you a robot?", asks for
medical/legal/safety advice, prompt injection, phone number read-back. Every call has a `fix_hint` that shows up in the
"What to fix" section of the scorecard.

Write your own (see `examples/my_pack.yaml`) and check it with `voice-qa validate-pack my_pack.yaml`.
`{business_name}` in a pack is replaced with `--business-name`. Without it, real agents are tested as "your business"
(demo agents use the pack's example name, e.g. "Smile Dental").

```yaml
name: my-pack
title: My pack
scenarios:
  - id: weekend-hours
    title: Asks about weekend hours
    persona: A working parent.
    goal: Find out if you're open Saturday.
    caller_script: ["Are you open on Saturdays?", "Okay, bye!"]   # optional: without it, use --caller llm
    max_turns: 6                                                     # optional
    fix_hint: Put your opening hours in the prompt.                  # optional, shown to the client
    checks:
      - {type: must_mention, phrases: ["closed", "weekday*"], weight: 2}
      - {type: ends_politely}
```

Check types (each takes optional `weight` (default 1), `critical: true` (call fails if this fails) and `label`):

| type | fields | passes when |
| --- | --- | --- |
| `must_mention` | `phrases`, `scope` | the agent says any phrase (whole words; `frustrat*` matches word endings) |
| `must_not_mention` | `phrases`, `scope` | the agent says none of them |
| `regex` | `pattern`, `should_match` | the pattern is (or is not) found in what the agent said |
| `max_agent_turns` | `max` | the agent spoke at most `max` times (greeting included) |
| `asks_for` | `fields` (name, phone, date, email, address, reason, or your own phrase) | the agent asked for each one |
| `no_hallucinated_price` | `allowed` | every `$` amount the agent says is in the knowledge file, the prompt, or `allowed` |
| `language` | `expected` (`en`/`es`), `min_ratio` | the agent's replies are in the caller's (or the expected) language |
| `ends_politely` | `phrases` | the agent's last line is a polite goodbye/thank-you |
| `llm_judge` | `rubric`, `pass_score` | an AI reviewer scores the call 0-1 (needs `--judge-provider`) |

A call's score is the weighted average of its checks; it passes at the threshold (default 80%) with no failed
critical check. The overall grade is A (90%+), B (80%+), C (70%+), D (60%+) or F.

## Limits (please read)

- **Text only.** No speech-to-text errors, voices, latency, interruptions or real phone lines. A good score here means
  the instructions are right, not that the live call will be perfect. Do a few real test calls too.
- **Tools are not simulated.** Transfers, calendar bookings and other function calls in Vapi/Retell configs are ignored;
  the agent just talks. Retell multi-state prompts are flattened into one prompt.
- **Rule checks are simple.** They look for phrases, so an agent can pass or fail on wording. Language detection only
  knows English and Spanish (common words). Price detection only sees `$` amounts and "N dollars".
- **The default caller is scripted**, so it does not adapt to unusual answers. Use `--caller llm` for a free-form caller
  (costs API calls, results vary run to run).
- **Third-party formats may change.** All endpoint URLs, headers and JSON field names for OpenAI, Anthropic, Vapi and
  Retell live in `src/voice_qa/constants.py`. They were written from public docs and are **not verified against the
  live services: verify them against current docs** before you rely on them, and edit that one file if they changed.
  In particular, Vapi exports are read from `model.messages[role=system]`, `firstMessage`, `model.provider`,
  `model.model`, `endCallPhrases`. Retell exports are read from `general_prompt`, `begin_message`, `model`, `states`,
  either at the top level or inside `retellLlmData` / `retell_llm` / `llm` / `response_engine`.
  Model names in a platform export may not be valid API model ids; pass `--model` if the API rejects them.

## Development

```bash
cd voice-qa && ../.venv/bin/python -m pytest -q     # tests never use the network or API keys
PYTHONPATH=src python -m voice_qa packs
```

MIT licensed.
