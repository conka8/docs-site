---
name: voice-qa
description: Test an AI voice receptionist (Vapi, Retell, a webhook, or just its system prompt) with simulated callers from industry scenario packs (dental, HVAC, law firm, restaurant, med spa, real estate) and produce a client-ready HTML pass/fail scorecard, JSON results and JUnit XML. Use when someone wants to QA, test, grade or audit a voice agent / AI receptionist / phone bot, compare a new prompt version against an old one, or make a scorecard to show a client.
---

# voice-qa: test an AI phone receptionist

Use the `voice-qa` command line tool. If it is not installed, run `pip install <path-to>/voice-qa`
(or from the project folder: `PYTHONPATH=src python -m voice_qa ...`).

## 1. Find out what to test

Ask the user (only for what is missing):
1. **How to reach the agent**: a system prompt text file, a Vapi assistant JSON export, a Retell agent/LLM JSON export,
   or a webhook URL. No agent yet? Use the built-in demo: `--agent scripted` (good) or `--agent scripted --demo bad`.
2. **Industry pack**: run `voice-qa packs` and pick the closest (`dental`, `hvac`, `law-firm`, `restaurant`, `med-spa`,
   `real-estate`).
3. **Business name**, and optionally a text file with the business's real prices/facts (`--knowledge-file`).
4. Optional branding for the scorecard: agency name, colour, logo URL, contact line.

For `prompt`, `vapi-config` and `retell-config` an LLM plays the agent, so `ANTHROPIC_API_KEY` or `OPENAI_API_KEY`
must be set (or `--provider fake` for a dry run). Never print or ask the user to paste API keys into the chat.

## 2. Run it

```bash
voice-qa run --agent prompt --prompt-file prompt.txt --pack dental --business-name "Smile Dental" -o voice-qa-out/
voice-qa run --agent vapi-config --config-file assistant.json --pack dental -o voice-qa-out/
voice-qa run --agent retell-config --config-file agent.json --pack hvac -o voice-qa-out/
voice-qa run --agent http --url https://example.com/agent --reply-path reply --pack restaurant -o voice-qa-out/
```

Add `--brand-name "Agency" --brand-color "#0ea5e9" --logo-url https://... --agency-contact "email"` for white-label,
`--compare old/results.json` after changing the prompt, `--judge-provider anthropic` to enable AI-judged checks.

## 3. Report back

- Read the console summary (or `voice-qa-out/results.json`). Tell the user the grade, how many calls passed, and the
  **critical** failures first (emergency handling, claiming to be human, prompt injection, giving advice, made-up prices).
- For each failed call, quote the `fix_hint` and propose the exact sentence to add to their agent's prompt.
  If they agree, edit the prompt file and re-run with `--compare` to show the improvement.
- Point them to `voice-qa-out/scorecard.html` (open in a browser, print to PDF for the client).

## Notes

- Text-only simulation: it checks what the agent says, not voice, latency or real phone behaviour.
- Custom scenarios: write a pack YAML (see the README) and run `voice-qa validate-pack file.yaml` before using it.
- Exit codes: 0 ok, 1 below `--fail-under` or a test conversation could not finish, 2 bad input. Platform field names live in `src/voice_qa/constants.py`
  and should be verified against current Vapi/Retell docs.
