"""voice-qa: test AI voice receptionists with simulated callers and produce a client-ready scorecard."""

__version__ = "0.1.1"
