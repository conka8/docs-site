"""Agents under test: prompt + LLM, generic HTTP webhook, Vapi/Retell config importers, scripted fake."""

from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from importlib import resources
from pathlib import Path
from typing import Any, Iterable

from . import constants as C
from .conversation import AgentReply, Turn, to_messages
from .providers import Provider
from .textutil import detect_language, find_phone_numbers, find_phrase, not_utf8_message
from .transport import HttpError, Transport, post_json


class AdapterError(Exception):
    """The agent config is invalid or the agent could not be reached."""


# ---------------------------------------------------------------- prompt agent


class PromptAgent:
    """Plays the agent with its own system prompt on an LLM provider."""

    kind = "prompt"

    def __init__(self, system_prompt: str, provider: Provider, first_message: str | None = None,
                 end_call_phrases: Iterable[str] = (), name: str = "prompt agent"):
        if not (system_prompt or "").strip():
            raise AdapterError("The agent's system prompt is empty.")
        self.system_prompt = system_prompt
        self.provider = provider
        self.first_message = first_message or None
        self.end_call_phrases = [p for p in end_call_phrases if p and p.strip()]
        self.name = name

    @property
    def known_text(self) -> str:
        return self.system_prompt + "\n" + (self.first_message or "")

    def describe(self) -> str:
        return f"{self.name} on {self.provider.describe()}"

    def reply(self, transcript: list[Turn]) -> AgentReply:
        text = self.provider.complete(self.system_prompt, to_messages(transcript, me="agent"))
        end = bool(self.end_call_phrases) and find_phrase(text, self.end_call_phrases) is not None
        return AgentReply(text, end)


# ---------------------------------------------------------------- http agent

_PATH_TOKEN = re.compile(r"[^.\[\]]+|\[(\d+)\]")


def get_path(obj: Any, path: str) -> Any:
    """Read a value with a simple JSON path: ``reply``, ``data.text``, ``choices[0].message.content``,
    ``choices.0.message.content`` (a leading ``$.`` is allowed). Raises KeyError if missing."""
    p = (path or "").strip()
    if p.startswith("$"):
        p = p[1:].lstrip(".")
    if not p:
        return obj
    cur = obj
    for m in _PATH_TOKEN.finditer(p):
        key = m.group(1) if m.group(1) is not None else m.group(0)
        if isinstance(cur, list):
            try:
                cur = cur[int(key)]
            except (ValueError, IndexError) as e:
                raise KeyError(f"'{path}': no item {key}") from e
        elif isinstance(cur, dict):
            if key not in cur:
                raise KeyError(f"'{path}': no field '{key}'")
            cur = cur[key]
        else:
            raise KeyError(f"'{path}': cannot look inside {type(cur).__name__} for '{key}'")
    return cur


class HttpAgent:
    """POSTs ``{"messages": [{"role", "content"}...]}`` to your webhook and reads the reply text."""

    kind = "http"

    def __init__(self, url: str, reply_path: str = C.HTTP_AGENT_DEFAULT_REPLY_PATH, *,
                 headers: dict | None = None, end_call_path: str | None = None,
                 extra_body: dict | None = None, first_message: str | None = None,
                 transport: Transport | None = None, sleep=None, timeout: float = C.HTTP_TIMEOUT_SECONDS):
        if not url or not re.match(r"^https?://", url):
            raise AdapterError(f"The agent URL must start with http:// or https:// (got {url!r}).")
        self.url = url
        self.reply_path = reply_path or C.HTTP_AGENT_DEFAULT_REPLY_PATH
        self.headers = dict(headers or {})
        self.end_call_path = end_call_path
        self.extra_body = dict(extra_body or {})
        self.first_message = first_message
        self.transport = transport
        self.sleep = sleep
        self.timeout = timeout
        self.known_text = ""

    def describe(self) -> str:
        return f"webhook {self.url}"

    def build_payload(self, transcript: list[Turn]) -> dict:
        msgs = [
            {"role": C.HTTP_AGENT_ROLE_AGENT if t.role == "agent" else C.HTTP_AGENT_ROLE_CALLER, "content": t.text}
            for t in transcript
        ]
        payload = dict(self.extra_body)
        payload["messages"] = msgs
        return payload

    def reply(self, transcript: list[Turn]) -> AgentReply:
        try:
            data = post_json(self.url, self.build_payload(transcript), self.headers, transport=self.transport,
                             sleep=self.sleep, timeout=self.timeout)
        except HttpError as e:
            raise AdapterError(f"agent webhook failed: {e}") from e
        try:
            text = get_path(data, self.reply_path)
        except KeyError as e:
            raise AdapterError(f"agent webhook reply: {e.args[0]} (set --reply-path to where the text is)") from e
        if not isinstance(text, str):
            text = json.dumps(text) if text is not None else ""
        end = False
        if self.end_call_path:
            try:
                end = bool(get_path(data, self.end_call_path))
            except KeyError:
                end = False
        return AgentReply(text.strip(), end)


# ---------------------------------------------------------------- scripted agent


class ScriptedAgent:
    """Deterministic fake agent for demos and tests.

    Script format (YAML or JSON)::

        first_message: "Thanks for calling {business_name}!"
        default: "Could you tell me more?"
        rules:                       # first matching rule wins, checked against the caller's last line
          - if_any: ["robot", "real person"]   # phrases (whole words, * = any ending)
            if_regex: "..."                     # optional regex instead of / as well as if_any
            language: es                        # optional: only when the caller's line is in this language
            say: "I'm an AI assistant..."       # {business_name} and {caller_phone} are filled in
            end_call: false
    """

    kind = "scripted"

    def __init__(self, script: dict, business_name: str = "our office", name: str = "scripted agent"):
        if not isinstance(script, dict):
            raise AdapterError("A scripted agent must be a mapping with 'rules' and/or 'default'.")
        self.script = script
        self.business_name = business_name
        self.name = script.get("name") or name
        self.rules = []
        for i, rule in enumerate(script.get("rules") or []):
            if not isinstance(rule, dict) or "say" not in rule:
                raise AdapterError(f"scripted agent rule #{i + 1} needs a 'say' line")
            if not rule.get("if_any") and not rule.get("if_regex") and not rule.get("language"):
                raise AdapterError(f"scripted agent rule #{i + 1} needs 'if_any', 'if_regex' or 'language'")
            self.rules.append(rule)
        self.default = script.get("default", "Could you tell me a bit more about what you need?")
        fm = script.get("first_message")
        self.first_message = self._fill(fm, []) if fm else None
        self.known_text = str(script.get("knowledge", ""))

    def describe(self) -> str:
        return f"{self.name} (scripted)"

    def _fill(self, text: str, transcript: list[Turn]) -> str:
        phone = ""
        for t in reversed(transcript):
            if t.role == "caller":
                nums = find_phone_numbers(t.text)
                if nums:
                    phone = nums[-1]
                    break
        return str(text).replace("{business_name}", self.business_name).replace("{caller_phone}", phone)

    def _matches(self, rule: dict, text: str) -> bool:
        if rule.get("language") and detect_language(text) != rule["language"]:
            return False
        if rule.get("if_any") and find_phrase(text, rule["if_any"]) is None:
            return False
        if rule.get("if_regex") and not re.search(rule["if_regex"], text, re.IGNORECASE):
            return False
        return True

    def reply(self, transcript: list[Turn]) -> AgentReply:
        last = next((t.text for t in reversed(transcript) if t.role == "caller"), "")
        for rule in self.rules:
            if self._matches(rule, last):
                return AgentReply(self._fill(rule["say"], transcript), bool(rule.get("end_call")))
        return AgentReply(self._fill(self.default, transcript), False)


def _load_data_file(path: str | Path) -> Any:
    p = Path(path)
    if not p.is_file():
        raise AdapterError(f"File not found: {p}")
    try:
        text = p.read_text(encoding="utf-8")
    except UnicodeDecodeError as e:
        raise AdapterError(not_utf8_message(p)) from e
    if p.suffix.lower() == ".json":
        try:
            return json.loads(text)
        except json.JSONDecodeError as e:
            raise AdapterError(f"{p} is not valid JSON: {e}") from e
    import yaml

    try:
        return yaml.safe_load(text)
    except yaml.YAMLError as e:
        raise AdapterError(f"{p} is not valid YAML: {e}") from e


def load_script(path: str | Path) -> dict:
    data = _load_data_file(path)
    if not isinstance(data, dict):
        raise AdapterError(f"{path}: a scripted agent file must be a mapping")
    return data


DEMO_AGENTS = ("good", "bad")


def demo_script(name: str = "good") -> dict:
    """Bundled demo receptionists: 'good' handles the packs well, 'bad' makes classic mistakes."""
    if name not in DEMO_AGENTS:
        raise AdapterError(f"Unknown demo agent '{name}'. Choose: {', '.join(DEMO_AGENTS)}")
    import yaml

    text = resources.files("voice_qa").joinpath("demo", f"{name}_receptionist.yaml").read_text(encoding="utf-8")
    return yaml.safe_load(text)


# ---------------------------------------------------------------- Vapi / Retell importers


@dataclass
class ImportedConfig:
    platform: str
    name: str
    system_prompt: str
    first_message: str | None = None
    model: str | None = None
    provider: str | None = None  # our provider name if we can map it
    platform_provider: str | None = None
    end_call_phrases: list = field(default_factory=list)
    notes: list = field(default_factory=list)


def _map_provider(raw: Any) -> str | None:
    return C.PLATFORM_PROVIDER_MAP.get(str(raw).lower()) if raw else None


def import_vapi(data: dict) -> ImportedConfig:
    """Pull prompt, first message and model out of a Vapi assistant JSON export."""
    if not isinstance(data, dict):
        raise AdapterError("Vapi config must be a JSON object (the assistant).")
    model = data.get(C.VAPI_MODEL_KEY) or {}
    if isinstance(model, str):
        model = {C.VAPI_MODEL_NAME_KEY: model}
    prompt_parts = []
    for m in model.get(C.VAPI_MODEL_MESSAGES_KEY) or []:
        if isinstance(m, dict) and m.get("role") == "system" and m.get("content"):
            prompt_parts.append(str(m["content"]))
    if not prompt_parts:
        for key in C.VAPI_SYSTEM_PROMPT_LEGACY_KEYS:
            if model.get(key):
                prompt_parts.append(str(model[key]))
            elif data.get(key):
                prompt_parts.append(str(data[key]))
    if not prompt_parts:
        raise AdapterError(
            "Could not find a system prompt in this Vapi file (looked in model.messages[role=system] "
            "and systemPrompt). Is it an assistant export?"
        )
    raw_provider = model.get(C.VAPI_MODEL_PROVIDER_KEY)
    cfg = ImportedConfig(
        platform="vapi",
        name=str(data.get(C.VAPI_NAME_KEY) or "Vapi assistant"),
        system_prompt="\n\n".join(prompt_parts),
        first_message=data.get(C.VAPI_FIRST_MESSAGE_KEY) or None,
        model=model.get(C.VAPI_MODEL_NAME_KEY) or None,
        provider=_map_provider(raw_provider),
        platform_provider=raw_provider,
        end_call_phrases=[str(p) for p in data.get(C.VAPI_END_CALL_PHRASES_KEY) or []],
    )
    if raw_provider and not cfg.provider:
        cfg.notes.append(f"Vapi model provider '{raw_provider}' is not supported here; pick one with --provider.")
    if data.get("tools") or model.get("tools") or model.get("toolIds"):
        cfg.notes.append("Tools/functions in the Vapi config are not simulated (text-only test).")
    return cfg


def import_retell(data: dict) -> ImportedConfig:
    """Pull prompt, begin message and model out of a Retell agent or Retell LLM JSON export."""
    if not isinstance(data, dict):
        raise AdapterError("Retell config must be a JSON object.")
    llm = data if C.RETELL_PROMPT_KEY in data else None
    if llm is None:
        for key in C.RETELL_LLM_CONTAINER_KEYS:
            inner = data.get(key)
            if isinstance(inner, dict) and C.RETELL_PROMPT_KEY in inner:
                llm = inner
                break
    if llm is None or not str(llm.get(C.RETELL_PROMPT_KEY) or "").strip():
        raise AdapterError(
            f"Could not find '{C.RETELL_PROMPT_KEY}' in this Retell file. Export the Retell LLM "
            "(or an agent export that includes it)."
        )
    prompt = str(llm[C.RETELL_PROMPT_KEY])
    notes = []
    states = llm.get(C.RETELL_STATES_KEY) or []
    state_texts = [
        f"## State: {s.get(C.RETELL_STATE_NAME_KEY, 'state')}\n{s[C.RETELL_STATE_PROMPT_KEY]}"
        for s in states if isinstance(s, dict) and s.get(C.RETELL_STATE_PROMPT_KEY)
    ]
    if state_texts:
        prompt += "\n\n" + "\n\n".join(state_texts)
        notes.append("Multi-state prompt flattened into one prompt; state transitions are not simulated.")
    name = next((str(data[k]) for k in C.RETELL_NAME_KEYS if data.get(k)), "Retell agent")
    model = llm.get(C.RETELL_MODEL_KEY) or None
    provider = None
    if model:
        low = str(model).lower()
        provider = "anthropic" if low.startswith("claude") else "openai" if low.startswith(("gpt", "o1", "o3", "o4")) else None
    return ImportedConfig(
        platform="retell",
        name=name,
        system_prompt=prompt,
        first_message=llm.get(C.RETELL_BEGIN_MESSAGE_KEY) or None,
        model=model,
        provider=provider,
        platform_provider=None,
        notes=notes,
    )


def load_platform_config(path: str | Path, platform: str) -> ImportedConfig:
    data = _load_data_file(path)
    if platform == "vapi":
        return import_vapi(data)
    if platform == "retell":
        return import_retell(data)
    raise AdapterError(f"Unknown platform '{platform}'")


# re-export for convenience
__all__ = [
    "AdapterError", "PromptAgent", "HttpAgent", "ScriptedAgent", "ImportedConfig", "get_path",
    "import_vapi", "import_retell", "load_platform_config", "load_script", "demo_script", "DEMO_AGENTS",
]
