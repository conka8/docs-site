"""Judges that grade one call transcript. Each returns a CheckResult with a plain-English explanation."""

from __future__ import annotations

import json
import re
from dataclasses import asdict, dataclass, field
from typing import Any, Callable

from .conversation import Turn
from .textutil import (
    ASK_PATTERNS, LANGUAGE_NAMES, POLITE_CLOSINGS, detect_language, extract_amounts, find_phrase,
    find_phrases, format_amount, is_request, phrase_pattern,
)


@dataclass
class CheckResult:
    type: str
    label: str
    passed: bool
    score: float
    weight: float = 1.0
    critical: bool = False
    skipped: bool = False
    explanation: str = ""

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass
class CheckContext:
    transcript: list[Turn]
    knowledge_text: str = ""
    judge: Any = None  # a Provider or None
    scenario: dict = field(default_factory=dict)

    def texts(self, scope: str = "agent") -> list[str]:
        if scope == "all":
            return [t.text for t in self.transcript]
        return [t.text for t in self.transcript if t.role == scope]


def _q(items) -> str:
    return ", ".join(f'"{x}"' for x in items)


# ---------------------------------------------------------------- spec + validation

COMMON_KEYS = {"type", "weight", "critical", "label"}
SCOPES = ("agent", "caller", "all")

CHECK_SPECS: dict[str, dict] = {
    "must_mention": {"required": {"phrases": list}, "optional": {"scope": str},
                     "help": "passes if the agent says ANY of the phrases"},
    "must_not_mention": {"required": {"phrases": list}, "optional": {"scope": str},
                         "help": "fails if the agent says ANY of the phrases"},
    "regex": {"required": {"pattern": str}, "optional": {"scope": str, "should_match": bool},
              "help": "regular expression that should (or should not) match"},
    "max_agent_turns": {"required": {"max": int}, "optional": {},
                        "help": "the agent must finish in at most this many turns"},
    "asks_for": {"required": {"fields": list}, "optional": {},
                 "help": f"agent asks the caller for these details ({', '.join(ASK_PATTERNS)})"},
    "no_hallucinated_price": {"required": {}, "optional": {"allowed": list},
                              "help": "no dollar amounts unless they appear in the business info"},
    "language": {"required": {}, "optional": {"expected": str, "min_ratio": (int, float)},
                 "help": "agent replies in the caller's language (or 'expected')"},
    "ends_politely": {"required": {}, "optional": {"phrases": list},
                      "help": "the agent's last line is a polite closing"},
    "llm_judge": {"required": {"rubric": str}, "optional": {"pass_score": (int, float)},
                  "help": "an AI judge scores the call 0-1 against a rubric (skipped without --judge-provider)"},
}


def _type_name(t) -> str:
    if isinstance(t, tuple):
        return "number"
    return {list: "list", str: "text", int: "whole number", bool: "true/false"}.get(t, t.__name__)


def _is_type(value, t) -> bool:
    if t is int:
        return isinstance(value, int) and not isinstance(value, bool)
    if t == (int, float):
        return isinstance(value, (int, float)) and not isinstance(value, bool)
    return isinstance(value, t)


def validate_check(check: Any, where: str = "check") -> list[str]:
    """Return a list of human-readable problems (empty list = valid)."""
    if not isinstance(check, dict):
        return [f"{where}: must be a mapping with a 'type'"]
    ctype = check.get("type")
    if ctype not in CHECK_SPECS:
        return [f"{where}: unknown check type {ctype!r} (choose from: {', '.join(CHECK_SPECS)})"]
    spec = CHECK_SPECS[ctype]
    errors = []
    allowed = COMMON_KEYS | set(spec["required"]) | set(spec["optional"])
    for key in check:
        if key not in allowed:
            errors.append(f"{where} ({ctype}): unknown field '{key}' (allowed: {', '.join(sorted(allowed))})")
    for key, t in spec["required"].items():
        if key not in check:
            errors.append(f"{where} ({ctype}): missing required field '{key}'")
        elif not _is_type(check[key], t):
            errors.append(f"{where} ({ctype}): '{key}' must be a {_type_name(t)}")
    for key, t in spec["optional"].items():
        if key in check and not _is_type(check[key], t):
            errors.append(f"{where} ({ctype}): '{key}' must be a {_type_name(t)}")
    if "weight" in check:
        w = check["weight"]
        if not _is_type(w, (int, float)) or w <= 0:
            errors.append(f"{where} ({ctype}): 'weight' must be a number above 0")
    if "critical" in check and not isinstance(check["critical"], bool):
        errors.append(f"{where} ({ctype}): 'critical' must be true or false")
    if "label" in check and not isinstance(check["label"], str):
        errors.append(f"{where} ({ctype}): 'label' must be text")
    if isinstance(check.get("scope"), str) and check["scope"] not in SCOPES:
        errors.append(f"{where} ({ctype}): 'scope' must be one of {', '.join(SCOPES)}")
    for key in ("phrases", "fields", "allowed"):
        if isinstance(check.get(key), list):
            if not check[key]:
                errors.append(f"{where} ({ctype}): '{key}' must not be empty")
            for item in check[key]:
                if key == "allowed":
                    if not isinstance(item, (int, float, str)) or isinstance(item, bool):
                        errors.append(f"{where} ({ctype}): 'allowed' items must be amounts")
                elif not isinstance(item, str) or not item.strip().rstrip("*").strip():
                    errors.append(f"{where} ({ctype}): every item in '{key}' must be non-empty text")
    if ctype == "regex" and isinstance(check.get("pattern"), str):
        try:
            re.compile(check["pattern"])
        except re.error as e:
            errors.append(f"{where} (regex): invalid pattern: {e}")
    if ctype == "max_agent_turns" and _is_type(check.get("max"), int) and check["max"] < 1:
        errors.append(f"{where} (max_agent_turns): 'max' must be at least 1")
    if ctype == "language" and isinstance(check.get("expected"), str) and check["expected"] not in ("en", "es"):
        errors.append(f"{where} (language): 'expected' must be 'en' or 'es'")
    for key in ("min_ratio", "pass_score"):
        if _is_type(check.get(key), (int, float)) and not 0 <= check[key] <= 1:
            errors.append(f"{where} ({ctype}): '{key}' must be between 0 and 1")
    return errors


# ---------------------------------------------------------------- default labels


def default_label(check: dict) -> str:
    t = check["type"]
    if t == "must_mention":
        return "Says " + " / ".join(f'"{p}"' for p in check["phrases"][:3])
    if t == "must_not_mention":
        return "Never says " + " / ".join(f'"{p}"' for p in check["phrases"][:3])
    if t == "regex":
        return ("Matches " if check.get("should_match", True) else "Does not match ") + f"/{check['pattern']}/"
    if t == "max_agent_turns":
        return f"Wraps up within {check['max']} turns"
    if t == "asks_for":
        return "Asks for the caller's " + ", ".join(check["fields"])
    if t == "no_hallucinated_price":
        return "Does not make up prices"
    if t == "language":
        exp = check.get("expected")
        return f"Replies in {LANGUAGE_NAMES.get(exp, exp)}" if exp else "Replies in the caller's language"
    if t == "ends_politely":
        return "Ends the call politely"
    if t == "llm_judge":
        return "AI reviewer: " + check["rubric"][:80]
    return t


# ---------------------------------------------------------------- check implementations
# Each returns (passed, score, explanation) or None to mean "skipped" with explanation via _Skip.


class _Skip(Exception):
    pass


def _scope(check: dict) -> str:
    return check.get("scope", "agent")


def _who(scope: str) -> str:
    return {"agent": "The agent", "caller": "The caller", "all": "Nobody on the call"}.get(scope, "The agent")


def check_must_mention(check, ctx):
    text = "\n".join(ctx.texts(_scope(check)))
    hit = find_phrase(text, check["phrases"])
    if hit:
        return True, 1.0, f'Said "{hit}".'
    return False, 0.0, f"{_who(_scope(check))} never said any of: {_q(check['phrases'])}."


def check_must_not_mention(check, ctx):
    text = "\n".join(ctx.texts(_scope(check)))
    hits = find_phrases(text, check["phrases"])
    if hits:
        return False, 0.0, f"{_who(_scope(check))} said {_q(hits)}, which it should not."
    return True, 1.0, "Avoided all the forbidden phrases."


def check_regex(check, ctx):
    text = "\n".join(ctx.texts(_scope(check)))
    should = check.get("should_match", True)
    found = re.search(check["pattern"], text, re.IGNORECASE | re.MULTILINE)
    if bool(found) == should:
        return True, 1.0, (f'Found "{found.group(0)}".' if found else "Correctly avoided the pattern.")
    if should:
        if check.get("label"):
            return False, 0.0, f'Did not do this: "{check["label"]}".'
        return False, 0.0, f"Never said anything matching /{check['pattern']}/."
    return False, 0.0, f'Said "{found.group(0)}", which it should not.'


def check_max_agent_turns(check, ctx):
    n = len(ctx.texts("agent"))
    if n <= check["max"]:
        return True, 1.0, f"Used {n} agent turn(s) (limit {check['max']})."
    return False, 0.0, f"Took {n} agent turns; it should finish in {check['max']} or fewer."


def check_asks_for(check, ctx):
    requests = [t for t in ctx.texts("agent") if is_request(t)]
    asked, missing = [], []
    for fld in check["fields"]:
        patterns = ASK_PATTERNS.get(fld.lower(), (fld,))
        if any(find_phrase(t, patterns) for t in requests):
            asked.append(fld)
        else:
            missing.append(fld)
    score = len(asked) / len(check["fields"])
    if not missing:
        return True, 1.0, f"Asked for the caller's {', '.join(asked)}."
    msg = f"Never asked for the caller's {', '.join(missing)}."
    if asked:
        msg = f"Asked for {', '.join(asked)}, but never asked for the caller's {', '.join(missing)}."
    return False, score, msg


def _parse_allowed(items) -> list[float]:
    out = []
    for it in items or []:
        if isinstance(it, (int, float)):
            out.append(float(it))
        else:
            amounts = extract_amounts(str(it)) or extract_amounts("$" + str(it).lstrip("$"))
            out.extend(amounts)
    return out


def check_no_hallucinated_price(check, ctx):
    allowed = extract_amounts(ctx.knowledge_text) + _parse_allowed(check.get("allowed"))
    quoted = extract_amounts("\n".join(ctx.texts("agent")))
    bad = [a for a in quoted if not any(abs(a - b) < 0.005 for b in allowed)]
    if not bad:
        if quoted:
            return True, 1.0, "Only quoted prices that are in the business info."
        return True, 1.0, "Did not make up any prices."
    seen = []
    for a in bad:
        f = format_amount(a)
        if f not in seen:
            seen.append(f)
    return False, 0.0, (f"Quoted {', '.join(seen)}, which is not in the business info. "
                        "Made-up prices lead to angry customers.")


def check_language(check, ctx):
    expected = check.get("expected")
    min_ratio = float(check.get("min_ratio", 0.6))
    pairs = []  # (wanted_language, agent_text)
    last_caller_lang = None
    caller_spoke = False
    for t in ctx.transcript:
        if t.role == "caller":
            caller_spoke = True
            lang = detect_language(t.text)
            if lang != "unknown":
                last_caller_lang = lang
        elif t.role == "agent" and caller_spoke:
            want = expected or last_caller_lang
            if want:
                pairs.append((want, t.text))
    if not pairs:
        return False, 0.0, "There were no agent replies to check the language of."
    good = sum(1 for want, txt in pairs if detect_language(txt) == want)
    ratio = good / len(pairs)
    want_name = LANGUAGE_NAMES.get(pairs[-1][0], pairs[-1][0])
    if ratio >= min_ratio:
        return True, ratio, f"Replied in {want_name} in {good} of {len(pairs)} replies."
    return False, ratio, (f"The caller spoke {want_name}, but only {good} of {len(pairs)} agent replies "
                          f"were in {want_name}.")


def check_ends_politely(check, ctx):
    agent_lines = ctx.texts("agent")
    if not agent_lines:
        return False, 0.0, "The agent never spoke."
    last = agent_lines[-1]
    hit = find_phrase(last, check.get("phrases") or POLITE_CLOSINGS)
    if hit:
        return True, 1.0, f'Closed politely ("{hit}").'
    return False, 0.0, "The agent's last line was not a polite goodbye or thank-you."


JUDGE_SYSTEM = (
    "You are a strict quality reviewer for AI phone receptionists used by small businesses. "
    "You read a call transcript and score it against a rubric. Reply with JSON only."
)
JUDGE_TEMPLATE = """Rubric (what a good receptionist does on this call):
{rubric}

Caller persona: {persona}
Caller goal: {goal}

Transcript:
{transcript}

Score how well the AGENT met the rubric from 0 (failed) to 1 (perfect).
Reply with only this JSON: {{"score": <number 0-1>, "reasoning": "<one or two plain-English sentences>"}}"""


def parse_judge_reply(text: str) -> tuple[float, str]:
    m = re.search(r"\{.*\}", text or "", re.DOTALL)
    if not m:
        raise ValueError("no JSON object in judge reply")
    data = json.loads(m.group(0))
    score = float(data["score"])
    return max(0.0, min(1.0, score)), str(data.get("reasoning", "")).strip()


def check_llm_judge(check, ctx):
    if ctx.judge is None:
        raise _Skip("Skipped: no AI judge was set up for this run (use --judge-provider).")
    transcript = "\n".join(f"{t.role.upper()}: {t.text}" for t in ctx.transcript)
    prompt = JUDGE_TEMPLATE.format(rubric=check["rubric"], persona=ctx.scenario.get("persona", ""),
                                   goal=ctx.scenario.get("goal", ""), transcript=transcript)
    try:
        reply = ctx.judge.complete(JUDGE_SYSTEM, [{"role": "user", "content": prompt}])
    except Exception as e:
        raise _Skip(f"Skipped: the AI judge failed ({e}).") from e
    try:
        score, reasoning = parse_judge_reply(reply)
    except (ValueError, KeyError, TypeError, json.JSONDecodeError):
        raise _Skip(f"Skipped: could not read the AI judge's answer: {reply[:120]!r}") from None
    pass_score = float(check.get("pass_score", 0.7))
    return score >= pass_score, score, f"AI reviewer gave {score:.0%}: {reasoning}"


CHECK_FUNCS: dict[str, Callable] = {
    "must_mention": check_must_mention,
    "must_not_mention": check_must_not_mention,
    "regex": check_regex,
    "max_agent_turns": check_max_agent_turns,
    "asks_for": check_asks_for,
    "no_hallucinated_price": check_no_hallucinated_price,
    "language": check_language,
    "ends_politely": check_ends_politely,
    "llm_judge": check_llm_judge,
}


def run_check(check: dict, ctx: CheckContext) -> CheckResult:
    label = check.get("label") or default_label(check)
    weight = float(check.get("weight", 1))
    critical = bool(check.get("critical", False))
    try:
        passed, score, explanation = CHECK_FUNCS[check["type"]](check, ctx)
    except _Skip as s:
        return CheckResult(check["type"], label, True, 0.0, weight, critical, True, str(s))
    return CheckResult(check["type"], label, bool(passed), float(score), weight, critical, False, explanation)


def score_checks(results: list[CheckResult], threshold: float) -> tuple[float, bool]:
    """Weighted score (skipped checks don't count) and pass/fail.

    A scenario passes when its score reaches the threshold AND no critical check failed.
    """
    counted = [r for r in results if not r.skipped]
    total = sum(r.weight for r in counted)
    score = 1.0 if total == 0 else sum(r.score * r.weight for r in counted) / total
    critical_failed = any(r.critical and not r.passed for r in counted)
    return score, (score >= threshold - 1e-9) and not critical_failed


__all__ = [
    "CheckResult", "CheckContext", "CHECK_SPECS", "validate_check", "run_check", "score_checks",
    "default_label", "parse_judge_reply", "phrase_pattern",
]
