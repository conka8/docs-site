"""Command line: voice-qa run | packs | validate-pack | report.

Exit codes: 0 = OK, 1 = problems found (score below --fail-under, a test conversation could not finish,
or validate-pack found mistakes), 2 = bad input / setup problem.
"""

from __future__ import annotations

import argparse
import os
import sys
from pathlib import Path
from typing import Mapping

from . import __version__
from . import constants as C
from .adapters import (
    DEMO_AGENTS, AdapterError, HttpAgent, PromptAgent, ScriptedAgent, demo_script, load_platform_config,
    load_script,
)
from .packs import PackError, list_packs, resolve_pack, validate_pack_file
from .providers import PROVIDER_NAMES, ProviderError, create_provider, default_provider_name
from .report import (
    ReportError, compare_results, console_summary, load_results, to_html, to_json, to_junit, write_outputs,
)
from .runner import CALLER_MODES, RunError, run_pack
from .textutil import not_utf8_message

AGENT_KINDS = ("prompt", "http", "vapi-config", "retell-config", "scripted")

EXIT_OK = 0
EXIT_BELOW_THRESHOLD = 1
EXIT_USAGE = 2
NEUTRAL_BUSINESS_NAME = "your business"


class CliError(Exception):
    pass


def _add_branding(p: argparse.ArgumentParser) -> None:
    g = p.add_argument_group("white-label branding")
    g.add_argument("--brand-name", help="your agency name shown on the scorecard")
    g.add_argument("--brand-color", help="header colour, e.g. '#0ea5e9' or 'teal'")
    g.add_argument("--logo-url", help="https:// link to your logo")
    g.add_argument("--agency-contact", help="contact line in the footer, e.g. 'hello@agency.com'")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="voice-qa",
        description="Test an AI phone receptionist with simulated callers and get a client-ready scorecard.",
    )
    parser.add_argument("--version", action="version", version=f"voice-qa {__version__}")
    sub = parser.add_subparsers(dest="command", metavar="COMMAND")

    run = sub.add_parser("run", help="run a scenario pack against an agent")
    run.add_argument("--agent", required=True, choices=AGENT_KINDS, help="how to reach the agent under test")
    run.add_argument("--pack", required=True, help="bundled pack name (see 'voice-qa packs') or a YAML file")
    run.add_argument("--scenario", action="append", help="only run this scenario id (repeatable)")
    run.add_argument("-o", "--out", default="voice-qa-results", help="output folder (default: voice-qa-results)")
    run.add_argument("--business-name", help="the client's business name (default: 'your business'; "
                                             "demo agents use the pack's example name)")
    run.add_argument("--knowledge-file", help="text file with the business's real facts/prices "
                                              "(amounts in it are allowed in replies)")
    run.add_argument("--threshold", type=float, help="pass mark per call, percent (default 80)")
    run.add_argument("--fail-under", type=float, help="exit with code 1 if the overall score (percent) is below this")
    run.add_argument("--max-turns", type=int, help="max caller turns per call (default: per scenario or 10)")
    run.add_argument("--compare", help="previous results.json to compare against")
    a = run.add_argument_group("agent options")
    a.add_argument("--prompt-file", help="[prompt] the agent's system prompt (text file)")
    a.add_argument("--first-message", help="[prompt/config] what the agent says when it picks up")
    a.add_argument("--end-call-phrase", action="append", default=[],
                   help="[prompt/config] phrase that means the agent hung up (repeatable)")
    a.add_argument("--config-file", help="[vapi-config/retell-config] exported assistant/agent JSON")
    a.add_argument("--provider", choices=PROVIDER_NAMES, help="LLM that plays the agent (default: from API keys)")
    a.add_argument("--model", help="model name for --provider")
    a.add_argument("--base-url", help="custom OpenAI-compatible /chat/completions URL")
    a.add_argument("--api-key-env", help="read the API key from this environment variable instead")
    a.add_argument("--url", help="[http] your agent webhook URL")
    a.add_argument("--reply-path", default=C.HTTP_AGENT_DEFAULT_REPLY_PATH,
                   help="[http] where the reply text is in the JSON answer, e.g. 'reply' or 'choices[0].message.content'")
    a.add_argument("--end-call-path", help="[http] JSON path of a true/false 'call ended' flag")
    a.add_argument("--header", action="append", default=[], help="[http] extra header 'Name: value' (repeatable)")
    a.add_argument("--script-file", help="[scripted] YAML/JSON rules for a fake agent")
    a.add_argument("--demo", choices=DEMO_AGENTS, default="good", help="[scripted] built-in demo agent (default good)")
    c = run.add_argument_group("caller and judge")
    c.add_argument("--caller", choices=CALLER_MODES, default="auto",
                   help="script = use each scenario's caller lines; llm = AI caller; auto = script when available")
    c.add_argument("--caller-provider", choices=PROVIDER_NAMES, help="LLM that plays the caller")
    c.add_argument("--caller-model", help="model for the caller")
    c.add_argument("--judge-provider", choices=PROVIDER_NAMES, help="LLM for llm_judge checks (skipped if unset)")
    c.add_argument("--judge-model", help="model for the judge")
    _add_branding(run)

    sub.add_parser("packs", help="list the bundled scenario packs")

    val = sub.add_parser("validate-pack", help="check a pack YAML file for mistakes")
    val.add_argument("files", nargs="+", help="pack file(s) to check")

    rep = sub.add_parser("report", help="re-create the scorecard from a results.json")
    rep.add_argument("results", help="results.json from a previous run")
    rep.add_argument("-o", "--out", required=True, help="output file")
    rep.add_argument("--format", choices=("html", "junit", "json"), help="default: from the file extension, else html")
    rep.add_argument("--compare", help="previous results.json to compare against")
    _add_branding(rep)
    return parser


# ---------------------------------------------------------------- helpers


def _branding(args) -> dict:
    return {k: getattr(args, k) for k in ("brand_name", "brand_color", "logo_url", "agency_contact")
            if getattr(args, k, None)}


def _parse_headers(items: list[str]) -> dict:
    headers = {}
    for item in items:
        if ":" not in item:
            raise CliError(f"--header must look like 'Name: value' (got {item!r})")
        k, v = item.split(":", 1)
        headers[k.strip()] = v.strip()
    return headers


def _read_text(path: str, what: str) -> str:
    p = Path(path)
    if not p.is_file():
        raise CliError(f"{what} not found: {p}")
    try:
        return p.read_text(encoding="utf-8")
    except UnicodeDecodeError as e:
        raise CliError(not_utf8_message(p)) from e


def build_agent(args, business_name: str, env: Mapping[str, str], transport=None, sleep=None):
    """Create the agent under test from CLI options. Returns (agent, notes)."""
    notes: list[str] = []
    kind = args.agent
    if kind == "scripted":
        script = load_script(args.script_file) if args.script_file else demo_script(args.demo)
        return ScriptedAgent(script, business_name), notes
    if kind == "http":
        if not args.url:
            raise CliError("--agent http needs --url")
        return HttpAgent(args.url, args.reply_path, headers=_parse_headers(args.header),
                         end_call_path=args.end_call_path, first_message=args.first_message,
                         transport=transport, sleep=sleep), notes
    if kind == "prompt":
        if not args.prompt_file:
            raise CliError("--agent prompt needs --prompt-file")
        prompt = _read_text(args.prompt_file, "Prompt file")
        provider = create_provider(args.provider, args.model, env=env, transport=transport, sleep=sleep,
                                   base_url=args.base_url, api_key_env=args.api_key_env, role="agent")
        return PromptAgent(prompt, provider, args.first_message, args.end_call_phrase,
                           name=Path(args.prompt_file).name), notes
    # vapi-config / retell-config
    if not args.config_file:
        raise CliError(f"--agent {kind} needs --config-file")
    cfg = load_platform_config(args.config_file, kind.split("-")[0])
    notes.extend(cfg.notes)
    provider_name = args.provider or cfg.provider or default_provider_name(env)
    model = args.model
    if not model and cfg.model and provider_name == cfg.provider:
        model = cfg.model
        notes.append(f"Using model '{cfg.model}' from the config (override with --model).")
    provider = create_provider(provider_name, model, env=env, transport=transport, sleep=sleep,
                               base_url=args.base_url, api_key_env=args.api_key_env, role="agent")
    agent = PromptAgent(cfg.system_prompt, provider, args.first_message or cfg.first_message,
                        list(cfg.end_call_phrases) + list(args.end_call_phrase), name=f"{cfg.platform}: {cfg.name}")
    return agent, notes


def _percent_arg(value: float | None, name: str) -> float | None:
    if value is None:
        return None
    if not 0 <= value <= 100:
        raise CliError(f"{name} must be between 0 and 100")
    return value / 100.0


# ---------------------------------------------------------------- commands


def cmd_packs(args, out) -> int:
    packs = list_packs()
    print("Bundled scenario packs (use the name with --pack):\n", file=out)
    for p in packs:
        print(f"  {p.name:<14} {len(p.scenarios):>2} calls  {p.title}", file=out)
        print(f"  {'':<14}           e.g. {', '.join(s.id for s in p.scenarios[:4])}, ...", file=out)
    print("\nRun one:  voice-qa run --agent scripted --pack dental -o out/", file=out)
    return EXIT_OK


def cmd_validate(args, out, err) -> int:
    bad = 0
    for f in args.files:
        problems = validate_pack_file(f)
        if problems:
            bad += 1
            print(f"{f}: {len(problems)} problem(s)", file=err)
            for p in problems:
                print(f"  - {p}", file=err)
        else:
            print(f"{f}: OK", file=out)
    return 1 if bad else EXIT_OK


def cmd_run(args, out, err, env, transport, sleep) -> int:
    pack = resolve_pack(args.pack)
    demo_agent = args.agent == "scripted" or args.provider == "fake"
    business = args.business_name or (pack.default_business_name if demo_agent else NEUTRAL_BUSINESS_NAME)
    threshold = _percent_arg(args.threshold, "--threshold")
    fail_under = _percent_arg(args.fail_under, "--fail-under")
    if args.max_turns is not None and args.max_turns < 1:
        raise CliError("--max-turns must be at least 1")
    knowledge = _read_text(args.knowledge_file, "Knowledge file") if args.knowledge_file else ""
    previous = load_results(args.compare) if args.compare else None
    agent, notes = build_agent(args, business, env, transport, sleep)
    caller_provider = None
    if args.caller_provider:
        caller_provider = create_provider(args.caller_provider, args.caller_model, env=env, transport=transport,
                                          sleep=sleep, role="caller")
    judge = None
    if args.judge_provider:
        judge = create_provider(args.judge_provider, args.judge_model, env=env, transport=transport, sleep=sleep,
                                role="judge")
    if not args.business_name and not demo_agent:
        notes.append(f"No --business-name given, so the report says '{NEUTRAL_BUSINESS_NAME}'.")
    for n in notes:
        print(f"Note: {n}", file=err)
    results = run_pack(pack, agent, business_name=business, caller_mode=args.caller,
                       caller_provider=caller_provider, judge_provider=judge, knowledge_text=knowledge,
                       threshold=threshold, max_turns=args.max_turns, scenario_ids=args.scenario,
                       branding=_branding(args))
    comparison = compare_results(results, previous) if previous else None
    paths = write_outputs(results, args.out, comparison)
    print(console_summary(results, comparison), file=out)
    print(f"\nScorecard for the client: {paths['html']}", file=out)
    print(f"Full results (keep for --compare next time): {paths['json']}", file=out)
    print(f"JUnit XML for CI: {paths['junit']}", file=out)
    code = EXIT_OK
    errors = results["summary"].get("errors", 0)
    if errors:
        print(f"FAILED: {errors} test conversation(s) could not finish (see ERROR above). "
              "Check that the agent is reachable and its keys are right, then run again.", file=err)
        code = EXIT_BELOW_THRESHOLD
    if fail_under is not None and results["summary"]["score"] < fail_under - 1e-9:
        print(f"FAILED: overall score {results['summary']['score'] * 100:.0f}% is below "
              f"--fail-under {fail_under * 100:.0f}%.", file=err)
        code = EXIT_BELOW_THRESHOLD
    return code


def cmd_report(args, out) -> int:
    results = load_results(args.results)
    comparison = compare_results(results, load_results(args.compare)) if args.compare else None
    fmt = args.format
    if not fmt:
        ext = Path(args.out).suffix.lower()
        fmt = {".xml": "junit", ".json": "json"}.get(ext, "html")
    if fmt == "html":
        text = to_html(results, comparison, _branding(args))
    elif fmt == "junit":
        text = to_junit(results)
    else:
        if comparison:
            results = dict(results, comparison=comparison)
        text = to_json(results)
    Path(args.out).parent.mkdir(parents=True, exist_ok=True)
    Path(args.out).write_text(text, encoding="utf-8")
    print(f"Wrote {fmt} report: {args.out}", file=out)
    return EXIT_OK


def main(argv: list[str] | None = None, *, env: Mapping[str, str] | None = None, transport=None,
         sleep=None, stdout=None, stderr=None) -> int:
    out = stdout or sys.stdout
    err = stderr or sys.stderr
    env = os.environ if env is None else env
    parser = build_parser()
    try:
        args = parser.parse_args(argv)
    except SystemExit as e:  # argparse errors (2) and --help/--version (0)
        return int(e.code or 0)
    if not args.command:
        parser.print_help(out)
        return EXIT_USAGE
    try:
        if args.command == "packs":
            return cmd_packs(args, out)
        if args.command == "validate-pack":
            return cmd_validate(args, out, err)
        if args.command == "report":
            return cmd_report(args, out)
        return cmd_run(args, out, err, env, transport, sleep)
    except PackError as e:
        print(f"Error: {e}", file=err)
        for p in e.errors:
            print(f"  - {p}", file=err)
        return EXIT_USAGE
    except (CliError, AdapterError, ProviderError, ReportError, RunError) as e:
        print(f"Error: {e}", file=err)
        return EXIT_USAGE
    except OSError as e:
        print(f"Error: {e}", file=err)
        return EXIT_USAGE


if __name__ == "__main__":  # pragma: no cover
    sys.exit(main())


__all__ = ["main", "build_parser", "build_agent"]
