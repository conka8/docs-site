"""Every third-party endpoint, header and field name lives here.

These were written from public docs and may drift. If a provider or platform
changes its format, this is the only file you should need to edit.
VERIFY AGAINST CURRENT DOCS before relying on them.
"""

# ---------------------------------------------------------------- LLM APIs
ENV_OPENAI_KEY = "OPENAI_API_KEY"
ENV_ANTHROPIC_KEY = "ANTHROPIC_API_KEY"

# OpenAI-compatible chat completions (works for OpenAI and most compatible hosts)
OPENAI_CHAT_URL = "https://api.openai.com/v1/chat/completions"
DEFAULT_OPENAI_MODEL = "gpt-4o-mini"
# reply text lives at choices[0].message.content
OPENAI_CHOICES_FIELD = "choices"
OPENAI_MESSAGE_FIELD = "message"
OPENAI_CONTENT_FIELD = "content"

# Anthropic Messages API
ANTHROPIC_MESSAGES_URL = "https://api.anthropic.com/v1/messages"
ANTHROPIC_VERSION = "2023-06-01"
ANTHROPIC_VERSION_HEADER = "anthropic-version"
ANTHROPIC_KEY_HEADER = "x-api-key"
DEFAULT_ANTHROPIC_MODEL = "claude-sonnet-5-5"
# reply text lives in content[] blocks with type == "text"
ANTHROPIC_CONTENT_FIELD = "content"
ANTHROPIC_TEXT_BLOCK_TYPE = "text"
# Anthropic requires the conversation to start with a user turn.
ANTHROPIC_CALL_CONNECTED_PLACEHOLDER = "(The phone call has connected.)"

# ---------------------------------------------------------------- HTTP
HTTP_TIMEOUT_SECONDS = 60
HTTP_MAX_RETRIES = 2
HTTP_RETRY_STATUSES = frozenset({429, 500, 502, 503, 504})
HTTP_BACKOFF_SECONDS = 2.0
HTTP_MAX_RETRY_AFTER_SECONDS = 30.0

# ---------------------------------------------------------------- generic webhook adapter
HTTP_AGENT_DEFAULT_REPLY_PATH = "reply"
HTTP_AGENT_ROLE_CALLER = "user"
HTTP_AGENT_ROLE_AGENT = "assistant"

# ---------------------------------------------------------------- Vapi assistant export
# Shape assumed: {"name", "firstMessage", "endCallPhrases": [...],
#                 "model": {"provider", "model", "messages": [{"role": "system", "content"}]}}
VAPI_NAME_KEY = "name"
VAPI_FIRST_MESSAGE_KEY = "firstMessage"
VAPI_END_CALL_PHRASES_KEY = "endCallPhrases"
VAPI_MODEL_KEY = "model"
VAPI_MODEL_PROVIDER_KEY = "provider"
VAPI_MODEL_NAME_KEY = "model"
VAPI_MODEL_MESSAGES_KEY = "messages"
VAPI_SYSTEM_PROMPT_LEGACY_KEYS = ("systemPrompt",)  # older exports kept the prompt here

# ---------------------------------------------------------------- Retell agent / Retell LLM export
# Retell splits an "agent" (voice settings) from a "Retell LLM" (prompt). Exports seen in the wild
# either are the LLM object itself, or wrap it under one of these keys.
RETELL_LLM_CONTAINER_KEYS = ("retellLlmData", "retell_llm", "llm", "response_engine")
RETELL_NAME_KEYS = ("agent_name", "name")
RETELL_PROMPT_KEY = "general_prompt"
RETELL_BEGIN_MESSAGE_KEY = "begin_message"
RETELL_MODEL_KEY = "model"
RETELL_STATES_KEY = "states"
RETELL_STATE_NAME_KEY = "name"
RETELL_STATE_PROMPT_KEY = "state_prompt"

# Platform model-provider names we can map onto our own providers.
PLATFORM_PROVIDER_MAP = {
    "openai": "openai",
    "azure-openai": "openai",
    "anthropic": "anthropic",
}

# ---------------------------------------------------------------- simulation defaults
DEFAULT_MAX_TURNS = 10
DEFAULT_PASS_THRESHOLD = 0.8
# A caller line containing one of these ends the call (after the agent's last reply).
DEFAULT_TERMINAL_PHRASES = ("[end]", "[hangup]", "goodbye", "bye", "adiós", "adios")
CALLER_END_MARKERS = ("[end]", "[hangup]")

GRADE_BANDS = ((0.9, "A"), (0.8, "B"), (0.7, "C"), (0.6, "D"), (0.0, "F"))
