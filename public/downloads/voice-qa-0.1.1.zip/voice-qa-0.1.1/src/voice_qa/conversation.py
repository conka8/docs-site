"""Simulated phone calls: a caller (scripted or LLM) talks to the agent under test."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Iterable, Protocol

from . import constants as C
from .textutil import find_phrase, normalize


@dataclass
class Turn:
    role: str  # "agent" or "caller"
    text: str

    def to_dict(self) -> dict:
        return {"role": self.role, "text": self.text}

    @classmethod
    def from_dict(cls, d: dict) -> "Turn":
        return cls(d["role"], d.get("text", ""))


def to_messages(transcript: Iterable[Turn], me: str) -> list[dict]:
    """Turn a transcript into chat messages from the point of view of ``me`` ("agent" or "caller")."""
    return [
        {"role": "assistant" if t.role == me else "user", "content": t.text}
        for t in transcript
        if t.text
    ]


@dataclass
class AgentReply:
    text: str
    end_call: bool = False


class Agent(Protocol):
    first_message: str | None

    def reply(self, transcript: list[Turn]) -> AgentReply: ...


class ScriptedCaller:
    """Says the scenario's caller_script lines in order, then hangs up."""

    kind = "script"

    def __init__(self, lines: Iterable[str]):
        self.lines = [str(x) for x in lines]

    def next_message(self, transcript: list[Turn]) -> str | None:
        said = sum(1 for t in transcript if t.role == "caller")
        return self.lines[said] if said < len(self.lines) else None


CALLER_SYSTEM_PROMPT = """You are role-playing a person phoning {business}. You are testing their phone receptionist, but never say that.
Who you are: {persona}
What you want from this call: {goal}

Rules:
- Talk like a real person on the phone: one or two short sentences per turn, no lists, no stage directions.
- Stay in character. If the receptionist asks for details (name, phone number, dates), make up realistic ones.
- When your goal is reached, or a real caller would hang up, say goodbye and put [END] at the end of your message.
{extra}"""


class LLMCaller:
    """An AI caller driven by the scenario's persona and goal."""

    kind = "llm"

    def __init__(self, provider, persona: str, goal: str, business: str = "the business",
                 hints: Iterable[str] = ()):
        self.provider = provider
        hints = [h for h in hints if h]
        extra = ""
        if hints:
            extra = "- Lines you might use (adapt freely): " + " | ".join(hints)
        self.system = CALLER_SYSTEM_PROMPT.format(business=business, persona=persona, goal=goal, extra=extra)

    def next_message(self, transcript: list[Turn]) -> str | None:
        text = self.provider.complete(self.system, to_messages(transcript, me="caller"))
        return text.strip() or None


def strip_end_markers(text: str) -> tuple[str, bool]:
    """Remove [END]/[HANGUP] markers. Returns (clean_text, had_marker)."""
    low = normalize(text)
    had = False
    for marker in C.CALLER_END_MARKERS:
        while marker in low:
            had = True
            i = low.index(marker)
            text = text[:i] + text[i + len(marker):]
            low = low[:i] + low[i + len(marker):]
    return text.strip(), had


@dataclass
class Conversation:
    transcript: list[Turn] = field(default_factory=list)
    ended_by: str = "max_turns"
    error: str | None = None


ENDED_BY_TEXT = {
    "caller_hung_up": "the caller said goodbye",
    "agent_ended": "the agent ended the call",
    "caller_done": "the caller had nothing more to say",
    "max_turns": "the turn limit was reached",
    "error": "an error stopped the call",
}


def simulate_call(agent, caller, *, max_turns: int = C.DEFAULT_MAX_TURNS,
                  terminal_phrases: Iterable[str] = C.DEFAULT_TERMINAL_PHRASES) -> Conversation:
    """Run one call. The agent gets one last reply after the caller says a terminal phrase."""
    conv = Conversation()
    terminal_phrases = list(terminal_phrases)
    try:
        first = getattr(agent, "first_message", None)
        if first:
            conv.transcript.append(Turn("agent", first))
        for _ in range(max_turns):
            raw = caller.next_message(conv.transcript)
            if raw is None:
                conv.ended_by = "caller_done"
                return conv
            text, marker = strip_end_markers(raw)
            terminal = marker or find_phrase(text, terminal_phrases) is not None
            if not text:
                conv.ended_by = "caller_hung_up" if marker else "caller_done"
                return conv
            conv.transcript.append(Turn("caller", text))
            reply = agent.reply(conv.transcript)
            if reply.text:
                conv.transcript.append(Turn("agent", reply.text))
            if reply.end_call:
                conv.ended_by = "agent_ended"
                return conv
            if terminal:
                conv.ended_by = "caller_hung_up"
                return conv
        conv.ended_by = "max_turns"
    except Exception as e:  # one broken call must not stop the whole test run
        conv.ended_by = "error"
        conv.error = f"{type(e).__name__}: {e}"
    return conv
