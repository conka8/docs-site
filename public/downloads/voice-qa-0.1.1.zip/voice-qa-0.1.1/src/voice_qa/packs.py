"""Scenario packs: YAML files with test calls for one industry."""

from __future__ import annotations

import copy
import json
import re
from dataclasses import dataclass, field
from importlib import resources
from pathlib import Path
from typing import Any

from .checks import validate_check
from .textutil import not_utf8_message


class PackError(Exception):
    """A pack could not be found, read or validated."""

    def __init__(self, message: str, errors: list[str] | None = None):
        super().__init__(message)
        self.errors = errors or []


@dataclass
class Scenario:
    id: str
    title: str
    persona: str
    goal: str
    checks: list[dict]
    caller_script: list[str] | None = None
    max_turns: int | None = None
    pass_threshold: float | None = None
    terminal_phrases: list[str] | None = None
    fix_hint: str = ""
    tags: list[str] = field(default_factory=list)

    def filled(self, business_name: str) -> "Scenario":
        """Copy with {business_name} filled in everywhere."""
        return _fill(copy.deepcopy(self), business_name)

    def to_dict(self) -> dict:
        return {k: v for k, v in self.__dict__.items()}


@dataclass
class Pack:
    name: str
    title: str
    industry: str
    description: str
    scenarios: list[Scenario]
    default_business_name: str = "our office"
    pass_threshold: float | None = None
    source: str = ""


def _fill(obj: Any, name: str) -> Any:
    if isinstance(obj, str):
        return obj.replace("{business_name}", name)
    if isinstance(obj, list):
        return [_fill(x, name) for x in obj]
    if isinstance(obj, dict):
        return {k: _fill(v, name) for k, v in obj.items()}
    if isinstance(obj, Scenario):
        for k, v in list(obj.__dict__.items()):
            if k != "id":
                setattr(obj, k, _fill(v, name))
        return obj
    return obj


def to_fraction(value: float) -> float:
    """Accept 0.8 or 80 and return 0.8."""
    value = float(value)
    return value / 100.0 if value > 1 else value


PACK_KEYS = {"name", "title", "industry", "description", "default_business_name", "pass_threshold",
             "version", "scenarios"}
SCENARIO_KEYS = {"id", "title", "persona", "goal", "caller_script", "checks", "max_turns", "pass_threshold",
                 "terminal_phrases", "fix_hint", "tags"}
_ID_RE = re.compile(r"^[a-z0-9][a-z0-9_-]*$")


def _is_num(v) -> bool:
    return isinstance(v, (int, float)) and not isinstance(v, bool)


def validate_pack_data(data: Any) -> list[str]:
    """Return all problems found in a pack (empty list = valid)."""
    if not isinstance(data, dict):
        return ["The pack must be a mapping with 'name', 'title' and 'scenarios'."]
    errors = []
    for key in data:
        if key not in PACK_KEYS:
            errors.append(f"pack: unknown field '{key}' (allowed: {', '.join(sorted(PACK_KEYS))})")
    for key in ("name", "title"):
        if not isinstance(data.get(key), str) or not data[key].strip():
            errors.append(f"pack: '{key}' is required and must be text")
    for key in ("industry", "description", "default_business_name"):
        if key in data and not isinstance(data[key], str):
            errors.append(f"pack: '{key}' must be text")
    if "pass_threshold" in data and (not _is_num(data["pass_threshold"]) or not 0 < data["pass_threshold"] <= 100):
        errors.append("pack: 'pass_threshold' must be a number like 0.8 or 80")
    scenarios = data.get("scenarios")
    if not isinstance(scenarios, list) or not scenarios:
        errors.append("pack: 'scenarios' must be a non-empty list")
        return errors
    seen = set()
    for i, sc in enumerate(scenarios, 1):
        where = f"scenario #{i}"
        if not isinstance(sc, dict):
            errors.append(f"{where}: must be a mapping")
            continue
        sid = sc.get("id")
        if isinstance(sid, str) and sid:
            where = f"scenario '{sid}'"
            if not _ID_RE.match(sid):
                errors.append(f"{where}: 'id' may only use lowercase letters, digits, '-' and '_'")
            if sid in seen:
                errors.append(f"{where}: duplicate id")
            seen.add(sid)
        else:
            errors.append(f"{where}: 'id' is required and must be text")
        for key in sc:
            if key not in SCENARIO_KEYS:
                errors.append(f"{where}: unknown field '{key}' (allowed: {', '.join(sorted(SCENARIO_KEYS))})")
        for key in ("title", "persona", "goal"):
            if not isinstance(sc.get(key), str) or not sc[key].strip():
                errors.append(f"{where}: '{key}' is required and must be text")
        if "fix_hint" in sc and not isinstance(sc["fix_hint"], str):
            errors.append(f"{where}: 'fix_hint' must be text")
        script = sc.get("caller_script")
        if script is not None:
            if not isinstance(script, list) or not script:
                errors.append(f"{where}: 'caller_script' must be a non-empty list of lines")
            elif any(not isinstance(x, str) or not x.strip() for x in script):
                errors.append(f"{where}: every 'caller_script' line must be non-empty text")
        if "max_turns" in sc and (not isinstance(sc["max_turns"], int) or isinstance(sc["max_turns"], bool)
                                  or sc["max_turns"] < 1):
            errors.append(f"{where}: 'max_turns' must be a whole number of at least 1")
        if "pass_threshold" in sc and (not _is_num(sc["pass_threshold"]) or not 0 < sc["pass_threshold"] <= 100):
            errors.append(f"{where}: 'pass_threshold' must be a number like 0.8 or 80")
        for key in ("terminal_phrases", "tags"):
            if key in sc and (not isinstance(sc[key], list) or any(not isinstance(x, str) for x in sc[key])):
                errors.append(f"{where}: '{key}' must be a list of text")
        checks = sc.get("checks")
        if not isinstance(checks, list) or not checks:
            errors.append(f"{where}: 'checks' must be a non-empty list")
        else:
            for j, ch in enumerate(checks, 1):
                errors.extend(validate_check(ch, f"{where} check #{j}"))
    return errors


def parse_text(text: str, source: str = "pack") -> Any:
    if source.lower().endswith(".json"):
        try:
            return json.loads(text)
        except json.JSONDecodeError as e:
            raise PackError(f"{source}: not valid JSON: {e}", [f"not valid JSON: {e}"]) from e
    import yaml

    try:
        return yaml.safe_load(text)
    except yaml.YAMLError as e:
        raise PackError(f"{source}: not valid YAML: {e}", [f"YAML syntax error: {e}"]) from e


def pack_from_data(data: Any, source: str = "") -> Pack:
    errors = validate_pack_data(data)
    if errors:
        raise PackError(f"{source or 'pack'} has {len(errors)} problem(s)", errors)
    scenarios = []
    for sc in data["scenarios"]:
        scenarios.append(Scenario(
            id=sc["id"], title=sc["title"].strip(), persona=sc["persona"].strip(), goal=sc["goal"].strip(),
            checks=sc["checks"], caller_script=sc.get("caller_script"), max_turns=sc.get("max_turns"),
            pass_threshold=to_fraction(sc["pass_threshold"]) if "pass_threshold" in sc else None,
            terminal_phrases=sc.get("terminal_phrases"), fix_hint=(sc.get("fix_hint") or "").strip(),
            tags=sc.get("tags") or [],
        ))
    return Pack(
        name=data["name"], title=data["title"], industry=data.get("industry", ""),
        description=(data.get("description") or "").strip(), scenarios=scenarios,
        default_business_name=data.get("default_business_name") or "our office",
        pass_threshold=to_fraction(data["pass_threshold"]) if "pass_threshold" in data else None,
        source=source,
    )


def _read_pack_text(p: Path) -> str:
    try:
        return p.read_text(encoding="utf-8")
    except UnicodeDecodeError as e:
        raise PackError(not_utf8_message(p)) from e


def load_pack_file(path: str | Path) -> Pack:
    p = Path(path)
    if not p.is_file():
        raise PackError(f"Pack file not found: {p}")
    return pack_from_data(parse_text(_read_pack_text(p), str(p)), str(p))


def validate_pack_file(path: str | Path) -> list[str]:
    p = Path(path)
    if not p.is_file():
        return [f"File not found: {p}"]
    try:
        data = parse_text(_read_pack_text(p), str(p))
    except PackError as e:
        return e.errors or [str(e)]
    return validate_pack_data(data)


def bundled_pack_files() -> dict[str, Any]:
    """name -> resource path of every pack shipped with voice-qa."""
    folder = resources.files("voice_qa").joinpath("packs")
    out = {}
    for entry in sorted(folder.iterdir(), key=lambda e: e.name):
        if entry.name.endswith((".yaml", ".yml")):
            out[entry.name.rsplit(".", 1)[0]] = entry
    return out


def load_bundled_pack(name: str) -> Pack:
    files = bundled_pack_files()
    if name not in files:
        raise PackError(f"No bundled pack called '{name}'. Available: {', '.join(files)}")
    entry = files[name]
    return pack_from_data(parse_text(entry.read_text(encoding="utf-8"), entry.name), f"bundled:{name}")


def resolve_pack(name_or_path: str) -> Pack:
    """Load a bundled pack by name (e.g. 'dental') or a pack file by path."""
    p = Path(name_or_path)
    if p.suffix.lower() in (".yaml", ".yml", ".json") or p.is_file():
        return load_pack_file(p)
    return load_bundled_pack(name_or_path)


def list_packs() -> list[Pack]:
    return [load_bundled_pack(n) for n in bundled_pack_files()]

