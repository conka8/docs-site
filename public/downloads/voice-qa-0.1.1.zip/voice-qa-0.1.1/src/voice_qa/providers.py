"""LLM providers: OpenAI-compatible chat completions, Anthropic Messages, and a fake for tests/demos.

Every provider has ``complete(system, messages) -> str`` where messages are
``[{"role": "user"|"assistant", "content": str}, ...]``.
"""

from __future__ import annotations

import os
from typing import Callable, Iterable, Mapping

from . import constants as C
from .transport import HttpError, Transport, post_json


class ProviderError(Exception):
    """An LLM call failed or returned something we could not read."""


def merge_roles(messages: Iterable[dict]) -> list[dict]:
    """Merge back-to-back messages from the same role (APIs prefer strict alternation)."""
    out: list[dict] = []
    for m in messages:
        content = (m.get("content") or "").strip()
        if not content:
            continue
        if out and out[-1]["role"] == m["role"]:
            out[-1] = {"role": m["role"], "content": out[-1]["content"] + "\n" + content}
        else:
            out.append({"role": m["role"], "content": content})
    return out


class Provider:
    name = "base"
    model = ""

    def complete(self, system: str, messages: list[dict]) -> str:  # pragma: no cover - interface
        raise NotImplementedError

    def describe(self) -> str:
        return f"{self.name} ({self.model})" if self.model else self.name


class _HttpProvider(Provider):
    def __init__(self, api_key, model, *, url, transport=None, sleep=None, timeout=C.HTTP_TIMEOUT_SECONDS,
                 temperature=0.3, max_tokens=400):
        if not api_key:
            raise ProviderError(f"{self.name}: missing API key")
        self.api_key = api_key
        self.model = model
        self.url = url
        self.transport = transport
        self.sleep = sleep
        self.timeout = timeout
        self.temperature = temperature
        self.max_tokens = max_tokens

    def _post(self, payload: dict, headers: dict) -> dict:
        try:
            return post_json(self.url, payload, headers, transport=self.transport, sleep=self.sleep,
                             timeout=self.timeout)
        except HttpError as e:
            raise ProviderError(f"{self.name} request failed: {e}") from e


class OpenAIProvider(_HttpProvider):
    """Any OpenAI-compatible /chat/completions endpoint (OpenAI, OpenRouter, Groq, local servers...)."""

    name = "openai"

    def __init__(self, api_key, model=C.DEFAULT_OPENAI_MODEL, *, base_url=C.OPENAI_CHAT_URL, **kw):
        super().__init__(api_key, model or C.DEFAULT_OPENAI_MODEL, url=base_url or C.OPENAI_CHAT_URL, **kw)

    def build_payload(self, system: str, messages: list[dict]) -> dict:
        msgs = ([{"role": "system", "content": system}] if system else []) + merge_roles(messages)
        return {"model": self.model, "messages": msgs, "temperature": self.temperature,
                "max_tokens": self.max_tokens}

    def complete(self, system: str, messages: list[dict]) -> str:
        data = self._post(self.build_payload(system, messages), {"Authorization": f"Bearer {self.api_key}"})
        try:
            content = data[C.OPENAI_CHOICES_FIELD][0][C.OPENAI_MESSAGE_FIELD][C.OPENAI_CONTENT_FIELD]
        except (KeyError, IndexError, TypeError) as e:
            raise ProviderError(f"openai: unexpected response shape: {str(data)[:200]}") from e
        if isinstance(content, list):  # some compatible servers return content parts
            content = "".join(p.get("text", "") for p in content if isinstance(p, dict))
        return (content or "").strip()


class AnthropicProvider(_HttpProvider):
    name = "anthropic"

    def __init__(self, api_key, model=C.DEFAULT_ANTHROPIC_MODEL, *, base_url=C.ANTHROPIC_MESSAGES_URL, **kw):
        super().__init__(api_key, model or C.DEFAULT_ANTHROPIC_MODEL,
                         url=base_url or C.ANTHROPIC_MESSAGES_URL, **kw)

    def build_payload(self, system: str, messages: list[dict]) -> dict:
        msgs = merge_roles(messages)
        if not msgs or msgs[0]["role"] != "user":
            msgs.insert(0, {"role": "user", "content": C.ANTHROPIC_CALL_CONNECTED_PLACEHOLDER})
        payload = {"model": self.model, "max_tokens": self.max_tokens, "messages": msgs,
                   "temperature": self.temperature}
        if system:
            payload["system"] = system
        return payload

    def complete(self, system: str, messages: list[dict]) -> str:
        headers = {C.ANTHROPIC_KEY_HEADER: self.api_key, C.ANTHROPIC_VERSION_HEADER: C.ANTHROPIC_VERSION}
        data = self._post(self.build_payload(system, messages), headers)
        blocks = data.get(C.ANTHROPIC_CONTENT_FIELD) if isinstance(data, dict) else None
        if not isinstance(blocks, list):
            raise ProviderError(f"anthropic: unexpected response shape: {str(data)[:200]}")
        text = "".join(b.get("text", "") for b in blocks
                       if isinstance(b, dict) and b.get("type") == C.ANTHROPIC_TEXT_BLOCK_TYPE)
        return text.strip()


class FakeProvider(Provider):
    """Canned replies for demos and tests. Records every call in ``calls``.

    ``replies``: list of strings returned in order (last one repeats), or
    ``fn(system, messages) -> str`` for full control.
    """

    name = "fake"

    def __init__(self, replies: list[str] | None = None, fn: Callable[[str, list], str] | None = None,
                 model: str = "fake-model"):
        self.replies = list(replies or ["OK."])
        self.fn = fn
        self.model = model
        self.calls: list[tuple[str, list[dict]]] = []

    def complete(self, system: str, messages: list[dict]) -> str:
        self.calls.append((system, [dict(m) for m in messages]))
        if self.fn:
            return self.fn(system, messages)
        idx = min(len(self.calls) - 1, len(self.replies) - 1)
        return self.replies[idx]


FAKE_ROLE_REPLIES = {
    "agent": ["Thank you for calling. I'm an AI assistant for the office. How can I help you today?"],
    "caller": ["Thanks, that's all I needed. Goodbye. [END]"],
    "judge": ['{"score": 1.0, "reasoning": "Fake judge used for a demo: always passes."}'],
}

PROVIDER_NAMES = ("openai", "anthropic", "fake")


def default_provider_name(env: Mapping[str, str] | None = None) -> str | None:
    env = os.environ if env is None else env
    if env.get(C.ENV_ANTHROPIC_KEY):
        return "anthropic"
    if env.get(C.ENV_OPENAI_KEY):
        return "openai"
    return None


def create_provider(name: str | None, model: str | None = None, *, env: Mapping[str, str] | None = None,
                    transport: Transport | None = None, sleep=None, base_url: str | None = None,
                    api_key_env: str | None = None, role: str = "agent") -> Provider:
    """Build a provider by name, reading the API key from the environment."""
    env = os.environ if env is None else env
    name = (name or default_provider_name(env) or "").lower()
    if not name:
        raise ProviderError(
            f"No AI provider key found. Set {C.ENV_OPENAI_KEY} or {C.ENV_ANTHROPIC_KEY}, "
            "or use --provider fake for a demo."
        )
    if name == "fake":
        return FakeProvider(FAKE_ROLE_REPLIES.get(role, ["OK."]))
    if name == "openai":
        key_env = api_key_env or C.ENV_OPENAI_KEY
        key = env.get(key_env)
        if not key:
            raise ProviderError(f"Set the {key_env} environment variable to use the openai provider.")
        return OpenAIProvider(key, model, base_url=base_url, transport=transport, sleep=sleep)
    if name == "anthropic":
        key_env = api_key_env or C.ENV_ANTHROPIC_KEY
        key = env.get(key_env)
        if not key:
            raise ProviderError(f"Set the {key_env} environment variable to use the anthropic provider.")
        return AnthropicProvider(key, model, base_url=base_url, transport=transport, sleep=sleep)
    raise ProviderError(f"Unknown provider '{name}'. Choose one of: {', '.join(PROVIDER_NAMES)}.")
