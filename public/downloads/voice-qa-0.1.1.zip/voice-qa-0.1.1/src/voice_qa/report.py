"""Outputs: client-facing HTML scorecard, JSON results, JUnit XML, comparisons and console text."""

from __future__ import annotations

import json
import re
import xml.etree.ElementTree as ET
from html import escape
from pathlib import Path
from typing import Any

from .textutil import not_utf8_message

DEFAULT_BRAND_COLOR = "#2563eb"
_COLOR_RE = re.compile(r"^(#[0-9a-fA-F]{3}|#[0-9a-fA-F]{6}|[a-zA-Z]{3,20})$")
DEMO_NOTICE = ("Demo data: these conversations come from the built-in demo receptionist or the fake AI provider, "
               "not a real agent.")
TEXT_ONLY_NOTE = "text only: no audio or phone line was tested"


class ReportError(Exception):
    pass


def safe_color(value: str | None) -> str:
    """Only allow hex or named colours so branding can't inject CSS."""
    if value and _COLOR_RE.match(value.strip()):
        return value.strip()
    return DEFAULT_BRAND_COLOR


def safe_url(value: str | None) -> str | None:
    if value and re.match(r"^(https?://|data:image/)", value.strip(), re.IGNORECASE):
        return value.strip()
    return None


def is_demo(results: dict) -> bool:
    """True for demo runs (older results files have no "demo" field, so a scripted agent counts too)."""
    return bool(results.get("demo")) or (results.get("agent") or {}).get("kind") == "scripted"


def _int(value: Any) -> int:
    """Numbers read back from a results.json may have been edited by hand: never trust them in HTML."""
    try:
        return int(value)
    except (TypeError, ValueError):
        return 0


# ---------------------------------------------------------------- JSON


def to_json(results: dict) -> str:
    return json.dumps(dict(results, demo=is_demo(results)), indent=2, ensure_ascii=False)


def load_results(path: str | Path) -> dict:
    p = Path(path)
    if not p.is_file():
        raise ReportError(f"Results file not found: {p}")
    try:
        data = json.loads(p.read_text(encoding="utf-8"))
    except json.JSONDecodeError as e:
        raise ReportError(f"{p} is not valid JSON: {e}") from e
    except UnicodeDecodeError as e:
        raise ReportError(not_utf8_message(p)) from e
    if not isinstance(data, dict) or "scenarios" not in data or "summary" not in data:
        raise ReportError(f"{p} does not look like voice-qa results (no 'scenarios'/'summary').")
    return data


# ---------------------------------------------------------------- compare


def compare_results(current: dict, previous: dict) -> dict:
    """What changed since the previous run, scenario by scenario."""
    prev = {s["id"]: s for s in previous.get("scenarios", [])}
    cur = {s["id"]: s for s in current.get("scenarios", [])}
    rows = []
    for sid, s in cur.items():
        p = prev.get(sid)
        if p is None:
            change = "new"
        elif not p["passed"] and s["passed"]:
            change = "fixed"
        elif p["passed"] and not s["passed"]:
            change = "regressed"
        elif s["score"] > p["score"] + 1e-6:
            change = "improved"
        elif s["score"] < p["score"] - 1e-6:
            change = "worse"
        else:
            change = "same"
        rows.append({"id": sid, "title": s["title"], "change": change,
                     "before_passed": p["passed"] if p else None, "after_passed": s["passed"],
                     "before_score": p["score"] if p else None, "after_score": s["score"]})
    for sid, p in prev.items():
        if sid not in cur:
            rows.append({"id": sid, "title": p["title"], "change": "removed", "before_passed": p["passed"],
                         "after_passed": None, "before_score": p["score"], "after_score": None})
    before = previous.get("summary", {}).get("score", 0.0)
    after = current.get("summary", {}).get("score", 0.0)
    return {
        "previous_generated_at": previous.get("generated_at"),
        "score_before": before,
        "score_after": after,
        "score_change": round(after - before, 4),
        "fixed": [r for r in rows if r["change"] == "fixed"],
        "regressed": [r for r in rows if r["change"] == "regressed"],
        "rows": rows,
    }


# ---------------------------------------------------------------- console


def pct(x: float | None) -> str:
    try:
        return "-" if x is None else f"{float(x) * 100:.0f}%"
    except (TypeError, ValueError):
        return "-"


def console_summary(results: dict, comparison: dict | None = None) -> str:
    s = results["summary"]
    lines = [DEMO_NOTICE] if is_demo(results) else []
    lines += [f"Voice QA for {results['business_name']}  (pack: {results['pack']['name']}, "
              f"agent: {results['agent'].get('description') or results['agent'].get('kind')})",
              f"{_int(s['total'])} simulated text conversations ({TEXT_ONLY_NOTE}).", ""]
    for sc in results["scenarios"]:
        status = "ERROR" if sc.get("error") else ("PASS " if sc["passed"] else "FAIL ")
        lines.append(f"  {status} {pct(sc['score']):>5}  {sc['title']}")
        if not sc["passed"]:
            lines.append(f"               -> {sc['summary']}")
    lines += ["", f"Overall: {pct(s['score'])} (grade {s['grade']}), {s['passed']} of {s['total']} calls passed."]
    if comparison:
        lines.append(f"Compared with previous run: {pct(comparison['score_before'])} -> "
                     f"{pct(comparison['score_after'])}")
        for r in comparison["fixed"]:
            lines.append(f"  FIXED      {r['title']}")
        for r in comparison["regressed"]:
            lines.append(f"  REGRESSED  {r['title']}")
    return "\n".join(lines)


# ---------------------------------------------------------------- JUnit XML

_BAD_XML = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f]")


def _x(text: Any) -> str:
    return _BAD_XML.sub("", str(text if text is not None else ""))


def to_junit(results: dict) -> str:
    """JUnit XML so CI systems (GitHub Actions, GitLab, Jenkins) can show pass/fail per scenario."""
    s = results["summary"]
    errors = s.get("errors", 0)
    failures = s["failed"] - errors
    total_time = sum(sc.get("seconds", 0) for sc in results["scenarios"])
    suites = ET.Element("testsuites", name="voice-qa", tests=str(s["total"]), failures=str(failures),
                        errors=str(errors), time=f"{total_time:.3f}")
    suite = ET.SubElement(suites, "testsuite", name=_x(f"voice-qa.{results['pack']['name']}"),
                          tests=str(s["total"]), failures=str(failures), errors=str(errors), skipped="0",
                          time=f"{total_time:.3f}", timestamp=_x(results.get("generated_at", "")))
    props = ET.SubElement(suite, "properties")
    for k, v in (("business_name", results.get("business_name")), ("score", s["score"]),
                 ("grade", s["grade"]), ("threshold", results.get("threshold"))):
        ET.SubElement(props, "property", name=k, value=_x(v))
    ET.SubElement(props, "property", name="demo", value="true" if is_demo(results) else "false")
    for sc in results["scenarios"]:
        case = ET.SubElement(suite, "testcase", classname=_x(f"voice_qa.{results['pack']['name']}"),
                             name=_x(f"{sc['id']}: {sc['title']}"), time=f"{sc.get('seconds', 0):.3f}")
        detail_lines = [f"score {pct(sc['score'])} (needs {pct(sc['threshold'])})"]
        for c in sc["checks"]:
            mark = "SKIP" if c["skipped"] else ("ok" if c["passed"] else "FAIL")
            detail_lines.append(f"[{mark}] {c['label']}: {c['explanation']}")
        if sc.get("error"):
            el = ET.SubElement(case, "error", message=_x(sc["error"]), type="AgentError")
            el.text = _x("\n".join(detail_lines))
        elif not sc["passed"]:
            failed = [c["label"] for c in sc["checks"] if not c["passed"] and not c["skipped"]]
            el = ET.SubElement(case, "failure", message=_x("; ".join(failed) or "score below threshold"),
                               type="ScenarioFailed")
            el.text = _x("\n".join(detail_lines))
        out = ET.SubElement(case, "system-out")
        out.text = _x("\n".join(f"{t['role'].upper()}: {t['text']}" for t in sc["transcript"]))
    ET.indent(suites)
    return '<?xml version="1.0" encoding="UTF-8"?>\n' + ET.tostring(suites, encoding="unicode") + "\n"


# ---------------------------------------------------------------- HTML

CSS = """
:root { --brand: %(brand)s; --ink:#111827; --muted:#6b7280; --line:#e5e7eb; --pass:#15803d; --fail:#b91c1c; --warn:#b45309; }
* { box-sizing: border-box; }
body { margin:0; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
       color: var(--ink); background:#f9fafb; line-height:1.5; }
.page { max-width: 960px; margin: 0 auto; background:#fff; padding: 0 0 32px; }
header { background: var(--brand); color:#fff; padding: 24px 32px; display:flex; align-items:center; gap:16px; }
header img { max-height:48px; max-width:160px; background:#fff; border-radius:6px; padding:4px; }
header h1 { margin:0; font-size: 22px; }
header p { margin:2px 0 0; opacity:.9; }
section { padding: 8px 32px; }
h2 { font-size: 18px; border-bottom: 2px solid var(--brand); padding-bottom:4px; margin-top:28px; }
.hero { display:flex; gap:24px; align-items:center; flex-wrap:wrap; margin-top:20px; }
.grade { width:110px; height:110px; border-radius:50%%; border:8px solid var(--brand); display:flex;
         align-items:center; justify-content:center; font-size:48px; font-weight:800; color:var(--brand); }
.stat { font-size: 15px; color: var(--muted); }
.stat b { display:block; font-size: 28px; color: var(--ink); }
table { width:100%%; border-collapse: collapse; font-size: 14px; }
th, td { text-align:left; vertical-align: top; padding: 8px; border-bottom:1px solid var(--line); }
th { background:#f3f4f6; }
.pill { display:inline-block; padding:2px 10px; border-radius:999px; font-weight:700; font-size:12px; color:#fff; }
.pass { background: var(--pass); } .fail { background: var(--fail); } .error { background: var(--warn); }
.checks { margin:6px 0 0; padding-left: 18px; color: var(--muted); font-size: 13px; }
.checks .bad { color: var(--fail); }
.call { border:1px solid var(--line); border-radius:8px; padding: 10px 14px; margin: 12px 0; page-break-inside: avoid; }
.call h3 { margin: 0 0 6px; font-size: 15px; }
.line { margin: 3px 0; font-size: 13px; }
.who { font-weight:700; display:inline-block; min-width: 56px; }
.agent .who { color: var(--brand); }
.muted { color: var(--muted); font-size: 13px; }
.fix { background:#fff7ed; border-left: 4px solid var(--warn); padding: 8px 12px; margin: 8px 0; }
.fixed { background:#f0fdf4; border-left: 4px solid var(--pass); padding: 8px 12px; margin: 8px 0; }
.demo { background:#fef3c7; border:2px solid var(--warn); color:var(--ink); padding:10px 32px; font-weight:700; }
footer { padding: 16px 32px; color: var(--muted); font-size: 12px; border-top:1px solid var(--line); margin-top: 24px; }
@media print {
  body { background:#fff; }
  .page { max-width:none; }
  header, .pill, .grade, th, .demo { -webkit-print-color-adjust: exact; print-color-adjust: exact; }
  tr, .call, .fix, .fixed { page-break-inside: avoid; }
  a { color: inherit; text-decoration: none; }
}
"""

MAX_EXCERPT_TURNS = 8
MAX_LINE_CHARS = 400


def _status_pill(sc: dict) -> str:
    if sc.get("error"):
        return '<span class="pill error">ERROR</span>'
    return '<span class="pill pass">PASS</span>' if sc["passed"] else '<span class="pill fail">FAIL</span>'


def _excerpt(transcript: list[dict]) -> str:
    rows = []
    for t in transcript[:MAX_EXCERPT_TURNS]:
        text = t["text"]
        if len(text) > MAX_LINE_CHARS:
            text = text[:MAX_LINE_CHARS].rstrip() + "..."
        who = "Agent" if t["role"] == "agent" else "Caller"
        rows.append(f'<div class="line {escape(t["role"])}"><span class="who">{who}:</span> {escape(text)}</div>')
    if len(transcript) > MAX_EXCERPT_TURNS:
        rows.append(f'<div class="muted">... {len(transcript) - MAX_EXCERPT_TURNS} more line(s) in results.json</div>')
    return "\n".join(rows) or '<div class="muted">No conversation recorded.</div>'


def to_html(results: dict, comparison: dict | None = None, branding: dict | None = None) -> str:
    """Self-contained client-facing scorecard. Everything from users/LLMs is escaped."""
    brand = dict(results.get("branding") or {})
    brand.update({k: v for k, v in (branding or {}).items() if v})
    color = safe_color(brand.get("brand_color"))
    brand_name = brand.get("brand_name") or "Voice Agent QA"
    logo = safe_url(brand.get("logo_url"))
    contact = brand.get("agency_contact")
    s = results["summary"]
    business = results.get("business_name", "")
    date = (results.get("generated_at") or "")[:10]

    head = (f'<img src="{escape(logo, quote=True)}" alt="{escape(brand_name, quote=True)} logo">' if logo else "")
    parts = [
        "<!DOCTYPE html>",
        '<html lang="en"><head><meta charset="utf-8">',
        '<meta name="viewport" content="width=device-width, initial-scale=1">',
        f"<title>{escape(business)} - Voice Agent Scorecard</title>",
        f"<style>{CSS % {'brand': color}}</style></head><body><div class=\"page\">",
        f'<div class="demo">{escape(DEMO_NOTICE)}</div>' if is_demo(results) else "",
        f"<header>{head}<div><h1>{escape(brand_name)}</h1>"
        f"<p>AI Phone Receptionist Scorecard for <b>{escape(business)}</b> &middot; {escape(date)}</p></div></header>",
        "<section><div class=\"hero\">",
        f'<div class="grade" aria-label="overall grade">{escape(s["grade"])}</div>',
        f'<div class="stat"><b>{pct(s["score"])}</b>overall score</div>',
        f'<div class="stat"><b>{_int(s["passed"])} / {_int(s["total"])}</b>test conversations passed</div>',
        f'<div class="stat"><b>{_int(s.get("critical_failures", 0))}</b>critical problems</div>',
        "</div>",
        f'<p class="muted">We ran {_int(s["total"])} simulated text conversations with the AI receptionist '
        f'({TEXT_ONLY_NOTE}), pretending to be different kinds of callers '
        f'({escape(results["pack"].get("title", ""))}). Each conversation is graded on what the receptionist '
        f'said. A conversation passes at {pct(results.get("threshold"))} or higher with no critical mistakes.</p>'
        "</section>",
    ]

    # results table
    rows = []
    for sc in results["scenarios"]:
        items = []
        for c in sc["checks"]:
            if c["skipped"]:
                continue
            cls = "" if c["passed"] else ' class="bad"'
            mark = "&#10003;" if c["passed"] else "&#10007;"
            items.append(f"<li{cls}>{mark} {escape(c['label'])}</li>")
        checks_html = f'<ul class="checks">{"".join(items)}</ul>' if items else ""
        rows.append(
            f"<tr><td><b>{escape(sc['title'])}</b><div class=\"muted\">{escape(sc['persona'])}</div></td>"
            f"<td>{_status_pill(sc)}</td><td>{pct(sc['score'])}</td>"
            f"<td>{escape(sc['summary'])}{checks_html}</td></tr>"
        )
    parts += ["<section><h2>Test conversations</h2><table><thead><tr><th>Scenario</th><th>Result</th><th>Score</th>"
              "<th>What happened</th></tr></thead><tbody>", *rows, "</tbody></table></section>"]

    # fixed / to fix
    parts.append("<section><h2>What we fixed</h2>")
    if comparison is None:
        parts.append('<p class="muted">This is the first test run. After changes, run again with '
                     '<code>--compare</code> to show what improved.</p>')
    else:
        parts.append(f'<p>Score went from <b>{pct(comparison["score_before"])}</b> to '
                     f'<b>{pct(comparison["score_after"])}</b> since the run on '
                     f'{escape(str(comparison.get("previous_generated_at") or "")[:10])}.</p>')
        for r in comparison["fixed"]:
            parts.append(f'<div class="fixed">&#10003; <b>{escape(r["title"])}</b>: now handled correctly.</div>')
        for r in comparison["regressed"]:
            parts.append(f'<div class="fix">&#9888; <b>{escape(r["title"])}</b>: worked before, fails now.</div>')
        if not comparison["fixed"] and not comparison["regressed"]:
            parts.append('<p class="muted">No scenario changed between pass and fail.</p>')
    parts.append("</section><section><h2>What to fix</h2>")
    failing = [sc for sc in results["scenarios"] if not sc["passed"]]
    if not failing:
        parts.append('<p>Nothing! Every test call passed.</p>')
    for sc in failing:
        hint = sc.get("fix_hint") or "Review the transcript below and adjust the agent's instructions."
        parts.append(f'<div class="fix"><b>{escape(sc["title"])}</b>: {escape(sc["summary"])}'
                     f'<div><i>Suggested fix:</i> {escape(hint)}</div></div>')
    parts.append("</section>")

    # transcripts
    parts.append("<section><h2>Conversation transcripts (excerpts)</h2>")
    for sc in results["scenarios"]:
        parts.append(f'<div class="call"><h3>{_status_pill(sc)} {escape(sc["title"])}</h3>'
                     f'<div class="muted">Call ended because {escape(sc.get("ended_by_text", sc.get("ended_by", "")))}'
                     f'.</div>{_excerpt(sc["transcript"])}</div>')
    parts.append("</section>")

    agent_desc = results.get("agent", {}).get("description") or results.get("agent", {}).get("kind", "")
    judge = results.get("judge")
    contact_html = f"<p>Questions? {escape(contact)}</p>" if contact else ""
    parts.append(
        "<footer><b>How this was measured.</b> "
        f"On {escape(date)} we ran {_int(s['total'])} simulated text conversations (no audio, no phone call) with "
        f"{escape(agent_desc)} using the &ldquo;{escape(results['pack'].get('title', ''))}&rdquo; test pack. "
        "Each call was graded with fixed rules (for example: did it tell an emergency caller to dial 911, "
        "did it make up prices, did it admit being an AI)"
        + (f" plus an AI reviewer ({escape(judge)})" if judge else "")
        + ". Real calls can still differ because of speech recognition, voices and phone lines."
        f"{contact_html}<p>Generated with voice-qa {escape(results.get('version', ''))}.</p></footer>"
    )
    parts.append("</div></body></html>")
    return "\n".join(parts)


def write_outputs(results: dict, out_dir: str | Path, comparison: dict | None = None) -> dict:
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    paths = {"json": out / "results.json", "html": out / "scorecard.html", "junit": out / "junit.xml"}
    paths["json"].write_text(to_json(results), encoding="utf-8")
    paths["html"].write_text(to_html(results, comparison), encoding="utf-8")
    paths["junit"].write_text(to_junit(results), encoding="utf-8")
    return paths
