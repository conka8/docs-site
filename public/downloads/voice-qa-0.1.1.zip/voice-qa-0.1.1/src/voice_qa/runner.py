"""Run a scenario pack against an agent and collect results (a plain JSON-ready dict)."""

from __future__ import annotations

import datetime as _dt
import time
from typing import Iterable

from . import __version__
from . import constants as C
from .checks import CheckContext, run_check, score_checks
from .conversation import ENDED_BY_TEXT, LLMCaller, ScriptedCaller, simulate_call
from .packs import Pack, Scenario
from .providers import FakeProvider

CALLER_MODES = ("auto", "script", "llm")


class RunError(Exception):
    """The run could not start (bad options)."""


def grade_for(score: float) -> str:
    for floor, letter in C.GRADE_BANDS:
        if score >= floor - 1e-9:
            return letter
    return "F"  # pragma: no cover


def _make_caller(sc: Scenario, mode: str, caller_provider, business: str):
    if mode == "script" or (mode == "auto" and sc.caller_script):
        if not sc.caller_script:
            raise RunError(f"Scenario '{sc.id}' has no caller_script (use --caller llm with a --caller-provider).")
        return ScriptedCaller(sc.caller_script)
    if caller_provider is None:
        raise RunError(
            f"Scenario '{sc.id}' needs an AI caller: pass --caller-provider (openai, anthropic or fake)."
        )
    return LLMCaller(caller_provider, sc.persona, sc.goal, business, hints=sc.caller_script or ())


def plain_summary(passed: bool, checks: list[dict], error: str | None) -> str:
    """One plain-English sentence for the client report."""
    if error:
        return f"The test call could not finish: {error}"
    failed = [c for c in checks if not c["passed"] and not c["skipped"]]
    if passed and not failed:
        return "Handled this call well."
    parts = [c["explanation"] for c in failed]
    prefix = "Mostly fine, but: " if passed else ""
    return prefix + " ".join(parts)


def run_scenario(sc: Scenario, agent, *, business_name: str, caller_mode: str = "auto", caller_provider=None,
                 judge_provider=None, knowledge_text: str = "", threshold: float = C.DEFAULT_PASS_THRESHOLD,
                 max_turns: int | None = None) -> dict:
    sc = sc.filled(business_name)
    thr = sc.pass_threshold if sc.pass_threshold is not None else threshold
    started = time.perf_counter()
    caller = _make_caller(sc, caller_mode, caller_provider, business_name)
    turns = max_turns or sc.max_turns or C.DEFAULT_MAX_TURNS
    terminal = sc.terminal_phrases if sc.terminal_phrases is not None else C.DEFAULT_TERMINAL_PHRASES
    conv = simulate_call(agent, caller, max_turns=turns, terminal_phrases=terminal)
    checks: list[dict] = []
    if conv.error:
        score, passed = 0.0, False
    else:
        knowledge = "\n".join(x for x in (knowledge_text, getattr(agent, "known_text", "")) if x)
        ctx = CheckContext(conv.transcript, knowledge, judge_provider,
                           {"persona": sc.persona, "goal": sc.goal, "title": sc.title})
        results = [run_check(ch, ctx) for ch in sc.checks]
        score, passed = score_checks(results, thr)
        checks = [r.to_dict() for r in results]
    return {
        "id": sc.id,
        "title": sc.title,
        "persona": sc.persona,
        "goal": sc.goal,
        "caller": caller.kind,
        "passed": passed,
        "score": round(score, 4),
        "threshold": thr,
        "ended_by": conv.ended_by,
        "ended_by_text": ENDED_BY_TEXT.get(conv.ended_by, conv.ended_by),
        "agent_turns": sum(1 for t in conv.transcript if t.role == "agent"),
        "error": conv.error,
        "summary": plain_summary(passed, checks, conv.error),
        "fix_hint": sc.fix_hint,
        "checks": checks,
        "transcript": [t.to_dict() for t in conv.transcript],
        "seconds": round(time.perf_counter() - started, 3),
    }


def summarize(scenarios: list[dict]) -> dict:
    total = len(scenarios)
    passed = sum(1 for s in scenarios if s["passed"])
    score = sum(s["score"] for s in scenarios) / total if total else 0.0
    critical = sum(1 for s in scenarios for c in s["checks"] if c["critical"] and not c["passed"] and not c["skipped"])
    return {
        "total": total,
        "passed": passed,
        "failed": total - passed,
        "errors": sum(1 for s in scenarios if s.get("error")),
        "score": round(score, 4),
        "pass_rate": round(passed / total, 4) if total else 0.0,
        "grade": grade_for(score) if total else "F",
        "critical_failures": critical,
    }


def is_demo_run(agent, caller_provider=None, judge_provider=None) -> bool:
    """True when made-up parts were used: a scripted agent or the fake AI provider anywhere."""
    if getattr(agent, "kind", "") == "scripted":
        return True
    providers = (getattr(agent, "provider", None), caller_provider, judge_provider)
    return any(isinstance(p, FakeProvider) for p in providers)


def run_pack(pack: Pack, agent, *, business_name: str | None = None, caller_mode: str = "auto",
             caller_provider=None, judge_provider=None, knowledge_text: str = "",
             threshold: float | None = None, max_turns: int | None = None,
             scenario_ids: Iterable[str] | None = None, agent_info: dict | None = None,
             branding: dict | None = None, now: _dt.datetime | None = None, demo: bool | None = None) -> dict:
    """Run every (or the selected) scenario and return the results dict."""
    if caller_mode not in CALLER_MODES:
        raise RunError(f"caller mode must be one of {', '.join(CALLER_MODES)}")
    business = business_name or pack.default_business_name
    thr = threshold if threshold is not None else (pack.pass_threshold or C.DEFAULT_PASS_THRESHOLD)
    selected = pack.scenarios
    if scenario_ids:
        wanted = list(scenario_ids)
        known = {s.id for s in pack.scenarios}
        unknown = [w for w in wanted if w not in known]
        if unknown:
            raise RunError(f"Unknown scenario id(s): {', '.join(unknown)}. Known: {', '.join(sorted(known))}")
        selected = [s for s in pack.scenarios if s.id in wanted]
    # Fail fast on missing callers before making any (possibly paid) calls.
    for sc in selected:
        _make_caller(sc, caller_mode, caller_provider, business)
    results = [
        run_scenario(sc, agent, business_name=business, caller_mode=caller_mode, caller_provider=caller_provider,
                     judge_provider=judge_provider, knowledge_text=knowledge_text, threshold=thr,
                     max_turns=max_turns)
        for sc in selected
    ]
    now = now or _dt.datetime.now(_dt.timezone.utc)
    describe = getattr(agent, "describe", None)
    info = {"kind": getattr(agent, "kind", "custom"), "description": describe() if describe else ""}
    info.update(agent_info or {})
    return {
        "tool": "voice-qa",
        "version": __version__,
        "generated_at": now.isoformat(timespec="seconds"),
        "business_name": business,
        "pack": {"name": pack.name, "title": pack.title, "industry": pack.industry},
        "agent": info,
        "judge": judge_provider.describe() if judge_provider is not None else None,
        "demo": is_demo_run(agent, caller_provider, judge_provider) if demo is None else bool(demo),
        "threshold": thr,
        "branding": dict(branding or {}),
        "summary": summarize(results),
        "scenarios": results,
    }
