"""Small text helpers: phrase matching, language guessing, prices and phone numbers."""

from __future__ import annotations

import re
from typing import Iterable

_WORD_CHAR = re.compile(r"\w", re.UNICODE)


def normalize(text: str) -> str:
    """Lowercase and straighten curly quotes so phrase matching is forgiving."""
    return (
        (text or "")
        .replace("’", "'")
        .replace("‘", "'")
        .replace("“", '"')
        .replace("”", '"')
        .lower()
    )


def phrase_pattern(phrase: str) -> re.Pattern:
    """Build a case-insensitive regex for a phrase.

    Whole words only ("ai" does not match "said"). A trailing ``*`` matches any word
    ending ("frustrat*" matches "frustrated" and "frustrating").
    """
    p = normalize(phrase).strip()
    wildcard = p.endswith("*")
    if wildcard:
        p = p[:-1].rstrip()
    if not p:
        raise ValueError("empty phrase")
    body = r"\s+".join(re.escape(w) for w in p.split())
    start = r"(?<!\w)" if _WORD_CHAR.match(p[0]) else ""
    if wildcard:
        end = r"\w*"
    else:
        end = r"(?!\w)" if _WORD_CHAR.match(p[-1]) else ""
    return re.compile(start + body + end, re.IGNORECASE | re.UNICODE)


def find_phrases(text: str, phrases: Iterable[str]) -> list[str]:
    """Return every phrase (as written) that appears in text."""
    norm = normalize(text)
    return [p for p in phrases if p and p.strip() and phrase_pattern(p).search(norm)]


def find_phrase(text: str, phrases: Iterable[str]) -> str | None:
    hits = find_phrases(text, phrases)
    return hits[0] if hits else None


# ---------------------------------------------------------------- language

STOPWORDS = {
    "en": frozenset(
        "the and is are to you your of in for with that this can we have please thank thanks "
        "what help would like will be it my our how do does i'm it's yes sure right there "
        "an at on or if not just today about call".split()
    ),
    "es": frozenset(
        "el la los las de del que y en por para con una un es está están usted ustedes "
        "gracias hola sí su sus como pero muy puedo quiero necesito tengo buenos buenas días "
        "favor ayudar ayudarle le lo cita nombre número teléfono qué cuál cuándo dónde "
        "mañana tarde semana claro gusto español hablar también aquí bien".split()
    ),
}
_SPANISH_MARKS = re.compile(r"[ñ¿¡áéíóú]")


def detect_language(text: str) -> str:
    """Guess "en" or "es" from common words. Returns "unknown" when unsure."""
    words = re.findall(r"[\w']+", normalize(text))
    if not words:
        return "unknown"
    scores = {lang: sum(1 for w in words if w in stop) for lang, stop in STOPWORDS.items()}
    scores["es"] += len(_SPANISH_MARKS.findall(normalize(text))) * 0.5
    best = max(scores, key=scores.get)
    others = [v for k, v in scores.items() if k != best]
    if scores[best] < 1 or scores[best] <= max(others, default=0):
        return "unknown"
    return best


LANGUAGE_NAMES = {"en": "English", "es": "Spanish", "unknown": "an unclear language"}

# ---------------------------------------------------------------- money

_DOLLAR = re.compile(r"\$\s?(\d[\d,]*(?:\.\d{1,2})?)(\s?[kK]\b)?")
_WORD_DOLLARS = re.compile(
    r"(?<![\w$.])(\d[\d,]*(?:\.\d{1,2})?)\s*(?:dollars|bucks|usd|dólares|dolares)\b", re.IGNORECASE
)


def _to_number(raw: str, thousands: bool = False) -> float | None:
    try:
        value = float(raw.replace(",", ""))
    except ValueError:
        return None
    return value * 1000 if thousands else value


def extract_amounts(text: str) -> list[float]:
    """Find money amounts like "$99", "$1,200.50", "$5k" or "150 dollars"."""
    found: list[float] = []
    for m in _DOLLAR.finditer(text or ""):
        v = _to_number(m.group(1), bool(m.group(2)))
        if v is not None:
            found.append(v)
    for m in _WORD_DOLLARS.finditer(text or ""):
        v = _to_number(m.group(1))
        if v is not None:
            found.append(v)
    return found


def format_amount(value: float) -> str:
    return f"${value:,.2f}".replace(".00", "")


# ---------------------------------------------------------------- phone numbers

PHONE_RE = re.compile(r"(?<!\d)(?:\+?1[\s.-]?)?\(?\d{3}\)?[\s.-]?\d{3}[\s.-]?\d{4}(?!\d)")


def find_phone_numbers(text: str) -> list[str]:
    return [m.group(0).strip() for m in PHONE_RE.finditer(text or "")]


def digits_only(text: str) -> str:
    return re.sub(r"\D", "", text or "")


# ---------------------------------------------------------------- questions

QUESTION_MARKERS = (
    "may i", "can i", "could i", "could you", "can you", "would you", "please", "what is",
    "what's", "let me get", "i'll need", "i will need", "i just need", "tell me",
    "puede", "podría", "me da", "por favor", "cuál es",
)


def is_request(text: str) -> bool:
    """True when an agent line looks like a question or a request for information."""
    if "?" in (text or ""):
        return True
    return find_phrase(text, QUESTION_MARKERS) is not None


ASK_PATTERNS = {
    "name": (
        "your name", "full name", "first and last name", "name please", "who am i speaking",
        "who i'm speaking", "spell your name", "name for", "name on", "su nombre", "cómo se llama",
    ),
    "phone": (
        "phone number", "callback number", "call back number", "best number", "number to reach",
        "contact number", "cell number", "mobile number", "reach you at", "número de teléfono",
        "su número", "your number",
    ),
    "date": (
        "what day", "which day", "what date", "which date", "preferred date", "what time",
        "day and time", "date and time", "when would", "when works", "what works best",
        "availability", "when are you available", "qué día", "qué fecha", "qué hora",
    ),
    "email": ("email", "e-mail", "correo"),
    "address": ("address", "zip code", "where are you located", "dirección"),
    "reason": ("reason for", "what brings you", "what's going on", "what seems to be", "how can i help"),
}

POLITE_CLOSINGS = (
    "thank you", "thanks", "have a great day", "have a good day", "have a nice day",
    "have a wonderful", "goodbye", "good bye", "bye", "take care", "talk soon",
    "gracias", "que tenga", "adiós", "adios", "hasta luego", "cuídese",
)


def not_utf8_message(path) -> str:
    return f"{path} is not saved as UTF-8 text. Open it in a text editor, save it as UTF-8 and try again."


_SECRET_PATTERNS = (
    re.compile(r"Bearer\s+\S+", re.IGNORECASE),
    re.compile(r"sk-[A-Za-z0-9_-]{10,}"),
    re.compile(r"""api[_-]?key["'=: ]+\S+""", re.IGNORECASE),
)


def redact_secrets(text: str, limit: int = 200) -> str:
    """Hide things that look like API keys or tokens and cut long text (for error messages in reports)."""
    out = text or ""
    for pat in _SECRET_PATTERNS:
        out = pat.sub("[hidden]", out)
    out = out.strip()
    return out if len(out) <= limit else out[:limit].rstrip() + "..."
