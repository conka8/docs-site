"""Tiny HTTP layer on urllib with an injectable transport (so tests never touch the network)."""

from __future__ import annotations

import json
import time
import urllib.error
import urllib.request
from dataclasses import dataclass, field
from typing import Any, Callable

from . import constants as C
from .textutil import redact_secrets


@dataclass
class HttpRequest:
    method: str
    url: str
    headers: dict = field(default_factory=dict)
    body: bytes | None = None
    timeout: float = C.HTTP_TIMEOUT_SECONDS

    def json(self) -> Any:
        return json.loads(self.body.decode("utf-8")) if self.body else None


@dataclass
class HttpResponse:
    status: int
    body: str
    headers: dict = field(default_factory=dict)


class TransportError(Exception):
    """Network problem or timeout (no HTTP status)."""


class HttpError(Exception):
    """The server answered with an error, or retries ran out."""

    def __init__(self, message: str, status: int | None = None, body: str = ""):
        super().__init__(message)
        self.status = status
        self.body = body


Transport = Callable[[HttpRequest], HttpResponse]


def urllib_transport(req: HttpRequest) -> HttpResponse:
    """Default transport: a real HTTP call with urllib."""
    request = urllib.request.Request(req.url, data=req.body, headers=req.headers, method=req.method)
    try:
        with urllib.request.urlopen(request, timeout=req.timeout) as resp:  # noqa: S310
            body = resp.read().decode("utf-8", errors="replace")
            return HttpResponse(resp.status, body, dict(resp.headers.items()))
    except urllib.error.HTTPError as e:
        try:
            body = e.read().decode("utf-8", errors="replace")
        except Exception:  # pragma: no cover - defensive
            body = ""
        return HttpResponse(e.code, body, dict(e.headers.items()) if e.headers else {})
    except (urllib.error.URLError, TimeoutError, OSError) as e:
        reason = getattr(e, "reason", e)
        raise TransportError(f"could not reach {req.url}: {reason}") from e


def _retry_after(resp: HttpResponse) -> float | None:
    for k, v in resp.headers.items():
        if k.lower() == "retry-after":
            try:
                return min(float(v), C.HTTP_MAX_RETRY_AFTER_SECONDS)
            except ValueError:
                return None
    return None


def post_json(
    url: str,
    payload: Any,
    headers: dict | None = None,
    *,
    transport: Transport | None = None,
    retries: int = C.HTTP_MAX_RETRIES,
    sleep: Callable[[float], None] | None = None,
    timeout: float = C.HTTP_TIMEOUT_SECONDS,
) -> Any:
    """POST JSON and return the decoded JSON reply.

    Retries up to ``retries`` extra times on 429/5xx and network errors/timeouts.
    """
    transport = transport or urllib_transport
    sleep = sleep or time.sleep
    all_headers = {"Content-Type": "application/json", "Accept": "application/json"}
    all_headers.update(headers or {})
    req = HttpRequest("POST", url, all_headers, json.dumps(payload).encode("utf-8"), timeout)
    last_problem = ""
    last_status: int | None = None
    for attempt in range(retries + 1):
        wait = C.HTTP_BACKOFF_SECONDS * (2**attempt)
        try:
            resp = transport(req)
        except TransportError as e:
            last_problem, last_status = str(e), None
            if attempt < retries:
                sleep(wait)
                continue
            break
        if 200 <= resp.status < 300:
            try:
                return json.loads(resp.body) if resp.body.strip() else {}
            except json.JSONDecodeError as e:
                raise HttpError(f"{url} did not return JSON: {redact_secrets(resp.body)!r}", resp.status,
                                resp.body) from e
        last_status = resp.status
        last_problem = f"HTTP {resp.status}: {redact_secrets(resp.body)}"  # this text ends up in reports
        if resp.status in C.HTTP_RETRY_STATUSES and attempt < retries:
            ra = _retry_after(resp)
            sleep(ra if ra is not None else wait)
            continue
        if resp.status not in C.HTTP_RETRY_STATUSES:
            raise HttpError(f"{url} returned {last_problem}", resp.status, resp.body)
        break
    raise HttpError(f"{url} failed after {retries + 1} attempts ({last_problem})", last_status)
