import json
from pathlib import Path

import pytest

from voice_qa.transport import HttpResponse, TransportError

FIXTURES = Path(__file__).parent / "fixtures"


class FakeTransport:
    """Returns queued responses (HttpResponse, dict -> 200 JSON, or an Exception to raise)."""

    def __init__(self, *responses):
        self.queue = list(responses)
        self.requests = []

    def add(self, *responses):
        self.queue.extend(responses)

    def __call__(self, req):
        self.requests.append(req)
        if not self.queue:
            raise AssertionError("FakeTransport: no more queued responses")
        item = self.queue.pop(0) if len(self.queue) > 1 else self.queue[0]
        if callable(item) and not isinstance(item, (HttpResponse, dict)):
            item = item(req)
        if isinstance(item, Exception):
            raise item
        if isinstance(item, dict):
            return HttpResponse(200, json.dumps(item))
        return item


class Sleeper:
    def __init__(self):
        self.calls = []

    def __call__(self, seconds):
        self.calls.append(seconds)


@pytest.fixture
def fixtures():
    return FIXTURES


@pytest.fixture
def sleeper():
    return Sleeper()


@pytest.fixture
def make_transport():
    return FakeTransport


def openai_reply(text):
    return {"choices": [{"index": 0, "message": {"role": "assistant", "content": text}}]}


def anthropic_reply(text):
    return {"content": [{"type": "text", "text": text}], "role": "assistant"}


__all__ = ["FakeTransport", "Sleeper", "openai_reply", "anthropic_reply", "TransportError", "HttpResponse"]
