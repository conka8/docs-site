import json

import pytest
from conftest import FakeTransport

from voice_qa.adapters import (
    AdapterError, HttpAgent, PromptAgent, ScriptedAgent, demo_script, get_path, import_retell, import_vapi,
    load_platform_config, load_script,
)
from voice_qa.conversation import Turn
from voice_qa.providers import FakeProvider
from voice_qa.transport import HttpResponse

T = [Turn("agent", "Hello!"), Turn("caller", "Hi, are you a robot?")]


# ---------------------------------------------------------------- JSON path


@pytest.mark.parametrize("path, expected", [
    ("reply", "top"),
    ("$.reply", "top"),
    ("data.text", "nested"),
    ("choices[0].message.content", "first"),
    ("choices.1.message.content", "second"),
    ("$", None),
])
def test_get_path(path, expected):
    obj = {"reply": "top", "data": {"text": "nested"},
           "choices": [{"message": {"content": "first"}}, {"message": {"content": "second"}}]}
    assert get_path(obj, path) == (obj if path == "$" else expected)


@pytest.mark.parametrize("path", ["missing", "choices[5].message", "reply.inner", "choices.x"])
def test_get_path_missing(path):
    with pytest.raises(KeyError):
        get_path({"reply": "top", "choices": [{}]}, path)


# ---------------------------------------------------------------- HTTP agent


def test_http_agent_payload_headers_and_reply(sleeper):
    t = FakeTransport({"output": {"text": " I'm an AI assistant. "}, "done": False})
    agent = HttpAgent("https://agent.example/hook", "output.text", headers={"X-Key": "abc"},
                      end_call_path="done", extra_body={"session": "qa"}, transport=t, sleep=sleeper)
    r = agent.reply(T)
    assert r.text == "I'm an AI assistant." and r.end_call is False
    req = t.requests[0]
    assert req.url == "https://agent.example/hook" and req.headers["X-Key"] == "abc"
    assert req.json() == {"session": "qa", "messages": [{"role": "assistant", "content": "Hello!"},
                                                        {"role": "user", "content": "Hi, are you a robot?"}]}
    assert "webhook" in agent.describe()


def test_http_agent_end_call_and_non_string_reply():
    t = FakeTransport({"reply": ["a", 1], "meta": {"ended": True}})
    r = HttpAgent("http://x.test", end_call_path="meta.ended", transport=t).reply(T)
    assert r.text == json.dumps(["a", 1]) and r.end_call is True
    t = FakeTransport({"reply": None})
    r = HttpAgent("http://x.test", end_call_path="meta.ended", transport=t).reply(T)
    assert r.text == "" and r.end_call is False


def test_http_agent_errors(sleeper):
    with pytest.raises(AdapterError, match="http"):
        HttpAgent("ftp://x")
    with pytest.raises(AdapterError, match="no field 'reply'"):
        HttpAgent("http://x.test", transport=FakeTransport({"text": "hi"})).reply(T)
    with pytest.raises(AdapterError, match="webhook failed"):
        HttpAgent("http://x.test", transport=FakeTransport(HttpResponse(500, "err")), sleep=sleeper).reply(T)


# ---------------------------------------------------------------- prompt agent


def test_prompt_agent_maps_roles_and_end_call():
    provider = FakeProvider(["Okay, have a wonderful day!"])
    agent = PromptAgent("SYSTEM PROMPT", provider, "Hello!", ["have a wonderful day"])
    r = agent.reply(T)
    assert r.end_call is True
    system, messages = provider.calls[0]
    assert system == "SYSTEM PROMPT"
    assert messages == [{"role": "assistant", "content": "Hello!"}, {"role": "user", "content": "Hi, are you a robot?"}]
    assert "SYSTEM PROMPT" in agent.known_text and "fake" in agent.describe()
    assert PromptAgent("p", FakeProvider(["sure"])).reply(T).end_call is False
    with pytest.raises(AdapterError):
        PromptAgent("   ", provider)


# ---------------------------------------------------------------- scripted agent


def test_scripted_agent_rules(fixtures):
    agent = ScriptedAgent(load_script(fixtures / "http_script.yaml"), "Test Clinic")
    assert agent.first_message == "Hello from Test Clinic!"
    assert agent.reply(T).text == "I'm an AI assistant."
    r = agent.reply([Turn("caller", "my number is 559-555-0199 thanks")])
    assert r.text == "I have 559-555-0199, is that correct?"
    assert agent.reply([Turn("caller", "Hola, necesito una cita por favor")]).text.startswith("Hola")
    r = agent.reply([Turn("caller", "I'm going to hang up now")])
    assert r.end_call and r.text == "Goodbye!"
    assert agent.reply([Turn("caller", "blah")]).text == "Sorry, can you repeat that?"
    assert agent.reply([]).text == "Sorry, can you repeat that?"
    assert "scripted" in agent.describe()


@pytest.mark.parametrize("script, msg", [
    ([], "mapping"),
    ({"rules": [{"if_any": ["x"]}]}, "needs a 'say'"),
    ({"rules": [{"say": "hi"}]}, "needs 'if_any'"),
])
def test_scripted_agent_bad_scripts(script, msg):
    with pytest.raises(AdapterError, match=msg):
        ScriptedAgent(script)


def test_load_script_errors(tmp_path):
    with pytest.raises(AdapterError, match="not found"):
        load_script(tmp_path / "nope.yaml")
    (tmp_path / "list.yaml").write_text("- a\n- b\n")
    with pytest.raises(AdapterError, match="mapping"):
        load_script(tmp_path / "list.yaml")
    (tmp_path / "bad.json").write_text("{nope")
    with pytest.raises(AdapterError, match="not valid JSON"):
        load_script(tmp_path / "bad.json")
    (tmp_path / "bad.yaml").write_text("a: [unclosed\n")
    with pytest.raises(AdapterError, match="not valid YAML"):
        load_script(tmp_path / "bad.yaml")
    (tmp_path / "ok.json").write_text('{"default": "hi"}')
    assert ScriptedAgent(load_script(tmp_path / "ok.json")).reply([]).text == "hi"


def test_demo_scripts_load():
    for name in ("good", "bad"):
        assert ScriptedAgent(demo_script(name)).rules
    with pytest.raises(AdapterError, match="Unknown demo"):
        demo_script("ugly")


# ---------------------------------------------------------------- Vapi / Retell


def test_import_vapi(fixtures):
    cfg = load_platform_config(fixtures / "vapi_assistant.json", "vapi")
    assert cfg.platform == "vapi" and cfg.name == "Smile Dental Receptionist"
    assert cfg.system_prompt.startswith("You are Riley")
    assert cfg.first_message.startswith("Hi, thanks for calling")
    assert cfg.model == "gpt-4o" and cfg.provider == "openai" and cfg.platform_provider == "openai"
    assert cfg.end_call_phrases == ["have a wonderful day", "goodbye for now"]
    assert any("Tools" in n for n in cfg.notes)


def test_import_vapi_legacy_and_unsupported_provider(fixtures):
    cfg = load_platform_config(fixtures / "vapi_legacy.json", "vapi")
    assert cfg.system_prompt == "You are an old-style receptionist."
    assert cfg.provider is None and cfg.platform_provider == "groq"
    assert any("not supported" in n for n in cfg.notes)
    assert cfg.first_message is None
    top = import_vapi({"systemPrompt": "top-level prompt", "model": "gpt-4o"})
    assert top.system_prompt == "top-level prompt" and top.model == "gpt-4o"


@pytest.mark.parametrize("data", [[], {"name": "x"}, {"model": {"messages": [{"role": "user", "content": "hi"}]}}])
def test_import_vapi_errors(data):
    with pytest.raises(AdapterError):
        import_vapi(data)


def test_import_retell_agent_export(fixtures):
    cfg = load_platform_config(fixtures / "retell_agent.json", "retell")
    assert cfg.platform == "retell" and cfg.name == "Valley Comfort Dispatcher"
    assert cfg.system_prompt == "You are the dispatcher for Valley Comfort Heating & Air."
    assert cfg.first_message == "Valley Comfort, how can I help you today?"
    assert cfg.model == "gpt-4o-mini" and cfg.provider == "openai"


def test_import_retell_llm_with_states(fixtures):
    cfg = load_platform_config(fixtures / "retell_llm.json", "retell")
    assert cfg.name == "Retell agent"
    assert "Carter & Reyes" in cfg.system_prompt and "## State: intake" in cfg.system_prompt
    assert cfg.provider == "anthropic" and cfg.model == "claude-3.5-sonnet"
    assert cfg.notes


@pytest.mark.parametrize("data", [[], {"agent_name": "x"}, {"general_prompt": "  "},
                                  {"response_engine": {"type": "retell-llm"}}])
def test_import_retell_errors(data):
    with pytest.raises(AdapterError):
        import_retell(data)


def test_load_platform_config_unknown(fixtures):
    with pytest.raises(AdapterError, match="Unknown platform"):
        load_platform_config(fixtures / "vapi_assistant.json", "bland")
    assert import_retell({"general_prompt": "p", "model": "mystery-1"}).provider is None
