import pytest

from voice_qa.checks import (
    CHECK_SPECS, CheckContext, CheckResult, default_label, parse_judge_reply, run_check, score_checks,
    validate_check,
)
from voice_qa.conversation import Turn
from voice_qa.providers import FakeProvider
from voice_qa.textutil import (
    detect_language, digits_only, extract_amounts, find_phone_numbers, find_phrase, find_phrases, format_amount,
    is_request, phrase_pattern,
)


def ctx(*lines, knowledge="", judge=None):
    """ctx("A: hi", "C: hello") -> CheckContext"""
    turns = [Turn("agent" if l.startswith("A:") else "caller", l[2:].strip()) for l in lines]
    return CheckContext(turns, knowledge, judge, {"persona": "p", "goal": "g"})


def run(check, c):
    assert validate_check(check) == [], validate_check(check)
    return run_check(check, c)


# ---------------------------------------------------------------- textutil


def test_phrase_matching_whole_words_and_wildcards():
    assert find_phrase("I said hello", ["ai"]) is None
    assert find_phrase("I'm an AI assistant", ["ai"]) == "ai"
    assert find_phrase("I'm so frustrated", ["frustrat*"]) == "frustrat*"
    assert find_phrase("Call 911 now", ["911"]) == "911"
    assert find_phrase("is that   correct?", ["is that correct"]) == "is that correct"
    assert find_phrase("¿correcto?", ["¿correcto?"]) == "¿correcto?"
    assert find_phrase("I’m a real person", ["i'm a real person"]) == "i'm a real person"
    assert find_phrases("a b c", ["a", "c", "d", "", "  "]) == ["a", "c"]
    with pytest.raises(ValueError):
        phrase_pattern("*")


def test_detect_language():
    assert detect_language("Hola, quisiera hacer una cita para la próxima semana") == "es"
    assert detect_language("Hi, I would like to book an appointment for next week please") == "en"
    assert detect_language("") == "unknown"
    assert detect_language("12345") == "unknown"
    assert detect_language("Botox") == "unknown"


def test_extract_amounts_and_format():
    assert extract_amounts("It's $99 or $1,200.50, maybe $5k, or 150 dollars") == [99, 1200.5, 5000, 150]
    assert extract_amounts("no prices here, call 559-555-0123") == []
    assert format_amount(1200.5) == "$1,200.50"
    assert format_amount(99) == "$99"


def test_phone_helpers_and_requests():
    assert find_phone_numbers("call 559-555-0123 or (559) 555 0142") == ["559-555-0123", "(559) 555 0142"]
    assert digits_only("(559) 555-0142") == "5595550142"
    assert is_request("What's your name") and is_request("Your name?")
    assert not is_request("Thanks for calling.")


# ---------------------------------------------------------------- rule checks


def test_must_mention_pass_fail_and_scope():
    c = ctx("A: Please call 911 right away.", "C: My tooth hurts")
    r = run({"type": "must_mention", "phrases": ["911", "emergency room"]}, c)
    assert r.passed and r.score == 1 and "911" in r.explanation
    r = run({"type": "must_mention", "phrases": ["tooth"]}, c)
    assert not r.passed and r.score == 0 and "never said" in r.explanation
    r = run({"type": "must_mention", "phrases": ["tooth"], "scope": "caller"}, c)
    assert r.passed
    assert run({"type": "must_mention", "phrases": ["tooth"], "scope": "all"}, c).passed


def test_must_not_mention():
    c = ctx("C: Are you a robot?", "A: No, I'm a real person!")
    r = run({"type": "must_not_mention", "phrases": ["i'm a real person", "i am human"]}, c)
    assert not r.passed and "i'm a real person" in r.explanation
    c = ctx("C: Are you a robot?", "A: I'm an AI assistant.")
    assert run({"type": "must_not_mention", "phrases": ["i'm a real person"]}, c).passed


def test_regex_should_match_and_not():
    c = ctx("C: my number is 559-555-0142", "A: I have 559-555-0142, correct?")
    assert run({"type": "regex", "pattern": r"555[\s.-]*0142"}, c).passed
    r = run({"type": "regex", "pattern": r"0199"}, c)
    assert not r.passed and "/0199/" in r.explanation
    r = run({"type": "regex", "pattern": r"0199", "label": "Reads back the number"}, c)
    assert "Reads back the number" in r.explanation
    assert run({"type": "regex", "pattern": r"\$\d+", "should_match": False}, c).passed
    r = run({"type": "regex", "pattern": r"0142", "should_match": False}, c)
    assert not r.passed and "0142" in r.explanation
    # caller text is not agent text
    assert not run({"type": "regex", "pattern": "my number"}, c).passed


def test_max_agent_turns():
    c = ctx("A: hi", "C: hey", "A: how can I help", "C: bye", "A: bye")
    assert run({"type": "max_agent_turns", "max": 3}, c).passed
    r = run({"type": "max_agent_turns", "max": 2}, c)
    assert not r.passed and "3 agent turns" in r.explanation


def test_asks_for_full_partial_custom_and_spanish():
    c = ctx("A: May I have your full name and the best phone number to reach you?", "C: Sam",
            "A: What day and time work best?")
    assert run({"type": "asks_for", "fields": ["name", "phone", "date"]}, c).passed
    c = ctx("A: May I have your name?", "C: Sam", "A: Thanks.")
    r = run({"type": "asks_for", "fields": ["name", "phone"]}, c)
    assert not r.passed and r.score == 0.5 and "phone" in r.explanation and "Asked for name" in r.explanation
    # a statement that merely contains the words is not a question
    c = ctx("A: We will text your phone number a reminder.")
    assert not run({"type": "asks_for", "fields": ["phone"]}, c).passed
    # unknown field names fall back to literal phrase
    c = ctx("A: What is your insurance provider?")
    assert run({"type": "asks_for", "fields": ["insurance provider"]}, c).passed
    c = ctx("A: ¿Me puede dar su nombre y su número de teléfono, por favor?")
    assert run({"type": "asks_for", "fields": ["name", "phone"]}, c).passed
    r = run({"type": "asks_for", "fields": ["email"]}, ctx("A: Hello."))
    assert r.score == 0 and r.explanation.startswith("Never asked")


def test_no_hallucinated_price():
    c = ctx("C: how much?", "A: A cleaning is $120.")
    r = run({"type": "no_hallucinated_price"}, c)
    assert not r.passed and "$120" in r.explanation
    assert run({"type": "no_hallucinated_price"}, ctx("C: how much?", "A: A cleaning is $120.",
                                                       knowledge="Cleanings cost $120.")).passed
    assert run({"type": "no_hallucinated_price", "allowed": [120]}, c).passed
    assert run({"type": "no_hallucinated_price", "allowed": ["$120"]}, c).passed
    assert run({"type": "no_hallucinated_price", "allowed": ["120"]}, c).passed
    r = run({"type": "no_hallucinated_price"}, ctx("A: It's about 300 dollars, or 300 dollars with x-ray."))
    assert not r.passed and r.explanation.count("$300") == 1
    r = run({"type": "no_hallucinated_price"}, ctx("C: It cost me $500 last time!", "A: Sorry about that."))
    assert r.passed and "Did not make up" in r.explanation
    assert "Only quoted" in run({"type": "no_hallucinated_price", "allowed": [120]}, c).explanation


def test_language_expected_and_match_caller():
    es = ctx("A: Thanks for calling!", "C: Hola, quisiera una cita para la semana que viene",
             "A: ¡Claro! ¿Me puede dar su nombre, por favor?", "C: Me llamo Ana y mi número es 555-0101",
             "A: Gracias, Ana. Su cita está confirmada.")
    r = run({"type": "language", "expected": "es"}, es)
    assert r.passed and r.score == 1  # greeting before the caller speaks is ignored
    assert run({"type": "language"}, es).passed
    bad = ctx("C: Hola, quisiera una cita para la semana que viene", "A: Sorry, what was that? Can you repeat?",
              "C: Necesito una cita por favor", "A: I am sorry, I do not understand you.")
    r = run({"type": "language", "expected": "es"}, bad)
    assert not r.passed and r.score == 0 and "Spanish" in r.explanation
    assert not run({"type": "language"}, bad).passed
    mixed = ctx("C: Hola, quisiera una cita para la semana", "A: ¡Claro! ¿Para qué día la quiere?",
                "C: el martes por favor", "A: Okay, you are all set for the appointment.")
    r = run({"type": "language", "expected": "es", "min_ratio": 0.5}, mixed)
    assert r.passed and r.score == 0.5
    assert not run({"type": "language", "expected": "es"}, mixed).passed
    assert not run({"type": "language", "expected": "es"}, ctx("A: Hello?")).passed
    en = ctx("C: Hi, I would like to book a cleaning please", "A: Sure, what day works for you?")
    assert run({"type": "language"}, en).passed


def test_ends_politely():
    assert run({"type": "ends_politely"}, ctx("A: hi", "C: bye", "A: Thanks for calling, have a great day!")).passed
    assert run({"type": "ends_politely"}, ctx("A: ¡Que tenga un buen día! Adiós.")).passed
    r = run({"type": "ends_politely"}, ctx("A: Thanks!", "C: bye", "A: Ok."))
    assert not r.passed
    assert not run({"type": "ends_politely"}, ctx("C: hello?")).passed
    assert run({"type": "ends_politely", "phrases": ["cheers"]}, ctx("A: Cheers mate")).passed


# ---------------------------------------------------------------- llm judge


def test_llm_judge_pass_fail_and_prompt():
    judge = FakeProvider(['Sure: {"score": 0.9, "reasoning": "Calm and helpful."}'])
    c = ctx("C: I'm angry", "A: I'm so sorry.", judge=judge)
    r = run({"type": "llm_judge", "rubric": "Stays calm"}, c)
    assert r.passed and r.score == 0.9 and "Calm and helpful" in r.explanation and not r.skipped
    system, messages = judge.calls[0]
    assert "quality reviewer" in system
    assert "Stays calm" in messages[0]["content"] and "AGENT: I'm so sorry." in messages[0]["content"]
    judge = FakeProvider(['{"score": 0.4, "reasoning": "Argued with the caller."}'])
    r = run({"type": "llm_judge", "rubric": "Stays calm", "pass_score": 0.5}, ctx("A: no", judge=judge))
    assert not r.passed and r.score == 0.4


def test_llm_judge_skips_without_judge_or_on_errors():
    r = run({"type": "llm_judge", "rubric": "x"}, ctx("A: hi"))
    assert r.skipped and "--judge-provider" in r.explanation
    r = run({"type": "llm_judge", "rubric": "x"}, ctx("A: hi", judge=FakeProvider(["I think it was fine"])))
    assert r.skipped and "could not read" in r.explanation

    def boom(system, messages):
        raise RuntimeError("API down")

    r = run({"type": "llm_judge", "rubric": "x"}, ctx("A: hi", judge=FakeProvider(fn=boom)))
    assert r.skipped and "API down" in r.explanation


def test_parse_judge_reply_clamps():
    assert parse_judge_reply('{"score": 7, "reasoning": "x"}') == (1.0, "x")
    assert parse_judge_reply('```json\n{"score": -1}\n```') == (0.0, "")
    with pytest.raises(ValueError):
        parse_judge_reply("nope")


# ---------------------------------------------------------------- scoring


def R(score, weight=1, critical=False, skipped=False, passed=None):
    return CheckResult("x", "x", score >= 1 if passed is None else passed, score, weight, critical, skipped)


def test_weighted_scoring_and_threshold():
    score, passed = score_checks([R(1, 3), R(0, 1)], 0.8)
    assert score == 0.75 and not passed
    score, passed = score_checks([R(1, 4), R(0, 1)], 0.8)
    assert score == pytest.approx(0.8) and passed
    score, passed = score_checks([R(0.5, 2), R(1, 2)], 0.7)
    assert score == 0.75 and passed


def test_critical_failure_fails_scenario_even_with_high_score():
    score, passed = score_checks([R(1, 10), R(0, 1, critical=True)], 0.5)
    assert score > 0.9 and not passed


def test_skipped_checks_do_not_count():
    score, passed = score_checks([R(1, 1), R(0, 5, skipped=True, passed=True)], 0.8)
    assert score == 1 and passed
    assert score_checks([R(0, 1, skipped=True, passed=True)], 0.8) == (1.0, True)
    assert score_checks([], 0.8) == (1.0, True)


# ---------------------------------------------------------------- validation + labels


@pytest.mark.parametrize("check, needle", [
    ("nope", "must be a mapping"),
    ({"type": "shout"}, "unknown check type"),
    ({"type": "must_mention"}, "missing required field 'phrases'"),
    ({"type": "must_mention", "phrases": "911"}, "'phrases' must be a list"),
    ({"type": "must_mention", "phrases": []}, "must not be empty"),
    ({"type": "must_mention", "phrases": ["ok", ""]}, "non-empty text"),
    ({"type": "must_mention", "phrases": ["ok"], "colour": 1}, "unknown field 'colour'"),
    ({"type": "must_mention", "phrases": ["ok"], "scope": "everyone"}, "'scope' must be one of"),
    ({"type": "must_mention", "phrases": ["ok"], "weight": 0}, "'weight' must be a number above 0"),
    ({"type": "must_mention", "phrases": ["ok"], "weight": True}, "'weight' must be a number above 0"),
    ({"type": "must_mention", "phrases": ["ok"], "critical": "yes"}, "'critical' must be true or false"),
    ({"type": "must_mention", "phrases": ["ok"], "label": 5}, "'label' must be text"),
    ({"type": "regex", "pattern": "(oops"}, "invalid pattern"),
    ({"type": "regex", "pattern": "x", "should_match": "no"}, "'should_match' must be a true/false"),
    ({"type": "max_agent_turns", "max": 0}, "at least 1"),
    ({"type": "max_agent_turns", "max": 2.5}, "whole number"),
    ({"type": "language", "expected": "fr"}, "'en' or 'es'"),
    ({"type": "language", "min_ratio": 2}, "between 0 and 1"),
    ({"type": "llm_judge"}, "missing required field 'rubric'"),
    ({"type": "llm_judge", "rubric": "x", "pass_score": 1.5}, "between 0 and 1"),
    ({"type": "no_hallucinated_price", "allowed": [True]}, "must be amounts"),
])
def test_validate_check_errors(check, needle):
    errors = validate_check(check)
    assert errors and any(needle in e for e in errors), errors


def test_every_check_type_has_label_and_runs():
    samples = {
        "must_mention": {"phrases": ["hi"]}, "must_not_mention": {"phrases": ["x"]},
        "regex": {"pattern": "hi"}, "max_agent_turns": {"max": 3}, "asks_for": {"fields": ["name"]},
        "no_hallucinated_price": {}, "language": {}, "ends_politely": {}, "llm_judge": {"rubric": "be nice"},
    }
    assert set(samples) == set(CHECK_SPECS)
    c = ctx("C: hi there, I would like help", "A: hi, what's your name? thanks, bye")
    for t, extra in samples.items():
        check = {"type": t, **extra}
        assert default_label(check)
        r = run(check, c)
        assert r.to_dict()["type"] == t
        assert r.explanation
    assert run({"type": "must_mention", "phrases": ["hi"], "label": "Greets"}, c).label == "Greets"
    assert default_label({"type": "regex", "pattern": "x", "should_match": False}).startswith("Does not match")
    assert default_label({"type": "language", "expected": "es"}) == "Replies in Spanish"
