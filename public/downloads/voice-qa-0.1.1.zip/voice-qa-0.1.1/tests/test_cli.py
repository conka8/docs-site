import io
import json
import os
import subprocess
import sys
import xml.etree.ElementTree as ET
from pathlib import Path

import pytest
from conftest import FakeTransport, anthropic_reply, openai_reply

from voice_qa.cli import main
from voice_qa.transport import HttpResponse

ROOT = Path(__file__).resolve().parents[1]


def run_cli(args, env=None, transport=None, sleep=None):
    out, err = io.StringIO(), io.StringIO()
    code = main(args, env=env if env is not None else {}, transport=transport, sleep=sleep or (lambda s: None),
                stdout=out, stderr=err)
    return code, out.getvalue(), err.getvalue()


def test_packs_command():
    code, out, _ = run_cli(["packs"])
    assert code == 0
    for name in ("dental", "hvac", "law-firm", "restaurant", "med-spa", "real-estate"):
        assert name in out


def test_validate_pack_ok_and_bad(fixtures):
    code, out, _ = run_cli(["validate-pack", str(fixtures / "mini_pack.yaml")])
    assert code == 0 and "OK" in out
    code, out, err = run_cli(["validate-pack", str(fixtures / "mini_pack.yaml"), str(fixtures / "bad_pack.yaml")])
    assert code == 1 and "problem(s)" in err and "duplicate id" in err
    code, _, err = run_cli(["validate-pack", "does-not-exist.yaml"])
    assert code == 1 and "File not found" in err


def test_validate_every_bundled_pack_via_cli():
    files = sorted(str(p) for p in (ROOT / "src" / "voice_qa" / "packs").glob("*.yaml"))
    assert len(files) == 6
    code, out, err = run_cli(["validate-pack", *files])
    assert code == 0, err
    assert out.count(": OK") == 6


def test_run_scripted_demo_writes_all_outputs(tmp_path):
    out_dir = tmp_path / "out"
    code, out, err = run_cli(["run", "--agent", "scripted", "--pack", "dental", "-o", str(out_dir),
                              "--business-name", "Smile Dental", "--brand-name", "Acme Agency",
                              "--fail-under", "90"])
    assert code == 0, err
    assert "Overall: 100% (grade A)" in out and "scorecard.html" in out
    results = json.loads((out_dir / "results.json").read_text())
    assert results["summary"]["passed"] == 10 and results["branding"]["brand_name"] == "Acme Agency"
    assert "Acme Agency" in (out_dir / "scorecard.html").read_text()
    ET.parse(out_dir / "junit.xml")


def test_run_bad_demo_fail_under_exit_code_and_compare(tmp_path):
    before = tmp_path / "before"
    code, out, err = run_cli(["run", "--agent", "scripted", "--demo", "bad", "--pack", "dental", "-o", str(before),
                              "--fail-under", "80"])
    assert code == 1 and "below --fail-under 80%" in err and "FAIL" in out
    # without --fail-under a low score is still exit 0
    code, _, _ = run_cli(["run", "--agent", "scripted", "--demo", "bad", "--pack", "dental", "-o",
                          str(tmp_path / "x")])
    assert code == 0
    after = tmp_path / "after"
    code, out, err = run_cli(["run", "--agent", "scripted", "--pack", "dental", "-o", str(after),
                              "--compare", str(before / "results.json")])
    assert code == 0, err
    assert "FIXED" in out and "Compared with previous run" in out
    assert "now handled correctly" in (after / "scorecard.html").read_text()


def test_run_with_scenario_filter_threshold_and_script_file(tmp_path, fixtures):
    code, out, err = run_cli(["run", "--agent", "scripted", "--script-file", str(fixtures / "http_script.yaml"),
                              "--pack", str(fixtures / "mini_pack.yaml"), "--scenario", "robot",
                              "--threshold", "50", "--max-turns", "2", "-o", str(tmp_path)])
    assert code == 0, err
    results = json.loads((tmp_path / "results.json").read_text())
    assert [s["id"] for s in results["scenarios"]] == ["robot"] and results["threshold"] == 0.5


def test_run_prompt_agent_with_fake_provider(tmp_path, fixtures):
    code, out, err = run_cli(["run", "--agent", "prompt", "--prompt-file", str(fixtures / "dental_prompt.txt"),
                              "--provider", "fake", "--pack", "dental", "--scenario", "are-you-a-robot",
                              "--judge-provider", "fake", "-o", str(tmp_path)])
    assert code == 0, err
    r = json.loads((tmp_path / "results.json").read_text())
    assert r["agent"]["kind"] == "prompt" and r["judge"].startswith("fake")
    assert r["scenarios"][0]["passed"]


def test_run_prompt_agent_openai_via_transport(tmp_path, fixtures):
    t = FakeTransport(openai_reply("I'm an AI assistant for Smile Dental. Thanks for calling, goodbye!"))
    code, out, err = run_cli(["run", "--agent", "prompt", "--prompt-file", str(fixtures / "dental_prompt.txt"),
                              "--provider", "openai", "--model", "gpt-test", "--pack", "dental",
                              "--scenario", "are-you-a-robot", "-o", str(tmp_path)],
                             env={"OPENAI_API_KEY": "sk-x"}, transport=t)
    assert code == 0, err
    assert len(t.requests) == 3
    body = t.requests[0].json()
    assert body["model"] == "gpt-test" and "Smile Dental in Fresno" in body["messages"][0]["content"]
    assert t.requests[0].headers["Authorization"] == "Bearer sk-x"


def test_run_prompt_agent_partial_failure_recorded(tmp_path, fixtures):
    t = FakeTransport(HttpResponse(500, "down"))
    code, out, err = run_cli(["run", "--agent", "prompt", "--prompt-file", str(fixtures / "dental_prompt.txt"),
                              "--pack", "dental", "--scenario", "emergency", "--scenario", "asks-price",
                              "-o", str(tmp_path), "--fail-under", "50"],
                             env={"ANTHROPIC_API_KEY": "a"}, transport=t)
    assert code == 1
    r = json.loads((tmp_path / "results.json").read_text())
    assert r["summary"]["errors"] == 2 and "ERROR" in out
    assert "2 test conversation(s) could not finish" in err
    assert all("anthropic request failed" in s["error"] for s in r["scenarios"])


def test_run_http_agent(tmp_path):
    t = FakeTransport({"data": {"reply": "I'm an AI virtual assistant. Have a great day!"}})
    code, out, err = run_cli(["run", "--agent", "http", "--url", "https://agent.test/hook",
                              "--reply-path", "data.reply", "--header", "Authorization: Bearer abc",
                              "--pack", "dental", "--scenario", "are-you-a-robot", "-o", str(tmp_path)],
                             transport=t)
    assert code == 0, err
    assert t.requests[0].headers["Authorization"] == "Bearer abc"
    assert t.requests[0].json()["messages"][0] == {"role": "user", "content": "Wait, am I talking to a real person or a robot?"}


def test_run_vapi_and_retell_config(tmp_path, fixtures):
    t = FakeTransport(openai_reply("I'm an AI assistant. Have a wonderful day!"))
    code, out, err = run_cli(["run", "--agent", "vapi-config", "--config-file", str(fixtures / "vapi_assistant.json"),
                              "--pack", "dental", "--scenario", "are-you-a-robot", "-o", str(tmp_path / "v")],
                             env={"OPENAI_API_KEY": "k"}, transport=t)
    assert code == 0, err
    assert "Using model 'gpt-4o'" in err
    first = t.requests[0].json()
    assert first["model"] == "gpt-4o" and first["messages"][0]["content"].startswith("You are Riley")
    r = json.loads((tmp_path / "v" / "results.json").read_text())
    sc = r["scenarios"][0]
    assert sc["transcript"][0]["text"].startswith("Hi, thanks for calling Smile Dental")
    assert sc["ended_by"] == "agent_ended"  # "have a wonderful day" is an endCallPhrase

    t = FakeTransport(anthropic_reply("I'm an AI assistant. Goodbye!"))
    code, out, err = run_cli(["run", "--agent", "retell-config", "--config-file", str(fixtures / "retell_agent.json"),
                              "--provider", "anthropic", "--pack", "hvac", "--scenario", "are-you-a-robot",
                              "-o", str(tmp_path / "r")], env={"ANTHROPIC_API_KEY": "k"}, transport=t)
    assert code == 0, err
    body = t.requests[0].json()
    assert body["model"] == "claude-sonnet-5-5"  # config model belongs to another vendor, so default is used
    assert body["system"].startswith("You are the dispatcher")


def test_run_llm_caller_fake(tmp_path):
    code, out, err = run_cli(["run", "--agent", "scripted", "--pack", "dental", "--caller", "llm",
                              "--caller-provider", "fake", "--scenario", "emergency", "-o", str(tmp_path)])
    assert code == 0, err
    r = json.loads((tmp_path / "results.json").read_text())
    assert r["scenarios"][0]["caller"] == "llm"


@pytest.mark.parametrize("args, env, needle", [
    (["run", "--agent", "scripted", "--pack", "plumbing"], {}, "No bundled pack"),
    (["run", "--agent", "prompt", "--pack", "dental"], {}, "needs --prompt-file"),
    (["run", "--agent", "prompt", "--prompt-file", "nope.txt", "--pack", "dental"], {}, "Prompt file not found"),
    (["run", "--agent", "http", "--pack", "dental"], {}, "needs --url"),
    (["run", "--agent", "http", "--url", "https://x.test", "--header", "bad", "--pack", "dental"], {}, "Name: value"),
    (["run", "--agent", "vapi-config", "--pack", "dental"], {}, "needs --config-file"),
    (["run", "--agent", "scripted", "--pack", "dental", "--threshold", "150"], {}, "between 0 and 100"),
    (["run", "--agent", "scripted", "--pack", "dental", "--max-turns", "0"], {}, "at least 1"),
    (["run", "--agent", "scripted", "--pack", "dental", "--scenario", "nope"], {}, "Unknown scenario"),
    (["run", "--agent", "scripted", "--pack", "dental", "--caller", "llm"], {}, "--caller-provider"),
    (["run", "--agent", "scripted", "--pack", "dental", "--compare", "missing.json"], {}, "not found"),
    (["run", "--agent", "scripted", "--pack", "dental", "--knowledge-file", "missing.txt"], {}, "not found"),
    (["run", "--agent", "scripted", "--pack", "dental", "--script-file", "missing.yaml"], {}, "not found"),
])
def test_run_errors_exit_2(args, env, needle, fixtures, tmp_path):
    code, out, err = run_cli(args + ["-o", str(tmp_path)], env=env)
    assert code == 2 and needle in err, err


def test_run_prompt_without_keys_exit_2(fixtures, tmp_path):
    code, _, err = run_cli(["run", "--agent", "prompt", "--prompt-file", str(fixtures / "dental_prompt.txt"),
                            "--pack", "dental", "-o", str(tmp_path)], env={})
    assert code == 2 and "No AI provider key found" in err
    code, _, err = run_cli(["run", "--agent", "scripted", "--pack", "dental", "--judge-provider", "openai",
                            "-o", str(tmp_path)], env={})
    assert code == 2 and "OPENAI_API_KEY" in err


def test_bad_pack_file_exit_2(fixtures, tmp_path):
    code, _, err = run_cli(["run", "--agent", "scripted", "--pack", str(fixtures / "bad_pack.yaml"),
                            "-o", str(tmp_path)])
    assert code == 2 and "duplicate id" in err


def test_knowledge_file_allows_prices(tmp_path):
    script = tmp_path / "s.yaml"
    script.write_text('default: "A crown is $950. Thanks for calling, goodbye!"\n')
    k = tmp_path / "k.txt"
    k.write_text("Crowns: $950\n")
    base = ["run", "--agent", "scripted", "--script-file", str(script), "--pack", "dental",
            "--scenario", "asks-price"]
    run_cli(base + ["-o", str(tmp_path / "a")])
    run_cli(base + ["--knowledge-file", str(k), "-o", str(tmp_path / "b")])
    a = json.loads((tmp_path / "a" / "results.json").read_text())["scenarios"][0]["checks"][0]
    b = json.loads((tmp_path / "b" / "results.json").read_text())["scenarios"][0]["checks"][0]
    assert a["type"] == "no_hallucinated_price" and not a["passed"] and b["passed"]


def test_report_command_formats(tmp_path):
    run_cli(["run", "--agent", "scripted", "--demo", "bad", "--pack", "hvac", "-o", str(tmp_path / "before")])
    run_cli(["run", "--agent", "scripted", "--pack", "hvac", "-o", str(tmp_path / "after")])
    res = str(tmp_path / "after" / "results.json")
    code, out, _ = run_cli(["report", res, "-o", str(tmp_path / "card.html"), "--brand-name", "Brandy",
                            "--brand-color", "#123456", "--logo-url", "https://l.test/x.png",
                            "--agency-contact", "call 555", "--compare", str(tmp_path / "before" / "results.json")])
    assert code == 0 and "Wrote html" in out
    html = (tmp_path / "card.html").read_text()
    assert "Brandy" in html and "#123456" in html and "call 555" in html and "now handled correctly" in html
    code, _, _ = run_cli(["report", res, "-o", str(tmp_path / "j.xml")])
    assert code == 0 and ET.parse(tmp_path / "j.xml").getroot().tag == "testsuites"
    code, _, _ = run_cli(["report", res, "-o", str(tmp_path / "copy.json"), "--compare",
                          str(tmp_path / "before" / "results.json")])
    data = json.loads((tmp_path / "copy.json").read_text())
    assert code == 0 and data["comparison"]["fixed"]
    code, _, _ = run_cli(["report", res, "-o", str(tmp_path / "card.txt"), "--format", "junit"])
    assert code == 0 and (tmp_path / "card.txt").read_text().startswith("<?xml")
    code, _, err = run_cli(["report", str(tmp_path / "nope.json"), "-o", str(tmp_path / "x.html")])
    assert code == 2 and "not found" in err


def test_usage_errors_help_and_version():
    assert run_cli([])[0] == 2
    assert run_cli(["run"])[0] == 2  # argparse: missing --agent/--pack
    assert run_cli(["run", "--agent", "carrier-pigeon", "--pack", "dental"])[0] == 2
    assert run_cli(["--help"])[0] == 0
    assert run_cli(["--version"])[0] == 0


def test_python_dash_m_entry_point():
    env = dict(os.environ, PYTHONPATH=str(ROOT / "src"))
    proc = subprocess.run([sys.executable, "-m", "voice_qa", "packs"], capture_output=True, text=True, env=env,
                          cwd=ROOT, timeout=60)
    assert proc.returncode == 0 and "dental" in proc.stdout


def test_run_webhook_errors_exit_1_without_fail_under(tmp_path):
    t = FakeTransport(HttpResponse(500, "Internal error. Authorization: Bearer secret-token-123"))
    code, out, err = run_cli(["run", "--agent", "http", "--url", "https://agent.test/hook", "--pack", "dental",
                              "--scenario", "are-you-a-robot", "-o", str(tmp_path)], transport=t)
    assert code == 1
    assert "ERROR" in out and "could not finish" in err
    r = json.loads((tmp_path / "results.json").read_text())
    assert r["summary"]["errors"] == 1 and r["demo"] is False
    assert "secret-token-123" not in (tmp_path / "scorecard.html").read_text()
    assert "secret-token-123" not in (tmp_path / "results.json").read_text()


def test_run_business_name_defaults(tmp_path):
    t = FakeTransport({"reply": "I'm an AI assistant. Have a great day!"})
    code, out, err = run_cli(["run", "--agent", "http", "--url", "https://agent.test/hook", "--pack", "dental",
                              "--scenario", "are-you-a-robot", "-o", str(tmp_path / "real")], transport=t)
    assert code == 0, err
    r = json.loads((tmp_path / "real" / "results.json").read_text())
    assert r["business_name"] == "your business" and "Smile Dental" not in out
    assert "No --business-name given" in err
    # demo agents keep the pack's example name
    code, out, err = run_cli(["run", "--agent", "scripted", "--pack", "dental", "--scenario", "are-you-a-robot",
                              "-o", str(tmp_path / "demo")])
    assert code == 0, err
    r = json.loads((tmp_path / "demo" / "results.json").read_text())
    assert r["business_name"] == "Smile Dental" and r["demo"] is True
    assert out.startswith("Demo data:") and "Demo data:" in (tmp_path / "demo" / "scorecard.html").read_text()


def test_run_fake_provider_is_demo(tmp_path, fixtures):
    code, out, err = run_cli(["run", "--agent", "prompt", "--prompt-file", str(fixtures / "dental_prompt.txt"),
                              "--provider", "fake", "--pack", "dental", "--scenario", "are-you-a-robot",
                              "-o", str(tmp_path)])
    assert code == 0, err
    r = json.loads((tmp_path / "results.json").read_text())
    assert r["demo"] is True and r["business_name"] == "Smile Dental"


@pytest.mark.parametrize("which", ["prompt", "pack", "knowledge", "script", "results"])
def test_non_utf8_files_clean_error_exit_2(tmp_path, fixtures, which):
    bad = tmp_path / ("bad.json" if which == "results" else "bad.yaml" if which in ("pack", "script") else "bad.txt")
    bad.write_bytes(b"caf\xe9 \xff\xfe")
    base = ["run", "--pack", "dental", "-o", str(tmp_path / "o")]
    argv = {
        "prompt": base + ["--agent", "prompt", "--provider", "fake", "--prompt-file", str(bad)],
        "pack": ["run", "--agent", "scripted", "--pack", str(bad), "-o", str(tmp_path / "o")],
        "knowledge": base + ["--agent", "scripted", "--knowledge-file", str(bad)],
        "script": base + ["--agent", "scripted", "--script-file", str(bad)],
        "results": ["report", str(bad), "-o", str(tmp_path / "x.html")],
    }[which]
    code, out, err = run_cli(argv)
    assert code == 2
    assert "is not saved as UTF-8 text" in err and "Traceback" not in err
    if which == "pack":
        code, _, err = run_cli(["validate-pack", str(bad)])
        assert code == 1 and "UTF-8" in err
