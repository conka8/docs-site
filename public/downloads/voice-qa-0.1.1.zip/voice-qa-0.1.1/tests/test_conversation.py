from voice_qa.adapters import ScriptedAgent
from voice_qa.conversation import (
    AgentReply, LLMCaller, ScriptedCaller, Turn, simulate_call, strip_end_markers, to_messages,
)
from voice_qa.providers import FakeProvider


class EchoAgent:
    first_message = "Hi, this is the clinic."

    def __init__(self, end_on=None):
        self.end_on = end_on
        self.seen = []

    def reply(self, transcript):
        last = transcript[-1].text
        self.seen.append(last)
        return AgentReply(f"You said: {last}", end_call=self.end_on is not None and self.end_on in last)


def test_scripted_caller_runs_until_script_ends():
    conv = simulate_call(EchoAgent(), ScriptedCaller(["one", "two"]), max_turns=10, terminal_phrases=[])
    assert [t.role for t in conv.transcript] == ["agent", "caller", "agent", "caller", "agent"]
    assert conv.ended_by == "caller_done" and conv.error is None


def test_terminal_phrase_stops_after_agent_reply():
    agent = EchoAgent()
    conv = simulate_call(agent, ScriptedCaller(["hello", "ok thanks, bye!", "never said"]), max_turns=10)
    assert conv.ended_by == "caller_hung_up"
    assert conv.transcript[-1] == Turn("agent", "You said: ok thanks, bye!")
    assert "never said" not in agent.seen


def test_custom_terminal_phrase_and_end_marker():
    conv = simulate_call(EchoAgent(), ScriptedCaller(["hi", "I'm done here", "more"]), max_turns=10,
                         terminal_phrases=["i'm done"])
    assert conv.ended_by == "caller_hung_up" and len(conv.transcript) == 5
    conv = simulate_call(EchoAgent(), ScriptedCaller(["great, thanks [END]", "more"]), max_turns=10,
                         terminal_phrases=[])
    assert conv.ended_by == "caller_hung_up"
    assert conv.transcript[1].text == "great, thanks"  # marker stripped
    conv = simulate_call(EchoAgent(), ScriptedCaller(["[HANGUP]"]), max_turns=10)
    assert conv.ended_by == "caller_hung_up" and len(conv.transcript) == 1


def test_max_turns_limit():
    lines = [f"line {i}" for i in range(20)]
    conv = simulate_call(EchoAgent(), ScriptedCaller(lines), max_turns=3, terminal_phrases=[])
    assert conv.ended_by == "max_turns"
    assert sum(1 for t in conv.transcript if t.role == "caller") == 3


def test_agent_can_end_call():
    conv = simulate_call(EchoAgent(end_on="transfer"), ScriptedCaller(["hi", "transfer me", "hello?"]),
                         max_turns=10)
    assert conv.ended_by == "agent_ended" and conv.transcript[-1].text == "You said: transfer me"


def test_agent_error_is_captured():
    class Broken:
        first_message = None

        def reply(self, transcript):
            raise RuntimeError("webhook down")

    conv = simulate_call(Broken(), ScriptedCaller(["hi"]), max_turns=3)
    assert conv.ended_by == "error" and "webhook down" in conv.error
    assert conv.transcript == [Turn("caller", "hi")]


def test_llm_caller_gets_reversed_roles_and_persona():
    caller_llm = FakeProvider(["Hi, I need a cleaning.", "Thanks, goodbye [END]"])
    caller = LLMCaller(caller_llm, "Maria, busy mom", "Book a cleaning", "Smile Dental", hints=["say hi"])
    agent = ScriptedAgent({"first_message": "Smile Dental, how can I help?", "default": "Sure, what day?"})
    conv = simulate_call(agent, caller, max_turns=5)
    assert conv.ended_by == "caller_hung_up"
    assert [t.text for t in conv.transcript] == ["Smile Dental, how can I help?", "Hi, I need a cleaning.",
                                                 "Sure, what day?", "Thanks, goodbye", "Sure, what day?"]
    system, messages = caller_llm.calls[1]
    assert "Maria, busy mom" in system and "Book a cleaning" in system and "Smile Dental" in system
    assert "say hi" in system
    assert messages[0] == {"role": "user", "content": "Smile Dental, how can I help?"}
    assert messages[1] == {"role": "assistant", "content": "Hi, I need a cleaning."}


def test_llm_caller_empty_reply_ends_call():
    conv = simulate_call(EchoAgent(), LLMCaller(FakeProvider(["   "]), "p", "g"), max_turns=5)
    assert conv.ended_by == "caller_done"


def test_helpers():
    assert strip_end_markers("Bye [end] now [HANGUP]") == ("Bye  now", True)
    assert strip_end_markers("hello") == ("hello", False)
    msgs = to_messages([Turn("agent", "a"), Turn("caller", "c"), Turn("agent", "")], me="agent")
    assert msgs == [{"role": "assistant", "content": "a"}, {"role": "user", "content": "c"}]
    assert Turn.from_dict(Turn("caller", "x").to_dict()) == Turn("caller", "x")
