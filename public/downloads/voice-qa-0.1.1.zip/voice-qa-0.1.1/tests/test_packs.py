from pathlib import Path

import pytest

from voice_qa.packs import (
    PackError, bundled_pack_files, list_packs, load_bundled_pack, load_pack_file, pack_from_data, resolve_pack,
    to_fraction, validate_pack_data, validate_pack_file,
)

EXPECTED_PACKS = {"dental", "hvac", "law-firm", "restaurant", "med-spa", "real-estate"}
CORE_SCENARIOS = {"book-appointment", "angry-customer", "emergency", "asks-price", "wrong-number",
                  "spanish-speaker", "are-you-a-robot", "asks-for-advice", "prompt-injection",
                  "confirms-phone-number"}


def test_all_bundled_packs_exist():
    assert set(bundled_pack_files()) == EXPECTED_PACKS


@pytest.mark.parametrize("name", sorted(EXPECTED_PACKS))
def test_every_bundled_pack_validates(name):
    entry = bundled_pack_files()[name]
    errors = validate_pack_file(Path(str(entry)))
    assert errors == [], errors
    pack = load_bundled_pack(name)
    assert pack.name == name and pack.title and pack.default_business_name
    assert 8 <= len(pack.scenarios) <= 12
    ids = {s.id for s in pack.scenarios}
    assert CORE_SCENARIOS <= ids
    for sc in pack.scenarios:
        assert sc.caller_script, f"{name}/{sc.id} needs a caller_script for deterministic runs"
        assert sc.fix_hint, f"{name}/{sc.id} needs a fix_hint for the client report"
    # safety scenarios must have a critical check
    for sid in ("emergency", "are-you-a-robot", "prompt-injection", "asks-for-advice"):
        sc = next(s for s in pack.scenarios if s.id == sid)
        assert any(c.get("critical") for c in sc.checks), f"{name}/{sid}"


def test_list_packs_and_resolve():
    assert {p.name for p in list_packs()} == EXPECTED_PACKS
    assert resolve_pack("dental").name == "dental"


def test_load_pack_file_and_defaults(fixtures):
    pack = resolve_pack(str(fixtures / "mini_pack.yaml"))
    assert pack.name == "mini" and pack.default_business_name == "Test Clinic"
    assert pack.pass_threshold is None and pack.description == ""
    sc = pack.scenarios[1]
    assert sc.fix_hint == "Tell the agent to admit it is an AI." and sc.max_turns is None
    filled = pack.scenarios[0].filled("Acme & Co")
    assert filled.checks[0]["phrases"] == ["Acme & Co"]
    assert pack.scenarios[0].checks[0]["phrases"] == ["{business_name}"]  # original untouched
    assert filled.to_dict()["id"] == "greet"


def test_validation_reports_every_problem(fixtures):
    errors = validate_pack_file(fixtures / "bad_pack.yaml")
    text = "\n".join(errors)
    for needle in [
        "'title' is required",
        "'id' may only use lowercase",
        "unknown field 'colour'",
        "'caller_script' must be a non-empty list",
        "missing required field 'phrases'",
        "unknown check type 'shout_loudly'",
        "invalid pattern",
        "'phrases' must not be empty",
        "'weight' must be a number above 0",
        "'checks' must be a non-empty list",
        "duplicate id",
        "'max_turns' must be a whole number",
        "'expected' must be 'en' or 'es'",
        "'max' must be at least 1",
        "'pass_score' must be between 0 and 1",
    ]:
        assert needle in text, f"missing: {needle}\n{text}"
    with pytest.raises(PackError) as e:
        load_pack_file(fixtures / "bad_pack.yaml")
    assert len(e.value.errors) == len(errors)


def test_yaml_syntax_and_missing_file(fixtures, tmp_path):
    errors = validate_pack_file(fixtures / "broken_yaml.yaml")
    assert errors and "YAML" in errors[0]
    assert validate_pack_file(tmp_path / "nope.yaml") == [f"File not found: {tmp_path / 'nope.yaml'}"]
    with pytest.raises(PackError, match="not found"):
        load_pack_file(tmp_path / "nope.yaml")
    with pytest.raises(PackError, match="not valid YAML"):
        load_pack_file(fixtures / "broken_yaml.yaml")


def test_json_pack(tmp_path):
    p = tmp_path / "p.json"
    p.write_text('{"name": "j", "title": "J", "scenarios": [{"id": "a", "title": "A", "persona": "p", '
                 '"goal": "g", "pass_threshold": 90, "checks": [{"type": "ends_politely"}]}]}')
    pack = resolve_pack(str(p))
    assert pack.scenarios[0].pass_threshold == 0.9
    p.write_text("{bad json")
    assert "not valid JSON" in validate_pack_file(p)[0]


@pytest.mark.parametrize("data, needle", [
    ([], "must be a mapping"),
    ({"title": "t", "scenarios": []}, "'name' is required"),
    ({"name": "n", "title": "t"}, "'scenarios' must be a non-empty list"),
    ({"name": "n", "title": "t", "extra": 1, "scenarios": [1]}, "unknown field 'extra'"),
    ({"name": "n", "title": "t", "scenarios": ["x"]}, "must be a mapping"),
    ({"name": "n", "title": "t", "pass_threshold": 0, "scenarios": [{}]}, "'pass_threshold' must be a number"),
    ({"name": "n", "title": "t", "industry": 3, "scenarios": [{}]}, "'industry' must be text"),
    ({"name": "n", "title": "t", "scenarios": [{"title": "x"}]}, "'id' is required"),
    ({"name": "n", "title": "t", "scenarios": [{"id": "a", "title": "x", "persona": "p", "goal": "g",
                                                 "caller_script": ["ok", ""], "checks": [{"type": "ends_politely"}]}]},
     "every 'caller_script' line"),
    ({"name": "n", "title": "t", "scenarios": [{"id": "a", "title": "x", "persona": "p", "goal": "g",
                                                 "tags": "x", "fix_hint": 3, "pass_threshold": "high",
                                                 "checks": [{"type": "ends_politely"}]}]},
     "'tags' must be a list of text"),
])
def test_validate_pack_data_cases(data, needle):
    errors = validate_pack_data(data)
    assert any(needle in e for e in errors), errors


def test_unknown_bundled_pack():
    with pytest.raises(PackError, match="No bundled pack called 'plumbing'"):
        resolve_pack("plumbing")
    with pytest.raises(PackError):
        pack_from_data({"name": "x"})


def test_to_fraction():
    assert to_fraction(80) == 0.8 and to_fraction(0.75) == 0.75 and to_fraction(1) == 1.0
