import io
import json
import urllib.error

import pytest
from conftest import FakeTransport, anthropic_reply, openai_reply

from voice_qa import constants as C
from voice_qa import transport as T
from voice_qa.providers import (
    AnthropicProvider, FakeProvider, OpenAIProvider, ProviderError, create_provider, default_provider_name,
    merge_roles,
)
from voice_qa.transport import HttpError, HttpRequest, HttpResponse, TransportError, post_json

MSGS = [{"role": "assistant", "content": "Thanks for calling!"}, {"role": "user", "content": "Hi, book me in"}]


# ---------------------------------------------------------------- OpenAI


def test_openai_request_shape_and_parse(sleeper):
    t = FakeTransport(openai_reply("  Sure, what's your name?  "))
    p = OpenAIProvider("sk-test", "gpt-test", transport=t, sleep=sleeper)
    assert p.complete("You are a receptionist", MSGS) == "Sure, what's your name?"
    req = t.requests[0]
    assert req.method == "POST" and req.url == C.OPENAI_CHAT_URL
    assert req.headers["Authorization"] == "Bearer sk-test"
    assert req.headers["Content-Type"] == "application/json"
    body = req.json()
    assert body["model"] == "gpt-test"
    assert body["messages"][0] == {"role": "system", "content": "You are a receptionist"}
    assert body["messages"][1:] == MSGS
    assert req.timeout == C.HTTP_TIMEOUT_SECONDS
    assert sleeper.calls == []


def test_openai_custom_base_url_default_model_and_content_parts():
    t = FakeTransport({"choices": [{"message": {"content": [{"type": "text", "text": "a"}, {"text": "b"}]}}]})
    p = OpenAIProvider("k", None, base_url="http://localhost:1234/v1/chat/completions", transport=t)
    assert p.model == C.DEFAULT_OPENAI_MODEL
    assert p.complete("", MSGS) == "ab"
    assert t.requests[0].url.startswith("http://localhost:1234")
    assert t.requests[0].json()["messages"][0]["role"] == "assistant"  # no empty system message


def test_openai_unexpected_shape():
    p = OpenAIProvider("k", transport=FakeTransport({"error": "weird"}))
    with pytest.raises(ProviderError, match="unexpected response"):
        p.complete("s", MSGS)


def test_missing_key_rejected():
    with pytest.raises(ProviderError, match="missing API key"):
        OpenAIProvider("")


# ---------------------------------------------------------------- Anthropic


def test_anthropic_request_shape_and_parse():
    t = FakeTransport({"content": [{"type": "text", "text": "Hello "}, {"type": "tool_use", "id": "x"},
                                   {"type": "text", "text": "there"}]})
    p = AnthropicProvider("ak-test", transport=t)
    assert p.model == "claude-sonnet-5-5"
    assert p.complete("SYSTEM", MSGS) == "Hello there"
    req = t.requests[0]
    assert req.url == C.ANTHROPIC_MESSAGES_URL
    assert req.headers["x-api-key"] == "ak-test"
    assert req.headers["anthropic-version"] == C.ANTHROPIC_VERSION
    assert "Authorization" not in req.headers
    body = req.json()
    assert body["system"] == "SYSTEM"
    assert body["model"] == "claude-sonnet-5-5"
    assert body["max_tokens"] > 0
    # conversation must start with a user turn
    assert body["messages"][0] == {"role": "user", "content": C.ANTHROPIC_CALL_CONNECTED_PLACEHOLDER}
    assert body["messages"][1]["role"] == "assistant"


def test_anthropic_empty_conversation_and_no_system():
    t = FakeTransport(anthropic_reply("Hi"))
    AnthropicProvider("k", "claude-x", transport=t).complete("", [])
    body = t.requests[0].json()
    assert "system" not in body and body["messages"][0]["role"] == "user" and body["model"] == "claude-x"


def test_anthropic_bad_shape():
    with pytest.raises(ProviderError, match="unexpected response"):
        AnthropicProvider("k", transport=FakeTransport({"type": "error"})).complete("s", MSGS)


def test_merge_roles():
    merged = merge_roles([{"role": "user", "content": "a"}, {"role": "user", "content": "b"},
                          {"role": "assistant", "content": " "}, {"role": "assistant", "content": "c"}])
    assert merged == [{"role": "user", "content": "a\nb"}, {"role": "assistant", "content": "c"}]


# ---------------------------------------------------------------- retries / errors


def test_retry_on_429_then_success(sleeper):
    t = FakeTransport(HttpResponse(429, "slow down", {"Retry-After": "3"}), HttpResponse(503, "busy"),
                      openai_reply("ok"))
    p = OpenAIProvider("k", transport=t, sleep=sleeper)
    assert p.complete("s", MSGS) == "ok"
    assert len(t.requests) == 3
    assert sleeper.calls == [3.0, C.HTTP_BACKOFF_SECONDS * 2]


def test_retry_exhausted_on_5xx(sleeper):
    t = FakeTransport(HttpResponse(500, "boom"))
    with pytest.raises(ProviderError, match="failed after 3 attempts"):
        AnthropicProvider("k", transport=t, sleep=sleeper).complete("s", MSGS)
    assert len(t.requests) == 3 and len(sleeper.calls) == 2


def test_no_retry_on_400(sleeper):
    t = FakeTransport(HttpResponse(401, '{"error": "bad key"}'))
    with pytest.raises(ProviderError, match="401"):
        OpenAIProvider("k", transport=t, sleep=sleeper).complete("s", MSGS)
    assert len(t.requests) == 1 and sleeper.calls == []


def test_timeout_is_retried_then_succeeds(sleeper):
    t = FakeTransport(TransportError("timed out"), openai_reply("finally"))
    assert OpenAIProvider("k", transport=t, sleep=sleeper).complete("s", MSGS) == "finally"
    assert sleeper.calls == [C.HTTP_BACKOFF_SECONDS]


def test_timeout_every_time(sleeper):
    t = FakeTransport(TransportError("timed out"))
    with pytest.raises(HttpError, match="timed out"):
        post_json("https://x.test", {}, transport=t, sleep=sleeper, retries=1)
    assert len(t.requests) == 2


def test_post_json_non_json_and_empty_body_and_bad_retry_after(sleeper):
    with pytest.raises(HttpError, match="did not return JSON"):
        post_json("https://x.test", {}, transport=FakeTransport(HttpResponse(200, "<html>")), sleep=sleeper)
    assert post_json("https://x.test", {}, transport=FakeTransport(HttpResponse(204, "")), sleep=sleeper) == {}
    t = FakeTransport(HttpResponse(429, "", {"retry-after": "soon"}), HttpResponse(200, "[1]"))
    assert post_json("https://x.test", {"a": 1}, transport=t, sleep=sleeper, timeout=5) == [1]
    assert sleeper.calls == [C.HTTP_BACKOFF_SECONDS]
    assert t.requests[0].timeout == 5 and json.loads(t.requests[0].body) == {"a": 1}


def test_urllib_transport_success_http_error_and_network_error(monkeypatch):
    class Resp:
        status = 200
        headers = {"Content-Type": "application/json"}

        def read(self):
            return b'{"ok": true}'

        def __enter__(self):
            return self

        def __exit__(self, *a):
            return False

    seen = {}

    def fake_urlopen(request, timeout):
        seen["url"], seen["timeout"], seen["data"] = request.full_url, timeout, request.data
        return Resp()

    monkeypatch.setattr(T.urllib.request, "urlopen", fake_urlopen)
    r = T.urllib_transport(HttpRequest("POST", "https://x.test/a", {"A": "b"}, b"{}", 7))
    assert r.status == 200 and r.body == '{"ok": true}' and seen["timeout"] == 7

    def http_error(request, timeout):
        raise urllib.error.HTTPError(request.full_url, 429, "Too Many", {"Retry-After": "1"}, io.BytesIO(b"later"))

    monkeypatch.setattr(T.urllib.request, "urlopen", http_error)
    r = T.urllib_transport(HttpRequest("POST", "https://x.test/a"))
    assert r.status == 429 and r.body == "later" and r.headers["Retry-After"] == "1"

    def net_error(request, timeout):
        raise urllib.error.URLError("timed out")

    monkeypatch.setattr(T.urllib.request, "urlopen", net_error)
    with pytest.raises(TransportError, match="timed out"):
        T.urllib_transport(HttpRequest("POST", "https://x.test/a"))

    def sock_timeout(request, timeout):
        raise TimeoutError("read timeout")

    monkeypatch.setattr(T.urllib.request, "urlopen", sock_timeout)
    with pytest.raises(TransportError):
        T.urllib_transport(HttpRequest("POST", "https://x.test/a"))


# ---------------------------------------------------------------- factory + fake


def test_create_provider_from_env():
    env = {"OPENAI_API_KEY": "o", "ANTHROPIC_API_KEY": "a"}
    assert default_provider_name(env) == "anthropic"
    assert default_provider_name({"OPENAI_API_KEY": "o"}) == "openai"
    assert default_provider_name({}) is None
    p = create_provider(None, env=env)
    assert isinstance(p, AnthropicProvider) and p.api_key == "a"
    p = create_provider("openai", "gpt-x", env=env, base_url="http://h/v1/chat/completions")
    assert isinstance(p, OpenAIProvider) and p.model == "gpt-x" and p.url.startswith("http://h")
    p = create_provider("openai", env={"MY_KEY": "m"}, api_key_env="MY_KEY")
    assert p.api_key == "m"
    assert "openai" in p.describe()


@pytest.mark.parametrize("name, env, msg", [
    (None, {}, "No AI provider key found"),
    ("openai", {}, "OPENAI_API_KEY"),
    ("anthropic", {}, "ANTHROPIC_API_KEY"),
    ("mistral", {"X": "1"}, "Unknown provider"),
])
def test_create_provider_errors(name, env, msg):
    with pytest.raises(ProviderError, match=msg):
        create_provider(name, env=env)


def test_fake_provider_roles_and_sequence():
    assert "AI assistant" in create_provider("fake", env={}, role="agent").complete("", [])
    assert "[END]" in create_provider("fake", env={}, role="caller").complete("", [])
    assert '"score"' in create_provider("fake", env={}, role="judge").complete("", [])
    f = FakeProvider(["one", "two"])
    assert [f.complete("s", []) for _ in range(3)] == ["one", "two", "two"]
    assert len(f.calls) == 3 and f.describe() == "fake (fake-model)"
    assert FakeProvider(fn=lambda s, m: s.upper()).complete("hey", []) == "HEY"


def test_error_body_is_cut_and_secrets_hidden(sleeper):
    body = ('{"error": "bad auth", "echo": "Authorization: Bearer abc.def-123", "key": "sk-live_ABCDEFGHIJKLMNOP", '
            '"api_key": "pk_123456"}' + " filler" * 100)
    with pytest.raises(HttpError) as e:
        post_json("https://x.test", {}, transport=FakeTransport(HttpResponse(400, body)), sleep=sleeper)
    msg = str(e.value)
    assert "bad auth" in msg and "[hidden]" in msg
    assert "abc.def-123" not in msg and "sk-live_ABCDEFGHIJKLMNOP" not in msg and "pk_123456" not in msg
    assert "filler filler" in msg and msg.endswith("...") and len(msg) < 300


def test_redact_secrets_helper():
    from voice_qa.textutil import redact_secrets

    assert redact_secrets("token Bearer xyz ok") == "token [hidden] ok"
    assert redact_secrets("API-KEY=abc123 rest") == "[hidden] rest"
    assert redact_secrets("short sk-1234") == "short sk-1234"  # too short to look like a key
    assert redact_secrets("x" * 250, limit=10) == "x" * 10 + "..."
