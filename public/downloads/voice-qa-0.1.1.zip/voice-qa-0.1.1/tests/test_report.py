import copy
import json
import xml.etree.ElementTree as ET

import pytest

from voice_qa.adapters import ScriptedAgent, demo_script
from voice_qa.packs import load_bundled_pack, resolve_pack
from voice_qa.report import (
    ReportError, compare_results, console_summary, load_results, safe_color, safe_url, to_html, to_json, to_junit,
    write_outputs,
)
from voice_qa.runner import run_pack

EVIL = "<script>alert('x')</script>"


@pytest.fixture(scope="module")
def good_results():
    pack = load_bundled_pack("dental")
    return run_pack(pack, ScriptedAgent(demo_script("good"), "Smile Dental"))


@pytest.fixture(scope="module")
def bad_results():
    pack = load_bundled_pack("dental")
    return run_pack(pack, ScriptedAgent(demo_script("bad"), "Smile Dental"),
                    branding={"brand_name": "Acme Voice Agency", "brand_color": "#ff6600",
                              "agency_contact": "hi@acme.test"})


def evil_results(fixtures):
    pack = resolve_pack(str(fixtures / "mini_pack.yaml"))
    agent = ScriptedAgent({"default": f"Hello {EVIL} bye"}, EVIL)
    return run_pack(pack, agent, business_name=EVIL,
                    branding={"brand_name": EVIL, "agency_contact": EVIL, "logo_url": "javascript:alert(1)",
                              "brand_color": "red;}</style><script>x()</script>"})


def test_html_escapes_everything(fixtures):
    html = to_html(evil_results(fixtures))
    assert "<script>" not in html
    assert "&lt;script&gt;" in html
    assert "javascript:" not in html
    assert "red;}" not in html and "--brand: #2563eb" in html


def test_html_contents_good(good_results):
    html = to_html(good_results)
    assert html.startswith("<!DOCTYPE html>")
    assert "Smile Dental" in html and ">A<" in html and "100%" in html
    assert "Nothing! Every test call passed." in html
    assert "first test run" in html  # no comparison yet
    assert "How this was measured" in html and good_results["generated_at"][:10] in html
    assert "@media print" in html and "<link" not in html and "<script" not in html
    assert html.count('class="call"') == good_results["summary"]["total"]


def test_html_branding_and_fix_section(bad_results):
    html = to_html(bad_results)
    assert "Acme Voice Agency" in html and "--brand: #ff6600" in html and "hi@acme.test" in html
    assert "What to fix" in html and "Suggested fix" in html and "911" in html
    assert 'class="pill fail"' in html
    # override branding at report time
    html2 = to_html(bad_results, branding={"brand_name": "Other Agency", "logo_url": "https://x.test/logo.png",
                                           "brand_color": "teal"})
    assert "Other Agency" in html2 and 'src="https://x.test/logo.png"' in html2 and "--brand: teal" in html2


def test_html_truncates_long_transcripts(good_results):
    r = copy.deepcopy(good_results)
    r["scenarios"][0]["transcript"] = [{"role": "caller", "text": "x" * 1000}] * 12
    html = to_html(r)
    assert "4 more line(s)" in html and "x" * 401 not in html


def test_safe_color_and_url():
    assert safe_color("#abc") == "#abc" and safe_color("navy") == "navy"
    assert safe_color("url(evil)") == "#2563eb" and safe_color(None) == "#2563eb"
    assert safe_url("https://a.test/l.png") and safe_url("data:image/png;base64,AAA")
    assert safe_url("javascript:x") is None and safe_url(None) is None


def test_junit_is_valid_xml(bad_results):
    xml = to_junit(bad_results)
    root = ET.fromstring(xml.encode("utf-8"))
    assert root.tag == "testsuites"
    suite = root.find("testsuite")
    cases = suite.findall("testcase")
    s = bad_results["summary"]
    assert len(cases) == s["total"] == int(suite.get("tests"))
    assert int(suite.get("failures")) == s["failed"] - s["errors"]
    failures = [c for c in cases if c.find("failure") is not None]
    assert len(failures) == s["failed"]
    emergency = next(c for c in cases if c.get("name").startswith("emergency:"))
    assert "911" in emergency.find("failure").get("message")
    assert "AGENT:" in emergency.find("system-out").text
    props = {p.get("name"): p.get("value") for p in suite.find("properties")}
    assert props["business_name"] == "Smile Dental" and props["grade"] == s["grade"]


def test_junit_with_errors_and_control_chars(fixtures):
    r = evil_results(fixtures)
    r["scenarios"][0]["transcript"].append({"role": "agent", "text": "bad\x00char\x1b"})
    r["scenarios"][1]["error"] = "agent down"
    r["summary"]["errors"] = 1
    r["summary"]["failed"] = max(r["summary"]["failed"], 1)
    r["scenarios"][1]["passed"] = False
    root = ET.fromstring(to_junit(r).encode("utf-8"))
    errs = root.findall(".//error")
    assert len(errs) == 1 and errs[0].get("message") == "agent down"
    assert root.get("errors") == "1"


def test_json_roundtrip(tmp_path, good_results):
    p = tmp_path / "r.json"
    p.write_text(to_json(good_results), encoding="utf-8")
    assert load_results(p) == json.loads(json.dumps(good_results))


def test_load_results_errors(tmp_path):
    with pytest.raises(ReportError, match="not found"):
        load_results(tmp_path / "missing.json")
    (tmp_path / "bad.json").write_text("{nope")
    with pytest.raises(ReportError, match="not valid JSON"):
        load_results(tmp_path / "bad.json")
    (tmp_path / "other.json").write_text('{"hello": 1}')
    with pytest.raises(ReportError, match="does not look like"):
        load_results(tmp_path / "other.json")


def test_compare_fixed_regressed_new_removed(good_results, bad_results):
    cmp = compare_results(good_results, bad_results)
    fixed = {r["id"] for r in cmp["fixed"]}
    assert {"emergency", "are-you-a-robot", "prompt-injection"} <= fixed
    assert cmp["regressed"] == [] and cmp["score_change"] > 0
    back = compare_results(bad_results, good_results)
    assert {r["id"] for r in back["regressed"]} == fixed and back["score_change"] < 0

    prev = copy.deepcopy(good_results)
    prev["scenarios"] = prev["scenarios"][1:]  # first scenario is "new" now
    prev["scenarios"].append(dict(prev["scenarios"][0], id="old-one", title="Old"))
    prev["scenarios"][0] = dict(prev["scenarios"][0], score=0.5)  # current is higher -> improved (still passing)
    cur = copy.deepcopy(good_results)
    cur["scenarios"][2] = dict(cur["scenarios"][2], score=0.9)  # lower than before -> worse
    changes = {r["id"]: r["change"] for r in compare_results(cur, prev)["rows"]}
    assert changes[good_results["scenarios"][0]["id"]] == "new"
    assert changes["old-one"] == "removed"
    assert changes[good_results["scenarios"][1]["id"]] == "improved"
    assert changes[good_results["scenarios"][2]["id"]] == "worse"
    assert changes[good_results["scenarios"][3]["id"]] == "same"


def test_html_and_console_with_comparison(good_results, bad_results):
    cmp = compare_results(good_results, bad_results)
    html = to_html(good_results, cmp)
    assert "now handled correctly" in html and "Score went from" in html
    text = console_summary(good_results, cmp)
    assert "FIXED" in text and "Compared with previous run" in text
    back = compare_results(bad_results, good_results)
    assert "worked before, fails now" in to_html(bad_results, back)
    assert "REGRESSED" in console_summary(bad_results, back)
    same = compare_results(good_results, good_results)
    assert "No scenario changed" in to_html(good_results, same)


def test_console_summary(bad_results):
    text = console_summary(bad_results)
    assert "FAIL" in text and "Overall:" in text and "->" in text and "grade F" in text


def test_write_outputs(tmp_path, good_results):
    paths = write_outputs(good_results, tmp_path / "out")
    assert sorted(p.name for p in (tmp_path / "out").iterdir()) == ["junit.xml", "results.json", "scorecard.html"]
    assert json.loads(paths["json"].read_text())["summary"]["grade"] == "A"
    ET.parse(paths["junit"])


def test_text_only_wording_and_demo_banner(good_results):
    assert good_results["demo"] is True  # scripted demo agent
    html = to_html(good_results)
    assert "We ran 10 simulated text conversations with the AI receptionist" in html
    assert "no audio or phone line was tested" in html and "We called" not in html
    assert '<div class="demo">Demo data:' in html
    text = console_summary(good_results)
    assert text.splitlines()[0].startswith("Demo data:")
    assert "10 simulated text conversations (text only: no audio or phone line was tested)." in text
    assert json.loads(to_json(good_results))["demo"] is True
    assert '<property name="demo" value="true"' in to_junit(good_results)


def test_real_results_have_no_demo_banner(good_results):
    real = dict(good_results, demo=False, agent={"kind": "http", "description": "webhook https://a.test"})
    assert "Demo data" not in to_html(real) and "Demo data" not in console_summary(real)
    assert json.loads(to_json(real))["demo"] is False
    old = {k: v for k, v in good_results.items() if k != "demo"}  # results.json from before the field existed
    assert json.loads(to_json(old))["demo"] is True


def test_html_never_trusts_summary_numbers(good_results):
    tampered = copy.deepcopy(good_results)
    tampered["summary"].update({"total": EVIL, "passed": EVIL, "critical_failures": EVIL, "score": EVIL})
    tampered["threshold"] = EVIL
    html = to_html(tampered)
    assert "<script>" not in html and "&lt;script&gt;" not in html.split("<section>")[1]
    assert "<b>0 / 0</b>" in html and "<b>-</b>overall score" in html


def test_load_results_not_utf8(tmp_path):
    p = tmp_path / "r.json"
    p.write_bytes(b'{"summary": "\xff\xfe"}')
    with pytest.raises(ReportError, match="UTF-8"):
        load_results(p)
