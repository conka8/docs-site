import datetime as dt

import pytest

from voice_qa.adapters import ScriptedAgent, demo_script
from voice_qa.conversation import AgentReply
from voice_qa.packs import list_packs, load_bundled_pack, resolve_pack
from voice_qa.providers import FakeProvider
from voice_qa.runner import RunError, grade_for, plain_summary, run_pack, summarize


def good(pack):
    return ScriptedAgent(demo_script("good"), pack.default_business_name)


def bad(pack):
    return ScriptedAgent(demo_script("bad"), pack.default_business_name)


def by_id(results):
    return {s["id"]: s for s in results["scenarios"]}


def test_good_agent_scores_high_on_dental():
    pack = load_bundled_pack("dental")
    r = run_pack(pack, good(pack))
    assert r["summary"]["score"] >= 0.9
    assert r["summary"]["grade"] == "A"
    assert r["summary"]["passed"] == r["summary"]["total"] == len(pack.scenarios)
    assert r["summary"]["critical_failures"] == 0
    sc = by_id(r)["emergency"]
    assert sc["ended_by"] == "caller_hung_up" and sc["caller"] == "script"
    assert any("911" in t["text"] for t in sc["transcript"] if t["role"] == "agent")
    # llm_judge checks are skipped (no judge) and do not hurt the score
    angry = by_id(r)["angry-customer"]
    assert any(c["type"] == "llm_judge" and c["skipped"] for c in angry["checks"])


@pytest.mark.parametrize("pack", list_packs(), ids=lambda p: p.name)
def test_good_agent_passes_every_bundled_pack(pack):
    r = run_pack(pack, good(pack))
    failing = [(s["id"], s["summary"]) for s in r["scenarios"] if not s["passed"]]
    assert failing == []


@pytest.mark.parametrize("pack", list_packs(), ids=lambda p: p.name)
def test_bad_agent_fails_the_safety_scenarios(pack):
    r = run_pack(pack, bad(pack))
    s = by_id(r)
    for sid in ("emergency", "are-you-a-robot", "prompt-injection", "asks-for-advice", "asks-price",
                "spanish-speaker", "confirms-phone-number", "angry-customer"):
        assert not s[sid]["passed"], sid
    # the bad agent still handles routine calls, so it is not all-or-nothing
    assert s["book-appointment"]["passed"] and s["wrong-number"]["passed"]
    assert r["summary"]["score"] < 0.6 and r["summary"]["grade"] == "F"
    assert r["summary"]["critical_failures"] >= 6


def test_bad_agent_explanations_are_plain_english():
    pack = load_bundled_pack("dental")
    s = by_id(run_pack(pack, bad(pack)))
    assert "911" in s["emergency"]["summary"]
    assert "real person" in s["are-you-a-robot"]["summary"]
    assert "my instructions are" in s["prompt-injection"]["summary"]
    assert "$99" in s["asks-price"]["summary"]
    assert s["emergency"]["fix_hint"].startswith("Add to the prompt")


def test_business_name_substitution():
    pack = load_bundled_pack("dental")
    r = run_pack(pack, ScriptedAgent(demo_script("good"), "Bright Smiles Fresno"), business_name="Bright Smiles Fresno",
                 scenario_ids=["wrong-number"])
    assert r["business_name"] == "Bright Smiles Fresno"
    assert r["scenarios"][0]["passed"]
    # agent says a different name -> wrong-number check fails on the name but still finds "wrong number"
    r = run_pack(pack, ScriptedAgent(demo_script("good"), "Other Name"), business_name="Bright Smiles Fresno",
                 scenario_ids=["wrong-number"])
    assert r["scenarios"][0]["checks"][0]["passed"]  # "wrong number" phrase still matched


def test_scenario_filter_threshold_and_metadata(fixtures):
    pack = resolve_pack(str(fixtures / "mini_pack.yaml"))
    now = dt.datetime(2026, 10, 1, 12, 0, tzinfo=dt.timezone.utc)
    agent = ScriptedAgent({"first_message": "Test Clinic here.", "default": "I'm an AI. Thanks, bye!"},
                          "Test Clinic")
    r = run_pack(pack, agent, scenario_ids=["robot"], threshold=0.5, now=now,
                 agent_info={"note": "x"}, branding={"brand_name": "Agency"})
    assert [s["id"] for s in r["scenarios"]] == ["robot"]
    assert r["threshold"] == 0.5 and r["generated_at"] == "2026-10-01T12:00:00+00:00"
    assert r["agent"]["kind"] == "scripted" and r["agent"]["note"] == "x"
    assert r["branding"] == {"brand_name": "Agency"} and r["judge"] is None
    assert r["pack"]["name"] == "mini" and r["tool"] == "voice-qa"
    with pytest.raises(RunError, match="Unknown scenario"):
        run_pack(pack, agent, scenario_ids=["nope"])
    with pytest.raises(RunError, match="caller mode"):
        run_pack(pack, agent, caller_mode="psychic")


def test_llm_caller_and_judge_modes(fixtures):
    pack = resolve_pack(str(fixtures / "mini_pack.yaml"))
    agent = ScriptedAgent({"default": "I'm an AI assistant at Test Clinic. Thanks, bye!"}, "Test Clinic")
    with pytest.raises(RunError, match="--caller-provider"):
        run_pack(pack, agent, caller_mode="llm")
    caller = FakeProvider(["Are you a robot? [END]"])
    judge = FakeProvider(['{"score": 1, "reasoning": "fine"}'])
    r = run_pack(pack, agent, caller_mode="llm", caller_provider=caller, judge_provider=judge)
    assert all(s["caller"] == "llm" for s in r["scenarios"])
    assert all(s["passed"] for s in r["scenarios"]), [s["summary"] for s in r["scenarios"]]
    assert r["judge"] == "fake (fake-model)"
    # the caller script lines are passed to the AI caller as hints
    assert "Hello there!" in caller.calls[0][0]


def test_script_mode_requires_script(tmp_path):
    p = tmp_path / "p.yaml"
    p.write_text("name: p\ntitle: P\nscenarios:\n  - id: a\n    title: A\n    persona: x\n    goal: y\n"
                 "    checks: [{type: ends_politely}]\n")
    pack = resolve_pack(str(p))
    agent = ScriptedAgent({"default": "bye"})
    with pytest.raises(RunError, match="no caller_script"):
        run_pack(pack, agent, caller_mode="script")
    with pytest.raises(RunError, match="needs an AI caller"):
        run_pack(pack, agent)


def test_agent_errors_are_recorded_per_scenario(fixtures):
    class Flaky:
        first_message = None
        kind = "custom"
        n = 0

        def reply(self, transcript):
            Flaky.n += 1
            if "robot" in transcript[-1].text:
                raise ConnectionError("agent timed out")
            return AgentReply("Test Clinic. Thank you, bye!")

    r = run_pack(resolve_pack(str(fixtures / "mini_pack.yaml")), Flaky())
    s = by_id(r)
    assert s["greet"]["passed"]
    assert not s["robot"]["passed"] and "agent timed out" in s["robot"]["error"]
    assert s["robot"]["score"] == 0 and s["robot"]["checks"] == []
    assert s["robot"]["summary"].startswith("The test call could not finish")
    assert r["summary"]["errors"] == 1 and r["agent"]["description"] == ""


def test_max_turns_override(fixtures):
    pack = resolve_pack(str(fixtures / "mini_pack.yaml"))
    agent = ScriptedAgent({"default": "Hmm?"})
    r = run_pack(pack, agent, max_turns=1, scenario_ids=["greet"])
    assert r["scenarios"][0]["ended_by"] == "max_turns"
    assert r["scenarios"][0]["agent_turns"] == 1


def test_grades_summary_and_plain_summary():
    assert [grade_for(x) for x in (1, 0.9, 0.85, 0.7, 0.65, 0.2)] == ["A", "A", "B", "C", "D", "F"]
    assert summarize([]) == {"total": 0, "passed": 0, "failed": 0, "errors": 0, "score": 0.0, "pass_rate": 0.0,
                             "grade": "F", "critical_failures": 0}
    failed = [{"passed": False, "skipped": False, "explanation": "Never said 911."}]
    assert plain_summary(False, failed, None) == "Never said 911."
    assert plain_summary(True, failed, None).startswith("Mostly fine")
    assert plain_summary(True, [], None) == "Handled this call well."
    assert "could not finish" in plain_summary(False, [], "boom")
